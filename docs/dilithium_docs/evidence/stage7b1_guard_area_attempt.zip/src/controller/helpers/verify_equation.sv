// Adopt prepared Verify context;compute invNTT(A*z-c*t1),UseHint,pack w1,
// hash mu||w1,and compare ctilde. ONE services tree;no polynomial/message RAM.
// Every adopted region is released before held completion,valid or invalid.
`default_nettype none
module verify_equation (
  input wire logic clk,rst,command_valid_i,output logic command_ready_o,busy_o,fault_o,
  input wire logic [15:0] command_id_i,input wire logic context_valid_i,
  input wire logic [1:0] context_param_i,input wire logic [15:0] context_id_i,input wire logic [63:0] context_regions_i,
  input wire logic [7:0][5:0] context_t1hat_i,context_hints_i,input wire logic [6:0][5:0] context_zhat_i,
  input wire logic [5:0] context_chat_i,input wire logic [255:0] context_rho_i,input wire logic [511:0] context_mu_i,context_ctilde_i,
  output logic context_take_valid_o,input wire logic context_take_ready_i,
  output logic done_valid_o,input wire logic done_ready_i,output logic [15:0] done_id_o,
  output logic [2:0] done_code_o,done_detail_o,output logic done_accept_o,output logic [511:0] done_digest_o,
  output dilithium_service_pkg::request_t service_o,input dilithium_service_pkg::response_t service_i
);
  typedef enum logic [5:0] {IDLE,CHECK,PLAN,TAKE,A_START,A_WAIT,PWM_START,PWM_WAIT,PWM_RETIRE,
    PROCESS_START,PROCESS_WAIT,PROCESS_RETIRE,FREE_PRODUCT,INVERSE_START,INVERSE_WAIT,INVERSE_RETIRE,
    FREE_ROW,HASH_START,PACK_START,READ_W_REQ,READ_W_RESP,READ_H_REQ,READ_H_RESP,FEED,PACK_WAIT,HASH_WAIT,DRAIN,CLEAN,REPORT,HALT} state_e;
  state_e state;
  logic [1:0] param_r,lane_r;logic [15:0] id_r;logic [3:0] k_r,l_r,row_r,column_r;
  logic [7:0][5:0] t1_r,hints_r,w_r;logic [6:0][5:0] z_r,a_r;logic [5:0] chat_r,acc_r,product_r,scan_r,count_r,needed_r,word_r;
  logic [255:0] rho_r;logic [511:0] mu_r,ctilde_r,digest_r;logic [63:0] original_r,plan_r,owned_r,persistent_r;
  logic [3:0] command_k,command_l;logic [63:0] command_mask;logic layout_bad,source_changed,quiescent,incomplete,challenge_product_r,accept_r;
  logic [2:0] code_r,detail_r;logic a_issued_r,a_retired_r,a_core_r;
  logic ar,aq,am,ai,ad,ae,aack;logic [15:0] alen,aout,aid;logic [63:0] adata;
  logic fr,fb,fq,fqr,fs,fm,fi,fl,fd,fack,fpayload,fpr;logic [1:0] fp;
  logic [15:0] fid,flen,fout,findex,fdid,body_words_r;logic [63:0] fdata;logic [3:0] fbytes;logic [2:0] fcode;
  logic pack_active_r,read_pending_r,raw_started_r,raw_retired_r,raw_core_r;logic [6:0] raw_bytes_r,ctbytes,pack_words_r,words_per_poly;
  logic [8:0] sent_r;logic [91:0] wcache_r,hcache_r;logic [5:0] hinted;logic hint_bad;
  logic hash_live,out_fire,raw_done,pack_out,pack_done,read_bad,pack_bad,raw_bad;logic [2:0] hash_error,hash_detail;
  logic [31:0][5:0] command_list;logic [31:0] command_active;logic [64:0] command_check;
  always_comb begin
    command_k=context_param_i==0?4'd4:context_param_i==1?4'd6:4'd8;
    command_l=context_param_i==0?4'd4:context_param_i==1?4'd5:4'd7;
    command_list='0;command_active=0;
    for(int j=0;j<8;j++)if(j<int'(command_k))begin
      command_list[j]=context_t1hat_i[j];command_active[j]=1;
      command_list[8+j]=context_hints_i[j];command_active[8+j]=1;
    end
    for(int j=0;j<7;j++)if(j<int'(command_l))begin
      command_list[16+j]=context_zhat_i[j];command_active[16+j]=1;
    end
    command_list[23]=context_chat_i;command_active[23]=1;
    command_check=dilithium_service_pkg::checked_handle_set(command_list,command_active);
    command_mask=command_check[63:0];layout_bad=command_check[64];
    layout_bad|=command_mask!=context_regions_i || (context_param_i==0 && context_ctilde_i[511:256]!=0) ||
      (context_param_i==1 && context_ctilde_i[511:384]!=0);
  end
  assign source_changed=!context_valid_i || context_param_i!=param_r || context_id_i!=id_r || context_regions_i!=original_r ||
    context_t1hat_i!=t1_r || context_hints_i!=hints_r || context_zhat_i!=z_r || context_chat_i!=chat_r ||
    context_rho_i!=rho_r || context_mu_i!=mu_r || context_ctilde_i!=ctilde_r;
  assign quiescent=service_i.active==0 && !service_i.op_busy && !service_i.process_busy && !service_i.sign.busy &&
    !service_i.load.busy && !service_i.row_busy && !service_i.response_valid && service_i.read_ready &&
    service_i.pack.command_ready && !service_i.pack.output_valid && !service_i.pack.done_valid;
  assign incomplete=((service_i.reserved & (original_r|plan_r)) & ~service_i.complete)!=0;
  assign command_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault;
  assign busy_o=state!=IDLE;assign done_valid_o=!rst && state==REPORT && !fault_o;
  assign done_id_o=id_r;assign done_code_o=code_r;assign done_detail_o=detail_r;
  assign done_accept_o=done_valid_o && code_r==0 && accept_r;assign done_digest_o=done_valid_o && code_r==0?digest_r:512'd0;
  assign context_take_valid_o=state==TAKE && quiescent && !source_changed && !fault_o;
  assign ctbytes=param_r==0?7'd32:param_r==1?7'd48:7'd64;
  assign words_per_poly=param_r==0?7'd24:7'd16;
  assign hash_live=state>=HASH_START && state<=DRAIN;
  keygen_hash_message matrix_message(.clk(clk),.rst(rst),.command_valid_i(state==A_START && !fault_o),.command_ready_o(ar),
    .command_op_i(2'd1),.command_param_i(param_r),.command_id_i(id_r),.command_nonce_i(16'd0),
    .command_row_i({4'd0,row_r}),.command_column_i({4'd0,column_r}),.command_seed_i({256'd0,rho_r}),
    .request_valid_o(aq),.request_ready_i(state==A_WAIT && service_i.job_ready && !fault_o),.request_mode_o(am),
    .request_message_len_o(alen),.request_output_len_o(aout),.input_data_o(adata),.input_valid_o(ai),
    .input_ready_i(state==A_WAIT && service_i.input_ready && !fault_o),.done_valid_o(ad),.done_ready_i(aack),.done_error_o(ae),.done_id_o(aid));
  assign aack=state==A_WAIT && ad && a_retired_r && service_i.active==0 && !fault_o;
  use_hint correction(.param_i(param_r),.coefficient_i(wcache_r[23*lane_r+:23]),.hint_i(hcache_r[23*lane_r+:23]),.high_o(hinted),.error_o(hint_bad));
  sign_hash_message formatter(.clk(clk),.rst(rst),.command_valid_i(state==HASH_START && !fault_o),.command_ready_o(fr),.busy_o(fb),
    .command_op_i(2'd2),.command_param_i(param_r),.command_id_i(id_r),.command_message_len_i(16'd0),.command_nonce_i(16'd0),.command_context_len_i(9'd0),
    .command_tr_i(512'd0),.command_mu_i(mu_r),.command_mask_seed_i(512'd0),.command_key_i(256'd0),.command_rnd_i(256'd0),
    .payload_valid_i(fpayload),.payload_ready_o(fpr),.payload_data_i(state==DRAIN?64'd0:service_i.pack.output_data),
    .payload_bytes_i(state==DRAIN?4'd0:service_i.pack.output_bytes),.payload_index_i(body_words_r),
    .payload_last_i(state!=DRAIN && row_r==k_r-1'b1 && service_i.pack.output_last),
    .request_valid_o(fq),.request_ready_i(fqr),.request_sampling_o(fs),.request_mode_o(fm),.request_param_o(fp),.request_id_o(fid),
    .request_message_len_o(flen),.request_output_len_o(fout),.input_valid_o(fi),.input_ready_i(hash_live && service_i.raw_input_ready && !fault_o),
    .input_data_o(fdata),.input_bytes_o(fbytes),.input_index_o(findex),.input_last_o(fl),.done_valid_o(fd),.done_ready_i(fack),.done_code_o(fcode),.done_id_o(fdid));
  assign fpayload=hash_live && !fault_o && (state==DRAIN || (pack_active_r && service_i.pack.output_valid));
  assign fqr=hash_live && service_i.raw_ready && !fault_o;
  assign fack=(state==HASH_WAIT || state==DRAIN) && fd && !pack_active_r && !read_pending_r && raw_retired_r && service_i.active==0 && !fault_o;
  assign out_fire=service_i.raw_output_valid && service_o.raw_output_ready;
  assign raw_done=service_i.raw_done_valid && service_o.raw_done_ready;
  assign pack_out=service_i.pack.output_valid && service_o.pack.output_ready;
  assign pack_done=service_i.pack.done_valid && service_o.pack.done_ready;
  assign read_bad=service_i.response_error || service_i.response_word!=word_r || service_i.response_id!=id_r || service_i.response_param!=param_r || service_i.response_ntt_domain ||
    {service_i.response_bank,service_i.response_region}!=(state==READ_W_RESP?w_r[row_r]:hints_r[row_r]) ||
    service_i.response_mode!=(state==READ_W_RESP?2'd0:2'd3);
  assign pack_bad=service_i.pack.output_id!=id_r || service_i.pack.output_bytes!=8 || service_i.pack.output_index!=pack_words_r ||
    pack_words_r>=words_per_poly || service_i.pack.output_last!=(pack_words_r==words_per_poly-1'b1);
  always_comb begin
    raw_bad=out_fire && (service_i.raw_output_core!=raw_core_r || service_i.raw_output_id!=id_r || service_i.raw_output_bytes!=16 || raw_bytes_r>=ctbytes || raw_retired_r);
    if(raw_done)raw_bad|=service_i.raw_done_core!=raw_core_r || service_i.raw_done_id!=id_r || raw_bytes_r+(out_fire?7'd16:7'd0)!=ctbytes || raw_retired_r;
    hash_error=0;hash_detail=0;
    if((state==READ_W_RESP || state==READ_H_RESP) && service_i.response_valid && read_bad)hash_error=6;
    if(state==FEED && hint_bad)hash_error=6;
    if(pack_out && state!=DRAIN && pack_bad)hash_error=7;
    if(pack_done && state!=DRAIN && (service_i.pack.done_id!=id_r || service_i.pack.done_code!=0 || sent_r!=256 || pack_words_r!=words_per_poly))begin hash_error=7;hash_detail=service_i.pack.done_code;end
    service_o='0;
    service_o.job_valid=state==A_WAIT && aq && !fault_o;service_o.job_mode=0;service_o.job_param=param_r;
    service_o.job_id=id_r;{service_o.job_bank,service_o.job_region}=a_r[column_r];service_o.message_len=alen;
    service_o.input_valid=state==A_WAIT && ai && !fault_o;service_o.input_data=adata;
    service_o.status_ready=state==A_WAIT && a_issued_r && !a_retired_r && !fault_o;
    service_o.op_valid=(state==PWM_START || state==INVERSE_START) && !fault_o;service_o.op=state==INVERSE_START?2'd1:2'd2;
    service_o.op_a_region=state==INVERSE_START?acc_r:challenge_product_r?chat_r:a_r[column_r];
    service_o.op_b_region=challenge_product_r?t1_r[row_r]:z_r[column_r];
    service_o.op_a_id=id_r;service_o.op_b_id=id_r;service_o.op_id=id_r;
    service_o.op_dest_region=state==INVERSE_START?w_r[row_r]:(!challenge_product_r && column_r==0?acc_r:product_r);
    service_o.op_done_ready=(state==PWM_WAIT || state==INVERSE_WAIT) && !fault_o;
    service_o.process_valid=state==PROCESS_START && !fault_o;service_o.process_op=challenge_product_r?2'd1:2'd0;
    service_o.process_inplace=1;service_o.process_a=acc_r;service_o.process_b=product_r;service_o.process_dest=acc_r;
    service_o.process_a_id=id_r;service_o.process_b_id=id_r;service_o.process_id=id_r;service_o.process_done_ready=state==PROCESS_WAIT && !fault_o;
    service_o.pack.command_valid=state==PACK_START && !fault_o;service_o.pack.command_op=3;service_o.pack.command_param=param_r;service_o.pack.command_id=id_r;
    service_o.pack.input_valid=pack_active_r && !fault_o && ((state==FEED && !hint_bad) || (state==DRAIN && sent_r<256));
    service_o.pack.input_data=state==DRAIN?23'd0:{17'd0,hinted};service_o.pack.input_index=sent_r[7:0];service_o.pack.input_last=sent_r==255;
    service_o.pack.output_ready=hash_live && pack_active_r && !fault_o && (state==DRAIN || fpr);
    service_o.pack.done_ready=hash_live && pack_active_r && !fault_o && (state==PACK_WAIT || state==DRAIN || service_i.pack.done_code!=0 || service_i.pack.done_id!=id_r);
    service_o.read_valid=(state==READ_W_REQ || state==READ_H_REQ) && !fault_o;
    {service_o.read_bank,service_o.read_region}=state==READ_W_REQ?w_r[row_r]:hints_r[row_r];service_o.read_word=word_r;
    service_o.response_ready=!fault_o && (state==READ_W_RESP || state==READ_H_RESP || (state==DRAIN && read_pending_r));
    service_o.raw_valid=hash_live && fq && !fault_o;service_o.raw_mode=fm;service_o.raw_id=fid;service_o.raw_message_len=flen;service_o.raw_output_len=fout;
    service_o.raw_input_valid=hash_live && fi && !fault_o;service_o.raw_input_data=fdata;
    service_o.raw_output_ready=hash_live && raw_started_r && !raw_retired_r && !fault_o;service_o.raw_done_ready=service_o.raw_output_ready;
    service_o.release_valid=!fault_o && ((state==FREE_PRODUCT && owned_r[product_r]) ||
      (state==FREE_ROW && owned_r[scan_r] && plan_r[scan_r] && !persistent_r[scan_r]) || (state==CLEAN && owned_r[scan_r]));
    {service_o.release_bank,service_o.release_region}=state==FREE_PRODUCT?product_r:scan_r;
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;id_r<=0;k_r<=0;l_r<=0;row_r<=0;column_r<=0;t1_r<=0;hints_r<=0;w_r<=0;z_r<=0;a_r<=0;chat_r<=0;acc_r<=0;product_r<=0;
      scan_r<=0;count_r<=0;needed_r<=0;word_r<=0;rho_r<=0;mu_r<=0;ctilde_r<=0;digest_r<=0;original_r<=0;plan_r<=0;owned_r<=0;persistent_r<=0;
      code_r<=0;detail_r<=0;challenge_product_r<=0;accept_r<=0;a_issued_r<=0;a_retired_r<=0;a_core_r<=0;
      lane_r<=0;pack_active_r<=0;read_pending_r<=0;raw_started_r<=0;raw_retired_r<=0;raw_core_r<=0;raw_bytes_r<=0;pack_words_r<=0;body_words_r<=0;sent_r<=0;wcache_r<=0;hcache_r<=0;fault_o<=0;
    end else if((service_i.fault && state!=IDLE) || raw_bad)begin fault_o<=1;state<=HALT;end
    else begin
      if(service_o.read_valid && service_i.read_ready)read_pending_r<=1;
      if(service_o.response_ready && service_i.response_valid)read_pending_r<=0;
      if(service_o.pack.input_valid && service_i.pack.input_ready)sent_r<=sent_r+1'b1;
      if(pack_out)pack_words_r<=pack_words_r+1'b1;
      if(pack_done)pack_active_r<=0;
      if(fpayload && fpr && state!=DRAIN)body_words_r<=body_words_r+1'b1;
      if(service_o.raw_valid && service_i.raw_ready)begin raw_started_r<=1;raw_core_r<=service_i.raw_core;end
      if(out_fire)begin digest_r[8*raw_bytes_r+:128]<=service_i.raw_output_data;raw_bytes_r<=raw_bytes_r+16;end
      if(raw_done)raw_retired_r<=1;
      if(hash_error!=0 && state!=DRAIN)begin code_r<=hash_error;detail_r<=hash_detail;state<=DRAIN;end
      else case(state)
        IDLE:if(command_valid_i && command_ready_o)begin
          param_r<=context_param_i;id_r<=command_id_i;k_r<=command_k;l_r<=command_l;needed_r<=6'(command_k+command_l+2);
          t1_r<=context_t1hat_i;hints_r<=context_hints_i;z_r<=context_zhat_i;chat_r<=context_chat_i;rho_r<=context_rho_i;mu_r<=context_mu_i;ctilde_r<=context_ctilde_i;
          original_r<=context_regions_i;plan_r<=0;owned_r<=0;persistent_r<=0;code_r<=0;detail_r<=0;scan_r<=0;count_r<=0;row_r<=0;column_r<=0;accept_r<=0;digest_r<=0;
          a_r<=0;w_r<=0;acc_r<=0;product_r<=0;raw_started_r<=0;raw_retired_r<=0;raw_bytes_r<=0;pack_active_r<=0;read_pending_r<=0;body_words_r<=0;
          if(!context_valid_i || context_param_i==3 || context_id_i!=command_id_i || layout_bad)begin code_r<=1;state<=REPORT;end else state<=CHECK;
        end
        CHECK:if(!quiescent || source_changed || (service_i.reserved & original_r)!=original_r || (service_i.complete & original_r)!=original_r)begin code_r<=2;state<=REPORT;end else state<=PLAN;
        PLAN:begin
          if(source_changed)begin code_r<=2;state<=REPORT;end
          else begin
            if(!service_i.reserved[scan_r] && count_r<needed_r)begin
              plan_r[scan_r]<=1;count_r<=count_r+1'b1;
              if(count_r<l_r)a_r[count_r]<=scan_r;
              else if(count_r==l_r)acc_r<=scan_r;
              else if(count_r==l_r+1)product_r<=scan_r;
              else begin w_r[count_r-6'(l_r)-2]<=scan_r;persistent_r[scan_r]<=1;end
            end
            if(scan_r==63)begin
              if(count_r==needed_r || (count_r==needed_r-1'b1 && !service_i.reserved[scan_r]))state<=TAKE;
              else begin code_r<=3;state<=REPORT;end
            end else scan_r<=scan_r+1'b1;
          end
        end
        TAKE:if(source_changed)begin code_r<=2;state<=REPORT;end else if(context_take_valid_o && context_take_ready_i)begin owned_r<=original_r;state<=A_START;end
        A_START:if(ar)begin a_issued_r<=0;a_retired_r<=0;state<=A_WAIT;end
        A_WAIT:begin
          if(aq && service_i.job_ready)begin a_issued_r<=1;a_core_r<=service_i.job_core;end
          if(service_i.status_valid && service_o.status_ready)begin
            a_retired_r<=1;
            if(service_i.status_id!=id_r || service_i.status_core!=a_core_r)code_r<=7;
            else if(service_i.status_code!=0)begin code_r<=4;detail_r<=service_i.status_code;end
          end
          if(aack)begin
            owned_r<=service_i.reserved & (original_r|plan_r);
            if(incomplete)begin fault_o<=1;state<=HALT;end
            else if(code_r!=0 || ae || aid!=id_r || !service_i.complete[a_r[column_r]])begin if(code_r==0)code_r<=4;scan_r<=0;state<=CLEAN;end
            else if(column_r==l_r-1'b1)begin column_r<=0;challenge_product_r<=0;state<=PWM_START;end
            else begin column_r<=column_r+1'b1;state<=A_START;end
          end
        end
        PWM_START:if(service_i.op_ready)state<=PWM_WAIT;
        PWM_WAIT:if(service_i.op_done_valid)begin
          if(service_i.op_done_id!=id_r || service_i.op_done_region!=(!challenge_product_r && column_r==0?acc_r:product_r))code_r<=7;
          else if(service_i.op_done_code!=0)begin code_r<=5;detail_r<=service_i.op_done_code;end
          state<=PWM_RETIRE;
        end
        PWM_RETIRE:if(!service_i.op_busy)begin
          owned_r<=service_i.reserved & (original_r|plan_r);
          if(incomplete)begin fault_o<=1;state<=HALT;end
          else if(code_r!=0)begin scan_r<=0;state<=CLEAN;end
          else if(!challenge_product_r && column_r==0)begin column_r<=1;state<=PWM_START;end
          else state<=PROCESS_START;
        end
        PROCESS_START:if(service_i.process_ready)state<=PROCESS_WAIT;
        PROCESS_WAIT:if(service_i.process_done_valid)begin
          if(service_i.process_done_id!=id_r || service_i.process_done_dest!=acc_r)code_r<=7;
          else if(service_i.process_done_code!=0)begin code_r<=5;detail_r<=service_i.process_done_code;end
          state<=PROCESS_RETIRE;
        end
        PROCESS_RETIRE:if(!service_i.process_busy)begin
          owned_r<=service_i.reserved & (original_r|plan_r);
          if(incomplete)begin fault_o<=1;state<=HALT;end else if(code_r!=0)begin scan_r<=0;state<=CLEAN;end else state<=FREE_PRODUCT;
        end
        FREE_PRODUCT:if(service_i.release_ready)begin
          owned_r[product_r]<=0;
          if(challenge_product_r)state<=INVERSE_START;
          else if(column_r==l_r-1'b1)begin challenge_product_r<=1;state<=PWM_START;end
          else begin column_r<=column_r+1'b1;state<=PWM_START;end
        end
        INVERSE_START:if(service_i.op_ready)state<=INVERSE_WAIT;
        INVERSE_WAIT:if(service_i.op_done_valid)begin
          if(service_i.op_done_id!=id_r || service_i.op_done_region!=w_r[row_r])code_r<=7;
          else if(service_i.op_done_code!=0)begin code_r<=5;detail_r<=service_i.op_done_code;end
          state<=INVERSE_RETIRE;
        end
        INVERSE_RETIRE:if(!service_i.op_busy)begin
          owned_r<=service_i.reserved & (original_r|plan_r);scan_r<=0;
          if(incomplete)begin fault_o<=1;state<=HALT;end else state<=code_r==0?FREE_ROW:CLEAN;
        end
        FREE_ROW:if(!owned_r[scan_r] || !plan_r[scan_r] || persistent_r[scan_r] || service_i.release_ready)begin
          if(plan_r[scan_r] && !persistent_r[scan_r])owned_r[scan_r]<=0;
          if(scan_r==63)begin
            if(row_r==k_r-1'b1)begin row_r<=0;word_r<=0;body_words_r<=0;state<=HASH_START;end
            else begin row_r<=row_r+1'b1;column_r<=0;state<=A_START;end
          end else scan_r<=scan_r+1'b1;
        end
        HASH_START:if(fr)begin raw_started_r<=0;raw_retired_r<=0;raw_bytes_r<=0;digest_r<=0;state<=PACK_START;end
        PACK_START:if(service_i.pack.command_ready)begin pack_active_r<=1;sent_r<=0;pack_words_r<=0;word_r<=0;state<=READ_W_REQ;end
        READ_W_REQ:if(service_i.read_ready)state<=READ_W_RESP;
        READ_W_RESP:if(service_i.response_valid)begin wcache_r<=service_i.response_data;state<=READ_H_REQ;end
        READ_H_REQ:if(service_i.read_ready)state<=READ_H_RESP;
        READ_H_RESP:if(service_i.response_valid)begin hcache_r<=service_i.response_data;lane_r<=0;state<=FEED;end
        FEED:if(service_o.pack.input_valid && service_i.pack.input_ready)begin
          if(lane_r!=3)lane_r<=lane_r+1'b1;
          else if(word_r==63)state<=PACK_WAIT;
          else begin word_r<=word_r+1'b1;state<=READ_W_REQ;end
        end
        PACK_WAIT:if(pack_done)begin
          if(row_r==k_r-1'b1)state<=HASH_WAIT;
          else begin row_r<=row_r+1'b1;state<=PACK_START;end
        end
        HASH_WAIT:if(fack)begin
          if(fcode!=0 || fdid!=id_r)begin code_r<=7;detail_r<=fcode;end
          else accept_r<=digest_r==ctilde_r;
          scan_r<=0;state<=CLEAN;
        end
        DRAIN:if(fack)begin scan_r<=0;state<=CLEAN;end
        CLEAN:if(!owned_r[scan_r] || service_i.release_ready)begin
          owned_r[scan_r]<=0;
          if(scan_r==63)state<=REPORT;else scan_r<=scan_r+1'b1;
        end
        REPORT:if(done_ready_i)state<=IDLE;
        HALT:state<=HALT;
        default:begin fault_o<=1;state<=HALT;end
      endcase
    end
  end
endmodule
`default_nettype wire
