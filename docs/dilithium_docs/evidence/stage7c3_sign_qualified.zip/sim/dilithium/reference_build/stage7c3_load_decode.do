onerror {quit -code 1 -f}
vlib sim/dilithium/work_lighthd_load
vmap lighthd_load_work sim/dilithium/work_lighthd_load
vlog -sv -work lighthd_load_work src/controller/process/lighthd_bitunpkg.sv src/controller/process/lighthd_secret_regroup.sv src/controller/datapath/lighthd_sampler_writer.sv src/controller/datapath/lighthd_load_decode.sv src/controller/memory/poly_bram.sv src/controller/memory/memory_banks.sv src/controller/memory/lighthd_memory_port.sv src/controller/memory/lighthd_memory.sv src/controller/memory/lighthd_memory_router.sv src/controller/memory/lighthd_bank_fabric.sv tb/tb_dilithium/lighthd_bank_fixture.sv tb/tb_dilithium/tb_lighthd_load_decode.sv
vsim -voptargs=+acc lighthd_load_work.tb_lighthd_load_decode
run -all
quit -f
