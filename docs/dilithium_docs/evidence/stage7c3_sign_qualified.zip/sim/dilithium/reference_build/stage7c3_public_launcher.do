onerror {quit -code 1 -f}
set DILITHIUM_STAGE 7
set DILITHIUM_TEST lighthd_sign_diagnostic
do sim/dilithium/run.do
quit -sim
set DILITHIUM_TEST lighthd_sign_protocol
do sim/dilithium/run.do
quit -sim
set DILITHIUM_TEST lighthd_keygen_protocol
do sim/dilithium/run.do
quit -f
