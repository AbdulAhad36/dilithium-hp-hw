# Dilithium reference verification

## Stage5N.4f yhat,A*y and decomposition

The focused harness connects real sign_key_prepare -> sign_mask_prepare ->
sign_matrix_prepare to ONE actual dilithium_services. No expected polynomial
or digest is injected into RTL;no RAM is preloaded. Original y and the
prepared key remain retained while every matrix row is sampled,computed,
inverse-transformed and decomposed into w0/w1. Main Sign is not enabled yet.

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_matrix
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_matrix
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_matrix
```

| File | Role |
|---|---|
|src/controller/helpers/sign_matrix_prepare.sv|Free-address plan,FNTT(y),A-row sampler/row MAC/decomposition schedule,result validation,rollback,retained READY/clear |
|tb/tb_dilithium/tb_sign_matrix_prepare.sv|Three real clients and one services tree,declared stall/result-fault adapters,real capacity blockers,exact bank readback and reset recovery |
|tb/tb_dilithium/sign_matrix_reference.c|Test adapter around unchanged C uniform_gamma1,matrix expansion,NTT/PWM/INTT/decompose;canonical printed values |
|sim/dilithium/dilithium_vectors.py|sign_matrix_material/cases/artifact,check_sign_matrix_c,verify_sign_matrix and compare/selftest selector |
|sim/dilithium/stage5_sign_matrix_inputs.txt|Python-generated command/reset/fault fields,three published SK inputs,rnd and message payload |
|sim/dilithium/stage5_sign_matrix_outputs.txt|Questa-produced actual DUT capture |
|sim/dilithium/stage5_sign_matrix_c_reference.log|Six complete intermediate-vector fixtures,96256 coefficient comparisons |
|sim/dilithium/stage5_sign_matrix_compare.log|Independent expected-value/ownership/retirement/readback verdict |
|sim/dilithium/stage5_sign_matrix_checker_selftest.log|Corrupted-capture negative gate |

Study the helper in execution order:CHECK/PLAN chooses disjoint free regions;
NTT_START/WAIT preserves original y;A_START/WAIT constructs exact rho/column/
row messages;ROW_START/WAIT uses existing PWM/ADD/INTT;DECOMP_START/WAIT/
RETIRE validates both outputs;FREE_ROW reuses row workspace;REPORT/READY/
CLEAN retain or release the new vector. SPECIFICATION.md gives codes/ports,
MEMORY_MAP.md gives dimensions/lifetimes,PROCESS_BLOCKS.md explains each step.

Capture records:H source;K prepared key publication;M real mask publication;
I initial reservation map;C command;G chosen workspace;N/O forward request/
result;J/W/S A descriptor/absorption/status;R/Q row request/result;D/B
decomposition request/result;X physical scalar writes;F memory finish ACK;
L releases;P whole-vector publication;E parent result;V exact packed reads;
T stalls/peak allocations;A reset/fault abort;Z totals. Row-internal PWM,
accumulator ADD and inverse writes are checked too,not only final reads.

The oracle uses independent direct root evaluation/inverse formulas,plain
modular products and mathematical decomposition. It agrees with unchanged C
on both nonce0 and nonce=l at every level:6 complete fixtures,96256 values
across y,yhat,A,w,w0,w1. C's Montgomery PWM/inverse factors cancel in w;
RTL row intermediates use ordinary modular residues. Expectations are local
FIPS-derived intermediates,not published official sigGen vectors. Only three
secret-key input fixtures come from the existing pinned NIST KeyGen corpus.

The gate includes all k rows at levels2/3/5,ID65535 wrap,nonzero nonce,
actual sampled capacity blockers,real wrong-source-ID NTT/row/decomposition
rejections,observed NTT/A/row/decomposition result-tag faults after earlier
work,and exact preservation of the key,y,sentinel and blockers. Reset points
cover partial FNTT output,partial A sample,partial row PWM,between low/high
decomposition finish ACKs,held successful result,and an injected parent fault
followed by GLOBAL reset/reload/recovery. A few outstanding physical writes
after that injected parent fault are checked as aborted work,never success.

Final fresh gates PASS:

-66 commands =24 successful executions +24 expected errors +18 reset/fault
  aborts.48 normal completions. Successful executions reuse six distinct
  level/nonce combinations,including recovery runs.
-1060230 exact scalar writes cover FNTT,A sampling,PWM,in-place ADD,INTT,
  both decomposition outputs and aborted prefixes.4137 physical finish ACKs.
-102336 exact packed reads =8192 yhat +9216 w0 +9216 w1 +53248 prepared-key
  +16384 original-y +3072 sentinel +3008 capacity-blocker words. Final output
  reads26624 x4=106496 coefficients across24 whole-vector executions.
-303 forward requests,1192 A jobs,210 row commands and198 decompositions;
  corresponding retirements300/1189/204/195. Interruptions get no success
  credit.21 actual key preparations and27 actual mask-vector generations
  reuse three published SK input fixtures.
-Normal success peak allocated regions34/46/62,including one unrelated
  sentinel. Deliberately filled capacity tests raise the all-case level2
  peak to46. Address-plan budgets and actual allocations are distinct counts;
  see MEMORY_MAP.md/THROUGHPUT.md for arithmetic and full release accounting.
-Seven stall totals[260,1389,175,166,3760,1772,973] cover forward/A/row/
  decomposition commands,input,child completions and releases.
-66/66 mutated/missing/duplicate capture cases reject. Fresh local full-
  KeyGen also passes8 complete C-reference keypairs,3 rejects,5 resets,
  5433 exact key words,2058 hash-input words,656 tr bytes,11179 field reads
  and37/37 checker faults. These are the two fresh RTL gates at this token;
  earlier unrelated captures retain their own historical provenance.

Source token:
e08c7d68837cb2a9a702ebe761af37a6ed53429299bf49947ded7d95f7a99025.
Create-only archive:evidence/stage5n4f_sign_matrix.zip +.sha256,containing
MANIFEST.csv,RESULT.txt,source/fixtures,fresh C-reference logs and both fresh
RTL/comparison/negative gates. CRC,member hashes/sizes and current disk bytes
are checked. The first read-only diagnostic capture was not retagged or reused
as final checkpoint evidence. All59 prior RTL files and6.757ns SDC remain
byte-identical to4e;only one new control helper is added. No synthesis/PPA,
netlist/full-UVM,board/security or full-signature claim.

## Stage5N.4e retained key to signing hashes and mask vector

The new control-only helpers/sign_mask_prepare.sv is connected in a focused
owner harness to real sign_key_prepare and one actual dilithium_services.
K/tr come from a validated,transformed,retained key. Actual RTL mu feeds the
private-seed hash;actual RTL seed feeds every sampler nonce. No expected
digest or polynomial is injected into the RTL. Main Sign remains unfinished.

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_mask
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_mask
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_mask
```

| File | Role |
|---|---|
|src/controller/helpers/sign_mask_prepare.sv|Hash/seed/vector schedule,private result collection,retirement barriers,rollback and retained clear |
|tb/tb_dilithium/tb_sign_mask_prepare.sv|Both real clients,one services instance,declared handshake stalls/result-fault adapters,real mask/key/sentinel reads |
|sim/dilithium/dilithium_vectors.py|sign_mask_cases/artifact,check_sign_mask_c,verify_sign_mask,compare/selftest selector |
|tb/tb_dilithium/sign_hash_reference.c|Existing component adapter around unchanged C SHAKE256 and poly_uniform_gamma1;no new C model |
|sim/dilithium/stage5_sign_mask_inputs.txt|Python-generated commands,rnd,payloads and three published SK input fixtures |
|sim/dilithium/stage5_sign_mask_outputs.txt|Questa-generated capture;never a Python-generated DUT output |
|sim/dilithium/stage5_sign_mask_c_reference.log|Independent Python/C component agreement |
|sim/dilithium/stage5_sign_mask_compare.log|Strict expected-message/digest/coefficient/metadata comparison |
|sim/dilithium/stage5_sign_mask_checker_selftest.log|85 deliberately corrupted captures rejected |

Read the helper in execution order:CHECK -> START/WAIT_RESULT for op0 mu ->
op1 private seed -> op3 for each nonce -> REPORT/READY -> CLEAN. The sampler
status handshake accepts memory finish on the same edge;complete is checked
after that retirement,not before the acknowledgment changes bank metadata.
The initial controller's premature check was found and corrected;only the
fresh passing source/capture belongs to the final checkpoint.

Capture records:H source token;K newly prepared key header/map;C command;
D descriptor/assigned core;W exact absorption word;R raw digest beat;
S raw/sampler retirement;X scalar bank write;P whole successful publication;
E held parent result;V privileged mask/key/sentinel packed read;L mask release;
A reset/fault abort;T handshake-stall witnesses;F totals. The independent
checker enforces descriptor order,full absorption/retirement before dependent
descriptors,exact tags/lengths/bytes,all sampled writes,publication and cleanup.

Final primary gate PASS:

-78 commands =27 successes +36 expected errors +15 reset/fault aborts;
  63 normal completions. Levels2/3/5 each contribute26 commands.
-18 actual key preparations reuse three published NIST KeyGen SK inputs;
  each context is reused across commands and reloaded after global reset.
  This gate does not rerun all75 SKs;the prior4d gate does.
-4464 exact absorption words;6800 physical digest bytes in425 x16-byte beats.
  Deliberate observed-byte-count faults are checked separately from physical
  128-bit data transfer;discarded/error diagnostic digests are not successes.
-49094 scalar mask writes =191 complete polynomials x256 +198 partial
  coefficients. Six partial vectors have32/34 writes in their interrupted
  second polynomial. Every observed value is checked;aborts get no success.
-83136 exact92-bit reads =9216 mask +69888 prepared-key +4032 sentinel words.
  Mask reads check36864 coefficients from27 complete vectors. Key/sentinel
  reads prove noninterference after every non-reset success/error.
-308 accepted descriptors =60 mu +51 seed +197 mask. Retirements are
  57/48/191 respectively;12 requests are interrupted by reset/fault.
-169 mask-region releases;none releases a key/sentinel region. Per-level
  mask counts4/5/7,upper valid nonce65536-l,overflow,bounds,alias,occupied
  plan,255-byte context,empty message and deterministic rnd are exercised.
-Malformed payload drains without seed forwarding. Wrong observed raw ID,
  raw byte count,raw-done ID,mask status ID and mask status code stop dependent
  work and discard any accumulated masks. These are explicit result adapters,
  not claims that the unchanged engines spontaneously produced bad results.
-Five abort phases per level:mu output,seed output,partial second mask,
  held successful done,and injected physical-fault response during a partial
  vector. Global reset/reload/recovery follows each. Held done/READY results
  remain stable;new command fields are poisoned after acceptance.
-Descriptor/input/output/status/release stall totals:
  [224,3908,228,616,106].85/85 checker corruptions reject.

Python hashlib plus independent sampler arithmetic agrees with unchanged C
on462 intended component messages/45606 bytes/336 mask polynomials. These
intermediate expectations are local FIPS-derived vectors. Only the three SK
inputs originate in the existing pinned official NIST KeyGen corpus;this is
not an official sigGen vector or complete signature claim.

Fresh local full-KeyGen regression also passes:8 complete independent-C
keypairs,3 expected rejects,5 reset aborts;5433 exact key words,2058 public-key
hash input words,656 tr bytes and11179 field-read words.37/37 checker faults
reject. These are the two fresh RTL gates at this token;older unrelated
captures retain their previous checkpoint provenance and are not relabeled.

All58 prior RTL files and6.757ns SDC remain byte-identical to4d;only one new
control helper is added. No PPA/netlist/full-UVM/board/security result is
created. Source token:
53e7a2e7883166e9b384e8b8dbbe8f6fe9d5b01037e8c045c800832f67edd78b.
Create-only evidence:evidence/stage5n4e_sign_masks.zip,with MANIFEST.csv and
RESULT.txt,and external .sha256 sidecar. It contains source,fixtures,fresh
C-reference logs and both fresh capture/comparison/negative-checker gates;
archive CRC,member size/SHA and current-source byte agreement are checked.

Remaining:forward-transform y,matrix/vector products,decomposition/challenge,
secret products,z/hint/norm reductions,rejection/retry,signature encoding and
working main Sign;then Verify/full official-output tests. This client handles
one attempt only;retry seed reuse/nonce progression belongs to that controller.

## Stage5N.4d retained signing-key preparation

The working sign_key_prepare helper drives the real shared loader and NTT
engine,using one rotating scratch region and retaining rho/K/tr plus prepared
handles. It is exercised at the future main operation-owner boundary with
one actual dilithium_services instance. Main Sign/Verify remain unsupported;
this is not a complete signature or official sigGen result.

```powershell
# Repository root;the same single Python file
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_prepare
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_prepare
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_prepare
```

| File(s) | Contents / creator |
|---|---|
|src/controller/helpers/sign_key_prepare.sv|Control-only loader/transform/context/clear client |
|tb/tb_dilithium/tb_sign_key_prepare.sv|Actual services/banks,operation-owner/privileged-consumer mux,declared stall/fault adapters;no RAM preload or forced RTL |
|tb/tb_dilithium/sign_prepare_reference.c|Test-only adapter around unchanged software unpack_sk/poly_ntt |
|sim/dilithium/stage5_sign_prepare_inputs.txt|Single Python prepare:level/ID/base/scratch/sentinel,framing/reset/result-fault selectors and exact SK bytes |
|sim/dilithium/stage5_sign_prepare_outputs.txt|S source header,C command,W key input,L/B load command/result,N/O transform command/result,R owner release,G allocation,X scalar write,U finish,Z loader rollback,P/Q physical packed request/ACK,H first valid context,D parent done,V privileged/sentinel read,I pending consumer read,E clear,A reset,T witnesses,F totals |
|sim/dilithium/stage5_sign_prepare_c_reference.log|Python direct polynomial evaluation versus unchanged C unpack_sk/poly_ntt |
|sim/dilithium/stage5_sign_prepare.log / _console.log|Questa capture;GUI waves show retained context,owned mask,scratch,ordinal and owner/service records |
|sim/dilithium/stage5_sign_prepare_compare.log / _checker_selftest.log|Separate exact comparison and deliberately corrupted-capture gates |

The75 official key inputs are the existing pinned NIST KeyGen secret keys.
Expected intermediate coefficients are locally derived,not NIST-published
standalone Pre-NTT/preparation vectors. Python evaluates each polynomial at
the odd roots of unity independently of the butterfly schedule. The unchanged
C unpack_sk/poly_ntt cross-check covers164 source fixtures/709632 transformed
coefficients,including full source data for malformed/reset tests. No new
external corpus or second Python script is added.

The component workload is165 commands:95 successful keys,62 expected errors
and8 resets/fault-aborted keys. It checks1013992 scalar writes,115776 packed
reads and1816 accepted transform requests(1200 Pre-NTT,616 ordinary forward).
The final gate results/source token are recorded below. Prototype/diagnostic
replay did not substitute for the final fresh prepare/simulation/comparison.

Coverage of this functional gate includes:

- All75 published SKs at levels2/3/5 and local coefficient patterns. Correct
  NTT-domain values,polynomial order,ID/level/mode/domain/small metadata and
  retained rho/K/tr are checked;input commands are poisoned after acceptance
  to prove snapshot retention and blocked replacement commands.
- Raw region bounds,aliasing scratch,occupied raw/scratch regions,unused eta
  encodings and malformed byte/index/last framing. Rejections preserve an
  unrelated real SHAKE/sampler-generated sentinel.
- Pre only for eligible s1/s2;ordinary forward for t0. Each destination is
  free,each write/packed ACK is tracked per allocation generation,and source
  release follows validated result identity and complete memory commit.
  Peak live key storage is at most N+1 regions.
- Real NTT source-ID rejection at the first/last polynomial,observed result
  ID/region corruption after partial progress,and load result ID/mask
  corruption. Normal errors drain child retirement and release every owned
  raw/replacement/new completed result before returning invalid context.
- Five resets at partial key header,first NTT load,partial NTT writeback,
  first completed transform/source release,and held prepared-key done.
  Three further declared service-fault cases halt ownership until global
  reset. These fatal cases intentionally do not claim normal rollback done.
- Successful done holds,then context remains stable in READY while a new
  command is held. Every prepared polynomial is read by the privileged Sign
  consumer before clear. A pending read blocks clear;after draining,clear
  zeroes exposed context and releases the entire prepared key. The unrelated
  sentinel survives;global reset instead invalidates all shared allocations.

Periodic backpressure need not stall every individual key. The first key
deterministically witnesses all child channels;retained context,clear barrier,
done hold and outer owner protection are required per relevant key. The caller
must retain the outer services lease between child jobs and while context is
READY,block unrelated host requests,and stop new privileged requests on clear.
The helper does not itself implement main Sign's host arbiter or signature
controller. No formal/security/secure-erasure/UVM/PPA/netlist signoff is claimed.

Study sign_key_prepare's LOAD/OP/FREE_SOURCE/READY/CLEAN states,then the test's
owner mux and explicit adapters,then sign_prepare_math/verify_sign_prepare in
the single Python script. Next:retained-key signing hashes and mask generation.

### Final Stage5N.4d results and evidence

| Fresh current-source gate | Result | Checker corruptions rejected |
|---|---|---|
|sign_prepare|165 keys,157 completions(95 success,62 errors),8 resets/fault aborts;1013992 exact scalar writes,115776 exact packed reads;1816 requests(1200 Pre,616 forward);75/75 official SKs prepared |55/55 |
|sign_load_service|138 keys,133 completions,5 resets;449992 writes,105728 key words,133 sampled sentinels,95 CNB handoffs |95/95 |
|full_keygen|8 complete C-reference keypairs,3 rejects,5 resets;5433 key words,2058 hash words,656 tr bytes,11179 field reads |37/37 |

Physical NTT results:1805 successful retirements,6 real source-ID rejections,
5 reset/fault-interrupted requests. Six physically completed results have
bad observed tags and are discarded;1799 pass parent checks/source release.
Checked transform writes462111 =1805 x256 +31 reset-prefix values;decoded
raw writes551881 complete the1013992 total. Packed reads115776 =105728
prepared-key words +157 x64 sentinel words.95 pending clear-barrier reads
are additional,separately logged responses.96 valid context publications
include one held-done reset;only95 commands count as completed success.
The monitor observes maximum13/18/24 live key regions(levels2/3/5),with no
additional bank/poly RAM. Detailed accounting is also in THROUGHPUT.md.

All57 prior RTL files and6.757ns SDC are byte-identical to Stage5N.4c2.
The other Stage5N.4c2 regression gates remain preserved there;they are not
claimed freshly rerun here. Likewise,the75-case complete KeyGen RTL result
remains Stage5N.3 evidence. Fresh prepare still cross-checks all75 complete
software keypairs against official bytes,plus the independent C component
oracles. This milestone's new75-key RTL result is key preparation,not signing.

Global source token:
a72c6cc1cabf9338fd0ac684f6393e7c44ff05e4cc5aa571d57c6305f1926647.
All3 final captures/comparisons/checker logs use that snapshot. Frozen
create-only archive:evidence/stage5n4d_key_prepare.zip with SHA256 sidecar;
manifest records every source/input/capture/log size and hash. Prior immutable
archives are preserved. No synthesis/netlist/full-UVM/PPA/main-Sign completion
or secure erasure is claimed by this source functional checkpoint.

## Stage5N.4c2 key loader in the actual shared service

New sign_load_service selection uses the same fixture and single launcher/
Python script as the standalone loader. The test instantiates production
dilithium_services,including its existing Keccak pair,sampler,NTT,process
clients and one four-bank memory tree. No hierarchical RAM preload or forced
RTL signals are used. Main Sign/Verify remain unsupported;this is the key-load
and ownership milestone,not complete signatures or official NIST sigGen.

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_load_service
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_load_service
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_load_service
```

| File(s),under sim/dilithium/ | Meaning |
|---|---|
|stage5_sign_load_inputs.txt|Same138 prepared expanded-key commands as the standalone gate |
|stage5_sign_load_service_outputs.txt|C/W/L/X/P/K/U/Z/D/A/T/V/S/F retain the standalone meanings;B arbitration witnesses,G/J/E raw descriptor/output/retirement,I held public read,N sampled sentinel readback,Y/O decoded-key-to-CNB command/result |
|stage5_sign_load_service.log / _console.log|Questa capture;GUI waves show production services,loader/arbiter state,private plan and physical ACKs |
|stage5_sign_load_service_compare.log|Exact decoded fields,scalar/packed storage,ACKs,rollback,publication,raw/sentinel data and owner lifecycle |
|stage5_sign_load_service_checker_selftest.log|Negative tests for storage,header,peer data,arbitration,reset and consumer-handoff records |

Measured comparison:138 commands =95 successful keys +38 expected errors +5
resets.449992 exact scalar writes and105728 exact packed key-word readbacks
match the prior client gate. All75 official KeyGen SKs are used;their decoded
coefficient expectations are Python/C-derived,not published standalone NIST
bank-load vectors. No new corpus was downloaded.

Additional checks use real SHAKE256/ExpandMask sentinels before every key;
133 non-reset cases preserve8512 exact packed sentinel words. At each of
three levels,the waiting key is blocked for six cycles by each prior owner:
sample status,raw output,raw retirement,public read,row,NTT,scalar process and
sign process. Three empty-message SHAKE256 jobs return17 exact bytes each;
their core/ID/retirement and held public-read data are independently checked.

Every key acceptance blocks simultaneous public read/release,including an
occupied final destination. During payload,request classes are probed
separately so outer row priority cannot hide an inner-arbiter defect. All
classes are asserted together during held done. A waiting row stays asserted
through load retirement,which checks that it cannot mask the current owner's
done-ready. Whole-key private commits,late-error cleanup and five exact reset
prefixes remain checked against real physical memory requests/ACKs.

After successful retirement,95 real read-only CNB commands consume the first
decoded s1 polynomial with the validated owner/level/region. Their reject
result is false because all secret coefficients are within the z bound.
Full key readback afterward also proves that this consumer did not modify
the stored key. The DMA schedule adds95 x(1 metadata check +64 arithmetic
words)=6175 internal reads,not included in the105728 public key-word readbacks.

Shared witness cycles(write stalls,finish stalls,allocation stalls,private
earlier commits,rollback-release stalls,blocked external releases) are
204554/3490/0/665097/0/713762. Allocation and internal rollback releases do
not stall in this exclusive shared workload;their positive stall tests remain
in the standalone client gate. Each of eight prior-owner probe classes totals
18 cycles(three levels x6);138 acceptance edges and713762 exclusive-owner
cycles are observed. These witness counts are not throughput measurements.

Five previous RTL files change:service types,services wrapper,row wrapper,
bank arbiter and KeyGen's new zero tie-off. Three older focused benches add
explicit zero ties for the new ports. The loader/decoder,primitive memory,
Keccak,sampler,NTT and process arithmetic RTL and6.757ns SDC are unchanged.
No new fitted PPA,netlist,full-system UVM,secure erasure or full Sign result.
Next:retain validated key/header handles and schedule shared secret transforms.

### Final Stage5N.4c2 gate results

| Current-source selector | Exact comparison | Deliberately corrupted captures rejected |
|---|---|---|
|sign_load_service|138 key commands,133 completions,5 resets;449992 scalar writes,105728 key words;75 official SKs,133 sampled sentinels,95 CNB handoffs |95/95 |
|sign_load|Same138 standalone client cases and exact write/read totals |61/61 |
|sign_service|33 commands,30 completions,9 errors,3 resets;768 process words |33/33 |
|sign_hash|167 commands,162 completions,5 resets;7760 raw bytes,6400 mask coefficients,29 peers,9 forwarded digests |61/61 |
|full_keygen|8 complete C-reference keypairs,3 rejects,5 resets;5433 key words,2058 hash words,656 tr bytes,11179 field reads |37/37 |
|seed_row|13 complete rows,27 row rejections,7 resets;163 samples,161 NTTs,55 ADDs,12544 packed reads;20 seed hashes;6 schoolbook row cross-checks |23/23 |
|bank_process|23 samples,15 NTTs,71 process commands;34 successes,33 rejects,4 resets;8512 packed reads |29/29 |

Global source token:
ed9bd7a5ea0a278d435f14b49c2360a93bda066d2392894e7485d9f2b62e9af8.
All seven captures/comparisons/checker logs use this source snapshot. The
shared negative-test suite rejects missing required ownership witnesses;
positive witness counters are not claimed to be exact independently specified
cycle totals. One provisional test that changed a positive counter to another
positive counter was corrected before this final run.

The prior75-case complete KeyGen RTL run remains in Stage5N.3 evidence;it was
not rerun here. Fresh prepare still checks all75 complete software keypairs
against official NIST bytes,plus independent component C references. The new
75-key RTL claim here is specifically decoded-key ingestion,not full signing.
Frozen create-only source/manifest/capture evidence:
evidence/stage5n4c2_shared_key_load.zip and its SHA256 sidecar. Prior archives
are preserved. Study tb_sign_load_service.sv for actual service ownership and
verify_sign_load_service in the single Python file for exact peer/sentinel/
handoff checks;the standalone verifier is reused for the core storage lifecycle.

## Stage5N.4c1 expanded-key ingestion into real banks

This focused gate connects new process/sign_key_load.sv and the existing
sign_key_decode to the actual memory/packer/four dual-port banks. It does not
yet instantiate the loader in dilithium_services or main Sign. The bench
implements the required exclusive-owner/read/release gating;production shared
arbitration and handoff are the next Stage5N.4c2 checkpoint.

```powershell
# Repository root;one existing Python script
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_load
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_load
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_load
```

| File(s),under sim/dilithium/ | Contents / creator |
|---|---|
|stage5_sign_load_inputs.txt|Python prepare:level,ID,base,sentinel,fault/reset selectors and exact expanded-key bytes |
|stage5_sign_load_outputs.txt|RTL bench:C command,W input,L allocation,X scalar write,P physical packed request,K physical ACK,U finish,Z rollback release,D whole-key result/header,A reset,T witnesses,V packed readback,S unchanged sentinel,F totals |
|stage5_sign_load.log / _console.log|Questa capture and GUI waves for plan,commit mask,private visibility,write/finish/release |
|stage5_sign_load_compare.log|Independent expected fields/coefficients,packing,ACK causality,publication,rollback and readback |
|stage5_sign_load_checker_selftest.log|61/61 deliberately corrupted captures rejected |

Expected coefficients are independently decoded from key bytes in Python and
cross-checked with unchanged C unpack_sk/pack_sk. The75 official inputs come
from the existing pinned NIST KeyGen corpus;NIST does not publish standalone
bank-load coefficient vectors here. Additional local patterns,malformed keys,
resets and region-boundary cases are component fixtures,not official sigGen.
No new external corpus is downloaded at this checkpoint.

Measured PASS:138 commands =95 successes +38 expected errors +5 resets.
449992 exact scalar writes =422912 successful +16585 rejected-key prefixes
+10495 reset prefixes. Successful storage readback is105728 packed words
x4 =422912 coefficients,including332800 from all75 published KeyGen SKs.
The entire key remains hidden while earlier polynomials are internally
COMPLETE. Each successful polynomial finish requires all64 physical ACKs.
Late eta errors discard the active partial and release ALL prior commits.
Done/header/region outputs remain stable under held completion;error outputs
are zero. Sentinel data and metadata survive rejected and successful keys.

All three levels test exclusive end64 success,end64 collision,and end65
overflow. The original decoder fault corpus adds malformed index/byte/last
and unused eta values. Five resets occur at partial header,first polynomial
commit,held first coefficient,held final coefficient and held done. Recovery
reuses key IDs with different contents. Reset invalidates ownership,not RAM
payload;no secure erasure or algebraic key-consistency claim is made.

Witness cycles(write/finish/allocate stalls,private earlier commits,rollback
release stalls,blocked external lease probes):738973/10347/1571/1173357/32/
1256619. These are workload witnesses,not hardware throughput measurements.
The checker validates every scalar write against accepted source-bit limits,
every packed request and ACK,all finish/release ownership,and every read's
ID,region,word,mode,level,domain and small-coefficient flag. Corruptions include
missing ACKs/rollback,early retirement,wrong headers/readbacks and reset tags.

All56 previous RTL files and the6.757ns SDC are byte-identical to Stage5N.4b.
Fresh full-KeyGen regression also passes:8 complete keypairs,3 rejects,5 reset
aborts,5433 exact64-bit key words,2058 public-key hash words,656 tr bytes and
11179 field read words;37/37 checker corruptions rejected. The previous75-case
full-KeyGen RTL run remains in Stage5N.3 evidence,not newly rerun here.
Global source token:bfeaf559c72686430b40bed7c81df00e7000e9cf62a73d5f90951f35129a9e77.
The loader is a new unconnected production client;there is no new PPA,netlist,
full-system UVM or complete Sign result. Frozen evidence is
evidence/stage5n4c1_sign_load.zip with its create-only SHA256 sidecar.
Study sign_key_load.sv for ownership/rollback;tb_sign_key_load.sv for actual
memory transfers;sign_load_cases/verify_sign_load in the single Python script
for expected values and lifecycle checks. Next:production shared-service wiring.

## Stage5N.4b signing hash messages through the real shared service

Message definitions follow [FIPS204 Sign/Sign_internal and ExpandMask](https://nvlpubs.nist.gov/nistpubs/fips/nist.fips.204.pdf).
These are locally constructed component fixtures,not published NIST sigGen
cases or complete signatures. No new official corpus was downloaded.

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_hash
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_hash
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_hash
```

| File(s),under sim/dilithium/ | Contents / creator |
|---|---|
| stage5_sign_hash_inputs.txt |Single Python prepare:opcode,level,ID,context/message lengths,nonce,fault/reset/link/peer selectors,command fields and payload bytes |
| stage5_sign_hash_outputs.txt |tb_sign_hash_message:C command,D accepted descriptor/core,P payload,W absorption,R raw result,S service retirement,E formatter retirement,V stored mask word,G/H/Q peer request/output/retirement,L actual digest forward,A reset,T witnesses,F totals |
| stage5_sign_hash.log / _console.log |Questa capture;GUI waves include merge reservoir,prefix,drain and service ownership |
| stage5_sign_hash_c_reference.log |Independent C assembly/SHAKE/w1 packing/mask sampling agreement |
| stage5_sign_hash_compare.log |Exact descriptor,payload,absorption,digest,mask,owner/order and reset comparison |
| stage5_sign_hash_checker_selftest.log |61/61 deliberately corrupted captures rejected |

Study process/sign_hash_message.sv for byte merging and error drain;
tb_sign_hash_message.sv for the actual dilithium_services connection,peer
owner,cache gating and retirement barrier;sign_hash_cases/check_sign_hash_c/
verify_sign_hash in the single Python script for independent expected values.
The test-only sign_hash_reference.c assembles message components and calls
unchanged C shake256,polyveck_pack_w1 and poly_uniform_gamma1. Python uses
byte concatenation,hashlib SHAKE and the existing independent mask model.
C agrees on154 intended messages/420639 bytes and26 mask source polynomials.
For malformed-payload cases,C checks the intended message;the actual dummy
drain bytes and their diagnostic digest are independently checked by Python.

167 commands =128 successes +13 invalid commands +21 payload errors +5 resets.
The162 completions include all34 expected errors.52618 exact absorption words
include reset prefixes.7760 finite raw bytes =6464 successful request bytes +
1296 discarded error-drain diagnostics.29 peer jobs add464 separately checked
bytes.6400 mask coefficients =25 complete polynomials;C's26 includes the source
for one reset-aborted sampling request.9 actual RTL digest forwards check
mu ->private seed/challenge and private seed ->mask,not golden-file substitution.

Fixtures cover context0/1/7/8/9/255;empty/partial/rate-adjacent messages;all
payload tail sizes;65535-byte total absorption and one-byte overflow;invalid
context/level;deterministic zero rnd and supplied rnd;all challenge sizes;
mask nonces0,1,l-1,l,255,256,65534,65535;wrong payload index/bytes/last;
poisoned unused bytes and command inputs changed after acceptance.
Five resets target blocked descriptor,exact two-word absorption prefix,
held formatter completion,held raw output and held mask status. Recovery
reuses the same ID with different fields/data. Invalid payloads are drained,
not credited as successful hashes. Raw and sampler owners must retire before
formatter completion is accepted;invalid digests never enter the valid cache.
61 checker corruptions reject,including wrong bytes/tags/cores,peer separation,
missing forwards,early retirement,corrupted error-zero-fill and lost reset prefix.

Current source token:4e1391e067ed91c2497802338b6bc22b6e8242d19548366db80048158a913b73.
All55 previous RTL files and6.757ns SDC are byte-identical to Stage5N.4a.
Fresh regressions PASS:sign_decode129 commands/75 official keys/436424 emitted
coefficients/35 checker faults;sign_service33 commands/33 checker faults;
full_keygen8 complete keypairs/3 rejects/5 resets/37 checker faults.
Prior all75 official full-KeyGen RTL evidence remains in Stage5N.3,not newly
rerun here. Frozen evidence:evidence/stage5n4b_sign_hash.zip +.sha256 sidecar;
create-only source/docs/reference/fixture/capture/verdict bundle with manifest.
No main Sign/bank-key loader/w1 RTL packing or new PPA claim. Next:whole-key
private bank ingestion,then connect the remaining Sign schedule.

## Stage5N.4a expanded secret-key decoder

Byte layout follows [FIPS204 skEncode/skDecode,Algorithms24/25](https://nvlpubs.nist.gov/nistpubs/fips/nist.fips.204.pdf),
with our explicit strict rejection of unused eta encodings. This is a decoder
test using existing official KeyGen keys,not full NIST signature generation.
No new corpus was downloaded. The75 sk byte strings come directly from the
same pinned NIST/ML-DSA-keyGen-FIPS204/expectedResults.json,joined by tgId/tcId
and checked against provenance and the unchanged hashes described below.
Additional malformed/reset/boundary keys are locally constructed and labeled.

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_decode
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_decode
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_decode
```

| File(s),under sim/dilithium/ | Contents / creator |
|---|---|
| stage5_sign_decode_inputs.txt |Python prepare:case,level,ID,fault word/kind,reset phase,length,expanded-key bytes;freshness token |
| stage5_sign_decode_outputs.txt |tb_sign_key_decode:C command,W accepted indexed input,B header,P coefficient and metadata,D completion,A reset,T stall witnesses,F totals |
| stage5_sign_decode.log / _console.log |Questa capture;GUI waves include header,coefficient,done,reservoir and section/index state |
| stage5_sign_decode_c_reference.log |Python/C full-key decode/encode agreement |
| stage5_sign_decode_compare.log |Separate exact RTL comparison with mathematical decoding and expected fault/reset behavior |
| stage5_sign_decode_checker_selftest.log |35/35 deliberate corruptions rejected |

Study process/sign_key_decode.sv for hardware framing/reservoir/field ordering;
tb/tb_dilithium/tb_sign_key_decode.sv for driving,stalls and resets;and
decode_key_math,sign_decode_cases,verify_sign_decode in the single Python script
for independent expected values. Test-only sign_decode_reference.c calls the
unchanged C unpack_sk/pack_sk. C permits unused eta patterns to decode outside
the secret range;Python separately verifies RTL's deliberate strict rejection.

129 commands,124 completions =92 successful keys +32 expected errors,and5
reset-aborted keys. All75 official secret keys decode fully;25 per level.
436424 exact emitted coefficients =409600 success +16585 error prefixes +
10239 reset prefixes. The official keys account for332800 success coefficients.
32 errors =1 invalid level +15 malformed-frame cases +16 unused-eta cases.
Five resets target partial header,held header,held first coefficient,held last
coefficient and held done. Every reset checkpoint has an exact required input/
coefficient prefix;the following same-ID command uses new input and succeeds.
Input/header/coefficient/done stability under stalls is asserted.

Python/C agree on128 full source-key fixtures and549888 coefficients,including
complete source keys whose RTL transactions are malformed or aborted. C also
roundtrips their exact bytes. All35 checker corruptions reject,covering tags,
headers,values,word metadata,reset-prefix data/missing prefix,missing events/
witnesses,footer and stale token.
Expected values come from integer bit slicing;RTL reservoir code is not reused.
Malformed keys and reset prefixes are not credited as successful keys.

Source token:8987bbbd148fec599b1b951fc16a6531f13baaea31dfc8a7d0cae5863ca45eae.
All54 existing RTL files remain unchanged;only the new standalone decoder
is added. Fresh current-source regressions PASS:sign_service33 commands,
30 completions,9 expected errors,3 resets and33 checker corruptions;
full_keygen8 complete keypairs,3 rejects,5 resets and37 checker corruptions.
The three-gate loop ends ALL_STAGE5N4A_CURRENT_GATES_PASS. The preceding
Stage5N.3 all75-keypair RTL regression remains in its immutable archive,
not claimed newly rerun here. Python/C preparation does freshly check all75
published complete keypairs in software,as well as the new decoder fixtures.
Frozen evidence:evidence/stage5n4a_sign_decode.zip and matching.sha256 sidecar;
create-only archive with current source/docs/references,prepared fixtures,
three fresh captures/comparisons/checker logs and size/SHA256 manifest.
No decoder bank-ingestion/main Sign/hash-format implementation or PPA claim.

## Stage5N.3 shared signing-process memory verification

This is local component verification,not a published standalone NIST signing
corpus. The existing single script uses independent division/wrap decomposition,
centered norm comparison and HighBits-change hint calculation. RTL is not
imported as a model. Existing scalar C crosschecks remain in prepare.

```powershell
# Repository root,before current-source capture
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_service
do dilithium/run.do
# For the deeper DMA/error/reset gate,use sign_dma instead.
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_service
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_service
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_dma
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_dma
```

Run each selector in Questa before comparing its capture. The same launcher
provides waves for DMA ownership,word/lane progress,allocations/finish and ACKs.
Require explicit capture PASS,separate comparison PASS and checker PASS.

| File(s),under sim/dilithium/ | Creator / contents |
|---|---|
| stage5_sign_dma_inputs.txt |Single Python prepare:71 commands,source coefficients,high values,explicit response-fault/reset selectors;freshness token |
| stage5_sign_dma_outputs.txt |tb_sign_process_dma:C command,W accepted scalar writes,P packed BRAM requests,Q ACKs,U finish,D completion,R committed readback,A reset-aborted command,T witnesses,F totals |
| stage5_sign_service_outputs.txt |tb_sign_service:actual main-owned shared services;S sampled source words,C command,D completion,R result words,A aborted command,T arbitration/lease witnesses,F totals |
| stage5_sign_dma/sign_service.log |Questa Transcripts;matching _console.log captures batch output |
| stage5_sign_dma/sign_service_compare.log |Separate exact-file Python comparisons |
| stage5_sign_dma/sign_service_checker_selftest.log |Deliberate capture corruption rejection results |

DMA gate:71 commands,65 completions(44 successes +21 expected errors),6 reset
aborts;14284 exact scalar writes and3570 acknowledged packed writes. This
includes correct partial prefixes later canceled by reset:1108 scalar writes
and276 ACKs. Non-reset cases account for13176 scalar writes/3294 ACKs.
The checker verifies request-before-ACK and all64 ACKs before successful finish,
exact rollback finish codes,result metadata,canonical values and held leases.
All32 deliberately corrupted captures are rejected,including early ACK/finish,
bad reset-prefix data and missing source-lease evidence.

Shared-service gate:33 commands,30 completions(21 successes +9 expected errors),
3 reset aborts. All3 levels each exercise Decompose,4 successful CNB commands
and2 successful Mhint commands,plus owner/level/high errors and an abort.
192 source words=768 sampled coefficients;768 result words=3072 exact process
coefficients. The source is actual SHAKE256 -> sampler mask output from the
existing stage2 cases12/14/16,not a preloaded RAM image. No RTL forcing is used.
Priority probes submit rejected row/NTT/scalar commands and hold a public read;
signing waits. Other clients stay blocked during held signing completion.
All33 capture corruptions are rejected. Test declarations/checks are in
tb/tb_dilithium/tb_sign_service.sv;arithmetic/partial-write tests use
tb_sign_process_dma.sv and the production memory.sv/memory_banks/poly_bram.

The retained regression also freshly passes sign_process(7752 groups,117
complete polynomials,45 expected errors,6 aborts,27 checker faults),bank_process
(23 samples,15 NTTs,71 process commands,29 checker faults),and full_keygen
(8 complete keypairs,3 expected rejects,5 reset aborts,37 checker faults).
All75 official nist_keygen cases also freshly PASS:433600 exact key bytes,
54200 key words,18300 PK hash input words,4800 tr bytes and112000 field-read
records;41/41 checker corruptions rejected. The sequential six-gate run ends
with ALL_STAGE5N3_CURRENT_GATES_PASS. Earlier diagnostic gates not listed here
retain historical evidence;they are not claimed newly rerun.

Compared with Stage5N.2 evidence,48 previous RTL files remain byte-identical.
Only five prior RTL files change:the service package,service wrapper,row/bank
wrappers,and KeyGen's zero assignment for the new sign request. The new DMA
is a separate process file. The6.757ns SDC is byte-identical. The prepared
Quartus list adds the DMA;no fit or post-netlist result is claimed.

Current source token:b224a41318be58d790ee39d066ce6d27290538fdf003a7ea282e7162265a86ac.
Immutable evidence:evidence/stage5n3_sign_memory.zip and matching.sha256
sidecar,created without overwriting prior checkpoints. The archive includes
current source/references/docs,prepared fixtures,six fresh captures,comparison
and checker logs,and a size/SHA256 manifest. No full Sign/Verify or PPA claim.

## Stage5N.2 Decompose/CNB/Mhint flow

This is a local FIPS-derived process test,not a downloaded standalone NIST
process-vector corpus. The same single Python script prepares and compares it.
Python defines decomposition by integer division/positive ties/special wrap,
norms by centered absolute value,and Mhint by a high-bit-change calculation.
It separately checks scalar results against unchanged C decompose,make_hint
and poly_chknorm through tb/tb_dilithium/sign_process_reference.c.
No RTL arithmetic is imported into either oracle.

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_process
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_process
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_process
```

| File in sim/dilithium/ | Producer / contents |
|---|---|
| stage5_sign_process_inputs.txt |Python:case,op,param,kind,ID,group,last,abort,packed92-bit data,packed24-bit high |
| stage5_sign_process_expected.txt |Python:case,error,high24,low76,hint mask,lane-reject mask,prefix reject,prefix weight |
| stage5_sign_process_outputs.txt |RTL bench:J accepted case,P actual tagged results,A aborted case,X reset,F totals |
| stage5_sign_process.log |Questa Transcript;GUI waves show input/output,packet tracker and accumulators |
| stage5_sign_process_compare.log |Separate complete-file Python verdict |
| stage5_sign_process_checker_selftest.log |27 deliberate corruption rejections |
| stage5_sign_process_c_reference.log |Independent Python/C scalar agreement and exhaustive C decomposition checks |

Current process results:7752 accepted x4 groups,7746 exact returned results,
45 expected protocol/data errors,6 reset-aborted groups and117 complete
256-coefficient polynomials:53 Decompose,44 CNB and20 Mhint packets.
7746*4=30984 returned lane positions,including180 zeroed error lanes;
7701 valid groups=30804 mathematical lane results.
C checks30996 scalar input fixtures:18040/6488/6468 at levels2/3/5. This
includes aborted inputs;three invalid-level groups(12 lanes) have no C level
executable and are instead checked as RTL error cases. Counts must not be
confused with only successfully completed polynomials.

The unchanged C decomposition passes all8380417 canonical coefficients at
each level(25141251 level/input pairs). This exhaustive statement applies to
the C oracle,not the RTL. RTL tests target every high-bin/tie/wrap boundary,
random values,all norm-bound signs/equalities,all lanes,late/sticky norm
failure,hint negative ties/high wraps and omega/omega+1 counts.
7509 simultaneous input/output handshakes,2865 input stalls and2903 output
stalls occur in this directed campaign. Six resets cancel held middle/final
results,then recover with the same ID and different data. Invalid opcode,
level,data/high,kind,index,last and changing packet identity are exercised.
All27 checker corruptions reject,including missing sticky reject/hint weight.

The new blocks are not yet connected to main memory DMA/Sign. Final frozen
source also passes full_keygen(8 complete,3 expected rejects,5 reset aborts,
37 checker corruptions) and all75 NIST keypairs(433600 exact key bytes,
41 checker corruptions). All48 pre-existing RTL files and6.757ns SDC remain
byte-identical to Stage5N.1;both complete-key capture streams match Stage5N.1
except freshness headers. No KeyGen arithmetic/schedule change is introduced.

These three freshly captured gates share source token
9c78215f9e0edec3dfd474b7999acd338ba37a30f6ab46c46d9ed4ed55d19bd2.
Other gates retain their previous archived evidence;they are not claimed
freshly rerun. The create-only evidence/stage5n2_sign_process.zip and SHA256
sidecar preserve source,models,corpus,current inputs/golden files,three fresh
captures/verdicts and universal docs. MANIFEST.csv records sizes/hashes.
No new functional/code coverage percentage,PPA or synthesis result is claimed.

## Stage5N.1 shared-service refactor verification

The complete-KeyGen benches now instantiate the same external dilithium top
with its engines/banks/Bitpkg owned by dilithium_services. The source/golden
token includes both new service files. Reuse the existing prepare command and
selectors full_keygen,nist_keygen,keygen,rounded_keygen;there is no new launcher
or second Python script. See the Stage5M commands below for nist_keygen.

tb_full_keygen additionally checks the entire routed request record every
owned cycle. Without an owner it requires zero requests,no live bank regions,
engine jobs/responses or packed output/completion. It observes ownership after
main completion acceptance while the main FSM is IDLE and the child is still
freeing retained regions. Removing that cleanup lease would fail this check.
Reset aborts continue to cancel the client and the same shared physical engines.

New Q record:owned-cycle count,post-completion cleanup-owner cycle count,
unowned-idle cycle count. Each must be positive and cleanup must be a strict
subset of owned cycles. The checker requires exactly one Q record;the fault
suite now deletes it and zeroes its cleanup count as two additional negative
tests. The main byte/hash/metadata/reset oracles remain independent and intact.

The local full_keygen gate passes8 complete keypairs,3 expected rejects,
5 reset aborts and37 checker corruptions. Its Q witness is988082 owned cycles,
195 cleanup-owner cycles and52 unowned-idle cycles. Its simulated campaign
duration remains6676943064ps,identical to the frozen Stage5M local run. These
are directed-test observations,not a sustained-throughput or PPA benchmark.
The full official-vector gate also passes75/75 keypairs,433600 exact key bytes
and41 checker corruptions. Its Q witness is9142284 owned cycles,2225
cleanup-owner cycles and151 unowned-idle cycles. All local/NIST capture events
match the frozen Stage5M streams exactly except freshness headers and Q.
Both diagnostic gates also freshly pass:keygen checks34 rows,172304 scalar
writes,8448 exact92-bit reads and29 checker faults;rounded_keygen checks34
rows,190224 writes,12800 reads and36 checker faults. Each has7 complete,
3 expected rejects and4 reset aborts.

These four gates share source token
830c05c8b16215688d1923497ed1b147ecf6b2aea526d4cf54688e8a0ab4a345.
Frozen source,reference,prepared inputs,official corpus,four captures/verdicts
and universal docs are in evidence/stage5n1_shared_services.zip with SHA256
sidecar. Prior archives remain unchanged. Other focused gates retain their
previous archived evidence;they are not claimed freshly rerun here.
Sign/Verify and multi-client contention remain unimplemented;this step verifies
the main-owned resource boundary with its current KeyGen client only.

## Stage5M official NIST KeyGen flow

The official corpus is NIST's [ACVP-Server ML-DSA KeyGen FIPS204 directory](https://github.com/usnistgov/ACVP-Server/tree/2972def23bf9f3680c2c531561ed9bdd0f1086ad/gen-val/json-files/ML-DSA-keyGen-FIPS204),
pinned at commit2972def23bf9f3680c2c531561ed9bdd0f1086ad. It contains75 AFT
cases:25 each for ML-DSA-44/65/87,called levels2/3/5 in our interface. Every
case is included;there is no subset selection. This is the published corpus
at that revision,not a claim to cover every possible NIST validation case.

| File | Origin and use |
|---|---|
| NIST/ML-DSA-keyGen-FIPS204/prompt.json |Downloaded unchanged from NIST;32-byte seed,parameter set,tgId,tcId |
| NIST/ML-DSA-keyGen-FIPS204/expectedResults.json |Downloaded unchanged;published complete pk/sk bytes |
| NIST/ML-DSA-keyGen-FIPS204/provenance.json |Pinned URLs,revision,retrieval time,byte sizes and SHA256 |
| sim/dilithium/stage5_nist_keygen_inputs.txt |Python joins cases by(tgId,tcId);writes seed/level/operation ID for RTL |
| sim/dilithium/stage5_nist_keygen_expected.txt |Python copies published keys into one readable file;index,tgId,tcId,parameter,seed,pk,sk |
| sim/dilithium/stage5_nist_keygen_outputs.txt |Questa captures actual key words,hash transfers,field-read metadata,completion and cleanup |
| sim/dilithium/stage5_nist_keygen_compare.log |Separate Python byte/protocol comparison verdict |
| sim/dilithium/stage5_nist_keygen_checker_selftest.log |Deliberate-corruption rejection verdict |
| sim/dilithium/stage5_nist_keygen_c_reference.log |Additional C-versus-NIST check;C does not supply the expected RTL keys |

Simple flow:

```text
NIST seed + level -> input file -> unchanged full-KeyGen RTL -> output file
NIST published pk/sk -----------> expected file -----------+-> Python compare
```

Run from the repository root:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

Then run in the Questa GUI Transcript,working directory sim/:

```tcl
set DILITHIUM_STAGE 5
set DILITHIUM_TEST nist_keygen
do dilithium/run.do
```

Finally run separately from the repository root:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit nist_keygen
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit nist_keygen
```

The simulator uses tb_full_keygen with NIST_VECTORS=1 and FULL_KEYGEN=1 on
the main RTL. It receives no expected keys. It starts all75 operations,
stalls the output periodically,holds completion,and waits for zero bank
reservations before the next seed. There is only an initial reset;successive
keypairs reuse the same physical resources. Operation IDs cross65535.
The16-case local suite remains selectable as full_keygen and covers resets
and rejected commands separately.

Python first verifies pinned raw-file hashes,metadata,75 unique joined cases,
seed/key lengths and parameter counts. Seed hex in NIST is byte order;the
input file reverses that byte string into a little-endian256-bit SV literal.
Actual output word bits7:0 are the first byte. The comparator checks every
PK/SK byte,word index,type,ID,byte count,last,PK-before-SK order,hash data,
tr,field-read ownership and cleanup/completion order. It requires every case
and the final totals. No result is inferred merely from simulator exit0.
The prepare command also checks all75 complete C keypairs against NIST.

All input/golden/capture files are bound to current source and corpus hashes.
Changes to the script,TB or corpus require prepare and a fresh capture.
Earlier Stage5L evidence remains immutable;old loose captures have their
historical token and must not be compared against the updated preparation.
Stage5M results:75/75 complete NIST keypairs match,25 per parameter set.
54200 accepted64-bit key words =433600 exact bytes;18300 exact public-key
hash input words,4800 exact tr bytes and112000 field-read metadata records.
All75 completions and subsequent zero-reservation cleanup pass. The fork
witnesses3632 host-ahead and17452 hash-ahead cycles;these are protocol witnesses,
not throughput. All39 checker corruptions are rejected,including the final
byte of both keys at all three levels and a missing complete case.

Counting:25*(3872+5984+7488)=433600 successful key bytes;there are no aborted
prefixes in the NIST campaign. PK absorption is25*(164+244+324)=18300 words.
tr is75*64=4800 bytes. Field reads are25*64*(16+23+31)=112000 words.
All46 production RTL SystemVerilog files are byte-identical to Stage5L.

The local full_keygen suite also freshly passes8 complete keypairs,3 expected
rejects,5 reset aborts and35 checker corruptions with this updated harness.
Both captures use source token
22f42dd20700ee8b0e014dee66c45118bcb0edc647f8ded54949f658bd0a6461.
The other15 gates' most recent complete regression is the immutable Stage5L
archive;they are not claimed newly rerun for Stage5M. Freeze this stage in
evidence/stage5m_nist_keygen.zip with stage5m_nist_keygen.sha256,including raw
official corpus,provenance,current source/reference/input files,both fresh
captures and verdicts. MANIFEST.csv checks every member's size and SHA256.

This is source known-answer testing,not NIST certification,full-system UVM
coverage,timing signoff or FPGA testing. Sign/Verify remain unimplemented.

## Stage5L complete software-reference KeyGen

FULL_KEYGEN=1 on dilithium/keygen now enables the complete encoded-key path.
The autonomous polynomial scheduler retains rounded fields,then
helpers/keygen_encode.sv reads them through the existing bank interface,
uses the existing Bitpkg,and forks each public-key word to the output and
the same finite raw-SHAKE service. SHAKE256(pk,64) supplies tr. The controller
then emits the secret key and holds overall completion before source cleanup.
No second Keccak or encoded-key RAM is introduced.

Run the one-script capture/compare flow:

```powershell
# Repository root;GCC builds the independent C reference programs.
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST full_keygen
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit full_keygen
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit full_keygen
```

Inputs:stage5_full_keygen_inputs.txt contains16 operation/level/ID/xi/reset
cases. Expected complete keys:stage5_full_keygen_expected.txt. The Python
prepare command builds three C executables from the unchanged reference
crypto_sign_keypair,polyvec,polynomial,packing,rounding and SHAKE sources.
tb/tb_dilithium/keygen_reference.c only injects the supplied32-byte xi through
a test randombytes implementation;it checks that KeyGen requests it exactly
once.13 valid fixture seeds generate deterministic complete reference keys;
three rejected commands have no expected keys. Source tokens include these
reference sources and the expected key bytes.

The bench supplies start,output-ready,done-ready and reset;no external row,
sample,NTT,process or packing commands are driven. Actual RTL key words are
captured in stage5_full_keygen_outputs.txt. Python checks every accepted byte,
key type,index,ID,last and length against the C output. It independently
compares all public-key absorption words and all tr bytes using hashlib,
validates every encoding read's section/poly/word/region/owner/parameter/domain,
and forbids retained-source releases before operation retirement.
Reports:stage5_full_keygen_compare.log,stage5_full_keygen_checker_selftest.log
and stage5_full_keygen_c_reference.log.

Results:8 successful complete keypair operations,3 expected rejects and5 reset
aborts. The successful runs cover all levels2/3/5,plus five level2 recoveries.
5433 exact64-bit output words,2058 public-key SHAKE input words,656 tr bytes
and11179 metadata-checked field-read words are captured,including abort prefixes.
The eight successful operations emit36704 complete key bytes. The whole capture
also contains6760 aborted-prefix bytes;those are not successful key objects.
35 deliberate corruptions are rejected,including secret-key data,hash bytes,
duplicate fork deliveries,missing hash retirement and premature source release.

Resets target hash-accepted/host-stalled first PK word,partial PK field,
first128-bit tr beat,partial SK secret field,and held final completion after
both keys have streamed. Recovery reuses the ID with different xi. The
parameter2 normal run starts with ID65500 to exercise internal16-bit wrap.
Three ordinary operations run consecutively without reset,proving cleanup/reuse.
Four-cycle held overall completion and independently stalled hash/output
paths are checked. Fork witnesses:434 host-ahead cycles and1939 hash-ahead
cycles in this directed run;these are handshake observations,not throughput.

The final regression also reruns all15 earlier focused gates and their checker
fault tests;all16 gates pass on source token
b4c3284a2fe1cacad64c73cde32f43674e3ad3c17fd04b6197bd033a0b6b55b6.
The create-only evidence/stage5l_full_keygen.zip preserves current RTL,
testbenches,independent references,input/golden files,all16 captures/verdicts,
universal docs and prepared project files. MANIFEST.csv records member sizes
and SHA256;stage5l_full_keygen.sha256 records the archive digest. All25 imported
Keccak/sampler/NTT SystemVerilog files are unchanged from the Stage5K archive.

This is complete deterministic KeyGen against the local final-format software
reference,not official downloaded NIST conformance yet. Official KeyGen vectors
are the next gate before Sign controller work. Sign/Verify still return
unsupported code2. No new PPA,synthesis,netlist,full-system UVM coverage or FPGA
result is claimed. Earlier sections below describe preserved historical gates.

The official-vector follow-up above completes that Stage5L next gate.

## Stage5K connected Power2Round and Bitpkg arithmetic

The new rounded KeyGen path enables ROUND_OUTPUTS=1 on keygen/dilithium.
After t=A*s1+s2,it runs the existing acknowledged P2R process DMA. It retains
each row's t0 in flat region56+i and t1 in40+i through overall completion,
then releases both arrays after the existing secret cleanup.
The earlier selector keygen explicitly retains ROUND_OUTPUTS=0 as its baseline.

Two new selectors use the same launcher and Python script:

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST rounded_keygen
do dilithium/run.do
# Select bitpkg instead for the standalone packet-format gate.
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit rounded_keygen
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit rounded_keygen
# After running selector bitpkg:
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit bitpkg
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit bitpkg
```

Rounded result:7 successful polynomial-phase operations,3 expected rejects,
4 resets and34 delivered t rows.190224 scalar values and12800 exact92-bit
read words match. Retained t0/t1 metadata and every rounded coefficient are
checked before overall completion. Both regions must be COMPLETE before
row output becomes valid. Rounded-specific checker corruptions target each
array's values/IDs,allocations and high-region commit;36 total corruptions
are rejected. The source still exposes t rows for inspection;it does not yet
emit serialized public or secret keys.

Bitpkg result:97 commands,60 successful packets,31 expected errors,6 reset
aborts;18292 accepted input coefficients and2482 exact64-bit words. Formats
are t1(10 bits),t0(13 bits),eta-s(3 bits at levels2/5,4 at level3).
Six patterns cover zeros,extreme values,alternation,boundaries and pseudorandom
values for each format/level. Reject tests cover invalid command/level,
out-of-format coefficients,wrong index and early/missing last. Reset aborts
at17 accepted coefficients or a held first output;different data reuses the ID.
Output/data/tag/index/last hold under backpressure;final status also holds.
15 capture corruptions are rejected.

The Python preparation now builds a C packing oracle for levels2/3/5 from the
unchanged software poly.c packers and their dependencies.66 valid fixtures,
including abort/recovery inputs,match18496 C-encoded bytes. This is independent
development-reference evidence,not official NIST full-key vectors.

Inputs:stage5_bitpkg_inputs.txt and the existing stage5_keygen_inputs.txt.
Captures:stage5_bitpkg_outputs.txt and stage5_rounded_keygen_outputs.txt;
each has its own compare/checker logs. C witness:stage5_bitpkg_c_reference.log.
Prepared source tokens include the C adapter and its actual software sources.
Next:connect bank reads to Bitpkg,serialize complete key fields in final FIPS
order,and hash the encoded public key to obtain tr. Bitpkg is currently tested
as a working process block;it is not yet the complete key-output pipeline.
The selected next interface is tagged64-bit key streaming,with rounded fields
retained in existing banks and no additional encoded-key RAM. This choice is
documented in SPECIFICATION.md;its main output ports are not implemented yet.
All15 focused gates and their checker fault tests freshly pass on the same
source token. Create-only evidence:evidence/stage5k_rounding_bitpkg.zip and
its SHA256 sidecar include current source,captures,C oracle sources and
per-file hashes. Preserve all earlier immutable snapshots.

## Stage5J autonomous KeyGen polynomial phase

New RTL:`src/controller/keygen.sv` schedules the shared seed/sampler,retained
secret transforms,all matrix rows,existing row accumulator and final modular
s2 addition. `src/controller/dilithium.sv` is the main operation FSM;currently
operation0 selects this polynomial phase. Sign/Verify return explicit unsupported
code2 and do not start a child. This is not complete encoded KeyGen.

Use the same single script and launcher:

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST keygen
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit keygen
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit keygen
```

The input file stage5_keygen_inputs.txt contains14 operation/level/ID/xi/reset
cases. The bench supplies only start/read/response controls,not polynomial
commands or preformatted messages. Python independently derives all secrets,
matrix entries,transforms,products,partial sums,inverse rows and final t rows.
Each allocated region's ID/order,every accepted scalar value,index,last,
commit,readback metadata and release is checked. Row0 at each level also
matches a coefficient-domain negacyclic schoolbook calculation.

Results:7 complete polynomial-phase operations,3 expected rejects and4 resets;
34 delivered t=A*s1+s2 rows.172304 scalar writes and8448 exact92-bit reads match.
The three ordinary runs cover all34 secret nonces and102 matrix positions
across levels2/3/5;four recovery runs use level2 with different xi and reused IDs.
The parameter2 run uses ID65500,exercising16-bit wrap. Invalid parameter3 and
unimplemented Sign/Verify commands have no sampling/allocation side effects.
The controller retires every temporary and retained region after overall
completion acceptance,then runs again without reset. Raw s1/s2 and s1_hat
remain readable while overall completion is held.

Reset targets:half-collected seed output,first secret after8 accepted values,
first t row held before consumption,and the first accumulator rewrite after8
accepted values. Recovery uses the same ID with a different xi. Pending-read
handoff:all34 row completions retire while their last read response is held;
136 checks prove the controller keeps the region reserved until that response
retires.29 deliberately corrupted captures are rejected.

All13 focused integration gates and their checker fault tests pass on the same
current source token after relocation and Power2Round extraction.
Frozen create-only source/capture evidence:`evidence/stage5j_keygen_polynomials.zip`
and its SHA256 sidecar. Earlier archives retain their snapshot paths unchanged.

Capture/verdicts:stage5_keygen_outputs.txt,stage5_keygen_compare.log and
stage5_keygen_checker_selftest.log. Require
DILITHIUM_STAGE5J_KEYGEN_POLYNOMIAL_CAPTURE_PASS,the independent
DILITHIUM STAGE5J KEYGEN POLYNOMIAL COMPARE PASS,schoolbook and checker PASS.
This is local FIPS-derived intermediate testing,not official full-key NIST KATs.
Key encoding,public-key hashing and complete public/secret-key output remain
next. No new synthesis,PPA,full-system UVM or coverage percentage is claimed.

Source relocation:old bank_poly_store is now module memory in controller/memory.sv;
the old scalar memory is slot_memory under legacy/. The legacy scalar tests
remain selectable. Historical Stage5I and earlier sections below refer to their
snapshot names. See SPECIFICATION.md for the current layout.

## Stage5I seed-driven sampling and row execution

The new synthesizable `src/controller/keygen_sample_source.sv` retains the
RTL-expanded seed and supplies messages to the existing banked row subsystem.
The focused bench connects the adapter to `keccak_sampler_row #(.RAW_SERVICE(1))`.
There is one dual-core Keccak, one sampler, one NTT and one four-bank store.
No second hash engine or full-polynomial buffer is added.

Run the same prepare command, then select the new test in Questa:

```tcl
# Questa Transcript; working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST seed_row
do dilithium/run.do
```

```powershell
# Repository root, after simulation
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit seed_row
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit seed_row
```

`prepare` creates `stage5_seed_inputs.txt`: three deterministic 32-byte xi
values, one per level. It derives them with SHA256("banked-row-level-p").
These are local reproducible inputs, not official NIST KeyGen vectors.
The RTL hashes xi||byte(k)||byte(l), collects 128 SHAKE256 bytes, and retains
rho(32 bytes), rho-prime(64) and K(32). Commands then select A[row,column] or a
secret nonce. The RTL formatter supplies rho||column||row or rho-prime||nonce_le16.
The test supplies descriptors and xi; its seed-driven branch does not drive
preformatted fixture bytes into the DUT.

The existing row bench has a SEED_SOURCE parameter; selector seed_row sets it
to 1. Selector row retains the original fixture-driven baseline. Its 48 message
fixtures remain independent expectations for both tests. The seed-driven
capture is `stage5_seed_row_outputs.txt`; verdicts are in
`stage5_seed_row_compare.log` and `stage5_seed_row_checker_selftest.log`.
The source token includes the new helper, changed wrappers, bench and checker.

Additional ledger events:SC(source command),SR(raw descriptor),SI(raw absorption),
SO(raw output),SE(raw retirement),SF(sample absorption),SD(source retirement and
retained seed). Python checks every seed byte, every accepted absorption word,
tag/core ownership and retirement order before applying the existing row,
packed-memory, direct-transform, schoolbook and C-ADD checkers.

Results:190 source commands =20 successful seed expansions +163 successful
sampling commands +7 expected rejections. All2560 raw SHAKE bytes and1103
sampling absorption words match. All163 polynomials feed the established
row campaign:13 complete rows,27 row rejections,7 row reset aborts,161 NTT
commands,55 ADDs and12544 exact92-bit readbacks. The seven adapter rejections
are missing seed,invalid opcode,invalid seed level,mismatched retained level,
out-of-range secret nonce,row and column. Rejected requests cause no hash,
sampling or bank allocation. Completion holds four cycles per command without
accepting another command or changing retained material. Reset invalidates
seed validity and the bank/row state together.

23 deliberate capture corruptions are rejected. Existing eleven focused gates
are rerun separately on the same source token. These checks do not establish
whole-KeyGen output or comprehensive UVM coverage. Current row fixtures use
s1 nonces and two matrix rows per level; all s2 nonces and remaining matrix rows
are not exercised in this connected campaign. Seed/absorption-phase resets
remain covered by earlier isolated helper tests, not a new Stage5I reset sweep.
The bench still schedules polynomial/NTT/row commands. Next:automate the
KeyGen sequence,retain s2,add it to each inverse row,then round and encode keys.

The Stage5H section below describes the preserved fixture-driven baseline.

Frozen evidence:`evidence/stage5i_seed_row.zip` and
`evidence/stage5i_seed_row.sha256`. The create-only archive contains current
source,fixtures,captures,all12 gate verdicts,documentation and a per-file hash
manifest. Preserve earlier archives;their snapshots describe earlier source.

## Current scope

### Stage5H row multiply/accumulate and inverse NTT

New RTL:row_accumulate.sv and keccak_sampler_row.sv under src/controller/.
The existing process DMA/store gain an explicit destructive accumulation mode.
Test:tb/tb_dilithium/tb_row_accumulate.sv. Same single script and launcher:

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST row
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit row
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit row
```

Require DILITHIUM_STAGE5H_ROW_CAPTURE_PASS,then DILITHIUM STAGE5H ROW COMPARE
PASS,ROW_SCHOOLBOOK_PASS and C_ROW_ADD_PASS. Inputs:stage5_row_samples.txt has48
FIPS-formatted secret/matrix message fixtures;stage5_row_expected.txt contains
six complete expected coefficient-domain rows. Python expands deterministic xi
with SHAKE256(xi||k||l),then formats rho||column||row and rho-prime||nonce_le16.
The test drives those messages into actual SHAKE/sampler RTL. Seed collection
and message-formatter RTL are still separately tested helpers,not connected by
this row scheduler. These fixtures are locally generated,not official NIST KATs.

The bench exercises two rows per level2/3/5,retaining transformed secrets between
rows,plus seven reset/recovery cases. Ordinary NTT and eligible Pre-NTT feed the
retained secret bank. Each successful row uses l PWM commands,l-1 destructive
ADDs,and one normalized inverse NTT. Row source metadata is validated before
arithmetic;all lower commands,IDs,domains,write/ack/commit and release order are
independently checked. The resulting polynomial is u_i=(A*s1)_i. Addition of s2,
Power2Round,key encoding and full-KeyGen output comparison remain next work.

Results:47 row commands=13 successes+27 expected rejections+7 reset aborts.
163 successful sample jobs,161 NTT/Pre/PWM/INTT commands and55 in-place ADD
commands are captured.96264 scalar writes,24066 physical packed writes and
24066 acknowledgements match. Public readbacks12544 words=50176 coefficients;
6918 process word-cache reads verify old data,updated owner ID and exact
read-before-overwrite frontier. C independently matches13832 completed ADD
results from13833 accepted operands(the final extra input is reset-aborted).
The six reference rows also match coefficient-domain negacyclic schoolbook
products,independently of the hardware scheduling.

Rejections cover invalid level/row index,workspace alias/busy state,stale A/S
owners,wrong parameter,untransformed secret and missing matrix source. No child
arithmetic starts for these commands. Sources and result remain protected while
completion is held. The single accumulator and scratch are reused/released;
matrix/secret preservation is checked with full readback. Reset targets:
metadata validation,first PWM execution,first accumulator completion,in-place
partial overwrite,scratch release,inverse execution,and held whole-row completion.
Recovery reuses row IDs with a different matrix row. All old descriptors reject
reads after reset. Witnesses:160 held-row refusal checks and4 pending-read checks.

Capture extends the existing scalar/word ledger with B(row descriptor array),
DROW(row retirement),Z(row abort),M(old source-word cache read and write frontier)
and L(region release,internal/external). Python models the exact child command
sequence and snapshots the old accumulator before rewrite.26 checker corruptions
are rejected,including incorrect term count,stale source,missing ADD/ack/commit,
wrong cached old data/frontier and wrong row result. Files:stage5_row_outputs.txt,
stage5_row_compare.log and stage5_row_checker_selftest.log. GUI waves show the
row FSM,column counter,leases,PWM/ADD/inverse commands and accumulator updates.

This is a source-tested sequential staged-row implementation. It does not yet
overlap matrix sampling with row arithmetic or implement the full KeyGen/Sign/
Verify controller. No new synthesis,physical RAM/Fmax/area result or full-system
UVM coverage percentage is claimed. Default selector4/Quartus top stay unchanged.
All ten earlier source gates and checker selftests freshly pass at the current
source token. Frozen evidence:evidence/stage5h_row.zip and stage5h_row.sha256,
containing current source/references,fixtures,all eleven source captures/verdicts,
universal docs and the prepared Quartus project. CRC/member bytes and per-member
manifest hashes are verified. Older evidence remains unchanged.

### Stage5G banked ADD/SUB/Power2Round and NTT chains

New RTL:src/controller/process/poly_process_dma.sv. It is connected inside
keccak_sampler_ntt_banks with PROCESS_SERVICE=1. Test:tb/tb_dilithium/
tb_bank_process.sv. The same single Python script and run.do drive this gate.
The earlier arithmetic unit and all three standalone engines are unchanged.

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST bank_process
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit bank_process
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit bank_process
```

Require DILITHIUM_STAGE5G_CAPTURE_PASS,then the independent DILITHIUM STAGE5G
BANK PROCESS COMPARE PASS and C_BANK_PROCESS_PASS. Prepare generates
stage5_process_banks_inputs.txt:262 scheduled sample,NTT,process,read and reset
actions,plus the common104 messages. RTL captures stage5_process_banks_outputs.txt.
Python keeps its own region/owner/domain/value and write/ack/commit ledger.
It computes ordinary modular arithmetic and integer Power2Round,with direct
NTT/inverse and schoolbook references for the real connected NTT chains.
The rebuilt process_reference C executable separately checks actual accepted
process operands using repository power2round() and modular arithmetic.

Results:23 successful sample jobs;15 successful NTT operations;71 process
commands=34 successes+33 expected rejections+4 reset aborts. There are8978
accepted process inputs and8976 completed outputs,all matching Python/C.
The ledger checks22297 coefficient writes,5574 packed writes and5574 acks,
plus8512 exact92-bit reads(34048 coefficients). Completed jobs account for21760
coefficient writes;537 belong to aborted prefixes. Packed writes5440 belong to
completed jobs,134 to aborted prefixes;one additional prefix coefficient never
forms a full word. These are checked observations,not all possible input values.

All three parameters are exercised. Chains include sampled secrets -> NTT,
sampled matrix -> PWM -> ADD/SUB -> INTT -> ADD -> Power2Round,and stored low ->
real NTT. ADD/SUB cover both domains,A==B,negative modular differences and
round-trip recovery. Source preservation is checked. Invalid op,stale/missing
A/B,domain/parameter mismatch,and destination aliasing reject without arithmetic
or allocation side effects. Busy destinations wait while unrelated release
unblocks them. Held completions protect result regions. Pending public reads
block process acceptance. Resets reach initial DMA,arithmetic with partial
writeback,between low/high writes,and after low commit before high commit.
Recovery reuses source IDs with different messages. Full KeyGen formatting,
row scheduling and key encoding remain future work;these are not NIST KATs.

Power2Round writes low modulo q and zero-extended high into two64-word regions.
Public complete bits mask partial publication until both commits. The signed
low and13-bit encoding4096-low are also checked at the arithmetic boundary;
key byte encoding is not implemented. Observed rounding spans high0..1023,
low-4095..4088;exact positive4096 ties are covered by the separate Stage5A
directed RTL gate,not asserted reached by this banked workload.

Capture:J/S sample allocation/retirement,O NTT command,C process command,V
region allocation,W scalar store,P/Q packed write/ack,U internal region commit,
T NTT input,N NTT output,I process input,K all arithmetic outputs,R/E public
read/rejection,L release,A reset-aborted process,X reset,Y partial-publication
snapshot,G ownership witnesses,F totals. The checker validates262 actions,
all physical packing/order/metadata and atomic-publication snapshots. It rejects
29 deliberate corruptions,including missing high commit and a false visible
partial result. Logs:stage5_process_banks_compare.log,
stage5_process_banks_c_reference.log,stage5_process_banks_checker_selftest.log.

This gate establishes the tested shared bank/process connection. It is not full
KeyGen,whole-operation official-vector conformance,full-system UVM coverage or
a new synthesis/timing/area result. Default selector4 and Quartus top are still
the preserved scalar baseline;the banked process path has its explicit selector.
All nine earlier source gates and checker selftests are freshly revalidated.
Frozen evidence:evidence/stage5g_bank_process.zip and stage5g_bank_process.sha256.
The archive preserves current sources,reference code,prepared inputs,all ten
source captures/verdicts,shared documentation and the prepared Quartus project.
CRC,manifest hashes and member bytes are verified. Earlier archives are unchanged;
no new synthesis/netlist run is represented by this checkpoint.

### Stage5F sampling through banked NTT and result storage

New controller:src/controller/keccak_sampler_ntt_banks.sv. Focused test:
tb/tb_dilithium/tb_keccak_sampler_ntt_banks.sv. The actual SHAKE,sampler and NTT
run together;the same Python script supplies independent hashlib/scalar sampler
and direct-transform/schoolbook polynomial expectations. This is not an official
NIST full-operation test.

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST bank_ntt
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit bank_ntt
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit bank_ntt
```

Require DILITHIUM_STAGE5F_CAPTURE_PASS and DILITHIUM STAGE5F BANK NTT COMPARE
PASS. Capture:stage5_ntt_banks_outputs.txt;verdict:stage5_ntt_banks_compare.log;
checker fault verdict:stage5_ntt_banks_checker_selftest.log. GUI waves include
leases,word/lane DMA,engine streams,word acknowledgements and public reads.

Results:16 successful sample jobs;54 arithmetic commands comprising30 successes,
21 expected rejections and3 reset aborts. Checks cover4096 sampled coefficients,
9746 accepted DMA values,7712 engine outputs and2944 exact92-bit readbacks
(11776 coefficients). Physical writes2952=1024 sample+1920 successful compute+
8 aborted-compute words. Acknowledgements2951=2944 completed-job words+7 aborted
words;reset cancels the final outstanding acknowledgement. Successful compute
DMA9216 values plus530 aborted-prefix values(18+256+256) gives9746. Engine
outputs7680 from30 completed polynomials plus32 before reset gives7712.

All four banks,three parameters and four operations are exercised,including
same-bank source/destination placement,A==B PWM,round trips and independent
schoolbook multiplication. Original inputs remain readable and unchanged.
Rejections check nonexistent/stale A and B,domain/parameter/Pre eligibility and
destination aliasing. A busy explicit destination waits;source release attempts
are blocked. Pending external reads block compute acceptance. Held completion
blocks destination release. Reset targets load,execution and packed writeback;
recovery reuses IDs with different input values.

Capture records retain the Stage4 J/W/S,O/V/T/K/D/B,R/E/L,X/F ledger. O additionally
names the requested destination;R includes the actual small-coefficient flag.
P/Q record physical packed writes/acknowledgements with sampler/compute owner,
region and word index;P also carries all92 data bits. G records ownership
witnesses. Python checks exact arithmetic,packing,lane order,addresses,IDs,
domains,bounds,write-before-ack-before-publication,source preservation and reset.
Nineteen corruptions of values,tags,packing,acknowledgements,publication records,
witnesses and freshness are rejected. This is focused source verification,not a
new full-system coverage percentage or PPA/full-KeyGen result.
All eight earlier focused source gates and their checker selftests freshly
pass with the current source token. The create-only evidence/stage5f_bank_ntt.zip
and stage5f_bank_ntt.sha256 preserve sources,references,all nine captures/verdicts,
shared docs and the prepared Quartus project. MANIFEST.csv records each member's
SHA256;no new synthesis/fit is claimed. Earlier evidence archives are unchanged.

### Stage5E real sampling into packed banks

New RTL:bank_poly_store.sv and keccak_sampler_banks.sv under src/controller/.
Tests:tb_keccak_sampler_banks.sv and bank_store_protocol_test.sv under
tb/tb_dilithium/. Same single Python script and run.do;the common104-job
stage2_inputs/expected files drive the actual SHAKE/sampler engines.

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST bank_store
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit bank_store
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit bank_store
```

Require DILITHIUM_STAGE5_STORE_PASS,BANK_STORE_PROTOCOL_PASS and DILITHIUM
STAGE5 STORE COMPARE PASS. Output:stage5_store_outputs.txt;comparison and fault
checker logs:stage5_store_compare.log/stage5_store_checker_selftest.log.

Results:104 accepted jobs,88 completed,8 expected errors,8 reset aborts.
23173 accepted coefficients match Python;5792 physical packed writes and5790
acknowledgements are checked. Readback5632 words equals22528 completed-polynomial
coefficients. MEMORY_MAP.md explains aborted prefixes and the two unaccepted
write acknowledgements. All64 aligned regions are filled/inspected,occupied
regions reject replacement until released,and fresh jobs overwrite/revalidate
them. Both contexts and all four modes/three parameters are checked.

Capture:J descriptor/core/region/ID,W coefficient,K92-bit bank write,B write
ack,S external retirement,R checked word response,E rejected read,L release,
A abort,X reset,G protocol-fault gate,F totals. Python independently checks
coefficient values,23-bit lane order,physical word addresses,write acknowledgements,
publication,IDs/domain/bounds metadata,read order,region reuse and exact totals.
It rejects12 intentional corruptions,including removing a physical write.

The companion injects wrong coefficient index,last,value,ID,core;premature or
wrong-ID success;and a257th coefficient. All raise sticky fault without any
successful publication. Reset recovery is checked between faults. Main tests
also reset held successful/error read responses and invalidate stale regions.
These are focused integration checks;no new full-system UVM/coverage/PPA or
full-operation result is claimed. Stage5F above adds banked NTT DMA/writeback;
default Stage4 remains available as the historical scalar baseline.

Frozen checkpoint:evidence/stage5e_bank_store.zip and stage5e_bank_store.sha256.
115 members preserve RTL/references,all eight focused captures/verdicts and
the then-current shared docs. CRC,manifest/member bytes and SHA256 verified;
preserve this archive unchanged during NTT migration.

### Stage5D LightHD four-bank memory foundation

User selected the published four1024x92-bit dual-port logical banks over the
earlier scalar-pool proposals. Files:src/controller/poly_bram.sv,
src/controller/memory_banks.sv,tb/tb_dilithium/tb_memory_banks.sv. Same Python
script and launcher;no new full-system UVM or standalone .do is added.

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,from sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST bank_memory
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit bank_memory
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit bank_memory
```

Require DILITHIUM_STAGE5_BANKS_PASS and DILITHIUM STAGE5 BANKS COMPARE PASS.
Input:stage5_banks_inputs.txt;capture:stage5_banks_outputs.txt;verdict and checker
logs:stage5_banks_compare.log,stage5_banks_checker_selftest.log. The generated
program has14880 offers:14872 accepted,8 deliberately blocked/canceled on reset.
Of the14872 accepted requests,14864 receive responses and8 write acknowledgements
are canceled by reset. The writes themselves had committed and persist.
Responses comprise9509 exact92-bit reads plus5355 write acknowledgements.

Python keeps a separate(bank,address)->92-bit word model and a pending response
per port. Each accepted read snapshots its expected value;responses must match
ID,port,address,operation and data and occur after their acceptance edge. Write
acknowledgement payload is unspecified and not compared. Reset cancels queued
responses without clearing modeled payload. Recovery reads prove that accepted
writes persist and unaccepted blocked writes did not happen.

The program writes/reads every one of4096 bank words,then tests same-address
read/read,read/write,write/write,independent ports,random traffic,stalls and
reset. Witnesses:73 collisions,4112 same-address dual-read pairs,1031 cycles
with eight accepted requests,3075 request stalls,3034 response stalls,14807
same-edge response replacements. Twelve capture corruptions are rejected.
Capture records:J accepted request,R response,A reset-aborted response,X reset,
F totals. All prior six integration/process/hash gates were freshly rerun PASS.

The bank primitive is not an ownership controller. This gate does not prove
correct KeyGen scheduling,packing/Pre regrouping,physical BRAM inference or
LightHD's32-cycle NTT input loading. The legacy Stage4 top remains unchanged.
Current NTT ports are scalar23-bit,so wide memory alone does not provide that
loading rate. MEMORY_MAP.md lists migration work and the inspected paper regions.

### Stage5C shared hash service and RTL seed collection

Files:the optional RAW_SERVICE route in src/controller/keccak_sampler.sv,
src/controller/keygen_seed_collect.sv,and tb/tb_dilithium/tb_shared_hash.sv.
The existing single Python script/launcher now support unit shared_hash.
Stage3/4 wrappers tie the route off;their main ports/capacity are unchanged.

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST shared_hash
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit shared_hash
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit shared_hash
```

Require DILITHIUM_STAGE5_SHARED_HASH_PASS and DILITHIUM STAGE5 SHARED HASH
COMPARE PASS. Generated input:stage5_shared_inputs.txt;capture:
stage5_shared_outputs.txt;verdict/selftest:stage5_shared_compare.log and
stage5_shared_checker_selftest.log. These are local component vectors,not
official full-operation NIST vectors.

Measured:26 accepted commands,18 raw hash requests,7 completed sampled
polynomials,7 seed results(including1 expected parameter error),3 reset aborts.
The18 raw requests are9 expansion attempts plus9 direct finite hashes;the
rejected parameter case issues no hash. Six expansion results succeed;one
additional128-byte hash finishes before its held seed result is reset.
Reset-aborted input and output attempts contribute no completed seed result.

**1699 SHAKE bytes** match hashlib:6 successful expansions*128 +16 accepted
bytes before an output reset +128 bytes before a held-result reset +787 direct
raw bytes. The partial-input reset contributes no hash bytes. **1792 sampled
coefficients=7*256** match the independent sampler model. Three A/secret pairs
cover all parameters,and one additional A job runs alongside a raw job.

Crucially,the sampling message formatter consumes rho/rho-prime from the actual
RTL collector via the harness's seed-cache registers. Expected Python seed
material is used only for checking,not to drive the sampler. The main controller
and persistent polynomial/key-storage schedule are not implemented by this test.

Cases include empty/partial/multi-rate absorption,output lengths1/15/16/17/
32/128/137/169/272,both SHAKE modes,both physical cores,two raw jobs,raw+sampling,
simultaneous request arbitration,held raw completion while a peer finishes,
held seed results and ID reuse after reset. Resets target two accepted input
words,one accepted output beat,and a complete but unaccepted seed result.
Ownership overlap witnesses:mixed raw/sampling67 cycles,two raw333 cycles.
Held raw output/completion/seed-result witnesses:60/298/44 cycles;one raw-priority
arbitration edge is observed. These are ownership/workload observations,not
measurements of simultaneous permutation throughput.

Capture:J accepted command,R raw descriptor,W raw absorption,O tagged raw byte
beat,D raw completion,Z collected seed fields,S sampling descriptor,P sampling
absorption,C coefficient,T sampling status,A abort,X reset,F totals. Python
checks live core ownership,exact bytes/fields/order,completion boundaries and
all totals. Only output_bytes low bytes are compared;SHAKE rate boundaries can
produce short beats before the next permutation. Twelve corrupted captures
(raw data/core/ID/size,seeds,coefficients,error,completion and token) are rejected.
No new main-top PPA,netlist,full-operation or integrated coverage claim.

Frozen evidence:evidence/stage5c_shared_hash.zip with
stage5c_shared_hash.sha256.99 members preserve current RTL/references,all six
focused captures/verdicts and the then-current docs. CRC,manifest/member bytes
and archive SHA256 were verified. The mutable PROCESS_BLOCKS.md subsequently
corrects its shift-range explanation:valid t1 shifted by13 already fits0..q-1;
this documentation correction changes no RTL or measured result.

### Stage5B final-standard KeyGen message formatting

The chosen algorithm is final FIPS204 ML-DSA-44/65/87,called level2/3/5 in our
interface/docs. This gate checks only seed expansion and the absorbed matrix/
secret sampling messages,not full KeyGen keys or sampled coefficients.

Files added:src/controller/keygen_hash_message.sv and
tb/tb_dilithium/tb_keygen_hash_message.sv. The existing single Python script,
launcher and Quartus source list are extended. No standalone engine is changed.
Normative rules:FIPS204 Algorithms6,32,33;local sign.c/symmetric-shake.c agree.
These are generated component vectors,not published NIST full-operation vectors.

Flow:Python generates commands -> RTL formatter -> existing dual-Keccak in the
focused test -> stage5_hash_outputs.txt -> separate Python hashlib comparison.
Expected bytes are not used by RTL. The TB additionally checks every accepted
absorption word against the independently generated message. SHAKE samples use
rho/rho-prime derived from the fixed test seed for the selected parameter set.

```powershell
# Repository root; needs GCC for the other Stage5 process-reference gate.
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST hash_format
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit hash_format
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit hash_format
```

Require DILITHIUM_STAGE5_HASH_FORMAT_PASS and DILITHIUM STAGE5 HASH FORMAT
COMPARE PASS. Measured2026-10-20:165 accepted,162 message completions including
14 expected errors,3 reset aborts;883 absorption words,5888 exact SHAKE bytes.
The148 successful hashes are12 seed expansions and136 sampling-message hashes:
102 matrix coordinates(16+30+56) and34 secret nonces(8+11+15).
Twelve seed expansions include3 same-ID reset recoveries plus9 pattern/parameter
cases. Output bytes=12*128+136*32=5888. Absorption words=12*5+102*5+34*9+7
aborted-prefix words=883. Seed output slicing is rho32,rho-prime64,K32;an RTL
collector is now tested by Stage5C above;the Stage5B gate itself only checks bytes.

Errors cover parameter3,opcode3,out-of-range row/column and secret nonces.
Resets hit a held descriptor,after two absorption words,and a held message
completion;all coordinate/hash state resets together. Request/input/done/hash
stalls observe111/288/757/671 cycles;all held offers stay stable. The command
ports are poisoned after acceptance to check snapshots. Both physical core
tags are observed. Twelve intentional checker corruptions are rejected.

Capture records:J command,D descriptor,W absorption word,V SHAKE beat,S message
completion,A abort,E finished hash/error case,X reset,F totals. Python checks
ownership,ordering,bytes,IDs,errors and exact totals. Sampling descriptors retain
output_len0;the test service substitutes32 bytes only to bound the hash test.
Continuous-XOF sampling/drain remains covered by the earlier connected gates.
No main-top connection,full-operation key output,new coverage or PPA claim.

To return to the arithmetic unit:set DILITHIUM_TEST process with stage5.
The default connected gate remains DILITHIUM_STAGE4.

### Stage5A process-unit reference and execution

The algorithm choice is now final FIPS204;these ADD/SUB/Power2Round rules are
also common to the earlier candidate versions. The same Python file generates
stage5_process_inputs.txt with10349 arithmetic/framing cases. During prepare,
GCC builds tb/tb_dilithium/process_reference.c plus the unchanged local rounding.c
under sim/dilithium/reference_build/. Its exhaustive Power2Round reference
check and Python/C agreement appear in stage5_c_reference.log. The C program
uses the original power2round function;no RTL math is called.

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,from sim/:isolated process gate,not complete Stage5/KeyGen
set DILITHIUM_STAGE 5
set DILITHIUM_TEST process
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5
python sim/dilithium/dilithium_vectors.py selftest --stage 5
```

Require DILITHIUM_STAGE5_PROCESS_PASS and DILITHIUM STAGE5 PROCESS COMPARE PASS.
10349 accepted cases produce10346 exact outputs,3 reset aborts and13 expected
error outputs. C separately checks8380417 canonical inputs;RTL checks9208 dense
rounding points plus modular arithmetic/error/transport cases. Error outputs
count among the10346 compared beats,not extra transactions.12 checker corruptions
are rejected. Source/reference/C-adapter hashes bind the generated file and capture.

stage5_outputs.txt records J(accepted case),P(error,residue,high,signed low,
packed low,ID,index,last,opcode),A(reset abort),X(reset),F(totals). Separate Python
comparison verifies exact arithmetic,metadata,elastic ordering and totals.
GCC is needed only by prepare;Questa's freshness check does not compile C.
The default run and Python --stage remain4 for the current connected subsystem.
No complete KeyGen or official full-operation vector comparison is claimed.
Create-only evidence/stage5a_process.zip and stage5a_process.sha256 preserve
the audit manifest,current source/references,test inputs/captures/verdicts and
shared docs. Its immutable RESULT.txt records the then-pending decisions;
the byte-format choice is resolved above,while key storage remains open.

Stage4 now checks real Keccak -> sampling -> memory -> NTT -> memory. It uses
the same Python script and locally generated subsystem vectors;these are not
official full-operation Dilithium/ML-DSA vectors. Main default commands:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,from sim/
set DILITHIUM_STAGE 4
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 4
python sim/dilithium/dilithium_vectors.py selftest --stage 4
```

Preparation writes the shared sampling files and stage4_expected.txt with26
arithmetic polynomials. Python imports the unchanged mathematical functions in
FIPS204_NTT/ntt_vectors.py. Direct polynomial evaluation/inverse evaluation
provide transform expectations;independent schoolbook multiplication checks
the Matrix A/secret product chain. The SV test does not generate expected
NTT values using the DUT or a mirrored RTL function.

stage4_outputs.txt records J/W/S sampling lifecycle,O(compute descriptor),
V(reservation decision/destination),T(each DMA value with source slot/ID/index),
K(each NTT output/index/last),D(public completion),B(reset abort),R(stored
readback including domain),E(rejected read),L(release),X(reset) andF(totals).
The separate Python checker maintains slot ownership and source locks,
derives eligibility from actual expected values,checks every transfer and
all metadata,and requires exact lifecycle/totals. It computes each operation
again from the expected source polynomials;captured RTL values are never
used as the golden input to later expected arithmetic.

PASS:16 sampled jobs,50 commands,30 successes,17 rejects,3 reset aborts;
4096 sampled values,9745 DMA values,7713 result values and11776 stored reads.
Result arithmetic:30*256=7680 completed values plus33 accepted before reset.
All16 source polynomials and30 completed results are read in full:46*256=11776.
The three aborted destinations never publish complete results. Reset also
invalidates their source slots;43 explicit releases and6 invalid reads pass.
12 checker corruptions cover output,DMA value/ID,stored value/domain,source ID,
reservation/completion,missing output/commit,stale token and extra read.
Logs:stage4.log,stage4_compare.log,stage4_checker_selftest.log.

Relocated standalone NTT source UVM passes748 jobs/191488 values;18 original
standalone Python cases/4608 values match. Logs under sim/ntt/import_* identify
this relocation separately from historical branch evidence. No fresh standalone
or integrated synthesis/netlist run was made in this functionality-first stage.
Create-only evidence/stage4_subsystem.zip and stage4_subsystem.sha256 preserve
the imported module package,current integration source/reference/tests,
prepared projects,source captures/verdicts and universal docs. MANIFEST.csv
hashes each member;RESULT.txt states functional scope and unrun PPA/netlist work.

## Preserved Stage3 scope and commands

Stage3 extends the same one-script flow to real sampled polynomial storage.
Select DILITHIUM_STAGE=3 to run tb_keccak_sampler_memory. Inputs and expected
polynomials remain stage2_inputs.txt/stage2_expected.txt for both stages;these
names preserve the original generated format. Stage3 writes a distinct
stage3_outputs.txt with slot lifecycle and stored readbacks.

Current commands after `prepare`,from the Questa GUI Transcript in sim/:

```tcl
set DILITHIUM_STAGE 3
do dilithium/run.do
```

Then from the repository root:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 3
python sim/dilithium/dilithium_vectors.py selftest --stage 3
```

Require DILITHIUM_STAGE3_CAPTURE_PASS,MEMORY_PROTOCOL_PASS and the independent
DILITHIUM STAGE3 COMPARE PASS.104 jobs pass:88 complete,8 expected errors,
8 aborts;23180 exact writes (22528 complete+652 aborted-prefix values),22528
exact stored readbacks,88 releases,99 invalid reads and5 integrated resets.
All24 successful mode/parameter/actual-core combinations are present.
The three-slot fault companion separately proves8 protocol-fault cases,bounds,
pipelined read responses and reset of a stalled successful response.

Stage3 capture records:J(case,core,slot,ID),W(case,core,index,value,last),
S(case,core,status),A(case,core,prefix count),R(case,slot,index,value,ID,mode,
parameter,domain),E(slot,index rejected),L(slot release),X(reset),F(totals).
Python maintains its own slot/live-job model;it checks allocation,publication,
every write/read,release/reset and exact totals against the independent golden
polynomials.12 deliberate corruptions cover data,slot,index,ID,mode,parameter,
domain,missing read,duplicate job,missing commit,stale token and extra read.
All are rejected. stage3.log,stage3_compare.log and stage3_checker_selftest.log
record the verdicts. No official full-operation vectors or full UVM claim.
The create-only evidence/stage3_subsystem.zip and stage3_subsystem.sha256
preserve current RTL,testbenches,independent script,vectors,captures,logs,
universal docs and prepared Quartus files. MANIFEST.csv lists each member's
SHA256. RESULT.txt distinguishes source verification from unrun Stage3 synthesis.

## Preserved Stage2 flow

Stage2 checks the real SHAKE-to-sampling connection. The vectors are generated
locally;they are not official full-operation NIST vectors. The absorbed messages
include deterministic seeded bytes and arbitrary boundary lengths. This does
not validate full KeyGen/Sign/Verify seed expansion,encoding or signing randomness.

One script,`sim/dilithium/dilithium_vectors.py`,provides prepare/check/compare and
checker self-test. It uses Python hashlib SHAKE128/SHAKE256 and the unchanged
independent scalar sampler reference in `FIPS204_SAMPLER/sampler_vectors.py`.
No RTL function or SV golden result is used to generate the expected polynomial.

## Simple flow and commands

```text
Python messages -> SHAKE in hashlib -> independent sampling -> expected file
       |
       +-> input file -> real Keccak+sampler RTL -> captured output file
                                                      |
                          separate Python compare ----+-> PASS/FAIL
```

From repository root:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

From `sim/` in the Questa GUI Transcript:

```tcl
set DILITHIUM_STAGE 2
do dilithium/run.do
```

From repository root after capture:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 2
python sim/dilithium/dilithium_vectors.py selftest --stage 2
```

| File under sim/dilithium/ | Producer and meaning |
|---|---|
| stage2_inputs.txt | Python:case index,ID,mode,param,abort flag,byte length,message hex |
| stage2_expected.txt | Python:expected status/abort/count and canonical coefficients |
| stage2_outputs.txt | Simulator:J descriptor,C coefficient,S status,A abort,F totals |
| stage2.log | Saved headless Transcript;GUI displays its own Transcript |
| stage2_compare.log | Separate Python verdict |
| stage2_checker_selftest.log | Deliberate-corruption rejection verdict |
| stage2.wlf | Wave database;GUI launcher adds public and bridge/control waves |

The two input/golden files carry the same SHA256 token,bound to their contents,
reference and actual source/test/launcher files. The launcher checks freshness
before compilation;comparison recomputes it. Re-run prepare and capture after
source changes. Do not compare an old capture against a different token.

The simulator checks values/index/core/ID/last and status against the generated
golden file,plus independent protocol/ownership assertions. It requires an
explicit test_passed flag after all104 jobs. A fatal or watchdog without that
flag makes the launcher fail. The separate Python checker verifies all records
and exact totals again;process exit alone is not a passing result.

## Measured source results

104 accepted jobs:88 complete polynomials,8 expected invalid-parameter errors,
8 reset aborts. Current two-slot bridge:23089 coefficients match:22528 from88*256
complete polynomials plus561 accepted aborted-prefix coefficients. All24 combinations
of4 modes,3 valid parameters and2 contexts are observed in successful jobs.

Four reset targets reach both owned contexts:full blocked bridge,held Keccak output,
drain pending,and externally stalled status. Recovery reuses the same IDs with
different messages. All12 checker corruptions are rejected:value,index,core,
job ID,last,status,case,footer,missing coefficient,duplicate descriptor,extra
coefficient and stale token.

The queue reaches full occupancy for34198 observed cycles and simultaneous
push/pop128 times. Status checks both queued tags before retirement. The
initial one-slot workload checked23081 values;that historical capture remains
in evidence/stage2_subsystem_initial.zip. Changed abort timing explains the
different number of checked prefix values;all88 complete polynomials stay256
coefficients long. See THROUGHPUT.md for workload cycles and timing-trial status.

These are focused source tests. Full Dilithium UVM coverage,full-operation
official-vector checks,new integrated netlist simulation and FPGA testing remain
future stages. The standalone Keccak NIST suite is separately documented.
