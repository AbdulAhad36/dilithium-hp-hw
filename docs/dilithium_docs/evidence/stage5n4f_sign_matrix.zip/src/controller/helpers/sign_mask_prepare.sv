// Control-only signing front end. Caller retains the prepared-key lease and
// grants this client exclusive services until busy drops (including READY).
// Pure-message mu -> private seed -> ExpandMask vector;no duplicate engines.
// Masks stay private until the entire vector succeeds. Explicit clear releases
// masks only;the prepared key belongs to sign_key_prepare and remains retained.
`default_nettype none
module sign_mask_prepare (
  input wire logic clk,rst,command_valid_i,output logic command_ready_o,busy_o,fault_o,
  input wire logic context_valid_i,input wire logic [1:0] context_param_i,
  input wire logic [15:0] context_id_i,input wire logic [63:0] context_regions_i,
  input wire logic [255:0] context_key_i,input wire logic [511:0] context_tr_i,
  input wire logic [15:0] command_id_i,command_message_len_i,command_nonce_i,
  input wire logic [8:0] command_context_len_i,input wire logic [5:0] command_base_i,
  input wire logic [255:0] command_rnd_i,
  input wire logic payload_valid_i,output logic payload_ready_o,
  input wire logic [63:0] payload_data_i,input wire logic [3:0] payload_bytes_i,
  input wire logic [15:0] payload_index_i,input wire logic payload_last_i,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic [2:0] done_code_o,output logic [15:0] done_id_o,
  output logic result_valid_o,output logic [511:0] result_mu_o,result_seed_o,
  output logic [63:0] result_regions_o,output logic [6:0][5:0] result_handles_o,
  input wire logic clear_valid_i,output logic clear_ready_o,
  output dilithium_service_pkg::request_t service_o,
  input wire dilithium_service_pkg::response_t service_i
);
  typedef enum logic [3:0] {IDLE,CHECK,START,WAIT_RESULT,REPORT,READY,CLEAN,HALT} state_e;
  state_e state;
  logic [1:0] param_r,phase_r;logic [15:0] id_r,key_id_r,mlen_r,nonce_r;
  logic [8:0] ctx_r;logic [5:0] base_r,scan_r;logic [3:0] length_r,ordinal_r;
  logic [63:0] plan_r,owned_r,key_regions_r;logic [6:0][5:0] handles_r;
  logic [255:0] key_r,rnd_r;logic [511:0] tr_r,mu_r,seed_r,digest_r;
  logic [2:0] code_r;logic clearing_r,started_r,core_r,retired_r;
  logic [6:0] count_r;logic [6:0] command_end;logic [16:0] nonce_end;
  logic [17:0] message_end;logic [3:0] command_length;logic [63:0] command_plan;
  logic quiescent,fmt_command_ready,fmt_busy,fmt_request,fmt_ready,fmt_sampling,fmt_mode;
  logic [1:0] fmt_param;logic [15:0] fmt_id,fmt_length,fmt_outlen;
  logic fmt_input,fmt_input_ready,fmt_last,fmt_done,fmt_done_ready;
  logic [63:0] fmt_data;logic [3:0] fmt_bytes;logic [15:0] fmt_index,fmt_done_id;
  logic [2:0] fmt_code;logic raw_fire,done_fire,status_fire,identity_bad;
  wire [5:0] destination=base_r+6'(ordinal_r);
  always_comb begin
    command_length=context_param_i==0?4'd4:(context_param_i==1?4'd5:4'd7);
    command_end={1'b0,command_base_i}+7'(command_length);
    nonce_end={1'b0,command_nonce_i}+17'(command_length);
    message_end=18'd66+18'(command_context_len_i)+18'(command_message_len_i);
    command_plan=0;
    for(int i=0;i<64;i++)if(i>=int'(command_base_i) && i<int'(command_end))command_plan[i]=1;
  end
  assign quiescent=service_i.active==0 && !service_i.op_busy && !service_i.process_busy &&
    !service_i.sign.busy && !service_i.load.busy && !service_i.row_busy &&
    !service_i.pack.done_valid && !service_i.response_valid && service_i.read_ready;
  assign command_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault;
  assign busy_o=state!=IDLE;assign done_valid_o=!rst && state==REPORT && !fault_o;
  assign done_code_o=code_r;assign done_id_o=id_r;
  assign result_valid_o=!rst && !fault_o && ((state==REPORT && code_r==0) || state==READY);
  assign result_mu_o=result_valid_o?mu_r:512'd0;assign result_seed_o=result_valid_o?seed_r:512'd0;
  assign result_regions_o=result_valid_o?owned_r:64'd0;
  assign result_handles_o=result_valid_o?handles_r:'0;
  assign clear_ready_o=!rst && state==READY && quiescent && !fault_o && !service_i.fault;
  sign_hash_message formatter(
    .clk(clk),.rst(rst),.command_valid_i(state==START && !fault_o),.command_ready_o(fmt_command_ready),.busy_o(fmt_busy),
    .command_op_i(phase_r),.command_param_i(param_r),.command_id_i(id_r),
    .command_message_len_i(mlen_r),.command_nonce_i(nonce_r+16'(ordinal_r)),.command_context_len_i(ctx_r),
    .command_tr_i(tr_r),.command_mu_i(mu_r),.command_mask_seed_i(seed_r),.command_key_i(key_r),.command_rnd_i(rnd_r),
    .payload_valid_i(payload_valid_i && phase_r==0),.payload_ready_o(payload_ready_o),
    .payload_data_i(payload_data_i),.payload_bytes_i(payload_bytes_i),.payload_index_i(payload_index_i),.payload_last_i(payload_last_i),
    .request_valid_o(fmt_request),.request_ready_i(fmt_ready),.request_sampling_o(fmt_sampling),.request_mode_o(fmt_mode),
    .request_param_o(fmt_param),.request_id_o(fmt_id),.request_message_len_o(fmt_length),.request_output_len_o(fmt_outlen),
    .input_valid_o(fmt_input),.input_ready_i(fmt_input_ready),.input_data_o(fmt_data),.input_bytes_o(fmt_bytes),
    .input_index_o(fmt_index),.input_last_o(fmt_last),.done_valid_o(fmt_done),.done_ready_i(fmt_done_ready),
    .done_code_o(fmt_code),.done_id_o(fmt_done_id));
  assign fmt_ready=state==WAIT_RESULT && !fault_o && (fmt_sampling?service_i.job_ready:service_i.raw_ready);
  assign fmt_input_ready=state==WAIT_RESULT && !fault_o && (fmt_sampling?service_i.input_ready:service_i.raw_input_ready);
  // Drain formatter and physical service before handing the engines onward.
  assign fmt_done_ready=state==WAIT_RESULT && !fault_o && fmt_done &&
    ((!started_r && fmt_code!=0) || (retired_r && service_i.active==0));
  assign raw_fire=service_i.raw_output_valid && service_o.raw_output_ready;
  assign done_fire=service_i.raw_done_valid && service_o.raw_done_ready;
  assign status_fire=service_i.status_valid && service_o.status_ready;
  always_comb begin
    identity_bad=0;
    if(raw_fire)identity_bad=service_i.raw_output_core!=core_r || service_i.raw_output_id!=id_r ||
      service_i.raw_output_bytes!=16 || count_r>48 || retired_r;
    if(done_fire)identity_bad=identity_bad || service_i.raw_done_core!=core_r ||
      service_i.raw_done_id!=id_r || count_r+(raw_fire?7'd16:7'd0)!=64 || retired_r;
    if(status_fire)identity_bad=identity_bad || service_i.status_core!=core_r || service_i.status_id!=id_r ||
      service_i.status_code!=0 || retired_r;
    service_o='0;
    if(state==WAIT_RESULT && !fault_o)begin
      service_o.raw_valid=fmt_request && !fmt_sampling;service_o.raw_mode=fmt_mode;
      service_o.raw_id=fmt_id;service_o.raw_message_len=fmt_length;service_o.raw_output_len=fmt_outlen;
      service_o.raw_input_valid=fmt_input && !fmt_sampling;service_o.raw_input_data=fmt_data;
      service_o.raw_output_ready=started_r && phase_r!=3;service_o.raw_done_ready=started_r && phase_r!=3;
      service_o.job_valid=fmt_request && fmt_sampling;service_o.job_mode=2;service_o.job_param=fmt_param;
      service_o.job_id=fmt_id;{service_o.job_bank,service_o.job_region}=destination;
      service_o.message_len=fmt_length;service_o.input_valid=fmt_input && fmt_sampling;service_o.input_data=fmt_data;
      service_o.status_ready=started_r && phase_r==3;
    end
    service_o.release_valid=state==CLEAN && owned_r[scan_r] && !fault_o;
    {service_o.release_bank,service_o.release_region}=scan_r;
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;phase_r<=0;id_r<=0;key_id_r<=0;mlen_r<=0;nonce_r<=0;ctx_r<=0;base_r<=0;scan_r<=0;
      length_r<=0;ordinal_r<=0;plan_r<=0;owned_r<=0;key_regions_r<=0;handles_r<=0;
      key_r<=0;rnd_r<=0;tr_r<=0;mu_r<=0;seed_r<=0;digest_r<=0;code_r<=0;clearing_r<=0;
      started_r<=0;core_r<=0;retired_r<=0;count_r<=0;fault_o<=0;
    end else if(state!=IDLE && (service_i.fault ||
      ((state==CHECK || state==START || state==WAIT_RESULT || state==READY || state==CLEAN ||
        (state==REPORT && code_r==0)) && (!context_valid_i || context_id_i!=key_id_r ||
          context_param_i!=param_r || context_regions_i!=key_regions_r))))begin
      fault_o<=1;state<=HALT;
    end else case(state)
      IDLE:if(command_valid_i && command_ready_o)begin
        param_r<=context_param_i;key_id_r<=context_id_i;key_regions_r<=context_regions_i;
        key_r<=context_key_i;tr_r<=context_tr_i;rnd_r<=command_rnd_i;id_r<=command_id_i;
        mlen_r<=command_message_len_i;ctx_r<=command_context_len_i;nonce_r<=command_nonce_i;base_r<=command_base_i;
        length_r<=command_length;plan_r<=command_plan;owned_r<=0;handles_r<=0;mu_r<=0;seed_r<=0;
        code_r<=0;clearing_r<=0;phase_r<=0;ordinal_r<=0;
        if(!context_valid_i || context_param_i==3)begin code_r<=1;state<=REPORT;end
        else if(command_end>64 || nonce_end>65536 || command_context_len_i>255 || message_end>65535 ||
          (command_plan & context_regions_i)!=0)begin code_r<=2;state<=REPORT;end
        else state<=CHECK;
      end
      CHECK:begin
        if(!quiescent || (service_i.reserved & key_regions_r)!=key_regions_r ||
          (service_i.complete & key_regions_r)!=key_regions_r)begin code_r<=1;state<=REPORT;end
        else if((service_i.reserved & plan_r)!=0)begin code_r<=3;state<=REPORT;end
        else state<=START;
      end
      START:if(fmt_command_ready)begin started_r<=0;retired_r<=0;count_r<=0;digest_r<=0;state<=WAIT_RESULT;end
      WAIT_RESULT:begin
        if(fmt_request && fmt_ready)begin started_r<=1;core_r<=fmt_sampling?service_i.job_core:service_i.raw_core;end
        if(raw_fire)begin
          if(count_r<=48)digest_r[8*count_r+:128]<=service_i.raw_output_data;
          if(count_r<=64)count_r<=count_r+16;
        end
        if(done_fire || status_fire)retired_r<=1;
        if(identity_bad)code_r<=5;
        if(fmt_done_ready)begin
          if(phase_r==3)owned_r<=service_i.reserved & plan_r;
          if(phase_r==3 && ((service_i.reserved & plan_r) & ~service_i.complete)!=0)begin
            fault_o<=1;state<=HALT;
          end else if(code_r!=0 || identity_bad || fmt_code!=0 || fmt_done_id!=id_r ||
            (phase_r==3 && (!service_i.reserved[destination] || !service_i.complete[destination])))begin
            // Sampling status accepts the memory finish on that same edge.
            // Check complete only AFTER status/active retirement,not before ACK.
            if(code_r==0)code_r<=identity_bad || fmt_done_id!=id_r || phase_r==3?3'd5:3'd4;
            scan_r<=0;state<=CLEAN;
          end else if(phase_r==0)begin mu_r<=digest_r;phase_r<=1;state<=START;end
          else if(phase_r==1)begin seed_r<=digest_r;phase_r<=3;state<=START;end
          else begin
            handles_r[ordinal_r]<=destination;
            if(ordinal_r==length_r-1'b1)state<=REPORT;
            else begin ordinal_r<=ordinal_r+1'b1;state<=START;end
          end
        end
      end
      REPORT:if(done_ready_i)state<=code_r==0?READY:IDLE;
      READY:if(clear_valid_i && clear_ready_o)begin mu_r<=0;seed_r<=0;handles_r<=0;scan_r<=0;clearing_r<=1;state<=CLEAN;end
      CLEAN:if(!owned_r[scan_r] || service_i.release_ready)begin
        owned_r[scan_r]<=0;
        if(scan_r==63)begin mu_r<=0;seed_r<=0;handles_r<=0;state<=clearing_r?IDLE:REPORT;end
        else scan_r<=scan_r+1'b1;
      end
      HALT:state<=HALT;
      default:begin fault_o<=1;state<=HALT;end
    endcase
  end
endmodule
`default_nettype wire
