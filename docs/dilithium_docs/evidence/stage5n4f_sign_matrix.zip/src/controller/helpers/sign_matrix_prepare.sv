// One attempt's yhat, A*y and Decompose schedule. Control/handles only.
// Caller holds prepared-key AND mask leases,with exclusive services ownership
// across this client's entire busy interval,including retained READY/cleanup.
`default_nettype none
module sign_matrix_prepare (
  input wire logic clk,rst,command_valid_i,output logic command_ready_o,busy_o,fault_o,
  input wire logic [15:0] command_id_i,
  input wire logic context_valid_i,input wire logic [1:0] context_param_i,
  input wire logic [15:0] context_id_i,input wire logic [63:0] context_regions_i,
  input wire logic [255:0] context_rho_i,
  input wire logic mask_valid_i,input wire logic [15:0] mask_id_i,
  input wire logic [63:0] mask_regions_i,input wire logic [6:0][5:0] mask_handles_i,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic [2:0] done_code_o,done_detail_o,output logic [15:0] done_id_o,
  output logic result_valid_o,output logic [63:0] result_regions_o,
  output logic [6:0][5:0] result_yhat_o,output logic [7:0][5:0] result_low_o,result_high_o,
  input wire logic clear_valid_i,output logic clear_ready_o,
  output dilithium_service_pkg::request_t service_o,
  input wire dilithium_service_pkg::response_t service_i
);
  typedef enum logic [4:0] {IDLE,CHECK,PLAN,NTT_START,NTT_WAIT,A_START,A_WAIT,
    ROW_START,ROW_WAIT,DECOMP_START,DECOMP_WAIT,DECOMP_RETIRE,FREE_ROW,REPORT,READY,CLEAN,HALT} state_e;
  state_e state;
  logic [1:0] param_r;logic [15:0] id_r,key_id_r,mask_id_r;
  logic [255:0] rho_r;logic [63:0] key_regions_r,mask_regions_r,plan_r,owned_r,persistent_r;
  logic [6:0][5:0] y_r,yhat_r,a_r;logic [7:0][5:0] low_r,high_r;
  logic [5:0] acc_r,scratch_r,w_r,scan_r,count_r,needed_r;
  logic [3:0] rows_r,row_r;logic [2:0] columns_r,column_r;
  logic [2:0] code_r,detail_r;logic clearing_r,issued_r,core_r,retired_r;
  logic [3:0] command_rows;logic [2:0] command_columns;
  logic [63:0] handle_mask;logic source_bad,quiescent,incomplete;
  logic fmt_ready,fmt_request,fmt_mode,fmt_input,fmt_done,fmt_error,fmt_ack;
  logic [15:0] fmt_len,fmt_outlen,fmt_id;logic [63:0] fmt_data;
  always_comb begin
    command_rows=context_param_i==0?4'd4:(context_param_i==1?4'd6:4'd8);
    command_columns=context_param_i==0?3'd4:(context_param_i==1?3'd5:3'd7);
    handle_mask=0;source_bad=0;
    for(int j=0;j<7;j++)if(j<int'(command_columns))begin
      if(handle_mask[mask_handles_i[j]])source_bad=1;
      handle_mask[mask_handles_i[j]]=1;
    end
    source_bad=source_bad || handle_mask!=mask_regions_i || (mask_regions_i & context_regions_i)!=0;
  end
  assign quiescent=service_i.active==0 && !service_i.op_busy && !service_i.process_busy &&
    !service_i.sign.busy && !service_i.load.busy && !service_i.row_busy &&
    !service_i.pack.done_valid && !service_i.response_valid && service_i.read_ready;
  assign incomplete=((service_i.reserved & plan_r) & ~service_i.complete)!=0;
  assign command_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault;
  assign busy_o=state!=IDLE;assign done_valid_o=!rst && state==REPORT && !fault_o;
  assign done_code_o=code_r;assign done_detail_o=detail_r;assign done_id_o=id_r;
  assign result_valid_o=!rst && !fault_o && ((state==REPORT && code_r==0) || state==READY);
  assign result_regions_o=result_valid_o?owned_r:64'd0;
  assign result_yhat_o=result_valid_o?yhat_r:'0;assign result_low_o=result_valid_o?low_r:'0;
  assign result_high_o=result_valid_o?high_r:'0;
  assign clear_ready_o=!rst && state==READY && quiescent && !fault_o && !service_i.fault;
  keygen_hash_message matrix_message(
    .clk(clk),.rst(rst),.command_valid_i(state==A_START && !fault_o),.command_ready_o(fmt_ready),
    .command_op_i(2'd1),.command_param_i(param_r),.command_id_i(id_r),.command_nonce_i(16'd0),
    .command_row_i({4'd0,row_r}),.command_column_i({5'd0,column_r}),.command_seed_i({256'd0,rho_r}),
    .request_valid_o(fmt_request),.request_ready_i(state==A_WAIT && service_i.job_ready && !fault_o),
    .request_mode_o(fmt_mode),.request_message_len_o(fmt_len),.request_output_len_o(fmt_outlen),
    .input_data_o(fmt_data),.input_valid_o(fmt_input),.input_ready_i(state==A_WAIT && service_i.input_ready && !fault_o),
    .done_valid_o(fmt_done),.done_ready_i(fmt_ack),.done_error_o(fmt_error),.done_id_o(fmt_id));
  assign fmt_ack=state==A_WAIT && !fault_o && fmt_done &&
    ((!issued_r && fmt_error) || (retired_r && service_i.active==0));
  always_comb begin
    service_o='0;
    service_o.op_valid=state==NTT_START && !fault_o;service_o.op=0;
    service_o.op_a_region=y_r[column_r];service_o.op_a_id=mask_id_r;
    service_o.op_dest_region=yhat_r[column_r];service_o.op_id=id_r;
    service_o.op_done_ready=state==NTT_WAIT && !fault_o;
    service_o.job_valid=state==A_WAIT && fmt_request && !fault_o;
    service_o.job_mode=0;service_o.job_param=param_r;service_o.job_id=id_r;
    {service_o.job_bank,service_o.job_region}=a_r[column_r];service_o.message_len=fmt_len;
    service_o.input_valid=state==A_WAIT && fmt_input && !fault_o;service_o.input_data=fmt_data;
    service_o.status_ready=state==A_WAIT && issued_r && !retired_r && !fault_o;
    service_o.row_valid=state==ROW_START && !fault_o;service_o.row_param=param_r;
    service_o.row_index=row_r;service_o.row_id=id_r;service_o.row_acc=acc_r;
    service_o.row_scratch=scratch_r;service_o.row_result=w_r;
    service_o.row_a=a_r;service_o.row_s=yhat_r;
    for(int j=0;j<7;j++)begin service_o.row_a_id[j]=id_r;service_o.row_s_id[j]=id_r;end
    service_o.row_done_ready=state==ROW_WAIT && !fault_o;
    service_o.sign.valid=state==DECOMP_START && !fault_o;service_o.sign.op=0;
    service_o.sign.param=param_r;service_o.sign.a=w_r;service_o.sign.a_id=id_r;
    service_o.sign.dest=low_r[row_r];service_o.sign.high=high_r[row_r];service_o.sign.id=id_r;
    service_o.sign.done_ready=state==DECOMP_WAIT && !fault_o;
    service_o.release_valid=!fault_o && ((state==FREE_ROW && owned_r[scan_r] && !persistent_r[scan_r]) ||
      (state==CLEAN && owned_r[scan_r]));
    {service_o.release_bank,service_o.release_region}=scan_r;
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;id_r<=0;key_id_r<=0;mask_id_r<=0;rho_r<=0;
      key_regions_r<=0;mask_regions_r<=0;plan_r<=0;owned_r<=0;persistent_r<=0;
      y_r<=0;yhat_r<=0;a_r<=0;low_r<=0;high_r<=0;acc_r<=0;scratch_r<=0;w_r<=0;
      scan_r<=0;count_r<=0;needed_r<=0;rows_r<=0;row_r<=0;columns_r<=0;column_r<=0;
      code_r<=0;detail_r<=0;clearing_r<=0;issued_r<=0;core_r<=0;retired_r<=0;fault_o<=0;
    end else if(state!=IDLE && (service_i.fault ||
      ((state!=REPORT || code_r==0) && (!context_valid_i || !mask_valid_i ||
        context_id_i!=key_id_r || context_param_i!=param_r || context_regions_i!=key_regions_r ||
        mask_id_i!=mask_id_r || mask_regions_i!=mask_regions_r))))begin fault_o<=1;state<=HALT;end
    else case(state)
      IDLE:if(command_valid_i && command_ready_o)begin
        param_r<=context_param_i;id_r<=command_id_i;key_id_r<=context_id_i;mask_id_r<=mask_id_i;
        rho_r<=context_rho_i;key_regions_r<=context_regions_i;mask_regions_r<=mask_regions_i;y_r<=mask_handles_i;
        rows_r<=command_rows;columns_r<=command_columns;needed_r<=6'(2*command_rows+2*command_columns+3);
        plan_r<=0;owned_r<=0;persistent_r<=0;yhat_r<=0;a_r<=0;low_r<=0;high_r<=0;
        scan_r<=0;count_r<=0;row_r<=0;column_r<=0;code_r<=0;detail_r<=0;clearing_r<=0;
        if(!context_valid_i || !mask_valid_i || context_param_i==3 || source_bad)begin code_r<=1;state<=REPORT;end
        else state<=CHECK;
      end
      CHECK:if(!quiescent || ((service_i.reserved & (key_regions_r|mask_regions_r))!=(key_regions_r|mask_regions_r)) ||
        ((service_i.complete & (key_regions_r|mask_regions_r))!=(key_regions_r|mask_regions_r)))begin code_r<=1;state<=REPORT;end
        else state<=PLAN;
      PLAN:begin
        if(!service_i.reserved[scan_r] && count_r<needed_r)begin
          plan_r[scan_r]<=1;count_r<=count_r+1'b1;
          if(count_r<6'(columns_r))begin yhat_r[count_r]<=scan_r;persistent_r[scan_r]<=1;end
          else if(count_r<6'(2*columns_r))a_r[count_r-6'(columns_r)]<=scan_r;
          else if(count_r<6'(2*columns_r)+6'(rows_r))begin low_r[count_r-6'(2*columns_r)]<=scan_r;persistent_r[scan_r]<=1;end
          else if(count_r<6'(2*columns_r)+6'(2*rows_r))begin high_r[count_r-6'(2*columns_r)-6'(rows_r)]<=scan_r;persistent_r[scan_r]<=1;end
          else if(count_r==needed_r-3)acc_r<=scan_r;
          else if(count_r==needed_r-2)scratch_r<=scan_r;
          else w_r<=scan_r;
        end
        if(scan_r==63)begin
          if(count_r==needed_r || (count_r==needed_r-1 && !service_i.reserved[scan_r]))state<=NTT_START;
          else begin code_r<=2;state<=REPORT;end
        end else scan_r<=scan_r+1'b1;
      end
      NTT_START:if(service_i.op_ready)state<=NTT_WAIT;
      NTT_WAIT:if(service_i.op_done_valid)begin
        owned_r<=service_i.reserved & plan_r;
        if(incomplete)begin fault_o<=1;state<=HALT;end
        else if(service_i.op_done_code!=0)begin code_r<=3;detail_r<=service_i.op_done_code;scan_r<=0;state<=CLEAN;end
        else if(service_i.op_done_id!=id_r || service_i.op_done_region!=yhat_r[column_r] ||
          !service_i.reserved[yhat_r[column_r]] || !service_i.complete[yhat_r[column_r]])begin code_r<=7;scan_r<=0;state<=CLEAN;end
        else if(column_r==columns_r-1'b1)begin column_r<=0;state<=A_START;end
        else begin column_r<=column_r+1'b1;state<=NTT_START;end
      end
      A_START:if(fmt_ready)begin issued_r<=0;retired_r<=0;state<=A_WAIT;end
      A_WAIT:begin
        if(fmt_request && service_i.job_ready)begin issued_r<=1;core_r<=service_i.job_core;end
        if(service_i.status_valid && service_o.status_ready)begin
          retired_r<=1;
          if(service_i.status_id!=id_r || service_i.status_core!=core_r)code_r<=7;
          else if(service_i.status_code!=0)begin code_r<=4;detail_r<=service_i.status_code;end
        end
        if(fmt_ack)begin
          owned_r<=service_i.reserved & plan_r;
          if(incomplete)begin fault_o<=1;state<=HALT;end
          else if(code_r!=0 || fmt_error || fmt_id!=id_r || !service_i.reserved[a_r[column_r]] || !service_i.complete[a_r[column_r]])begin
            if(code_r==0)code_r<=fmt_error?3'd4:3'd7;
            scan_r<=0;state<=CLEAN;
          end else if(column_r==columns_r-1'b1)state<=ROW_START;
          else begin column_r<=column_r+1'b1;state<=A_START;end
        end
      end
      ROW_START:if(service_i.row_ready)state<=ROW_WAIT;
      ROW_WAIT:if(service_i.row_done_valid)begin
        owned_r<=service_i.reserved & plan_r;
        if(incomplete)begin fault_o<=1;state<=HALT;end
        else if(service_i.row_done_code!=0)begin code_r<=5;detail_r<=service_i.row_done_code;scan_r<=0;state<=CLEAN;end
        else if(service_i.row_done_id!=id_r || service_i.row_done_region!=w_r || service_i.row_completed_terms!=columns_r ||
          !service_i.reserved[w_r] || !service_i.complete[w_r])begin code_r<=7;scan_r<=0;state<=CLEAN;end
        else state<=DECOMP_START;
      end
      DECOMP_START:if(service_i.sign.ready)state<=DECOMP_WAIT;
      DECOMP_WAIT:if(service_i.sign.done_valid)begin
        owned_r<=service_i.reserved & plan_r;
        // The child hides its source w even in REPORT. Check the whole plan
        // only after its done handshake releases that source lease.
        if(service_i.sign.done_code!=0)begin code_r<=6;detail_r<=service_i.sign.done_code;scan_r<=0;state<=CLEAN;end
        else if(service_i.sign.done_id!=id_r || service_i.sign.done_dest!=low_r[row_r] || service_i.sign.done_high!=high_r[row_r] ||
          !service_i.complete[low_r[row_r]] || !service_i.complete[high_r[row_r]] ||
          !service_i.reserved[low_r[row_r]] || !service_i.reserved[high_r[row_r]])begin code_r<=7;scan_r<=0;state<=CLEAN;end
        else state<=DECOMP_RETIRE;
      end
      DECOMP_RETIRE:if(!service_i.sign.busy)begin
        if(incomplete)begin fault_o<=1;state<=HALT;end
        else begin scan_r<=0;state<=FREE_ROW;end
      end
      FREE_ROW:if(!owned_r[scan_r] || persistent_r[scan_r] || service_i.release_ready)begin
        if(!persistent_r[scan_r])owned_r[scan_r]<=0;
        if(scan_r==63)begin
          if(row_r==rows_r-1'b1)state<=REPORT;
          else begin row_r<=row_r+1'b1;column_r<=0;state<=A_START;end
        end else scan_r<=scan_r+1'b1;
      end
      REPORT:if(done_ready_i)state<=code_r==0?READY:IDLE;
      READY:if(clear_valid_i && clear_ready_o)begin scan_r<=0;clearing_r<=1;state<=CLEAN;end
      CLEAN:if(!owned_r[scan_r] || service_i.release_ready)begin
        owned_r[scan_r]<=0;
        if(scan_r==63)state<=clearing_r?IDLE:REPORT;
        else scan_r<=scan_r+1'b1;
      end
      HALT:state<=HALT;
      default:begin fault_o<=1;state<=HALT;end
    endcase
  end
endmodule
`default_nettype wire
