`timescale 1ns/1ps
module tb_lighthd_sign;
  import lighthd_pkg::*;
  parameter bit DIAGNOSTIC=1;
  logic clk=0;always #5 clk=~clk;
  logic rst=1,start_valid_i=0,start_ready_o,busy_o,fault_o;
  logic [1:0] start_param_i=0;logic [15:0] start_id_i=0,start_message_len_i=0;
  logic [8:0] start_context_len_i=0;logic [255:0] start_rnd_i=0;
  logic input_valid_i=0,input_ready_o;logic [63:0] input_data_i=0;
  logic [3:0] input_bytes_i=0;logic [15:0] input_index_i=0;logic input_last_i=0;
  logic signature_valid_o,signature_ready_i,signature_last_o;
  logic [63:0] signature_data_o;logic [3:0] signature_bytes_o;logic [9:0] signature_index_o;logic [15:0] signature_id_o;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o,done_stage_o,done_detail_o;
  logic [15:0] done_id_o;logic [16:0] attempts_o,rejections_o,next_nonce_o;
  request_t service_o;response_t service_i;logic datapath_fault;
  lighthd_sign controller(.*);
  lighthd_datapath datapath(.clk(clk),.rst(rst),.service_i(service_o),.service_o(service_i),.fault_o(datapath_fault));
  int input_file,output_file,n,serial,original,level,id,context_len,message_len,sk_len,body_len;
  string token,sk_hex,body_hex;
  logic [7:0] sk[6000],body[65535];
  int cycles=0,current=-1,got=0,total_words=0,completed=0,start_cycle,prep_count=0,pre_count=0,overlap=0,max_ring=0;
  logic held=0;logic [94:0] snapshot;
  always @(negedge clk)cycles++;
  assign signature_ready_i=!rst && cycles%13>3;
  always @(posedge clk)if(rst)held=0;else begin
    int occupied;
    occupied=$countones(controller.a_reserved_r);if(occupied>max_ring)max_ring=occupied;
    if(occupied>(start_param_i==2?16:9))$fatal(1,"Signing A ring exceeded its fixed capacity");
    if(datapath.polynomial.core_busy && |service_i.sample.active)overlap++;
    if(held && (!signature_valid_o || {signature_data_o,signature_bytes_o,signature_index_o,signature_last_o,signature_id_o}!==snapshot))
      $fatal(1,"Compact signature changed under backpressure");
    held=signature_valid_o && !signature_ready_i;
    snapshot={signature_data_o,signature_bytes_o,signature_index_o,signature_last_o,signature_id_o};
    if(service_o.ntt.valid && service_i.ntt.ready && controller.state==controller.PREP_CMD)begin
      prep_count++;if(service_o.ntt.op==3)pre_count++;
    end
    if(controller.state==controller.CHASH_DRAIN && controller.format_finished_r && controller.raw_finished_r && controller.bank_finished_r)
      $fdisplay(output_file,"C %0d %0d %0d %0128h",attempts_o,controller.nonce_base_r,controller.ctilde_bytes,controller.ctilde_r);
    if(service_i.process.done_valid && service_o.process.done_ready && service_i.process.reject)begin
      if(controller.state==controller.Z_NORM_RUN)$fdisplay(output_file,"R %0d 1 %0d",attempts_o,controller.poly_r);
      if(controller.state==controller.R0_NORM_RUN)$fdisplay(output_file,"R %0d 2 %0d",attempts_o,controller.row_r);
      if(controller.state==controller.CT0_NORM_RUN)$fdisplay(output_file,"R %0d 3 %0d",attempts_o,controller.row_r);
    end
    if(controller.state==controller.MHINT_RUN && service_i.process.done_valid && controller.hint_reject)
      $fdisplay(output_file,"R %0d 4 %0d",attempts_o,controller.row_r);
    if(controller.state==controller.HINT_RESULT && controller.hint_result && controller.hint_reject)
      $fdisplay(output_file,"R %0d 4 %0d",attempts_o,controller.row_r);
    if(signature_valid_o && signature_ready_i)begin
      int length;length=start_param_i==0?2420:start_param_i==1?3309:4627;
      if(signature_id_o!=start_id_i || signature_index_o*8!=got || signature_bytes_o<1 || signature_bytes_o>8 ||
        signature_last_o!=(got+signature_bytes_o==length) || (signature_data_o>>(8*int'(signature_bytes_o)))!=0)
        $fatal(1,"Compact signature identity/order/byte count/padding");
      $fdisplay(output_file,"S %0d %016h %0d %0d",signature_index_o,signature_data_o,signature_bytes_o,signature_last_o);
      got+=int'(signature_bytes_o);total_words++;
    end
    if(fault_o || datapath_fault)$fatal(1,"Compact Sign fault case%0d state%0d ntterror%0d procerror%0d loaderror%0d",current,controller.state,
      service_i.ntt.done_code,service_i.process.done_code,service_i.load.done_code);
    if(busy_o && cycles%100000==0)$display("COMPACT_SIGN_PROGRESS:case%0d clock%0d state%0d attempts%0d rejections%0d",current,cycles,controller.state,attempts_o,rejections_o);
  end
  task automatic feed_frame(input bit secret_key,input int length);
    int amount,index,watchdog;index=0;watchdog=0;
    while(index*8<length && !done_valid_o)begin
      @(negedge clk);input_valid_i=1;input_data_i='1;
      amount=length-index*8>=8?8:length-index*8;
      input_bytes_i=4'(amount);input_index_i=16'(index);input_last_i=index*8+amount==length;
      for(int lane=0;lane<amount;lane++)input_data_i[8*lane+:8]=secret_key?sk[8*index+lane]:body[8*index+lane];
      @(posedge clk);
      while(!input_ready_o && !done_valid_o)begin
        @(posedge clk);if(watchdog++>500000)$fatal(1,"Compact Sign input timeout state%0d",controller.state);
      end
      if(input_ready_o)index++;
      @(negedge clk);input_valid_i=0;
    end
    if(index*8<length)$fatal(1,"Signing completed before required input frame");
  endtask
  initial begin
    int watchdog,k,l;
    input_file=$fopen(DIAGNOSTIC?"sim/dilithium/stage7c_sign_diagnostic_inputs.txt":"sim/dilithium/stage7c_sign_inputs.txt","r");
    output_file=$fopen(DIAGNOSTIC?"sim/dilithium/stage7c3_sign_diagnostic_outputs.txt":"sim/dilithium/stage7c3_sign_outputs.txt","w");
    if(!input_file || !output_file || $fscanf(input_file,"%s %d",token,n)!=2)$fatal(1,"Prepare compact signing fixtures");
    $fdisplay(output_file,"%s %0d",token,n);repeat(3)@(negedge clk);rst=0;
    for(int test=0;test<n;test++)begin
      if($fscanf(input_file,"%d %d %d %d %d %d %d %d %h %s %s",serial,original,level,id,context_len,message_len,sk_len,body_len,start_rnd_i,sk_hex,body_hex)!=11 || serial!=test)
        $fatal(1,"Compact Sign fixture schema");
      for(int i=0;i<sk_len;i++)sk[i]=8'(sk_hex.substr(2*i,2*i+1).atohex());
      for(int i=0;i<body_len;i++)body[i]=8'(body_hex.substr(2*i,2*i+1).atohex());
      @(negedge clk);current=serial;start_param_i=2'(level);start_id_i=16'(id);
      start_context_len_i=9'(context_len);start_message_len_i=16'(message_len);
      start_valid_i=1;got=0;prep_count=0;pre_count=0;start_cycle=cycles;
      #1;if(!start_ready_o)$fatal(1,"Compact Sign not ready for command");
      $fdisplay(output_file,"J %0d %0d %0d %0d",serial,original,level,id);
      @(negedge clk);start_valid_i=0;
      feed_frame(1,sk_len);feed_frame(0,body_len);watchdog=0;
      while(!done_valid_o)begin
        @(negedge clk);
        if(watchdog++>5000000)$fatal(1,"Compact Sign command timeout case%0d state%0d producer%0d attempts%0d",serial,controller.state,controller.producer,attempts_o);
      end
      k=level==0?4:level==1?6:8;l=level==0?4:level==1?5:7;
      if(done_code_o!=0 || done_stage_o!=0 || done_detail_o!=0 || done_id_o!=start_id_i ||
        prep_count!=l+2*k || pre_count!=l+k || !service_i.idle)$fatal(1,"Compact Sign completion/cache/retirement gate");
      $fdisplay(output_file,"D %0d %0d %0d %0d %0d %0d %0d",done_code_o,done_stage_o,done_detail_o,attempts_o,rejections_o,next_nonce_o,cycles-start_cycle);
      $display("COMPACT_SIGN_CASE_PASS:serial%0d original%0d level%0d cycles%0d attempts%0d",serial,original,level,cycles-start_cycle,attempts_o);
      repeat(3)begin @(negedge clk);if(!done_valid_o || done_code_o!=0)$fatal(1,"Compact Sign completion unstable");end
      done_ready_i=1;@(negedge clk);done_ready_i=0;completed++;
    end
    $fdisplay(output_file,"F %0d",completed);$fclose(input_file);$fclose(output_file);
    $display("LIGHTHD_SIGN_CAPTURE_PASS:%0d signatures/%0d words/overlap%0d/peak_A_ring%0d;independent published-signature comparison required",completed,total_words,overlap,max_ring);
    $finish;
  end
  initial begin #(64'd10000000000);$fatal(1,"Compact Sign global watchdog");end
endmodule
