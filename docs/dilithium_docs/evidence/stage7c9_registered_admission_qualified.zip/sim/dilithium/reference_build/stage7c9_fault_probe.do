onerror {quit -code 1 -f}
vmap lighthd_foundation_work sim/dilithium/work_lighthd_foundation
vlog -sv -work lighthd_foundation_work sim/dilithium/reference_build/stage7c9_fault_probe.sv
vsim -voptargs=+acc lighthd_foundation_work.tb_lighthd_main lighthd_foundation_work.stage7c9_fault_probe
onfinish stop
run -all
quit -f
