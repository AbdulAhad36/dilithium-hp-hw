onerror {quit -code 1 -f}
vlib sim/dilithium/work_lighthd_geometry
vmap lighthd_geometry_work sim/dilithium/work_lighthd_geometry
vlog -sv -work lighthd_geometry_work src/controller/memory/lighthd_memory_port.sv tb/tb_dilithium/tb_lighthd_memory_geometry.sv tb/tb_dilithium/tb_lighthd_memory_admission.sv
vsim lighthd_geometry_work.tb_lighthd_memory_admission
onfinish stop
run -all
quit -sim
vsim -voptargs=+acc lighthd_geometry_work.tb_lighthd_memory_geometry
onfinish stop
run -all
quit -f
