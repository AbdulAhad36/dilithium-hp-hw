`timescale 1ns/1ps
`define V tb_lighthd_main.dut.core.verify_controller
`define D tb_lighthd_main.dut.core.datapath
module stage7c9_fault_probe;
 int last=-1;
 always @(negedge tb_lighthd_main.clk)if(!tb_lighthd_main.rst)begin
  if(int'(`V.state)!=last)begin
   $display("C9_VERIFY_TRACE t%0t state%0d producer%0d inputfault%b samplefault%b nttDone%b/%0d processDone%b/%0d physicalfault%b",$time,`V.state,`V.producer,`V.input_fault,`V.service_i.sample.fault,`V.service_i.ntt.done_valid,`V.service_i.ntt.done_code,`V.service_i.process.done_valid,`V.service_i.process.done_code,tb_lighthd_main.dut.core.physical_fault);
   last=int'(`V.state);
  end
  if(`V.service_i.ntt.done_valid && `V.service_i.ntt.done_code!=0)
   $display("C9_NTT_FAULT state%0d op%0d in%0d out%0d stream%b doneerror%h",`D.polynomial.state,`D.polynomial.op_r,`D.polynomial.inputs_r,`D.polynomial.outputs_r,`D.polynomial.stream_fault,`D.polynomial.memory_done_error_i);
  if(`D.polynomial.stream_fault)$display("C9_STREAM_FAULT state%0d op%0d load%b pwm%b allsources%b inputs%0d result%b writeReady%h",`D.polynomial.state,`D.polynomial.op_r,`D.polynomial.load_ready,`D.polynomial.pwm_ready,`D.polynomial.all_sources,`D.polynomial.inputs_r,`D.polynomial.result_valid,`D.polynomial.memory_write_ready_i);
 end
endmodule
