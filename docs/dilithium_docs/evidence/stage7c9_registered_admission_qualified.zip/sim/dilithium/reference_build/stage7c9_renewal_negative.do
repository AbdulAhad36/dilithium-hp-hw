onerror {quit -code 1 -f}
vlib sim/dilithium/reference_build/work_renewal_negative
vmap renewal_negative_work sim/dilithium/reference_build/work_renewal_negative
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/keccak/keccak_pkg.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/keccak/keccak_param_unit.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/keccak/keccak_absorb_unit.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/keccak/theta_step.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/keccak/rho_step.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/keccak/pi_step.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/keccak/chi_step.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/keccak/iota_step.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/keccak/keccak_step_unit.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/keccak/keccak_output_unit.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/keccak/keccak_core.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/keccak/keccak_dual_interleaved.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/sampler/sampler_pkg.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/sampler/sampler_input_prepare.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/sampler/sampler_mask_unpack.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/sampler/sampler_secret_lane.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/sampler/sampler_compact.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/sampler/sampler_ball.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/sampler/sampler.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/ntt/ntt_pkg.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/ntt/mod_mul.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/ntt/butterfly_unit.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/ntt/twiddle_rom.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/ntt/ntt_core.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/helpers/lighthd_pkg.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/memory/poly_bram.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/memory/memory_banks.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/memory/lighthd_memory_port.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/memory/lighthd_memory.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/memory/lighthd_memory_router.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/memory/lighthd_bank_fabric.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/process/lighthd_secret_regroup.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/process/power2round.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/process/cnb.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/process/mhint.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/process/lighthd_process.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/process/lighthd_bitpkg.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/datapath/keccak_sampler.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/datapath/lighthd_sampler_writer.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/process/lighthd_bitunpkg.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/datapath/lighthd_load_decode.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/datapath/lighthd_hash_sampler.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/datapath/lighthd_ntt_dma.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/datapath/lighthd_process_dma.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/datapath/lighthd_datapath.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/process/lighthd_hintunpkg.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/lighthd_verify_input.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/process/sign_hash_message.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/lighthd_verify.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/lighthd_keygen.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/lighthd_sign_input.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/process/lighthd_hintpkg.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/lighthd_sign.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/lighthd_dilithium.sv}
vlog -sv -work renewal_negative_work {D:/GitHub/dilithium-hp-hw/tmp/stage7c8_archive_check/src/controller/dilithium_fpga.sv}
vlog -sv -work renewal_negative_work sim/dilithium/reference_build/stage7c9_renewal_negative_tb.sv
vsim renewal_negative_work.tb_lighthd_ntt_dma
onfinish stop
run -all
quit -f
