from pathlib import Path
from collections import defaultdict
from statistics import mean
import json,csv
here=Path('sim/dilithium');base=here/'reference_build/stage7c9_baseline_c8'
a=(base/'stage7c4_main_outputs.txt').read_text().splitlines();b=(here/'stage7c4_main_outputs.txt').read_text().splitlines()
assert a[-1]==b[-1]=='F 210' and len(a)==len(b),'Incomplete/changed full campaign'
groups=defaultdict(list);valid_verify=defaultdict(list);report=[]
for i,(old,new) in enumerate(zip(a[1:],b[1:]),1):
 x=old.split();y=new.split()
 if x[0]=='D':
  assert x[:-1]==y[:-1],f'Changed command outcome at line{i}'
  groups[(op,p)].append([int(x[-1]),int(y[-1])])
  if op==2 and int(x[4])==1:valid_verify[p].append([int(x[-1]),int(y[-1])])
 else:
  assert old==new,f'Changed non-timing capture record at line{i}'
  if x[0]=='J':op,p=int(x[2]),int(x[4])
report.append('FULL210_NON_TIMING_EXACT_C8:all published payload/status/attempt records exact;original source headers remain different')
summary={}
for key,values in sorted(groups.items()):
 old=[v[0]for v in values];new=[v[1]for v in values];delta=[y-x for x,y in values]
 s=dict(n=len(values),old_mean=mean(old),new_mean=mean(new),min_delta=min(delta),max_delta=max(delta),mean_delta=mean(delta),mean_overhead_pct=100*(mean(new)/mean(old)-1),max_case_overhead_pct=max(100*(y/x-1)for x,y in values),new_min=min(new),new_max=max(new))
 summary[str(key)]=s;report.append(f'{key}:'+json.dumps(s))
old=list(csv.DictReader((base/'stage7_uvm_latency.csv').open()));new=list(csv.DictReader((here/'stage7_uvm_latency.csv').open()))
assert len(old)==len(new)==30
report.append('UVM_LATENCY_HEADER:'+','.join(new[0]))
changes=[]
for x,y in zip(old,new):
 assert all(x[k]==y[k]for k in ('case','op','param'))
 changes.append({k:[x[k],y[k]]for k in x if x[k]!=y[k]})
report.append('UVM_CHANGED_ROWS:'+str(sum(bool(v)for v in changes))+'/30;all original CSV columns retained')
report.append('VALID_VERIFY_MEANS:'+json.dumps({str(p):[mean(v[0]for v in rows),mean(v[1]for v in rows)]for p,rows in valid_verify.items()}))
report.append('C9R1_CYCLE_AUDIT_PASS:measured overhead,not zero-cycle claim')
(here/'reference_build/stage7c9r1_cycles.json').write_text(json.dumps(dict(full=summary,valid_verify=dict(valid_verify),uvm_changes=changes),indent=2)+'\n')
(here/'stage7c9r1_cycle_audit.log').write_text('\n'.join(report)+'\n')
print('\n'.join(report))
