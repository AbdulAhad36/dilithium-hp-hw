# Dilithium simulation

Current `run.do` exercises Stage3's real Keccak→sampler→memory connection using a focused
non-UVM testbench under `tb/tb_dilithium/`. Main Dilithium UVM and implementation
launchers will replace/extend this evolving project at their actual stages.

Repository-root terminal:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

Questa GUI Transcript,working directory `sim/`:

```tcl
do dilithium/run.do
```

Repository-root terminal after capture:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 3
python sim/dilithium/dilithium_vectors.py selftest --stage 3
```

104 jobs:88 complete,8 expected errors,8 reset aborts,23180 exact coefficient
writes and22528 exact stored-coefficient readbacks. Require
`DILITHIUM_STAGE3_CAPTURE_PASS`,`MEMORY_PROTOCOL_PASS` and the separate Python
`DILITHIUM STAGE3 COMPARE PASS`. The launcher checks vector/source freshness and
the explicit completion flag. GUI waves include allocation,read/response/release,
slot validity and internal coefficient writes. No full UVM/coverage claim.

To rerun the preserved Stage2 test in Questa:

```tcl
set DILITHIUM_STAGE 2
do dilithium/run.do
```

Then use Python compare/selftest with `--stage 2`. Set `DILITHIUM_STAGE 3`
before running again to return to the memory test. Both stages use the same
generated input/expected files and the same Python script. Stage3 captures
memory lifecycle and readbacks in stage3_outputs.txt;Stage2 uses stage2_outputs.txt.

Golden vectors bind to the source/test/launcher/reference hash;rerun prepare and
capture after changing them. Current workload cycle witnesses are in
stage2_jobs.csv. Universal docs:docs/dilithium_docs/REFERENCE_VERIFICATION.md,
ARCHITECTURE.md and THROUGHPUT.md. Standalone module projects remain separate.
