"""Real SHAKE -> sampling -> polynomial memory: independent file comparison.

These are locally generated subsystem vectors, not full-operation NIST vectors.
One script is extended as the Dilithium subsystem grows.
"""
import argparse
import hashlib
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
REF = ROOT / 'FIPS204_SAMPLER/sampler_vectors.py'
spec = importlib.util.spec_from_file_location('sampler_reference', REF)
reference = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reference)


def cases():
    result = []
    def add(mode, param, label, length=None, abort=False, job_id=None):
        i = len(result)
        length = (34 if mode == 0 else 66 if mode in (1, 2) else 32) if length is None else length
        message = hashlib.shake_256(label.encode()).digest(length)
        # Raw absorbed messages exercise the engine connection; full seed/nonce
        # formatting is a later controller/version contract.
        if param == 3:
            values, code = [], 3
        else:
            stream = (hashlib.shake_128 if mode == 0 else hashlib.shake_256)(message).digest(4096)
            values, _ = reference.sample(mode, param, stream)
            assert len(values) == 256
            code = 0
        result.append(dict(i=i, id=1000+i if job_id is None else job_id,
                           mode=mode, param=param, message=message,
                           abort=abort, code=code, values=values))
    # Twelve pairs establish both contexts in every mode/parameter combination.
    for mode in range(4):
        for param in range(3):
            for slot in range(2):
                add(mode, param, f'base-{mode}-{param}-{slot}')
    # All sixteen ordered mode pairs, including independent live peer modes.
    for first in range(4):
        for second in range(4):
            param = (first+second) % 3
            add(first, param, f'mixed-{first}-{second}-a')
            add(second, param, f'mixed-{first}-{second}-b')
    # Empty/partial/multi-rate absorption; unused high input bytes are poisoned.
    lengths = [0, 1, 7, 8, 9, 33, 34, 65, 66, 135, 136, 137,
               167, 168, 169, 271, 272, 273, 335, 336, 337, 15, 16, 17]
    for i, length in enumerate(lengths):
        add(i % 4, (i//4) % 3, f'length-{i}', length)
    assert len(result) == 80
    for mode in range(4):
        for slot in range(2):
            add(mode, 3, f'invalid-{mode}-{slot}')
    for phase in range(4):
        for slot in range(2):
            add((phase+slot) % 4, phase % 3, f'abort-{phase}-{slot}', abort=True,
                job_id=2000+phase*2+slot)
        for slot in range(2):
            add((phase+slot) % 4, phase % 3, f'recover-{phase}-{slot}',
                job_id=2000+phase*2+slot)
    assert len(result) == 104
    return result


def artifacts():
    rows = cases()
    stimuli, golden = [], []
    for c in rows:
        stimuli.append(f"{c['i']} {c['id']} {c['mode']} {c['param']} {int(c['abort'])} {len(c['message'])} {c['message'].hex() or '-'}")
        golden.append(f"{c['i']} {c['code']} {int(c['abort'])} {len(c['values'])} " +
                      ' '.join(f'{v:06x}' for v in c['values']))
    body = '\n'.join(stimuli)+'\n'
    expected = '\n'.join(golden)+'\n'
    sources = [Path(__file__).resolve(), REF, ROOT/'sim/dilithium/run.do']
    sources += sorted((ROOT/'src/keccak').glob('*.sv'))
    sources += sorted((ROOT/'src/sampler').glob('*.sv'))
    sources += sorted((ROOT/'src/controller').glob('*.sv'))
    sources += sorted((ROOT/'tb/tb_dilithium').glob('*.sv'))
    h = hashlib.sha256((body+expected).encode())
    for p in sources:
        h.update(p.relative_to(ROOT).as_posix().encode()); h.update(p.read_bytes())
    token = h.hexdigest()
    header = f'{token} {len(rows)}\n'
    return rows, token, header+body, header+expected


def prepare():
    rows, token, stimuli, golden = artifacts()
    (HERE/'stage2_inputs.txt').write_text(stimuli, encoding='ascii')
    (HERE/'stage2_expected.txt').write_text(golden, encoding='ascii')
    print(f'PREPARE PASS: {len(rows)} jobs;88 successful,8 invalid-parameter errors,8 reset aborts;token {token}')


def check():
    rows, token, stimuli, golden = artifacts()
    if (HERE/'stage2_inputs.txt').read_text() != stimuli or (HERE/'stage2_expected.txt').read_text() != golden:
        raise ValueError('Stale source/reference/vector files: rerun prepare and capture')
    return rows, token


def verify(lines):
    rows, token = check()
    if not lines or lines[0] != 'H '+token:
        raise ValueError('Capture token differs;rerun simulation after prepare')
    opened, counts, finished = {}, {}, {}
    total_values = 0
    footer = None
    for line in lines[1:]:
        f = line.split()
        if f[0] == 'F':
            if footer is not None: raise ValueError('Duplicate footer')
            footer = list(map(int, f[1:]));continue
        i, core = map(int, f[1:3])
        if not 0 <= i < len(rows) or core not in (0, 1): raise ValueError('Unknown job/core')
        c = rows[i]
        if f[0] == 'J':
            if i in opened or int(f[3]) != c['id']: raise ValueError('Repeated/wrong descriptor')
            opened[i] = core;counts[i] = 0;continue
        if opened.get(i) != core or i in finished: raise ValueError('Unowned/retired output')
        if f[0] == 'C':
            index, value, last = int(f[3]), int(f[4],16), int(f[5])
            if index != counts[i] or index >= len(c['values']) or value != c['values'][index] or last != int(index==255):
                raise ValueError(f'Coefficient mismatch:case{i},index{index},observed{value}')
            counts[i] += 1;total_values += 1
        elif f[0] == 'S':
            if c['abort'] or int(f[3]) != c['code'] or counts[i] != len(c['values']):
                raise ValueError(f'Wrong status/count for case{i}')
            finished[i] = 'S'
        elif f[0] == 'A':
            if not c['abort'] or int(f[3]) != counts[i]: raise ValueError('Unexpected abort/count')
            finished[i] = 'A'
        else:raise ValueError('Unknown capture record')
    if len(opened) != 104 or len(finished) != 104 or footer != [104,88,8,8,total_values]:
        raise ValueError('Missing/extra jobs or incorrect footer')
    combinations = {(opened[c['i']],c['mode'],c['param']) for c in rows if not c['abort'] and c['code']==0}
    if len(combinations) != 24:raise ValueError('Missing mode/parameter/context combination')
    message = (f'DILITHIUM STAGE2 COMPARE PASS:104 jobs,88 complete,8 expected errors,8 reset aborts;'
               f'{total_values} exact coefficients (22528 complete-polynomial values plus checked aborted prefixes);'
               '24 mode/parameter/context combinations\n')
    return message


def verify_memory(lines):
    rows, token = check()
    if not lines or lines[0] != 'H '+token:
        raise ValueError('Memory capture token differs')
    opened, counts, finished, read_counts = {}, {}, {}, {}
    slots, live = {}, {}
    writes = reads = invalid = releases = resets = 0
    footer = None
    for line in lines[1:]:
        if footer is not None: raise ValueError('Record after memory footer')
        f = line.split()
        kind = f[0]
        if kind == 'F':
            footer = list(map(int, f[1:])); continue
        if kind == 'X':
            if live: raise ValueError('Reset omitted live-job abort records')
            slots.clear(); resets += 1; continue
        if kind in ('E', 'L'):
            slot = int(f[1])
            if not 0 <= slot < 4: raise ValueError('Bad memory slot')
            if kind == 'E':
                if slot in slots and slots[slot][1]: raise ValueError('Readable slot reported error')
                if not 0 <= int(f[2]) < 256: raise ValueError('Bad invalid-read index')
                invalid += 1
            else:
                if slot not in slots or not slots[slot][1]: raise ValueError('Release of incomplete slot')
                if read_counts.get(slots[slot][0], 0) != 256: raise ValueError('Released before full readback')
                del slots[slot]; releases += 1
            continue
        if kind not in ('J', 'W', 'S', 'A', 'R'): raise ValueError('Unknown memory record')
        i = int(f[1])
        if not 0 <= i < len(rows): raise ValueError('Bad memory case')
        c = rows[i]
        if kind == 'J':
            core, slot, job_id = map(int, f[2:])
            if core not in (0, 1) or core in live or not 0 <= slot < 4 or slot in slots:
                raise ValueError('Memory allocation reused live owner')
            if i in opened or job_id != c['id']: raise ValueError('Repeated/wrong memory descriptor')
            opened[i] = (core, slot); counts[i] = read_counts[i] = 0
            slots[slot] = (i, False); live[core] = i
        elif kind == 'R':
            slot, index = map(int, f[2:4])
            if slots.get(slot) != (i, True) or opened.get(i, (None,None))[1] != slot:
                raise ValueError('Read before commit, after release/reset, or from wrong slot')
            if index != read_counts.get(i) or index >= 256: raise ValueError('Read order/count mismatch')
            if (int(f[4],16) != c['values'][index] or
                list(map(int,f[5:])) != [c['id'],c['mode'],c['param'],int(c['mode']==0)]):
                raise ValueError('Memory data or metadata mismatch')
            reads += 1; read_counts[i] += 1
        else:
            core = int(f[2])
            if live.get(core) != i: raise ValueError('Write/status without live owner')
            slot = opened[i][1]
            if kind == 'W':
                index = int(f[3])
                if index != counts[i] or index >= len(c['values']): raise ValueError('Write index mismatch')
                if int(f[4],16) != c['values'][index] or int(f[5]) != int(index==255):
                    raise ValueError('Write data/last mismatch')
                counts[i] += 1; writes += 1
            else:
                if kind == 'S':
                    if c['abort'] or int(f[3]) != c['code'] or counts[i] != len(c['values']):
                        raise ValueError('Incorrect memory completion')
                    if c['code']==0: slots[slot] = (i,True)
                    else: del slots[slot]
                elif not c['abort'] or int(f[3]) != counts[i]:
                    raise ValueError('Incorrect memory abort')
                finished[i] = kind; del live[core]
    successful = [c['i'] for c in rows if not c['abort'] and c['code']==0]
    combinations = {(opened[i][0],rows[i]['mode'],rows[i]['param']) for i in successful}
    if (len(opened)!=104 or len(finished)!=104 or live or slots or
        footer != [104,88,8,8,writes,reads] or reads!=22528 or releases!=88 or
        invalid<90 or resets!=5 or len(combinations)!=24 or any(read_counts[i]!=256 for i in successful)):
        raise ValueError('Incomplete memory lifecycle/readback gate')
    return (f'DILITHIUM STAGE3 COMPARE PASS:104 jobs,88 complete,8 expected errors,8 reset aborts;'
            f'{writes} exact writes,22528 exact readbacks;88 releases,{invalid} invalid reads,5 resets\n')


def compare(stage=2):
    message=(verify_memory if stage==3 else verify)((HERE/f'stage{stage}_outputs.txt').read_text().splitlines())
    (HERE/f'stage{stage}_compare.log').write_text(message);print(message,end='')


def selftest(stage=2):
    if stage==3:
        original=(HERE/'stage3_outputs.txt').read_text().splitlines()
        verify_memory(original)
        ri=next(i for i,s in enumerate(original) if s.startswith('R '))
        trials=[]
        for label,column,value in [('value',4,'ffffff'),('slot',2,'4'),('index',3,'1'),
                                    ('job_id',5,'0'),('mode',6,'3'),('parameter',7,'3'),('domain',8,'1')]:
            lines=original.copy();f=lines[ri].split()
            if f[column]==value:value='0'
            f[column]=value;lines[ri]=' '.join(f);trials.append((label,lines))
        ji=next(i for i,s in enumerate(original) if s.startswith('J '))
        si=next(i for i,s in enumerate(original) if s.startswith('S '))
        trials += [('missing_read',original[:ri]+original[ri+1:]),
                   ('duplicate_job',original[:ji]+[original[ji]]+original[ji:]),
                   ('missing_commit',original[:si]+original[si+1:]),
                   ('stale_token',['H '+'0'*64]+original[1:]),
                   ('extra_read',original+[original[ri]])]
        for label,lines in trials:
            try:verify_memory(lines)
            except (ValueError,IndexError):continue
            raise ValueError('Memory checker accepted corruption:'+label)
        message='STAGE3 CHECKER SELFTEST PASS:12/12 corruptions rejected\n'
        (HERE/'stage3_checker_selftest.log').write_text(message);print(message,end='');return
    original=(HERE/'stage2_outputs.txt').read_text().splitlines()
    verify(original)
    ci=next(i for i,s in enumerate(original) if s.startswith('C '))
    ji=next(i for i,s in enumerate(original) if s.startswith('J '))
    si=next(i for i,s in enumerate(original) if s.startswith('S '))
    trials=[]
    for label,row,column,value in [
        ('value',ci,4,lambda v:f'{int(v,16)^1:06x}'),
        ('index',ci,3,lambda v:str(int(v)+1)),
        ('core',ci,2,lambda v:str(int(v)^1)),
        ('job_id',ji,3,lambda v:str(int(v)+1)),
        ('last',ci,5,lambda v:str(int(v)^1)),
        ('status',si,3,lambda v:str(int(v)+1)),
        ('case',ci,1,lambda v:'104'),
        ('footer',len(original)-1,1,lambda v:'103')]:
        lines=original.copy();f=lines[row].split();f[column]=value(f[column]);lines[row]=' '.join(f)
        trials.append((label,lines))
    trials += [('missing_coefficient',original[:ci]+original[ci+1:]),
               ('duplicate_descriptor',original[:ji]+[original[ji]]+original[ji:]),
               ('extra_coefficient',original+[original[ci]]),
               ('stale_capture',['H '+'0'*64]+original[1:])]
    for label,lines in trials:
        try:verify(lines)
        except ValueError:continue
        raise ValueError('Checker accepted corruption:'+label)
    message='STAGE2 CHECKER SELFTEST PASS:12/12 corruptions rejected\n'
    (HERE/'stage2_checker_selftest.log').write_text(message);print(message,end='')


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['prepare','check','compare','selftest'])
    p.add_argument('--stage',type=int,choices=[2,3],default=2)
    try:
        args=p.parse_args();command=args.command
        if command=='check':
            check();print('STAGE2 VECTOR FRESHNESS PASS')
        elif command=='prepare':prepare()
        else:{'compare':compare,'selftest':selftest}[command](args.stage)
    except (ValueError,OSError,AssertionError) as e:
        raise SystemExit('DILITHIUM REFERENCE FAIL: '+str(e))
