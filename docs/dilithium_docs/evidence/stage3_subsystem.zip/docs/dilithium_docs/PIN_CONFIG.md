# Dilithium current interface and virtual pins

Current synthesis top:`keccak_sampler_memory`,the Stage3 subsystem helper. The future
`dilithium.sv` top will extend this table when main-controller interfaces exist.
All214 non-clock bits are assigned virtual pins;clk is the one physical clock
input. No board/package assignment is selected. Stage3 has not been fitted yet.
Count:130 retained Stage2 non-clock bits (181 minus51 coefficient-stream bits)
plus84 memory/slot bits=214. Clock adds one for215 total top-level bits.

| Port | Direction | Bits | Meaning |
|---|---|---:|---|
| clk | Input |1|Shared clock,target6.757ns/about148MHz |
| rst | Input |1|Active-high coordinated reset;hold through rising edges;abort both contexts |
| job_valid_i / job_ready_o | Input/output |1 each|Descriptor ready/valid transfer |
| job_core_o | Output |1|Actual assigned Keccak/sampler context on command acceptance |
| job_slot_o | Output |2|Reserved polynomial slot on command acceptance |
| job_id_i | Input |16|Polynomial/job ID |
| message_len_i | Input |16|Complete absorption-message byte length,0..65535 |
| job_mode_i | Input |2|0=A,1=secret,2=mask,3=challenge |
| job_param_i | Input |2|0/1/2 select level2/3/5 parameters;3 yields parameter error |
| input_data_i | Input |64|Message bytes,earliest in low byte;declared length controls final partial word |
| input_valid_i / input_ready_o | Input/output |1 each|Message ready/valid transfer |
| read_valid_i / read_ready_o | Input/output |1 each|Read-request handshake |
| read_slot_i / read_index_i | Input |2 /8|Polynomial slot and coefficient index |
| response_valid_o / response_ready_i | Output/input |1 each|Synchronous read-response handshake |
| response_error_o | Output |1|Slot not COMPLETE;ignore response payload |
| response_slot_o / response_index_o | Output |2 /8|Echoed read location |
| response_data_o | Output |23|Canonical stored coefficient on successful read |
| response_id_o | Output |16|Stored job ID |
| response_mode_o / response_param_o | Output |2 each|Stored sampling mode and parameter |
| response_ntt_domain_o | Output |1|Matrix A is already transform-domain |
| release_valid_i / release_ready_o | Input/output |1 each|Explicit slot-release handshake |
| release_slot_i | Input |2|Slot to release after all consumers finish |
| reserved_o / complete_o | Output |4 each|Per-slot allocation and successful-commit masks |
| fault_o | Output |1|Sticky internal memory-protocol fault;reset recovery required |
| status_valid_o / status_ready_i | Output/input |1 each|Completion/error ready/valid;source drained before external offer |
| status_core_o | Output |1|Completed context |
| status_id_o | Output |16|Completed job ID |
| status_code_o | Output |3|Existing sampler status encoding;current tests exercise OK0 and parameter error3 |
| active_o | Output |2|Context ownership until external status acceptance |

Hold producer payloads stable while valid and not ready. Public output/status
offers remain stable until accepted or reset. input_data_i belongs to the
currently accepted Keccak message;new absorption messages are serialized by its
ingress protocol. Reset discards old jobs;it does not securely erase all data.
Independent per-job cancellation and finite-XOF length controls are not exposed.
Read/status offers remain stable until accepted or coordinated reset. Pending
read responses prevent slot release;the future controller owns longer lifetimes.
