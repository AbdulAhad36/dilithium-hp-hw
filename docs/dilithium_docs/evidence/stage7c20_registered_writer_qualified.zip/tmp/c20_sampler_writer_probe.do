onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vlib sim/dilithium/work_c20_writer_probe
vmap c20_writer_work sim/dilithium/work_c20_writer_probe
set fd [open quartus/dilithium/dilithium_full.qsf r]
set settings [read $fd];close $fd
foreach line [split $settings "\n"] {
  if {[regexp {SYSTEMVERILOG_FILE\s+(.+)$} [string trim $line] -> source]} {
    vlog -sv -work c20_writer_work [file normalize [file join quartus/dilithium $source]]
  }
}
vlog -sv -work c20_writer_work tmp/c20_sampler_writer_probe.sv tb/tb_dilithium/lighthd_bank_fixture.sv tmp/tb_c20_sampler_writer_probe.sv
vsim -L cyclonev_ver c20_writer_work.tb_c20_sampler_writer_probe
onfinish stop
run -all
quit -f
