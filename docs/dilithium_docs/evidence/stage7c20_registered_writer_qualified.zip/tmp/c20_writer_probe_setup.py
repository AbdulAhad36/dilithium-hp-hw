from pathlib import Path
import json,hashlib,sys
r=Path.cwd();here=r/'sim/dilithium';out=here/'reference_build/stage7c20_writer_probe';out.mkdir(exist_ok=False)
sys.path.insert(0,str(here));import dilithium_vectors as v
old_token,inputs,expected,selected=v.lighthd_sampler_artifacts()
source=(r/'tmp/c20_sampler_writer_probe.sv').read_text()
bench=(r/'tb/tb_dilithium/tb_lighthd_sampler_writer.sv').read_text().replace('module tb_lighthd_sampler_writer;','module tb_c20_sampler_writer_probe;')
bench=bench.replace('sim/dilithium/stage7c_sampler_inputs.txt','sim/dilithium/reference_build/stage7c20_writer_probe/stage7c_sampler_inputs.txt')
bench=bench.replace('sim/dilithium/stage7c1_sampler_writer_outputs.txt','sim/dilithium/reference_build/stage7c20_writer_probe/stage7c1_sampler_writer_outputs.txt')
bench=bench.replace('lighthd_sampler_writer dut(', 'c20_sampler_writer_probe dut(')
bench=bench.replace('  lighthd_sampler_writer dut(', '  c20_sampler_writer_probe dut(')
bench=bench.replace('  c20_sampler_writer_probe dut(','''  logic [1:0][3:0] probe_write_valid,probe_write_ready;
  logic [1:0][3:0] probe_gate;
  int queue_peak=0,queue_held=0,queue_renew=0;
  assign probe_gate={8{cycles%97>=23}};
  assign dut_write_valid_i[0]=probe_write_valid & probe_gate;
  assign probe_write_ready=dut_write_ready_o[0] & probe_gate;
  always @(posedge clk)if(!rst)begin
    if(dut.normal_count_r>queue_peak)queue_peak=dut.normal_count_r;
    if(dut.normal_count_r==2)queue_held++;
    if(dut.normal_push && dut.normal_ready)queue_renew++;
  end
  c20_sampler_writer_probe dut(''')
bench=bench.replace('.memory_write_valid_o(dut_write_valid_i[0])','.memory_write_valid_o(probe_write_valid)').replace('.memory_write_ready_i(dut_write_ready_o[0])','.memory_write_ready_i(probe_write_ready)')
bench=bench.replace('    $finish;','''    if(queue_peak!=2 || queue_held==0 || queue_renew==0)$fatal(1,"Normal queue stress missing");
    $display("WRITER_NORMAL_QUEUE_PROBE_PASS:depth%0d full_cycles%0d simultaneous_renewals%0d",queue_peak,queue_held,queue_renew);
    $finish;''')
token=hashlib.sha256(old_token.encode()+source.encode()+bench.encode()).hexdigest()
(out/'stage7c_sampler_inputs.txt').write_text(inputs.replace(old_token,token,1))
chosen=[c for c in selected if c['param']!=3 and not c['abort'] and c['bad_bytes']<0 and len(c['data'])>10]
assert len(chosen)==112
want=[token,str(len(chosen))]
for c in chosen:
 words=v.lighthd_memory_words(c);want += [str(c['i']),str(len(words))]+[f'{w:023x}' for w in words]
(out/'expected_words.txt').write_text('\n'.join(want)+'\n')
do='''onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vlib sim/dilithium/work_c20_writer_probe
vmap c20_writer_work sim/dilithium/work_c20_writer_probe
set fd [open quartus/dilithium/dilithium_full.qsf r]
set settings [read $fd];close $fd
foreach line [split $settings "\\n"] {
  if {[regexp {SYSTEMVERILOG_FILE\\s+(.+)$} [string trim $line] -> source]} {
    vlog -sv -work c20_writer_work [file normalize [file join quartus/dilithium $source]]
  }
}
vlog -sv -work c20_writer_work tmp/c20_sampler_writer_probe.sv tb/tb_dilithium/lighthd_bank_fixture.sv tmp/tb_c20_sampler_writer_probe.sv
vsim -L cyclonev_ver c20_writer_work.tb_c20_sampler_writer_probe
onfinish stop
run -all
quit -f
'''
patch='*** Begin Patch\n'
for n,b in {'tmp/tb_c20_sampler_writer_probe.sv':bench,'tmp/c20_sampler_writer_probe.do':do}.items():
 assert not (r/n).exists()
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in b.splitlines())
print(json.dumps(patch+'*** End Patch'))
