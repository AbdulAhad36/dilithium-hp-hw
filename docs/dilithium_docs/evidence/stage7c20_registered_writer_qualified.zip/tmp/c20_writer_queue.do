onerror {quit -code 1 -f}
vlib sim/dilithium/work_c20_writer_queue
vmap c20_writer_queue sim/dilithium/work_c20_writer_queue
vlog -sv -work c20_writer_queue src/controller/process/lighthd_secret_regroup.sv tmp/c20_sampler_writer_probe.sv tmp/tb_c20_writer_queue.sv
vsim c20_writer_queue.tb_c20_writer_queue
onfinish stop
run -all
quit -f
