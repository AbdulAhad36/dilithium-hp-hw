onerror {quit -code 1 -f}
vmap c20_writer_work sim/dilithium/work_c20_writer_probe
vlog -sv -work c20_writer_work tmp/tb_c20_sampler_writer_mixed.sv
foreach different {0 1} {
  vsim -L cyclonev_ver -gDIFFERENT_BANKS=$different c20_writer_work.tb_c20_sampler_writer_mixed
  onfinish stop
  run -all
  quit -sim
}
quit -f
