from pathlib import Path
import re,json
q=Path('quartus/dilithium/critical_full');names=(q/'mapped_register_names.rpt').read_text().splitlines();result={}
for label,expr,wanted in [('data','normal_data_r',184),('address','normal_address_r',20),('bank','normal_bank_r',4),('core','normal_core_r',2),('occupancy','normal_count_r',2),('pointers','normal_(read|write)_r',2)]:
 hits=[n for n in names if re.search(r'\|lighthd_sampler_writer:writer\|'+expr,n)]
 assert len(hits)==wanted,(label,len(hits),wanted);result[label]=dict(bits=len(hits),names=hits)
Path('sim/dilithium/reference_build/stage7c20_writer_registers.json').write_text(json.dumps(result,indent=2)+'\n')
print('C20_WRITER_HANDOFF_HARDWARE_PASS:214 original data/address/bank/core/occupancy/pointer bits in ONE shared two-entry normal queue')
