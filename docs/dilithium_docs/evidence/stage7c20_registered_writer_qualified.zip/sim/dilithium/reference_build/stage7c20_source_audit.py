from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c18r1_source_hashes.json').read_text());new=json.loads((rb/'stage7c20_source_hashes.json').read_text())
for n,d in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
assert len(new)==251 and len(set(new)-set(old))==2
assert {n for n in old if old[n]!=new[n]}=={'src/controller/datapath/lighthd_sampler_writer.sv','tb/tb_dilithium/tb_lighthd_sampler_writer.sv','sim/dilithium/dilithium_vectors.py','quartus/dilithium/report_full.tcl'}
print('C20_SOURCE_AUDIT_PASS:251frozen/one writer RTL/explicit tests-fingerprint-guards;all engine/Process/controller/RAM arithmetic and QSF/SDC exact C18R1')
