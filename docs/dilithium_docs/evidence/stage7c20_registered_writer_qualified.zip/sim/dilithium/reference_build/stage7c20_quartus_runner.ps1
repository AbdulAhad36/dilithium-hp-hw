$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw\quartus\dilithium'
& 'F:/altera/quartus/bin64/quartus_sh.exe' --flow compile dilithium_full *> stage7c20_compile.log
if ($LASTEXITCODE -ne 0) {throw 'Whole-main compilation failed'}
& 'F:/altera/quartus/bin64/quartus_sta.exe' -t report_full.tcl *> stage7c20_report_full.log
if ($LASTEXITCODE -ne 0) {throw 'Retained-hardware/four-corner report failed'}
if (-not (Select-String -LiteralPath critical_full/retained_registers.rpt -Pattern 'WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS' -Quiet)) {throw 'Missing retained-feature proof'}
'STAGE7C20_QUARTUS_RUNNER_PASS'
