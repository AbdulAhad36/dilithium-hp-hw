from pathlib import Path
from collections import defaultdict
from statistics import mean
import json
h=Path('sim/dilithium');m=json.loads((h/'reference_build/stage7c20_metrics.json').read_text())
f=min(c['fmax_mhz'] for c in m['corners']);groups=defaultdict(list);valid=defaultdict(list)
previous=json.loads((h/'reference_build/stage7c18r1_throughput.json').read_text())
prior={(v['operation'],v['level']):v for v in previous['rows']}
lines=(h/'stage7c4_main_outputs.txt').read_text().splitlines();assert lines[-1]=='F 210'
for line in lines[1:]:
    x=line.split()
    if x[0]=='J':op,p=int(x[2]),int(x[4])
    if x[0]=='D':
        groups[op,p].append(int(x[-1]))
        if op==2 and int(x[4])==1:valid[p].append(int(x[-1]))
assert [sum(len(v) for k,v in groups.items() if k[0]==op) for op in range(3)]==[75,90,45]
assert sum(map(len,valid.values()))==9
rows=[]
for op in range(3):
    for p,level in enumerate((2,3,5)):
        cycles=mean(valid[p] if op==2 else groups[op,p])
        name=('KeyGen','Sign mean','Verify valid')[op];old=prior[name,level]
        rate=f*1e6/cycles
        rows.append(dict(operation=name,level=level,cycles=cycles,cycle_delta_vs_C18R1=cycles-old['cycles'],latency_us=cycles/f,operations_per_second=rate,rate_gain_vs_C18R1_pct=100*(rate/old['operations_per_second']-1)))
result=dict(worst_fmax_mhz=f,reported_period_ns=1000/f,fmax_gain_vs_C18R1_pct=100*(f/62.18-1),rows=rows)
(h/'reference_build/stage7c20_throughput.json').write_text(json.dumps(result,indent=2)+'\n')
print('|Operation|Level|Mean cycles|Estimated latency us|Estimated operations/s|')
print('|---|---:|---:|---:|---:|')
for r in rows:print(f'|{r["operation"]}|{r["level"]}|{r["cycles"]:.2f}|{r["latency_us"]:.1f}|{r["operations_per_second"]:.1f}|')
print('C20_THROUGHPUT_CALC_PASS:per-operation cycle penalties AND actual Fmax used;sequential estimates,not board measurements or initiation interval')
