from pathlib import Path
import json,re
h=Path('sim/dilithium');q=Path('quartus/dilithium')
metrics=json.loads((h/'reference_build/stage7c20_metrics.json').read_text())
old=json.loads((h/'reference_build/stage7c18r1_area_inventory.json').read_text())
def number(s):return float(re.match(r'[\d,.]+',s)[0].replace(',',''))
new=[]
for line in (q/'output_full/dilithium_full.fit.rpt').read_text().splitlines():
    c=[v.strip() for v in line.split(';')[1:-1]]
    if len(c)!=17 or not c[14].startswith('|dilithium_fpga'):continue
    new.append(dict(path=c[14],entity=c[15],placed=number(c[2]),own_placed=number(c[2].split('(')[1]),regs=number(c[7]),own_regs=number(c[7].split('(')[1]),aluts=number(c[6]),bram=c[10],dsp=c[11]))
assert len(new)>20,'Missing final placement hierarchy'
before={v['path']:v for v in old};report=[]
targets={'lighthd_hash_sampler','lighthd_keygen','lighthd_sign','lighthd_verify','lighthd_ntt_dma','lighthd_process_dma','lighthd_memory_router','lighthd_memory_port'}
for v in new:
    if v['entity'] in targets:
        a=before[v['path']];report.append(dict(path=v['path'],entity=v['entity'],C18R1_placed=a['placed'],C20_placed=v['placed'],delta=round(v['placed']-a['placed'],1),old_regs=a['regs'],new_regs=v['regs']))
assert metrics['area']['placed_ALMs']>=number(str(new[0]['placed']))-10,'Wrong hierarchy scope'
(h/'reference_build/stage7c20_area_inventory.json').write_text(json.dumps(new,indent=2)+'\n')
(h/'reference_build/stage7c20_area_delta.json').write_text(json.dumps(report,indent=2)+'\n')
print('SIBLING_SCOPE_AREA_DELTAS: inclusive attribution,do not add nested descendants')
for v in report:print(json.dumps(v))
print('ACTUAL_WHOLE_PLACED_ALMS',metrics['area']['placed_ALMs'],'STRICT_TARGET_MET',metrics['area']['placed_ALMs']<20000)
