from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c18r1_source_hashes.json').read_text());new=json.loads((rb/'stage7c20_source_hashes.json').read_text())
names=['src/controller/process/'+n+'.sv' for n in ('lighthd_process','cnb','mhint','power2round')]
names+=['tb/tb_dilithium/'+n+'.sv' for n in ('tb_lighthd_process_payload','lighthd_process_c17_reference','tb_lighthd_process_ranges','lighthd_cnb_c15_reference','lighthd_mhint_c15_reference')]
names+=['src/controller/helpers/lighthd_pkg.sv']
for n in names:assert old[n]==new[n]==hashlib.sha256((r/n).read_bytes()).hexdigest(),n
p=rb/'stage7c20_baseline_c18r1/stage7c18r1_foundation.log';b=p.read_bytes();s=b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8',errors='replace')
for marker in ('accepted29339358 checked29339355','LIGHTHD_DECOMPOSE_CANONICAL_DOMAIN_PASS:level0','LIGHTHD_DECOMPOSE_CANONICAL_DOMAIN_PASS:level1','LIGHTHD_DECOMPOSE_CANONICAL_DOMAIN_PASS:level2','norm134217728'):
 assert marker in s,marker
print('C20_UNIT_DOMAIN_PROOF_REUSE_PASS:10 exact RTL/ref/bench/package files;C18R1 exhaustive arithmetic evidence retained,not relabelled as a fresh C20 execution')
