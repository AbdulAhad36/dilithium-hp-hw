from pathlib import Path
import re,json
r=Path.cwd();q=r/'quartus/dilithium/critical_full'
names=(q/'mapped_register_names.rpt').read_text().splitlines()
process=[n for n in names if '|lighthd_process:process_unit|' in n]
assert 500<=len(process)<=624,len(process)
assert not any(re.search(r'\|(coefficient[01]_r|coarse_r|high[12]_r|low2_r|hint[012]_r|level[012]_r)',n) for n in process)
digest=[n for n in names if re.search(r'\|lighthd_verify:verify_controller\|(mu_r|digest_r)\[',n)]
assert len(digest)==512,len(digest)
result=dict(Process_original_mapped_bits=len(process),Verify_shared_digest_bits=len(digest),process_names=process,digest_names=digest)
(r/'sim/dilithium/reference_build/stage7c20_lifetime_registers.json').write_text(json.dumps(result,indent=2)+'\n')
print(f'C20_LIFETIME_HARDWARE_GUARD_PASS:Process{len(process)} original bits/no parallel scratch;Verify512 shared Mu/digest bits')
