// Three clients (NTT,sampling,Process/controller) share eight physical lanes.
// Only16 ownership bits are retained. No polynomial allocation/tag database.
// Commands reserve a selected set atomically per A/B port;other banks keep
// running independently. Owners retire on the real memory-done handshake.
`default_nettype none
module lighthd_memory_router (
  input wire logic clk,rst,
  input wire logic [2:0][1:0] client_command_valid_i,
  output logic [2:0][1:0] client_command_ready_o,
  input wire logic [2:0][1:0][3:0] client_command_mask_i,client_command_write_i,
  input wire logic [2:0][1:0][3:0][9:0] client_command_base_i,
  input wire logic [2:0][1:0][3:0][10:0] client_command_words_i,
  input wire logic [2:0][1:0][3:0][1:0] client_command_mode_i,
  input wire logic [2:0][1:0][3:0] client_write_valid_i,
  output logic [2:0][1:0][3:0] client_write_ready_o,
  input wire logic [2:0][1:0][3:0][91:0] client_write_data_i,
  input wire logic [2:0][1:0][3:0][9:0] client_write_address_i,
  output logic [2:0][1:0][3:0] client_read_valid_o,
  input wire logic [2:0][1:0][3:0] client_read_ready_i,
  output logic [2:0][1:0][3:0][91:0] client_read_data_o,
  output logic [2:0][1:0][3:0][9:0] client_read_address_o,
  output logic [2:0][1:0][3:0] client_read_last_o,client_done_valid_o,client_done_error_o,
  input wire logic [2:0][1:0][3:0] client_done_ready_i,
  output logic [1:0] memory_command_valid_o,input wire logic [1:0] memory_command_ready_i,
  output logic [1:0][3:0] memory_command_mask_o,memory_command_write_o,
  output logic [1:0][3:0][9:0] memory_command_base_o,
  output logic [1:0][3:0][10:0] memory_command_words_o,
  output logic [1:0][3:0][1:0] memory_command_mode_o,
  output logic [1:0][3:0] memory_write_valid_o,input wire logic [1:0][3:0] memory_write_ready_i,
  output logic [1:0][3:0][91:0] memory_write_data_o,
  output logic [1:0][3:0][9:0] memory_write_address_o,
  input wire logic [1:0][3:0] memory_read_valid_i,
  output logic [1:0][3:0] memory_read_ready_o,
  input wire logic [1:0][3:0][91:0] memory_read_data_i,
  input wire logic [1:0][3:0][9:0] memory_read_address_i,
  input wire logic [1:0][3:0] memory_read_last_i,memory_done_valid_i,memory_done_error_i,
  output logic [1:0][3:0] memory_done_ready_o
);
  logic [1:0][3:0][1:0] owner_r;
  logic [1:0][1:0] turn_r,selected;
  logic [1:0][3:0] effective_mask;
  always_comb begin
    client_command_ready_o=0;client_write_ready_o=0;client_read_valid_o=0;
    client_read_data_o=0;client_read_address_o=0;client_read_last_o=0;
    client_done_valid_o=0;client_done_error_o=0;
    memory_command_valid_o=0;memory_command_mask_o=0;memory_command_write_o=0;
    memory_command_base_o=0;memory_command_words_o=0;memory_command_mode_o=0;
    memory_write_valid_o=0;memory_write_data_o=0;memory_write_address_o=0;memory_read_ready_o=0;memory_done_ready_o=0;
    selected='1;effective_mask=0;
    for(int p=0;p<2;p++)begin
      for(int offset=0;offset<3;offset++)begin
        int c;logic available;logic [3:0] mask;
        c=int'(turn_r[p])+offset;if(c>=3)c-=3;
        mask=client_command_mask_i[c][p]==0?4'b1:client_command_mask_i[c][p];
        available=!rst;
        for(int b=0;b<4;b++)if(mask[b] && owner_r[p][b]!=3 &&
          !(owner_r[p][b]==c && memory_done_valid_i[p][b] && client_done_ready_i[c][p][b]))available=0;
        if(selected[p]==3 && client_command_valid_i[c][p] && available)begin
          selected[p]=2'(c);effective_mask[p]=mask;
          memory_command_valid_o[p]=1;memory_command_mask_o[p]=client_command_mask_i[c][p];
          memory_command_write_o[p]=client_command_write_i[c][p];
          memory_command_base_o[p]=client_command_base_i[c][p];
          memory_command_words_o[p]=client_command_words_i[c][p];
          memory_command_mode_o[p]=client_command_mode_i[c][p];
          client_command_ready_o[c][p]=memory_command_ready_i[p];
        end
      end
      for(int b=0;b<4;b++)if(!rst && owner_r[p][b]!=3)begin
        memory_write_valid_o[p][b]=client_write_valid_i[owner_r[p][b]][p][b];
        memory_write_data_o[p][b]=client_write_data_i[owner_r[p][b]][p][b];
        memory_write_address_o[p][b]=client_write_address_i[owner_r[p][b]][p][b];
        memory_read_ready_o[p][b]=client_read_ready_i[owner_r[p][b]][p][b];
        memory_done_ready_o[p][b]=client_done_ready_i[owner_r[p][b]][p][b];
        client_write_ready_o[owner_r[p][b]][p][b]=memory_write_ready_i[p][b];
        client_read_valid_o[owner_r[p][b]][p][b]=memory_read_valid_i[p][b];
        client_read_data_o[owner_r[p][b]][p][b]=memory_read_data_i[p][b];
        client_read_address_o[owner_r[p][b]][p][b]=memory_read_address_i[p][b];
        client_read_last_o[owner_r[p][b]][p][b]=memory_read_last_i[p][b];
        client_done_valid_o[owner_r[p][b]][p][b]=memory_done_valid_i[p][b];
        client_done_error_o[owner_r[p][b]][p][b]=memory_done_error_i[p][b];
      end
    end
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin owner_r<='1;turn_r<=0;end
    else for(int p=0;p<2;p++)begin
      for(int b=0;b<4;b++)begin
        if(memory_done_valid_i[p][b] && memory_done_ready_o[p][b])owner_r[p][b]<=3;
        if(memory_command_valid_o[p] && memory_command_ready_i[p] && effective_mask[p][b])owner_r[p][b]<=selected[p];
      end
      if(memory_command_valid_o[p] && memory_command_ready_i[p])turn_r[p]<=selected[p]==2?2'd0:selected[p]+1'b1;
    end
  end
endmodule
`default_nettype wire
