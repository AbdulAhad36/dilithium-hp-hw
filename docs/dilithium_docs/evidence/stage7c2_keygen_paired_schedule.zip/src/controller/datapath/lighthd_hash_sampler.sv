// The accepted physical dual Keccak/sampler with direct Figure5/B-port writes.
// Final FIPS absorption messages arrive on the existing64-bit stream. Finite
// raw hashes share those SAME two cores;no private KeyGen/Sign/Verify hash.
`default_nettype none
module lighthd_hash_sampler (
  input wire logic clk,rst,job_valid_i,output logic job_ready_o,job_core_o,
  input wire logic job_batch_last_i,input wire logic [1:0] job_mode_i,job_param_i,job_bank_i,
  input wire logic [9:0] job_base_i,input wire logic [15:0] job_id_i,message_len_i,
  input wire logic [63:0] input_data_i,input wire logic input_valid_i,output logic input_ready_o,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic done_core_o,output logic [15:0] done_id_o,output logic [2:0] done_code_o,
  output logic fault_o,output logic [1:0] active_o,
  input wire logic raw_valid_i,output logic raw_ready_o,raw_core_o,
  input wire logic raw_mode_i,input wire logic [15:0] raw_id_i,raw_message_len_i,raw_output_len_i,
  input wire logic [63:0] raw_input_data_i,input wire logic raw_input_valid_i,output logic raw_input_ready_o,
  output logic raw_output_valid_o,raw_output_core_o,output logic [15:0] raw_output_id_o,
  output logic [127:0] raw_output_data_o,output logic [4:0] raw_output_bytes_o,input wire logic raw_output_ready_i,
  output logic raw_done_valid_o,raw_done_core_o,output logic [15:0] raw_done_id_o,input wire logic raw_done_ready_i,
  output logic [1:0] memory_command_valid_o,input wire logic [1:0] memory_command_ready_i,
  output logic [1:0][3:0] memory_command_mask_o,memory_command_write_o,
  output logic [1:0][3:0][9:0] memory_command_base_o,
  output logic [1:0][3:0][10:0] memory_command_words_o,
  output logic [1:0][3:0][1:0] memory_command_mode_o,
  output logic [1:0][3:0] memory_write_valid_o,input wire logic [1:0][3:0] memory_write_ready_i,
  output logic [1:0][3:0][91:0] memory_write_data_o,
  output logic [1:0][3:0][9:0] memory_write_address_o,
  input wire logic [1:0][3:0] memory_done_valid_i,memory_done_error_i,
  output logic [1:0][3:0] memory_done_ready_o
);
  logic hash_job_ready,writer_job_ready,hash_job_valid,writer_done_valid,writer_done_ready;
  logic packet_valid,packet_ready,packet_core,packet_last;
  logic [15:0] packet_id;logic [7:0] packet_index;logic [91:0] packet_data;logic [4:0] packet_count;
  logic status_valid,status_core,status_ready,writer_done_core;
  logic [15:0] status_id,writer_done_id;logic [2:0] status_code,writer_done_code;
  logic bad_job,bad_pending_r;logic [15:0] bad_id_r;
  assign bad_job=job_param_i==3 || job_base_i[5:0]!=0;
  assign hash_job_valid=!bad_job && !bad_pending_r && !fault_o && job_valid_i && writer_job_ready;
  assign job_ready_o=!rst && !fault_o && !bad_pending_r && (bad_job || (hash_job_ready && writer_job_ready));
  assign done_valid_o=bad_pending_r || writer_done_valid;
  assign done_id_o=bad_pending_r?bad_id_r:writer_done_id;
  assign done_core_o=bad_pending_r?1'b0:writer_done_core;
  assign done_code_o=bad_pending_r?3'd3:writer_done_code;
  assign writer_done_ready=done_ready_i && !bad_pending_r;
  keccak_sampler #(.RAW_SERVICE(1),.BANK_IO(1)) engine(
    .clk(clk),.rst(rst),.job_valid_i(hash_job_valid),.job_ready_o(hash_job_ready),.job_core_o(job_core_o),
    .job_id_i(job_id_i),.message_len_i(message_len_i),.job_mode_i(job_mode_i),.job_param_i(job_param_i),
    .input_data_i(input_data_i),.input_valid_i(input_valid_i),.input_ready_o(input_ready_o),
    .output_data_o(),.output_core_o(packet_core),.output_last_o(packet_last),.output_valid_o(packet_valid),
    .output_id_o(packet_id),.output_index_o(packet_index),.output_ready_i(packet_ready),
    .status_valid_o(status_valid),.status_core_o(status_core),.status_id_o(status_id),.status_code_o(status_code),
    .status_ready_i(status_ready),.active_o(),.output_bank_data_o(packet_data),.output_bank_count_o(packet_count),
    .raw_valid_i(raw_valid_i),.raw_ready_o(raw_ready_o),.raw_core_o(raw_core_o),.raw_mode_i(raw_mode_i),
    .raw_id_i(raw_id_i),.raw_message_len_i(raw_message_len_i),.raw_output_len_i(raw_output_len_i),
    .raw_input_data_i(raw_input_data_i),.raw_input_valid_i(raw_input_valid_i),.raw_input_ready_o(raw_input_ready_o),
    .raw_output_valid_o(raw_output_valid_o),.raw_output_core_o(raw_output_core_o),.raw_output_id_o(raw_output_id_o),
    .raw_output_data_o(raw_output_data_o),.raw_output_bytes_o(raw_output_bytes_o),.raw_output_ready_i(raw_output_ready_i),
    .raw_done_valid_o(raw_done_valid_o),.raw_done_core_o(raw_done_core_o),.raw_done_id_o(raw_done_id_o),.raw_done_ready_i(raw_done_ready_i));
  lighthd_sampler_writer writer(
    .clk(clk),.rst(rst),.job_valid_i(hash_job_valid && hash_job_ready),.job_ready_o(writer_job_ready),
    .job_core_i(job_core_o),.job_batch_last_i(job_batch_last_i),.job_mode_i(job_mode_i),
    .job_bank_i(job_bank_i),.job_base_i(job_base_i),.job_id_i(job_id_i),
    .packet_valid_i(packet_valid),.packet_ready_o(packet_ready),.packet_core_i(packet_core),
    .packet_last_i(packet_last),.packet_id_i(packet_id),.packet_index_i(packet_index),.packet_data_i(packet_data),.packet_count_i(packet_count),
    .status_valid_i(status_valid),.status_core_i(status_core),.status_id_i(status_id),.status_code_i(status_code),.status_ready_o(status_ready),
    .done_valid_o(writer_done_valid),.done_ready_i(writer_done_ready),.done_core_o(writer_done_core),.done_id_o(writer_done_id),
    .done_code_o(writer_done_code),.fault_o(fault_o),.active_o(active_o),
    .memory_command_valid_o(memory_command_valid_o),.memory_command_ready_i(memory_command_ready_i),
    .memory_command_mask_o(memory_command_mask_o),.memory_command_write_o(memory_command_write_o),
    .memory_command_base_o(memory_command_base_o),.memory_command_words_o(memory_command_words_o),.memory_command_mode_o(memory_command_mode_o),
    .memory_write_valid_o(memory_write_valid_o),.memory_write_ready_i(memory_write_ready_i),.memory_write_data_o(memory_write_data_o),.memory_write_address_o(memory_write_address_o),
    .memory_done_valid_i(memory_done_valid_i),.memory_done_error_i(memory_done_error_i),.memory_done_ready_o(memory_done_ready_o));
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin bad_pending_r<=0;bad_id_r<=0;end
    else begin
      if(job_valid_i && job_ready_o && bad_job)begin bad_pending_r<=1;bad_id_r<=job_id_i;end
      if(bad_pending_r && done_ready_i)bad_pending_r<=0;
    end
  end
endmodule
`default_nettype wire
