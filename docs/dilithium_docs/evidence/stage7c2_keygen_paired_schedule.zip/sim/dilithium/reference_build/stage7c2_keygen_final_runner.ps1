Set-Location -LiteralPath 'D:/GitHub/dilithium-hp-hw'
'START final protocol20 then official75 compact KeyGen' | Set-Content sim/dilithium/stage7c2_keygen_final_status.log
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l sim/dilithium/stage7c2_keygen_protocol.log -do sim/dilithium/reference_build/stage7c2_keygen_protocol.do *> sim/dilithium/stage7c2_keygen_protocol_console.log
if($LASTEXITCODE -ne 0){'FAIL protocol simulation' | Add-Content sim/dilithium/stage7c2_keygen_final_status.log;exit 1}
& python sim/dilithium/dilithium_vectors.py lighthd_keygen_protocol_compare *> sim/dilithium/stage7c2_keygen_protocol_compare.log
if($LASTEXITCODE -ne 0){'FAIL protocol compare' | Add-Content sim/dilithium/stage7c2_keygen_final_status.log;exit 1}
'PASS protocol20;START full75' | Add-Content sim/dilithium/stage7c2_keygen_final_status.log
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l sim/dilithium/stage7c2_keygen_full.log -do sim/dilithium/reference_build/stage7c2_keygen_full.do *> sim/dilithium/stage7c2_keygen_full_console.log
if($LASTEXITCODE -ne 0){'FAIL full simulation' | Add-Content sim/dilithium/stage7c2_keygen_final_status.log;exit 1}
& python sim/dilithium/dilithium_vectors.py lighthd_keygen_compare *> sim/dilithium/stage7c2_keygen_compare.log
if($LASTEXITCODE -ne 0){'FAIL full compare' | Add-Content sim/dilithium/stage7c2_keygen_final_status.log;exit 1}
& python sim/dilithium/dilithium_vectors.py lighthd_keygen_selftest *> sim/dilithium/stage7c2_keygen_checker.log
if($LASTEXITCODE -ne 0){'FAIL checker selftest' | Add-Content sim/dilithium/stage7c2_keygen_final_status.log;exit 1}
'COMPLETE protocol20/full75/checker25' | Add-Content sim/dilithium/stage7c2_keygen_final_status.log
