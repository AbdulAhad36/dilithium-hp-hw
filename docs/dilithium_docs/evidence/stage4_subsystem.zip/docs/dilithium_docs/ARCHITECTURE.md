# Dilithium architecture

## Current implemented boundary:Stage4

```text
messages/jobs -> keccak_sampler_ntt
                    | producer (unchanged Keccak + sampler)
                    v
                 four-slot memory <--- NTT result writeback
                    |    ^                     ^
                    |    | compute reservation  |
                    v    | / source locks      |
                 sequential DMA ------------> ntt_engine
                    |                         NTT/INTT/PWM/Pre
                    +--> public readback when idle
```

The new helper arbitrates sampling commands,compute commands and public reads.
Accepted compute descriptors latch both slot/expected-ID pairs,opcode and new
result ID. Memory checks eligibility,locks sources and chooses a free separate
destination. The DMA serially loads256 A values and,for PWM,256 B values.
The unchanged NTT emits256 results into that destination. Engine completion
precedes publication and the held ready/valid completion reply.

Compute has priority over a new sampling command/public read request;an old
read response drains before command acceptance. Sampling is not overlapped
with compute in this first implementation. Source release is refused while
locked;an unrelated completed slot may be released while destination reservation
is waiting for capacity. The source data remains intact after completion.

Domain/Pre/parameter/ID checks are hardware checks,not assumptions based solely
on the testbench. SPECIFICATION.md and MEMORY_MAP.md define them. This top
does not implement seed/nonce assembly,full polynomial schedules or full
KeyGen/Sign/Verify. Whole-system PPA optimization remains deferred.

## Preserved Stage3 producer/storage boundary

The approved four-slot memory now receives real sampled polynomials:

```text
commands/messages -> keccak_sampler_memory
                         | atomic job + slot allocation
                         v
                    keccak_sampler
                    Keccak -> sampler
                         | tagged coefficient stream
                         v
                    memory.sv (4 x256 x23)
                         | synchronous ready/valid reads
                         v
                  testbench;NTT consumer follows
```

Allocation and producer-command acceptance share one handshake. The actual
assigned core,job ID,mode and parameter bind to the slot. Status retirement and
memory commit share another handshake. The producer cannot accept a job when
the pool is full. Completed slots survive context reuse until explicit release.
Reads and writes use separate logical ports;payload RAM is not bulk-reset.
MEMORY_MAP.md defines publication,invalidation,release conflicts and fault handling.

The synthesis project now selects keccak_sampler_ntt;Stage4 source checking
passes. Existing Stage2 fitted metrics do not include memory or the NTT.

## Preserved Stage2 producer boundary

```text
Job descriptor + complete absorption message
             |                     64-bit ready/valid
             v                            |
  controller/keccak_sampler.sv            v
     ownership/atomic start --> dual Keccak cores
             |                            |
             |               shared128-bit data/bytes/core
             |                            v
             |                 two-slot credit bridge
             |                            |
             +-- matching context --> sampler
                                          |
                         tagged23-bit coefficients + status
                                          |
                              external sink (testbench)
```

This helper will be controlled by the future `src/controller/dilithium.sv`.
No main algorithm controller,NTT connection or complete KeyGen/Sign/Verify
implementation is present yet. Sampler RTL remains unchanged. The Stage2
producer's external sink is memory when instantiated by the Stage3 wrapper.
The Keccak wrapper has a registered offset-ready decode,and each core has a
registered absorb-ready decode without changing its processing cycles.
The user selected an initial combined target of about148MHz;the
Quartus project uses6.757ns and is not silently relaxed to close timing.
On2026-10-20 the user deferred PPA optimization until full-operation outputs
are correct. Timing closure does not block the next memory integration step.

## Command and context ownership

`job_valid_i && job_ready_o` atomically starts Keccak and sampler for the core
actually assigned by Keccak. The descriptor contains job ID,sampling mode,
parameter encoding,and the absorption-message byte count. The source supplies
those message bytes on the shared64-bit ready/valid port. Seed/nonce assembly
is external at this stage;the adapter does not implement full algorithm encoding.

Mode0 explicitly selects SHAKE128;all other sampling modes select SHAKE256.
The decode uses a dedicated scalar wire. Quartus treated the original
package-qualified constant in a port expression as an implicit net despite
Questa accepting it. That build was stopped and excluded;the current adapter
uses explicit net declarations and `default_nettype none`.

Two ownership bits keep a descriptor live until the external status handshake.
Sampler activity always implies ownership:reset clears both,accepted commands
set both,and ownership releases only on the sampler's external status handshake.
Thus !owned already guarantees sampler-ready for a new command. The helper
does not feed the redundant sampler_job_ready mux back into Keccak start;
source assertions check this invariant and readiness at every accepted command.
An idle Keccak core cannot be reused while its old sampler job/status still owns
it. The inherited Keccak dispatch preference can cause head-of-line command
waiting when its chosen idle core is still owned;this baseline favors simple
ownership over new dispatch scheduling. Performance optimization follows later.

## Bridge and backpressure

Two shared slots store128 data bits,a5-bit byte count and a core tag each.
Registered occupancy and read/write pointers own the slots. Required data is
forwarded in order;the existing sampler handles64-bit chunks internally. A push
and pop can occur on the same edge. Hash ready uses registered free space or
registered drain state;sampler ready/source_stop no longer propagate through
the bridge into Keccak's same-cycle output-ready logic. A full queue may stall
the peer stream. This is a small register queue,not polynomial memory.

Sampler `source_stop` explicitly cancels surplus unaccepted sampler-input offers.
Such offers belong to the old job and must not enter its replacement. This is a
documented internal cancellation boundary;ordinary public coefficient/status
offers remain stable under backpressure until accepted or reset.

## Drain,stop and completion

The adapter never wires sampler stop directly to Keccak stop:

1. The sampler requests stop after successful generation or an error.
2. The adapter marks that context draining and cancels its surplus bridge beat.
3. It accepts/discards a further offered SHAKE beat for that context. This
   handshake releases the shared Keccak output lock,even under downstream stalls.
4. It registers Keccak stop AFTER that handshake and holds stop through any
   intervening permutation until the core returns idle.
5. It exposes the sampler's status only when that core is idle and neither queue slot has a
   token from the job. Status acceptance releases ownership.

The peer context is retained throughout. The selected sampler status may wait
for its hash core,so another status can experience head-of-line waiting. Arbitrary
permanent sink stalls or missing declared message bytes cannot guarantee progress.
The producer must send the declared message;coordinated reset cancels a job that
cannot finish absorption. This stage has no independent per-job cancel command.

Continuous SHAKE uses `output_len_i=0`;sampler input_last is0. Bounded-XOF
exhaustion/refill is outside this stage's interface and is not simulated by
calling a rate-block boundary the end of a polynomial.

## Reset and validation hooks

One shared clock is used. Hold active-high reset through rising edges so both
the asynchronous Keccak controls and synchronous sampler controls reset.
Ownership,bridge valid and stop/drain state cancel together. The focused test
then reuses job IDs with different messages to expose stale-state leakage.

Source assertions reject unowned hash/bridge tokens,premature reuse and invalid
hash byte counts. The testbench additionally checks stable coefficient/status/
Keccak offers and proves every stop rise follows a discarded release handshake.
The combined TimeQuest helper checks the original accepted sampler payload and
reservation register counts with hierarchy-qualified patterns. These checks
complement tests;they are not formal proof or full security signoff.

## Historical Stage2 timing work (further optimization deferred)

The initial routed critical path ends at a shared Keccak1600-bit state enable.
Rejected timing trial2 qualified absorption writes by64-bit destination lane. Absorbing
one word XORs data into one lane;the absorb unit returns the previous value
for every other lane,so leaving those registers untouched preserves the state.
Padding and permutation still write the whole state on their original edges.
That change passed correctness but worsened routed timing and area,so it was
rejected. Trial3 dedicated global enable routing also worsened timing and was
rejected. Trial4 restores exact initial RTL and uses a local synthesis
assignment to implement only the two state arrays' hold behavior through data
feedback muxes instead of register clock-enable ports. Trial5 additionally
registers the launch-offset-zero flag while preserving the exact countdown and
launch interval;the source checks its equality to the counter. Trial6
adds the two-slot queue described above. External interfaces and the engines'
processing stages remain unchanged;queueing latency under stalls can change.
Standalone sampler RTL is unchanged. Active trial7 restores ordinary clock-enable
mapping and predecodes absorb-ready in each core to shorten the wide write control.
Trial8 additionally removes a redundant sampler-ready condition from command
launch;ownership and source assertions enforce atomic acceptance. This is the
current verified functional source. Its main fit is137.74MHz with-0.503ns setup;
structural guards pass. See THROUGHPUT.md for historical trial results.
