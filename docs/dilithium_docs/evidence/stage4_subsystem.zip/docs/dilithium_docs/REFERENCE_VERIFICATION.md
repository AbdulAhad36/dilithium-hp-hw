# Dilithium reference verification

## Current scope

Stage4 now checks real Keccak -> sampling -> memory -> NTT -> memory. It uses
the same Python script and locally generated subsystem vectors;these are not
official full-operation Dilithium/ML-DSA vectors. Main default commands:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,from sim/
set DILITHIUM_STAGE 4
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 4
python sim/dilithium/dilithium_vectors.py selftest --stage 4
```

Preparation writes the shared sampling files and stage4_expected.txt with26
arithmetic polynomials. Python imports the unchanged mathematical functions in
FIPS204_NTT/ntt_vectors.py. Direct polynomial evaluation/inverse evaluation
provide transform expectations;independent schoolbook multiplication checks
the Matrix A/secret product chain. The SV test does not generate expected
NTT values using the DUT or a mirrored RTL function.

stage4_outputs.txt records J/W/S sampling lifecycle,O(compute descriptor),
V(reservation decision/destination),T(each DMA value with source slot/ID/index),
K(each NTT output/index/last),D(public completion),B(reset abort),R(stored
readback including domain),E(rejected read),L(release),X(reset) andF(totals).
The separate Python checker maintains slot ownership and source locks,
derives eligibility from actual expected values,checks every transfer and
all metadata,and requires exact lifecycle/totals. It computes each operation
again from the expected source polynomials;captured RTL values are never
used as the golden input to later expected arithmetic.

PASS:16 sampled jobs,50 commands,30 successes,17 rejects,3 reset aborts;
4096 sampled values,9745 DMA values,7713 result values and11776 stored reads.
Result arithmetic:30*256=7680 completed values plus33 accepted before reset.
All16 source polynomials and30 completed results are read in full:46*256=11776.
The three aborted destinations never publish complete results. Reset also
invalidates their source slots;43 explicit releases and6 invalid reads pass.
12 checker corruptions cover output,DMA value/ID,stored value/domain,source ID,
reservation/completion,missing output/commit,stale token and extra read.
Logs:stage4.log,stage4_compare.log,stage4_checker_selftest.log.

Relocated standalone NTT source UVM passes748 jobs/191488 values;18 original
standalone Python cases/4608 values match. Logs under sim/ntt/import_* identify
this relocation separately from historical branch evidence. No fresh standalone
or integrated synthesis/netlist run was made in this functionality-first stage.
Create-only evidence/stage4_subsystem.zip and stage4_subsystem.sha256 preserve
the imported module package,current integration source/reference/tests,
prepared projects,source captures/verdicts and universal docs. MANIFEST.csv
hashes each member;RESULT.txt states functional scope and unrun PPA/netlist work.

## Preserved Stage3 scope and commands

Stage3 extends the same one-script flow to real sampled polynomial storage.
Select DILITHIUM_STAGE=3 to run tb_keccak_sampler_memory. Inputs and expected
polynomials remain stage2_inputs.txt/stage2_expected.txt for both stages;these
names preserve the original generated format. Stage3 writes a distinct
stage3_outputs.txt with slot lifecycle and stored readbacks.

Current commands after `prepare`,from the Questa GUI Transcript in sim/:

```tcl
set DILITHIUM_STAGE 3
do dilithium/run.do
```

Then from the repository root:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 3
python sim/dilithium/dilithium_vectors.py selftest --stage 3
```

Require DILITHIUM_STAGE3_CAPTURE_PASS,MEMORY_PROTOCOL_PASS and the independent
DILITHIUM STAGE3 COMPARE PASS.104 jobs pass:88 complete,8 expected errors,
8 aborts;23180 exact writes (22528 complete+652 aborted-prefix values),22528
exact stored readbacks,88 releases,99 invalid reads and5 integrated resets.
All24 successful mode/parameter/actual-core combinations are present.
The three-slot fault companion separately proves8 protocol-fault cases,bounds,
pipelined read responses and reset of a stalled successful response.

Stage3 capture records:J(case,core,slot,ID),W(case,core,index,value,last),
S(case,core,status),A(case,core,prefix count),R(case,slot,index,value,ID,mode,
parameter,domain),E(slot,index rejected),L(slot release),X(reset),F(totals).
Python maintains its own slot/live-job model;it checks allocation,publication,
every write/read,release/reset and exact totals against the independent golden
polynomials.12 deliberate corruptions cover data,slot,index,ID,mode,parameter,
domain,missing read,duplicate job,missing commit,stale token and extra read.
All are rejected. stage3.log,stage3_compare.log and stage3_checker_selftest.log
record the verdicts. No official full-operation vectors or full UVM claim.
The create-only evidence/stage3_subsystem.zip and stage3_subsystem.sha256
preserve current RTL,testbenches,independent script,vectors,captures,logs,
universal docs and prepared Quartus files. MANIFEST.csv lists each member's
SHA256. RESULT.txt distinguishes source verification from unrun Stage3 synthesis.

## Preserved Stage2 flow

Stage2 checks the real SHAKE-to-sampling connection. The vectors are generated
locally;they are not official full-operation NIST vectors. The absorbed messages
include deterministic seeded bytes and arbitrary boundary lengths. This does
not validate full KeyGen/Sign/Verify seed expansion,encoding or signing randomness.

One script,`sim/dilithium/dilithium_vectors.py`,provides prepare/check/compare and
checker self-test. It uses Python hashlib SHAKE128/SHAKE256 and the unchanged
independent scalar sampler reference in `FIPS204_SAMPLER/sampler_vectors.py`.
No RTL function or SV golden result is used to generate the expected polynomial.

## Simple flow and commands

```text
Python messages -> SHAKE in hashlib -> independent sampling -> expected file
       |
       +-> input file -> real Keccak+sampler RTL -> captured output file
                                                      |
                          separate Python compare ----+-> PASS/FAIL
```

From repository root:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

From `sim/` in the Questa GUI Transcript:

```tcl
set DILITHIUM_STAGE 2
do dilithium/run.do
```

From repository root after capture:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 2
python sim/dilithium/dilithium_vectors.py selftest --stage 2
```

| File under sim/dilithium/ | Producer and meaning |
|---|---|
| stage2_inputs.txt | Python:case index,ID,mode,param,abort flag,byte length,message hex |
| stage2_expected.txt | Python:expected status/abort/count and canonical coefficients |
| stage2_outputs.txt | Simulator:J descriptor,C coefficient,S status,A abort,F totals |
| stage2.log | Saved headless Transcript;GUI displays its own Transcript |
| stage2_compare.log | Separate Python verdict |
| stage2_checker_selftest.log | Deliberate-corruption rejection verdict |
| stage2.wlf | Wave database;GUI launcher adds public and bridge/control waves |

The two input/golden files carry the same SHA256 token,bound to their contents,
reference and actual source/test/launcher files. The launcher checks freshness
before compilation;comparison recomputes it. Re-run prepare and capture after
source changes. Do not compare an old capture against a different token.

The simulator checks values/index/core/ID/last and status against the generated
golden file,plus independent protocol/ownership assertions. It requires an
explicit test_passed flag after all104 jobs. A fatal or watchdog without that
flag makes the launcher fail. The separate Python checker verifies all records
and exact totals again;process exit alone is not a passing result.

## Measured source results

104 accepted jobs:88 complete polynomials,8 expected invalid-parameter errors,
8 reset aborts. Current two-slot bridge:23089 coefficients match:22528 from88*256
complete polynomials plus561 accepted aborted-prefix coefficients. All24 combinations
of4 modes,3 valid parameters and2 contexts are observed in successful jobs.

Four reset targets reach both owned contexts:full blocked bridge,held Keccak output,
drain pending,and externally stalled status. Recovery reuses the same IDs with
different messages. All12 checker corruptions are rejected:value,index,core,
job ID,last,status,case,footer,missing coefficient,duplicate descriptor,extra
coefficient and stale token.

The queue reaches full occupancy for34198 observed cycles and simultaneous
push/pop128 times. Status checks both queued tags before retirement. The
initial one-slot workload checked23081 values;that historical capture remains
in evidence/stage2_subsystem_initial.zip. Changed abort timing explains the
different number of checked prefix values;all88 complete polynomials stay256
coefficients long. See THROUGHPUT.md for workload cycles and timing-trial status.

These are focused source tests. Full Dilithium UVM coverage,full-operation
official-vector checks,new integrated netlist simulation and FPGA testing remain
future stages. The standalone Keccak NIST suite is separately documented.
