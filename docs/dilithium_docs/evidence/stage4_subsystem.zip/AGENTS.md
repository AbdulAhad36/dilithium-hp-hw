# Agent onboarding - integration

## Active direction: functionality first (user decision 2026-10-20)

The user explicitly stopped timing optimization before memory. Integrate the
remaining blocks and establish correct full-operation outputs first; optimize
Fmax, actual placed ALMs and throughput afterward in Stage7. This supersedes
the earlier timing-first gate. Keep the 6.757 ns benchmark constraint; it is
not a requirement for starting Stage3. Do not start more timing experiments.

Branch: integration, created from sampler_v1 at e1b9c84. No commit or push
without explicit instruction. Announce each stage, ask about major architecture
decisions and report completed work with evidence and the next action.
Preserve accepted standalone source/evidence and existing uncommitted work.

Read docs/dilithium_docs/DILITHIUM_PLAN.md first. Integration == Dilithium:
one universal documentation suite under docs/dilithium_docs. RTL layout is
src/keccak, src/ntt, src/sampler, src/controller/process,
src/controller/memory.sv and src/controller/dilithium.sv. Import each accepted
module with its standalone UVM, sim, Quartus and docs assets when needed.
Focused non-UVM tests under tb/tb_dilithium are authorized during integration.
Full-operation reference checks precede comprehensive full-system UVM/PPA work.

Stage1 Keccak import from keccak_v2 fe54a78 is complete: 904 source UVM
transactions plus dual suites and 6364 published NIST output comparisons PASS.
Its immutable import archive preserves the original RTL and standalone PPA.
Current integration Keccak has subsequently verified control changes; do not
apply historical standalone PPA to the modified source.

Stage2 functional PASS. Current trial8 source has atomic ownership/command
binding, a two-slot registered-credit bridge and handshake-before-stop draining.
104 jobs: 88 complete, 8 expected errors, 8 reset aborts; 23089 exact coefficient
checks. All24 mode/parameter/context combinations and12 checker faults PASS.
The modified Keccak core also passes904 transactions plus dual suites and6364
NIST outputs. Sampler RTL is unchanged. Trial8 cycle rows match trial7.
Launcher:sim/dilithium/run.do; checker:sim/dilithium/dilithium_vectors.py.
No full-operation Dilithium/NIST/UVM or integrated netlist completion is claimed.

Historical Stage2 main seed1 fit:11293 PLACED ALMs,7557 registers,15970 ALUTs,
one M10K/1024bits,zero DSP;137.74MHz worst Fmax,setup-0.503ns/hold+0.157ns
at6.757ns. All original sampler/Keccak structural guards PASS. Timing is OPEN.
Main and isolated seed2 compiles have finished;seed2 is not selected.
Keep verified trial8 functional RTL; no new timing experiments before memory.
Initial evidence archive stage2_subsystem_initial.zip is immutable and describes
the earlier single-slot source,not current-source PPA.

Stage3 is complete for the focused functional gate. The user approved the
configurable four-slot pool on2026-10-20. memory.sv and keccak_sampler_memory.sv
implement it.104 jobs/88 complete/8 errors/8 aborts,23180 exact writes and22528
exact readbacks PASS;88 releases,99 rejected reads,8 pool-stall cycles,1321
read-stall cycles and170 concurrent read/write cycles.8 memory fault kinds
are contained;12 Python corruptions rejected. Stage2 freshly passes unchanged.
Commit requires256 writes plus successful matching external status acceptance.
Read data/metadata hold under stalls;release waits for pending responses;
reset invalidates metadata,not RAM. Sticky protocol faults require reset.
Read MEMORY_MAP.md for the full contract;Stage4 below adds the IN_USE leases.
Create-only evidence:docs/dilithium_docs/evidence/stage3_subsystem.zip and
stage3_subsystem.sha256;preserve them. The archive includes source/checker
manifests and captures;no Stage3 fitted PPA is claimed.
Stage4 is complete for its focused functional gate. Imported57 NTT package files
from ntt_v2:577a34b2fff19864cb16b490b7629ed211613000. Six RTL files and existing
UVM are byte-identical;ntt_import_manifest.csv records path adapters/provenance.
Locations:src/ntt,tb_uvm/tb_uvm_ntt_LightHD,sim/ntt,quartus/ntt,FIPS204_NTT,
docs/ntt_docs. No obsolete experiment tree or generated build database imported.
Relocated standalone UVM748 jobs/191488 values PASS;32 group type mean90.4731%,
raw code12990/14093=92.17%. Standalone Python18 cases/4608 values PASS.
These are NTT-only results,not integrated coverage or a fresh synthesis result.

New helper:keccak_sampler_ntt. Same four-slot pool now supports IN_USE locks,
separate result reservations and explicit domain/bounded-eligibility metadata.
Sequential sampling/compute;one outstanding DMA read. NTT uses canonical23-bit
residues and Dilithium ordering;INTT scales by1/256. Matrix A goes straight to
PWM. Pre checks all values represent[-4,4]. Invalid/stale source code1;domain/
parameter/Pre rejection code2;success0. Invalid commands never start the engine.
Compute source slots are protected even while waiting for a free destination;
only unrelated slots may be released then. Inputs are preserved;PWM aliasing
is allowed. Results publish only after256 writes and engine done. Faults halt
the helper until coordinated reset. Do not mistake mode metadata for domain.

Stage4 source/Python PASS:16 sampled jobs,50 commands,30 complete results,
17 rejects,3 reset aborts.4096 sampled values,9745 DMA values,7713 NTT outputs
(7680 complete+33 aborted-prefix values),11776 readbacks.43 releases,6 invalid
reads,4 resets. Witnesses:24 pool-wait cycles,188 completion-stall cycles,
699 read-stall cycles,33 source locks.12 checker corruptions rejected.
Reset targets:load17 values,coreRUN after256 loads,and writeback after32 outputs;
same IDs recover using different messages. Stage2/3 freshly revalidated.

Default sim/dilithium/run.do runs Stage4;set DILITHIUM_STAGE 2 or3 for old gates.
One Python prepare/check/compare/selftest script;--stage 2/3/4,default4.
Shared sampling files plus stage4_expected.txt with26 arithmetic expectations.
Quartus top is now keccak_sampler_ntt,294 virtual non-clock bits;6.757ns unchanged.
NO Stage4 synthesis/fit/netlist/PPA run. Old Stage2 reports are historical only.
Create-only Stage4 evidence:docs/dilithium_docs/evidence/stage4_subsystem.zip
and stage4_subsystem.sha256. Preserve all existing milestone archives unchanged.
NEXT:Stage5 exact algorithm/version/encoding audit,then level2 KeyGen schedule,
polynomial live ranges and controller/process blocks. Ask major decisions before
dependent implementation. Do not start PPA optimization or claim full Dilithium.
Keep native128 sampler processing deferred:input beats still issue64-bit chunks.

Scope:LightHD's full CRYSTALS-Dilithium KeyGen/Sign/Verify at levels2/3/5,
starting level2. Audit exact algorithm/version/encoding before selecting
full-operation official vectors;do not silently claim final FIPS204 ML-DSA
compatibility from LightHD's draft-standard citation.

The sampler history below is accepted standalone evidence. Its old instructions
restricting integration are superseded by the user's integration authorization.

## Accepted sampler baseline inherited from sampler_v1

User accepted Stage4.9r on2026-10-19. Main baseline:3537 actual placed ALMs,
164.74MHz worst Fmax,+0.430ns setup,+0.141ns hold at unchanged6.500ns.
3931 registers,4256 ALUTs,one M10K/1024bits,zero DSP. All4 corners0TNS.
Quartus seed1,HIGH PERFORMANCE EFFORT,physical register retiming OFF.
Original payload/sign/reservation structural guards pass. Area ALWAYS means
actual final-placement ALMs. Never use needed estimates for area claims.

Read README.md and docs/sampler_docs/post_midyear/SAMPLER_PLAN.md before work,
then SPECIFICATION.md,COVERAGE.md,THROUGHPUT.md,STAGE4_9R_RESULTS.json and the
user's docs/sampler_docs/LIGHTHD_SAMPLER.md and SAMPLER.md.
Main UVM621 complete/182 expected errors/51 aborts/159628 comparisons PASS;
functional1652/1721=95.99%,code15093/15799=95.53%. Python104/19456,C48/12288,
checker12,performance96 and five zero-credit fault gates PASS. Source checks
reuse byte-identical O after26 hashes;R has fresh fit/timing/structural evidence.
All96 performance rows match the preceding selected implementation.

Stage5 completed on2026-10-19 using DISTINCT current synthesis/fit netlists.
Each main-UVM run:184 jobs,156 complete,24 expected errors,4 reset aborts,
39936 checks,zero errors/fatals. All104-job source/synthesis/fit captures match
byte-for-byte and Python19456 values. Fresh source621/159628,P/C48/12288,
checker12 pass. Source functional95.99%,code95.53%;netlists1255/1721=72.92%,
source-only groups unsampled. Timing/structural refresh passes unchanged.
Read SAMPLER_NETLIST_RESULTS.json and evidence/sampler_stage5.zip. Preserve
both accepted R and Stage5 evidence. The96 performance CSV rows match accepted
archive;not rerun. CycloneV netlists are functional only;TimeQuest is timing.
Next Stage6 requires separate integration-branch/import authorization. Do not
start integration,change branches,import modules or commit without instruction.

RTL:src/sampler;UVM:tb_uvm/tb_uvm_sampler;common templates:tb_uvm/tb_uvm_reusable;
simulation:sim/sampler;Quartus:quartus/sampler;docs:docs/sampler_docs/post_midyear.
Keep exactly3 .do launchers:run_uvm.do,run_post_synthesis.do,run_post_fit.do.
Vectors/performance are modes of the main UVM. Independent models must not call
DUT functions. Coverage credits only scoreboard-accepted observations. Genuine
gaps stay visible;no artificial percentage ceiling or impossible bins.

Native128 remains inactive:tagged128-bit beats issue64-bit chunks. Current
pipeline:capture→staged prepare→extract→local compact→packed/admit→aligned
commit→32-entry/context collectors→per-context read→shared formatted output.
Mask conversion stays before packing;secret values remain4-bit encoded until
output formatting. Preserve complete state,credit/quota ownership and drain
before reuse. Do not relax6.500ns or waive original register guards.

Frozen Stage4.9r JSON/ZIP/SHA are immutable;never overwrite them. Its recorded
acceptance-pending field predates the explicit user acceptance. Mutable docs
record that acceptance. User-confirmed cleanup on2026-10-19 removed obsolete
checkpoint records/archives and leftover sim/ntt_LightHD and quartus/ntt_LightHD
folders. Stage4.9r evidence remains,with the new Stage5 result/archive/checksum added. All49 protected
source/model/settings/evidence files passed before/after hash checks. Two Python
analysis/checkpoint helpers remain after automatic review rejected their deletion.
