# Dilithium simulation

Current `run.do` exercises Stage4's real Keccak→sampler→memory→NTT path using a focused
non-UVM testbench under `tb/tb_dilithium/`. Main Dilithium UVM and implementation
launchers will replace/extend this evolving project at their actual stages.

Repository-root terminal:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

Questa GUI Transcript,working directory `sim/`:

```tcl
do dilithium/run.do
```

Repository-root terminal after capture:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 4
python sim/dilithium/dilithium_vectors.py selftest --stage 4
```

16 sampling jobs and50 compute commands:30 completed,17 rejected,3 reset-aborted.
Require `DILITHIUM_STAGE4_CAPTURE_PASS` and independent
`DILITHIUM STAGE4 COMPARE PASS`;4096 sampled values,9745 DMA operands,7713 NTT
outputs and11776 stored readbacks match. All12 checker corruptions are rejected.
GUI waves include commands,DMA progress,NTT streams and memory lifecycle.
No complete Dilithium UVM/coverage/PPA claim.

To rerun the preserved Stage2 test in Questa:

```tcl
set DILITHIUM_STAGE 2
do dilithium/run.do
```

Then use Python compare/selftest with `--stage 2`. Set `DILITHIUM_STAGE 3`
for the preserved sampling-memory test (104 jobs/22528 readbacks),and use
`--stage 3` for its Python verdict. Set `DILITHIUM_STAGE 4` to return to the
current all-engine test. All stages use the same sampling input/expected files
and the same Python script. Stage4 adds stage4_expected.txt with26 independently
calculated arithmetic expectations. Stage-specific captures are named
stage2_outputs.txt,stage3_outputs.txt andstage4_outputs.txt. Python defaults to4.

Golden vectors bind to the source/test/launcher/reference hash;rerun prepare and
capture after changing them. Current workload cycle witnesses are in
stage2_jobs.csv. Universal docs:docs/dilithium_docs/REFERENCE_VERIFICATION.md,
ARCHITECTURE.md and THROUGHPUT.md. Standalone module projects remain separate.
