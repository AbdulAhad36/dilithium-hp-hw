`timescale 1ps/1ps
// Actual retained-key preparer -> signing hash/mask client -> ONE services.
// The outer owner excludes host access across both clients and their gaps.
module tb_sign_mask_prepare;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,fault_o;
  logic context_valid_i;logic [1:0] context_param_i;logic [15:0] context_id_i;
  logic [63:0] context_regions_i;logic [255:0] context_key_i;logic [511:0] context_tr_i;
  logic [15:0] command_id_i=0,command_message_len_i=0,command_nonce_i=0;
  logic [8:0] command_context_len_i=0;logic [5:0] command_base_i=0;logic [255:0] command_rnd_i=0;
  logic payload_valid_i=0,payload_ready_o,payload_last_i=0;logic [63:0] payload_data_i=0;
  logic [3:0] payload_bytes_i=0;logic [15:0] payload_index_i=0;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o;logic [15:0] done_id_o;
  logic result_valid_o;logic [511:0] result_mu_o,result_seed_o;
  logic [63:0] result_regions_o;logic [6:0][5:0] result_handles_o;
  logic clear_valid_i=0,clear_ready_o;
  request_t service_o,prep_request,consumer='0,wire_request;
  response_t service_i,actual;
  sign_mask_prepare dut(.take_valid_i(1'b0),.take_ready_o(),.*);
  dilithium_services services(.clk(clk),.rst(rst),.request_i(wire_request),.response_o(actual));
  logic pk_valid=0,pk_ready,pk_busy,pk_active,pk_fault,pk_input=0,pk_input_ready,pk_last=0;
  logic [1:0] pk_param=0;logic [15:0] pk_id=100;
  logic [63:0] pk_data=0;logic [9:0] pk_index=0;
  logic pk_done,pk_done_ready=0,pk_clear=0,pk_clear_ready;logic [2:0] pk_code,pk_detail;
  logic [15:0] pk_done_id;logic [22:0][5:0] pk_handles;logic [255:0] pk_rho;
  sign_key_prepare prep(.clk(clk),.rst(rst),.command_valid_i(pk_valid),.command_ready_o(pk_ready),
    .busy_o(pk_busy),.service_active_o(pk_active),.fault_o(pk_fault),.command_param_i(pk_param),.command_id_i(pk_id),
    .command_base_i(6'd0),.command_work_i(6'd31),.input_valid_i(pk_input),.input_ready_o(pk_input_ready),
    .input_data_i(pk_data),.input_bytes_i(4'd8),.input_index_i(pk_index),.input_last_i(pk_last),
    .done_valid_o(pk_done),.done_ready_i(pk_done_ready),.done_code_o(pk_code),.done_detail_o(pk_detail),.done_id_o(pk_done_id),
    .context_valid_o(context_valid_i),.context_param_o(context_param_i),.context_id_o(context_id_i),
    .context_regions_o(context_regions_i),.context_handles_o(pk_handles),.context_rho_o(pk_rho),
    .context_key_o(context_key_i),.context_tr_o(context_tr_i),.clear_valid_i(pk_clear),.clear_ready_o(pk_clear_ready),
    .service_o(prep_request),.service_i(actual));
  int cycles=0,case_no=-1,p,jid,ctx,mlen,nonce,base,inject,abort_phase,sklen,bodylen,count,fd;
  int commands=0,completions=0,errors=0,aborts=0,words=0,rawbytes=0,writes=0,reads=0,keys=0;
  int stalls[5];bit monitor=0,test_passed=0,force_fault=0,reading=0,abort_hit=0;
  int watched_case=-1,watched_cycles=0;
  wire gr=cycles%7>2,gi=cycles%11>3,go=cycles%13>4,gs=cycles%17>5,gl=cycles%5>1;
  always_comb begin
    wire_request=pk_active?prep_request:((busy_o || command_valid_i)?service_o:consumer);
    service_i=actual;
    if(!pk_active && (busy_o || command_valid_i))begin
      wire_request.raw_valid=service_o.raw_valid && gr;service_i.raw_ready=actual.raw_ready && gr;
      wire_request.job_valid=service_o.job_valid && gr;service_i.job_ready=actual.job_ready && gr;
      wire_request.raw_input_valid=service_o.raw_input_valid && gi;service_i.raw_input_ready=actual.raw_input_ready && gi;
      wire_request.input_valid=service_o.input_valid && gi;service_i.input_ready=actual.input_ready && gi;
      wire_request.raw_output_ready=service_o.raw_output_ready && go;service_i.raw_output_valid=actual.raw_output_valid && go;
      wire_request.raw_done_ready=service_o.raw_done_ready && gs;service_i.raw_done_valid=actual.raw_done_valid && gs;
      wire_request.status_ready=service_o.status_ready && gs;service_i.status_valid=actual.status_valid && gs;
      wire_request.release_valid=service_o.release_valid && gl;service_i.release_ready=actual.release_ready && gl;
      if(reading)wire_request=consumer;
      if(inject==2 && dut.phase_r==0)service_i.raw_output_id=actual.raw_output_id^16'd1;
      if(inject==3 && dut.phase_r==1)service_i.raw_output_bytes=15;
      if(inject==4 && dut.phase_r==1)service_i.raw_done_id=actual.raw_done_id^16'd1;
      if(inject==5 && dut.phase_r==3 && dut.ordinal_r==2)service_i.status_id=actual.status_id^16'd1;
      if(inject==6 && dut.phase_r==3 && dut.ordinal_r==dut.length_r-1)service_i.status_code=7;
      if(force_fault)service_i.fault=1;
    end
  end
  bit held=0;logic [18:0] old_done;logic [1129:0] old_result;bit result_held=0;
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held=0;result_held=0;end
    else begin
      if(actual.fault || pk_fault)$fatal(1,"Mask unexpected physical fault");
      if(monitor)begin
        if(watched_case!=case_no)begin watched_case=case_no;watched_cycles=0;end
        watched_cycles++;
        if(done_valid_o && abort_phase!=0 && abort_phase!=4)$fatal(1,"Mask unexpectedly completed before reset checkpoint:case%0d code%0d",case_no,done_code_o);
        if(watched_cycles==100000)$fatal(1,"Mask bounded watchdog case%0d state%0d phase%0d ordinal%0d",case_no,dut.state,dut.phase_r,dut.ordinal_r);
        if((abort_phase==3 || abort_phase==5) && dut.phase_r==3 && dut.ordinal_r==1 &&
          services.datapath.subsystem.store.write_fire && services.datapath.subsystem.store.write_index_i==31)abort_hit=1;
        if(held && (!done_valid_o || {done_code_o,done_id_o}!==old_done))$fatal(1,"Mask held completion changed");
        held=done_valid_o && !done_ready_i;old_done={done_code_o,done_id_o};
        if(result_held && !(clear_valid_i && clear_ready_o) && (!result_valid_o ||
          {result_mu_o,result_seed_o,result_regions_o,result_handles_o}!==old_result))$fatal(1,"Mask retained result changed");
        result_held=result_valid_o && !(clear_valid_i && clear_ready_o);
        old_result={result_mu_o,result_seed_o,result_regions_o,result_handles_o};
        if(!result_valid_o && (result_mu_o || result_seed_o || result_regions_o || result_handles_o))$fatal(1,"Tentative mask result exposed");
        if(busy_o && command_ready_o)$fatal(1,"Mask replacement accepted");
        if(service_o.raw_valid && !service_i.raw_ready || service_o.job_valid && !service_i.job_ready)stalls[0]++;
        if(service_o.raw_input_valid && !service_i.raw_input_ready || service_o.input_valid && !service_i.input_ready)stalls[1]++;
        if(actual.raw_output_valid && !wire_request.raw_output_ready)stalls[2]++;
        if(actual.raw_done_valid && !wire_request.raw_done_ready || actual.status_valid && !wire_request.status_ready)stalls[3]++;
        if(service_o.release_valid && !service_i.release_ready)stalls[4]++;
        if(command_valid_i && command_ready_o)begin $fdisplay(fd,"C %0d %0d %0d %0d %0d %0d %0d",case_no,p,jid,ctx,mlen,nonce,base);commands++;end
        if(dut.fmt_request && dut.fmt_ready)$fdisplay(fd,"D %0d %0d %0d %0d %0d %0d",case_no,dut.phase_r,dut.ordinal_r,dut.fmt_id,dut.fmt_length,dut.fmt_sampling?actual.job_core:actual.raw_core);
        if(dut.fmt_input && dut.fmt_input_ready)begin $fdisplay(fd,"W %0d %0d %0d %0d %0d %016h",case_no,dut.phase_r,dut.ordinal_r,dut.fmt_index,dut.fmt_bytes,dut.fmt_data);words++;end
        if(actual.raw_output_valid && wire_request.raw_output_ready)begin
          $fdisplay(fd,"R %0d %0d %0d %0d %0d %032h",case_no,dut.phase_r,service_i.raw_output_id,service_i.raw_output_core,service_i.raw_output_bytes,service_i.raw_output_data);rawbytes+=16;
        end
        if(actual.raw_done_valid && wire_request.raw_done_ready)$fdisplay(fd,"S %0d %0d %0d %0d %0d",case_no,dut.phase_r,0,service_i.raw_done_id,service_i.raw_done_core);
        if(actual.status_valid && wire_request.status_ready)$fdisplay(fd,"S %0d %0d %0d %0d %0d %0d",case_no,3,dut.ordinal_r,service_i.status_id,service_i.status_core,service_i.status_code);
        if(services.datapath.subsystem.store.write_fire)begin
          $fdisplay(fd,"X %0d %0d %0d %06h",case_no,services.datapath.subsystem.store.write_region,services.datapath.subsystem.store.write_index_i,services.datapath.subsystem.store.write_data_i);writes++;
        end
        if(wire_request.release_valid && actual.release_ready)$fdisplay(fd,"L %0d %0d",case_no,{wire_request.release_bank,wire_request.release_region});
      end
    end
  end
  task automatic reset_all();
    @(negedge clk);#1;rst=1;command_valid_i=0;payload_valid_i=0;done_ready_i=0;clear_valid_i=0;
    pk_valid=0;pk_input=0;pk_done_ready=0;pk_clear=0;consumer='0;reading=0;force_fault=0;monitor=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || pk_busy || context_valid_i || actual.reserved || result_valid_o || fault_o)$fatal(1,"Mask reset state");
  endtask
  task automatic prepare_key(input string skhex);
    byte unsigned value;int n;
    pk_param=2'(p);pk_id=16'(100+p);pk_valid=1;do @(posedge clk);while(!pk_ready);@(negedge clk);#1;pk_valid=0;
    for(int w=0;w<sklen/8;w++)begin
      pk_data=0;for(int b=0;b<8;b++)begin n=$sscanf(skhex.substr(2*(8*w+b),2*(8*w+b)+1),"%h",value);if(n!=1)$fatal(1,"SK byte");pk_data[8*b+:8]=value;end
      pk_index=10'(w);pk_last=w==sklen/8-1;pk_input=1;do @(posedge clk);while(!pk_input_ready);@(negedge clk);#1;pk_input=0;
    end
    while(!pk_done)begin @(negedge clk);#1;end
    if(pk_code || !context_valid_i)$fatal(1,"Key preparation failed");
    $fdisplay(fd,"K %0d %0d %0d %016h %064h %0128h",case_no,p,context_id_i,context_regions_i,context_key_i,context_tr_i);keys++;
    pk_done_ready=1;@(posedge clk);@(negedge clk);#1;pk_done_ready=0;
  endtask
  task automatic read_region(input int kind,input int ordinal,input int region);
    reading=1;
    for(int w=0;w<64;w++)begin
      consumer='0;consumer.read_valid=1;{consumer.read_bank,consumer.read_region}=6'(region);consumer.read_word=6'(w);
      do @(posedge clk);while(!actual.read_ready);@(negedge clk);#1;consumer.read_valid=0;
      while(!actual.response_valid)begin @(negedge clk);#1;end
      if(actual.response_error)$fatal(1,"Mask consumer read error");
      $fdisplay(fd,"V %0d %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,kind,ordinal,region,w,actual.response_id,actual.response_mode,actual.response_param,actual.response_ntt_domain,actual.response_data);reads++;
      repeat(w%3)@(negedge clk);#1;consumer.response_ready=1;@(posedge clk);@(negedge clk);#1;consumer='0;
    end
    reading=0;
  endtask
  task automatic seed_occupied();
    consumer='0;consumer.job_valid=1;consumer.job_bank=3;consumer.job_region=2;
    consumer.job_mode=2;consumer.job_param=0;consumer.job_id=60000;consumer.message_len=0;consumer.status_ready=1;
    do @(posedge clk);while(!actual.job_ready);@(negedge clk);#1;consumer.job_valid=0;
    while(actual.active!=0)begin @(negedge clk);#1;end consumer='0;
    if(!actual.complete[50])$fatal(1,"Occupied sentinel missing");
  endtask
  initial begin
    int f,n,parsed;string directory,token,skhex,bodyhex;byte unsigned value;bit aborted;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_sign_mask_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d",token,count)!=2)$fatal(1,"Prepare mask fixtures");
    fd=$fopen({directory,"/stage5_sign_mask_outputs.txt"},"w");$fdisplay(fd,"H %s",token);reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %d %d %d %h %d %s %d %s",case_no,p,jid,ctx,mlen,nonce,base,inject,abort_phase,command_rnd_i,sklen,skhex,bodylen,bodyhex)!=14 || case_no!=c)$fatal(1,"Mask fixture row");
      monitor=0;
      if(context_valid_i && context_param_i!=p)begin
        pk_clear=1;do @(posedge clk);while(!pk_clear_ready);@(negedge clk);#1;pk_clear=0;
        while(pk_busy)begin @(negedge clk);#1;end reset_all();
      end
      if(!context_valid_i)begin prepare_key(skhex);seed_occupied();end
      for(int s=0;s<5;s++)stalls[s]=0;
      abort_hit=0;monitor=1;command_id_i=16'(jid);command_message_len_i=16'(mlen);command_context_len_i=9'(ctx);command_nonce_i=16'(nonce);command_base_i=6'(base);
      command_valid_i=1;do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;
      command_id_i='1;command_rnd_i='1;command_message_len_i='1;command_context_len_i='1;command_nonce_i='1;command_base_i='1;
      if(ctx<=255 && 66+bodylen<=65535 && base+((p==0)?4:(p==1?5:7))<=64 && base!=0 && base!=50 && nonce+((p==0)?4:(p==1?5:7))<=65536)begin
        for(int w=0;w<(bodylen+7)/8;w++)begin
          payload_data_i='1;n=bodylen-8*w;if(n>8)n=8;
          for(int b=0;b<n;b++)begin parsed=$sscanf(bodyhex.substr(2*(8*w+b),2*(8*w+b)+1),"%h",value);if(parsed!=1)$fatal(1,"Mask payload byte");payload_data_i[8*b+:8]=value;end
          n=bodylen-8*w;if(n>8)n=8;
          payload_bytes_i=4'(n);payload_index_i=16'(w ^ ((inject==1 && w==0)?1:0));payload_last_i=8*(w+1)>=bodylen;payload_valid_i=1;
          do @(posedge clk);while(!payload_ready_o);@(negedge clk);#1;payload_valid_i=0;
          if(inject==1)break;
        end
      end
      aborted=0;
      if(abort_phase!=0)begin
        case(abort_phase)
          1:while(!(dut.phase_r==0 && actual.raw_output_valid))begin @(negedge clk);#1;end
          2:while(!(dut.phase_r==1 && actual.raw_output_valid))begin @(negedge clk);#1;end
          3,5:while(!abort_hit)begin @(negedge clk);#1;end
          4:while(!done_valid_o)begin @(negedge clk);#1;end
        endcase
        if(abort_phase==5)begin force_fault=1;repeat(3)@(negedge clk);#1;if(!fault_o || done_valid_o || result_valid_o)$fatal(1,"Mask fault did not halt");end
        $fdisplay(fd,"A %0d %0d",case_no,abort_phase);aborts++;aborted=1;reset_all();
      end
      if(!aborted)begin
        while(!done_valid_o)begin @(negedge clk);#1;end
        if(done_code_o==0)begin
          $fdisplay(fd,"P %0d %0128h %0128h %016h %011h",case_no,result_mu_o,result_seed_o,result_regions_o,result_handles_o);
          repeat(7)begin @(negedge clk);#1;if(!result_valid_o)$fatal(1,"Mask result vanished");end
        end
        $fdisplay(fd,"E %0d %0d %0d",case_no,done_id_o,done_code_o);completions++;if(done_code_o)errors++;
        done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
        if(done_code_o==0)begin
          repeat(7)@(negedge clk);#1;
          for(int j=0;j<(p==0?4:(p==1?5:7));j++)read_region(0,j,base+j);
          clear_valid_i=1;do @(posedge clk);while(!clear_ready_o);@(negedge clk);#1;clear_valid_i=0;
          while(busy_o)begin @(negedge clk);#1;end
        end else while(busy_o)begin @(negedge clk);#1;end
        // Key and unrelated sentinel must survive both success-clear and errors.
        for(int j=0;j<(p==0?12:(p==1?17:23));j++)read_region(1,j,pk_handles[j]);
        read_region(2,0,50);
        if(actual.reserved!==(context_regions_i | (64'd1<<50)))$fatal(1,"Mask leaked/clobbered regions");
        $fdisplay(fd,"T %0d %0d %0d %0d %0d %0d",case_no,stalls[0],stalls[1],stalls[2],stalls[3],stalls[4]);
      end
      monitor=0;
    end
    $fdisplay(fd,"F %0d %0d %0d %0d %0d %0d %0d %0d %0d",commands,completions,errors,aborts,words,rawbytes,writes,reads,keys);
    $fclose(f);$fclose(fd);$display("STAGE5N4E_SIGN_MASK_CAPTURE_PASS:%0d commands,%0d completions,%0d errors,%0d resets",commands,completions,errors,aborts);test_passed=1;$finish;
  end
  initial begin #(64'd100000000000);$fatal(1,"Mask watchdog case%0d state%0d phase%0d",case_no,dut.state,dut.phase_r);end
endmodule
