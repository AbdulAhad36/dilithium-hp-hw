`timescale 1ps/1ps
// Three working control clients,one physical services tree. No RAM preload.
module tb_sign_matrix_prepare;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,fault_o;logic [15:0] command_id_i=0;
  logic context_valid_i;logic [1:0] context_param_i;logic [15:0] context_id_i;
  logic [63:0] context_regions_i;logic [255:0] context_rho_i,key;logic [511:0] tr;
  logic mask_valid_i;logic [15:0] mask_id_i;logic [63:0] mask_regions_i;logic [6:0][5:0] mask_handles_i;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o,done_detail_o;logic [15:0] done_id_o;
  logic result_valid_o;logic [63:0] result_regions_o;logic [6:0][5:0] result_yhat_o;
  logic [7:0][5:0] result_low_o,result_high_o;logic clear_valid_i=0,clear_ready_o;
  request_t service_o,key_request,mask_request,consumer='0,wire_request;response_t service_i,actual;
  sign_matrix_prepare dut(.take_valid_i(1'b0),.take_ready_o(),.*);
  dilithium_services services(.clk(clk),.rst(rst),.request_i(wire_request),.response_o(actual));
  logic kv=0,kr,kbusy,kactive,kfault,ki=0,kir,klast=0,kdone,kdr=0,kclear=0,kcr;
  logic [1:0] kp=0;logic [63:0] kd=0;logic [9:0] kindex=0;
  logic [2:0] kcode,kdetail;logic [15:0] kid;logic [22:0][5:0] kh;
  sign_key_prepare prep(.clk(clk),.rst(rst),.command_valid_i(kv),.command_ready_o(kr),.busy_o(kbusy),
    .service_active_o(kactive),.fault_o(kfault),.command_param_i(kp),.command_id_i(16'(100+kp)),
    .command_base_i(6'd0),.command_work_i(6'd31),.input_valid_i(ki),.input_ready_o(kir),.input_data_i(kd),
    .input_bytes_i(4'd8),.input_index_i(kindex),.input_last_i(klast),.done_valid_o(kdone),.done_ready_i(kdr),
    .done_code_o(kcode),.done_detail_o(kdetail),.done_id_o(kid),.context_valid_o(context_valid_i),
    .context_param_o(context_param_i),.context_id_o(context_id_i),.context_regions_o(context_regions_i),
    .context_handles_o(kh),.context_rho_o(context_rho_i),.context_key_o(key),.context_tr_o(tr),
    .clear_valid_i(kclear),.clear_ready_o(kcr),.service_o(key_request),.service_i(actual));
  logic mv=0,mr,mbusy,mfault,mpv=0,mpr,mplast=0,mdone,mdr=0,mclear=0,mcr;
  logic [63:0] mpdata=0;logic [15:0] mpindex=0;logic [3:0] mpbytes=8;
  logic [255:0] rnd=0;logic [15:0] mask_nonce=0,mid;logic [2:0] mcode;
  logic [511:0] mu,seed;
  assign mask_id_i=16'(1000+kp);
  sign_mask_prepare front(.take_valid_i(1'b0),.take_ready_o(),.clk(clk),.rst(rst),.command_valid_i(mv),.command_ready_o(mr),.busy_o(mbusy),.fault_o(mfault),
    .context_valid_i(context_valid_i),.context_param_i(context_param_i),.context_id_i(context_id_i),
    .context_regions_i(context_regions_i),.context_key_i(key),.context_tr_i(tr),.command_id_i(mask_id_i),
    .command_message_len_i(16'd169),.command_nonce_i(mask_nonce),.command_context_len_i(9'd7),.command_base_i(6'd32),
    .command_rnd_i(rnd),.payload_valid_i(mpv),.payload_ready_o(mpr),.payload_data_i(mpdata),.payload_bytes_i(mpbytes),
    .payload_index_i(mpindex),.payload_last_i(mplast),.done_valid_o(mdone),.done_ready_i(mdr),.done_code_o(mcode),.done_id_o(mid),
    .result_valid_o(mask_valid_i),.result_mu_o(mu),.result_seed_o(seed),.result_regions_o(mask_regions_i),.result_handles_o(mask_handles_i),
    .clear_valid_i(mclear),.clear_ready_o(mcr),.service_o(mask_request),.service_i(actual));
  int case_no=-1,p,jid,nonce,inject,abort_phase,sklen,count,fd,cycles=0;
  int commands=0,completed=0,errors=0,aborts=0,writes=0,reads=0,keys=0,masks=0,peak=0;
  int stalls[7];logic [63:0] blockers=0;bit monitor=0,preparing_mask=0,reading=0,force_fault=0,abort_hit=0,test_passed=0,plan_seen=0;
  wire gr=cycles%7>2,gs=cycles%11>3,gi=cycles%13>4,gl=cycles%5>1;
  always_comb begin
    wire_request=kactive?key_request:(preparing_mask?mask_request:((busy_o || command_valid_i)?service_o:consumer));
    service_i=actual;
    if(!kactive && !preparing_mask && (busy_o || command_valid_i))begin
      wire_request.op_valid=service_o.op_valid && gr;service_i.op_ready=actual.op_ready && gr;
      wire_request.job_valid=service_o.job_valid && gr;service_i.job_ready=actual.job_ready && gr;
      wire_request.row_valid=service_o.row_valid && gr;service_i.row_ready=actual.row_ready && gr;
      wire_request.sign.valid=service_o.sign.valid && gr;service_i.sign.ready=actual.sign.ready && gr;
      wire_request.input_valid=service_o.input_valid && gi;service_i.input_ready=actual.input_ready && gi;
      wire_request.op_done_ready=service_o.op_done_ready && gs;service_i.op_done_valid=actual.op_done_valid && gs;
      wire_request.status_ready=service_o.status_ready && gs;service_i.status_valid=actual.status_valid && gs;
      wire_request.row_done_ready=service_o.row_done_ready && gs;service_i.row_done_valid=actual.row_done_valid && gs;
      wire_request.sign.done_ready=service_o.sign.done_ready && gs;service_i.sign.done_valid=actual.sign.done_valid && gs;
      wire_request.release_valid=service_o.release_valid && gl;service_i.release_ready=actual.release_ready && gl;
      if(reading)wire_request=consumer;
      if(inject==2 && dut.column_r==1)wire_request.op_a_id=service_o.op_a_id^16'd1;
      if(inject==3 && dut.column_r==1)service_i.op_done_id=actual.op_done_id^16'd1;
      if(inject==4 && dut.row_r==1 && dut.column_r==1)service_i.status_id=actual.status_id^16'd1;
      if(inject==5 && dut.row_r==1)wire_request.row_s_id[0]=service_o.row_s_id[0]^16'd1;
      if(inject==6 && dut.row_r==1)service_i.row_done_id=actual.row_done_id^16'd1;
      if(inject==7 && dut.row_r==1)wire_request.sign.a_id=service_o.sign.a_id^16'd1;
      if(inject==8 && dut.row_r==dut.rows_r-1)service_i.sign.done_high=actual.sign.done_high^6'd1;
      if(force_fault)service_i.fault=1;
    end
  end
  bit held=0,rheld=0;logic [21:0] old_done;logic [201:0] old_result;
  int watched=-1,elapsed=0;
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held=0;rheld=0;end
    else begin
      if(actual.fault || kfault || mfault)$fatal(1,"Matrix physical child fault case%0d state%0d",case_no,dut.state);
      if(monitor)begin
        if(watched!=case_no)begin watched=case_no;elapsed=0;end elapsed++;
        if(elapsed==300000)$fatal(1,"Matrix watchdog case%0d state%0d row%0d col%0d code%0d",case_no,dut.state,dut.row_r,dut.column_r,done_code_o);
        if(held && (!done_valid_o || {done_code_o,done_detail_o,done_id_o}!==old_done))$fatal(1,"Matrix held done changed");
        held=done_valid_o && !done_ready_i;old_done={done_code_o,done_detail_o,done_id_o};
        if(rheld && !(clear_valid_i && clear_ready_o) && (!result_valid_o ||
          {result_regions_o,result_yhat_o,result_low_o,result_high_o}!==old_result))$fatal(1,"Matrix retained result changed");
        rheld=result_valid_o && !(clear_valid_i && clear_ready_o);old_result={result_regions_o,result_yhat_o,result_low_o,result_high_o};
        if(!result_valid_o && (result_regions_o || result_yhat_o || result_low_o || result_high_o))$fatal(1,"Tentative matrix result exposed");
        if(busy_o && command_ready_o)$fatal(1,"Matrix owner replaced");
        if(done_valid_o && abort_phase!=0 && abort_phase!=5)$fatal(1,"Matrix completed before reset phase case%0d code%0d",case_no,done_code_o);
        if($countones(actual.reserved)>peak)peak=$countones(actual.reserved);
        if(service_o.op_valid && !service_i.op_ready)stalls[0]++;
        if(service_o.job_valid && !service_i.job_ready)stalls[1]++;
        if(service_o.row_valid && !service_i.row_ready)stalls[2]++;
        if(service_o.sign.valid && !service_i.sign.ready)stalls[3]++;
        if(service_o.input_valid && !service_i.input_ready)stalls[4]++;
        if(actual.op_done_valid && !wire_request.op_done_ready || actual.status_valid && !wire_request.status_ready ||
          actual.row_done_valid && !wire_request.row_done_ready || actual.sign.done_valid && !wire_request.sign.done_ready)stalls[5]++;
        if(service_o.release_valid && !service_i.release_ready)stalls[6]++;
        if(command_valid_i && command_ready_o)begin $fdisplay(fd,"C %0d %0d %0d %0d %0d %0d",case_no,p,jid,nonce,inject,abort_phase);commands++;end
        if(dut.state==3 && !plan_seen)begin $fdisplay(fd,"G %0d %016h %011h %011h %012h %012h %0d %0d %0d",case_no,dut.plan_r,dut.yhat_r,dut.a_r,dut.low_r,dut.high_r,dut.acc_r,dut.scratch_r,dut.w_r);plan_seen=1;end
        if(wire_request.op_valid && actual.op_ready)$fdisplay(fd,"N %0d %0d %0d %0d %0d %0d",case_no,dut.column_r,wire_request.op_a_region,wire_request.op_dest_region,wire_request.op_a_id,wire_request.op_id);
        if(actual.op_done_valid && wire_request.op_done_ready)$fdisplay(fd,"O %0d %0d %0d %0d %0d %0d",case_no,dut.column_r,service_i.op_done_id,service_i.op_done_region,service_i.op_done_code,actual.op_done_code);
        if(dut.fmt_request && dut.state==6 && service_i.job_ready)$fdisplay(fd,"J %0d %0d %0d %0d %0d %0d",case_no,dut.row_r,dut.column_r,wire_request.job_id,dut.a_r[dut.column_r],actual.job_core);
        if(dut.fmt_input && dut.state==6 && service_i.input_ready)$fdisplay(fd,"W %0d %0d %0d %016h",case_no,dut.row_r,dut.column_r,dut.fmt_data);
        if(actual.status_valid && wire_request.status_ready)$fdisplay(fd,"S %0d %0d %0d %0d %0d %0d",case_no,dut.row_r,dut.column_r,service_i.status_id,service_i.status_core,service_i.status_code);
        if(wire_request.row_valid && actual.row_ready)$fdisplay(fd,"R %0d %0d %0d %0d",case_no,dut.row_r,wire_request.row_id,wire_request.row_s_id[0]);
        if(actual.row_done_valid && wire_request.row_done_ready)$fdisplay(fd,"Q %0d %0d %0d %0d %0d %0d",case_no,dut.row_r,service_i.row_done_id,service_i.row_done_region,service_i.row_done_code,service_i.row_completed_terms);
        if(wire_request.sign.valid && actual.sign.ready)$fdisplay(fd,"D %0d %0d %0d %0d %0d %0d",case_no,dut.row_r,wire_request.sign.a,wire_request.sign.dest,wire_request.sign.high,wire_request.sign.a_id);
        if(actual.sign.done_valid && wire_request.sign.done_ready)$fdisplay(fd,"B %0d %0d %0d %0d %0d %0d",case_no,dut.row_r,service_i.sign.done_id,service_i.sign.done_dest,service_i.sign.done_high,service_i.sign.done_code);
        if(services.datapath.subsystem.store.write_fire)begin
          $fdisplay(fd,"X %0d %0d %0d %0d %0d %0d %06h",case_no,dut.state,dut.row_r,dut.column_r,
            services.datapath.subsystem.store.write_region,services.datapath.subsystem.store.write_index_i,services.datapath.subsystem.store.write_data_i);writes++;
          if(abort_phase==1 && dut.state==4 && services.datapath.subsystem.store.write_index_i==31)abort_hit=1;
          if(abort_phase==2 && dut.state==6 && dut.row_r==0 && dut.column_r==1 && services.datapath.subsystem.store.write_index_i==31)abort_hit=1;
          if((abort_phase==3 || abort_phase==6) && dut.state==8 && services.datapath.subsystem.store.write_index_i==31)abort_hit=1;
        end
        if(services.datapath.subsystem.store.finish_fire)$fdisplay(fd,"F %0d %0d %0d %0d",case_no,dut.state,services.datapath.subsystem.store.finish_region,services.datapath.subsystem.store.finish_code_i);
        if(wire_request.release_valid && actual.release_ready)$fdisplay(fd,"L %0d %0d %0d",case_no,dut.state,{wire_request.release_bank,wire_request.release_region});
      end
    end
  end
  always @(negedge clk)if(monitor && !rst && abort_phase==4 && dut.state==10 &&
    services.datapath.subsystem.sign_client.state==13)abort_hit=1;
  task automatic reset_all();
    @(negedge clk);#1;rst=1;kv=0;ki=0;kdr=0;kclear=0;mv=0;mpv=0;mdr=0;mclear=0;
    command_valid_i=0;done_ready_i=0;clear_valid_i=0;consumer='0;preparing_mask=0;reading=0;force_fault=0;monitor=0;blockers=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || kbusy || mbusy || actual.reserved || result_valid_o || fault_o)$fatal(1,"Matrix reset ownership");
  endtask
  task automatic seed_region(input int region);
    consumer='0;consumer.job_valid=1;{consumer.job_bank,consumer.job_region}=6'(region);
    consumer.job_mode=2;consumer.job_param=0;consumer.job_id=60000;consumer.status_ready=1;
    do @(posedge clk);while(!actual.job_ready);@(negedge clk);#1;consumer.job_valid=0;
    while(actual.active!=0)begin @(negedge clk);#1;end consumer='0;
    if(!actual.complete[region])$fatal(1,"Matrix blocker seed failed");
  endtask
  task automatic prepare_key(input string hexbytes);
    int parsed;byte unsigned value;kp=2'(p);kv=1;do @(posedge clk);while(!kr);@(negedge clk);#1;kv=0;
    for(int w=0;w<sklen/8;w++)begin
      kd=0;for(int b=0;b<8;b++)begin parsed=$sscanf(hexbytes.substr(2*(8*w+b),2*(8*w+b)+1),"%h",value);if(parsed!=1)$fatal(1,"Matrix SK byte");kd[8*b+:8]=value;end
      kindex=10'(w);klast=w==sklen/8-1;ki=1;do @(posedge clk);while(!kir);@(negedge clk);#1;ki=0;
    end
    while(!kdone)begin @(negedge clk);#1;end if(kcode || !context_valid_i)$fatal(1,"Matrix key prepare failed");
    $fdisplay(fd,"K %0d %0d %016h %064h",case_no,p,context_regions_i,context_rho_i);keys++;
    kdr=1;@(posedge clk);@(negedge clk);#1;kdr=0;seed_region(50);
  endtask
  task automatic prepare_mask(input string bodyhex);
    int parsed;byte unsigned value;preparing_mask=1;mask_nonce=16'(nonce);mv=1;
    do @(posedge clk);while(!mr);@(negedge clk);#1;mv=0;
    for(int w=0;w<22;w++)begin
      mpdata=0;for(int b=0;b<8;b++)begin parsed=$sscanf(bodyhex.substr(2*(8*w+b),2*(8*w+b)+1),"%h",value);if(parsed!=1)$fatal(1,"Matrix body byte");mpdata[8*b+:8]=value;end
      mpindex=16'(w);mplast=w==21;mpv=1;do @(posedge clk);while(!mpr);@(negedge clk);#1;mpv=0;
    end
    while(!mdone)begin @(negedge clk);#1;end if(mcode || !mask_valid_i)$fatal(1,"Matrix mask prepare failed");
    $fdisplay(fd,"M %0d %0d %016h %011h %0128h %0128h",case_no,nonce,mask_regions_i,mask_handles_i,mu,seed);masks++;
    mdr=1;@(posedge clk);@(negedge clk);#1;mdr=0;preparing_mask=0;
  endtask
  task automatic read_region(input int kind,input int ordinal,input int region);
    reading=1;
    for(int w=0;w<64;w++)begin
      consumer='0;consumer.read_valid=1;{consumer.read_bank,consumer.read_region}=6'(region);consumer.read_word=6'(w);
      do @(posedge clk);while(!actual.read_ready);@(negedge clk);#1;consumer.read_valid=0;
      while(!actual.response_valid)begin @(negedge clk);#1;end
      if(actual.response_error)$fatal(1,"Matrix read error");
      $fdisplay(fd,"V %0d %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,kind,ordinal,region,w,actual.response_id,actual.response_mode,actual.response_param,actual.response_ntt_domain,actual.response_data);reads++;
      repeat(w%3)@(negedge clk);#1;consumer.response_ready=1;@(posedge clk);@(negedge clk);#1;consumer='0;
    end reading=0;
  endtask
  initial begin
    int f,needed;string directory,token,skhex,bodyhex;bit aborted;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_sign_matrix_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d",token,count)!=2)$fatal(1,"Prepare matrix fixtures");
    fd=$fopen({directory,"/stage5_sign_matrix_outputs.txt"},"w");$fdisplay(fd,"H %s",token);reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %h %d %s %s",case_no,p,jid,nonce,inject,abort_phase,rnd,sklen,skhex,bodyhex)!=10 || case_no!=c)$fatal(1,"Matrix fixture row");
      monitor=0;
      if(context_valid_i && context_param_i!=p)reset_all();
      if(!context_valid_i)prepare_key(skhex);
      if(mask_valid_i && mask_nonce!=nonce)begin
        preparing_mask=1;mclear=1;do @(posedge clk);while(!mcr);@(negedge clk);#1;mclear=0;
        while(mbusy)begin @(negedge clk);#1;end preparing_mask=0;
      end
      if(!mask_valid_i)prepare_mask(bodyhex);
      blockers=0;needed=2*(p==0?4:(p==1?5:7))+2*(p==0?4:(p==1?6:8))+3;
      if(inject==1)for(int r=0;r<64 && 64-$countones(actual.reserved)>=needed;r++)if(!actual.reserved[r])begin seed_region(r);blockers[r]=1;end
      $fdisplay(fd,"I %0d %016h",case_no,actual.reserved);
      for(int j=0;j<7;j++)stalls[j]=0;peak=0;abort_hit=0;plan_seen=0;monitor=1;
      command_id_i=16'(jid);command_valid_i=1;do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;command_id_i='1;
      aborted=0;
      if(abort_phase!=0)begin
        if(abort_phase==5)while(!done_valid_o)begin @(negedge clk);#1;end
        else while(!abort_hit)begin @(negedge clk);#1;end
        if(abort_phase==6)begin force_fault=1;repeat(3)@(negedge clk);#1;if(!fault_o || done_valid_o || result_valid_o)$fatal(1,"Matrix fault did not halt");end
        $fdisplay(fd,"A %0d %0d %0d %0d %0d",case_no,abort_phase,dut.state,dut.row_r,dut.column_r);
        if(abort_phase==4)rst=1; // before the high-region finish acknowledgment
        aborts++;aborted=1;reset_all();
      end
      if(!aborted)begin
        while(!done_valid_o)begin @(negedge clk);#1;end
        if(done_code_o==0)$fdisplay(fd,"P %0d %016h %011h %012h %012h",case_no,result_regions_o,result_yhat_o,result_low_o,result_high_o);
        repeat(7)@(negedge clk);#1;$fdisplay(fd,"E %0d %0d %0d %0d",case_no,done_id_o,done_code_o,done_detail_o);
        completed++;if(done_code_o)errors++;
        done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
        if(done_code_o==0)begin
          repeat(7)@(negedge clk);#1;
          for(int j=0;j<(p==0?4:(p==1?5:7));j++)read_region(0,j,result_yhat_o[j]);
          for(int r=0;r<(p==0?4:(p==1?6:8));r++)begin read_region(1,r,result_low_o[r]);read_region(2,r,result_high_o[r]);end
          clear_valid_i=1;do @(posedge clk);while(!clear_ready_o);@(negedge clk);#1;clear_valid_i=0;
        end
        while(busy_o)begin @(negedge clk);#1;end
        for(int j=0;j<(p==0?12:(p==1?17:23));j++)read_region(3,j,kh[j]);
        for(int j=0;j<(p==0?4:(p==1?5:7));j++)read_region(4,j,mask_handles_i[j]);
        read_region(5,0,50);
        for(int r=0;r<64;r++)if(blockers[r])begin
          read_region(6,r,r);consumer='0;consumer.release_valid=1;{consumer.release_bank,consumer.release_region}=6'(r);
          do @(posedge clk);while(!actual.release_ready);@(negedge clk);#1;consumer='0;
        end
        if(actual.reserved!==(context_regions_i|mask_regions_i|(64'd1<<50)))$fatal(1,"Matrix workspace leaked/source clobbered");
        $fdisplay(fd,"T %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,stalls[0],stalls[1],stalls[2],stalls[3],stalls[4],stalls[5],stalls[6],peak);
      end monitor=0;
    end
    $fdisplay(fd,"Z %0d %0d %0d %0d %0d %0d %0d %0d",commands,completed,errors,aborts,writes,reads,keys,masks);
    $fclose(f);$fclose(fd);$display("STAGE5N4F_SIGN_MATRIX_CAPTURE_PASS:%0d commands,%0d completions,%0d errors,%0d reset/fault aborts",commands,completed,errors,aborts);test_passed=1;$finish;
  end
  initial begin #(64'd100000000000);$fatal(1,"Matrix global watchdog case%0d state%0d",case_no,dut.state);end
endmodule
