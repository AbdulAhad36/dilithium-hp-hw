// w1 -> shared Bitpkg -> mu||encoded_w1 -> shared SHAKE256 -> SampleInBall.
// Caller retains matrix/key/mask contexts and the outer operation lease.
// No polynomial/message RAM;one cached92-bit source word and private digest.
`default_nettype none
module sign_challenge_prepare (
  input wire logic clk,rst,command_valid_i,output logic command_ready_o,busy_o,fault_o,
  input wire logic [15:0] command_id_i,
  input wire logic context_valid_i,input wire logic [1:0] context_param_i,
  input wire logic [15:0] context_id_i,input wire logic [63:0] context_regions_i,
  input wire logic [7:0][5:0] context_high_i,input wire logic [511:0] context_mu_i,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic [2:0] done_code_o,done_detail_o,output logic [15:0] done_id_o,
  output logic result_valid_o,output logic [511:0] result_ctilde_o,
  output logic [6:0] result_bytes_o,output logic [5:0] result_region_o,
  input wire logic clear_valid_i,output logic clear_ready_o,
  input wire logic take_valid_i,output logic take_ready_o,
  output dilithium_service_pkg::request_t service_o,
  input wire dilithium_service_pkg::response_t service_i
);
  typedef enum logic [4:0] {IDLE,CHECK,FIND,FMT_START,PACK_START,READ_REQ,READ_RESP,FEED,
    PACK_WAIT,HASH_WAIT,DRAIN,SAMPLE_START,SAMPLE_INPUT,SAMPLE_WAIT,REPORT,READY,CLEAN,HALT} state_e;
  state_e state;
  logic [1:0] param_r,lane_r;logic [15:0] id_r,source_id_r;
  logic [63:0] regions_r;logic [7:0][5:0] high_r;logic [511:0] mu_r,digest_r;
  logic [3:0] rows_r,poly_r;logic [5:0] word_r,scan_r,dest_r;
  logic [91:0] cache_r;logic [8:0] sent_r;logic [6:0] pack_words_r,bytes_r,raw_count_r;logic [7:0] body_words_r;
  logic [3:0] sample_word_r;logic [2:0] code_r,detail_r;
  logic pack_active_r,read_pending_r,raw_started_r,raw_retired_r,raw_core_r,sample_core_r,sample_retired_r;
  logic owned_r,clearing_r,hash_live,quiescent,bad_source,bad_pack_output,pack_out_fire,pack_done_fire,raw_fire,raw_done_fire;
  logic [63:0] command_high_mask;logic [3:0] command_rows;logic [6:0] words_per_poly;
  logic fmt_ready,fmt_busy,fmt_request,fmt_req_ready,fmt_sampling,fmt_mode,fmt_input,fmt_done,fmt_ack,fmt_payload,fmt_payload_ready;
  logic [1:0] fmt_param;logic [15:0] fmt_id,fmt_length,fmt_outlen,fmt_index,fmt_done_id;
  logic [63:0] fmt_data,fmt_payload_data;logic [3:0] fmt_bytes,fmt_payload_bytes;
  logic fmt_last,fmt_payload_last;logic [2:0] fmt_code,new_code,new_detail;
  logic [15:0] fmt_payload_index;
  assign hash_live=state>=FMT_START && state<=DRAIN;
  assign words_per_poly=param_r==0?7'd24:7'd16;
  assign quiescent=service_i.active==0 && !service_i.op_busy && !service_i.process_busy &&
    !service_i.sign.busy && !service_i.load.busy && !service_i.row_busy &&
    !service_i.pack.output_valid && !service_i.pack.done_valid &&
    !service_i.response_valid && service_i.read_ready;
  always_comb begin
    command_rows=context_param_i==0?4'd4:(context_param_i==1?4'd6:4'd8);
    command_high_mask=0;bad_source=0;
    for(int r=0;r<8;r++)if(r<int'(command_rows))begin
      if(command_high_mask[context_high_i[r]])bad_source=1;
      command_high_mask[context_high_i[r]]=1;
    end
    bad_source|=(command_high_mask & context_regions_i)!=command_high_mask;
  end
  assign command_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault;
  assign busy_o=state!=IDLE;assign done_valid_o=!rst && state==REPORT && !fault_o;
  assign done_code_o=code_r;assign done_detail_o=detail_r;assign done_id_o=id_r;
  assign result_valid_o=!rst && !fault_o && ((state==REPORT && code_r==0) || state==READY);
  assign result_ctilde_o=result_valid_o?digest_r:512'd0;
  assign result_bytes_o=result_valid_o?bytes_r:7'd0;assign result_region_o=result_valid_o?dest_r:6'd0;
  assign clear_ready_o=!rst && state==READY && quiescent && service_i.pack.command_ready && !fault_o && !service_i.fault;
  assign take_ready_o=clear_ready_o && !clear_valid_i;
  assign bad_pack_output=service_i.pack.output_id!=id_r || service_i.pack.output_bytes!=8 ||
    service_i.pack.output_index!=pack_words_r || pack_words_r>=words_per_poly ||
    service_i.pack.output_last!=(pack_words_r==words_per_poly-1'b1);
  always_comb begin
    fmt_payload=0;fmt_payload_data=service_i.pack.output_data;fmt_payload_bytes=8;
    fmt_payload_index={8'd0,body_words_r};fmt_payload_last=poly_r==rows_r-1'b1 && service_i.pack.output_last;
    if(hash_live && !fault_o)begin
      if(state==DRAIN)begin fmt_payload=1;fmt_payload_data=0;fmt_payload_bytes=0;fmt_payload_last=0;end
      else if(pack_active_r)begin fmt_payload=service_i.pack.output_valid;if(bad_pack_output)fmt_payload_bytes=0;end
    end
  end
  sign_hash_message formatter(.clk(clk),.rst(rst),.command_valid_i(state==FMT_START && !fault_o),
    .command_ready_o(fmt_ready),.busy_o(fmt_busy),.command_op_i(2'd2),.command_param_i(param_r),.command_id_i(id_r),
    .command_message_len_i(16'd0),.command_nonce_i(16'd0),.command_context_len_i(9'd0),
    .command_tr_i(512'd0),.command_mu_i(mu_r),.command_mask_seed_i(512'd0),.command_key_i(256'd0),.command_rnd_i(256'd0),
    .payload_valid_i(fmt_payload),.payload_ready_o(fmt_payload_ready),.payload_data_i(fmt_payload_data),
    .payload_bytes_i(fmt_payload_bytes),.payload_index_i(fmt_payload_index),.payload_last_i(fmt_payload_last),
    .request_valid_o(fmt_request),.request_ready_i(fmt_req_ready),.request_sampling_o(fmt_sampling),.request_mode_o(fmt_mode),
    .request_param_o(fmt_param),.request_id_o(fmt_id),.request_message_len_o(fmt_length),.request_output_len_o(fmt_outlen),
    .input_valid_o(fmt_input),.input_ready_i(hash_live && service_i.raw_input_ready && !fault_o),
    .input_data_o(fmt_data),.input_bytes_o(fmt_bytes),.input_index_o(fmt_index),.input_last_o(fmt_last),
    .done_valid_o(fmt_done),.done_ready_i(fmt_ack),.done_code_o(fmt_code),.done_id_o(fmt_done_id));
  assign fmt_req_ready=hash_live && service_i.raw_ready && !fault_o;
  assign fmt_ack=(state==HASH_WAIT || state==DRAIN) && fmt_done && !fault_o && !pack_active_r && !read_pending_r &&
    ((raw_retired_r && service_i.active==0) || (!raw_started_r && fmt_code!=0));
  assign pack_out_fire=service_i.pack.output_valid && service_o.pack.output_ready;
  assign pack_done_fire=service_i.pack.done_valid && service_o.pack.done_ready;
  assign raw_fire=service_i.raw_output_valid && service_o.raw_output_ready;
  assign raw_done_fire=service_i.raw_done_valid && service_o.raw_done_ready;
  always_comb begin
    service_o='0;
    service_o.pack.command_valid=state==PACK_START && !fault_o;service_o.pack.command_op=3;
    service_o.pack.command_param=param_r;service_o.pack.command_id=id_r;
    service_o.pack.input_valid=!fault_o && pack_active_r && (state==FEED || (state==DRAIN && sent_r<256));
    service_o.pack.input_data=state==DRAIN?23'd0:cache_r[23*lane_r+:23];
    service_o.pack.input_index=sent_r[7:0];service_o.pack.input_last=sent_r==255;
    service_o.pack.output_ready=hash_live && pack_active_r && !fault_o && (state==DRAIN || fmt_payload_ready);
    service_o.pack.done_ready=hash_live && pack_active_r && !fault_o &&
      (state==PACK_WAIT || state==DRAIN || service_i.pack.done_code!=0 || service_i.pack.done_id!=id_r);
    service_o.read_valid=state==READ_REQ && !fault_o;{service_o.read_bank,service_o.read_region}=high_r[poly_r];
    service_o.read_word=word_r;service_o.response_ready=!fault_o && (state==READ_RESP || (state==DRAIN && read_pending_r));
    service_o.raw_valid=hash_live && fmt_request && !fault_o;service_o.raw_mode=fmt_mode;service_o.raw_id=fmt_id;
    service_o.raw_message_len=fmt_length;service_o.raw_output_len=fmt_outlen;
    service_o.raw_input_valid=hash_live && fmt_input && !fault_o;service_o.raw_input_data=fmt_data;
    service_o.raw_output_ready=hash_live && raw_started_r && !fault_o;
    service_o.raw_done_ready=hash_live && raw_started_r && !raw_retired_r && !fault_o;
    service_o.job_valid=state==SAMPLE_START && !fault_o;service_o.job_mode=3;service_o.job_param=param_r;
    service_o.job_id=id_r;{service_o.job_bank,service_o.job_region}=dest_r;service_o.message_len=16'(bytes_r);
    service_o.input_valid=state==SAMPLE_INPUT && !fault_o;service_o.input_data=digest_r[64*sample_word_r+:64];
    service_o.status_ready=state==SAMPLE_WAIT && !sample_retired_r && !fault_o;
    service_o.release_valid=state==CLEAN && owned_r && !fault_o;
    {service_o.release_bank,service_o.release_region}=dest_r;
  end
  always_comb begin
    new_code=0;new_detail=0;
    if(state==READ_RESP && service_i.response_valid && (service_i.response_error ||
      {service_i.response_bank,service_i.response_region}!=high_r[poly_r] || service_i.response_word!=word_r ||
      service_i.response_id!=source_id_r || service_i.response_mode!=0 || service_i.response_param!=param_r || service_i.response_ntt_domain))new_code=3;
    if(pack_out_fire && state!=DRAIN && bad_pack_output)new_code=6;
    if(pack_done_fire && state!=DRAIN)begin
      if(service_i.pack.done_code!=0)begin new_code=4;new_detail=service_i.pack.done_code;end
      else if(service_i.pack.done_id!=id_r || sent_r!=256 || pack_words_r!=words_per_poly)new_code=6;
    end
    if(raw_fire && (service_i.raw_output_id!=id_r || service_i.raw_output_core!=raw_core_r ||
      service_i.raw_output_bytes!=16 || raw_count_r>=bytes_r || raw_retired_r))new_code=6;
    if(raw_done_fire && (service_i.raw_done_id!=id_r || service_i.raw_done_core!=raw_core_r ||
      raw_count_r+(raw_fire?7'd16:7'd0)!=bytes_r))new_code=6;
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;id_r<=0;source_id_r<=0;regions_r<=0;high_r<=0;mu_r<=0;digest_r<=0;
      rows_r<=0;poly_r<=0;word_r<=0;scan_r<=0;dest_r<=0;cache_r<=0;lane_r<=0;sent_r<=0;
      pack_words_r<=0;body_words_r<=0;bytes_r<=0;raw_count_r<=0;sample_word_r<=0;code_r<=0;detail_r<=0;
      pack_active_r<=0;read_pending_r<=0;raw_started_r<=0;raw_retired_r<=0;raw_core_r<=0;
      sample_core_r<=0;sample_retired_r<=0;owned_r<=0;clearing_r<=0;fault_o<=0;
    end else if(state!=IDLE && (service_i.fault || ((state!=REPORT || code_r==0) &&
      (!context_valid_i || context_param_i!=param_r || context_id_i!=source_id_r || context_regions_i!=regions_r))))begin fault_o<=1;state<=HALT;end
    else begin
      if(service_o.read_valid && service_i.read_ready)read_pending_r<=1;
      if(service_i.response_valid && service_o.response_ready)read_pending_r<=0;
      if(service_o.pack.input_valid && service_i.pack.input_ready)sent_r<=sent_r+1'b1;
      if(pack_out_fire)pack_words_r<=pack_words_r+1'b1;
      if(pack_done_fire)pack_active_r<=0;
      if(fmt_payload && fmt_payload_ready && fmt_payload_bytes==8)body_words_r<=body_words_r+1'b1;
      if(service_o.raw_valid && service_i.raw_ready)begin raw_started_r<=1;raw_core_r<=service_i.raw_core;end
      if(raw_fire)begin if(raw_count_r<bytes_r)digest_r[8*raw_count_r+:128]<=service_i.raw_output_data;raw_count_r<=raw_count_r+16;end
      if(raw_done_fire)raw_retired_r<=1;
      case(state)
        IDLE:if(command_valid_i && command_ready_o)begin
          param_r<=context_param_i;id_r<=command_id_i;source_id_r<=context_id_i;regions_r<=context_regions_i;
          high_r<=context_high_i;mu_r<=context_mu_i;rows_r<=command_rows;bytes_r<=context_param_i==0?7'd32:(context_param_i==1?7'd48:7'd64);
          digest_r<=0;poly_r<=0;word_r<=0;scan_r<=0;sent_r<=0;pack_words_r<=0;body_words_r<=0;raw_count_r<=0;
          pack_active_r<=0;read_pending_r<=0;raw_started_r<=0;raw_retired_r<=0;sample_retired_r<=0;owned_r<=0;
          code_r<=0;detail_r<=0;clearing_r<=0;
          if(!context_valid_i || context_param_i==3 || bad_source)begin code_r<=1;state<=REPORT;end
          else state<=CHECK;
        end
        CHECK:if(!quiescent || (service_i.reserved & regions_r)!=regions_r || (service_i.complete & regions_r)!=regions_r)begin code_r<=1;state<=REPORT;end
          else if(service_i.pack.command_ready)state<=FIND; // readiness may be backpressured
        FIND:if(!service_i.reserved[scan_r])begin dest_r<=scan_r;state<=FMT_START;end
          else if(scan_r==63)begin code_r<=2;state<=REPORT;end else scan_r<=scan_r+1'b1;
        FMT_START:if(fmt_ready)state<=PACK_START;
        PACK_START:if(service_i.pack.command_ready)begin pack_active_r<=1;sent_r<=0;pack_words_r<=0;word_r<=0;lane_r<=0;state<=READ_REQ;end
        READ_REQ:if(service_i.read_ready)state<=READ_RESP;
        READ_RESP:if(service_i.response_valid)begin cache_r<=service_i.response_data;lane_r<=0;state<=FEED;end
        FEED:if(service_i.pack.input_ready)begin
          if(sent_r==255)state<=PACK_WAIT;
          else if(lane_r==3)begin word_r<=word_r+1'b1;state<=READ_REQ;end else lane_r<=lane_r+1'b1;
        end
        PACK_WAIT:if(pack_done_fire)begin
          if(poly_r==rows_r-1'b1)state<=HASH_WAIT;else begin poly_r<=poly_r+1'b1;state<=PACK_START;end
        end
        HASH_WAIT:if(fmt_ack)begin
          if(fmt_code!=0 || fmt_done_id!=id_r)begin code_r<=6;state<=CLEAN;end
          else state<=SAMPLE_START;
        end
        DRAIN:if(fmt_ack)state<=CLEAN;
        SAMPLE_START:if(service_i.job_ready)begin sample_core_r<=service_i.job_core;sample_word_r<=0;state<=SAMPLE_INPUT;end
        SAMPLE_INPUT:if(service_i.input_ready)begin
          if(8*(sample_word_r+1)>=bytes_r)state<=SAMPLE_WAIT;else sample_word_r<=sample_word_r+1'b1;
        end
        SAMPLE_WAIT:begin
          if(service_i.status_valid && service_o.status_ready)begin
            sample_retired_r<=1;
            if(service_i.status_id!=id_r || service_i.status_core!=sample_core_r)code_r<=6;
            else if(service_i.status_code!=0)begin code_r<=5;detail_r<=service_i.status_code;end
          end
          if(sample_retired_r && service_i.active==0)begin
            owned_r<=service_i.reserved[dest_r];
            if(service_i.reserved[dest_r] && !service_i.complete[dest_r])begin fault_o<=1;state<=HALT;end
            else if(code_r!=0 || !service_i.reserved[dest_r] || !service_i.complete[dest_r])begin
              if(code_r==0)code_r<=6;state<=CLEAN;
            end else state<=REPORT;
          end
        end
        REPORT:if(done_ready_i)state<=code_r==0?READY:IDLE;
        READY:if(clear_valid_i && clear_ready_o)begin clearing_r<=1;state<=CLEAN;end
          else if(take_valid_i && take_ready_o)begin owned_r<=0;digest_r<=0;state<=IDLE;end
        CLEAN:if(!owned_r || service_i.release_ready)begin owned_r<=0;digest_r<=0;state<=clearing_r?IDLE:REPORT;end
        HALT:state<=HALT;
        default:begin fault_o<=1;state<=HALT;end
      endcase
      if(hash_live && new_code!=0 && code_r==0)begin code_r<=new_code;detail_r<=new_detail;state<=DRAIN;end
    end
  end
endmodule
`default_nettype wire
