// Adopt matrix/challenge results atomically,retire dead yhat,and FNTT(c).
// The outer owner preserves key/raw-y leases. No polynomial payload storage.
`default_nettype none
module sign_challenge_transform (
  input wire logic clk,rst,command_valid_i,output logic command_ready_o,busy_o,fault_o,
  input wire logic [15:0] command_id_i,
  input wire logic key_valid_i,mask_valid_i,input wire logic [1:0] param_i,
  input wire logic [15:0] key_id_i,mask_id_i,
  input wire logic [63:0] key_regions_i,mask_regions_i,
  input wire logic matrix_valid_i,input wire logic [15:0] matrix_id_i,
  input wire logic [63:0] matrix_regions_i,
  input wire logic [6:0][5:0] matrix_yhat_i,
  input wire logic [7:0][5:0] matrix_low_i,matrix_high_i,
  input wire logic challenge_valid_i,input wire logic [15:0] challenge_id_i,
  input wire logic [5:0] challenge_region_i,input wire logic [6:0] challenge_bytes_i,
  input wire logic [511:0] challenge_ctilde_i,
  output logic matrix_take_valid_o,challenge_take_valid_o,
  input wire logic matrix_take_ready_i,challenge_take_ready_i,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic [2:0] done_code_o,done_detail_o,output logic [15:0] done_id_o,
  output logic result_valid_o,output logic [63:0] result_regions_o,
  output logic [7:0][5:0] result_low_o,result_high_o,
  output logic [15:0] result_matrix_id_o,
  output logic [5:0] result_chat_o,output logic [511:0] result_ctilde_o,
  output logic [6:0] result_bytes_o,
  input wire logic clear_valid_i,output logic clear_ready_o,
  input wire logic take_valid_i,output logic take_ready_o,
  output dilithium_service_pkg::request_t service_o,
  input wire dilithium_service_pkg::response_t service_i
);
  typedef enum logic [3:0] {IDLE,CHECK,TAKE,DROP_HATS,FIND,NTT_START,NTT_WAIT,
    NTT_RETIRE,DROP_C,REPORT,READY,CLEAN,HALT} state_e;
  state_e state;
  logic [1:0] param_r;logic [15:0] id_r,key_id_r,mask_id_r,matrix_id_r,cid_r;
  logic [63:0] key_r,mask_r,matrix_r,hats_r,owned_r;
  logic [6:0][5:0] yhat_r;logic [7:0][5:0] low_r,high_r;
  logic [5:0] c_r,chat_r,scan_r;logic [511:0] ctilde_r;logic [6:0] bytes_r;
  logic [2:0] code_r,detail_r;logic adopted_r,clearing_r;
  logic [63:0] input_hats,input_outputs,input_all;logic layout_bad,quiescent,source_changed;
  logic [3:0] rows,columns;
  always_comb begin
    rows=param_i==0?4'd4:(param_i==1?4'd6:4'd8);
    columns=param_i==0?4'd4:(param_i==1?4'd5:4'd7);
    input_hats=0;input_outputs=0;layout_bad=0;
    for(int j=0;j<7;j++)if(j<int'(columns))begin
      if(input_hats[matrix_yhat_i[j]])layout_bad=1;
      input_hats[matrix_yhat_i[j]]=1;
    end
    for(int j=0;j<8;j++)if(j<int'(rows))begin
      if(input_outputs[matrix_low_i[j]])layout_bad=1;
      input_outputs[matrix_low_i[j]]=1;
      if(input_outputs[matrix_high_i[j]])layout_bad=1;
      input_outputs[matrix_high_i[j]]=1;
    end
    input_all=input_hats|input_outputs|(64'd1<<challenge_region_i);
    layout_bad|=(input_hats & input_outputs)!=0 ||
      (input_hats|input_outputs)!=matrix_regions_i || matrix_regions_i[challenge_region_i] ||
      (input_all & (key_regions_i|mask_regions_i))!=0 || (key_regions_i & mask_regions_i)!=0 ||
      challenge_bytes_i!=(param_i==0?7'd32:(param_i==1?7'd48:7'd64)) ||
      (param_i==0 && challenge_ctilde_i[511:256]!=0) || (param_i==1 && challenge_ctilde_i[511:384]!=0);
  end
  assign quiescent=service_i.active==0 && !service_i.op_busy && !service_i.process_busy &&
    !service_i.sign.busy && !service_i.load.busy && !service_i.row_busy &&
    service_i.pack.command_ready && !service_i.pack.output_valid && !service_i.pack.done_valid &&
    !service_i.response_valid && service_i.read_ready;
  assign source_changed=!matrix_valid_i || !challenge_valid_i || matrix_id_i!=matrix_id_r ||
    matrix_regions_i!=matrix_r || matrix_yhat_i!=yhat_r || matrix_low_i!=low_r || matrix_high_i!=high_r ||
    challenge_id_i!=cid_r || challenge_region_i!=c_r || challenge_bytes_i!=bytes_r || challenge_ctilde_i!=ctilde_r;
  assign command_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault;
  assign busy_o=state!=IDLE;assign done_valid_o=!rst && state==REPORT && !fault_o;
  assign done_code_o=code_r;assign done_detail_o=detail_r;assign done_id_o=id_r;
  assign result_valid_o=!rst && !fault_o && ((state==REPORT && code_r==0) || state==READY);
  assign result_regions_o=result_valid_o?owned_r:64'd0;
  assign result_low_o=result_valid_o?low_r:'0;assign result_high_o=result_valid_o?high_r:'0;
  assign result_matrix_id_o=result_valid_o?matrix_id_r:16'd0;
  assign result_chat_o=result_valid_o?chat_r:6'd0;
  assign result_ctilde_o=result_valid_o?ctilde_r:512'd0;assign result_bytes_o=result_valid_o?bytes_r:7'd0;
  assign clear_ready_o=!rst && state==READY && quiescent && !fault_o && !service_i.fault;
  assign take_ready_o=clear_ready_o && !clear_valid_i;
  // Neither upstream may transfer alone. Both readiness signals are independent
  // of these valid signals;the outer owner routes this single atomic edge.
  assign matrix_take_valid_o=state==TAKE && quiescent && challenge_take_ready_i && !source_changed && !fault_o;
  assign challenge_take_valid_o=state==TAKE && quiescent && matrix_take_ready_i && !source_changed && !fault_o;
  always_comb begin
    service_o='0;
    service_o.release_valid=!fault_o && ((state==DROP_HATS && hats_r[scan_r]) ||
      state==DROP_C || (state==CLEAN && owned_r[scan_r]));
    {service_o.release_bank,service_o.release_region}=state==DROP_C?c_r:scan_r;
    service_o.op_valid=state==NTT_START && !fault_o;service_o.op=0;
    service_o.op_a_region=c_r;service_o.op_a_id=cid_r;
    service_o.op_dest_region=chat_r;service_o.op_id=id_r;
    service_o.op_done_ready=state==NTT_WAIT && !fault_o;
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;id_r<=0;key_id_r<=0;mask_id_r<=0;matrix_id_r<=0;cid_r<=0;
      key_r<=0;mask_r<=0;matrix_r<=0;hats_r<=0;owned_r<=0;yhat_r<=0;low_r<=0;high_r<=0;
      c_r<=0;chat_r<=0;scan_r<=0;ctilde_r<=0;bytes_r<=0;code_r<=0;detail_r<=0;
      adopted_r<=0;clearing_r<=0;fault_o<=0;
    end else if(state!=IDLE && (service_i.fault ||
      ((state!=REPORT || code_r==0) && (!key_valid_i || !mask_valid_i || param_i!=param_r ||
       key_id_i!=key_id_r || mask_id_i!=mask_id_r || key_regions_i!=key_r || mask_regions_i!=mask_r))))begin
      fault_o<=1;state<=HALT;
    end else case(state)
      IDLE:if(command_valid_i && command_ready_o)begin
        param_r<=param_i;id_r<=command_id_i;key_id_r<=key_id_i;mask_id_r<=mask_id_i;
        key_r<=key_regions_i;mask_r<=mask_regions_i;matrix_id_r<=matrix_id_i;cid_r<=challenge_id_i;
        matrix_r<=matrix_regions_i;hats_r<=input_hats;yhat_r<=matrix_yhat_i;low_r<=matrix_low_i;high_r<=matrix_high_i;
        c_r<=challenge_region_i;ctilde_r<=challenge_ctilde_i;bytes_r<=challenge_bytes_i;
        owned_r<=0;code_r<=0;detail_r<=0;adopted_r<=0;clearing_r<=0;scan_r<=0;chat_r<=0;
        if(!key_valid_i || !mask_valid_i || !matrix_valid_i || !challenge_valid_i || param_i==3 || layout_bad)begin
          code_r<=1;state<=REPORT;
        end else state<=CHECK;
      end
      CHECK:if(source_changed || (service_i.reserved & (key_r|mask_r|matrix_r|(64'd1<<c_r)))!=(key_r|mask_r|matrix_r|(64'd1<<c_r)) ||
        (service_i.complete & (key_r|mask_r|matrix_r|(64'd1<<c_r)))!=(key_r|mask_r|matrix_r|(64'd1<<c_r)))begin code_r<=1;state<=REPORT;end
        else if(quiescent)state<=TAKE;
      TAKE:if(source_changed)begin code_r<=1;state<=REPORT;end
        else if(matrix_take_valid_o && matrix_take_ready_i && challenge_take_valid_o && challenge_take_ready_i)begin
          owned_r<=matrix_r|(64'd1<<c_r);adopted_r<=1;scan_r<=0;state<=DROP_HATS;
        end
      DROP_HATS:if(!hats_r[scan_r] || service_i.release_ready)begin
        if(hats_r[scan_r])owned_r[scan_r]<=0;
        if(scan_r==63)begin scan_r<=0;state<=FIND;end else scan_r<=scan_r+1'b1;
      end
      FIND:if(!service_i.reserved[scan_r])begin chat_r<=scan_r;state<=NTT_START;end
        else if(scan_r==63)begin code_r<=2;scan_r<=0;state<=CLEAN;end else scan_r<=scan_r+1'b1;
      NTT_START:if(service_i.op_ready)state<=NTT_WAIT;
      NTT_WAIT:if(service_i.op_done_valid)begin
        // Sources are hidden by the physical child until done retirement.
        if(service_i.op_done_code!=0)begin code_r<=3;detail_r<=service_i.op_done_code;end
        else if(service_i.op_done_id!=id_r || service_i.op_done_region!=chat_r)code_r<=4;
        state<=NTT_RETIRE;
      end
      NTT_RETIRE:if(!service_i.op_busy)begin
        if(service_i.reserved[chat_r])owned_r[chat_r]<=1;
        if((service_i.reserved & owned_r)!=owned_r || (service_i.complete & owned_r)!=owned_r ||
          (service_i.reserved[chat_r] && !service_i.complete[chat_r]))begin fault_o<=1;state<=HALT;end
        else if(code_r!=0 || !service_i.reserved[chat_r] || !service_i.complete[chat_r])begin
          if(code_r==0)code_r<=4;scan_r<=0;state<=CLEAN;
        end else state<=DROP_C;
      end
      DROP_C:if(service_i.release_ready)begin owned_r[c_r]<=0;state<=REPORT;end
      REPORT:if(done_ready_i)state<=code_r==0?READY:IDLE;
      READY:if(clear_valid_i && clear_ready_o)begin clearing_r<=1;scan_r<=0;state<=CLEAN;end
        else if(take_valid_i && take_ready_o)begin owned_r<=0;adopted_r<=0;ctilde_r<=0;state<=IDLE;end
      CLEAN:if(!owned_r[scan_r] || service_i.release_ready)begin
        owned_r[scan_r]<=0;
        if(scan_r==63)begin ctilde_r<=0;adopted_r<=0;state<=clearing_r?IDLE:REPORT;end
        else scan_r<=scan_r+1'b1;
      end
      HALT:state<=HALT;
      default:begin fault_o<=1;state<=HALT;end
    endcase
  end
endmodule
`default_nettype wire
