`timescale 1ps/1ps
module tb_full_sign #(parameter bit NIST_VECTORS=0);
  localparam string STEM=NIST_VECTORS?"stage5_nist_sign":"stage5_full_sign";
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic start_valid_i=0,start_ready_o,busy_o;logic [1:0] start_op_i=0,start_param_i=0;
  logic [15:0] start_id_i=0,start_message_len_i=0;logic [8:0] start_context_len_i=0;
  logic [255:0] start_seed_i=0,start_rnd_i=0;
  logic sign_input_valid_i=0,sign_input_ready_o;logic [63:0] sign_input_data_i=0;
  logic [3:0] sign_input_bytes_i=8;logic [15:0] sign_input_index_i=0;logic sign_input_last_i=0;
  logic signature_valid_o,signature_ready_i=0,signature_last_o;logic [63:0] signature_data_o;
  logic [3:0] signature_bytes_o;logic [9:0] signature_index_o;logic [15:0] signature_id_o;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o,done_stage_o,done_detail_o;logic [15:0] done_id_o;
  logic [16:0] sign_attempts_o,sign_rejections_o,sign_next_nonce_o;
  logic key_valid_o,key_ready_i=0,key_type_o,key_last_o;logic [63:0] key_data_o;
  logic [3:0] key_bytes_o;logic [9:0] key_index_o;logic [15:0] key_id_o;
  logic row_result_valid_o,row_result_ready_i=0;logic [3:0] row_result_index_o;
  logic [5:0] row_result_region_o;logic [15:0] row_result_id_o;
  logic seed_valid_o;logic [255:0] rho_o,key_o;logic [511:0] rhoprime_o;
  logic read_valid_i=1,read_ready_o,response_valid_o,response_error_o;
  logic [1:0] read_bank_i=0,response_bank_o,response_mode_o,response_param_o;
  logic [3:0] read_region_i=0,response_region_o;logic [5:0] read_word_i=0,response_word_o;
  logic [91:0] response_data_o;logic [15:0] response_id_o;
  logic response_ntt_domain_o,response_small_o,response_ready_i=1;
  logic [63:0] reserved_o,complete_o;logic fault_o;
  dilithium #(.FULL_KEYGEN(1)) dut(.*);
  int case_no=-1,op,p,jid,flavor,injection,abort_phase,code,stage,detail,ctxlen,mlen;
  int fd,count,cycles=0,elapsed=0,frame=0,tail_wait=0,raw_absorbs=0;
  int commands=0,completions=0,aborts=0,input_words=0,signature_words=0,key_words=0,allocations=0,commits=0,releases=0;
  bit test_passed=0,monitor=0,abort_hit=0,held_sig=0,held_done=0,held_input=0,held_key=0;
  logic [94:0] sig_snapshot;logic [75:0] done_snapshot;logic [84:0] input_snapshot;
  logic [95:0] key_snapshot;
  always @(negedge clk)begin
    signature_ready_i=!rst && cycles%19>6;key_ready_i=!rst && cycles%13>3;
    if(signature_valid_o && signature_last_o && tail_wait<9)begin signature_ready_i=0;tail_wait++;end
    if(abort_phase==5 && signature_index_o>=13)signature_ready_i=0;
    if(abort_phase==6 && signature_last_o)signature_ready_i=0;
  end
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held_sig=0;held_done=0;held_input=0;held_key=0;end
    else if(monitor)begin
      elapsed++;if(elapsed>3000000)$fatal(1,"Full Sign watchdog case%0d main%0d sign%0d key%0d attempt%0d stage%0d",case_no,dut.state,dut.g_sign.signer.state,dut.g_sign.signer.keys.state,dut.g_sign.signer.attempt.state,dut.g_sign.signer.attempt.stage_r);
      if(fault_o && abort_phase!=8)$fatal(1,"Full Sign unexpected fault case%0d",case_no);
      if(dut.keygen_owner && dut.sign_owner)$fatal(1,"Main granted two owners");
      if(dut.keygen_owner && dut.shared_request!==dut.keygen_request)$fatal(1,"KeyGen routing");
      if(dut.sign_owner && (dut.shared_request!==dut.sign_request || read_ready_o || response_valid_o || !busy_o))$fatal(1,"Sign/debug service isolation");
      if(!dut.keygen_owner && !dut.sign_owner && dut.shared_request!=='0)$fatal(1,"Unowned main request");
      if(busy_o && start_ready_o)$fatal(1,"Busy main accepted new work");
      if(signature_valid_o && (!dut.sign_owner || key_valid_o))$fatal(1,"Signature output ownership");
      if(held_sig && !fault_o && (!signature_valid_o || sig_snapshot!=={signature_id_o,signature_index_o,signature_bytes_o,signature_last_o,signature_data_o}))$fatal(1,"Stalled signature changed");
      held_sig=signature_valid_o && !signature_ready_i;sig_snapshot={signature_id_o,signature_index_o,signature_bytes_o,signature_last_o,signature_data_o};
      if(held_done && (!done_valid_o || done_snapshot!=={done_id_o,done_code_o,done_stage_o,done_detail_o,sign_attempts_o,sign_rejections_o,sign_next_nonce_o}))$fatal(1,"Held main completion changed");
      held_done=done_valid_o && !done_ready_i;done_snapshot={done_id_o,done_code_o,done_stage_o,done_detail_o,sign_attempts_o,sign_rejections_o,sign_next_nonce_o};
      if(held_input && !done_valid_o && !fault_o && (!sign_input_valid_i || input_snapshot!=={sign_input_index_i,sign_input_bytes_i,sign_input_last_i,sign_input_data_i}))$fatal(1,"Host changed stalled input");
      held_input=sign_input_valid_i && !sign_input_ready_o && !done_valid_o && !fault_o;input_snapshot={sign_input_index_i,sign_input_bytes_i,sign_input_last_i,sign_input_data_i};
      if(held_key && (!key_valid_o || key_snapshot!=={key_id_o,key_type_o,key_index_o,key_bytes_o,key_last_o,key_data_o}))$fatal(1,"Mixed-operation stalled key changed");
      held_key=key_valid_o && !key_ready_i;key_snapshot={key_id_o,key_type_o,key_index_o,key_bytes_o,key_last_o,key_data_o};
      if(start_valid_i && start_ready_o)begin
        $fdisplay(fd,"C %0d %0d %0d %0d %0d %0d %064h %064h",case_no,start_op_i,start_param_i,start_id_i,start_context_len_i,start_message_len_i,start_rnd_i,start_seed_i);commands++;
      end
      if(sign_input_valid_i && sign_input_ready_o)begin
        $fdisplay(fd,"I %0d %0d %0d %0d %0d %016h",case_no,frame,sign_input_index_i,sign_input_bytes_i,sign_input_last_i,sign_input_data_i);input_words++;
        if(abort_phase==1 && frame==0 && sign_input_index_i==8)abort_hit=1;
      end
      if(signature_valid_o && signature_ready_i)begin
        $fdisplay(fd,"S %0d %0d %0d %0d %0d %016h",case_no,signature_id_o,signature_index_o,signature_bytes_o,signature_last_o,signature_data_o);signature_words++;
      end
      if(key_valid_o && key_ready_i)begin
        $fdisplay(fd,"K %0d %0d %0d %0d %0d %0d %016h",case_no,key_id_o,key_type_o,key_index_o,key_bytes_o,key_last_o,key_data_o);key_words++;
      end
      if(dut.sign_owner && dut.g_sign.signer.attempt.cv[0] && dut.g_sign.signer.attempt.cr[0])
        $fdisplay(fd,"N %0d %0d %0d",case_no,dut.g_sign.signer.attempt.attempts_o+1,dut.g_sign.signer.attempt.nonce_r);
      if(dut.shared_request.raw_input_valid && dut.shared_response.raw_input_ready)begin
        raw_absorbs++;if(abort_phase==3 && raw_absorbs==12)abort_hit=1;
      end
      if(abort_phase==2 && dut.g_sign.signer.keys.state==5 && dut.g_sign.signer.keys.ordinal_r==3)abort_hit=1;
      if(abort_phase==4 && dut.g_sign.signer.attempt.retry_r && dut.g_sign.signer.attempt.stage_r==0 &&
        dut.services.datapath.subsystem.store.write_fire && dut.services.datapath.subsystem.store.write_index_i==31)abort_hit=1;
      if(dut.services.datapath.subsystem.store.alloc_fire)begin
        $fdisplay(fd,"A %0d %0d %0d %0d %0d %0d %016h",case_no,dut.services.datapath.subsystem.store.alloc_region,
          dut.services.datapath.subsystem.store.alloc_rewrite_i,dut.services.datapath.subsystem.store.alloc_id_i,
          dut.services.datapath.subsystem.store.alloc_mode_i,dut.services.datapath.subsystem.store.alloc_param_i,
          dut.services.datapath.subsystem.store.reserved_o);allocations++;
      end
      if(dut.services.datapath.subsystem.store.finish_fire)begin
        $fdisplay(fd,"M %0d %0d %0d %0d %0d",case_no,dut.services.datapath.subsystem.store.finish_region,
          dut.services.datapath.subsystem.store.finish_id_i,dut.services.datapath.subsystem.store.finish_code_i,
          dut.services.datapath.subsystem.store.count_r[dut.services.datapath.subsystem.store.finish_region]);commits++;
      end
      if(dut.services.datapath.subsystem.store.release_fire)begin
        $fdisplay(fd,"F %0d %0d",case_no,dut.services.datapath.subsystem.store.release_region);releases++;
      end
    end
  end
  task automatic reset_all();
    release dut.services.datapath.subsystem.store.fault_o;
    rst=1;monitor=0;start_valid_i=0;sign_input_valid_i=0;done_ready_i=0;abort_hit=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || reserved_o || complete_o || fault_o || signature_valid_o || !start_ready_o)$fatal(1,"Full Sign reset ownership");
  endtask
  task automatic send_frame(input int kind,input string hexbytes);
    int length,parsed,valid,index;byte unsigned value;
    length=hexbytes=="-"?0:hexbytes.len()/2;frame=kind;
    for(int w=0;w<(length+7)/8;w++)begin
      if(rst || done_valid_o || fault_o)return;
      if(w%9==2)begin @(negedge clk);#1;if(rst || done_valid_o || fault_o)return;end
      sign_input_data_i='1;valid=length-8*w>=8?8:length-8*w;
      for(int j=0;j<valid;j++)begin parsed=$sscanf(hexbytes.substr(2*(8*w+j),2*(8*w+j)+1),"%h",value);if(parsed!=1)$fatal(1,"Full Sign byte parse");sign_input_data_i[8*j+:8]=value;end
      sign_input_bytes_i=4'(valid);sign_input_index_i=16'(w);sign_input_last_i=8*(w+1)>=length;
      if(kind==0)begin
        if(injection==1 && w==2)sign_input_index_i=16'd1026;
        if(injection==2 && w==0)sign_input_bytes_i=0;
        if(injection==3 && w==17)sign_input_last_i=1;
        if(injection==4 && sign_input_last_i)sign_input_last_i=0;
        if(injection==5 && w==16)sign_input_data_i[7:0]=8'hff;
      end else begin
        if(injection==6 && w==0)sign_input_index_i=9;
        if(injection==7 && w==0)sign_input_bytes_i=0;
        if(injection==8 && w==0)sign_input_last_i=1;
        if(injection==9 && sign_input_last_i)sign_input_last_i=0;
      end
      sign_input_valid_i=1;
      do @(posedge clk);while(!sign_input_ready_o && !rst && !done_valid_o && !fault_o);
      @(negedge clk);#1;sign_input_valid_i=0;
    end
  endtask
  task automatic refuse_busy();
    while(dut.g_sign.signer.state!=5 && !rst)begin @(negedge clk);#1;end
    if(rst)return;start_valid_i=1;
    repeat(4)begin @(posedge clk);if(start_ready_o)$fatal(1,"Busy offer accepted");end
    @(negedge clk);#1;start_valid_i=0;$fdisplay(fd,"REFUSE %0d 4",case_no);
  endtask
  initial begin
    int f,cleanup_cycles;string directory,token,skhex,bodyhex;logic [255:0] rnd,xi;bit hit;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/",STEM,"_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d",token,count)!=2)$fatal(1,"Prepare full Sign fixtures");
    fd=$fopen({directory,"/",STEM,"_outputs.txt"},"w");$fdisplay(fd,"H %s",token);reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %d %d %d %d %d %d %h %h %s %s",case_no,op,p,jid,flavor,injection,abort_phase,code,stage,detail,ctxlen,mlen,rnd,xi,skhex,bodyhex)!=16 || case_no!=c)$fatal(1,"Full Sign fixture");
      elapsed=0;raw_absorbs=0;tail_wait=0;abort_hit=0;monitor=1;
      start_op_i=2'(op);start_param_i=2'(p);start_id_i=16'(jid);start_seed_i=xi;start_rnd_i=rnd;
      start_message_len_i=16'(mlen);start_context_len_i=9'(ctxlen);start_valid_i=1;
      do @(posedge clk);while(!start_ready_o);@(negedge clk);#1;start_valid_i=0;
      // The operation must use the accepted metadata,not these later values.
      start_param_i=3;start_id_i=16'(jid)^16'hbeef;start_op_i=3;start_seed_i='1;start_rnd_i='1;start_message_len_i=65535;start_context_len_i=511;
      if(op==1 && code!=1)fork begin send_frame(0,skhex);if(!rst && !done_valid_o && !fault_o)send_frame(1,bodyhex);end join_none
      if(op==1 && code==0 && abort_phase==0)fork refuse_busy();join_none
      if(abort_phase!=0)begin
        hit=0;while(!hit)begin
          @(negedge clk);#1;
          case(abort_phase)
            1,2,3,4:hit=abort_hit;
            5:hit=signature_valid_o && signature_index_o==13 && !signature_ready_i;
            6:hit=signature_valid_o && signature_last_o && !signature_ready_i;
            7:hit=done_valid_o;
            8:if(dut.g_sign.signer.state==8 && dut.g_sign.signer.encoder.state==6 && dut.g_sign.signer.encoder.hints_r && dut.shared_response.response_valid)begin force dut.services.datapath.subsystem.store.fault_o=1'b1;repeat(3)@(negedge clk);#1;hit=1;if(!fault_o || done_valid_o || start_ready_o)$fatal(1,"Fatal Sign escaped");end
            9:hit=dut.g_sign.signer.encoder.hints_r && dut.g_sign.signer.encoder.state==6 && dut.shared_response.response_valid;
          endcase
          if(done_valid_o && abort_phase!=7)$fatal(1,"Full Sign abort missed phase%0d",abort_phase);
        end
        if(abort_phase==7)repeat(7)@(negedge clk);#1;
        $fdisplay(fd,"Z %0d %0d %0d %0d %0d %016h %0d %0d %0d",case_no,abort_phase,dut.state,dut.g_sign.signer.state,fault_o,
          dut.services.datapath.subsystem.store.reserved_o,sign_attempts_o,sign_rejections_o,sign_next_nonce_o);aborts++;reset_all();wait fork;
      end else begin
        while(!done_valid_o)begin @(negedge clk);#1;end
        repeat(9)@(negedge clk);#1;wait fork;
        if(done_id_o!=jid || done_code_o!=code || done_stage_o!=stage || done_detail_o!=detail)$fatal(1,"Full Sign completion case%0d got%0d/%0d/%0d expected%0d/%0d/%0d",case_no,done_code_o,done_stage_o,done_detail_o,code,stage,detail);
        if(op!=0 && reserved_o!=0)$fatal(1,"Sign completion before full cleanup");
        $fdisplay(fd,"D %0d %0d %0d %0d %0d %0d %0d %0d %016h",case_no,done_id_o,done_code_o,done_stage_o,done_detail_o,
          sign_attempts_o,sign_rejections_o,sign_next_nonce_o,dut.services.datapath.subsystem.store.reserved_o);completions++;
        done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
        cleanup_cycles=0;
        if(op==0)begin
          start_valid_i=1;
          while(dut.child_busy)begin if(start_ready_o)$fatal(1,"Main bypassed KeyGen cleanup");cleanup_cycles++;@(negedge clk);#1;end
          start_valid_i=0;if(cleanup_cycles==0)$fatal(1,"No KeyGen cleanup refusal");$fdisplay(fd,"GATE %0d %0d",case_no,cleanup_cycles);
        end
        while(!start_ready_o)begin @(negedge clk);#1;end
        if(reserved_o || complete_o || busy_o)$fatal(1,"Full Sign leaked work between requests");
        $fdisplay(fd,"B %0d 0000000000000000",case_no);
      end monitor=0;
      $display("%s progress:%0d/%0d commands",STEM,c+1,count);
    end
    $fdisplay(fd,"END %0d %0d %0d %0d %0d %0d %0d %0d %0d",commands,completions,aborts,input_words,signature_words,key_words,allocations,commits,releases);
    $fclose(f);$fclose(fd);
    if(NIST_VECTORS)$display("STAGE5N4H7_NIST_SIGN_CAPTURE_PASS:%0d commands,%0d completions,%0d aborts",commands,completions,aborts);
    else $display("STAGE5N4H6_FULL_SIGN_CAPTURE_PASS:%0d commands,%0d completions,%0d aborts",commands,completions,aborts);
    test_passed=1;$finish;
  end
  initial begin #(64'd4000000000000);$fatal(1,"Full Sign global watchdog case%0d",case_no);end
endmodule
