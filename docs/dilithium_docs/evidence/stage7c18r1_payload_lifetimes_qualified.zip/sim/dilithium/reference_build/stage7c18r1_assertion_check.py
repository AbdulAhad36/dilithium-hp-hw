from pathlib import Path
p=Path('sim/dilithium/stage7c18r1_assertion_negative.log')
s=p.read_text()
assert 'VERIFY_PREFIX_GUARD_FAULT_INJECTED' in s
assert '** Fatal: Verify digest overwrote Mu before prefix consumption' in s
assert 'LIGHTHD_MAIN_CAPTURE_PASS:9' not in s
print('C18R1_SIMULATION_ASSERTION_NEGATIVE_PASS:deliberate premature Mu overwrite rejected by actual production assertion;private incomplete capture is not NIST evidence')
