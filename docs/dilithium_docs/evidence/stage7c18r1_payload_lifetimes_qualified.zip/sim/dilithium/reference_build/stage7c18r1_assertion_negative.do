onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vlib sim/dilithium/work_c18r1_assertion_negative
vmap c18r1_assert_work sim/dilithium/work_c18r1_assertion_negative
set fd [open quartus/dilithium/dilithium_full.qsf r]
set settings [read $fd];close $fd
foreach line [split $settings "\n"] {
  if {[regexp {SYSTEMVERILOG_FILE\s+(.+)$} [string trim $line] -> source]} {
    vlog -sv -work c18r1_assert_work [file normalize [file join quartus/dilithium $source]]
  }
}
vlog -sv -work c18r1_assert_work sim/dilithium/reference_build/stage7c18r1_assertion_main.sv sim/dilithium/reference_build/stage7c18r1_assertion_negative.sv
vsim -L cyclonev_ver c18r1_assert_work.tb_c18r1_assertion_negative
onfinish stop
run -all
quit -f
