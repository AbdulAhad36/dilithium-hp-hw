from pathlib import Path
import re,json
q=Path('quartus/dilithium/critical_full');names=(q/'mapped_register_names.rpt').read_text().splitlines();result={}
for key,expr,lo,hi in [('unpacker_words',r'\|lighthd_bitunpkg:unpacker\|words_r',192,192),
 ('unpacker_slots',r'\|lighthd_bitunpkg:unpacker\|(read_slot_r|write_slot_r)',4,4),
 ('unpacker_offset',r'\|lighthd_bitunpkg:unpacker\|bit_offset_r',4,6),
 ('hint_mask',r'\|lighthd_hint_codec:.*\|d_registered_hints',4,4),
 ('hint_coordinates',r'\|lighthd_hint_codec:.*\|d_registered_(row|word)',9,9),
 ('hint_pending',r'\|lighthd_hint_codec:.*\|d_output_pending_r',1,1)]:
 hits=[n for n in names if re.search(expr,n)];assert lo<=len(hits)<=hi,(key,len(hits));result[key]=dict(bits=len(hits),names=hits)
assert 'WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS' in (q/'retained_registers.rpt').read_text()
Path('sim/dilithium/reference_build/stage7c18r1_stream_registers.json').write_text(json.dumps(result,indent=2)+'\n')
print('C18R1_STREAM_HARDWARE_GUARD_PASS:192word bits/ring state/registered hint mask and coordinates/pending bit retained')
