from pathlib import Path
import re,json
q=Path('quartus/dilithium/critical_full');h=Path('sim/dilithium/reference_build')
names=(q/'mapped_register_names.rpt').read_text().splitlines();result={}
for label,expr,lo,hi in [('raw_operands',r'\|lighthd_process_dma:process_path\|operand_[ab]_r',184,184),
                       ('word_tag',r'\|lighthd_process_dma:process_path\|operand_tag_r',6,7),
                       ('valid',r'\|lighthd_process_dma:process_path\|operand_valid_r',1,1)]:
    hits=[n for n in names if re.search(expr,n)];assert lo<=len(hits)<=hi,(label,len(hits))
    result[label]=dict(bits=len(hits),names=hits)
assert 'WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS' in (q/'retained_registers.rpt').read_text()
(h/'stage7c18r1_operand_registers.json').write_text(json.dumps(result,indent=2)+'\n')
print('C18R1_PROCESS_OPERAND_HW_GUARD_PASS:184 raw payload bits/word tag/valid physically retained')
