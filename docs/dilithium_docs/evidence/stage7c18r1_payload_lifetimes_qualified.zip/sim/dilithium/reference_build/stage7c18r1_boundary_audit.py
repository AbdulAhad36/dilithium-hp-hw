from pathlib import Path
import json,hashlib
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
a=json.loads((rb/'stage7c18_source_hashes.json').read_text());b=json.loads((rb/'stage7c18r1_source_hashes.json').read_text())
assert a.keys()==b.keys()
assert {n for n in a if a[n]!=b[n]}=={'src/controller/lighthd_verify.sv'}
snapshot=rb/'stage7c18r1_baseline_c18/lighthd_verify.sv'
assert hashlib.sha256(snapshot.read_bytes()).hexdigest()==a['src/controller/lighthd_verify.sv']
old=snapshot.read_text()
new=(r/'src/controller/lighthd_verify.sv').read_text()
new=new.replace('  // synthesis translate_off\n','').replace('  // synthesis translate_on\n','')
assert old==new
print('C18R1_ASSERTION_BOUNDARY_AUDIT_PASS:248/249files exact initial C18;remaining RTL exact after removing two synthesis-only directive comments')
