from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c17_source_hashes.json').read_text());new=json.loads((rb/'stage7c18r1_source_hashes.json').read_text())
for n,d in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
changed={n for n in old if old[n]!=new[n]}
assert changed=={'src/controller/process/lighthd_process.sv','src/controller/process/lighthd_bitunpkg.sv','src/controller/lighthd_verify.sv','tb/tb_dilithium/tb_lighthd_bitunpkg_ring.sv','sim/dilithium/dilithium_vectors.py','quartus/dilithium/report_full.tcl'},changed
assert len(new)==249 and len(set(new)-set(old))==4
for stem,path in [('lighthd_process','src/controller/process/'),('lighthd_verify','src/controller/')]:
 ref=(r/('tb/tb_dilithium/'+stem+'_c17_reference.sv')).read_text().replace('module '+stem+'_c17_reference (','module '+stem+' (')
 assert any(hashlib.sha256(b).hexdigest()==old[path+stem+'.sv'] for b in (ref.encode(),ref.replace('\n','\r\n').encode())),stem
print('C18R1_SOURCE_AUDIT_PASS:249files/3RTL/explicit proof-fingerprint-guards;engines/QSF/SDC exact C17')
