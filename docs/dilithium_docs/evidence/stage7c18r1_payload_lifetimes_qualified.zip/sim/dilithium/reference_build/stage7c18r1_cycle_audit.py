from pathlib import Path
from collections import defaultdict
from statistics import mean
import csv,json
h=Path('sim/dilithium');base=h/'reference_build/stage7c18r1_baseline_c17'
report=[];groups=defaultdict(list);details=[]
for leaf,footer in [('stage7c4_main_outputs.txt','F 210'),('stage7c4_main_protocol_outputs.txt','F 88')]:
    a=(base/leaf).read_text().splitlines();b=(h/leaf).read_text().splitlines()
    assert a[-1]==b[-1]==footer and len(a)==len(b),(leaf,'incomplete capture')
    for x,y in zip(a[1:],b[1:]):
        u,v=x.split(),y.split();assert u[0]==v[0],(leaf,u,v)
        if u[0]=='J':serial,op,p=int(u[1]),int(u[2]),int(u[4])
        if u[0]=='D':
            assert u[:-1]==v[:-1],(leaf,'changed status/attempt/rejection/nonce',u,v)
            before,after=int(u[-1]),int(v[-1]);delta=after-before
            details.append(dict(capture=leaf,case=serial,operation=op,param=p,before=before,after=after,delta=delta))
            groups[leaf,op,p].append(delta)
        else:assert u==v,(leaf,'changed payload or control record',u,v)
    report.append(leaf+':all payload/status/attempt/rejection/nonce records EXACT C17;cycles measured separately')
old=list(csv.DictReader((base/'stage7_uvm_checked.csv').open()))
new=list(csv.DictReader((h/'stage7_uvm_checked.csv').open()))
assert len(old)==len(new)==30
for a,b in zip(old,new):assert all(a[k]==b[k] for k in a if k!='source_token'),(a,b)
old=list(csv.DictReader((base/'stage7_uvm_latency.csv').open()))
new=list(csv.DictReader((h/'stage7_uvm_latency.csv').open()));assert len(old)==len(new)==30
uvm=[]
for a,b in zip(old,new):
    assert all(a[k]==b[k] for k in ('case','op','param','id'))
    uvm.append(dict(case=int(a['case']),delta={k:int(b[k])-int(a[k]) for k in a if k not in ('case','op','param','id')}))
for (leaf,op,p),v in sorted(groups.items()):report.append(f'{leaf}:op{op}/level{(2,3,5)[p]} count{len(v)} delta cycles min{min(v)} mean{mean(v):.3f} max{max(v)}')
report.append('STAGE7C18R1_CYCLE_AUDIT_PASS:outputs unchanged;latency changes measured,not claimed zero')
(h/'reference_build/stage7c18r1_cycle_deltas.json').write_text(json.dumps(dict(native=details,UVM=uvm),indent=2)+'\n')
(h/'stage7c18r1_cycle_audit.log').write_text('\n'.join(report)+'\n');print('\n'.join(report))
