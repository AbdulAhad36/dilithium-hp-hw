`timescale 1ns/1ps
module tb_c18r1_assertion_negative;
  tb_c18r1_assertion_main mainbench();
  bit injected=0;
  `define V mainbench.dut.core.verify_controller
  always @(negedge mainbench.clk)if(!mainbench.rst && !injected &&
    `V.raw_phase && `V.state!=`V.MU_RUN && `V.service_i.raw.output_valid && `V.service_o.raw.output_ready)begin
    force `V.formatter.prefix_left_r=8'd1;
    injected=1;
    $display("VERIFY_PREFIX_GUARD_FAULT_INJECTED");
  end
endmodule
