"""Boolean/occupancy proof supplement;native ring test checks actual RTL."""
from itertools import product
groups=(16,24,40,48,52,64,72,80)
checked=valid=reject_ready_changes=0
for group,count,ready,bad,ended,input_valid,bad_frame in product(groups,range(145),range(2),range(2),range(2),range(2),range(2)):
    enough=count>=group
    offered=enough and not bad
    pop=offered and ready
    before=(not ended) and ((not offered) or ready) and (count<=80 or (pop and count<=80+group))
    after=(not ended) and ((not enough) or ready) and (count<=80 or (enough and ready and count<=80+group))
    old_push=before and input_valid;new_push=after and input_valid
    # Highest-priority invalid-field rejection applies on this same edge,
    # independently of a simultaneous transport/frame error.
    old_code=2 if enough and bad else 3 if old_push and bad_frame else 0
    new_code=2 if enough and bad else 3 if new_push and bad_frame else 0
    assert old_code==new_code
    if not (enough and bad):
        assert before==after
        assert count+64*new_push-group*pop<=144
        valid+=1
    elif before!=after:reject_ready_changes+=1
    checked+=1
assert reject_ready_changes>0
print(f'C18R1_ADMISSION_TRUTH_PROOF_PASS:{checked}combinations/{valid}nonreject exact timing/{reject_ready_changes}imminent-reject ready differences;error priority exact')
