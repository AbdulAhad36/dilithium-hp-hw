$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l sim/dilithium/stage7c21_foundation.log -do sim/dilithium/reference_build/stage7c21_foundation.do *> sim/dilithium/stage7c21_foundation_console.log
if ($LASTEXITCODE -ne 0) {throw 'Native foundation failed'}
foreach ($marker in @('LIGHTHD_CONTROLLER_LIFETIME_CYCLE_PASS:195757cycles/3Sign/3Verify/3full digests/3retry contexts','LIGHTHD_CONTROLLER_LIFETIME_CYCLE_PASS:972701cycles/14Sign/27Verify/15full digests/11retry contexts','LIGHTHD_SIGN_INPUT_CAPTURE_PASS','LIGHTHD_VERIFY_INPUT_CAPTURE_PASS','LIGHTHD_WRITER_QUEUE_STRESS_PASS:17batches/2178writes/34completions/4occupied-reset recoveries/8rejects', 'LIGHTHD_SAMPLER_WRITER_CAPTURE_PASS:112','LIGHTHD_HASH_SAMPLER_CAPTURE_PASS:104','LIGHTHD_VERIFY_DIGEST_LIFETIME_PASS:','LIGHTHD_UNPACK_READY_ISOLATION_PASS:','LIGHTHD_BITUNPKG_RING_CYCLE_PASS:','SHARED_HINT_REGISTERED_FINAL_STALL_PASS:','LIGHTHD_PROCESS_RANGE_EXHAUSTIVE_PASS:norm134217728','LIGHTHD_PROCESS_PASS:','LIGHTHD_PROCESS_OPERAND_STAGE_PASS:','LIGHTHD_MEMORY_DIRECT_DATA_PASS:400000','LIGHTHD_PROCESS_PHASE_PORT_PASS:2097152','SHARED_HINT_MODE_SWITCH_PASS:60','LIGHTHD_HINTPKG_PASS:packets43','LIGHTHD_PROCESS_DMA_PASS:cases64','BRAM_FIFO_PASS','LIGHTHD_DIRECT_MEMORY_PASS','LIGHTHD_NTT_DMA_CAPTURE_PASS','LIGHTHD_HINT_CAPTURE_PASS','LIGHTHD_MAIN_CAPTURE_PASS:9')) {
  if (-not (Select-String -LiteralPath sim/dilithium/stage7c21_foundation.log -Pattern $marker -Quiet)) {throw "Missing gate $marker"}
}
foreach ($gate in @('lighthd_owner_selftest','lighthd_sign_load_compare','lighthd_verify_input_compare','lighthd_main_protocol_compare','lighthd_writer_compare','lighthd_writer_mixed_compare','lighthd_chain_compare','lighthd_dma_compare','lighthd_hint_compare','lighthd_hint_selftest','lighthd_main_diagnostic_compare')) {
  & 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py $gate *> "sim/dilithium/stage7c21_${gate}.log"
  if ($LASTEXITCODE -ne 0) {throw "Foundation comparison failed: $gate"}
}
& 'C:/Python314/python.exe' sim/dilithium/reference_build/stage7c21_proof_reuse.py
if ($LASTEXITCODE -ne 0) {throw 'Unchanged arithmetic proof reuse failed'}
'STAGE7C21_FOUNDATION_RUNNER_PASS'
