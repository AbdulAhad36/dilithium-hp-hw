from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c20_source_hashes.json').read_text());new=json.loads((rb/'stage7c21_source_hashes.json').read_text())
for n,d in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
assert len(new)==256 and len(set(new)-set(old))==5
expected={'src/controller/'+n+'.sv' for n in ('lighthd_sign_input','lighthd_sign','lighthd_verify_input','lighthd_verify','lighthd_dilithium')}
expected|={'src/controller/process/lighthd_hint_codec.sv','tb/tb_dilithium/tb_lighthd_sign_input.sv','tb/tb_dilithium/tb_lighthd_verify_input.sv','sim/dilithium/dilithium_vectors.py','quartus/dilithium/report_full.tcl'}
assert {n for n in old if old[n]!=new[n]}==expected
print('C21_SOURCE_AUDIT_PASS:256frozen/6controller-hint RTL changes/2standalone pin declarations/5new reference-test files;arithmetic,QSF,SDC unchanged C20')
