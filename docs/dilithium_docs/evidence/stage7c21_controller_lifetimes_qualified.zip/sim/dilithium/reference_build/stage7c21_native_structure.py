from pathlib import Path
import json,re
h=Path('sim/dilithium');q=Path('quartus/dilithium')
s=(q/'output_full/dilithium_full.map.rpt').read_text();m=json.loads((h/'reference_build/stage7c21_metrics.json').read_text())
expected={'Independent 27x27':8,'Fixed Point Dedicated Pre-Adder':4,'Fixed Point Dedicated Output Adder Chain':4}
for label,wanted in expected.items():
 match=re.search(r';\s*'+re.escape(label)+r'\s*;\s*(\d+)',s)
 assert match and int(match[1])==wanted,(label,match)
assert m['area']['DSPs']==8
names=(q/'critical_full/mapped_register_names.rpt').read_text().splitlines()
counts={}
for key,expr in [('compact_input_selects',r'\|ntt_core:core\|operand_[ab]_sel_q'),('compact_return_selects',r'\|ntt_core:core\|return_select_[ab]')]:
 hits=[n for n in names if re.search(expr,n)]
 assert 0<len(hits)<=24,(key,len(hits))
 counts[key]={'active_original_bits':len(hits),'names':hits}
result={'mapped_hard_DSP_configuration':expected,'final_placed_DSPs':8,'decoder_registers':counts}
(h/'reference_build/stage7c21_native_structure.json').write_text(json.dumps(result,indent=2)+'\n')
print('C21_NATIVE_HARDWARE_GUARD_PASS:8 final DSPs/4 hard preadders/4 hard chainadders;'+','.join(k+'='+str(v['active_original_bits']) for k,v in counts.items()))
