$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
foreach($top in @('sign','verify')) {
  foreach($variant in @('baseline','lifetime')) {
    $folder="tmp/stage7c21_${top}_map_${variant}"
    Push-Location -LiteralPath $folder
    & F:/altera/quartus/bin64/quartus_map.exe probe -c probe --read_settings_files=on --write_settings_files=off *> map_console.log
    $code=$LASTEXITCODE
    Pop-Location
    if($code -ne 0){throw "Map failed: $folder"}
    "C21_MAP_PASS $top $variant"
  }
}
