from pathlib import Path
import json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
s=(rb/'stage7c20_archive.py').read_text(encoding='utf-8').replace('stage7c20','stage7c21').replace('C20_','C21_').replace('C20 execution','C21 execution').replace('C20 registered','C21 controller')
s=s.replace('stage7c21_registered_writer_qualified.zip','stage7c21_controller_lifetimes_qualified.zip')
s=s.replace("stage='7C.20 registered normal sampler-writer handoff'","stage='7C.21 local controller lifetime sharing and registered owner selection'")
s=s.replace("for leaf in ('c20_sampler_writer_probe.sv','tb_c20_sampler_writer_probe.sv','tb_c20_sampler_writer_mixed.sv','tb_c20_writer_queue.sv','c20_sampler_writer_probe.do','c20_writer_mixed.do','c20_writer_queue.do','c20_writer_probe_setup.py'):","for leaf in ('c21_prototypes.py','c21_probe_setup.py','c21_probe.do','c21_followup.do','tb_c21_lifetimes.sv','tb_c21_main_probe.sv','c21_input_setup.py','c21_inputs.do','c21_map_setup.py','c21_map_runner.ps1','c21_promote.py','c21_runner_setup.py','c21_probe_compare.py','c21_owner_proof.py'):")
s=s.replace("for leaf in ('stage7c18r1_metrics.json','stage7c18r1_area_inventory.json','stage7c18r1_source_hashes.json','stage7c18r1_throughput.json')", "for leaf in ('stage7c18r1_source_hashes.json','stage7c20_metrics.json','stage7c20_area_inventory.json','stage7c20_source_hashes.json','stage7c20_throughput.json')")
anchor="metrics=json.loads((rb/'stage7c21_metrics.json').read_text())"
extra="""# Earlier exhaustive proof is reused explicitly,never relabelled fresh.
paths.add('sim/dilithium/reference_build/stage7c20_baseline_c18r1/stage7c18r1_foundation.log')
for leaf in ('stage7c_sign_load_inputs.txt','stage7c_sign_load_expected.txt','stage7c3_sign_load_outputs.txt','stage7c4_verify_input_inputs.txt','stage7c4_verify_input_expected.txt','stage7c4_verify_input_outputs.txt'):
    paths.add('sim/dilithium/'+leaf)
# Private overridden-source probes are historical diagnostics,not current token captures.
for p in (r/'tmp').glob('*c21*.sv'):paths.add(p.relative_to(r).as_posix())
for p in (r/'tmp').glob('lighthd_*_c20_reference.sv'):paths.add(p.relative_to(r).as_posix())
for folder in ('stage7c21_sign_map_baseline','stage7c21_sign_map_lifetime','stage7c21_verify_map_baseline','stage7c21_verify_map_lifetime'):
    for p in (r/'tmp'/folder).rglob('*'):
        if p.is_file() and p.suffix in ('.qsf','.qpf','.rpt','.log','.summary'):paths.add(p.relative_to(r).as_posix())

"""
s=s.replace(anchor,extra+anchor)
s=s.replace(" writer_physical_guards=json.loads", " controller_lifetime_guards=json.loads((rb/'stage7c21_lifetime_registers.json').read_text()),\n controller_cycle_checks=dict(diagnostic_clocks=195757,protocol_clocks=972701,owner_model_combinations=65536),\n writer_physical_guards=json.loads")
s=s.replace("private_probes='Prepromotion diagnostic fingerprints/logs preserved;initial stress-driver expected-index bug corrected before promotion'", "private_probes='Diagnostic9/protocol88/default input135-105/hint106-shared60 pass;initial declaration/standalone wildcard binding errors retained as failed trials'")
s=s.replace("memory_contract='RAM request acceptance/ordering/collisions unchanged;normal packet acceptance decoupled with214bit shared handoff'", "memory_contract='Polynomial RAM/collision rules and214bit writer handoff unchanged;Sign TR->Mu,key-rnd->mask;Verify TR->Mu->digest;standalone snapshot defaults preserved'")
s=s.replace("remaining_work='Under20000 ALMs/148MHz and broader controller storage optimization remain unaccepted targets'", "remaining_work='Under20000 actual placed ALMs/148MHz remain unaccepted targets;use new final critical paths and disjoint area scopes'")
replay=(rb/'stage7c20_archive_replay.py').read_text(encoding='utf-8').replace('stage7c20','stage7c21').replace('C20_','C21_').replace('registered_writer','controller_lifetimes')
replay=replay.replace("('lighthd_writer_compare'","('lighthd_owner_selftest','lighthd_sign_load_compare','lighthd_verify_input_compare','lighthd_writer_compare'")
changes={'sim/dilithium/reference_build/stage7c21_archive.py':s,'sim/dilithium/reference_build/stage7c21_archive_replay.py':replay}
print(json.dumps('*** Begin Patch\n'+''.join('*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in v.splitlines()) for n,v in changes.items())+'*** End Patch'))
