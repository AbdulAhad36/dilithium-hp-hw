from itertools import product
from pathlib import Path
import hashlib,json
source=Path('tmp/c21_lighthd_dilithium.sv')
s=source.read_text();count=0
assert 'state==RETIRE && !(child_ready && response.idle)' in s
assert 'if(fault_o || (state==EXECUTE && child_done && child_id!=id_r))owner_select_next=0;' in s
assert 'Registered main owner differs from original state decode' in s
# Independent next-state model,including invalid enum states,command errors,
# done backpressure,retirement and fault/mismatched child-ID quarantine.
for state,op,start,fire,badop,badcmd,done,take,ready,idle,fault,wrong in product(range(8),range(4),range(4),*[range(2)]*9):
 nextstate=state;nextop=op
 if state==0:
  if fire:nextop=start;nextstate=3 if badop or badcmd else 1
 elif state==1:
  if done and take:nextstate=2
 elif state==2:
  if ready and idle:nextstate=0
 elif state==3:
  if take:nextstate=0
 else:nextstate=4
 if fault or (state==1 and done and wrong):nextstate=4
 original=(1<<nextop) if nextstate in (1,2) and nextop<3 else 0
 candidate=0
 if state==0 and fire and not badop and not badcmd:candidate=(1<<start) if start<3 else 0
 elif state==1 or (state==2 and not (ready and idle)):candidate=(1<<op) if op<3 else 0
 if fault or (state==1 and done and wrong):candidate=0
 assert original==candidate,(state,op,start,fire,badop,badcmd,done,take,ready,idle,fault,wrong)
 count+=1
print('C21_OWNER_NEXT_STATE_MODEL_PASS:',count,'combinations;actual RTL checked every native cycle;sha256',hashlib.sha256(source.read_bytes()).hexdigest())
