onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vmap c21_probe sim/dilithium/work_c21_probe
vsim -L cyclonev_ver -gDIAGNOSTIC=0 -gPROTOCOL=1 c21_probe.tb_c21_lifetimes
onfinish stop
run -all
quit -sim
vlog -sv -work c21_probe tb/tb_dilithium/lighthd_hintpkg_c13_reference.sv tb/tb_dilithium/lighthd_hintunpkg_c13_reference.sv tb/tb_dilithium/lighthd_hint_decode_stage_reference.sv tb/tb_dilithium/tb_lighthd_hint_shared.sv
vsim -L cyclonev_ver c21_probe.tb_lighthd_hint_shared
onfinish stop
run -all
quit -f
