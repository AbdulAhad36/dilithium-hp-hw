from pathlib import Path
import json
r=Path.cwd();changes={}
for name in ('tb_lighthd_sign_input','tb_lighthd_verify_input','tb_lighthd_hintunpkg'):
 s=(r/'tb/tb_dilithium'/(name+'.sv')).read_text()
 s=s.replace('module '+name+';','module c21_'+name+';')
 for old in ('stage7c3_sign_load_outputs.txt','stage7c4_verify_input_outputs.txt','stage7c4_hint_outputs.txt'):
  s=s.replace(old,'stage7c21_probe_'+old)
 changes['tmp/c21_'+name+'.sv']=s
changes['tmp/c21_inputs.do']='''onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vmap c21_probe sim/dilithium/work_c21_probe
vlog -sv -work c21_probe tb/tb_dilithium/lighthd_hint_compat.sv tb/tb_dilithium/lighthd_service_fixture.sv tb/tb_dilithium/lighthd_bank_fixture.sv tmp/c21_tb_lighthd_sign_input.sv tmp/c21_tb_lighthd_verify_input.sv tmp/c21_tb_lighthd_hintunpkg.sv
foreach top {c21_tb_lighthd_sign_input c21_tb_lighthd_verify_input c21_tb_lighthd_hintunpkg} {
 vsim -L cyclonev_ver c21_probe.$top
 onfinish stop
 run -all
 quit -sim
}
quit -f
'''
print(json.dumps('*** Begin Patch\n'+''.join('*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines()) for n,s in changes.items())+'*** End Patch'))
