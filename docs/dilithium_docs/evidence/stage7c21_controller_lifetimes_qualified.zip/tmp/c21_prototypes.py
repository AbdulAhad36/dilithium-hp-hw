from pathlib import Path
import json,sys
r=Path.cwd();u={}
def read(n):return (r/n).read_text(encoding='utf-8')

# Generic standalone input clients keep their original local snapshot mode.
# The production owner may instead accept their narrow write events directly.
s=read('src/controller/lighthd_sign_input.sv')
s=s.replace('module lighthd_sign_input (','module lighthd_sign_input #(parameter bit EXTERNAL_HEADER=0) (')
s=s.replace('  output logic poly_valid_o,', '''  output logic header_write_valid_o,output logic [3:0] header_write_index_o,
  output logic [63:0] header_write_data_o,
  output logic poly_valid_o,''')
s=s.replace('field_word_r<=0;header_r<=0;done_code_o<=0;', 'field_word_r<=0;done_code_o<=0;')
s=s.replace('done_code_o<=command_param_i==3?1:0;header_r<=0;', 'done_code_o<=command_param_i==3?1:0;')
s=s.replace('header_r[64*word_r[3:0]+:64]<=input_data_i;word_r<=word_r+1\'b1;', 'word_r<=word_r+1\'b1;')
insert='''  assign header_write_valid_o=!rst && state==HEADER && input_valid_i && input_ready_o && !bad_frame;
  assign header_write_index_o=word_r[3:0];assign header_write_data_o=input_data_i;
  generate if(!EXTERNAL_HEADER)begin:local_header
    always_ff @(posedge clk or posedge rst)begin
      if(rst)header_r<=0;
      else if(command_valid_i && command_ready_o)header_r<=0;
      else if(header_write_valid_o)header_r[64*header_write_index_o+:64]<=header_write_data_o;
    end
  end else begin:owned_header
    assign header_r=1024'd0;
  end endgenerate
'''
s=s.replace('  always_ff @(posedge clk or posedge rst)begin',insert+'  always_ff @(posedge clk or posedge rst)begin',1)
u['lighthd_sign_input']=s

s=read('src/controller/lighthd_sign.sv')
s=s.replace('logic [8:0] context_r;logic [255:0] rnd_r;', '''logic [8:0] context_r;logic [255:0] rnd_r;
  // Fixed register lifetimes:tr->mu,and key||rnd->mask seed.
  logic [255:0] rho_store_r;
  logic [511:0] tr_mu_store_r,entropy_mask_store_r;
  logic header_write_valid;logic [3:0] header_write_index;logic [63:0] header_write_data;
  assign rnd_r=entropy_mask_store_r[511:256];
  assign mu_r=tr_mu_store_r;assign mask_r=entropy_mask_store_r;''')
s=s.replace('  logic [255:0] rho,key;logic [511:0] tr;', '''  logic [255:0] rho,key;logic [511:0] tr;
  assign rho=rho_store_r;assign key=entropy_mask_store_r[255:0];assign tr=tr_mu_store_r;''')
s=s.replace('lighthd_sign_input key_input(', 'lighthd_sign_input #(.EXTERNAL_HEADER(1)) key_input(')
s=s.replace('.rho_o(rho),.key_o(key),.tr_o(tr),', '''.rho_o(),.key_o(),.tr_o(),
    .header_write_valid_o(header_write_valid),.header_write_index_o(header_write_index),.header_write_data_o(header_write_data),''')
s=s.replace('context_r<=0;rnd_r<=0;', 'context_r<=0;rho_store_r<=0;tr_mu_store_r<=0;entropy_mask_store_r<=0;')
s=s.replace('nonce_base_r<=0;mu_r<=0;mask_r<=0;ctilde_r<=0;', 'nonce_base_r<=0;ctilde_r<=0;')
s=s.replace('    end else begin\n      released_prev_r', '''    end else begin
      if(header_write_valid)begin
        if(header_write_index<4)rho_store_r[64*header_write_index[1:0]+:64]<=header_write_data;
        else if(header_write_index<8)entropy_mask_store_r[64*header_write_index[1:0]+:64]<=header_write_data;
        else tr_mu_store_r[64*header_write_index[2:0]+:64]<=header_write_data;
      end
      released_prev_r''')
s=s.replace('if(state==MU_RUN)mu_r[128*raw_count_r+:128]<=service_i.raw.output_data;', 'if(state==MU_RUN)tr_mu_store_r[128*raw_count_r+:128]<=service_i.raw.output_data;')
s=s.replace('else if(state==MASK_RUN)mask_r[128*raw_count_r+:128]<=service_i.raw.output_data;', 'else if(state==MASK_RUN)entropy_mask_store_r[128*raw_count_r+:128]<=service_i.raw.output_data;')
s=s.replace('context_r<=start_context_len_i;rnd_r<=start_rnd_i;', "context_r<=start_context_len_i;rho_store_r<=0;tr_mu_store_r<=0;entropy_mask_store_r<={start_rnd_i,256'd0};")
s=s.replace('REPORT:if(done_ready_i)begin rnd_r<=0;state<=IDLE;end', 'REPORT:if(done_ready_i)begin entropy_mask_store_r[511:256]<=0;state<=IDLE;end')
s=s.replace('endmodule\n`default_nettype wire', '''  // synthesis translate_off
  always @(posedge clk)if(!rst)begin
    if(service_i.raw.output_valid && service_o.raw.output_ready &&
       (state==MU_RUN || state==MASK_RUN) && formatter.prefix_left_r!=0)
      $fatal(1,"Sign register overlay overwrote an unconsumed hash prefix");
    if(header_write_valid && !(state==KEY_WAIT))$fatal(1,"Sign header write outside key input");
  end
  // synthesis translate_on
endmodule
`default_nettype wire''')
u['lighthd_sign']=s

s=read('src/controller/lighthd_verify_input.sv')
s=s.replace('module lighthd_verify_input (','module lighthd_verify_input #(parameter bit EXTERNAL_TR=0) (')
s=s.replace('  output logic done_valid_o,', '''  output logic tr_write_valid_o,output logic [1:0] tr_write_index_o,output logic [127:0] tr_write_data_o,
  output logic done_valid_o,''')
s=s.replace('rho_o<=0;tr_o<=0;ctilde_o<=0;', 'rho_o<=0;ctilde_o<=0;')
s=s.replace('tr_o[128*digest_beats_r+:128]<=service_i.raw.output_data;digest_beats_r<=digest_beats_r+1\'b1;', "digest_beats_r<=digest_beats_r+1'b1;")
insert='''  assign tr_write_valid_o=!rst && service_o.raw.output_ready && service_i.raw.output_valid;
  assign tr_write_index_o=digest_beats_r[1:0];assign tr_write_data_o=service_i.raw.output_data;
  generate if(!EXTERNAL_TR)begin:local_tr
    always_ff @(posedge clk or posedge rst)begin
      if(rst)tr_o<=0;
      else if(command_valid_i && command_ready_o)tr_o<=0;
      else if(tr_write_valid_o)tr_o[128*tr_write_index_o+:128]<=tr_write_data_o;
    end
  end else begin:owned_tr
    assign tr_o=512'd0;
  end endgenerate
'''
s=s.replace('  always_ff @(posedge clk or posedge rst)begin',insert+'  always_ff @(posedge clk or posedge rst)begin',1)
u['lighthd_verify_input']=s

s=read('src/controller/lighthd_verify.sv')
s=s.replace('logic [255:0] rho;logic [511:0] tr,ctilde;', '''logic [255:0] rho;logic [511:0] tr,ctilde;
  logic input_tr_write;logic [1:0] input_tr_index;logic [127:0] input_tr_data;
  assign tr=mu_r; // tr->mu->computed challenge,one fixed512-bit bank.''')
s=s.replace('lighthd_verify_input inputs(', 'lighthd_verify_input #(.EXTERNAL_TR(1)) inputs(')
s=s.replace('.rho_o(rho),.tr_o(tr),.ctilde_o(ctilde),', '''.rho_o(rho),.tr_o(),.ctilde_o(ctilde),
    .tr_write_valid_o(input_tr_write),.tr_write_index_o(input_tr_index),.tr_write_data_o(input_tr_data),''')
s=s.replace('    end else begin\n      if((state==MU_CMD', '''    end else begin
      if(input_tr_write)mu_r[128*input_tr_index+:128]<=input_tr_data;
      if((state==MU_CMD''')
s=s.replace('always @(posedge clk)if(!rst && raw_phase && state!=MU_RUN &&', 'always @(posedge clk)if(!rst && raw_phase &&')
s=s.replace('$fatal(1,"Verify digest overwrote Mu before prefix consumption");', '''$fatal(1,"Verify overlay overwrote an unconsumed tr/mu prefix");
  always @(posedge clk)if(!rst && input_tr_write && state!=INPUT_WAIT)
    $fatal(1,"Verify tr write outside input ownership");''')
u['lighthd_verify']=s

s=read('src/controller/lighthd_dilithium.sv')
old='''  assign selected_k=(state==EXECUTE || state==RETIRE) && op_r==0;
  assign selected_s=(state==EXECUTE || state==RETIRE) && op_r==1;
  assign selected_v=(state==EXECUTE || state==RETIRE) && op_r==2;'''
new='''  logic [2:0] owner_select_r,owner_select_next;
  assign selected_k=owner_select_r[0];assign selected_s=owner_select_r[1];assign selected_v=owner_select_r[2];
  // Anticipate the same next-state decode,avoiding a wide live RETIRE fanout.
  // This adds no public or engine cycle;fault quarantine remains unchanged.
  always_comb begin
    owner_select_next=0;
    if(state==IDLE && command_fire && !bad_opcode && !bad_command)
      case(start_op_i) 0:owner_select_next=1;1:owner_select_next=2;2:owner_select_next=4;default:begin end endcase
    else if(state==EXECUTE || (state==RETIRE && !(child_ready && response.idle)))
      case(op_r) 0:owner_select_next=1;1:owner_select_next=2;2:owner_select_next=4;default:begin end endcase
    if(fault_o || (state==EXECUTE && child_done && child_id!=id_r))owner_select_next=0;
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)owner_select_r<=0;else owner_select_r<=owner_select_next;
  end
  // synthesis translate_off
  always @(posedge clk)if(!rst && owner_select_r!=={
    ((state==EXECUTE || state==RETIRE) && op_r==2),
    ((state==EXECUTE || state==RETIRE) && op_r==1),
    ((state==EXECUTE || state==RETIRE) && op_r==0)})
      $fatal(1,"Registered main owner differs from original state decode");
  // synthesis translate_on'''
assert old in s;s=s.replace(old,new);u['lighthd_dilithium']=s
s=read('src/controller/process/lighthd_hint_codec.sv')
s=s.replace('assign decode_write=d_input_valid_i && d_input_ready_o && !d_bad_frame;', '''// Store tentatively using the internal expected word address. Frame errors
  // still enter REPORT immediately;no masks are published from rejected data.
  // New decode commands refill all required bytes before count/order checking.
  assign decode_write=d_input_valid_i && d_input_ready_o;''')
u['lighthd_hint_codec']=s
patch='*** Begin Patch\n'
for name,s in u.items():
 if len(sys.argv)>1 and name not in sys.argv[1:]:continue
 p=r/('tmp/c21_'+name+'.sv');assert not p.exists(),p
 patch+='*** Add File: '+p.as_posix()+'\n'+''.join('+'+line+'\n' for line in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
