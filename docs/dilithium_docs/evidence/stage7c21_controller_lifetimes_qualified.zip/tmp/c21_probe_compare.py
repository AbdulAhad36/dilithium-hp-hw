import importlib.util
from pathlib import Path
p=Path('sim/dilithium/dilithium_vectors.py');s=importlib.util.spec_from_file_location('vectors',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
h=Path('sim/dilithium')
m.lighthd_main_compare(diagnostic=True,captured=(h/'stage7c21_probe_main_diagnostic_outputs.txt').read_text())
m.lighthd_main_protocol_compare(captured=(h/'stage7c21_probe_main_protocol_outputs.txt').read_text())
token,inputs,expected=m.lighthd_sign_load_artifacts()
assert (h/'stage7c21_probe_stage7c3_sign_load_outputs.txt').read_text().split()==expected.split()
print('C21_STANDALONE_SIGN_HEADER_PASS:135commands/105complete/21reject/9reset;default snapshot and actual bank words exact')
m.lighthd_verify_input_compare(captured=(h/'stage7c21_probe_stage7c4_verify_input_outputs.txt').read_text())
m.lighthd_hint_compare(captured=(h/'stage7c21_probe_stage7c4_hint_outputs.txt').read_text())
for leaf,markers in [('stage7c21_lifetime_probe_retry1.log',['CONTROLLER_LIFETIME_CYCLE_PROBE_PASS:195757cycles/3Sign/3Verify/3full digests/3retry contexts']),('stage7c21_lifetime_protocol_probe.log',['CONTROLLER_LIFETIME_CYCLE_PROBE_PASS:972701cycles/14Sign/27Verify/15full digests/11retry contexts','SHARED_HINT_MODE_SWITCH_PASS:60 alternating commands']),('stage7c21_inputs_probe.log',['LIGHTHD_SIGN_INPUT_CAPTURE_PASS','LIGHTHD_VERIFY_INPUT_CAPTURE_PASS','LIGHTHD_HINT_CAPTURE_PASS'])]:
 if leaf=='stage7c21_inputs_probe.log':leaf='stage7c21_inputs_probe_retry1.log'
 text=(h/leaf).read_text()
 assert all(x in text for x in markers),leaf
 assert '# ** Fatal:' not in text and '# ** Error:' not in text,leaf
print('C21_PRIVATE_PROBES_PASS:prototype-only,before promotion;C20 fixtures unchanged')
