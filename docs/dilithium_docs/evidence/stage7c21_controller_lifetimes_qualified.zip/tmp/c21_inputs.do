onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vmap c21_probe sim/dilithium/work_c21_probe
vlog -sv -work c21_probe tb/tb_dilithium/lighthd_hint_compat.sv tb/tb_dilithium/lighthd_service_fixture.sv tb/tb_dilithium/lighthd_bank_fixture.sv tmp/c21_tb_lighthd_sign_input.sv tmp/c21_tb_lighthd_verify_input.sv tmp/c21_tb_lighthd_hintunpkg.sv
foreach top {c21_tb_lighthd_sign_input c21_tb_lighthd_verify_input c21_tb_lighthd_hintunpkg} {
 vsim -L cyclonev_ver c21_probe.$top
 onfinish stop
 run -all
 quit -sim
}
quit -f
