from pathlib import Path
import difflib,hashlib,json,sys
r=Path.cwd();rb=r/'sim/dilithium/reference_build';changes={}
for name in ('native_runner.ps1','quartus_runner.ps1','foundation_runner.ps1','production_runner.ps1','uvm_runner.ps1','collect_runner.ps1','foundation.do','production.do','metrics.py','admission_registers.py','native_structure.py','shared_hint_registers.py','operand_registers.py','stream_registers.py','writer_registers.py','area_delta.py','throughput.py','cycle_audit.py'):
 s=(rb/('stage7c20_'+name)).read_text(encoding='utf-8')
 # Clone current-stage paths only;earlier reference module filenames stay exact.
 s=s.replace('stage7c20','stage7c21').replace('STAGE7C20','STAGE7C21').replace('C20_','C21_')
 if name=='native_runner.ps1':s=s.replace("'uvm_prepare'","'uvm_prepare','lighthd_sign_load_prepare','lighthd_verify_input_prepare'")
 if name=='foundation.do':
  anchor='vlog -sv -work lighthd_foundation_work tb/tb_dilithium/tb_lighthd_sampler_writer.sv'
  extra=' '.join('tb/tb_dilithium/'+n+'.sv' for n in ('lighthd_sign_input_c20_reference','lighthd_sign_c20_reference','lighthd_verify_input_c20_reference','lighthd_verify_c20_reference','tb_lighthd_controller_lifetimes','tb_lighthd_sign_input','lighthd_service_fixture','tb_lighthd_verify_input'))
  # Fixture must precede elaboration,compile ordering does not affect module binds.
  s=s.replace(anchor,'vlog -sv -work lighthd_foundation_work '+extra+' tb/tb_dilithium/tb_lighthd_sampler_writer.sv')
  s=s.replace('foreach top {tb_lighthd_sampler_writer_queue','foreach top {tb_lighthd_sign_input tb_lighthd_verify_input tb_lighthd_controller_lifetimes tb_lighthd_sampler_writer_queue')
  s=s.replace('quit -f\n','vsim -L cyclonev_ver -gDIAGNOSTIC=0 -gPROTOCOL=1 lighthd_foundation_work.tb_lighthd_controller_lifetimes\nonfinish stop\nrun -all\nquit -f\n')
 if name=='foundation_runner.ps1':
  s=s.replace("@('LIGHTHD_WRITER_QUEUE_STRESS_PASS", "@('LIGHTHD_CONTROLLER_LIFETIME_CYCLE_PASS:195757cycles/3Sign/3Verify/3full digests/3retry contexts','LIGHTHD_CONTROLLER_LIFETIME_CYCLE_PASS:972701cycles/14Sign/27Verify/15full digests/11retry contexts','LIGHTHD_SIGN_INPUT_CAPTURE_PASS','LIGHTHD_VERIFY_INPUT_CAPTURE_PASS','LIGHTHD_WRITER_QUEUE_STRESS_PASS")
  s=s.replace("@('lighthd_writer_compare'","@('lighthd_owner_selftest','lighthd_sign_load_compare','lighthd_verify_input_compare','lighthd_main_protocol_compare','lighthd_writer_compare'")
 if name in ('area_delta.py','throughput.py'):
  s=s.replace('stage7c18r1_area_inventory.json','stage7c20_area_inventory.json').replace('stage7c18r1_throughput.json','stage7c20_throughput.json').replace('C18R1','C20').replace('62.18','63.59')
 if name=='cycle_audit.py':s=s.replace('stage7c21_baseline_c18r1','stage7c21_baseline_c20').replace('C18R1','C20')
 changes['sim/dilithium/reference_build/stage7c21_'+name]=s
# Store original C20 captures BEFORE any new run writes stable output paths.
for leaf in ('stage7c4_main_outputs.txt','stage7c4_main_protocol_outputs.txt','stage7_uvm_checked.csv','stage7_uvm_latency.csv'):
 changes['sim/dilithium/reference_build/stage7c21_baseline_c20/'+leaf]=(r/'sim/dilithium'/leaf).read_text(encoding='utf-8')
# Reuse only the unchanged arithmetic proof,with explicit C18R1 provenance.
s=(rb/'stage7c20_proof_reuse.py').read_text(encoding='utf-8').replace("new=json.loads((rb/'stage7c20_source_hashes.json')","new=json.loads((rb/'stage7c21_source_hashes.json')").replace('C20_UNIT_DOMAIN','C21_UNIT_DOMAIN').replace('fresh C20','fresh C21')
changes['sim/dilithium/reference_build/stage7c21_proof_reuse.py']=s
changes['sim/dilithium/reference_build/stage7c21_source_audit.py']='''from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c20_source_hashes.json').read_text());new=json.loads((rb/'stage7c21_source_hashes.json').read_text())
for n,d in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
assert len(new)==256 and len(set(new)-set(old))==5
expected={'src/controller/'+n+'.sv' for n in ('lighthd_sign_input','lighthd_sign','lighthd_verify_input','lighthd_verify','lighthd_dilithium')}
expected|={'src/controller/process/lighthd_hint_codec.sv','tb/tb_dilithium/tb_lighthd_sign_input.sv','tb/tb_dilithium/tb_lighthd_verify_input.sv','sim/dilithium/dilithium_vectors.py','quartus/dilithium/report_full.tcl'}
assert {n for n in old if old[n]!=new[n]}==expected
print('C21_SOURCE_AUDIT_PASS:256frozen/6controller-hint RTL changes/2standalone pin declarations/5new reference-test files;arithmetic,QSF,SDC unchanged C20')
'''
old=json.loads((rb/'stage7c20_source_hashes.json').read_text());names=set(old)
names|={'tb/tb_dilithium/'+n+'.sv' for n in ('lighthd_sign_input_c20_reference','lighthd_sign_c20_reference','lighthd_verify_input_c20_reference','lighthd_verify_c20_reference','tb_lighthd_controller_lifetimes')}
assert len(names)==256
changes['sim/dilithium/reference_build/stage7c21_source_hashes.json']=json.dumps({n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in sorted(names)},indent=2)+'\n'
patch='*** Begin Patch\n'
for n,s in changes.items():
 if len(sys.argv)>1 and Path(n).name not in sys.argv[1:]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
