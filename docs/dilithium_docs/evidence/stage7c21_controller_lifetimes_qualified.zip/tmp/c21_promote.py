from pathlib import Path
import difflib,json,sys
r=Path.cwd();changes={}
for n in ('lighthd_sign_input','lighthd_sign','lighthd_verify_input','lighthd_verify','lighthd_dilithium','lighthd_hint_codec'):
 target='src/controller/'+('process/' if n=='lighthd_hint_codec' else '')+n+'.sv'
 changes[target]=(r/('tmp/c21_'+n+'.sv')).read_text(encoding='utf-8')
for n in ('lighthd_sign_input','lighthd_sign','lighthd_verify_input','lighthd_verify'):
 changes['tb/tb_dilithium/'+n+'_c20_reference.sv']=(r/('tmp/'+n+'_c20_reference.sv')).read_text(encoding='utf-8')
changes['tb/tb_dilithium/tb_lighthd_controller_lifetimes.sv']=(r/'tmp/tb_c21_lifetimes.sv').read_text(encoding='utf-8').replace('module tb_c21_lifetimes','module tb_lighthd_controller_lifetimes').replace('tb_c21_main_probe #','tb_lighthd_main #').replace('CONTROLLER_LIFETIME_CYCLE_PROBE_PASS','LIGHTHD_CONTROLLER_LIFETIME_CYCLE_PASS')
for n,decl in [('sign','  logic header_write_valid_o;logic [3:0] header_write_index_o;logic [63:0] header_write_data_o;'),('verify','  logic tr_write_valid_o;logic [1:0] tr_write_index_o;logic [127:0] tr_write_data_o;')]:
 name='tb/tb_dilithium/tb_lighthd_'+n+'_input.sv';s=(r/name).read_text(encoding='utf-8');anchor='module tb_lighthd_'+n+'_input;'
 changes[name]=s.replace(anchor,anchor+'\n'+decl)
patch='*** Begin Patch\n'
for n,new in changes.items():
 if len(sys.argv)>1 and Path(n).stem not in sys.argv[1:]:continue
 p=r/n
 if not p.exists():patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in new.splitlines())
 else:
  diff=list(difflib.unified_diff(p.read_text(encoding='utf-8').splitlines(True),new.splitlines(True),n,n))
  patch+='*** Update File: '+n+'\n'+''.join('@@\n' if x.startswith('@@') else x for x in diff[2:])
print(json.dumps(patch+'*** End Patch'))
