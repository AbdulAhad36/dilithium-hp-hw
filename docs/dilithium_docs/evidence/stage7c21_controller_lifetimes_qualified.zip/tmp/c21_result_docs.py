from pathlib import Path
from statistics import mean
import json,re,sys,difflib
r=Path.cwd();h=r/'sim/dilithium';rb=h/'reference_build'
assert 'STAGE7C21_RESULT_COLLECTION_PASS' in (h/'stage7c21_collect_runner.log').read_text()
m=json.loads((rb/'stage7c21_metrics.json').read_text());old=json.loads((rb/'stage7c20_metrics.json').read_text());a=m['area']
f=min(c['fmax_mhz'] for c in m['corners']);setup=min(c['setup_ns'] for c in m['corners']);hold=min(c['hold_ns'] for c in m['corners'])
delta=a['placed_ALMs']-old['area']['placed_ALMs'];gain=100*(f/63.59-1)
u=(h/'stage7c21_uvm.log').read_text(encoding='utf-8',errors='replace')
bins={}
for key,label in [('functional','OVERALL FUNCTIONAL COVERAGE'),('module','DUT MODULE CODE COVERAGE'),('package','SHARED DUT PACKAGE CODE COVERAGE'),('overall','OVERALL DUT CODE COVERAGE')]:
 z=re.search(re.escape(label)+r'.*?:\s*(\d+) / (\d+)',u);assert z,label;bins[key]=tuple(map(int,z.groups()))
token=(h/'stage7c4_main_inputs.txt').read_text().split()[0];uvmtoken=re.search(r'[0-9a-f]{64}',(h/'stage7_uvm_inputs.txt').read_text())[0]
status=f'''## C21 source-qualified and routed controller trial

All256 source hashes,fresh foundation/standalone input tests,210 official
commands,88 protocol commands,90 checker corruptions and main33 UVM/negative
pass. Actual final placement: **{a['placed_ALMs']:,} ALMs**,{a['registers']:,} registers,
{a['M10Ks']} M10Ks and{a['DSPs']} DSPs. Worst Fmax **{f:.2f}MHz**,setup **{setup:+.3f}ns**,
hold **{hold:+.3f}ns**. Versus C20:{delta:+,} placed ALMs,{gain:+.2f}% Fmax.
The same Cyclone V,6.757ns and hold constraints remain. These are final placed
ALMs,not packing estimates. Under20K/148MHz and user performance acceptance
remain open. See THROUGHPUT.md for all corners and measured cycle/rate changes.

Area improves814 ALMs (2.66%),but worst Fmax falls0.22MHz (0.35%). All286
completed official/protocol latencies and30 main-UVM latency rows match C20;
the12 protocol reset-prefix records also match. No operation clocks are added,
so estimated operation rates also fall0.35%. This is an area tradeoff,not a
speed improvement or an accepted final design. Preserve C20 as the faster
checkpoint. No clock or hold constraint was relaxed.

'''
corners='|Corner|Fmax MHz|Setup ns|Setup TNS ns|Hold ns|Hold TNS ns|\n|---|---:|---:|---:|---:|---:|\n'
for c in m['corners']:corners+=f"|{c['corner']}|{c['fmax_mhz']:.2f}|{c['setup_ns']:+.3f}|{c['setup_tns_ns']:.3f}|{c['hold_ns']:+.3f}|{c['hold_tns_ns']:.3f}|\n"
t=json.loads((rb/'stage7c21_throughput.json').read_text());table='|Operation|Level|Mean cycles|Cycle delta vs C20|Estimated latency us|Estimated operations/s|Rate delta vs C20|\n|---|---:|---:|---:|---:|---:|---:|\n'
for row in t['rows']:table+=f"|{row['operation']}|{row['level']}|{row['cycles']:.2f}|{row['cycle_delta_vs_C20']:+.2f}|{row['latency_us']:.1f}|{row['operations_per_second']:.1f}|{row['rate_gain_vs_C20_pct']:+.2f}%|\n"
common='''Sign owns256 rho bits,512 TR/Mu bits and512 key-randomness/mask bits;
Verify owns512 TR/Mu/digest bits. The integrated input blocks retain no
duplicate header/TR snapshots;standalone defaults preserve their snapshots.
The routed hardware guards verify these banks,three registered main-owner
bits,the original writer214 bits,shared hint storage and unchanged arithmetic.
Diagnostic9/protocol88 compare195757/972701 clocks against frozen C20 controls,
qualified requests,valid outputs and retry context. Polynomial RAM rules stay.

'''
coverage='|Main coverage|Hit / defined|Percent|\n|---|---:|---:|\n'
for key,label in [('functional','Functional'),('module','RTL module raw code'),('package','Executable shared package raw code'),('overall','Overall DUT raw code')]:
 hit,total=bins[key];coverage+=f'|{label}|{hit} / {total}|{100*hit/total:.2f}%|\n'
covnote='''
Focused tests do not inflate main coverage. Current-token corrupt first key
byte rejects with zero credited outcomes. The exhaustive Process-domain proof
is explicitly reused from C18R1 via10 byte-identical files,not rerun/retagged.
'''
extras={
 'DILITHIUM_PLAN.md':common+'''The new slow85C worst path is unpacker read_slot_r[1] to count_r[3],11logic
levels/15.448ns;slow0C has the same endpoints at15.291ns. The previous main
RETIRE/hint indices endpoints are no longer worst. Next within Stage7C:qualify
an isolated change to this unpacker validation/packet-ready feedback path,
with canonicality,stalls,reset and continuous-word throughput proofs. Also
inspect the secret-regroup pending_core_r to Process operand path (15.378ns).
Under20K requires another9842 actual placed ALMs removed to reach19999;use
disjoint area scopes for larger savings. Preserve this trial and C20;
do not call a small improvement or a passing test target closure. No Stage8,
commit,branch change or full unpublished-RTL replica claim is authorized.

Create-only evidence: `evidence/stage7c21_controller_lifetimes_qualified.zip`
and its SHA256 sidecar. Saved-evidence extraction replay is required before
this checkpoint is handed off;that replay is not a native simulation rerun.

''',
 'THROUGHPUT.md':common+corners+'\n'+table+'\nRates use measured cycles and actual worst Fmax;sequential estimates,not board measurements or command initiation interval.\n\n',
 'COVERAGE.md':coverage+covnote+'\n',
 'REFERENCE_VERIFICATION.md':common+f'Main token `{token}`.\n\nUVM token `{uvmtoken}`.\n\n'+covnote+'\n',
 'MEMORY_MAP.md':common+'''|Controller bank|Bits|First use|Later use|Overwrite condition|
|---|---:|---|---|---|
|Sign rho|256|Accepted SK rho words|Matrix seed|Next command/reset|
|Sign TR/Mu|512|Accepted SK TR words|Message representative Mu|TR prefix fully consumed|
|Sign entropy/mask|512|Key low256,randomness high256|Mask-expansion seed|Key/randomness prefix fully consumed|
|Verify TR/Mu/digest|512|Hash of public key|Mu,then recomputed challenge|Prior hash prefix fully consumed|

Accepted64-bit header writes update Sign's owner banks;128-bit raw TR writes
update Verify's shared bank. Assertions forbid overwriting live hash prefixes.
Tentative data is never a qualified result. These are fixed local registers;
the four polynomial banks and their arbitration/collision rules do not change.

''',
 'PROCESS_BLOCKS.md':'''Hint input is stored tentatively at the internal expected word address.
Incorrect external index/byte-count/last still gives the same immediate error
and cannot publish masks. Subsequent decode refills required bytes;encode
overwrites used bytes and masks padding. Fresh106 suffix cases and60 alternating
encode/decode commands pass. Process arithmetic/four-stage pipeline is unchanged.

''',
 'SPECIFICATION.md':common,
}
patch='*** Begin Patch\n'
for leaf,extra in extras.items():
 if len(sys.argv)>1 and leaf not in sys.argv[1:]:continue
 p=r/'docs/dilithium_docs'/leaf;s=p.read_text(encoding='utf-8');prefix,tail=s.split('\n\n',1)
 # Replace only our provisional top section;preserve all earlier evidence.
 if tail.startswith('## C21') or tail.startswith('## Active C21'):
  match=re.search(r'\n## C20 ',tail);assert match,leaf;tail=tail[match.start()+1:]
 new=prefix+'\n\n'+status+extra+tail
 diff=list(difflib.unified_diff(s.splitlines(True),new.splitlines(True),str(p),str(p)))
 patch+='*** Update File: '+p.relative_to(r).as_posix()+'\n'+''.join('@@\n' if line.startswith('@@') else line for line in diff[2:])
print(json.dumps(patch+'*** End Patch'))
