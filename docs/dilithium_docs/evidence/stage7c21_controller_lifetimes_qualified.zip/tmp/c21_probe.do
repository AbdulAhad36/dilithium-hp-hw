onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vlib sim/dilithium/work_c21_probe
vmap c21_probe sim/dilithium/work_c21_probe
set fd [open quartus/dilithium/dilithium_full.qsf r]
set settings [read $fd];close $fd
set overridden {lighthd_sign_input lighthd_sign lighthd_verify_input lighthd_verify lighthd_dilithium lighthd_hint_codec}
foreach line [split $settings "\n"] {
  if {[regexp {SYSTEMVERILOG_FILE\s+(.+)$} [string trim $line] -> source]} {
    set stem [file rootname [file tail $source]]
    if {[lsearch -exact $overridden $stem]>=0} {vlog -sv -work c21_probe tmp/c21_${stem}.sv} else {
      vlog -sv -work c21_probe [file normalize [file join quartus/dilithium $source]]
    }
  }
}
vlog -sv -work c21_probe tmp/lighthd_sign_input_c20_reference.sv tmp/lighthd_sign_c20_reference.sv tmp/lighthd_verify_input_c20_reference.sv tmp/lighthd_verify_c20_reference.sv tmp/tb_c21_main_probe.sv tmp/tb_c21_lifetimes.sv
vsim -L cyclonev_ver c21_probe.tb_c21_lifetimes
onfinish stop
run -all
quit -f
