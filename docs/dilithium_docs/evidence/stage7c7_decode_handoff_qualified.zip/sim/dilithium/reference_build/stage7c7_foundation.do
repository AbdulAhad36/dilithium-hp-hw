onerror {quit -code 1 -f}
vlib sim/dilithium/work_lighthd_foundation
vmap lighthd_foundation_work sim/dilithium/work_lighthd_foundation
set fd [open quartus/dilithium/dilithium_full.qsf r]
set settings [read $fd];close $fd
foreach line [split $settings "\n"] {
  if {[regexp {SYSTEMVERILOG_FILE\s+(.+)$} [string trim $line] -> source]} {
    vlog -sv -work lighthd_foundation_work [file normalize [file join quartus/dilithium $source]]
  }
}
vlog -sv -work lighthd_foundation_work tb/tb_dilithium/lighthd_bank_fixture.sv tb/tb_dilithium/lighthd_service_fixture.sv tb/tb_dilithium/tb_lighthd_bitunpkg.sv tb/tb_dilithium/tb_lighthd_load_decode.sv tb/tb_dilithium/tb_lighthd_sign_input.sv tb/tb_dilithium/tb_lighthd_verify_input.sv tb/tb_dilithium/tb_lighthd_main.sv
foreach top {tb_lighthd_bitunpkg tb_lighthd_load_decode tb_lighthd_sign_input tb_lighthd_verify_input tb_lighthd_main} {
  vsim lighthd_foundation_work.$top
  onfinish stop
  run -all
  quit -sim
}
quit -f
