$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l sim/dilithium/stage7c7_foundation.log -do sim/dilithium/reference_build/stage7c7_foundation.do *> sim/dilithium/stage7c7_foundation_console.log
if ($LASTEXITCODE -ne 0) {throw 'Native decoder foundation failed'}
foreach ($marker in @('LIGHTHD_BITUNPKG_PASS','LIGHTHD_SHARED_LOAD_DECODE_PASS','LIGHTHD_SIGN_INPUT_CAPTURE_PASS','LIGHTHD_VERIFY_INPUT_CAPTURE_PASS','LIGHTHD_MAIN_CAPTURE_PASS:9')) {
  if (-not (Select-String -LiteralPath sim/dilithium/stage7c7_foundation.log -Pattern $marker -Quiet)) {throw "Missing gate $marker"}
}
foreach ($gate in @('lighthd_sign_load_compare','lighthd_verify_input_compare','lighthd_main_diagnostic_compare')) {
  & 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py $gate *> "sim/dilithium/stage7c7_${gate}.log"
  if ($LASTEXITCODE -ne 0) {throw "Decoder foundation comparison failed: $gate"}
}
'STAGE7C7_FOUNDATION_RUNNER_PASS'
