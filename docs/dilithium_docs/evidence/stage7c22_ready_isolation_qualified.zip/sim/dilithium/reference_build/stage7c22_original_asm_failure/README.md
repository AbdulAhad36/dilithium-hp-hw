# Original C22 assembler crash

The full flow successfully routed C22,then quartus_asm exited unexpectedly
(293007). The original compile log and fit/flow reports are retained here.
The copied asm report can predate this failed attempt because the crashed
assembler did not necessarily replace the previous report;it is historical,
not evidence of successful C22 assembly. Use the separately named manual
recovery logs and current final output reports to assess recovery.

No source,QSF,SDC or routed database was changed for the recovery. It reruns
only ASM,STA and the retained-hardware/four-corner report. This is not another
successful full-flow compile and the original failure is not retagged.
