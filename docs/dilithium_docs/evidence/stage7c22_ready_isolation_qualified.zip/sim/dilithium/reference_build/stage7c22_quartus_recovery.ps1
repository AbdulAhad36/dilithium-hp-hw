$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw\quartus\dilithium'
# The original full flow routed successfully,then quartus_asm crashed.
# Reuse that exact routed database;do not relabel this as a new full compile.
& F:/altera/quartus/bin64/quartus_asm.exe dilithium_full -c dilithium_full --read_settings_files=on --write_settings_files=off *> stage7c22_asm_recovery.log
if($LASTEXITCODE -ne 0){throw 'C22 assembler recovery failed'}
'C22_MANUAL_ASSEMBLER_RECOVERY_PASS'
& F:/altera/quartus/bin64/quartus_sta.exe dilithium_full -c dilithium_full --read_settings_files=on --write_settings_files=off *> stage7c22_sta_recovery.log
if($LASTEXITCODE -ne 0){throw 'C22 timing recovery failed'}
'C22_MANUAL_STA_RECOVERY_PASS'
& F:/altera/quartus/bin64/quartus_sta.exe -t report_full.tcl *> stage7c22_report_full.log
if($LASTEXITCODE -ne 0){throw 'C22 four-corner/retention report failed'}
if(-not(Select-String -LiteralPath critical_full/retained_registers.rpt -Pattern WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS -Quiet)){throw 'C22 retention marker missing'}
'STAGE7C22_MANUAL_POSTFIT_RECOVERY_PASS'
