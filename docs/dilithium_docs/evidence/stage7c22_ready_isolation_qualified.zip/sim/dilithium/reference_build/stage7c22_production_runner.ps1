$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l sim/dilithium/stage7c22_production.log -do sim/dilithium/reference_build/stage7c22_production.do *> sim/dilithium/stage7c22_production_console.log
if ($LASTEXITCODE -ne 0) {throw 'Native production run failed'}
foreach ($gate in @('lighthd_main_compare','lighthd_main_protocol_compare','lighthd_main_selftest')) {
  & 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py $gate *> "sim/dilithium/stage7c22_${gate}.log"
  if ($LASTEXITCODE -ne 0) {throw "Production comparison failed: $gate"}
}
'STAGE7C22_PRODUCTION_RUNNER_PASS'
