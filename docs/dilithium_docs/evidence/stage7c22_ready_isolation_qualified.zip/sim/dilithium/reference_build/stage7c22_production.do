onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vlib sim/dilithium/work_lighthd_production
vmap lighthd_production_work sim/dilithium/work_lighthd_production
set fd [open quartus/dilithium/dilithium_full.qsf r]
set settings [read $fd];close $fd
foreach line [split $settings "\n"] {
  if {[regexp {SYSTEMVERILOG_FILE\s+(.+)$} [string trim $line] -> source]} {
    vlog -sv -work lighthd_production_work [file normalize [file join quartus/dilithium $source]]
  }
}
vlog -sv -work lighthd_production_work tb/tb_dilithium/tb_lighthd_main.sv
vsim -L cyclonev_ver -gDIAGNOSTIC=0 lighthd_production_work.tb_lighthd_main
onfinish stop
run -all
quit -sim
vsim -L cyclonev_ver -gDIAGNOSTIC=0 -gPROTOCOL=1 lighthd_production_work.tb_lighthd_main
onfinish stop
run -all
quit -f
