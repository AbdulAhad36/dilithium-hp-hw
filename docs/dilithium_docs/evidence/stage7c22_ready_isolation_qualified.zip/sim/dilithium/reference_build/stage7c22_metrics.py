from pathlib import Path
import re,json
q=Path('quartus/dilithium');here=Path('sim/dilithium')
def read(p):
 data=p.read_bytes();return data.decode('utf-16' if data[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8',errors='replace')
primary='STAGE7C22_QUARTUS_RUNNER_PASS' in read(here/'stage7c22_quartus_runner.log')
recovered=(here/'stage7c22_quartus_recovery_r1.log').exists() and 'STAGE7C22_MANUAL_POSTFIT_RECOVERY_PASS' in read(here/'stage7c22_quartus_recovery_r1.log') and 'C22_MANUAL_ASSEMBLER_RECOVERY_PASS' in read(here/'stage7c22_quartus_recovery.log')
assert primary or recovered,'C22 routed/retained/four-corner gates not complete'
sta=read(q/'output_full/dilithium_full.sta.rpt');fit=read(q/'output_full/dilithium_full.fit.rpt')
def row(label):
 m=re.search(r';\s*'+re.escape(label)+r'\s*;\s*([\d,]+)',fit);assert m,label
 return int(m[1].replace(',',''))
metrics=[]
for corner,title in [('slow_85C','Slow 1100mV 85C'),('slow_0C','Slow 1100mV 0C'),('fast_85C','Fast 1100mV 85C'),('fast_0C','Fast 1100mV 0C')]:
 f=read(q/f'critical_full/{corner}_fmax.rpt');fm=float(re.search(r';\s*([\d.]+) MHz',f)[1]);d=dict(corner=corner,fmax_mhz=fm)
 for check in ('Setup','Hold'):
  section=sta.split('; '+title+' Model '+check+' Summary ;',1)[1]
  match=re.search(r';\s*clk\s*;\s*(-?[\d.]+)\s*;\s*(-?[\d.]+)',section)
  d[check.lower()+'_ns']=float(match[1]);d[check.lower()+'_tns_ns']=float(match[2])
 metrics.append(d)
# The fit report explicitly distinguishes final placement [A] from packing estimates.
m=re.search(r';\s*ALMs: used in final placement.*?;\s*([\d,]+)',fit)
if not m:
 m=re.search(r';\s*\[A\] ALMs used in final placement.*?;\s*([\d,]+)',fit)
assert m,'Final placed [A] ALM row not found'
area=dict(placed_ALMs=int(m[1].replace(',','')),registers=row('Total registers'),M10Ks=row('M10K blocks'),DSPs=row('Total DSP Blocks'),block_bits=row('Total block memory bits'))
result=dict(area=area,corners=metrics,physical_flow='original full flow' if primary else 'original successful fit plus manual ASM/STA/retention recovery after assembler crash')
(here/'reference_build/stage7c22_metrics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
