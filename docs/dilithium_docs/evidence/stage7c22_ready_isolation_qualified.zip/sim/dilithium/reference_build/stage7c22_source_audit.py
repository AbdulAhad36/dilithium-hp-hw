from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c21_source_hashes.json').read_text());new=json.loads((rb/'stage7c22_source_hashes.json').read_text())
for n,d in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
assert len(new)==259 and len(set(new)-set(old))==3
assert {n for n in old if old[n]!=new[n]}=={'src/controller/process/lighthd_bitunpkg.sv','src/controller/datapath/lighthd_process_dma.sv','sim/dilithium/dilithium_vectors.py','quartus/dilithium/report_full.tcl'}
print('C22_SOURCE_AUDIT_PASS:259 frozen/two transport-bookkeeping RTL changes/3new reference-test files;engine and Process arithmetic,RAM rules,QSF,SDC unchanged C21')
