$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
if(-not(Select-String -LiteralPath sim/dilithium/stage7c22_quartus_recovery.log -Pattern C22_MANUAL_ASSEMBLER_RECOVERY_PASS -Quiet)){throw 'Prior actual ASM recovery not complete'}
Set-Location -LiteralPath quartus/dilithium
& F:/altera/quartus/bin64/quartus_sta.exe dilithium_full -c dilithium_full *> stage7c22_sta_recovery_r1.log
if($LASTEXITCODE -ne 0){throw 'C22 timing recovery R1 failed'}
'C22_MANUAL_STA_RECOVERY_PASS'
& F:/altera/quartus/bin64/quartus_sta.exe -t report_full.tcl *> stage7c22_report_full.log
if($LASTEXITCODE -ne 0){throw 'C22 four-corner/retention report failed'}
if(-not(Select-String -LiteralPath critical_full/retained_registers.rpt -Pattern WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS -Quiet)){throw 'C22 retention marker missing'}
'STAGE7C22_MANUAL_POSTFIT_RECOVERY_PASS'
