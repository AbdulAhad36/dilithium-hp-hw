param([int]$RecoveryId)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
Wait-Process -Id $RecoveryId -ErrorAction SilentlyContinue
foreach($kind in @('native','uvm')){
 $marker='STAGE7C22_'+$kind.ToUpper()+'_RUNNER_PASS'
 if(-not(Select-String -LiteralPath "sim/dilithium/stage7c22_${kind}_runner.log" -Pattern $marker -Quiet)){throw "C22 source gate incomplete: $kind"}
}
if(-not(Select-String -LiteralPath sim/dilithium/stage7c22_quartus_recovery_r1.log -Pattern STAGE7C22_MANUAL_POSTFIT_RECOVERY_PASS -Quiet)){throw 'C22 post-fit recovery incomplete'}
foreach($reader in @('source_audit','proof_reuse','metrics','admission_registers','native_structure','shared_hint_registers','operand_registers','stream_registers','lifetime_registers','writer_registers','area_delta','throughput','cycle_audit')){
 & C:/Python314/python.exe "sim/dilithium/reference_build/stage7c22_${reader}.py" *> "sim/dilithium/stage7c22_${reader}_console.log"
 if($LASTEXITCODE -ne 0){throw "C22 result reader failed: $reader"}
}
& C:/Python314/python.exe sim/dilithium/dilithium_vectors.py uvm_check *> sim/dilithium/stage7c22_final_uvm_check.log
if($LASTEXITCODE -ne 0){throw 'C22 final UVM freshness failed'}
'STAGE7C22_RESULT_COLLECTION_PASS'
