from pathlib import Path
import json,hashlib,sys
r=Path.cwd();rb=r/'sim/dilithium/reference_build';u={}
names=('native_runner.ps1','quartus_runner.ps1','foundation_runner.ps1','production_runner.ps1','uvm_runner.ps1','collect_runner.ps1','foundation.do','production.do','metrics.py','admission_registers.py','native_structure.py','shared_hint_registers.py','operand_registers.py','stream_registers.py','lifetime_registers.py','writer_registers.py','area_delta.py','throughput.py','cycle_audit.py','proof_reuse.py')
for name in names:
 s=(rb/('stage7c21_'+name)).read_text(encoding='utf-8')
 s=s.replace('stage7c21','stage7c22').replace('STAGE7C21','STAGE7C22').replace('C21_','C22_')
 if name=='foundation.do':
  s=s.replace('vlog -sv -work lighthd_foundation_work tb/tb_dilithium/lighthd_sign_input_c20_reference.sv','vlog -sv -work lighthd_foundation_work tb/tb_dilithium/lighthd_bitunpkg_c21_reference.sv tb/tb_dilithium/tb_lighthd_unpack_counter.sv tb/tb_dilithium/tb_lighthd_operand_queue.sv tb/tb_dilithium/lighthd_sign_input_c20_reference.sv')
  s=s.replace('foreach top {tb_lighthd_sign_input','foreach top {tb_lighthd_unpack_counter tb_lighthd_operand_queue tb_lighthd_sign_input')
 if name=='foundation_runner.ps1':
  s=s.replace("@('LIGHTHD_CONTROLLER_LIFETIME", "@('LIGHTHD_UNPACK_COUNTER_CYCLE_PASS:174350','LIGHTHD_OPERAND_QUEUE_MODEL_PASS:4131 pushes/4125 pops/663 full clocks/3878 renewals/3 occupied reset observations/phases11','LIGHTHD_CONTROLLER_LIFETIME",1)
  s=s.replace("@('lighthd_owner_selftest'","@('lighthd_counter_selftest','lighthd_owner_selftest'")
 if name in ('area_delta.py','throughput.py'):
  s=s.replace('stage7c20_area_inventory.json','stage7c21_area_inventory.json').replace('stage7c20_throughput.json','stage7c21_throughput.json').replace('C20','C21').replace('63.59','63.37')
 if name=='cycle_audit.py':s=s.replace('stage7c22_baseline_c20','stage7c22_baseline_c21').replace('C20','C21')
 if name=='operand_registers.py':
  a=s.index('for label,expr,lo,hi in [');b=s.index(']:\n',a)+2
  s=s[:a]+'''for label,expr,lo,hi in [('raw_operands',r'\\|lighthd_process_dma:process_path\\|operand_[ab]_store_r',368,368),
                       ('word_tags',r'\\|lighthd_process_dma:process_path\\|operand_tag_store_r',12,12),
                       ('occupancy',r'\\|lighthd_process_dma:process_path\\|operand_count_r',2,2),
                       ('pointers',r'\\|lighthd_process_dma:process_path\\|operand_(read|write)_r',2,2)]:''' + s[b:]
  s=s.replace('184 raw payload bits/word tag/valid physically retained','368 raw payload/12 tag/2 occupancy/2 pointer bits;two entries physically retained')
 u['sim/dilithium/reference_build/stage7c22_'+name]=s
u['sim/dilithium/reference_build/stage7c22_source_audit.py']='''from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c21_source_hashes.json').read_text());new=json.loads((rb/'stage7c22_source_hashes.json').read_text())
for n,d in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
assert len(new)==259 and len(set(new)-set(old))==3
assert {n for n in old if old[n]!=new[n]}=={'src/controller/process/lighthd_bitunpkg.sv','src/controller/datapath/lighthd_process_dma.sv','sim/dilithium/dilithium_vectors.py','quartus/dilithium/report_full.tcl'}
print('C22_SOURCE_AUDIT_PASS:259 frozen/two transport-bookkeeping RTL changes/3new reference-test files;engine and Process arithmetic,RAM rules,QSF,SDC unchanged C21')
'''
old=json.loads((rb/'stage7c21_source_hashes.json').read_text());paths=set(old)
paths|={'tb/tb_dilithium/'+n+'.sv' for n in ('lighthd_bitunpkg_c21_reference','tb_lighthd_unpack_counter','tb_lighthd_operand_queue')}
assert len(paths)==259
u['sim/dilithium/reference_build/stage7c22_source_hashes.json']=json.dumps({n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in sorted(paths)},indent=2)+'\n'
patch='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and Path(n).name not in sys.argv[1:]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
