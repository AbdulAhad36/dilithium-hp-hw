from pathlib import Path
import json,difflib,sys
r=Path.cwd();changes={}
for folder,n in [('process','lighthd_bitunpkg'),('datapath','lighthd_process_dma')]:
 changes['src/controller/'+folder+'/'+n+'.sv']=(r/('tmp/c22_'+n+'.sv')).read_text(encoding='utf-8')
changes['tb/tb_dilithium/lighthd_bitunpkg_c21_reference.sv']=(r/'tmp/lighthd_bitunpkg_c21_reference.sv').read_text(encoding='utf-8')
changes['tb/tb_dilithium/tb_lighthd_unpack_counter.sv']=(r/'tmp/tb_c22_unpack_probe.sv').read_text().replace('module tb_c22_unpack_probe;','module tb_lighthd_unpack_counter;').replace('C22_UNPACK_COUNTER_CYCLE_PASS','LIGHTHD_UNPACK_COUNTER_CYCLE_PASS')
changes['tb/tb_dilithium/tb_lighthd_operand_queue.sv']=(r/'tmp/tb_c22_operand_queue.sv').read_text().replace('module tb_c22_operand_queue;','module tb_lighthd_operand_queue;').replace('C22_OPERAND_QUEUE_MODEL_PASS','LIGHTHD_OPERAND_QUEUE_MODEL_PASS')
patch='*** Begin Patch\n'
for n,s in changes.items():
 if len(sys.argv)>1 and Path(n).stem not in sys.argv[1:]:continue
 p=r/n
 if not p.exists():patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
 else:
  lines=list(difflib.unified_diff(p.read_text(encoding='utf-8').splitlines(True),s.splitlines(True)))
  patch+='*** Update File: '+n+'\n'+''.join('@@\n' if x.startswith('@@') else x for x in lines[2:])
print(json.dumps(patch+'*** End Patch'))
