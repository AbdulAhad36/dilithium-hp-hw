from pathlib import Path
import json,re,sys,difflib
r=Path.cwd();h=r/'sim/dilithium';rb=h/'reference_build'
assert 'STAGE7C22_RESULT_COLLECTION_PASS' in (h/'stage7c22_recovered_collection_r1.log').read_text()
m=json.loads((rb/'stage7c22_metrics.json').read_text());old=json.loads((rb/'stage7c21_metrics.json').read_text());a=m['area']
f=min(c['fmax_mhz'] for c in m['corners']);setup=min(c['setup_ns'] for c in m['corners']);hold=min(c['hold_ns'] for c in m['corners'])
area_delta=a['placed_ALMs']-old['area']['placed_ALMs'];freq_delta=f-63.37;gain=100*(f/63.37-1)
cycles=json.loads((rb/'stage7c22_cycle_deltas.json').read_text());assert len(cycles['native'])==286 and len(cycles['UVM'])==30
native_deltas=[x['delta'] for x in cycles['native']];uvm_deltas=[n for x in cycles['UVM'] for n in x['delta'].values()]
if all(n==0 for n in native_deltas+uvm_deltas):cycle_note='All286 completed official/protocol latencies and30 main-UVM latency rows exactly match C21;the12 reset-prefix records also match. No operation cycles were added.'
else:cycle_note=f'Completed native latency changes range{min(native_deltas):+}..{max(native_deltas):+} clocks. Main-UVM field changes range{min(uvm_deltas):+}..{max(uvm_deltas):+};per-operation means are reported below and in the cycle audit.'
u=(h/'stage7c22_uvm.log').read_text(encoding='utf-8',errors='replace');bins={}
for key,label in [('functional','OVERALL FUNCTIONAL COVERAGE'),('module','DUT MODULE CODE COVERAGE'),('package','SHARED DUT PACKAGE CODE COVERAGE'),('overall','OVERALL DUT CODE COVERAGE')]:
 z=re.search(re.escape(label)+r'.*?:\s*(\d+) / (\d+)',u);assert z,label;bins[key]=tuple(map(int,z.groups()))
token=(h/'stage7c4_main_inputs.txt').read_text().split()[0];uvmtoken=re.search(r'[0-9a-f]{64}',(h/'stage7_uvm_inputs.txt').read_text())[0]
status=f'''## C22 source-qualified and routed ready-isolation trial

All259 source hashes,fresh foundation/queue/counter checks,210 official commands,
88 protocol commands,90 checker corruptions and main33 UVM/negative pass.
Actual final placement: **{a['placed_ALMs']:,} ALMs**,{a['registers']:,} registers,
{a['M10Ks']} M10Ks and{a['DSPs']} DSPs. Worst Fmax **{f:.2f}MHz**,setup **{setup:+.3f}ns**,
hold **{hold:+.3f}ns**. Versus C21:{area_delta:+,} placed ALMs,{freq_delta:+.2f}MHz/{gain:+.2f}% Fmax.
The same Cyclone V,6.757ns and hold constraints remain. These are final placed
ALMs. Under20K/148MHz and user performance acceptance remain open. C20/C21
are preserved. Full corner/cycle/rate tables are in THROUGHPUT.md.

{cycle_note}

The original full flow routed successfully,then the assembler crashed293007.
Manual ASM recovery passes. The first STA retry used an unsupported option;
corrected STA,retained-hardware and four-corner reports pass without a refit
or source/QSF/SDC change. Original failure/retry logs are preserved. This is
successful manual post-fit recovery,not a new successful full-flow compile.

'''
common='''The unpacker computes occupancy progress independently of canonicality;
the existing invalid-field override still clears count and reports error2.
Output validity and field arithmetic are unchanged. The finite32,768-case
counter model and174350 actual old/new RTL clocks pass,including internal
count/state/ring positions and all visible controls/valid data/status.

The Process raw operand FIFO holds two190-bit tuples plus4 control bits:
368 raw payload,12 tag,2 occupancy and2 pointer bits. Admission uses registered
occupancy. The actual-RAM scoreboard checks4131 admissions/4125 deliveries,
663 full clocks,3878 renewals and three full resets at both read-pointer phases.
Payload ordering,held-head stability and II1 transfers pass. Process arithmetic,
polynomial RAM rules and the214-bit writer handoff remain unchanged.

'''
corners='|Corner|Fmax MHz|Setup ns|Setup TNS ns|Hold ns|Hold TNS ns|\n|---|---:|---:|---:|---:|---:|\n'
for c in m['corners']:corners+=f"|{c['corner']}|{c['fmax_mhz']:.2f}|{c['setup_ns']:+.3f}|{c['setup_tns_ns']:.3f}|{c['hold_ns']:+.3f}|{c['hold_tns_ns']:.3f}|\n"
t=json.loads((rb/'stage7c22_throughput.json').read_text());table='|Operation|Level|Mean cycles|Cycle delta vs C21|Estimated latency us|Estimated operations/s|Rate delta vs C21|\n|---|---:|---:|---:|---:|---:|---:|\n'
for row in t['rows']:table+=f"|{row['operation']}|{row['level']}|{row['cycles']:.2f}|{row['cycle_delta_vs_C21']:+.2f}|{row['latency_us']:.1f}|{row['operations_per_second']:.1f}|{row['rate_gain_vs_C21_pct']:+.2f}%|\n"
coverage='|Main coverage|Hit / defined|Percent|\n|---|---:|---:|\n'
for key,label in [('functional','Functional'),('module','RTL module raw code'),('package','Executable shared package raw code'),('overall','Overall DUT raw code')]:
 hit,total=bins[key];coverage+=f'|{label}|{hit} / {total}|{100*hit/total:.2f}%|\n'
proof='''Focused queue/counter hits are not merged into main UVM coverage. Current-token
corrupt first key byte rejects with no credited outcomes. The unchanged full
Process-domain proof is reused from C18R1 via10 byte-identical files,not rerun
or retagged as fresh. Initial queue tests without full-reset pressure failed
their missing-reset witness;the corrected gate stalls both sides of the actual
bank handshake and proves three full resets/both phases.

'''
worst=min(m['corners'],key=lambda c:c['setup_ns']);q=r/'quartus/dilithium/critical_full'/f"{worst['corner']}_setup.rpt"
text=q.read_text(errors='replace');path=None
for line in text.splitlines():
 c=[x.strip() for x in line.split(';')[1:-1]]
 if len(c)==8 and re.fullmatch(r'-?\d+\.\d+',c[0]):path=c;break
assert path,q
levels=re.search(r'; Number of Logic Levels\s*;\s*;\s*(\d+)',text);assert levels
short=lambda node:'|'.join(node.split('|')[-2:])
nextnote=f'''Fresh worst setup path ({worst['corner']}):`{short(path[1])}` to
`{short(path[2])}`,{levels[1]} logic levels/{path[-1]}ns data delay.
Use this path and disjoint placed-area scopes for the next Stage7C trial.
Another{max(0,a['placed_ALMs']-19999)} actual placed ALMs must be removed to reach19999.
Do not infer clock closure or performance acceptance from passing vectors.
No Stage8,commit,branch change or complete unpublished-RTL replica claim.

Create-only evidence:`evidence/stage7c22_ready_isolation_qualified.zip` and its
SHA256 sidecar. Fresh extraction replay is required before handoff;replay is
a saved-evidence check,not another native simulation run.

'''
extras={'DILITHIUM_PLAN.md':common+nextnote,'THROUGHPUT.md':common+corners+'\n'+table+'\nRates use measured cycles and actual worst Fmax;sequential estimates,not board measurements or command initiation interval.\n\n','MEMORY_MAP.md':common,'PROCESS_BLOCKS.md':common,'COVERAGE.md':coverage+'\n'+proof,'REFERENCE_VERIFICATION.md':common+f'Main token `{token}`.\n\nUVM token `{uvmtoken}`.\n\n'+proof,'SPECIFICATION.md':common}
patch='*** Begin Patch\n'
for leaf,extra in extras.items():
 if len(sys.argv)>1 and leaf not in sys.argv[1:]:continue
 p=r/'docs/dilithium_docs'/leaf;s=p.read_text(encoding='utf-8');title,tail=s.split('\n\n',1)
 if tail.startswith('## C22'):
  z=re.search(r'\n## C21 ',tail);assert z,leaf;tail=tail[z.start()+1:]
 new=title+'\n\n'+status+extra+tail
 d=list(difflib.unified_diff(s.splitlines(True),new.splitlines(True)))
 patch+='*** Update File: '+p.relative_to(r).as_posix()+'\n'+''.join('@@\n' if x.startswith('@@') else x for x in d[2:])
print(json.dumps(patch+'*** End Patch'))
