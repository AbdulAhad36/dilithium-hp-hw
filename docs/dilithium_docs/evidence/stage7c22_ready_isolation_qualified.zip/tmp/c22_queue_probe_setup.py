from pathlib import Path
import json
r=Path.cwd();s=(r/'tb/tb_dilithium/tb_lighthd_process_dma.sv').read_text().replace('module tb_lighthd_process_dma;','module tb_c22_operand_queue;')
anchor='  int stream_words=0,expected_stream_words=0,cycles=0,hint_words=0,hints_checked=0;'
code='''  logic [189:0] queue_model[$];logic [189:0] expected_head;
  int queue_pushes=0,queue_pops=0,queue_full=0,queue_peak=0,queue_renewals=0;
  int queue_reset_occupied=0;logic [1:0] reset_read_phases=0;
  always @(posedge clk)begin
    if(rst)begin
      if(queue_model.size()!=0)begin queue_reset_occupied++;reset_read_phases[dut.operand_read_r]=1;end
      queue_model.delete();
    end else if(dut.state!=dut.STREAM)queue_model.delete();
    else begin
      if(dut.operand_count_r!=queue_model.size())$fatal(1,"Operand queue count/model mismatch");
      if(dut.operand_count_r>queue_peak)queue_peak=dut.operand_count_r;
      if(dut.operand_count_r==2)begin
        queue_full++;
        if(dut.operand_ready || dut.operand_take || |dut.memory_read_ready_o)$fatal(1,"Full queue admitted RAM word");
      end
      if(dut.operand_pop)begin
        if(queue_model.size()==0)$fatal(1,"Queue popped without a model head");
        expected_head=queue_model.pop_front();
        if({dut.operand_a_r,dut.operand_b_r,dut.operand_tag_r[5:0]}!==expected_head)
          $fatal(1,"Operand queue reorder/duplicate/payload-tag corruption");
        queue_pops++;
      end
      if(dut.operand_take)begin
        queue_model.push_back({dut.memory_read_data_i[dut.port_r[0]][dut.bank_r[0]],
          dut.memory_read_data_i[dut.port_r[1]][dut.bank_r[1]],dut.consumed_r[5:0]});
        queue_pushes++;
      end
      if(dut.operand_take && dut.operand_pop)queue_renewals++;
    end
  end
'''
assert anchor in s;s=s.replace(anchor,code+anchor)
s=s.replace('    $finish;', '''    if(queue_peak!=2 || queue_full==0 || queue_renewals==0 || queue_reset_occupied==0)
      $fatal(1,"Operand queue pressure/reset witness missing");
    $display("C22_OPERAND_QUEUE_MODEL_PASS:%0d pushes/%0d pops/%0d full clocks/%0d renewals/%0d occupied reset observations/phases%b;actual RAM and Process",queue_pushes,queue_pops,queue_full,queue_renewals,queue_reset_occupied,reset_read_phases);
    $finish;''')
do='''onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vmap c22_probe sim/dilithium/work_c22_probe
vlog -sv -work c22_probe tmp/tb_c22_operand_queue.sv
vsim -L cyclonev_ver c22_probe.tb_c22_operand_queue
onfinish stop
run -all
quit -f
'''
u={'tmp/tb_c22_operand_queue.sv':s,'tmp/c22_queue.do':do}
print(json.dumps('*** Begin Patch\n'+''.join('*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in v.splitlines()) for n,v in u.items())+'*** End Patch'))
