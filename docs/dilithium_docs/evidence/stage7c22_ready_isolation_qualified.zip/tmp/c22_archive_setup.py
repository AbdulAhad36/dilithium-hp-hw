from pathlib import Path
import json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
s=(rb/'stage7c21_archive.py').read_text(encoding='utf-8')
s=s.replace('stage7c21','stage7c22').replace('STAGE7C21','STAGE7C22').replace('C21_','C22_')
s=s.replace('controller_lifetimes_qualified','ready_isolation_qualified')
s=s.replace("stage='7C.21 local controller lifetime sharing and registered owner selection'","stage='7C.22 unpacker bookkeeping and two-entry Process ready isolation'")
s=s.replace('fresh_C21_execution=False','fresh_C22_execution=False')
for leaf in ('metrics','area_inventory','source_hashes','throughput'):
 s=s.replace('stage7c20_'+leaf+'.json','stage7c21_'+leaf+'.json')
a=s.index("for leaf in ('c21_prototypes.py'");b=s.index("for p in rb.glob('stage7c22*')",a)
s=s[:a]+'''for p in (r/'tmp').glob('c22*.py'):paths.add(p.relative_to(r).as_posix())
for leaf in ('c22_probe.do','c22_queue.do'):
    paths.add('tmp/'+leaf)
''' + s[b:]
s=s.replace("for folder in ('stage7c22_sign_map_baseline','stage7c22_sign_map_lifetime','stage7c22_verify_map_baseline','stage7c22_verify_map_lifetime'):","for folder in ('stage7c22_bitunpkg_map_baseline','stage7c22_bitunpkg_map_candidate','stage7c22_process_dma_map_baseline','stage7c22_process_dma_map_candidate'):")
s=s.replace("for p in (r/'tmp').glob('lighthd_*_c20_reference.sv'):","for p in (r/'tmp').glob('lighthd_bitunpkg_c21_reference.sv'):")
s=s.replace("private_probes='Diagnostic9/protocol88/default input135-105/hint106-shared60 pass;initial declaration/standalone wildcard binding errors retained as failed trials'", "private_probes='Unpacker174350 cycles/DMA64/main9/protocol88 pass;initial full-reset test lacked forced bank pressure and failed its missing-reset witness;corrected test checks both phases'")
s=s.replace("memory_contract='Polynomial RAM/collision rules and214bit writer handoff unchanged;Sign TR->Mu,key-rnd->mask;Verify TR->Mu->digest;standalone snapshot defaults preserved'", "memory_contract='Polynomial RAM/collision rules and214bit writer unchanged;Process raw operand queue384bits/admission by registered occupancy;unpacker count keeps validation/error priority'")
s=s.replace(" controller_cycle_checks=dict(diagnostic_clocks=195757,protocol_clocks=972701,owner_model_combinations=65536),", " controller_cycle_checks=dict(diagnostic_clocks=195757,protocol_clocks=972701,owner_model_combinations=65536),\n counter_model_combinations=32768,unpacker_exact_RTL_cycles=174350,\n operand_queue_test=dict(admissions=4131,deliveries=4125,full_clocks=663,renewals=3878,full_resets=3,reset_read_phases=[0,1]),\n operand_queue_physical_guards=json.loads((rb/'stage7c22_operand_registers.json').read_text()),")
anchor="assert 'LIGHTHD_PROCESS_OPERAND_STAGE_PASS:' in foundation"
s=s.replace(anchor,anchor+"\nassert 'LIGHTHD_UNPACK_COUNTER_CYCLE_PASS:174350' in foundation\nassert 'LIGHTHD_OPERAND_QUEUE_MODEL_PASS:4131 pushes/4125 pops/663 full clocks/3878 renewals/3 occupied reset observations/phases11' in foundation\nassert 'LIGHTHD_COUNTER_PRIORITY_MODEL_PASS:32768' in read(h/'stage7c22_lighthd_counter_selftest.log')")
replay=(rb/'stage7c21_archive_replay.py').read_text(encoding='utf-8').replace('stage7c21','stage7c22').replace('C21_','C22_').replace('controller_lifetimes','ready_isolation')
replay=replay.replace("('lighthd_owner_selftest'","('lighthd_counter_selftest','lighthd_owner_selftest'")
u={'sim/dilithium/reference_build/stage7c22_archive.py':s,'sim/dilithium/reference_build/stage7c22_archive_replay.py':replay}
print(json.dumps('*** Begin Patch\n'+''.join('*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in v.splitlines()) for n,v in u.items())+'*** End Patch'))
