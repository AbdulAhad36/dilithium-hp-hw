from pathlib import Path
import json,sys
r=Path.cwd();changes={}
s=(r/'tb/tb_dilithium/tb_lighthd_bitunpkg_ring.sv').read_text()
s=s.replace('module tb_lighthd_bitunpkg_ring;','module tb_c22_unpack_probe;').replace('lighthd_bitunpkg_c16_reference reference_dut','lighthd_bitunpkg_c21_reference reference_dut')
# C21 already includes the same invalid-ready behavior;all controls now match.
a=s.index('    if(input_ready_o!==ref_input_ready)begin');b=s.index('    if(output_valid_o &&',a)
s=s[:a]+'''    if(input_ready_o!==ref_input_ready)$fatal(1,"C22 admission changed from C21");
    if(dut.count_r!==reference_dut.count_r || dut.state!==reference_dut.state ||
       {dut.read_slot_r,dut.write_slot_r,dut.bit_offset_r,dut.coefficients_r}!==
       {reference_dut.read_slot_r,reference_dut.write_slot_r,reference_dut.bit_offset_r,reference_dut.coefficients_r})
      $fatal(1,"C22 unpacker state/counter mismatch");
''' + s[b:]
s=s.replace('    if(reject_ready_deltas==0)$fatal(1,"Reject admission edge not exercised");','    if(reject_ready_deltas!=0)$fatal(1,"Unexpected ready delta");')
s=s.replace('LIGHTHD_BITUNPKG_RING_CYCLE_PASS','C22_UNPACK_COUNTER_CYCLE_PASS')
changes['tmp/tb_c22_unpack_probe.sv']=s
s=(r/'sim/dilithium/reference_build/stage7c21_foundation.do').read_text()
s=s.replace('work_lighthd_foundation','work_c22_probe').replace('lighthd_foundation_work','c22_probe')
s=s.replace('    vlog -sv -work c22_probe [file normalize [file join quartus/dilithium $source]]', '''    set stem [file rootname [file tail $source]]
    if {$stem eq "lighthd_bitunpkg" || $stem eq "lighthd_process_dma"} {vlog -sv -work c22_probe tmp/c22_${stem}.sv} else {
      vlog -sv -work c22_probe [file normalize [file join quartus/dilithium $source]]
    }''')
s=s.replace('foreach top {tb_lighthd_sign_input', 'vlog -sv -work c22_probe tmp/lighthd_bitunpkg_c21_reference.sv tmp/tb_c22_unpack_probe.sv\nforeach top {tb_lighthd_sign_input')
a=s.index('foreach top {');b=s.index(' {\n',a)
s=s[:a]+'foreach top {tb_c22_unpack_probe tb_lighthd_process_dma tb_lighthd_controller_lifetimes}'+s[b:]
# The private main outputs must not overwrite C21's final capture files.
main=(r/'tb/tb_dilithium/tb_lighthd_main.sv').read_text()
for leaf in ('outputs.txt','diagnostic_outputs.txt','protocol_outputs.txt'):main=main.replace('stage7c4_main_'+leaf,'stage7c22_probe_main_'+leaf)
changes['tmp/tb_c22_main_probe.sv']=main
s=s.replace('tb/tb_dilithium/tb_lighthd_main.sv','tmp/tb_c22_main_probe.sv')
a=s.index('foreach different {');b=s.index('vsim -L cyclonev_ver -gDIAGNOSTIC=0',a)
s=s[:a]+s[b:]
changes['tmp/c22_probe.do']=s
patch='*** Begin Patch\n'
for n,v in changes.items():
 if len(sys.argv)>1 and Path(n).stem not in sys.argv[1:]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in v.splitlines())
print(json.dumps(patch+'*** End Patch'))
