from pathlib import Path
import importlib.util,re
r=Path.cwd();h=r/'sim/dilithium'
p=h/'dilithium_vectors.py';s=importlib.util.spec_from_file_location('vectors',p);v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
v.lighthd_main_compare(diagnostic=True,captured=(h/'stage7c22_probe_main_diagnostic_outputs.txt').read_text())
v.lighthd_main_protocol_compare(captured=(h/'stage7c22_probe_main_protocol_outputs.txt').read_text())
t=(h/'stage7c22_private_probe.log').read_text()
for marker in ('C22_UNPACK_COUNTER_CYCLE_PASS:174350','LIGHTHD_PROCESS_DMA_PASS:cases64','LIGHTHD_CONTROLLER_LIFETIME_CYCLE_PASS:195757cycles/3Sign/3Verify/3full digests/3retry contexts','LIGHTHD_CONTROLLER_LIFETIME_CYCLE_PASS:972701cycles/14Sign/27Verify/15full digests/11retry contexts'):
 assert marker in t,marker
assert '# ** Fatal:' not in t and '# ** Error:' not in t
print('C22_PRIVATE_MAIN_PROBES_PASS:private source overrides with C21 fixtures;fresh production qualification still required')
