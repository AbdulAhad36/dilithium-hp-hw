onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vmap c22_probe sim/dilithium/work_c22_probe
vlog -sv -work c22_probe tmp/tb_c22_operand_queue.sv
vsim -L cyclonev_ver c22_probe.tb_c22_operand_queue
onfinish stop
run -all
quit -f
