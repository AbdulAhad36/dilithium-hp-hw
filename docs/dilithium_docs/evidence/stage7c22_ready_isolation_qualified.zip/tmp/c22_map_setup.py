from pathlib import Path
import json,re,sys
r=Path.cwd();changes={}
sources=[(r/'quartus/dilithium'/m).resolve() for m in re.findall(r'SYSTEMVERILOG_FILE\s+(.+)',(r/'quartus/dilithium/dilithium_full.qsf').read_text())]
base=(r/'tmp/stage7c19_formatter_map_baseline/probe.qsf').read_text().split('set_global_assignment -name TOP_LEVEL_ENTITY')[0]
for top in ('bitunpkg','process_dma'):
 if len(sys.argv)>1 and top not in sys.argv[1:]:continue
 for variant in ('baseline','candidate'):
  folder='tmp/stage7c22_'+top+'_map_'+variant
  qsf=base+'set_global_assignment -name TOP_LEVEL_ENTITY lighthd_'+top+'\n'
  for source in sources:
   override=r/('tmp/c22_'+source.stem+'.sv')
   path=override if variant=='candidate' and override.exists() else source
   qsf+='set_global_assignment -name SYSTEMVERILOG_FILE "'+path.as_posix()+'"\n'
  changes[folder+'/probe.qsf']=qsf
  changes[folder+'/probe.qpf']='PROJECT_REVISION = "probe"\n'
patch='*** Begin Patch\n'
for n,s in changes.items():
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+line+'\n' for line in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
