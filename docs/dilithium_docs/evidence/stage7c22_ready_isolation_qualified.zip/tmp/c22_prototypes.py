from pathlib import Path
import json,sys
r=Path.cwd();changes={}
s=(r/'src/controller/process/lighthd_bitunpkg.sv').read_text()
s=s.replace('logic ended_r,pop,push,enough,bad_value,bad_frame;','logic ended_r,pop,push,enough,bad_value,bad_frame,count_consume;\n  logic [7:0] count_after_group,count_with_word,count_group_with_word;')
s=s.replace('  assign push=input_valid_i && input_ready_o;','''  assign push=input_valid_i && input_ready_o;
  // Counter bookkeeping ignores canonicality until the existing error
  // override. Invalid fields always clear count and enter REPORT below.
  // The published output/pop still require successful field validation.
  assign count_consume=!rst && state==FEED && enough && output_ready_i;
  assign count_after_group=count_r-group_bits;
  // Modulo256 addition of64 uses only the upper two bits,no carry chain
  // after the late consume/refill selection.
  assign count_with_word={count_r[7]^count_r[6],~count_r[6],count_r[5:0]};
  assign count_group_with_word={count_after_group[7]^count_after_group[6],~count_after_group[6],count_after_group[5:0]};''')
s=s.replace("    count_next=count_r-(pop?group_bits:8'd0);\n    if(push && !bad_frame)count_next=count_next+8'd64;",'''    case({count_consume,push && !bad_frame})
      2'b01:count_next=count_with_word;
      2'b10:count_next=count_after_group;
      2'b11:count_next=count_group_with_word;
      default:count_next=count_r;
    endcase''')
s=s.replace('if(pop || push)count_r<=count_next;','if(count_consume || push)count_r<=count_next;')
changes['tmp/c22_lighthd_bitunpkg.sv']=s
s=(r/'src/controller/datapath/lighthd_process_dma.sv').read_text()
s=s.replace('logic operand_valid_r,operand_ready,operand_take;','''logic operand_valid_r,operand_ready,operand_take,operand_pop;
  logic [1:0] operand_count_r;
  logic operand_read_r,operand_write_r;
  (* ramstyle="logic" *) logic [1:0][91:0] operand_a_store_r,operand_b_store_r;
  (* ramstyle="logic" *) logic [1:0][5:0] operand_tag_store_r;''')
s=s.replace('    operand_ready=!operand_valid_r || process_ready;', '    operand_ready=operand_count_r<2;')
a=s.index('  // One elastic word;');b=s.index('  always_ff @(posedge clk or posedge rst)begin\n    if(rst)begin\n      state<=IDLE;',a)
s=s[:a]+'''  // Two registered raw-word entries break output-ready -> RAM-read-ready
  // feedback. Admission depends only on registered occupancy. The head is
  // stable under stalls;simultaneous pop/push retains one word per clock.
  assign operand_valid_r=operand_count_r!=0;
  assign operand_a_r=operand_a_store_r[operand_read_r];
  assign operand_b_r=operand_b_store_r[operand_read_r];
  assign operand_tag_r={1'b0,operand_tag_store_r[operand_read_r]};
  assign operand_pop=process_valid && process_ready;
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin operand_count_r<=0;operand_read_r<=0;operand_write_r<=0;end
    else if(state!=STREAM)begin operand_count_r<=0;operand_read_r<=0;operand_write_r<=0;end
    else begin
      case({operand_take,operand_pop})
        2'b10:operand_count_r<=operand_count_r+1'b1;
        2'b01:operand_count_r<=operand_count_r-1'b1;
        default:begin end
      endcase
      if(operand_take)operand_write_r<=!operand_write_r;
      if(operand_pop)operand_read_r<=!operand_read_r;
    end
  end
  always_ff @(posedge clk)if(operand_take)begin
    operand_a_store_r[operand_write_r]<=memory_read_data_i[port_r[0]][bank_r[0]];
    operand_b_store_r[operand_write_r]<=memory_read_data_i[port_r[1]][bank_r[1]];
    operand_tag_store_r[operand_write_r]<=consumed_r[5:0];
  end
  // synthesis translate_off
  always @(posedge clk)if(!rst && state==STREAM)begin
    if(operand_count_r>2 || (operand_pop && operand_count_r==0) ||
      (operand_take && operand_count_r==2))$fatal(1,"Process operand queue occupancy");
    if(operand_take && operand_count_r!=0 && operand_write_r==operand_read_r)
      $fatal(1,"Process operand queue overwrites a live head");
  end
  // synthesis translate_on
''' + s[b:]
changes['tmp/c22_lighthd_process_dma.sv']=s
s=(r/'src/controller/process/lighthd_bitunpkg.sv').read_text().replace('module lighthd_bitunpkg (','module lighthd_bitunpkg_c21_reference (')
changes['tmp/lighthd_bitunpkg_c21_reference.sv']=s
patch='*** Begin Patch\n'
for n,s in changes.items():
 if len(sys.argv)>1 and Path(n).stem not in sys.argv[1:]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
