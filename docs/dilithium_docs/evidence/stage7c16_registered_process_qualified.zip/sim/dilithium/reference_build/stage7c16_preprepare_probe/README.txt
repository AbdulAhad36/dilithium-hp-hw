Compilation/standalone mathematical diagnostics only. Main9/NTT/hint capture headers predate C16 preparation;not accepted fresh source gates. Fresh prepare and all captures must rerun.
