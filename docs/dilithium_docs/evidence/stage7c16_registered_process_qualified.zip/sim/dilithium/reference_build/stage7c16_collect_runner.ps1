$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
foreach ($jobId in @(22408,21388,22968)) {Wait-Process -Id $jobId -ErrorAction SilentlyContinue}
foreach ($kind in @('native','uvm','quartus')) {
  $marker='STAGE7C16_'+$kind.ToUpper()+'_RUNNER_PASS'
  if (-not (Select-String -LiteralPath "sim/dilithium/stage7c16_${kind}_runner.log" -Pattern $marker -Quiet)) {throw "C16 qualification incomplete: $kind"}
}
foreach ($reader in @('source_audit','metrics','admission_registers','native_structure','shared_hint_registers','operand_registers','area_delta','throughput','cycle_audit')) {
  & 'C:/Python314/python.exe' "sim/dilithium/reference_build/stage7c16_${reader}.py" *> "sim/dilithium/stage7c16_${reader}_console.log"
  if ($LASTEXITCODE -ne 0) {throw "C16 result reader failed: $reader"}
}
& 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py uvm_check *> sim/dilithium/stage7c16_final_uvm_check.log
if ($LASTEXITCODE -ne 0) {throw 'C16 final UVM freshness failed'}
'STAGE7C16_RESULT_COLLECTION_PASS'
