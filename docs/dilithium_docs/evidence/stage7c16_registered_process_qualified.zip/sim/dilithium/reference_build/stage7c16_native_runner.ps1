$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
foreach ($gate in @('lighthd_prepare','lighthd_hint_prepare','lighthd_main_prepare','uvm_prepare')) {
  & 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py $gate *> "sim/dilithium/stage7c16_${gate}.log"
  if ($LASTEXITCODE -ne 0) {throw "Preparation failed: $gate"}
}
'STAGE7C16_PREPARE_PASS'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File sim/dilithium/reference_build/stage7c16_foundation_runner.ps1
if ($LASTEXITCODE -ne 0) {throw 'Foundation runner failed;no full build launched'}
$uvmJob=Start-Process -FilePath powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File','sim/dilithium/reference_build/stage7c16_uvm_runner.ps1') -WindowStyle Hidden -RedirectStandardOutput sim/dilithium/stage7c16_uvm_runner.log -RedirectStandardError sim/dilithium/stage7c16_uvm_runner_errors.log -PassThru
$physicalJob=Start-Process -FilePath powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File','sim/dilithium/reference_build/stage7c16_quartus_runner.ps1') -WindowStyle Hidden -RedirectStandardOutput sim/dilithium/stage7c16_quartus_runner.log -RedirectStandardError sim/dilithium/stage7c16_quartus_runner_errors.log -PassThru
@{uvm=$uvmJob.Id;quartus=$physicalJob.Id}|ConvertTo-Json|Set-Content sim/dilithium/reference_build/stage7c16_job_ids.json
'STAGE7C16_FOUNDATION_PASS_FULL_JOBS_STARTED'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File sim/dilithium/reference_build/stage7c16_production_runner.ps1
if ($LASTEXITCODE -ne 0) {throw 'Production runner failed'}
'STAGE7C16_NATIVE_RUNNER_PASS'
