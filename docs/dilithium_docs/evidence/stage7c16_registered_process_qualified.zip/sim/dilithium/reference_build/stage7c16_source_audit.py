from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c15_source_hashes.json').read_text())
new=json.loads((rb/'stage7c16_source_hashes.json').read_text())
for n,digest in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==digest,n
changed=[n for n in old if old[n]!=new[n]]
expected={'src/controller/process/cnb.sv','src/controller/process/mhint.sv',
  'src/controller/datapath/lighthd_process_dma.sv','sim/dilithium/dilithium_vectors.py',
  'tb/tb_dilithium/tb_lighthd_process_dma.sv','quartus/dilithium/report_full.tcl'}
assert set(changed)==expected,changed
added=sorted(set(new)-set(old));assert len(added)==3,added
result=dict(frozen_files=len(new),changed_existing=changed,added_proof_sources=added,
  unchanged_existing=len(old)-len(changed),NTT_Keccak_sampler_QSF_SDC='exact C15')
(rb/'stage7c16_source_audit.json').write_text(json.dumps(result,indent=2)+'\n')
print('C16_SOURCE_AUDIT_PASS:240frozen files;3arithmetic-DMA RTL/one bench/Python fingerprint/report guards;all engines/QSF/SDC unchanged')
