`timescale 1ps/1ps
module tb_sign_signature_encode;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,fault_o;logic [1:0] param_i;
  logic [15:0] command_id_i=0,source_id_i;logic source_valid_i;logic [63:0] source_regions_i;
  logic [6:0][5:0] source_z_i;logic [7:0][5:0] source_hint_i;
  logic [511:0] source_ctilde_i;logic [6:0] source_bytes_i;
  logic source_take_valid_o,source_take_ready_i;
  logic output_valid_o,output_ready_i=0;logic [63:0] output_data_o;
  logic [3:0] output_bytes_o;logic [9:0] output_index_o;logic output_last_o;logic [15:0] output_id_o;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o;logic [15:0] done_id_o;
  request_t service_o,loop_request,wire_request;response_t service_i,actual;
  sign_signature_encode dut(.*);
  logic lv=0,lr,lb,lf,pv=0,pr,pl=0,ld,ldr=0,lclear=0,lcr,ltake,ltr;
  logic [15:0] lid=0,pi=0;logic [16:0] start_nonce=0;logic [63:0] pd=0;
  logic [255:0] rnd=0;logic [2:0] lc,ls,le;logic [15:0] ldi;
  logic [16:0] attempts,rejects,nextnonce;logic rv;logic [63:0] regions;
  logic [6:0][5:0] z;logic [7:0][5:0] hints;logic [511:0] digest;logic [6:0] digest_bytes;
  sign_attempt_setup fixture(.clk(clk),.rst(rst),.request_i(wire_request),.response_o(actual));
  sign_attempt_loop attempt(.clk(clk),.rst(rst),.command_valid_i(lv),.command_ready_o(lr),.busy_o(lb),.fault_o(lf),
    .context_valid_i(fixture.context_valid_i),.context_param_i(fixture.context_param_i),.context_id_i(fixture.context_id_i),
    .context_regions_i(fixture.context_regions_i),.context_handles_i(fixture.kh),.context_rho_i(fixture.context_rho_i),
    .context_key_i(fixture.key),.context_tr_i(fixture.tr),.command_id_i(lid),.command_message_len_i(16'd169),
    .command_nonce_i(start_nonce),.command_context_len_i(9'd7),.command_base_i(6'd32),.command_rnd_i(rnd),
    .payload_valid_i(pv),.payload_ready_o(pr),.payload_data_i(pd),.payload_bytes_i(4'd8),.payload_index_i(pi),.payload_last_i(pl),
    .done_valid_o(ld),.done_ready_i(ldr),.done_code_o(lc),.done_stage_o(ls),.done_detail_o(le),.done_id_o(ldi),
    .attempts_o(attempts),.rejections_o(rejects),.next_nonce_o(nextnonce),.result_valid_o(rv),.result_regions_o(regions),
    .result_z_o(z),.result_hint_o(hints),.result_ctilde_o(digest),.result_bytes_o(digest_bytes),
    .clear_valid_i(lclear),.clear_ready_o(lcr),.take_valid_i(ltake),.take_ready_o(ltr),.service_o(loop_request),.service_i(actual));
  int case_no=-1,p,jid,nonce,kind,count,fd,cycles=0,elapsed=0;
  int commands=0,takes=0,outputs=0,reads=0,releases=0,completions=0,aborts=0;
  bit encoding=0,monitor=0,force_fault=0,test_passed=0,hold_output=0,hold_done=0,error_witness=0;
  logic [94:0] held_output;logic [18:0] held_done;logic [63:0] accepted_map;
  always_comb begin
    param_i=2'(p);source_id_i=lid;source_valid_i=rv && kind!=3;source_regions_i=regions;
    source_z_i=z;source_hint_i=hints;source_ctilde_i=digest;source_bytes_i=digest_bytes;
    if(kind==1)source_z_i[1]=z[0];if(kind==2)source_bytes_i=16;
    source_take_ready_i=ltr;ltake=encoding && source_take_valid_o;
    wire_request=encoding?service_o:loop_request;service_i=actual;
    if(encoding)begin
      wire_request.read_valid=service_o.read_valid && cycles%7>2;service_i.read_ready=actual.read_ready && cycles%7>2;
      wire_request.response_ready=service_o.response_ready && cycles%11>3;service_i.response_valid=actual.response_valid && cycles%11>3;
      wire_request.release_valid=service_o.release_valid && cycles%5>1;service_i.release_ready=actual.release_ready && cycles%5>1;
      wire_request.pack.command_valid=service_o.pack.command_valid && cycles%7>2;service_i.pack.command_ready=actual.pack.command_ready && cycles%7>2;
      wire_request.pack.input_valid=service_o.pack.input_valid && cycles%13>4;service_i.pack.input_ready=actual.pack.input_ready && cycles%13>4;
      if(kind==4 && !dut.hints_r && dut.word_r==0)service_i.response_data[22:0]=23'd8249345;
      if(kind==5 && dut.hints_r && dut.word_r==0)service_i.response_data[22:0]=2;
      if((kind==6 || (kind==7 && dut.word_r<2)) && dut.hints_r)service_i.response_data={4{23'd1}};
      if((kind==7 && dut.hints_r && dut.word_r>=2) || (kind==8 && !dut.hints_r))service_i.response_id=actual.response_id^16'd1;
      if(kind==15 && dut.hints_r)service_i.response_mode=2;
      if(kind==16 && dut.hints_r)service_i.response_error=1;
      if(force_fault)service_i.fault=1;
    end
  end
  // Hold the final partial word in every successful run,as well as other stalls.
  int tail_wait=0,error_wait=0;
  always @(negedge clk)begin
    output_ready_i=encoding && cycles%19>6;
    if(output_last_o && tail_wait<9)begin output_ready_i=0;tail_wait++;end
    if(kind==12 && output_last_o)output_ready_i=0;
    if(kind==7 && dut.hints_r && dut.fill_r==8 && error_wait<24)begin output_ready_i=0;error_wait++;end
  end
  always @(posedge clk)begin
    cycles++;
    if(rst)begin hold_output=0;hold_done=0;end
    else if(monitor)begin
      elapsed++;if(elapsed>1800000)$fatal(1,"Encode watchdog case%0d state%0d attempt%0d",case_no,dut.state,attempt.state);
      if(actual.fault || fixture.kfault || lf)$fatal(1,"Encode upstream physical/key fault");
      if(hold_output && !fault_o && !force_fault && (!output_valid_o || held_output!=={output_id_o,output_index_o,output_bytes_o,output_last_o,output_data_o}))$fatal(1,"Encode stalled word changed");
      hold_output=output_valid_o && !output_ready_i;held_output={output_id_o,output_index_o,output_bytes_o,output_last_o,output_data_o};
      if(hold_done && (!done_valid_o || held_done!=={done_id_o,done_code_o}))$fatal(1,"Encode held completion changed");
      hold_done=done_valid_o && !done_ready_i;held_done={done_id_o,done_code_o};
      if(encoding)begin
        if(kind==7 && !error_witness && dut.hints_r && dut.fill_r==8 && actual.response_valid && !output_ready_i)begin
          if(service_o.response_ready || !output_valid_o)$fatal(1,"Encode bad-response barrier missing");
          $fdisplay(fd,"HOLD %0d %0d %0d %0d %0d %016h",case_no,output_id_o,output_index_o,actual.response_word,service_i.response_id,output_data_o);error_witness=1;
        end
        if(command_valid_i && command_ready_o)begin $fdisplay(fd,"C %0d %0d %0d %0d %0d",case_no,param_i,command_id_i,nonce,kind);commands++;end
        if(source_take_valid_o && source_take_ready_i)begin $fdisplay(fd,"T %0d %016h",case_no,source_regions_i);takes++;end
        if(service_o.read_valid && service_i.read_ready)$fdisplay(fd,"U %0d %0d %0d",case_no,{service_o.read_bank,service_o.read_region},service_o.read_word);
        if(service_i.response_valid && service_o.response_ready)begin
          $fdisplay(fd,"V %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,{service_i.response_bank,service_i.response_region},service_i.response_word,
            service_i.response_id,service_i.response_mode,service_i.response_param,service_i.response_ntt_domain,service_i.response_error,service_i.response_data);reads++;
        end
        if(output_valid_o && output_ready_i)begin $fdisplay(fd,"O %0d %0d %0d %0d %0d %016h",case_no,output_id_o,output_index_o,output_bytes_o,output_last_o,output_data_o);outputs++;end
        if(service_o.release_valid && service_i.release_ready)begin
          if(!accepted_map[{service_o.release_bank,service_o.release_region}])$fatal(1,"Encode foreign release");
          $fdisplay(fd,"F %0d %0d",case_no,{service_o.release_bank,service_o.release_region});releases++;
        end
      end
    end
  end
  task automatic reset_all();
    rst=1;monitor=0;encoding=0;force_fault=0;command_valid_i=0;done_ready_i=0;fixture.reset_controls();
    lv=0;pv=0;ldr=0;lclear=0;tail_wait=0;error_wait=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(actual.reserved || busy_o || rv || fault_o)$fatal(1,"Encode reset ownership");
  endtask
  task automatic prepare_attempt(input string skhex,bodyhex);
    int parsed;byte unsigned b;
    fixture.p=p;fixture.case_no=case_no;fixture.sklen=skhex.len()/2;
    if(!fixture.context_valid_i)fixture.prepare_key(skhex);
    lv=1;lid=16'(jid);start_nonce=17'(nonce);do @(posedge clk);while(!lr);@(negedge clk);#1;lv=0;
    for(int w=0;w<22;w++)begin
      pd=0;for(int j=0;j<8;j++)begin parsed=$sscanf(bodyhex.substr(2*(8*w+j),2*(8*w+j)+1),"%h",b);if(parsed!=1)$fatal(1,"Encode body parse");pd[8*j+:8]=b;end
      pi=16'(w);pl=w==21;pv=1;do @(posedge clk);while(!pr);@(negedge clk);#1;pv=0;
    end
    while(!ld)begin @(negedge clk);#1;end
    if(lc || !rv)$fatal(1,"Encode attempt rejected code%0d",lc);
    accepted_map=regions;
    $fdisplay(fd,"R %0d %0d %0d %0d %016h %011h %012h %0d %0128h",case_no,attempts,rejects,nextnonce,regions,z,hints,digest_bytes,digest);
    ldr=1;@(posedge clk);@(negedge clk);#1;ldr=0;
  endtask
  initial begin
    int f;string directory,token,skhex,bodyhex;bit is_abort,hit;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_sign_encode_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d",token,count)!=2)$fatal(1,"Prepare encode fixtures");
    fd=$fopen({directory,"/stage5_sign_encode_outputs.txt"},"w");$fdisplay(fd,"G %s",token);fixture.fd=fd;reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %h %s %s",case_no,p,jid,nonce,kind,rnd,skhex,bodyhex)!=8 || c!=case_no)$fatal(1,"Encode fixture row");
      monitor=0;if(fixture.context_valid_i && fixture.context_param_i!=p)reset_all();elapsed=0;monitor=1;
      prepare_attempt(skhex,bodyhex);encoding=1;command_id_i=16'(jid+256);tail_wait=0;error_wait=0;error_witness=0;command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;
      is_abort=(kind>=8 && kind<=14) || kind==17;
      if(is_abort)begin
        hit=0;
        while(!hit)begin
          @(negedge clk);#1;
          case(kind)
            8:hit=fault_o;
            9:hit=dut.state==3 && output_valid_o;
            10:hit=dut.state==7 && dut.word_r==8;
            11:hit=dut.state==9 && dut.word_r==8;
            12:hit=output_valid_o && output_last_o && !output_ready_i;
            13:hit=done_valid_o;
            14:begin if(dut.state==9)force_fault=1;hit=fault_o;end
            17:hit=dut.hints_r && actual.response_valid && !wire_request.response_ready;
          endcase
          if(done_valid_o && kind!=13)$fatal(1,"Encode abort phase missed kind%0d",kind);
        end
        if(kind==8 || kind==14)begin repeat(4)@(negedge clk);#1;if(!fault_o || done_valid_o || command_ready_o)$fatal(1,"Encode fatal escaped");end
        $fdisplay(fd,"Z %0d %0d %0d %0d",case_no,kind,dut.state,fault_o);aborts++;reset_all();
      end else begin
        while(!done_valid_o)begin @(negedge clk);#1;if(fault_o)$fatal(1,"Encode unexpected halt case%0d state%0d",case_no,dut.state);end
        repeat(7)@(negedge clk);#1;
        if(done_id_o!=jid+256 || done_code_o!=(kind>=1 && kind<=3?1:kind==4?2:kind!=0?3:0))$fatal(1,"Encode wrong completion case%0d code%0d",case_no,done_code_o);
        if(kind==7 && !error_witness)$fatal(1,"Encode held bad-response witness missing");
        $fdisplay(fd,"D %0d %0d %0d",case_no,done_id_o,done_code_o);completions++;
        done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;encoding=0;
        if(kind>=1 && kind<=3)begin
          if(!rv || regions!=accepted_map)$fatal(1,"Encode preflight changed old owner");
          lclear=1;do @(posedge clk);while(!lcr);@(negedge clk);#1;lclear=0;while(lb)begin @(negedge clk);#1;end
        end else if(rv || lb)$fatal(1,"Encode old owner still live");
        if(actual.reserved!==(fixture.context_regions_i|(64'd1<<50)))$fatal(1,"Encode leaked or freed foreign memory");
        $fdisplay(fd,"B %0d %016h",case_no,actual.reserved);
      end
      monitor=0;
    end
    $fdisplay(fd,"END %0d %0d %0d %0d %0d %0d %0d %0d",commands,takes,completions,aborts,outputs,reads,releases,fixture.keys);
    $fclose(f);$fclose(fd);$display("STAGE5N4H5_SIGN_ENCODE_CAPTURE_PASS:%0d commands,%0d completions,%0d aborts",commands,completions,aborts);test_passed=1;$finish;
  end
  initial begin #(64'd2000000000000);$fatal(1,"Encode global watchdog case%0d",case_no);end
endmodule
