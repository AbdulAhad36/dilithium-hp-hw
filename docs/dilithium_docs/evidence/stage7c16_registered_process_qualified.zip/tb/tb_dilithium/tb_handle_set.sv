// Equivalence gate for the area rewrite. Reference is the original sequential
// bitmap-insertion algorithm; stimulus includes every handle value/pair alias,
// noncontiguous active entries, empty sets and irrelevant inactive payloads.
module tb_handle_set;
  logic [31:0][5:0] handles;
  logic [31:0] active;
  logic [31:0] random_state=32'h1765a39b;
  int checked=0;
  function automatic logic [31:0] random_word();
    random_state^=random_state<<13;
    random_state^=random_state>>17;
    random_state^=random_state<<5;
    return random_state;
  endfunction
  task automatic check();
    logic [63:0] mask;
    logic duplicate;
    logic [64:0] actual;
    mask=0;duplicate=0;
    for(int j=0;j<32;j++)if(active[j])begin
      if(mask[handles[j]])duplicate=1;
      mask[handles[j]]=1;
    end
    actual[63:0]=dilithium_service_pkg::handle_mask(handles,active);
    actual[64]=dilithium_service_pkg::handle_count(actual[63:0])!=dilithium_service_pkg::handle_count({32'd0,active});
    if(actual!=={duplicate,mask})$fatal(1,"handle-set mismatch at case %0d",checked);
    checked++;
  endtask
  initial begin
    handles='0;active=0;check();
    for(int base=0;base<64;base++)begin
      for(int j=0;j<32;j++)handles[j]=6'(base+j);
      for(int n=1;n<=32;n++)begin active=32'hffffffff>>(32-n);check();end
      for(int j=0;j<32;j++)begin active=32'd1<<j;handles[j]=6'(base);check();end
      active='1;
      for(int a=0;a<32;a++)for(int b=0;b<a;b++)begin
        for(int j=0;j<32;j++)handles[j]=6'(base+j);
        handles[a]=handles[b];check();
      end
    end
    repeat(10000)begin
      active=random_word();
      for(int j=0;j<32;j++)handles[j]=6'(random_word());
      check();
    end
    for(int n=0;n<=64;n++)begin
      if(dilithium_service_pkg::handle_count(64'hffffffffffffffff>>(64-n))!=n)
        $fatal(1,"Population count mismatch at width %0d",n);
    end
    $display("HANDLE_SET_EQUIVALENCE_PASS:%0d cases;65 population-count widths",checked);$finish;
  end
endmodule
