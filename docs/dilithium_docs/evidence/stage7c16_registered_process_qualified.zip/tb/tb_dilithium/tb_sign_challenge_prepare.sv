`timescale 1ps/1ps
module tb_sign_challenge_prepare;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,fault_o;logic [15:0] command_id_i=0;
  logic context_valid_i;logic [1:0] context_param_i;logic [15:0] context_id_i;
  logic [63:0] context_regions_i;logic [7:0][5:0] context_high_i;logic [511:0] context_mu_i;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o,done_detail_o;logic [15:0] done_id_o;
  logic result_valid_o;logic [511:0] result_ctilde_o;logic [6:0] result_bytes_o;logic [5:0] result_region_o;
  logic clear_valid_i=0,clear_ready_o;
  request_t service_o,consumer='0,wire_request;response_t service_i,actual;
  sign_challenge_prepare dut(.take_valid_i(1'b0),.take_ready_o(),.*);
  sign_attempt_setup setup(.clk(clk),.rst(rst),.request_i(wire_request),.response_o(actual));
  int case_no=-1,p,jid,nonce,inject,abort_phase,sklen,count,fd,cycles=0;
  int commands=0,completed=0,errors=0,aborts=0,rawbeats=0,packinputs=0,packoutputs=0,writes=0,reads=0;
  int accepted_pack=0,accepted_raw=0;int stalls[7];logic [63:0] blockers=0;
  bit monitor=0,reading=0,force_fault=0,abort_hit=0,test_passed=0;
  wire gr=cycles%7>2,gi=cycles%11>3,go=cycles%13>4,gs=cycles%17>5;
  wire allow_pack=go && abort_phase!=2;wire allow_raw=go && !(abort_phase==3 && accepted_raw>=1);
  always_comb begin
    context_valid_i=setup.result_valid_o;context_param_i=setup.context_param_i;context_id_i=setup.done_id_o;
    context_regions_i=setup.result_regions_o;context_high_i=setup.result_high_o;context_mu_i=setup.mu;
    if(inject==12)context_high_i[1]=context_high_i[0];
    wire_request=(busy_o || command_valid_i)?service_o:consumer;service_i=actual;
    if(busy_o || command_valid_i)begin
      wire_request.pack.command_valid=service_o.pack.command_valid && gr;service_i.pack.command_ready=actual.pack.command_ready && gr;
      wire_request.pack.input_valid=service_o.pack.input_valid && gi;service_i.pack.input_ready=actual.pack.input_ready && gi;
      wire_request.pack.output_ready=service_o.pack.output_ready && allow_pack;service_i.pack.output_valid=actual.pack.output_valid && allow_pack;
      wire_request.pack.done_ready=service_o.pack.done_ready && gs;service_i.pack.done_valid=actual.pack.done_valid && gs;
      wire_request.raw_valid=service_o.raw_valid && gr;service_i.raw_ready=actual.raw_ready && gr;
      wire_request.raw_input_valid=service_o.raw_input_valid && gi;service_i.raw_input_ready=actual.raw_input_ready && gi;
      wire_request.raw_output_ready=service_o.raw_output_ready && allow_raw;service_i.raw_output_valid=actual.raw_output_valid && allow_raw;
      wire_request.raw_done_ready=service_o.raw_done_ready && gs;service_i.raw_done_valid=actual.raw_done_valid && gs;
      wire_request.job_valid=service_o.job_valid && gr;service_i.job_ready=actual.job_ready && gr;
      wire_request.input_valid=service_o.input_valid && gi;service_i.input_ready=actual.input_ready && gi;
      wire_request.status_ready=service_o.status_ready && gs;service_i.status_valid=actual.status_valid && gs;
      if(reading)wire_request=consumer;
      if(inject==1 && dut.poly_r==0 && dut.word_r==0)service_i.response_id=actual.response_id^16'd1;
      if(inject==2 && dut.poly_r==dut.rows_r-1 && dut.word_r==7)service_i.response_mode=3;
      if(inject==3 && dut.poly_r==1 && dut.word_r==5)service_i.response_data[0+:23]=p==0?23'd44:23'd16;
      if(inject==4 && dut.poly_r==0 && dut.sent_r==37)wire_request.pack.input_index=service_o.pack.input_index^8'd1;
      if(inject==5 && dut.poly_r==1 && dut.pack_words_r==3)service_i.pack.output_id=actual.pack.output_id^16'd1;
      if(inject==6 && dut.poly_r==dut.rows_r-1)service_i.pack.done_id=actual.pack.done_id^16'd1;
      if(inject==7)service_i.raw_output_id=actual.raw_output_id^16'd1;
      if(inject==8)service_i.raw_output_bytes=15;
      if(inject==9)service_i.raw_done_id=actual.raw_done_id^16'd1;
      if(inject==10)service_i.status_id=actual.status_id^16'd1;
      if(inject==11)service_i.status_code=7;
      if(force_fault)service_i.fault=1;
    end
  end
  bit held=0,rheld=0,ph=0;logic [21:0] old_done;logic [524:0] old_result;logic [91:0] old_pack;
  int watched=-1,elapsed=0;
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held=0;rheld=0;ph=0;end
    else if(monitor)begin
      if(actual.fault)$fatal(1,"Challenge unexpected physical fault");
      if(watched!=case_no)begin watched=case_no;elapsed=0;end elapsed++;
      if(elapsed==60000)$fatal(1,"Challenge watchdog case%0d state%0d code%0d pack%0d sent%0d fmt%0d rawret%0d",case_no,dut.state,done_code_o,dut.pack_active_r,dut.sent_r,dut.formatter.state,dut.raw_retired_r);
      if(held && (!done_valid_o || {done_code_o,done_detail_o,done_id_o}!==old_done))$fatal(1,"Challenge held done changed");
      held=done_valid_o && !done_ready_i;old_done={done_code_o,done_detail_o,done_id_o};
      if(rheld && !(clear_valid_i && clear_ready_o) && (!result_valid_o || {result_ctilde_o,result_bytes_o,result_region_o}!==old_result))$fatal(1,"Challenge retained result changed");
      rheld=result_valid_o && !(clear_valid_i && clear_ready_o);old_result={result_ctilde_o,result_bytes_o,result_region_o};
      if(!result_valid_o && (result_ctilde_o || result_bytes_o || result_region_o))$fatal(1,"Tentative challenge exposed");
      if(ph && (!actual.pack.output_valid || {actual.pack.output_id,actual.pack.output_index,actual.pack.output_bytes,actual.pack.output_last,actual.pack.output_data}!==old_pack))$fatal(1,"Stalled physical pack output changed");
      ph=actual.pack.output_valid && !wire_request.pack.output_ready;old_pack={actual.pack.output_id,actual.pack.output_index,actual.pack.output_bytes,actual.pack.output_last,actual.pack.output_data};
      if(busy_o && command_ready_o)$fatal(1,"Challenge owner replaced");
      if(done_valid_o && abort_phase!=0 && abort_phase!=5)$fatal(1,"Challenge completed before reset checkpoint case%0d code%0d",case_no,done_code_o);
      if(service_o.pack.command_valid && !service_i.pack.command_ready)stalls[0]++;
      if(service_o.pack.input_valid && !service_i.pack.input_ready)stalls[1]++;
      if(actual.pack.output_valid && !wire_request.pack.output_ready)stalls[2]++;
      if(service_o.raw_input_valid && !service_i.raw_input_ready)stalls[3]++;
      if(actual.raw_output_valid && !wire_request.raw_output_ready)stalls[4]++;
      if(actual.pack.done_valid && !wire_request.pack.done_ready || actual.raw_done_valid && !wire_request.raw_done_ready || actual.status_valid && !wire_request.status_ready)stalls[5]++;
      if(clear_valid_i && !clear_ready_o)stalls[6]++;
      if(command_valid_i && command_ready_o)begin $fdisplay(fd,"C %0d %0d %0d %0d %0d %0d",case_no,p,jid,nonce,inject,abort_phase);commands++;end
      if(wire_request.pack.command_valid && actual.pack.command_ready)$fdisplay(fd,"B %0d %0d %0d %0d %0d",case_no,dut.poly_r,wire_request.pack.command_op,wire_request.pack.command_param,wire_request.pack.command_id);
      if(actual.response_valid && wire_request.response_ready && !reading)$fdisplay(fd,"L %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,dut.poly_r,service_i.response_word,{service_i.response_bank,service_i.response_region},service_i.response_id,service_i.response_mode,service_i.response_param,service_i.response_ntt_domain,service_i.response_data);
      // Old output is consumed before a same-edge input failure clears bits.
      if(actual.pack.output_valid && wire_request.pack.output_ready)begin
        $fdisplay(fd,"O %0d %0d %0d %0d %0d %0d %016h",case_no,dut.poly_r,service_i.pack.output_id,service_i.pack.output_index,service_i.pack.output_bytes,service_i.pack.output_last,service_i.pack.output_data);packoutputs++;
      end
      if(wire_request.pack.input_valid && actual.pack.input_ready)begin
        $fdisplay(fd,"I %0d %0d %0d %0d %06h %0d",case_no,dut.poly_r,wire_request.pack.input_index,wire_request.pack.input_last,wire_request.pack.input_data,dut.state);packinputs++;accepted_pack++;
        if(abort_phase==1 && accepted_pack==17)abort_hit=1;
      end
      if(actual.pack.done_valid && wire_request.pack.done_ready)$fdisplay(fd,"T %0d %0d %0d %0d",case_no,dut.poly_r,service_i.pack.done_id,service_i.pack.done_code);
      if(dut.fmt_payload && dut.fmt_payload_ready)$fdisplay(fd,"P %0d %0d %0d %0d %016h",case_no,dut.fmt_payload_index,dut.fmt_payload_bytes,dut.fmt_payload_last,dut.fmt_payload_data);
      if(wire_request.raw_valid && actual.raw_ready)$fdisplay(fd,"H %0d %0d %0d %0d %0d",case_no,wire_request.raw_id,wire_request.raw_message_len,wire_request.raw_output_len,actual.raw_core);
      if(wire_request.raw_input_valid && actual.raw_input_ready)$fdisplay(fd,"W %0d %0d %0d %016h",case_no,dut.fmt_index,dut.fmt_bytes,wire_request.raw_input_data);
      if(actual.raw_output_valid && wire_request.raw_output_ready)begin
        $fdisplay(fd,"R %0d %0d %0d %0d %032h",case_no,service_i.raw_output_id,service_i.raw_output_core,service_i.raw_output_bytes,service_i.raw_output_data);rawbeats++;accepted_raw++;
      end
      if(actual.raw_done_valid && wire_request.raw_done_ready)$fdisplay(fd,"Q %0d %0d %0d",case_no,service_i.raw_done_id,service_i.raw_done_core);
      if(wire_request.job_valid && actual.job_ready)$fdisplay(fd,"J %0d %0d %0d %0d %0d %0d",case_no,wire_request.job_id,wire_request.job_param,wire_request.message_len,{wire_request.job_bank,wire_request.job_region},actual.job_core);
      if(wire_request.input_valid && actual.input_ready)$fdisplay(fd,"A %0d %0d %016h",case_no,dut.sample_word_r,wire_request.input_data);
      if(actual.status_valid && wire_request.status_ready)$fdisplay(fd,"S %0d %0d %0d %0d",case_no,service_i.status_id,service_i.status_core,service_i.status_code);
      if(setup.services.datapath.subsystem.store.write_fire)begin
        $fdisplay(fd,"X %0d %0d %0d %0d %06h",case_no,dut.state,setup.services.datapath.subsystem.store.write_region,setup.services.datapath.subsystem.store.write_index_i,setup.services.datapath.subsystem.store.write_data_i);writes++;
        if((abort_phase==4 || abort_phase==6) && setup.services.datapath.subsystem.store.write_index_i==31)abort_hit=1;
      end
      if(wire_request.release_valid && actual.release_ready)$fdisplay(fd,"F %0d %0d",case_no,{wire_request.release_bank,wire_request.release_region});
    end
  end
  task automatic reset_all();
    rst=1;setup.reset_controls();command_valid_i=0;done_ready_i=0;clear_valid_i=0;consumer='0;monitor=0;reading=0;force_fault=0;blockers=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || actual.reserved || result_valid_o || fault_o)$fatal(1,"Challenge reset state");
  endtask
  task automatic read_region(input int kind,input int ordinal,input int region);
    reading=1;
    for(int w=0;w<64;w++)begin
      consumer='0;consumer.read_valid=1;{consumer.read_bank,consumer.read_region}=6'(region);consumer.read_word=6'(w);
      do @(posedge clk);while(!actual.read_ready);@(negedge clk);#1;consumer.read_valid=0;
      while(!actual.response_valid)begin @(negedge clk);#1;end if(actual.response_error)$fatal(1,"Challenge result/source read error");
      $fdisplay(fd,"V %0d %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,kind,ordinal,region,w,actual.response_id,actual.response_mode,actual.response_param,actual.response_ntt_domain,actual.response_data);reads++;
      repeat(w%3)@(negedge clk);#1;consumer.response_ready=1;@(posedge clk);@(negedge clk);#1;consumer='0;
    end reading=0;
  endtask
  initial begin
    int f;string directory,token,skhex,bodyhex;logic [255:0] random_value;bit aborted;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_sign_challenge_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d",token,count)!=2)$fatal(1,"Prepare challenge fixtures");
    fd=$fopen({directory,"/stage5_sign_challenge_outputs.txt"},"w");$fdisplay(fd,"G %s",token);setup.fd=fd;reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %h %d %s %s",case_no,p,jid,nonce,inject,abort_phase,random_value,sklen,skhex,bodyhex)!=10 || case_no!=c)$fatal(1,"Challenge fixture row");
      monitor=0;if(setup.context_valid_i && setup.context_param_i!=p)reset_all();
      setup.case_no=case_no;setup.prepare_all(p,nonce,skhex,bodyhex,random_value);
      blockers=0;if(inject==13)for(int r=0;r<64;r++)if(!actual.reserved[r])begin setup.seed_region(r);blockers[r]=1;end
      $fdisplay(fd,"N %0d %016h",case_no,actual.reserved);accepted_pack=0;accepted_raw=0;abort_hit=0;
      for(int j=0;j<7;j++)stalls[j]=0;monitor=1;command_id_i=16'(jid);command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;command_id_i='1;
      aborted=0;
      if(abort_phase!=0)begin
        if(abort_phase==2)begin while(!actual.pack.output_valid)begin @(negedge clk);#1;end repeat(6)@(negedge clk);#1;end
        else if(abort_phase==3)begin while(!(accepted_raw==1 && actual.raw_output_valid))begin @(negedge clk);#1;end repeat(6)@(negedge clk);#1;end
        else if(abort_phase==5)while(!done_valid_o)begin @(negedge clk);#1;end
        else while(!abort_hit)begin @(negedge clk);#1;end
        if(abort_phase==6)begin force_fault=1;repeat(3)@(negedge clk);#1;if(!fault_o || done_valid_o || result_valid_o)$fatal(1,"Challenge injected fault not halted");end
        $fdisplay(fd,"Z %0d %0d %0d %0d %0d",case_no,abort_phase,dut.state,accepted_pack,accepted_raw);aborts++;aborted=1;reset_all();
      end
      if(!aborted)begin
        while(!done_valid_o)begin @(negedge clk);#1;end
        if(done_code_o==0)$fdisplay(fd,"D %0d %0d %0d %0128h",case_no,result_region_o,result_bytes_o,result_ctilde_o);
        repeat(7)@(negedge clk);#1;$fdisplay(fd,"E %0d %0d %0d %0d",case_no,done_id_o,done_code_o,done_detail_o);completed++;if(done_code_o)errors++;
        done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
        if(done_code_o==0)begin
          repeat(7)@(negedge clk);#1;read_region(0,0,result_region_o);
          // Pending consumer response must block clear;then drain it.
          reading=1;consumer='0;consumer.read_valid=1;{consumer.read_bank,consumer.read_region}=result_region_o;
          do @(posedge clk);while(!actual.read_ready);@(negedge clk);#1;consumer.read_valid=0;
          while(!actual.response_valid)begin @(negedge clk);#1;end clear_valid_i=1;
          repeat(6)begin @(negedge clk);#1;if(clear_ready_o)$fatal(1,"Challenge clear bypassed pending consumer");end
          $fdisplay(fd,"BARRIER %0d %023h",case_no,actual.response_data);consumer.response_ready=1;@(posedge clk);@(negedge clk);#1;consumer='0;reading=0;
          do @(posedge clk);while(!clear_ready_o);@(negedge clk);#1;clear_valid_i=0;
        end
        while(busy_o)begin @(negedge clk);#1;end
        for(int j=0;j<(p==0?12:(p==1?17:23));j++)read_region(1,j,setup.kh[j]);
        for(int j=0;j<(p==0?4:(p==1?5:7));j++)begin read_region(2,j,setup.mask_handles_i[j]);read_region(3,j,setup.result_yhat_o[j]);end
        for(int r=0;r<(p==0?4:(p==1?6:8));r++)begin read_region(4,r,setup.result_low_o[r]);read_region(5,r,setup.result_high_o[r]);end
        read_region(6,0,50);
        for(int r=0;r<64;r++)if(blockers[r])begin read_region(7,r,r);consumer='0;consumer.release_valid=1;{consumer.release_bank,consumer.release_region}=6'(r);
          do @(posedge clk);while(!actual.release_ready);@(negedge clk);#1;consumer='0;end
        if(actual.reserved!==(setup.context_regions_i|setup.mask_regions_i|setup.result_regions_o|(64'd1<<50)))$fatal(1,"Challenge leaked/clobbered storage");
        $fdisplay(fd,"ST %0d %0d %0d %0d %0d %0d %0d %0d",case_no,stalls[0],stalls[1],stalls[2],stalls[3],stalls[4],stalls[5],stalls[6]);
      end monitor=0;
    end
    $fdisplay(fd,"END %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",commands,completed,errors,aborts,packinputs,packoutputs,rawbeats,writes,reads,setup.keys,setup.masks);
    $fclose(f);$fclose(fd);$display("STAGE5N4G_SIGN_CHALLENGE_CAPTURE_PASS:%0d commands,%0d completions,%0d errors,%0d reset/fault aborts",commands,completed,errors,aborts);test_passed=1;$finish;
  end
  initial begin #(64'd150000000000);$fatal(1,"Challenge global watchdog case%0d",case_no);end
endmodule
