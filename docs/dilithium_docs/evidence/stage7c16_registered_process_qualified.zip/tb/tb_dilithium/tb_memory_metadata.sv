`timescale 1ns/1ps
module tb_memory_metadata;
  logic  clk=0;
  logic  rst=1;
  logic  alloc_valid_i;
  logic  alloc_core_i;
  logic [1:0] alloc_bank_i;
  logic [1:0] alloc_mode_i;
  logic [1:0] alloc_param_i;
  logic [3:0] alloc_region_i;
  logic [15:0] alloc_id_i;
  logic  alloc_compute_i;
  logic  alloc_ntt_domain_i;
  logic  alloc_rewrite_i;
  logic  alloc_ready_o;
  logic  write_valid_i;
  logic  write_core_i;
  logic  write_last_i;
  logic [15:0] write_id_i;
  logic [7:0] write_index_i;
  logic [22:0] write_data_i;
  logic  write_ready_o;
  logic  finish_valid_i;
  logic  finish_core_i;
  logic [15:0] finish_id_i;
  logic [2:0] finish_code_i;
  logic  finish_ready_o;
  logic  read_valid_i;
  logic [1:0] read_bank_i;
  logic [3:0] read_region_i;
  logic [5:0] read_word_i;
  logic  read_ready_o;
  logic  response_valid_o;
  logic  response_error_o;
  logic [1:0] response_bank_o;
  logic [1:0] response_mode_o;
  logic [1:0] response_param_o;
  logic [3:0] response_region_o;
  logic [5:0] response_word_o;
  logic [91:0] response_data_o;
  logic [15:0] response_id_o;
  logic  response_ntt_domain_o;
  logic  response_small_o;
  logic  response_ready_i;
  logic  release_valid_i;
  logic [1:0] release_bank_i;
  logic [3:0] release_region_i;
  logic  release_ready_o;
  logic [63:0] reserved_o;
  logic [63:0] complete_o;
  logic  fault_o;
  logic [15:0] context_id[2];int transactions=0;
  always #5 clk=~clk;
  memory dut (
    .clk(clk),
    .rst(rst),
    .alloc_valid_i(alloc_valid_i),
    .alloc_core_i(alloc_core_i),
    .alloc_bank_i(alloc_bank_i),
    .alloc_mode_i(alloc_mode_i),
    .alloc_param_i(alloc_param_i),
    .alloc_region_i(alloc_region_i),
    .alloc_id_i(alloc_id_i),
    .alloc_compute_i(alloc_compute_i),
    .alloc_ntt_domain_i(alloc_ntt_domain_i),
    .alloc_rewrite_i(alloc_rewrite_i),
    .alloc_ready_o(alloc_ready_o),
    .write_valid_i(write_valid_i),
    .write_core_i(write_core_i),
    .write_last_i(write_last_i),
    .write_id_i(write_id_i),
    .write_index_i(write_index_i),
    .write_data_i(write_data_i),
    .write_ready_o(write_ready_o),
    .finish_valid_i(finish_valid_i),
    .finish_core_i(finish_core_i),
    .finish_id_i(finish_id_i),
    .finish_code_i(finish_code_i),
    .finish_ready_o(finish_ready_o),
    .read_valid_i(read_valid_i),
    .read_bank_i(read_bank_i),
    .read_region_i(read_region_i),
    .read_word_i(read_word_i),
    .read_ready_o(read_ready_o),
    .response_valid_o(response_valid_o),
    .response_error_o(response_error_o),
    .response_bank_o(response_bank_o),
    .response_mode_o(response_mode_o),
    .response_param_o(response_param_o),
    .response_region_o(response_region_o),
    .response_word_o(response_word_o),
    .response_data_o(response_data_o),
    .response_id_o(response_id_o),
    .response_ntt_domain_o(response_ntt_domain_o),
    .response_small_o(response_small_o),
    .response_ready_i(response_ready_i),
    .release_valid_i(release_valid_i),
    .release_bank_i(release_bank_i),
    .release_region_i(release_region_i),
    .release_ready_o(release_ready_o),
    .reserved_o(reserved_o),
    .complete_o(complete_o),
    .fault_o(fault_o)
  );
  memory_metadata_equivalence comparison (
    .clk(clk),
    .rst(rst),
    .alloc_valid_i(alloc_valid_i),
    .alloc_core_i(alloc_core_i),
    .alloc_bank_i(alloc_bank_i),
    .alloc_mode_i(alloc_mode_i),
    .alloc_param_i(alloc_param_i),
    .alloc_region_i(alloc_region_i),
    .alloc_id_i(alloc_id_i),
    .alloc_compute_i(alloc_compute_i),
    .alloc_ntt_domain_i(alloc_ntt_domain_i),
    .alloc_rewrite_i(alloc_rewrite_i),
    .dut_alloc_ready_o(alloc_ready_o),
    .write_valid_i(write_valid_i),
    .write_core_i(write_core_i),
    .write_last_i(write_last_i),
    .write_id_i(write_id_i),
    .write_index_i(write_index_i),
    .write_data_i(write_data_i),
    .dut_write_ready_o(write_ready_o),
    .finish_valid_i(finish_valid_i),
    .finish_core_i(finish_core_i),
    .finish_id_i(finish_id_i),
    .finish_code_i(finish_code_i),
    .dut_finish_ready_o(finish_ready_o),
    .read_valid_i(read_valid_i),
    .read_bank_i(read_bank_i),
    .read_region_i(read_region_i),
    .read_word_i(read_word_i),
    .dut_read_ready_o(read_ready_o),
    .dut_response_valid_o(response_valid_o),
    .dut_response_error_o(response_error_o),
    .dut_response_bank_o(response_bank_o),
    .dut_response_mode_o(response_mode_o),
    .dut_response_param_o(response_param_o),
    .dut_response_region_o(response_region_o),
    .dut_response_word_o(response_word_o),
    .dut_response_data_o(response_data_o),
    .dut_response_id_o(response_id_o),
    .dut_response_ntt_domain_o(response_ntt_domain_o),
    .dut_response_small_o(response_small_o),
    .response_ready_i(response_ready_i),
    .release_valid_i(release_valid_i),
    .release_bank_i(release_bank_i),
    .release_region_i(release_region_i),
    .dut_release_ready_o(release_ready_o),
    .dut_reserved_o(reserved_o),
    .dut_complete_o(complete_o),
    .dut_fault_o(fault_o)
  );
  task automatic reset_all();
    @(negedge clk);rst=1;alloc_valid_i=0;write_valid_i=0;finish_valid_i=0;read_valid_i=0;release_valid_i=0;
    repeat(3)@(negedge clk);rst=0;response_ready_i=1;
  endtask
  task automatic allocate(input int core,region,input logic[15:0] id,input bit rewrite=0);
    @(negedge clk);alloc_core_i=1'(core);alloc_bank_i=2'(region>>4);alloc_region_i=4'(region);
    alloc_id_i=id;alloc_mode_i=rewrite?3:2'(region%4);alloc_param_i=rewrite?2:2'(region%3);
    alloc_compute_i=rewrite;alloc_ntt_domain_i=0;alloc_rewrite_i=rewrite;alloc_valid_i=1;
    do @(posedge clk);while(!alloc_ready_o);
    @(negedge clk);alloc_valid_i=0;context_id[core]=id;
  endtask
  task automatic put(input int core,index,value);
    @(negedge clk);write_core_i=1'(core);write_id_i=context_id[core];write_index_i=8'(index);
    write_data_i=23'(value);write_last_i=index==255;write_valid_i=1;
    do @(posedge clk);while(!write_ready_o);
    @(negedge clk);write_valid_i=0;
  endtask
  task automatic finish(input int core,input int status=0);
    @(negedge clk);finish_core_i=1'(core);finish_id_i=context_id[core];finish_code_i=3'(status);finish_valid_i=1;
    do @(posedge clk);while(!finish_ready_o);
    @(negedge clk);finish_valid_i=0;
  endtask
  task automatic receive(input bit expected_error,input logic[15:0] id);
    while(!response_valid_o)@(negedge clk);
    if(response_error_o!=expected_error || response_id_o!==(expected_error?16'd0:id))
      $fatal(1,"Metadata read mismatch region%0d word%0d",response_region_o,response_word_o);
    repeat(3)@(negedge clk);
    response_ready_i=1;@(posedge clk);@(negedge clk);transactions++;
  endtask
  task automatic read_word(input int region,word_index,input bit expected_error,input logic[15:0] id);
    @(negedge clk);read_bank_i=2'(region>>4);read_region_i=4'(region);read_word_i=6'(word_index);
    response_ready_i=0;read_valid_i=1;
    do @(posedge clk);while(!read_ready_o);
    @(negedge clk);read_valid_i=0;receive(expected_error,id);
  endtask
  task automatic release_slot(input int region);
    @(negedge clk);release_bank_i=2'(region>>4);release_region_i=4'(region);release_valid_i=1;
    do @(posedge clk);while(!release_ready_o);
    @(negedge clk);release_valid_i=0;
  endtask
  function automatic int coefficient(input int region,index);
    int x=index%9;
    return region%4==1?(x<=4?x:8380417-(9-x)):region*500+index*17;
  endfunction
  initial begin
    alloc_valid_i=0;
    alloc_core_i=0;
    alloc_bank_i=0;
    alloc_mode_i=0;
    alloc_param_i=0;
    alloc_region_i=0;
    alloc_id_i=0;
    alloc_compute_i=0;
    alloc_ntt_domain_i=0;
    alloc_rewrite_i=0;
    write_valid_i=0;
    write_core_i=0;
    write_last_i=0;
    write_id_i=0;
    write_index_i=0;
    write_data_i=0;
    finish_valid_i=0;
    finish_core_i=0;
    finish_id_i=0;
    finish_code_i=0;
    read_valid_i=0;
    read_bank_i=0;
    read_region_i=0;
    read_word_i=0;
    response_ready_i=0;
    release_valid_i=0;
    release_bank_i=0;
    release_region_i=0;
    reset_all();
    // Uninitialized tag RAM must remain invisible after reset.
    for(int r=0;r<64;r++)read_word(r,0,1,0);
    for(int r=0;r<64;r+=2)begin
      allocate(0,r,16'h9000^16'(r*53));allocate(1,r+1,16'h9000^16'((r+1)*53));
      for(int j=0;j<256;j++)begin put(0,j,coefficient(r,j));put(1,j,coefficient(r+1,j));end
      finish(0);finish(1);
    end
    if(complete_o!=='1 || reserved_o!=='1)$fatal(1,"64-slot fill incomplete");
    for(int r=0;r<64;r++)for(int w=0;w<64;w++)read_word(r,w,0,16'h9000^16'(r*53));
    // Simultaneous COMPLETE read and rewrite allocation must report OLD ID.
    @(negedge clk);alloc_core_i=0;alloc_bank_i=0;alloc_region_i=0;alloc_id_i=16'habcd;
    alloc_mode_i=3;alloc_param_i=2;alloc_compute_i=1;alloc_ntt_domain_i=0;alloc_rewrite_i=1;
    read_bank_i=0;read_region_i=0;read_word_i=0;response_ready_i=0;alloc_valid_i=1;read_valid_i=1;
    @(posedge clk);if(!alloc_ready_o || !read_ready_o)$fatal(1,"Rewrite/read precondition");
    @(negedge clk);alloc_valid_i=0;read_valid_i=0;context_id[0]=16'habcd;receive(0,16'h9000);
    for(int w=0;w<64;w++)begin
      read_word(0,w,0,16'habcd);
      for(int lane=0;lane<4;lane++)put(0,4*w+lane,800000+4*w+lane);
      read_word(0,w,1,0);
    end
    finish(0);
    for(int w=0;w<64;w++)read_word(0,w,0,16'habcd);
    release_slot(1);allocate(1,1,16'h5432);
    for(int j=0;j<7;j++)put(1,j,j);
    finish(1,1);read_word(1,0,1,0);
    // Invalid owner and premature successful finish keep the sticky-fault contract.
    for(int trial=0;trial<2;trial++)begin
      reset_all();allocate(0,0,16'h1234);
      @(negedge clk);
      if(trial==0)begin write_valid_i=1;write_core_i=0;write_id_i=16'h5678;end
      else begin finish_valid_i=1;finish_core_i=0;finish_id_i=16'h1234;finish_code_i=0;end
      @(posedge clk);@(negedge clk);#1;if(!fault_o)$fatal(1,"Expected protocol fault absent");
    end
    reset_all();for(int r=0;r<64;r++)read_word(r,0,1,0);
    $display("MEMORY_METADATA_UNIT_PASS:64 slots,two interleaved writers,rewrite/read collision,watermark,cancel,reset,faults;%0d reads",transactions);
    $finish;
  end
  always @(posedge clk)if(!rst && dut.metadata_read && dut.metadata_write && dut.read_region==dut.finish_region)
    $fatal(1,"Metadata RAM same-address collision");
  initial begin #10000000;$fatal(1,"Metadata unit watchdog");end
endmodule

