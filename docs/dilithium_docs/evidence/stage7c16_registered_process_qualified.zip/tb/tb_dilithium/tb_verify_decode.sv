`timescale 1ps/1ps
module tb_verify_decode;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,command_kind_i=0;logic [1:0] command_param_i=0;
  logic [15:0] command_id_i=0,command_length_i=0;
  logic input_valid_i=0,input_ready_o,input_last_i=0;logic [63:0] input_data_i=0;
  logic [3:0] input_bytes_i=8;logic [15:0] input_index_i=0;
  logic header_valid_o,header_ready_i=0;logic [511:0] header_data_o;logic [6:0] header_bytes_o;logic [15:0] header_id_o;
  logic output_valid_o,output_ready_i=0;logic [22:0] output_data_o;logic [1:0] output_section_o;
  logic [2:0] output_poly_o;logic [7:0] output_index_o;logic output_last_poly_o,output_last_frame_o;logic [15:0] output_id_o;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o;logic [15:0] done_id_o;
  verify_decode dut(.*);
  verify_decode_equivalence comparison (
    .clk(clk),
    .rst(rst),
    .command_valid_i(command_valid_i),
    .dut_command_ready_o(command_ready_o),
    .dut_busy_o(busy_o),
    .command_kind_i(command_kind_i),
    .command_param_i(command_param_i),
    .command_id_i(command_id_i),
    .command_length_i(command_length_i),
    .input_valid_i(input_valid_i),
    .dut_input_ready_o(input_ready_o),
    .input_data_i(input_data_i),
    .input_bytes_i(input_bytes_i),
    .input_index_i(input_index_i),
    .input_last_i(input_last_i),
    .dut_header_valid_o(header_valid_o),
    .header_ready_i(header_ready_i),
    .dut_header_data_o(header_data_o),
    .dut_header_bytes_o(header_bytes_o),
    .dut_header_id_o(header_id_o),
    .dut_output_valid_o(output_valid_o),
    .output_ready_i(output_ready_i),
    .dut_output_data_o(output_data_o),
    .dut_output_section_o(output_section_o),
    .dut_output_poly_o(output_poly_o),
    .dut_output_index_o(output_index_o),
    .dut_output_last_poly_o(output_last_poly_o),
    .dut_output_last_frame_o(output_last_frame_o),
    .dut_output_id_o(output_id_o),
    .dut_done_valid_o(done_valid_o),
    .done_ready_i(done_ready_i),
    .dut_done_code_o(done_code_o),
    .dut_done_id_o(done_id_o)
  );
  int fd,count,case_no=-1,kind,p,jid,declared,length,fw,fault,abort_phase,expected_code,cycles=0,elapsed=0;
  int commands=0,completed=0,errors=0,aborted=0,words=0,values=0,header_stalls=0,output_stalls=0,input_stalls=0;
  bit monitor=0,test_passed=0,hit=0,held_i=0,held_o=0,held_h=0,held_d=0;
  logic [84:0] previous_i;logic [53:0] previous_o;logic [534:0] previous_h;logic [18:0] previous_d;
  always @(negedge clk)begin
    header_ready_i=!rst && cycles%17>6 && abort_phase!=2;
    output_ready_i=!rst && cycles%19>5;
    if(abort_phase==3 && output_section_o!=2)output_ready_i=0;
    if(abort_phase==5 && output_section_o==2)output_ready_i=0;
    if(abort_phase==6 && output_last_frame_o)output_ready_i=0;
  end
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held_i=0;held_o=0;held_h=0;held_d=0;end
    else if(monitor)begin
      elapsed++;if(elapsed>60000)$fatal(1,"Verify decode watchdog case%0d state%0d",case_no,dut.state);
      if(held_i && !done_valid_o && (!input_valid_i || previous_i!=={input_index_i,input_bytes_i,input_last_i,input_data_i}))$fatal(1,"Held host input changed");
      if(held_o && (!output_valid_o || previous_o!=={output_id_o,output_section_o,output_poly_o,output_index_o,output_data_o,output_last_poly_o,output_last_frame_o}))$fatal(1,"Held decoded coefficient changed");
      if(held_h && (!header_valid_o || previous_h!=={header_id_o,header_bytes_o,header_data_o}))$fatal(1,"Held Verify header changed");
      if(held_d && (!done_valid_o || previous_d!=={done_id_o,done_code_o}))$fatal(1,"Held Verify completion changed");
      held_i=input_valid_i && !input_ready_o;previous_i={input_index_i,input_bytes_i,input_last_i,input_data_i};
      held_o=output_valid_o && !output_ready_i;previous_o={output_id_o,output_section_o,output_poly_o,output_index_o,output_data_o,output_last_poly_o,output_last_frame_o};
      held_h=header_valid_o && !header_ready_i;previous_h={header_id_o,header_bytes_o,header_data_o};
      held_d=done_valid_o && !done_ready_i;previous_d={done_id_o,done_code_o};
      if(held_i)input_stalls++;if(held_o)output_stalls++;if(held_h)header_stalls++;
      if(command_valid_i && command_ready_o)begin $fdisplay(fd,"C %0d %0d %0d %0d %0d",case_no,command_kind_i,command_param_i,command_id_i,command_length_i);commands++;end
      if(input_valid_i && input_ready_o)begin $fdisplay(fd,"I %0d %0d %0d %0d %016h",case_no,input_index_i,input_bytes_i,input_last_i,input_data_i);words++;end
      if(header_valid_o && header_ready_i)$fdisplay(fd,"H %0d %0d %0d %0128h",case_no,header_id_o,header_bytes_o,header_data_o);
      if(output_valid_o && output_ready_i)begin
        $fdisplay(fd,"P %0d %0d %0d %0d %0d %06h %0d %0d",case_no,output_id_o,output_section_o,output_poly_o,output_index_o,output_data_o,output_last_poly_o,output_last_frame_o);values++;
      end
    end
  end
  task automatic reset_all();
    rst=1;monitor=0;input_valid_i=0;command_valid_i=0;done_ready_i=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(!command_ready_o || busy_o || output_valid_o || header_valid_o || done_valid_o || dut.hints_r || dut.bits_r || header_data_o)$fatal(1,"Verify decode reset state");
  endtask
  task automatic send_frame(input string hexdata);
    int parsed,valid;byte unsigned octet;
    for(int w=0;w<(length+7)/8;w++)begin
      if(rst || done_valid_o)return;
      if(w%11==3)begin @(negedge clk);#1;if(rst || done_valid_o)return;end
      input_data_i='1;valid=length-8*w>=8?8:length-8*w;
      for(int b=0;b<valid;b++)begin parsed=$sscanf(hexdata.substr(2*(8*w+b),2*(8*w+b)+1),"%h",octet);if(parsed!=1)$fatal(1,"Verify decode byte");input_data_i[8*b+:8]=octet;end
      input_index_i=16'(w);input_bytes_i=4'(valid);input_last_i=8*(w+1)>=length;
      if(w==fw)case(fault)
        1:input_index_i=input_index_i^16'd1024;
        2:input_bytes_i=0;
        3:input_last_i=!input_last_i;
        4:input_bytes_i=9;
        5:input_bytes_i=input_bytes_i-1'b1;
      endcase
      input_valid_i=1;do @(posedge clk);while(!input_ready_o && !done_valid_o && !rst);
      @(negedge clk);#1;input_valid_i=0;
    end
  endtask
  initial begin
    int f;string directory,token,hexdata;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_verify_decode_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d",token,count)!=2)$fatal(1,"Prepare Verify decoder vectors");
    fd=$fopen({directory,"/stage5_verify_decode_outputs.txt"},"w");$fdisplay(fd,"V %s",token);reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %d %d %d %d %s",case_no,kind,p,jid,declared,length,fw,fault,abort_phase,expected_code,hexdata)!=11 || case_no!=c)$fatal(1,"Verify decode fixture");
      elapsed=0;hit=0;header_stalls=0;output_stalls=0;input_stalls=0;monitor=1;
      command_kind_i=1'(kind);command_param_i=2'(p);command_id_i=16'(jid);command_length_i=16'(declared);command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;
      command_kind_i=!command_kind_i;command_param_i=3;command_id_i=~16'(jid);command_length_i=65535;
      fork send_frame(hexdata);join_none
      if(abort_phase)begin
        while(!hit)begin
          @(negedge clk);#1;
          case(abort_phase)
            1:hit=dut.word_r==2;
            2:hit=header_valid_o && !header_ready_i;
            3:hit=output_valid_o && !output_ready_i && output_section_o!=2;
            4:hit=dut.state==4 && dut.hint_words_r>=1;
            5:hit=output_valid_o && !output_ready_i && output_section_o==2;
            6:hit=output_valid_o && output_last_frame_o && !output_ready_i;
            7:hit=done_valid_o;
          endcase
          if(done_valid_o && abort_phase!=7)$fatal(1,"Missed Verify abort%0d",abort_phase);
        end
        if(abort_phase!=1 && abort_phase!=4)repeat(5)@(negedge clk);#1;
        $fdisplay(fd,"Z %0d %0d %0d",case_no,abort_phase,dut.state);aborted++;reset_all();wait fork;
      end else begin
        while(!done_valid_o)begin @(negedge clk);#1;end
        repeat(7)begin @(negedge clk);#1;if(command_ready_o || input_ready_o)$fatal(1,"Verify accepted during held done");end
        wait fork;if(done_id_o!=jid || done_code_o!=expected_code)$fatal(1,"Verify decode status case%0d got%0d expected%0d",case_no,done_code_o,expected_code);
        $fdisplay(fd,"D %0d %0d %0d",case_no,done_id_o,done_code_o);completed++;if(done_code_o)errors++;
        $fdisplay(fd,"T %0d %0d %0d %0d",case_no,header_stalls,output_stalls,input_stalls);
        done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;monitor=0;
      end
    end
    $fdisplay(fd,"END %0d %0d %0d %0d %0d %0d",commands,completed,errors,aborted,words,values);
    $fclose(f);$fclose(fd);$display("STAGE5V1_VERIFY_DECODE_CAPTURE_PASS:%0d commands/%0d values",commands,values);test_passed=1;$finish;
  end
  initial begin #(64'd100000000000);$fatal(1,"Verify decode global watchdog");end
endmodule
