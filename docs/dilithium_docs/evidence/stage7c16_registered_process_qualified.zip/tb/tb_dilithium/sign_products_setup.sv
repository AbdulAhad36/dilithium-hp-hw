`timescale 1ps/1ps
// Real upstream clients and ONE physical services tree for response tests.
module sign_products_setup(input logic clk,rst,
  input wire dilithium_service_pkg::request_t request_i,
  output dilithium_service_pkg::response_t response_o,
  input logic mask_take_valid_i,vector_take_valid_i,
  output logic mask_take_ready_o,vector_take_ready_o);
  import dilithium_service_pkg::*;
  request_t routed,crequest,trequest;response_t actual;
  sign_attempt_setup setup(.clk(clk),.rst(rst),.request_i(routed),.response_o(actual));
  logic cv=0,cr,cbusy,cfault,cdone,cdr=0,cclear=0,ccr,cvalid,ctr,ctake;
  logic [2:0] ccode,cdetail;logic [15:0] cid;logic [511:0] ctilde;logic [6:0] cbytes;logic [5:0] cregion;
  logic tv=0,tr,tbusy,tfault,tdone,tdr=0,tclear=0,tcr,ctx_valid,t_mat_v,t_mat_r,t_c_v,t_c_r;
  logic [2:0] tcode,tdetail;logic [15:0] tid,ctx_matrix_id;
  logic [63:0] ctx_regions;logic [7:0][5:0] ctx_low,ctx_high;logic [5:0] ctx_chat;
  logic [511:0] ctx_ctilde;logic [6:0] ctx_bytes;
  bit preparing_challenge=0,preparing_transform=0;
  sign_challenge_prepare challenge(.clk(clk),.rst(rst),.command_valid_i(cv),.command_ready_o(cr),.busy_o(cbusy),.fault_o(cfault),
    .command_id_i(16'(20000+setup.context_param_i)),.context_valid_i(setup.result_valid_o),.context_param_i(setup.context_param_i),
    .context_id_i(setup.done_id_o),.context_regions_i(setup.result_regions_o),.context_high_i(setup.result_high_o),.context_mu_i(setup.mu),
    .done_valid_o(cdone),.done_ready_i(cdr),.done_code_o(ccode),.done_detail_o(cdetail),.done_id_o(cid),
    .result_valid_o(cvalid),.result_ctilde_o(ctilde),.result_bytes_o(cbytes),.result_region_o(cregion),
    .clear_valid_i(cclear),.clear_ready_o(ccr),.take_valid_i(ctake),.take_ready_o(ctr),.service_o(crequest),.service_i(actual));
  sign_challenge_transform transform(.clk(clk),.rst(rst),.command_valid_i(tv),.command_ready_o(tr),.busy_o(tbusy),.fault_o(tfault),
    .command_id_i(16'(25000+setup.context_param_i)),.key_valid_i(setup.context_valid_i),.mask_valid_i(setup.mask_valid_i),.param_i(setup.context_param_i),
    .key_id_i(setup.context_id_i),.mask_id_i(setup.mask_id_i),.key_regions_i(setup.context_regions_i),.mask_regions_i(setup.mask_regions_i),
    .matrix_valid_i(setup.result_valid_o),.matrix_id_i(setup.done_id_o),.matrix_regions_i(setup.result_regions_o),.matrix_yhat_i(setup.result_yhat_o),
    .matrix_low_i(setup.result_low_o),.matrix_high_i(setup.result_high_o),.challenge_valid_i(cvalid),.challenge_id_i(cid),.challenge_region_i(cregion),
    .challenge_bytes_i(cbytes),.challenge_ctilde_i(ctilde),.matrix_take_valid_o(t_mat_v),.challenge_take_valid_o(t_c_v),
    .matrix_take_ready_i(t_mat_r),.challenge_take_ready_i(t_c_r),.done_valid_o(tdone),.done_ready_i(tdr),.done_code_o(tcode),.done_detail_o(tdetail),.done_id_o(tid),
    .result_valid_o(ctx_valid),.result_regions_o(ctx_regions),.result_low_o(ctx_low),.result_high_o(ctx_high),.result_matrix_id_o(ctx_matrix_id),
    .result_chat_o(ctx_chat),.result_ctilde_o(ctx_ctilde),.result_bytes_o(ctx_bytes),.clear_valid_i(tclear),.clear_ready_o(tcr),
    .take_valid_i(vector_take_valid_i),.take_ready_o(vector_take_ready_o),.service_o(trequest),.service_i(actual));
  always_comb begin
    routed=preparing_challenge?crequest:(preparing_transform?trequest:request_i);response_o=actual;
    setup.matrix_take_valid=t_mat_v;t_mat_r=setup.matrix_take_ready;ctake=t_c_v;t_c_r=ctr;
    setup.mask_take_valid=mask_take_valid_i;mask_take_ready_o=setup.mask_take_ready;
  end
  task automatic reset_controls();
    setup.reset_controls();cv=0;cdr=0;cclear=0;tv=0;tdr=0;tclear=0;preparing_challenge=0;preparing_transform=0;
  endtask
  task automatic prepare_all(input int case_no,level,nonce,input string skhex,bodyhex,input logic [255:0] rnd);
    bit reused;setup.case_no=case_no;
    if(ctx_valid && setup.mask_nonce!=nonce)begin
      preparing_transform=1;tclear=1;do @(posedge clk);while(!tcr);@(negedge clk);#1;tclear=0;
      while(tbusy)begin @(negedge clk);#1;end preparing_transform=0;
    end
    reused=ctx_valid;
    if(!ctx_valid)begin
      setup.prepare_all(level,nonce,skhex,bodyhex,rnd);preparing_challenge=1;cv=1;
      do @(posedge clk);while(!cr);@(negedge clk);#1;cv=0;
      while(!cdone)begin @(negedge clk);#1;end if(ccode || !cvalid)$fatal(1,"Products real challenge failed");
      $fdisplay(setup.fd,"H %0d %0d %0d %0128h",case_no,cid,cregion,ctilde);
      cdr=1;@(posedge clk);@(negedge clk);#1;cdr=0;preparing_challenge=0;preparing_transform=1;tv=1;
      do @(posedge clk);while(!tr);@(negedge clk);#1;tv=0;
      while(!tdone)begin @(negedge clk);#1;end if(tcode || !ctx_valid)$fatal(1,"Products real challenge transform failed");
      tdr=1;@(posedge clk);@(negedge clk);#1;tdr=0;preparing_transform=0;
    end
    $fdisplay(setup.fd,"S %0d %0d %0d %016h %0d %012h %012h %0128h",case_no,reused,tid,ctx_regions,ctx_chat,ctx_low,ctx_high,ctx_ctilde);
  endtask
endmodule
