`timescale 1ps/1ps
module tb_sign_challenge_transform;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,fault_o;logic [15:0] command_id_i=0;
  logic key_valid_i,mask_valid_i;logic [1:0] param_i;logic [15:0] key_id_i,mask_id_i;
  logic [63:0] key_regions_i,mask_regions_i,matrix_regions_i;
  logic matrix_valid_i;logic [15:0] matrix_id_i;logic [6:0][5:0] matrix_yhat_i;
  logic [7:0][5:0] matrix_low_i,matrix_high_i;
  logic challenge_valid_i;logic [15:0] challenge_id_i;logic [5:0] challenge_region_i;
  logic [6:0] challenge_bytes_i;logic [511:0] challenge_ctilde_i;
  logic matrix_take_valid_o,challenge_take_valid_o,matrix_take_ready_i,challenge_take_ready_i;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o,done_detail_o;logic [15:0] done_id_o;
  logic result_valid_o;logic [63:0] result_regions_o;logic [7:0][5:0] result_low_o,result_high_o;
  logic [15:0] result_matrix_id_o;logic [5:0] result_chat_o;logic [511:0] result_ctilde_o;logic [6:0] result_bytes_o;
  logic clear_valid_i=0,clear_ready_o,take_valid_i=0,take_ready_o;
  request_t service_o,wire_request,consumer='0,crequest;response_t service_i,actual;
  sign_challenge_transform dut(.*);
  sign_attempt_setup setup(.clk(clk),.rst(rst),.request_i(wire_request),.response_o(actual));
  logic cv=0,cr,cbusy,cfault,cdone,cdr=0,cclear=0,ccr,cvalid,ctr;
  logic [2:0] ccode,cdetail;logic [15:0] cid;logic [511:0] ctilde;logic [6:0] cbytes;logic [5:0] cregion;
  logic matrix_take_wire,challenge_take_wire;
  sign_challenge_prepare challenge(.clk(clk),.rst(rst),.command_valid_i(cv),.command_ready_o(cr),.busy_o(cbusy),.fault_o(cfault),
    .command_id_i(16'(20000+param_i)),.context_valid_i(setup.result_valid_o),.context_param_i(param_i),
    .context_id_i(setup.done_id_o),.context_regions_i(setup.result_regions_o),.context_high_i(setup.result_high_o),.context_mu_i(setup.mu),
    .done_valid_o(cdone),.done_ready_i(cdr),.done_code_o(ccode),.done_detail_o(cdetail),.done_id_o(cid),
    .result_valid_o(cvalid),.result_ctilde_o(ctilde),.result_bytes_o(cbytes),.result_region_o(cregion),
    .clear_valid_i(cclear),.clear_ready_o(ccr),.take_valid_i(challenge_take_wire),.take_ready_o(ctr),.service_o(crequest),.service_i(actual));
  int case_no=-1,p,jid,nonce,inject,abort_phase,count,fd,cycles=0,commands=0,completions=0,errors=0,aborts=0,reads=0,writes=0,transfers=0;
  bit preparing=0,reading=0,monitor=0,force_fault=0,abort_hit=0,test_passed=0;
  logic [63:0] blockers=0,initial_map,matmap,hatmap,output_map;logic [6:0][5:0] hats;
  logic [7:0][5:0] lows,highs;logic [5:0] original_c;logic [511:0] original_digest;
  wire gm=cycles%7>2,gc=cycles%11>3,go=cycles%13>4,gs=cycles%17>5;
  wire transfer_gate=abort_phase!=1;
  always_comb begin
    key_valid_i=setup.context_valid_i;mask_valid_i=setup.mask_valid_i;param_i=setup.context_param_i;
    key_id_i=setup.context_id_i;mask_id_i=setup.mask_id_i;key_regions_i=setup.context_regions_i;mask_regions_i=setup.mask_regions_i;
    matrix_valid_i=setup.result_valid_o;matrix_id_i=setup.done_id_o;matrix_regions_i=setup.result_regions_o;
    matrix_yhat_i=setup.result_yhat_o;matrix_low_i=setup.result_low_o;matrix_high_i=setup.result_high_o;
    challenge_valid_i=cvalid;challenge_id_i=cid;challenge_region_i=cregion;challenge_bytes_i=cbytes;challenge_ctilde_i=ctilde;
    if(inject==1)matrix_low_i[1]=matrix_low_i[0];if(inject==2)challenge_bytes_i=cbytes-1'b1;
    matrix_take_ready_i=setup.matrix_take_ready && gm && transfer_gate;
    challenge_take_ready_i=ctr && gc && transfer_gate;
    matrix_take_wire=matrix_take_valid_o && gm && transfer_gate;setup.matrix_take_valid=matrix_take_wire;
    challenge_take_wire=challenge_take_valid_o && gc && transfer_gate;
    wire_request=preparing?crequest:((busy_o || command_valid_i)?service_o:consumer);service_i=actual;
    if(!preparing && (busy_o || command_valid_i))begin
      wire_request.op_valid=service_o.op_valid && go;service_i.op_ready=actual.op_ready && go;
      wire_request.op_done_ready=service_o.op_done_ready && gs;service_i.op_done_valid=actual.op_done_valid && gs;
      wire_request.release_valid=service_o.release_valid && gc;service_i.release_ready=actual.release_ready && gc;
      if(inject==3)wire_request.op_a_id=service_o.op_a_id^16'd1;
      if(inject==4)service_i.op_done_id=actual.op_done_id^16'd1;
      if(force_fault)service_i.fault=1;
      if(reading)wire_request=consumer;
    end
  end
  bit held=0,rheld=0;logic [21:0] old_done;logic [800:0] old_result;int elapsed=0;
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held=0;rheld=0;end
    else if(monitor)begin
      elapsed++;if(elapsed>20000)$fatal(1,"Transform watchdog case%0d state%0d",case_no,dut.state);
      if(actual.fault || cfault || setup.fault_o)$fatal(1,"Unexpected source/physical fault");
      if(held && (!done_valid_o || {done_code_o,done_detail_o,done_id_o}!==old_done))$fatal(1,"Held transform done changed");
      held=done_valid_o && !done_ready_i;old_done={done_code_o,done_detail_o,done_id_o};
      if(rheld && !(clear_valid_i && clear_ready_o) && !(take_valid_i && take_ready_o) &&
        (!result_valid_o || {result_regions_o,result_low_o,result_high_o,result_matrix_id_o,result_chat_o,result_ctilde_o,result_bytes_o}!==old_result))$fatal(1,"Retained transform result changed");
      rheld=result_valid_o && !(clear_valid_i && clear_ready_o) && !(take_valid_i && take_ready_o);
      old_result={result_regions_o,result_low_o,result_high_o,result_matrix_id_o,result_chat_o,result_ctilde_o,result_bytes_o};
      if(!result_valid_o && (result_regions_o || result_low_o || result_high_o || result_matrix_id_o || result_chat_o || result_ctilde_o || result_bytes_o))$fatal(1,"Private transform result leaked");
      if((matrix_take_wire && setup.matrix_take_ready)!=(challenge_take_wire && ctr))$fatal(1,"Non-atomic source handoff");
      if(dut.adopted_r && (setup.result_valid_o || cvalid || setup.clear_ready_o || ccr))$fatal(1,"Transferred source owner still live");
      if(command_valid_i && command_ready_o)begin $fdisplay(fd,"C %0d %0d %0d %0d %0d %0d",case_no,p,jid,nonce,inject,abort_phase);commands++;end
      if(matrix_take_wire && setup.matrix_take_ready)begin $fdisplay(fd,"T %0d %016h",case_no,actual.reserved);transfers++;end
      if(wire_request.op_valid && actual.op_ready)$fdisplay(fd,"O %0d %0d %0d %0d %0d %0d",case_no,wire_request.op,wire_request.op_a_region,wire_request.op_a_id,wire_request.op_dest_region,wire_request.op_id);
      if(actual.op_done_valid && wire_request.op_done_ready)$fdisplay(fd,"Q %0d %0d %0d %0d",case_no,service_i.op_done_code,service_i.op_done_id,service_i.op_done_region);
      if(wire_request.release_valid && actual.release_ready && !preparing)begin
        $fdisplay(fd,"F %0d %0d %0d",case_no,dut.state,{wire_request.release_bank,wire_request.release_region});
        if(abort_phase==2 && dut.state==3)abort_hit=1;
      end
      if(setup.services.datapath.subsystem.store.write_fire)begin
        $fdisplay(fd,"X %0d %0d %0d %0d %06h",case_no,dut.state,setup.services.datapath.subsystem.store.write_region,setup.services.datapath.subsystem.store.write_index_i,setup.services.datapath.subsystem.store.write_data_i);writes++;
        if((abort_phase==3 || abort_phase==5) && setup.services.datapath.subsystem.store.write_index_i==31)abort_hit=1;
      end
    end
  end
  task automatic reset_all();
    rst=1;setup.reset_controls();cv=0;cdr=0;cclear=0;command_valid_i=0;done_ready_i=0;clear_valid_i=0;take_valid_i=0;consumer='0;
    monitor=0;reading=0;preparing=0;force_fault=0;blockers=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || actual.reserved || result_valid_o || fault_o)$fatal(1,"Transform reset state");
  endtask
  task automatic read_region(input int kind,input int ordinal,input int region);
    reading=1;
    for(int w=0;w<64;w++)begin
      consumer='0;consumer.read_valid=1;{consumer.read_bank,consumer.read_region}=6'(region);consumer.read_word=6'(w);
      do @(posedge clk);while(!actual.read_ready);@(negedge clk);#1;consumer.read_valid=0;
      while(!actual.response_valid)begin @(negedge clk);#1;end
      if(actual.response_error)$fatal(1,"Transform read error");
      $fdisplay(fd,"V %0d %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,kind,ordinal,region,w,actual.response_id,actual.response_mode,actual.response_param,actual.response_ntt_domain,actual.response_data);reads++;
      repeat(w%3)@(negedge clk);#1;consumer.response_ready=1;@(posedge clk);@(negedge clk);#1;consumer='0;
    end reading=0;
  endtask
  task automatic release_external(input int region);
    consumer='0;consumer.release_valid=1;{consumer.release_bank,consumer.release_region}=6'(region);
    do @(posedge clk);while(!actual.release_ready);@(negedge clk);#1;consumer='0;
    $fdisplay(fd,"L %0d %0d",case_no,region);
  endtask
  initial begin
    int f;string directory,token,skhex,bodyhex;logic [255:0] rnd;bit aborted;logic [63:0] taken;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_sign_transform_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d",token,count)!=2)$fatal(1,"Prepare transform fixtures");
    fd=$fopen({directory,"/stage5_sign_transform_outputs.txt"},"w");$fdisplay(fd,"G %s",token);setup.fd=fd;reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %h %s %s",case_no,p,jid,nonce,inject,abort_phase,rnd,skhex,bodyhex)!=9 || case_no!=c)$fatal(1,"Transform fixture row");
      monitor=0;if(setup.context_valid_i && setup.context_param_i!=p)reset_all();setup.case_no=case_no;
      setup.prepare_all(p,nonce,skhex,bodyhex,rnd);preparing=1;cv=1;
      do @(posedge clk);while(!cr);@(negedge clk);#1;cv=0;
      while(!cdone)begin @(negedge clk);#1;end if(ccode || !cvalid)$fatal(1,"Real challenge source failed");
      cdr=1;@(posedge clk);@(negedge clk);#1;cdr=0;preparing=0;
      hats=setup.result_yhat_o;lows=setup.result_low_o;highs=setup.result_high_o;matmap=setup.result_regions_o;original_c=cregion;original_digest=ctilde;
      $fdisplay(fd,"H %0d %0d %0d %0128h",case_no,cid,cregion,ctilde);
      hatmap=0;for(int j=0;j<(p==0?4:(p==1?5:7));j++)hatmap[hats[j]]=1;
      blockers=0;if(inject==5)for(int r=0;r<64;r++)if(!actual.reserved[r])begin setup.seed_region(r);blockers[r]=1;end
      initial_map=actual.reserved;$fdisplay(fd,"N %0d %016h %016h %011h %012h %012h",case_no,initial_map,matmap,hats,lows,highs);
      elapsed=0;abort_hit=0;monitor=1;command_id_i=16'(jid);command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;
      aborted=0;
      if(abort_phase!=0)begin
        if(abort_phase==1)begin while(dut.state!=2)begin @(negedge clk);#1;end repeat(8)@(negedge clk);#1;end
        else if(abort_phase==4)while(!done_valid_o)begin @(negedge clk);#1;end
        else while(!abort_hit)begin @(negedge clk);#1;end
        if(abort_phase==5)begin force_fault=1;repeat(3)@(negedge clk);#1;if(!fault_o || done_valid_o || result_valid_o)$fatal(1,"Transform injected fault not HALT");end
        $fdisplay(fd,"Z %0d %0d %0d",case_no,abort_phase,dut.state);aborts++;aborted=1;reset_all();
      end
      if(!aborted)begin
        while(!done_valid_o)begin @(negedge clk);#1;end
        if(done_code_o==0)$fdisplay(fd,"D %0d %016h %0d %0d %0d %0128h",case_no,result_regions_o,result_chat_o,result_matrix_id_o,result_bytes_o,result_ctilde_o);
        repeat(7)@(negedge clk);#1;$fdisplay(fd,"E %0d %0d %0d %0d",case_no,done_id_o,done_code_o,done_detail_o);completions++;if(done_code_o)errors++;
        done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
        if(done_code_o==0)begin
          output_map=result_regions_o;read_region(0,0,result_chat_o);
          for(int r=0;r<(p==0?4:(p==1?6:8));r++)begin read_region(1,r,lows[r]);read_region(2,r,highs[r]);end
          // Old owners must not clear transferred storage.
          cclear=1;setup.clear_valid_i=1;repeat(6)begin @(negedge clk);#1;if(ccr || setup.clear_ready_o || actual.reserved!=(initial_map & ~hatmap & ~(64'd1<<original_c) | (64'd1<<result_chat_o)))$fatal(1,"Old owner reclaimed transferred storage");end
          cclear=0;setup.clear_valid_i=0;
          reading=1;consumer='0;consumer.read_valid=1;{consumer.read_bank,consumer.read_region}=result_chat_o;
          do @(posedge clk);while(!actual.read_ready);@(negedge clk);#1;consumer.read_valid=0;
          while(!actual.response_valid)begin @(negedge clk);#1;end
          if(inject==5)take_valid_i=1;else clear_valid_i=1;
          repeat(6)begin @(negedge clk);#1;if(clear_ready_o || take_ready_o)$fatal(1,"Transform transfer/clear bypassed pending read");end
          $fdisplay(fd,"BARRIER %0d %023h",case_no,actual.response_data);consumer.response_ready=1;@(posedge clk);@(negedge clk);#1;consumer='0;reading=0;
          if(inject==5)begin
            taken=result_regions_o;do @(posedge clk);while(!take_ready_o);$fdisplay(fd,"A %0d %016h",case_no,taken);
            @(negedge clk);#1;take_valid_i=0;for(int r=0;r<64;r++)if(taken[r])release_external(r);
          end else begin do @(posedge clk);while(!clear_ready_o);@(negedge clk);#1;clear_valid_i=0;end
        end
        while(busy_o)begin @(negedge clk);#1;end
        if(inject==1 || inject==2)begin
          for(int j=0;j<(p==0?4:(p==1?5:7));j++)read_region(7,j,hats[j]);
          for(int r=0;r<(p==0?4:(p==1?6:8));r++)begin read_region(1,r,lows[r]);read_region(2,r,highs[r]);end
          read_region(8,0,original_c);
          preparing=1;cclear=1;do @(posedge clk);while(!ccr);@(negedge clk);#1;cclear=0;
          while(cbusy)begin @(negedge clk);#1;end preparing=0;setup.preparing_matrix=1;setup.clear_valid_i=1;
          do @(posedge clk);while(!setup.clear_ready_o);@(negedge clk);#1;setup.clear_valid_i=0;
          while(setup.busy_o)begin @(negedge clk);#1;end setup.preparing_matrix=0;
        end
        for(int j=0;j<(p==0?12:(p==1?17:23));j++)read_region(3,j,setup.kh[j]);
        for(int j=0;j<(p==0?4:(p==1?5:7));j++)read_region(4,j,setup.mask_handles_i[j]);
        read_region(5,0,50);
        for(int r=0;r<64;r++)if(blockers[r])begin read_region(6,r,r);release_external(r);end
        if(actual.reserved!==(setup.context_regions_i|setup.mask_regions_i|(64'd1<<50)))$fatal(1,"Transform leaked/clobbered memory");
        $fdisplay(fd,"B %0d %016h",case_no,actual.reserved);
      end monitor=0;
    end
    $fdisplay(fd,"END %0d %0d %0d %0d %0d %0d %0d",commands,completions,errors,aborts,transfers,writes,reads);
    $fclose(f);$fclose(fd);$display("STAGE5N4H1_SIGN_TRANSFORM_CAPTURE_PASS:%0d commands,%0d completions,%0d errors,%0d aborts",commands,completions,errors,aborts);test_passed=1;$finish;
  end
  initial begin #(64'd150000000000);$fatal(1,"Transform global watchdog case%0d",case_no);end
endmodule
