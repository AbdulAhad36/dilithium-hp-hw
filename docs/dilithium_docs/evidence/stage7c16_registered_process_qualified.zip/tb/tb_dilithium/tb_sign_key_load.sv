`timescale 1ps/1ps
// Real decoder -> allocator/packer -> four dual-port banks. No RAM backdoors.
// This focused client gate precedes connection to the shared service arbiter.
module tb_sign_key_load;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,fault_o;
  logic [1:0] command_param_i=0;logic [15:0] command_id_i=0;logic [5:0] command_base_i=0;
  logic input_valid_i=0,input_ready_o,input_last_i=0;logic [63:0] input_data_i=0;
  logic [3:0] input_bytes_i=8;logic [9:0] input_index_i=0;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o;logic [15:0] done_id_o;
  logic [63:0] done_regions_o;logic [255:0] header_rho_o,header_key_o;logic [511:0] header_tr_o;
  logic [63:0] reserved,complete,visible,release_locks_o,hidden_o;
  logic alloc_valid_o,alloc_ready_i;logic [5:0] alloc_region_o;logic [15:0] alloc_id_o;
  logic [1:0] alloc_mode_o,alloc_param_o;
  logic write_valid_o,write_last_o,write_ready_i;logic [15:0] write_id_o;
  logic [7:0] write_index_o;logic [22:0] write_data_o;
  logic finish_valid_o,finish_ready_i;logic [15:0] finish_id_o;logic [2:0] finish_code_o;
  logic release_valid_o,release_ready_i;logic [5:0] release_region_o;
  sign_key_load dut(.reserved_i(reserved),.*);
  logic ca=0,cw=0,cf=0,cr=0,cy=0,cz=0;logic [5:0] region=0,rword=0,zregion=0;
  logic [7:0] index=0;logic [22:0] data=0;
  logic ma,mw,mf,mr,mv,me,mz,mem_fault;logic [1:0] mbank,mmode,mparam;
  logic [3:0] mregion;logic [5:0] mword;logic [91:0] mdata;logic [15:0] mid;logic mdomain,msmall;
  int cycles=0,case_no=-1,p,jid,base,sentinel,fault_word,fault,abort_phase,length,count,fd;
  int completions=0,errors=0,aborts=0,values=0,reads=0,word_count=0;int witnesses[6];
  bit monitor=0,test_passed=0,abort_request=0,hold_write=0;
  wire ga=cycles%7>2,gw=cycles%11>4 && !hold_write,gf=cycles%13>5,gz=cycles%17>6;
  wire host_release=cz && !release_locks_o[zregion] &&
    !(command_valid_i && command_ready_o); // exclusive acceptance edge
  assign alloc_ready_i=ma && ga;assign write_ready_i=mw && gw;
  assign finish_ready_i=mf && gf;assign release_ready_i=mz && gz;
  assign visible=complete & ~hidden_o;
  memory store(
    .clk(clk),.rst(rst),.alloc_valid_i(busy_o?(alloc_valid_o && ga):ca),.alloc_core_i(1'b0),
    .alloc_bank_i(busy_o?alloc_region_o[5:4]:region[5:4]),.alloc_region_i(busy_o?alloc_region_o[3:0]:region[3:0]),
    .alloc_id_i(busy_o?alloc_id_o:16'd60000),.alloc_mode_i(busy_o?alloc_mode_o:2'd2),
    .alloc_param_i(busy_o?alloc_param_o:2'd0),.alloc_compute_i(1'b1),.alloc_ntt_domain_i(1'b0),.alloc_rewrite_i(1'b0),.alloc_ready_o(ma),
    .write_valid_i(busy_o?(write_valid_o && gw):cw),.write_core_i(1'b0),
    .write_last_i(busy_o?write_last_o:index==255),.write_id_i(busy_o?write_id_o:16'd60000),
    .write_index_i(busy_o?write_index_o:index),.write_data_i(busy_o?write_data_o:data),.write_ready_o(mw),
    .finish_valid_i(busy_o?(finish_valid_o && gf):cf),.finish_core_i(1'b0),
    .finish_id_i(busy_o?finish_id_o:16'd60000),.finish_code_i(busy_o?finish_code_o:3'd0),.finish_ready_o(mf),
    .read_valid_i(cr && !busy_o),.read_bank_i(region[5:4]),.read_region_i(region[3:0]),.read_word_i(rword),
    .read_ready_o(mr),.response_valid_o(mv),.response_error_o(me),.response_bank_o(mbank),.response_region_o(mregion),
    .response_word_o(mword),.response_data_o(mdata),.response_id_o(mid),.response_mode_o(mmode),.response_param_o(mparam),
    .response_ntt_domain_o(mdomain),.response_small_o(msmall),.response_ready_i(cy && !busy_o),
    .release_valid_i(busy_o?(release_valid_o && gz):host_release),
    .release_bank_i(busy_o?release_region_o[5:4]:zregion[5:4]),.release_region_i(busy_o?release_region_o[3:0]:zregion[3:0]),
    .release_ready_o(mz),.reserved_o(reserved),.complete_o(complete),.fault_o(mem_fault)
  );
  logic held=0,wh=0;logic [1106:0] last_done;logic [47:0] last_write;
  wire [1106:0] done_payload={done_code_o,done_id_o,done_regions_o,header_rho_o,header_key_o,header_tr_o};
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held=0;wh=0;end
    else begin
      if(fault_o || mem_fault)$fatal(1,"Key load/store fault case%0d state%0d",case_no,dut.state);
      if(held && (!done_valid_o || done_payload!==last_done))$fatal(1,"Key load changed held result");
      held=done_valid_o && !done_ready_i;last_done=done_payload;
      if(wh && (!write_valid_o || {write_id_o,write_index_o,write_data_o,write_last_o}!==last_write))$fatal(1,"Key load changed held write");
      wh=write_valid_o && !write_ready_i;last_write={write_id_o,write_index_o,write_data_o,write_last_o};
      if(monitor)begin
        if(command_valid_i && command_ready_o)$fdisplay(fd,"C %0d %0d %0d %0d %0d",case_no,p,jid,base,sentinel);
        if(input_valid_i && input_ready_o)begin
          $fdisplay(fd,"W %0d %0d %0d %0d %016h",case_no,input_index_i,input_bytes_i,input_last_i,input_data_i);word_count++;
        end
        if(store.alloc_fire)$fdisplay(fd,"L %0d %0d %0d %0d %0d",case_no,{store.alloc_bank_i,store.alloc_region_i},store.alloc_id_i,store.alloc_mode_i,store.alloc_param_i);
        if(store.write_fire)begin
          $fdisplay(fd,"X %0d %0d %0d %06h %0d",case_no,store.write_region,store.write_index_i,store.write_data_i,store.write_last_i);values++;
        end
        if(store.finish_fire)begin
          $fdisplay(fd,"U %0d %0d %0d",case_no,store.finish_region,store.finish_code_i);
          if(abort_phase==2 && store.finish_code_i==0)abort_request=1;
        end
        if(store.release_fire)$fdisplay(fd,"Z %0d %0d",case_no,store.release_region);
        for(int b=0;b<4;b++)begin
          if(store.request_valid[0][b] && store.request_ready[0][b])$fdisplay(fd,"P %0d %0d %0d %023h",case_no,16*b+int'(store.request_address[0][b][9:6]),store.request_address[0][b][5:0],store.request_data[0][b]);
          if(store.response_valid[0][b] && store.response_ready[0][b])$fdisplay(fd,"K %0d %0d %0d",case_no,16*b+int'(store.response_address[0][b][9:6]),store.response_address[0][b][5:0]);
        end
        if(busy_o)begin
          if(command_ready_o)$fatal(1,"Key loader accepted over held owner");
          if(!done_valid_o && ((visible & dut.plan_r)!=0 || header_rho_o || header_key_o || header_tr_o))$fatal(1,"Tentative key published");
          if(done_valid_o && done_code_o!=0 && ((reserved & dut.plan_r)!=0 || done_regions_o || header_rho_o || header_key_o || header_tr_o))$fatal(1,"Bad key not rolled back");
          if(write_valid_o && !write_ready_i)witnesses[0]++;
          if(finish_valid_o && !finish_ready_i)witnesses[1]++;
          if(alloc_valid_o && !alloc_ready_i)witnesses[2]++;
          if((complete & hidden_o)!=0)witnesses[3]++;
          if(release_valid_o && !release_ready_i)witnesses[4]++;
          if(cz && release_locks_o[zregion])begin if(host_release)$fatal(1,"Released private key");witnesses[5]++;end
        end
      end
    end
  end
  always @(negedge clk)if(monitor && !rst)begin
    if(abort_phase==3 && write_valid_o)abort_request=1;
    if(abort_phase==4 && write_valid_o && dut.dec_key_last)begin hold_write=1;abort_request=1;end
  end
  task automatic reset_all();
    @(negedge clk);#1;rst=1;command_valid_i=0;input_valid_i=0;done_ready_i=0;ca=0;cw=0;cf=0;cr=0;cy=0;cz=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || done_valid_o || reserved || complete || header_key_o || header_tr_o || header_rho_o || hidden_o || release_locks_o)$fatal(1,"Key load reset retained ownership");
  endtask
  task automatic seed_sentinel();
    region=6'(sentinel);ca=1;do @(posedge clk);while(!ma);@(negedge clk);#1;ca=0;
    for(int j=0;j<256;j++)begin
      index=8'(j);data=23'(7000+j);cw=1;do @(posedge clk);while(!mw);@(negedge clk);#1;cw=0;
    end
    cf=1;do @(posedge clk);while(!mf);@(negedge clk);#1;cf=0;
  endtask
  task automatic read_region(input int regno,input bit capture);
    region=6'(regno);
    for(int w=0;w<64;w++)begin
      rword=6'(w);cr=1;do @(posedge clk);while(!mr);@(negedge clk);#1;cr=0;
      do begin @(negedge clk);#1;end while(!mv);
      repeat(2)@(negedge clk);#1;
      if(me || {mbank,mregion}!=regno || mword!=w)$fatal(1,"Key load read metadata");
      if(capture)begin
        $fdisplay(fd,"V %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,regno,w,mid,mmode,mparam,mdomain,msmall,mdata);reads++;
      end else begin
        if(mid!=60000 || mmode!=2 || mparam || mdomain)$fatal(1,"Sentinel metadata changed");
        for(int lane=0;lane<4;lane++)if(mdata[23*lane+:23]!==23'(7000+4*w+lane))$fatal(1,"Sentinel overwritten");
      end
      cy=1;@(posedge clk);@(negedge clk);#1;cy=0;
    end
  endtask
  task automatic free_region(input int regno);
    zregion=6'(regno);cz=1;do @(posedge clk);while(!mz);@(negedge clk);#1;cz=0;
  endtask
  initial begin
    int f,n;string directory,token,hexkey;byte unsigned octet;logic [63:0] result_mask;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_sign_load_inputs.txt"},"r");
    if(!f || $fscanf(f,"%s %d",token,count)!=2 || count<130)$fatal(1,"Prepare key load vectors");
    fd=$fopen({directory,"/stage5_sign_load_outputs.txt"},"w");$fdisplay(fd,"H %s",token);reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %d %d %d %s",case_no,p,jid,base,sentinel,fault_word,fault,abort_phase,length,hexkey)!=10 || case_no!=c || hexkey.len()!=2*length)$fatal(1,"Key load fixture");
      seed_sentinel();hold_write=abort_phase==3;abort_request=0;word_count=0;
      foreach(witnesses[j])witnesses[j]=0;
      monitor=1;command_param_i=2'(p);command_id_i=16'(jid);command_base_i=6'(base);command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;
      zregion=6'(base);cz=1; // futile external release probes throughout ownership
      for(int w=0;w<length/8;w++)begin
        if(done_valid_o || abort_request)break;
        input_data_i=0;
        for(int b=0;b<8;b++)begin
          n=$sscanf(hexkey.substr(2*(8*w+b),2*(8*w+b)+1),"%h",octet);if(n!=1)$fatal(1,"Key byte");input_data_i[8*b+:8]=octet;
        end
        input_index_i=10'(w ^ ((fault==1 && w==fault_word)?1:0));input_bytes_i=4'((fault>=10 && w==fault_word)?fault-10:8);
        input_last_i=(w==length/8-1) ^ (fault==2 && w==fault_word);input_valid_i=1;
        do @(posedge clk);while(!input_ready_o && !done_valid_o && !abort_request);
        @(negedge clk);#1;input_valid_i=0;
        if(abort_request)break;
        if(abort_phase==1 && word_count==3)begin abort_request=1;break;end
        if(w%19==0)begin repeat(2)@(negedge clk);#1;end
      end
      do begin @(negedge clk);#1;end while(!done_valid_o && !abort_request);
      if(abort_phase!=0)begin
        repeat(5)begin @(negedge clk);#1;end
        $fdisplay(fd,"A %0d %0d",case_no,abort_phase);$fdisplay(fd,"T %0d %0d %0d %0d %0d %0d %0d",case_no,witnesses[0],witnesses[1],witnesses[2],witnesses[3],witnesses[4],witnesses[5]);
        aborts++;monitor=0;reset_all();hold_write=0;continue;
      end
      repeat(7)begin @(negedge clk);#1;end
      $fdisplay(fd,"D %0d %0d %0d %016h %064h %064h %0128h",case_no,done_code_o,done_id_o,done_regions_o,header_rho_o,header_key_o,header_tr_o);
      result_mask=done_regions_o;completions++;if(done_code_o!=0)errors++;
      $fdisplay(fd,"T %0d %0d %0d %0d %0d %0d %0d",case_no,witnesses[0],witnesses[1],witnesses[2],witnesses[3],witnesses[4],witnesses[5]);
      cz=0;done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;monitor=0;
      if(reserved!=(result_mask | (64'd1<<sentinel)) || complete!=reserved)$fatal(1,"Rollback/publication mask");
      read_region(sentinel,0);$fdisplay(fd,"S %0d %0d",case_no,sentinel);
      for(int r=0;r<64;r++)if(result_mask[r])begin read_region(r,1);free_region(r);end
      free_region(sentinel);if(reserved)$fatal(1,"Key load leaked allocation");
    end
    $fdisplay(fd,"F %0d %0d %0d %0d %0d %0d",count,completions,errors,aborts,values,reads);$fclose(f);$fclose(fd);
    $display("STAGE5N4C1_SIGN_LOAD_CAPTURE_PASS:%0d commands,%0d complete,%0d errors,%0d resets,%0d writes,%0d reads",count,completions,errors,aborts,values,reads);test_passed=1;$finish;
  end
  initial begin #(64'd40000000000);$fatal(1,"Key load watchdog case%0d state%0d",case_no,dut.state);end
endmodule
