`timescale 1ps/1ps
// Actual key -> mask -> A*y -> challenge -> products, one physical services.
module sign_check_setup(input logic clk,rst,
  input wire dilithium_service_pkg::request_t request_i,
  output dilithium_service_pkg::response_t response_o,
  input logic take_valid_i,output logic take_ready_o);
  import dilithium_service_pkg::*;
  request_t routed,service_o;response_t actual;
  logic command_valid_i=0,command_ready_o,busy_o,fault_o;logic [15:0] command_id_i;
  logic key_valid_i;logic [1:0] param_i;logic [15:0] key_id_i;logic [63:0] key_regions_i;logic [22:0][5:0] key_handles_i;
  logic mask_valid_i;logic [15:0] mask_id_i,mask_nonce_i;logic [63:0] mask_regions_i;logic [6:0][5:0] mask_handles_i;
  logic [511:0] mask_mu_i,mask_seed_i;
  logic vector_valid_i;logic [15:0] vector_id_i,vector_matrix_id_i;logic [63:0] vector_regions_i;
  logic [7:0][5:0] vector_low_i,vector_high_i;logic [5:0] vector_chat_i;logic [511:0] vector_ctilde_i;logic [6:0] vector_bytes_i;
  logic mask_take_valid_o,vector_take_valid_o,mask_take_ready_i,vector_take_ready_i;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o,done_detail_o;logic [15:0] done_id_o;
  logic result_valid_o;logic [63:0] result_regions_o;logic [6:0][5:0] result_z_o;
  logic [7:0][5:0] result_low_o,result_high_o,result_ct0_o;logic [15:0] result_high_id_o;
  logic [511:0] result_mu_o,result_seed_o,result_ctilde_o;logic [6:0] result_bytes_o;logic [16:0] result_next_nonce_o;
  logic clear_valid_i=0,clear_ready_o;bit preparing=0;
  sign_response_products products(.service_i(actual),.*);
  sign_products_setup upstream(.clk(clk),.rst(rst),.request_i(routed),.response_o(actual),
    .mask_take_valid_i(mask_take_valid_o),.vector_take_valid_i(vector_take_valid_o),
    .mask_take_ready_o(mask_take_ready_i),.vector_take_ready_o(vector_take_ready_i));
  always_comb begin
    key_valid_i=upstream.setup.context_valid_i;param_i=upstream.setup.context_param_i;key_id_i=upstream.setup.context_id_i;
    key_regions_i=upstream.setup.context_regions_i;key_handles_i=upstream.setup.kh;
    mask_valid_i=upstream.setup.mask_valid_i;mask_id_i=upstream.setup.mask_id_i;mask_nonce_i=upstream.setup.mask_nonce;
    mask_regions_i=upstream.setup.mask_regions_i;mask_handles_i=upstream.setup.mask_handles_i;mask_mu_i=upstream.setup.mu;mask_seed_i=upstream.setup.seed;
    vector_valid_i=upstream.ctx_valid;vector_id_i=upstream.tid;vector_matrix_id_i=upstream.ctx_matrix_id;
    vector_regions_i=upstream.ctx_regions;vector_low_i=upstream.ctx_low;vector_high_i=upstream.ctx_high;
    vector_chat_i=upstream.ctx_chat;vector_ctilde_i=upstream.ctx_ctilde;vector_bytes_i=upstream.ctx_bytes;
    routed=preparing?service_o:request_i;response_o=actual;
  end
  task automatic reset_controls();
    upstream.reset_controls();command_valid_i=0;done_ready_i=0;clear_valid_i=0;preparing=0;
  endtask
  task automatic prepare_all(input int case_no,level,nonce,input string skhex,bodyhex,input logic [255:0] rnd);
    if(!result_valid_o)begin
      upstream.prepare_all(case_no,level,nonce,skhex,bodyhex,rnd);preparing=1;command_id_i=16'(35000+level);command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;
      while(!done_valid_o)begin @(negedge clk);#1;end
      if(done_code_o || !result_valid_o)$fatal(1,"Check real products failed");
      done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;preparing=0;
    end
    $fdisplay(upstream.setup.fd,"Y %0d %0d %016h %011h %012h %012h %012h %0d %0d %0d %0128h %0128h %0128h",
      case_no,done_id_o,result_regions_o,result_z_o,result_low_o,result_high_o,result_ct0_o,result_high_id_o,
      result_bytes_o,result_next_nonce_o,result_mu_o,result_seed_o,result_ctilde_o);
  endtask
endmodule
