`timescale 1ps/1ps
module tb_sign_key_decode;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o;logic [1:0] command_param_i=0;
  logic [15:0] command_id_i=0;
  logic input_valid_i=0,input_ready_o,input_last_i=0;logic [63:0] input_data_i=0;
  logic [3:0] input_bytes_i=8;logic [9:0] input_index_i=0;
  logic header_valid_o,header_ready_i;logic [255:0] header_rho_o,header_key_o;
  logic [511:0] header_tr_o;logic [15:0] header_id_o;
  logic output_valid_o,output_ready_i,output_last_poly_o,output_last_key_o;
  logic [22:0] output_data_o;logic [1:0] output_section_o;logic [2:0] output_poly_o;
  logic [7:0] output_index_o;logic [15:0] output_id_o;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o;logic [15:0] done_id_o;
  sign_key_decode dut(.*);
  int cycles=0,case_no=-1,p,jid,fault_word,fault,abort_phase,length,count,fd;
  int completions=0,errors=0,aborts=0,coefficients=0,word_count=0;
  int hold_checks=0,header_stalls=0,output_stalls=0,input_stalls=0;
  bit hold_header=1,hold_output=0,abort_request=0,test_passed=0,monitor=0;
  logic scheduled_header=0,scheduled_output=0;
  assign header_ready_i=!rst && !hold_header && scheduled_header;
  assign output_ready_i=!rst && !hold_output && scheduled_output;
  always @(negedge clk)begin
    scheduled_header<=cycles%17>5;scheduled_output<=cycles%23>7;
    if(!rst && monitor)begin
      if(abort_phase==3 && output_valid_o)abort_request=1;
      if(abort_phase==4 && output_valid_o && output_last_key_o)begin hold_output=1;abort_request=1;end
    end
  end
  logic ih=0,oh=0,bh=0,dh=0;logic [78:0] previous_input;
  logic [53:0] previous_output;logic [1039:0] previous_header;logic [18:0] previous_done;
  wire [78:0] input_payload={input_data_i,input_bytes_i,input_index_i,input_last_i};
  wire [53:0] output_payload={output_id_o,output_section_o,output_poly_o,output_index_o,output_data_o,output_last_poly_o,output_last_key_o};
  always @(posedge clk)begin
    cycles++;
    if(rst)begin ih=0;oh=0;bh=0;dh=0;end
    else if(monitor)begin
      if(ih && !done_valid_o && (!input_valid_i || input_payload!==previous_input))$fatal(1,"Decode test changed held input");
      if(oh && (!output_valid_o || output_payload!==previous_output))$fatal(1,"Decode changed held coefficient");
      if(bh && (!header_valid_o || {header_id_o,header_rho_o,header_key_o,header_tr_o}!==previous_header))$fatal(1,"Decode changed held header");
      if(dh && (!done_valid_o || {done_code_o,done_id_o}!==previous_done))$fatal(1,"Decode changed held completion");
      ih=input_valid_i && !input_ready_o;previous_input=input_payload;
      oh=output_valid_o && !output_ready_i;previous_output=output_payload;
      bh=header_valid_o && !header_ready_i;previous_header={header_id_o,header_rho_o,header_key_o,header_tr_o};
      dh=done_valid_o && !done_ready_i;previous_done={done_code_o,done_id_o};
      if(ih)input_stalls++;if(oh)output_stalls++;if(bh)header_stalls++;
      if(command_valid_i && command_ready_o)$fdisplay(fd,"C %0d %0d %0d",case_no,command_param_i,command_id_i);
      if(input_valid_i && input_ready_o)begin
        $fdisplay(fd,"W %0d %0d %0d %0d %016h",case_no,input_index_i,input_bytes_i,input_last_i,input_data_i);word_count++;
      end
      if(header_valid_o && header_ready_i)$fdisplay(fd,"B %0d %0d %064h %064h %0128h",case_no,header_id_o,header_rho_o,header_key_o,header_tr_o);
      if(output_valid_o && output_ready_i)begin
        $fdisplay(fd,"P %0d %0d %0d %0d %0d %06h %0d %0d",case_no,output_id_o,output_section_o,output_poly_o,output_index_o,output_data_o,output_last_poly_o,output_last_key_o);
        coefficients++;
      end
    end
  end
  task automatic reset_all();
    @(negedge clk);#1;rst=1;command_valid_i=0;input_valid_i=0;done_ready_i=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || done_valid_o || output_valid_o || header_valid_o || header_rho_o || header_key_o || header_tr_o || dut.count_r)$fatal(1,"Decode reset retained state");
  endtask
  task automatic witness();
    $fdisplay(fd,"T %0d %0d %0d %0d %0d",case_no,hold_checks,header_stalls,output_stalls,input_stalls);
  endtask
  initial begin
    int f,n,idx;string directory,token,hexkey;byte unsigned octet;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_sign_decode_inputs.txt"},"r");
    if(!f || $fscanf(f,"%s %d",token,count)!=2 || count<90)$fatal(1,"Prepare secret-key decoder vectors");
    fd=$fopen({directory,"/stage5_sign_decode_outputs.txt"},"w");$fdisplay(fd,"H %s",token);reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %d %s",case_no,p,jid,fault_word,fault,abort_phase,length,hexkey)!=8 || case_no!=c || hexkey.len()!=2*length)$fatal(1,"Decode fixture row");
      hold_header=1;hold_output=abort_phase==3;abort_request=0;word_count=0;
      hold_checks=0;header_stalls=0;output_stalls=0;input_stalls=0;monitor=1;
      command_param_i=2'(p);command_id_i=16'(jid);command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;
      for(int w=0;w<length/8;w++)begin
        if(done_valid_o || abort_request)break;
        input_data_i=0;
        for(int b=0;b<8;b++)begin
          n=$sscanf(hexkey.substr(2*(8*w+b),2*(8*w+b)+1),"%h",octet);if(n!=1)$fatal(1,"Decode fixture byte");input_data_i[8*b+:8]=octet;
        end
        input_index_i=10'(w ^ ((fault==1 && w==fault_word)?1:0));input_bytes_i=4'((fault>=10 && w==fault_word)?fault-10:8);
        input_last_i=(w==length/8-1) ^ (fault==2 && w==fault_word);input_valid_i=1;
        do @(posedge clk);while(!input_ready_o && !done_valid_o && !abort_request);
        @(negedge clk);#1;
        if(abort_request)break;
        input_valid_i=0;
        if(abort_phase==1 && word_count>=3)begin abort_request=1;break;end
        if(w==15 && !done_valid_o)begin
          repeat(6)@(negedge clk);#1;
          if(abort_phase==2)begin abort_request=1;break;end
          hold_header=0;
        end
        if(w%13==0)repeat(2)@(negedge clk);#1;
      end
      do begin @(negedge clk);#1;end while(!done_valid_o && !abort_request);
      if(abort_phase!=0)begin
        if(abort_phase==5 && !done_valid_o)$fatal(1,"Decode completion abort phase");
        repeat(6)begin @(negedge clk);#1;hold_checks++;end
        $fdisplay(fd,"A %0d %0d",case_no,abort_phase);witness();aborts++;reset_all();monitor=0;continue;
      end
      repeat(6)begin @(negedge clk);#1;hold_checks++;if(command_ready_o || input_ready_o)$fatal(1,"Decode accepted over held completion");end
      $fdisplay(fd,"D %0d %0d %0d",case_no,done_code_o,done_id_o);witness();completions++;if(done_code_o!=0)errors++;
      done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;monitor=0;
    end
    $fdisplay(fd,"F %0d %0d %0d %0d %0d",count,completions,errors,aborts,coefficients);$fclose(f);$fclose(fd);
    $display("STAGE5N4A_SIGN_DECODE_CAPTURE_PASS:%0d commands,%0d completions,%0d errors,%0d resets,%0d coefficients",count,completions,errors,aborts,coefficients);
    test_passed=1;$finish;
  end
  initial begin #(64'd30000000000);$fatal(1,"Decode watchdog case%0d state%0d",case_no,dut.state);end
endmodule
