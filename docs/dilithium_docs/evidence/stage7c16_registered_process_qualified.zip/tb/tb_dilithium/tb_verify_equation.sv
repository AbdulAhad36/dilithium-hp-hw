`timescale 1ps/1ps
module tb_verify_equation;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,fault_o;logic [15:0] command_id_i=0;
  logic context_valid_i,context_take_valid_o,context_take_ready_i;logic [1:0] context_param_i;logic [15:0] context_id_i;logic [63:0] context_regions_i;
  logic [7:0][5:0] context_t1hat_i,context_hints_i;logic [6:0][5:0] context_zhat_i;logic [5:0] context_chat_i;
  logic [255:0] context_rho_i;logic [511:0] context_mu_i,context_ctilde_i;
  logic done_valid_o,done_ready_i=0,done_accept_o;logic [15:0] done_id_o;logic [2:0] done_code_o,done_detail_o;logic [511:0] done_digest_o;
  request_t service_o,prep_request,external_request,actual;response_t service_i,response;
  logic sclear=0,scr,stake,str,sbusy,sfault,svalid;logic [1:0] sp;logic [15:0] sid;logic [63:0] sregions;
  logic [7:0][5:0] st1,shints;logic [6:0][5:0] sz;logic [5:0] schat;logic [255:0] srho;logic [511:0] smu,sctilde;
  int owner=0,cycles=0,elapsed=0,case_no=-1,p,jid,base,scenario,abort_phase,expected_code,expected_detail,ctxlen,mlen,sentinel;
  int fd,count,unit_count,commands=0,adoptions=0,dones=0,aborts=0,allocs=0,writes=0,finishes=0,releases=0,reads=0,ntts=0,processes=0,pack_inputs=0,pack_outputs=0,raw_words=0,raw_beats=0;
  int sample_index=0,raw_index=0;bit monitor=0,test_passed=0,change_source=0,inject_raw=0;
  logic [1:0] up=0;logic [22:0] ua=0,uh=0;logic [5:0] uhigh;logic uerror;
  use_hint probe(.param_i(up),.coefficient_i(ua),.hint_i(uh),.high_o(uhigh),.error_o(uerror));
  verify_equation dut(.*);
  verify_setup setup(.clk(clk),.rst(rst),.clear_i(sclear),.take_i(stake),.clear_ready_o(scr),.take_ready_o(str),.busy_o(sbusy),.fault_o(sfault),
    .valid_o(svalid),.param_o(sp),.id_o(sid),.regions_o(sregions),.t1hat_o(st1),.hints_o(shints),.zhat_o(sz),.chat_o(schat),.rho_o(srho),.mu_o(smu),.ctilde_o(sctilde),.request_o(prep_request),.response_i(response));
  dilithium_services physical(.clk(clk),.rst(rst),.request_i(actual),.response_o(response));
  always_comb begin
    context_valid_i=svalid;context_param_i=sp;context_id_i=sid;context_regions_i=sregions;context_t1hat_i=st1;context_hints_i=shints;
    context_zhat_i=sz;context_chat_i=schat;context_rho_i=srho;context_mu_i=smu;context_ctilde_i=sctilde;
    if(scenario==1)context_t1hat_i[1]=st1[0];
    if(scenario==2 || change_source)context_id_i=sid^16'd1;
    context_take_ready_i=str && abort_phase!=1;stake=context_take_valid_o && abort_phase!=1;
    actual=owner==2?service_o:owner==1?prep_request:external_request;service_i=response;
    if(owner==2)begin
      actual.input_valid=service_o.input_valid && cycles%7>2;service_i.input_ready=response.input_ready && cycles%7>2;
      actual.status_ready=service_o.status_ready && cycles%7>2;service_i.status_valid=response.status_valid && cycles%7>2;
      actual.op_valid=service_o.op_valid && cycles%5>1;service_i.op_ready=response.op_ready && cycles%5>1;
      actual.op_done_ready=service_o.op_done_ready && cycles%7>1;service_i.op_done_valid=response.op_done_valid && cycles%7>1;
      actual.process_valid=service_o.process_valid && cycles%11>2;service_i.process_ready=response.process_ready && cycles%11>2;
      actual.process_done_ready=service_o.process_done_ready && cycles%5>1;service_i.process_done_valid=response.process_done_valid && cycles%5>1;
      actual.raw_input_valid=service_o.raw_input_valid && cycles%11>3;service_i.raw_input_ready=response.raw_input_ready && cycles%11>3;
      actual.raw_output_ready=service_o.raw_output_ready && cycles%17>5 && abort_phase!=7;
      service_i.raw_output_valid=response.raw_output_valid && cycles%17>5 && abort_phase!=7;
      if(scenario==4 && dut.state==1)service_i.complete=0;
      if(scenario==5 && dut.state==2)service_i.reserved='1;
      if(scenario==6)service_i.status_id=16'hf00d;
      if(scenario==7)service_i.op_done_id=16'hf00d;
      if(scenario==8)service_i.process_done_id=16'hf00d;
      if(scenario==9 && dut.state==22 && dut.row_r==0 && dut.word_r==0)service_i.response_id=16'hf00d;
      if(scenario==10 && dut.state==22 && dut.row_r==0 && dut.word_r==0)service_i.response_data[22:0]=23'd64;
      if(scenario==11 && response.pack.output_valid && dut.row_r==0 && response.pack.output_index==0)service_i.pack.output_index=1;
      if(scenario==12)service_i.pack.done_id=16'hf00d;
      if(scenario==13)actual.op_a_id=service_o.op_a_id^16'd1;
      if(inject_raw)service_i.raw_output_id=16'hf00d;
    end
  end
  logic held_done=0,held_raw=0;logic [534:0] done_snapshot;logic [149:0] raw_snapshot;
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held_done=0;held_raw=0;end
    else if(monitor)begin
      elapsed++;if(elapsed>1000000)$fatal(1,"Verify equation watchdog case%0d state%0d row%0d col%0d",case_no,dut.state,dut.row_r,dut.column_r);
      if(fault_o && abort_phase!=9 && abort_phase!=10)$fatal(1,"Unexpected equation fault case%0d state%0d",case_no,dut.state);
      if(held_done && (!done_valid_o || done_snapshot!=={done_id_o,done_code_o,done_detail_o,done_accept_o,done_digest_o}))$fatal(1,"Held Verify verdict changed");
      held_done=done_valid_o && !done_ready_i;done_snapshot={done_id_o,done_code_o,done_detail_o,done_accept_o,done_digest_o};
      if(held_raw && (!response.raw_output_valid || raw_snapshot!=={response.raw_output_core,response.raw_output_id,response.raw_output_bytes,response.raw_output_data}))$fatal(1,"Held Verify digest changed");
      held_raw=response.raw_output_valid && !actual.raw_output_ready;raw_snapshot={response.raw_output_core,response.raw_output_id,response.raw_output_bytes,response.raw_output_data};
      if(command_valid_i && command_ready_o)begin $fdisplay(fd,"C %0d %0d %0d %0d %016h %0d %0d",case_no,command_id_i,context_id_i,context_param_i,context_regions_i,context_t1hat_i[0],context_t1hat_i[1]);commands++;end
      if(context_take_valid_o && context_take_ready_i)begin $fdisplay(fd,"T %0d %016h",case_no,sregions);adoptions++;end
      if(owner==2 && actual.job_valid && response.job_ready)begin $fdisplay(fd,"J %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,dut.row_r,dut.column_r,response.job_core,actual.job_id,actual.job_mode,actual.job_param,{actual.job_bank,actual.job_region},actual.message_len);sample_index=0;end
      if(owner==2 && actual.input_valid && response.input_ready)begin $fdisplay(fd,"S %0d %0d %0d %0d %016h",case_no,dut.row_r,dut.column_r,sample_index,actual.input_data);sample_index++;end
      if(owner==2 && actual.status_ready && response.status_valid)$fdisplay(fd,"H %0d %0d %0d %0d",case_no,service_i.status_core,service_i.status_id,service_i.status_code);
      if(owner==2 && actual.op_valid && response.op_ready)begin $fdisplay(fd,"N %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,dut.row_r,dut.state==13?2:int'(dut.challenge_product_r),dut.column_r,actual.op,actual.op_a_region,actual.op_b_region,actual.op_a_id,actual.op_b_id,actual.op_dest_region,actual.op_id);ntts++;end
      if(owner==2 && actual.op_done_ready && response.op_done_valid)$fdisplay(fd,"O %0d %0d %0d %0d",case_no,service_i.op_done_id,service_i.op_done_code,service_i.op_done_region);
      if(owner==2 && actual.process_valid && response.process_ready)begin $fdisplay(fd,"P %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,dut.row_r,dut.challenge_product_r,actual.process_op,actual.process_a,actual.process_b,actual.process_dest,actual.process_id,actual.process_a_id,actual.process_b_id,actual.process_inplace);processes++;end
      if(owner==2 && actual.process_done_ready && response.process_done_valid)$fdisplay(fd,"B %0d %0d %0d %0d",case_no,service_i.process_done_id,service_i.process_done_code,service_i.process_done_dest);
      if(owner==2 && actual.pack.command_valid && response.pack.command_ready)$fdisplay(fd,"PC %0d %0d %0d %0d %0d",case_no,dut.row_r,actual.pack.command_id,actual.pack.command_op,actual.pack.command_param);
      if(owner==2 && actual.pack.input_valid && response.pack.input_ready)begin $fdisplay(fd,"V %0d %0d %0d %06h %0d %0d",case_no,dut.row_r,actual.pack.input_index,actual.pack.input_data,actual.pack.input_last,dut.state==26);pack_inputs++;end
      if(owner==2 && actual.pack.output_ready && response.pack.output_valid)begin $fdisplay(fd,"E %0d %0d %0d %0d %0d %0d %016h",case_no,dut.row_r,service_i.pack.output_id,service_i.pack.output_index,service_i.pack.output_bytes,service_i.pack.output_last,service_i.pack.output_data);pack_outputs++;end
      if(owner==2 && actual.pack.done_ready && response.pack.done_valid)$fdisplay(fd,"PD %0d %0d %0d %0d %0d %0d",case_no,dut.row_r,service_i.pack.done_id,service_i.pack.done_code,dut.sent_r,dut.pack_words_r);
      if(dut.fpayload && dut.fpr)$fdisplay(fd,"L %0d %0d %0d %0d %016h",case_no,dut.body_words_r,dut.state==26?0:service_i.pack.output_bytes,dut.state!=26 && dut.row_r==dut.k_r-1 && service_i.pack.output_last,dut.state==26?64'd0:service_i.pack.output_data);
      if(owner==2 && actual.raw_valid && response.raw_ready)begin $fdisplay(fd,"Q %0d %0d %0d %0d %0d %0d",case_no,response.raw_core,actual.raw_id,actual.raw_mode,actual.raw_message_len,actual.raw_output_len);raw_index=0;end
      if(owner==2 && actual.raw_input_valid && response.raw_input_ready)begin $fdisplay(fd,"I %0d %0d %016h",case_no,raw_index,actual.raw_input_data);raw_index++;raw_words++;end
      if(owner==2 && actual.raw_output_ready && response.raw_output_valid)begin $fdisplay(fd,"D0 %0d %0d %0d %0d %032h",case_no,service_i.raw_output_core,service_i.raw_output_id,service_i.raw_output_bytes,service_i.raw_output_data);raw_beats++;end
      if(owner==2 && actual.raw_done_ready && response.raw_done_valid)$fdisplay(fd,"G %0d %0d %0d",case_no,service_i.raw_done_core,service_i.raw_done_id);
      if(dut.fd && dut.fack)$fdisplay(fd,"FMT %0d %0d %0d",case_no,dut.fdid,dut.fcode);
      if(owner==2 && actual.response_ready && response.response_valid)begin $fdisplay(fd,"R %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,dut.state==20?0:dut.state==22?1:2,dut.row_r,service_i.response_word,{service_i.response_bank,service_i.response_region},service_i.response_id,service_i.response_mode,service_i.response_param,service_i.response_ntt_domain,service_i.response_error,service_i.response_data);reads++;end
      if(physical.datapath.subsystem.store.alloc_fire)begin $fdisplay(fd,"A %0d %0d %0d %0d %0d %0d %0d %0d",case_no,physical.datapath.subsystem.store.alloc_region,physical.datapath.subsystem.store.alloc_rewrite_i,physical.datapath.subsystem.store.alloc_compute_i,physical.datapath.subsystem.store.alloc_ntt_domain_i,physical.datapath.subsystem.store.alloc_mode_i,physical.datapath.subsystem.store.alloc_param_i,physical.datapath.subsystem.store.alloc_id_i);allocs++;end
      if(physical.datapath.subsystem.store.write_fire)begin $fdisplay(fd,"W %0d %0d %0d %0d %06h %0d",case_no,physical.datapath.subsystem.store.write_region,physical.datapath.subsystem.store.write_id_i,physical.datapath.subsystem.store.write_index_i,physical.datapath.subsystem.store.write_data_i,physical.datapath.subsystem.store.write_last_i);writes++;end
      if(physical.datapath.subsystem.store.finish_fire)begin $fdisplay(fd,"M %0d %0d %0d %0d",case_no,physical.datapath.subsystem.store.finish_region,physical.datapath.subsystem.store.finish_code_i,physical.datapath.subsystem.store.writer_count_r[physical.datapath.subsystem.store.finish_core_i]);finishes++;end
      if(physical.datapath.subsystem.store.release_fire)begin $fdisplay(fd,"F %0d %0d",case_no,physical.datapath.subsystem.store.release_region);releases++;end
    end
  end
  task automatic reset_all();
    release dut.formatter.done_id_o;release physical.datapath.subsystem.store.fault_o;
    rst=1;monitor=0;owner=0;external_request='0;command_valid_i=0;done_ready_i=0;sclear=0;change_source=0;inject_raw=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || sbusy || fault_o || sfault || response.reserved || response.active || !command_ready_o)$fatal(1,"Equation reset");
  endtask
  task automatic create_sentinel(input string seed);
    int parsed;byte unsigned b;owner=0;external_request='0;external_request.job_valid=1;external_request.job_mode=2;external_request.job_id=62000;
    {external_request.job_bank,external_request.job_region}=6'(sentinel);external_request.message_len=66;
    do @(posedge clk);while(!response.job_ready);@(negedge clk);#1;external_request.job_valid=0;
    for(int w=0;w<9;w++)begin external_request.input_data=0;
      for(int j=0;j<8;j++)if(8*w+j<66)begin parsed=$sscanf(seed.substr(2*(8*w+j),2*(8*w+j)+1),"%h",b);external_request.input_data[8*j+:8]=b;end
      external_request.input_valid=1;do @(posedge clk);while(!response.input_ready);@(negedge clk);#1;external_request.input_valid=0;
    end
    while(!response.status_valid)begin @(negedge clk);#1;end
    if(response.status_code!=0)$fatal(1,"Equation sentinel");external_request.status_ready=1;@(posedge clk);@(negedge clk);#1;external_request='0;
    while(response.active)begin @(negedge clk);#1;end
  endtask
  task automatic read_sentinel(input int w);
    owner=0;external_request='0;external_request.read_valid=1;{external_request.read_bank,external_request.read_region}=6'(sentinel);external_request.read_word=6'(w);
    do @(posedge clk);while(!response.read_ready);@(negedge clk);#1;external_request.read_valid=0;
    while(!response.response_valid)begin @(negedge clk);#1;end
    $fdisplay(fd,"X %0d %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,sentinel,w,response.response_id,response.response_mode,response.response_param,response.response_ntt_domain,response.response_small,response.response_error,response.response_data);reads++;
    external_request.response_ready=1;@(posedge clk);@(negedge clk);#1;external_request='0;
  endtask
  initial begin
    int f,unit_p,unit_a,unit_h,unit_error,unit_high,k,l;bit hit;string directory,token,seed,pk,sig,body;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_verify_equation_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d %d %s",token,count,unit_count,seed)!=4)$fatal(1,"Prepare equation inputs");
    fd=$fopen({directory,"/stage5_verify_equation_outputs.txt"},"w");$fdisplay(fd,"V %s",token);reset_all();
    for(int u=0;u<unit_count;u++)begin
      if($fscanf(f,"%d %d %d %d %d",unit_p,unit_a,unit_h,unit_error,unit_high)!=5)$fatal(1,"UseHint fixture");
      up=2'(unit_p);ua=23'(unit_a);uh=23'(unit_h);#10;
      if(uerror!=unit_error || uhigh!=unit_high)$fatal(1,"UseHint unit%0d",u);
      $fdisplay(fd,"U %0d %0d %0d %0d %0d %0d",u,unit_p,unit_a,unit_h,uerror,uhigh);
    end
    @(negedge clk);#1;
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %d %d %d %d %s %s %s",case_no,p,jid,base,scenario,abort_phase,expected_code,expected_detail,ctxlen,mlen,pk,sig,body)!=13 || case_no!=c)$fatal(1,"Equation fixture");
      k=p==0?4:p==1?6:8;l=p==0?4:p==1?5:7;sentinel=base+2*k+l<=63?63:0;
      create_sentinel(seed);owner=1;setup.prepare(p,jid,base,ctxlen,mlen,pk,sig,body);elapsed=0;monitor=1;change_source=0;inject_raw=0;
      $fdisplay(fd,"INIT %0d %0d %0d %0d %0d %016h %064h %0128h %0128h",case_no,p,jid,base,sentinel,sregions,srho,smu,sctilde);
      for(int j=0;j<k;j++)begin $fdisplay(fd,"K %0d 0 %0d %0d",case_no,j,st1[j]);$fdisplay(fd,"K %0d 2 %0d %0d",case_no,j,shints[j]);end
      for(int j=0;j<l;j++)$fdisplay(fd,"K %0d 1 %0d %0d",case_no,j,sz[j]);$fdisplay(fd,"K %0d 3 0 %0d",case_no,schat);
      if(scenario==3)begin owner=0;external_request.read_valid=1;{external_request.read_bank,external_request.read_region}=6'(sentinel);external_request.read_word=0;
        do @(posedge clk);while(!response.read_ready);@(negedge clk);#1;external_request.read_valid=0;while(!response.response_valid)begin @(negedge clk);#1;end end
      owner=2;command_id_i=16'(jid);command_valid_i=1;do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;command_id_i=~16'(jid);
      hit=0;
      if(abort_phase)begin
        while(!hit)begin @(negedge clk);#1;
          case(abort_phase)
            1:hit=dut.state==3 && context_take_valid_o;
            2:hit=dut.state==5 && sample_index==2;
            3:hit=dut.state==5 && physical.datapath.subsystem.store.write_fire && physical.datapath.subsystem.store.write_index_i==17;
            4:hit=dut.state==7 && physical.datapath.subsystem.store.write_fire && physical.datapath.subsystem.store.write_index_i==17;
            5:hit=dut.state==10 && physical.datapath.subsystem.store.write_fire && physical.datapath.subsystem.store.write_index_i==17;
            6:hit=dut.state==23 && dut.sent_r==17;
            7:hit=response.raw_output_valid && !actual.raw_output_ready;
            8:hit=dut.state==27 && physical.datapath.subsystem.store.release_fire;
            9:if(response.raw_output_valid)begin inject_raw=1;repeat(3)@(negedge clk);#1;hit=fault_o;end
            10:if(dut.state==7 && physical.datapath.subsystem.store.write_fire)begin force physical.datapath.subsystem.store.fault_o=1'b1;repeat(3)@(negedge clk);#1;hit=fault_o;end
          endcase
          if(done_valid_o)$fatal(1,"Missed equation reset");
        end
        if(abort_phase==7)repeat(8)@(negedge clk);#1;
        $fdisplay(fd,"Z %0d %0d %0d %0d %016h %016h",case_no,abort_phase,dut.state,fault_o,response.reserved,response.complete);aborts++;reset_all();continue;
      end
      while(!done_valid_o)begin @(negedge clk);#1;
        if(scenario==16 && dut.state==3)change_source=1;
        if(scenario==15 && dut.fd)force dut.formatter.done_id_o=16'hf00d;
      end
      repeat(7)@(negedge clk);#1;release dut.formatter.done_id_o;
      if(done_code_o!=expected_code || done_detail_o!=expected_detail || done_id_o!=jid)$fatal(1,"Equation status case%0d got%0d/%0d expected%0d/%0d",case_no,done_code_o,done_detail_o,expected_code,expected_detail);
      $fdisplay(fd,"D %0d %0d %0d %0d %0d %0128h %016h %016h %0d",case_no,done_id_o,done_code_o,done_detail_o,done_accept_o,done_digest_o,response.reserved,response.complete,response.active);dones++;
      if(done_code_o==0 && (sbusy || response.reserved!=(64'd1<<sentinel)))$fatal(1,"Verdict before owner cleanup");
      done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
      if(scenario==3)begin owner=0;$fdisplay(fd,"X %0d %0d 0 %0d %0d %0d %0d %0d %0d %023h",case_no,sentinel,response.response_id,response.response_mode,response.response_param,response.response_ntt_domain,response.response_small,response.response_error,response.response_data);reads++;
        external_request.response_ready=1;@(posedge clk);@(negedge clk);#1;external_request='0;end
      if(svalid)begin owner=1;sclear=1;do @(posedge clk);while(!scr);$fdisplay(fd,"PREP_CLEAR %0d %016h",case_no,sregions);@(negedge clk);#1;sclear=0;
        while(sbusy)begin @(negedge clk);#1;end end
      for(int w=0;w<64;w++)read_sentinel(w);$fdisplay(fd,"EXTERNAL_RELEASE %0d %0d",case_no,sentinel);
      external_request.release_valid=1;{external_request.release_bank,external_request.release_region}=6'(sentinel);
      do @(posedge clk);while(!response.release_ready);@(negedge clk);#1;external_request='0;
      if(response.reserved || response.active || busy_o || sbusy)$fatal(1,"Equation final ownership");
      $fdisplay(fd,"ENDCASE %0d 0",case_no);monitor=0;
    end
    $fdisplay(fd,"END %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",unit_count,commands,adoptions,dones,aborts,allocs,writes,finishes,releases,reads,ntts,processes,pack_inputs,pack_outputs,raw_words,raw_beats);
    $fclose(f);$fclose(fd);$display("STAGE5V3_VERIFY_EQUATION_CAPTURE_PASS:%0d commands/%0d writes/%0d NTTs",commands,writes,ntts);test_passed=1;$finish;
  end
  initial begin #(64'd1800000000000);$fatal(1,"Verify equation global watchdog case%0d",case_no);end
endmodule
