`timescale 1ps/1ps
// Test-only real PK/SIG/message preparation chain;no golden values enter RTL.
module verify_setup (
  input logic clk,rst,clear_i,take_i,output logic clear_ready_o,take_ready_o,busy_o,fault_o,
  output logic valid_o,output logic [1:0] param_o,output logic [15:0] id_o,output logic [63:0] regions_o,
  output logic [7:0][5:0] t1hat_o,hints_o,output logic [6:0][5:0] zhat_o,output logic [5:0] chat_o,
  output logic [255:0] rho_o,output logic [511:0] mu_o,ctilde_o,
  output dilithium_service_pkg::request_t request_o,input dilithium_service_pkg::response_t response_i
);
  import dilithium_service_pkg::*;
  logic owner=0,pv=0,pr,pbusy,pfault,pi=0,pir,plast=0,pdone,pdr=0,ptake,ptr,pcvalid;
  logic [1:0] pp=0,pcp;logic [15:0] pid=0,pslen=0,pindex=0,pcid;logic [5:0] pbase=0;logic [63:0] pdata=0,pregions;
  logic [3:0] pbytes=8;logic [2:0] pcode,pdetail;logic [15:0] pdid;
  logic [7:0][5:0] pt1,phints;logic [6:0][5:0] pz;logic [255:0] prho;logic [511:0] ptrhash,pctilde;
  logic mv=0,mr,mbusy,mfault,mi=0,mir,mlast=0,mdone,mdr=0;logic [15:0] mid=0,mlen=0,mindex=0,mdid;logic [8:0] mctx=0;
  logic [63:0] mdata=0;logic [3:0] mbytes=8;logic [2:0] mcode,mdetail;request_t preq,mreq;
  assign request_o=owner?mreq:preq;assign busy_o=pbusy || mbusy;assign fault_o=pfault || mfault;
  verify_input_prepare prep(.clk(clk),.rst(rst),.command_valid_i(pv),.command_ready_o(pr),.busy_o(pbusy),.fault_o(pfault),
    .command_param_i(pp),.command_id_i(pid),.command_signature_len_i(pslen),.command_base_i(pbase),
    .input_valid_i(pi),.input_ready_o(pir),.input_data_i(pdata),.input_bytes_i(pbytes),.input_index_i(pindex),.input_last_i(plast),
    .done_valid_o(pdone),.done_ready_i(pdr),.done_code_o(pcode),.done_detail_o(pdetail),.done_id_o(pdid),
    .context_valid_o(pcvalid),.context_param_o(pcp),.context_id_o(pcid),.context_regions_o(pregions),.context_t1_o(pt1),.context_hints_o(phints),.context_z_o(pz),
    .context_rho_o(prho),.context_tr_o(ptrhash),.context_ctilde_o(pctilde),.clear_valid_i(1'b0),.clear_ready_o(),.take_valid_i(ptake),.take_ready_o(ptr),
    .service_o(preq),.service_i(response_i));
  verify_math_prepare math(.clk(clk),.rst(rst),.command_valid_i(mv),.command_ready_o(mr),.busy_o(mbusy),.fault_o(mfault),
    .command_id_i(mid),.command_message_len_i(mlen),.command_context_len_i(mctx),
    .context_valid_i(pcvalid),.context_param_i(pcp),.context_id_i(pcid),.context_regions_i(pregions),.context_t1_i(pt1),.context_hints_i(phints),.context_z_i(pz),
    .context_rho_i(prho),.context_tr_i(ptrhash),.context_ctilde_i(pctilde),.context_take_valid_o(ptake),.context_take_ready_i(ptr),
    .payload_valid_i(mi),.payload_ready_o(mir),.payload_data_i(mdata),.payload_bytes_i(mbytes),.payload_index_i(mindex),.payload_last_i(mlast),
    .done_valid_o(mdone),.done_ready_i(mdr),.done_code_o(mcode),.done_detail_o(mdetail),.done_id_o(mdid),
    .result_valid_o(valid_o),.result_param_o(param_o),.result_id_o(id_o),.result_regions_o(regions_o),.result_t1hat_o(t1hat_o),.result_hints_o(hints_o),
    .result_zhat_o(zhat_o),.result_chat_o(chat_o),.result_rho_o(rho_o),.result_mu_o(mu_o),.result_ctilde_o(ctilde_o),
    .clear_valid_i(clear_i),.clear_ready_o(clear_ready_o),.take_valid_i(take_i),.take_ready_o(take_ready_o),.service_o(mreq),.service_i(response_i));
  task automatic send_frame(input string data,input bit message_frame);
    int n,size,parsed;byte unsigned b;n=data=="-"?0:data.len()/2;
    for(int w=0;w<(n+7)/8;w++)begin
      size=n-8*w>=8?8:n-8*w;
      if(message_frame)begin
        mdata='1;mbytes=4'(size);mindex=16'(w);mlast=8*(w+1)>=n;
        for(int j=0;j<size;j++)begin parsed=$sscanf(data.substr(2*(8*w+j),2*(8*w+j)+1),"%h",b);mdata[8*j+:8]=b;end
        mi=1;do @(posedge clk);while(!mir);@(negedge clk);#1;mi=0;
      end else begin
        pdata='1;pbytes=4'(size);pindex=16'(w);plast=8*(w+1)>=n;
        for(int j=0;j<size;j++)begin parsed=$sscanf(data.substr(2*(8*w+j),2*(8*w+j)+1),"%h",b);pdata[8*j+:8]=b;end
        pi=1;do @(posedge clk);while(!pir);@(negedge clk);#1;pi=0;
      end
    end
  endtask
  task automatic prepare(input int p,jid,base,ctxlen,msglen,input string pk,sig,body);
    owner=0;pp=2'(p);pid=16'(jid);pslen=16'(sig.len()/2);pbase=6'(base);pv=1;
    do @(posedge clk);while(!pr);@(negedge clk);#1;pv=0;send_frame(pk,0);send_frame(sig,0);
    while(!pdone)begin @(negedge clk);#1;end
    if(pcode!=0 || !pcvalid)$fatal(1,"Verify equation source decoding");pdr=1;@(posedge clk);@(negedge clk);#1;pdr=0;
    owner=1;mid=16'(jid);mlen=16'(msglen);mctx=9'(ctxlen);mv=1;
    do @(posedge clk);while(!mr);@(negedge clk);#1;mv=0;send_frame(body,1);
    while(!mdone)begin @(negedge clk);#1;end
    if(mcode!=0 || !valid_o)$fatal(1,"Verify equation source math");mdr=1;@(posedge clk);@(negedge clk);#1;mdr=0;
  endtask
endmodule
