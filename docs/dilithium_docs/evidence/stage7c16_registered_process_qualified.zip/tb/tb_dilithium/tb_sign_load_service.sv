`timescale 1ps/1ps
// The actual production service tree:one Keccak pair,sampler,NTT and memory.
// All writes/reads use public interfaces;hierarchy is observation only.
module tb_sign_load_service;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  request_t request_i='0;response_t response_o;
  dilithium_services dut(.*);
  int cycles=0,case_no=-1,p,jid,base,sentinel,fault_word,fault,abort_phase,length,count,fd;
  int completions=0,errors=0,aborts=0,values=0,reads=0,word_count=0;
  int witnesses[6],blocks[10];bit monitor=0,test_passed=0,abort_request=0;
  wire loading=response_o.load.busy;
  wire [63:0] private_plan=dut.datapath.subsystem.l_hidden;
  logic held=0;sign_load_response_t previous_load;
  always @(posedge clk)begin
    cycles++;
    if(rst)held=0;
    else begin
      if(response_o.fault)$fatal(1,"Load service fault case%0d",case_no);
      if(held && (!response_o.load.done_valid || response_o.load!==previous_load))$fatal(1,"Held key result changed");
      held=response_o.load.done_valid && !request_i.load.done_ready;previous_load=response_o.load;
      if(monitor)begin
        if(request_i.load.valid && response_o.load.ready)begin
          if(response_o.release_ready || response_o.read_ready)$fatal(1,"Key acceptance failed read/release priority");blocks[8]++;
          $fdisplay(fd,"C %0d %0d %0d %0d %0d",case_no,p,jid,base,sentinel);
        end
        if(request_i.load.input_valid && response_o.load.input_ready)begin
          $fdisplay(fd,"W %0d %0d %0d %0d %016h",case_no,request_i.load.input_index,request_i.load.input_bytes,request_i.load.input_last,request_i.load.input_data);word_count++;
        end
        if(loading)begin
          if(response_o.job_ready || response_o.op_ready || response_o.process_ready || response_o.sign.ready || response_o.row_ready || response_o.raw_ready || response_o.read_ready || response_o.response_valid || response_o.release_ready || response_o.load.ready)
            $fatal(1,"Key load lost exclusive ownership case%0d",case_no);
          blocks[9]++;
          if((response_o.complete & private_plan)!=0)$fatal(1,"Partial key exposed by shared wrapper");
          if(!response_o.load.done_valid && (response_o.load.rho || response_o.load.key || response_o.load.tr || response_o.load.done_regions))$fatal(1,"Partial key header exposed");
          if(response_o.load.done_valid && response_o.load.done_code!=0 && (response_o.load.rho || response_o.load.key || response_o.load.tr || response_o.load.done_regions))$fatal(1,"Invalid key header exposed");
          if(dut.datapath.subsystem.l_write && !dut.datapath.subsystem.result_ready)witnesses[0]++;
          if(dut.datapath.subsystem.l_finish && !dut.datapath.subsystem.finish_ready)witnesses[1]++;
          if(dut.datapath.subsystem.l_alloc && !dut.datapath.subsystem.alloc_ready)witnesses[2]++;
          if((dut.datapath.subsystem.store_complete & private_plan)!=0)witnesses[3]++;
          if(dut.datapath.subsystem.l_release && !dut.datapath.subsystem.mem_release_ready)witnesses[4]++;
          if(request_i.release_valid)witnesses[5]++;
          if(dut.datapath.subsystem.store.alloc_fire)$fdisplay(fd,"L %0d %0d %0d %0d %0d",case_no,{dut.datapath.subsystem.store.alloc_bank_i,dut.datapath.subsystem.store.alloc_region_i},dut.datapath.subsystem.store.alloc_id_i,dut.datapath.subsystem.store.alloc_mode_i,dut.datapath.subsystem.store.alloc_param_i);
          if(dut.datapath.subsystem.store.write_fire)begin
            $fdisplay(fd,"X %0d %0d %0d %06h %0d",case_no,dut.datapath.subsystem.store.write_region,dut.datapath.subsystem.store.write_index_i,dut.datapath.subsystem.store.write_data_i,dut.datapath.subsystem.store.write_last_i);values++;
          end
          if(dut.datapath.subsystem.store.finish_fire)begin
            $fdisplay(fd,"U %0d %0d %0d",case_no,dut.datapath.subsystem.store.finish_region,dut.datapath.subsystem.store.finish_code_i);
            if(abort_phase==2 && dut.datapath.subsystem.store.finish_code_i==0)abort_request=1;
          end
          if(dut.datapath.subsystem.store.release_fire)$fdisplay(fd,"Z %0d %0d",case_no,dut.datapath.subsystem.store.release_region);
          for(int b=0;b<4;b++)begin
            if(dut.datapath.subsystem.store.request_valid[0][b] && dut.datapath.subsystem.store.request_ready[0][b])
              $fdisplay(fd,"P %0d %0d %0d %023h",case_no,16*b+int'(dut.datapath.subsystem.store.request_address[0][b][9:6]),dut.datapath.subsystem.store.request_address[0][b][5:0],dut.datapath.subsystem.store.request_data[0][b]);
            if(dut.datapath.subsystem.store.response_valid[0][b] && dut.datapath.subsystem.store.response_ready[0][b])
              $fdisplay(fd,"K %0d %0d %0d",case_no,16*b+int'(dut.datapath.subsystem.store.response_address[0][b][9:6]),dut.datapath.subsystem.store.response_address[0][b][5:0]);
          end
        end
      end
    end
  end
  always @(negedge clk)if(monitor && !rst && loading)begin
    if(abort_phase==3 && dut.datapath.subsystem.l_write)abort_request=1;
    if(abort_phase==4 && dut.datapath.subsystem.l_write && dut.datapath.subsystem.key_loader.decoder.output_last_key_o)abort_request=1;
  end
  task automatic reset_all();
    #1;rst=1;request_i='0;repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(response_o.reserved || response_o.complete || response_o.load.busy || response_o.load.done_valid || response_o.fault || response_o.load.key || response_o.load.tr || response_o.load.rho)$fatal(1,"Shared key reset retained state");
  endtask
  task automatic block_probe(input int kind);
    repeat(6)begin @(negedge clk);#1;if(response_o.load.ready)$fatal(1,"Key stole owner kind%0d",kind);blocks[kind]++;end
  endtask
  task automatic seed_sentinel(input bit blocking);
    @(negedge clk);#1;request_i.job_valid=1;{request_i.job_bank,request_i.job_region}=6'(sentinel);
    request_i.job_mode=2;request_i.job_param=0;request_i.job_id=60000;request_i.message_len=66;
    do @(posedge clk);while(!response_o.job_ready);@(negedge clk);#1;request_i.job_valid=0;
    if(blocking)request_i.load.valid=1;
    for(int w=0;w<9;w++)begin
      request_i.input_data='1;
      for(int b=0;b<8 && 8*w+b<66;b++)request_i.input_data[8*b+:8]=8'(case_no+8*w+b);
      request_i.input_valid=1;do @(posedge clk);while(!response_o.input_ready);@(negedge clk);#1;request_i.input_valid=0;
    end
    while(!response_o.status_valid)begin @(negedge clk);#1;end
    if(blocking)block_probe(0);
    request_i.load.valid=0;request_i.status_ready=1;@(posedge clk);@(negedge clk);#1;request_i.status_ready=0;
    if(response_o.active || !response_o.complete[sentinel])$fatal(1,"Sentinel sampling did not retire");
  endtask
  task automatic blockers();
    // A raw result and its held retirement both retain physical-core ownership.
    request_i.raw_valid=1;request_i.raw_mode=1;request_i.raw_id=61000;request_i.raw_message_len=0;request_i.raw_output_len=17;
    do @(posedge clk);while(!response_o.raw_ready);
    $fdisplay(fd,"G %0d %0d",case_no,response_o.raw_core);
    @(negedge clk);#1;request_i.raw_valid=0;request_i.load.valid=1;
    while(!response_o.raw_output_valid)begin @(negedge clk);#1;end
    block_probe(1);
    for(int beat=0;beat<2;beat++)begin
      while(!response_o.raw_output_valid)begin @(negedge clk);#1;end
      $fdisplay(fd,"J %0d %0d %0d %0d %032h",case_no,response_o.raw_output_core,response_o.raw_output_id,response_o.raw_output_bytes,response_o.raw_output_data);
      request_i.raw_output_ready=1;@(posedge clk);@(negedge clk);#1;request_i.raw_output_ready=0;
    end
    while(!response_o.raw_done_valid)begin @(negedge clk);#1;end
    block_probe(2);$fdisplay(fd,"E %0d %0d %0d",case_no,response_o.raw_done_core,response_o.raw_done_id);
    request_i.load.valid=0;request_i.raw_done_ready=1;@(posedge clk);@(negedge clk);#1;request_i.raw_done_ready=0;
    // Establish a public read BEFORE the waiting key descriptor.
    request_i.read_valid=1;{request_i.read_bank,request_i.read_region}=6'(sentinel);request_i.read_word=0;
    do @(posedge clk);while(!response_o.read_ready);@(negedge clk);#1;request_i.read_valid=0;request_i.load.valid=1;
    block_probe(3);request_i.row_valid=1;request_i.row_param=3;
    while(!response_o.response_valid)begin @(negedge clk);#1;end
    $fdisplay(fd,"I %0d %0d %0d %023h",case_no,response_o.response_id,{response_o.response_bank,response_o.response_region},response_o.response_data);
    request_i.response_ready=1;@(posedge clk);@(negedge clk);#1;request_i.response_ready=0;
    do @(posedge clk);while(!response_o.row_ready);@(negedge clk);#1;request_i.row_valid=0;
    block_probe(4);if(!response_o.row_done_valid || response_o.row_done_code!=4)$fatal(1,"Row priority status");
    request_i.op_valid=1;request_i.op_a_region=0;request_i.op_dest_region=0;
    request_i.row_done_ready=1;@(posedge clk);@(negedge clk);#1;request_i.row_done_ready=0;
    do @(posedge clk);while(!response_o.op_ready);@(negedge clk);#1;request_i.op_valid=0;
    block_probe(5);if(!response_o.op_done_valid || response_o.op_done_code!=3)$fatal(1,"NTT priority status");
    request_i.process_valid=1;request_i.process_op=3;request_i.op_done_ready=1;
    @(posedge clk);@(negedge clk);#1;request_i.op_done_ready=0;
    do @(posedge clk);while(!response_o.process_ready);@(negedge clk);#1;request_i.process_valid=0;
    block_probe(6);if(!response_o.process_done_valid || response_o.process_done_code!=4)$fatal(1,"Scalar priority status");
    request_i.sign.valid=1;request_i.sign.op=3;request_i.process_done_ready=1;
    @(posedge clk);@(negedge clk);#1;request_i.process_done_ready=0;
    do @(posedge clk);while(!response_o.sign.ready);@(negedge clk);#1;request_i.sign.valid=0;
    block_probe(7);if(!response_o.sign.done_valid || response_o.sign.done_code!=4)$fatal(1,"Sign process priority status");
    request_i.sign.done_ready=1;@(posedge clk);@(negedge clk);#1;request_i.sign.done_ready=0;
  endtask
  task automatic competitors(input bit enabled);
    // Isolate request classes during loading so row priority cannot mask a
    // broken inner arbiter. All classes are asserted together at held done.
    request_i.job_valid=enabled && case_no%7==0;request_i.raw_valid=enabled && case_no%7==1;
    request_i.op_valid=enabled && case_no%7==2;request_i.process_valid=enabled && case_no%7==3;
    request_i.sign.valid=enabled && case_no%7==4;request_i.row_valid=enabled && case_no%7==5;
    request_i.read_valid=enabled;request_i.release_valid=enabled;
    {request_i.read_bank,request_i.read_region}=6'(base);
    {request_i.release_bank,request_i.release_region}=6'(base);
  endtask
  task automatic handoff();
    // A real compute owner consumes the decoded key after load retirement.
    // CNB is read-only;small s1 coefficients cannot violate the z bound.
    request_i.sign.valid=1;request_i.sign.op=1;request_i.sign.param=2'(p);request_i.sign.kind=0;
    request_i.sign.a=6'(base);request_i.sign.a_id=16'(jid);request_i.sign.id=60001;
    do @(posedge clk);while(!response_o.sign.ready);
    $fdisplay(fd,"Y %0d %0d %0d %0d",case_no,base,jid,p);
    @(negedge clk);#1;request_i.sign.valid=0;
    while(!response_o.sign.done_valid)begin @(negedge clk);#1;end
    if(response_o.sign.done_code || response_o.sign.done_reject || response_o.sign.done_weight || response_o.sign.done_id!=60001)$fatal(1,"Key-to-process handoff failed");
    $fdisplay(fd,"O %0d %0d %0d %0d %0d",case_no,response_o.sign.done_code,response_o.sign.done_id,response_o.sign.done_reject,response_o.sign.done_weight);
    request_i.sign.done_ready=1;@(posedge clk);@(negedge clk);#1;request_i.sign.done_ready=0;
  endtask
  task automatic read_region(input int regno,input bit key_data);
    for(int w=0;w<64;w++)begin
      request_i.read_valid=1;{request_i.read_bank,request_i.read_region}=6'(regno);request_i.read_word=6'(w);
      do @(posedge clk);while(!response_o.read_ready);@(negedge clk);#1;request_i.read_valid=0;
      while(!response_o.response_valid)begin @(negedge clk);#1;end
      if(response_o.response_error || {response_o.response_bank,response_o.response_region}!=regno || response_o.response_word!=w)$fatal(1,"Shared key read tags");
      $fdisplay(fd,"%s %0d %0d %0d %0d %0d %0d %0d %0d %023h",key_data?"V":"N",case_no,regno,w,response_o.response_id,response_o.response_mode,response_o.response_param,response_o.response_ntt_domain,response_o.response_small,response_o.response_data);
      if(key_data)reads++;
      repeat(w%3)@(negedge clk);#1;request_i.response_ready=1;@(posedge clk);@(negedge clk);#1;request_i.response_ready=0;
    end
  endtask
  task automatic free_region(input int regno);
    request_i.release_valid=1;{request_i.release_bank,request_i.release_region}=6'(regno);
    do @(posedge clk);while(!response_o.release_ready);@(negedge clk);#1;request_i.release_valid=0;
  endtask
  task automatic witness();
    $fdisplay(fd,"T %0d %0d %0d %0d %0d %0d %0d",case_no,witnesses[0],witnesses[1],witnesses[2],witnesses[3],witnesses[4],witnesses[5]);
    $fdisplay(fd,"B %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,blocks[0],blocks[1],blocks[2],blocks[3],blocks[4],blocks[5],blocks[6],blocks[7],blocks[8],blocks[9]);
  endtask
  initial begin
    int f,n;string directory,token,hexkey;byte unsigned octet;logic [63:0] result_mask;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_sign_load_inputs.txt"},"r");
    if(!f || $fscanf(f,"%s %d",token,count)!=2 || count!=138)$fatal(1,"Prepare service key fixtures");
    fd=$fopen({directory,"/stage5_sign_load_service_outputs.txt"},"w");$fdisplay(fd,"H %s",token);reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %d %d %d %s",case_no,p,jid,base,sentinel,fault_word,fault,abort_phase,length,hexkey)!=10 || case_no!=c || hexkey.len()!=2*length)$fatal(1,"Shared key fixture");
      foreach(witnesses[j])witnesses[j]=0;foreach(blocks[j])blocks[j]=0;
      abort_request=0;word_count=0;monitor=1;
      request_i.load.param=2'(p);request_i.load.id=16'(jid);request_i.load.base=6'(base);
      seed_sentinel(c==0 || c==25 || c==50);
      if(c==0 || c==25 || c==50)blockers();
      request_i.load.valid=1;request_i.read_valid=1;request_i.release_valid=1;
      {request_i.release_bank,request_i.release_region}=6'(sentinel);
      do @(posedge clk);while(!response_o.load.ready);@(negedge clk);#1;request_i.load.valid=0;competitors(1);
      for(int w=0;w<length/8;w++)begin
        if(response_o.load.done_valid || abort_request)break;
        request_i.load.input_data=0;
        for(int b=0;b<8;b++)begin
          n=$sscanf(hexkey.substr(2*(8*w+b),2*(8*w+b)+1),"%h",octet);if(n!=1)$fatal(1,"Shared key byte");request_i.load.input_data[8*b+:8]=octet;
        end
        request_i.load.input_index=10'(w ^ ((fault==1 && w==fault_word)?1:0));request_i.load.input_bytes=4'((fault>=10 && w==fault_word)?fault-10:8);
        request_i.load.input_last=(w==length/8-1) ^ (fault==2 && w==fault_word);request_i.load.input_valid=1;
        do @(posedge clk);while(!response_o.load.input_ready && !response_o.load.done_valid && !abort_request);
        @(negedge clk);#1;request_i.load.input_valid=0;
        if(abort_request)break;
        if(abort_phase==1 && word_count==3)begin abort_request=1;break;end
        if(w%19==0)begin repeat(2)@(negedge clk);#1;end
      end
      while(!response_o.load.done_valid && !abort_request)begin @(negedge clk);#1;end
      if(abort_phase!=0)begin
        if(abort_phase==5)repeat(7)begin @(negedge clk);#1;end
        $fdisplay(fd,"A %0d %0d",case_no,abort_phase);witness();aborts++;monitor=0;reset_all();continue;
      end
      request_i.job_valid=1;request_i.op_valid=1;request_i.process_valid=1;request_i.sign.valid=1;request_i.row_valid=1;request_i.raw_valid=1;
      repeat(7)begin @(negedge clk);#1;end
      $fdisplay(fd,"D %0d %0d %0d %016h %064h %064h %0128h",case_no,response_o.load.done_code,response_o.load.done_id,response_o.load.done_regions,response_o.load.rho,response_o.load.key,response_o.load.tr);
      result_mask=response_o.load.done_regions;completions++;if(response_o.load.done_code!=0)errors++;witness();
      // Keep row_valid asserted THROUGH retirement:done_ready must not be masked.
      request_i.load.done_ready=1;@(posedge clk);@(negedge clk);#1;request_i.load.done_ready=0;competitors(0);monitor=0;
      if(response_o.load.busy || response_o.reserved!=(result_mask | (64'd1<<sentinel)) || response_o.complete!=response_o.reserved)$fatal(1,"Shared key ownership/rollback handoff");
      read_region(sentinel,0);$fdisplay(fd,"S %0d %0d",case_no,sentinel);
      if(result_mask)handoff();
      for(int r=0;r<64;r++)if(result_mask[r])begin read_region(r,1);free_region(r);end
      free_region(sentinel);if(response_o.reserved)$fatal(1,"Shared key leaked region");
    end
    $fdisplay(fd,"F %0d %0d %0d %0d %0d %0d",count,completions,errors,aborts,values,reads);$fclose(f);$fclose(fd);
    $display("STAGE5N4C2_SIGN_LOAD_SERVICE_CAPTURE_PASS:%0d commands,%0d complete,%0d errors,%0d resets,%0d writes,%0d reads",count,completions,errors,aborts,values,reads);test_passed=1;$finish;
  end
  initial begin #(64'd40000000000);$fatal(1,"Shared key watchdog case%0d state%0d",case_no,dut.datapath.subsystem.key_loader.state);end
endmodule
