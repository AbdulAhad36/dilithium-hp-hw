`timescale 1ps/1ps
module tb_verify_prepare;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,fault_o;logic [1:0] command_param_i=0;
  logic [15:0] command_id_i=0,command_signature_len_i=0;logic [5:0] command_base_i=0;
  logic input_valid_i=0,input_ready_o,input_last_i=0;logic [63:0] input_data_i=0;logic [3:0] input_bytes_i=8;logic [15:0] input_index_i=0;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o,done_detail_o;logic [15:0] done_id_o;
  logic context_valid_o;logic [1:0] context_param_o;logic [15:0] context_id_o;logic [63:0] context_regions_o;
  logic [7:0][5:0] context_t1_o,context_hints_o;logic [6:0][5:0] context_z_o;
  logic [255:0] context_rho_o;logic [511:0] context_tr_o,context_ctilde_o;
  logic clear_valid_i=0,clear_ready_o,take_valid_i=0,take_ready_o;
  request_t service_o,external_request,actual_request;response_t service_i,physical_response;
  logic external_owner=1,monitor=0;int cycles=0,elapsed=0,case_no=-1,p,jid,base,scenario,abort_phase,adopt,declared,expected_code,expected_detail,sentinel,frame=0;
  int fd,count,commands=0,done_count=0,abort_count=0,inputs=0,allocs=0,writes=0,finishes=0,releases=0,reads=0,raw_words=0,raw_beats=0;
  int raw_index=0;bit test_passed=0;
  verify_input_prepare dut(.*);
  dilithium_services physical(.clk(clk),.rst(rst),.request_i(actual_request),.response_o(physical_response));
  always_comb begin
    actual_request=external_owner?external_request:service_o;service_i=physical_response;
    if(!external_owner)begin
      actual_request.load.input_valid=service_o.load.input_valid && cycles%13>2;
      service_i.load.input_ready=physical_response.load.input_ready && cycles%13>2;
      actual_request.raw_input_valid=service_o.raw_input_valid && cycles%11>3;
      service_i.raw_input_ready=physical_response.raw_input_ready && cycles%11>3;
      actual_request.raw_output_ready=service_o.raw_output_ready && cycles%17>5 && abort_phase!=9;
      service_i.raw_output_valid=physical_response.raw_output_valid && cycles%17>5 && abort_phase!=9;
      if(physical_response.load.busy)begin
        actual_request.read_valid=1;{actual_request.read_bank,actual_request.read_region}=6'(base);actual_request.read_word=0;
        actual_request.release_valid=1;{actual_request.release_bank,actual_request.release_region}=6'(base);
        actual_request.op_valid=1;actual_request.process_valid=1;actual_request.sign.valid=1;actual_request.row_valid=1;actual_request.job_valid=1;
      end
    end
  end
  logic held_input=0,held_raw=0,held_load=0,held_done=0;
  logic [84:0] input_snapshot;logic [149:0] raw_snapshot;logic [84:0] load_snapshot;logic [21:0] done_snapshot;
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held_input=0;held_raw=0;held_load=0;held_done=0;end
    else if(monitor)begin
      elapsed++;if(elapsed>200000)$fatal(1,"Verify prepare watchdog case%0d parent%0d loader%0d raw%0d words%0d",case_no,dut.state,physical.datapath.subsystem.verify_loader.state,physical_response.active,dut.raw_words_r);
      if(fault_o && abort_phase!=10 && abort_phase!=11)$fatal(1,"Unexpected Verify prepare fault case%0d",case_no);
      if(held_input && !done_valid_o && !fault_o && (!input_valid_i || input_snapshot!=={input_index_i,input_bytes_i,input_last_i,input_data_i}))$fatal(1,"Host changed held input");
      held_input=input_valid_i && !input_ready_o;input_snapshot={input_index_i,input_bytes_i,input_last_i,input_data_i};
      if(held_raw && !fault_o && abort_phase!=10 && (!physical_response.raw_output_valid || raw_snapshot!=={physical_response.raw_output_core,physical_response.raw_output_id,physical_response.raw_output_bytes,physical_response.raw_output_data}))$fatal(1,"Held raw output changed");
      held_raw=physical_response.raw_output_valid && !actual_request.raw_output_ready;raw_snapshot={physical_response.raw_output_core,physical_response.raw_output_id,physical_response.raw_output_bytes,physical_response.raw_output_data};
      if(held_load && !fault_o && !physical_response.load.done_valid && dut.state==3 && (!service_o.load.input_valid || load_snapshot!=={service_o.load.input_index_hi,service_o.load.input_index,service_o.load.input_bytes,service_o.load.input_last,service_o.load.input_data}))$fatal(1,"Held decoder fork changed");
      held_load=service_o.load.input_valid && !service_i.load.input_ready;load_snapshot={service_o.load.input_index_hi,service_o.load.input_index,service_o.load.input_bytes,service_o.load.input_last,service_o.load.input_data};
      if(held_done && (!done_valid_o || done_snapshot!=={done_id_o,done_code_o,done_detail_o}))$fatal(1,"Held completion changed");
      held_done=done_valid_o && !done_ready_i;done_snapshot={done_id_o,done_code_o,done_detail_o};
      if(!external_owner && physical_response.load.busy && (physical_response.read_ready || physical_response.release_ready || physical_response.op_ready || physical_response.process_ready || physical_response.sign.ready || physical_response.row_ready || physical_response.job_ready))$fatal(1,"Concurrent bank client admitted");
      if(!external_owner && service_o.load.valid && !service_o.load.kind && (physical_response.load.ready!==physical_response.raw_ready))$fatal(1,"Split PK admission");
      if(command_valid_i && command_ready_o)begin $fdisplay(fd,"C %0d %0d %0d %0d %0d",case_no,command_param_i,command_id_i,command_base_i,command_signature_len_i);commands++;end
      if(input_valid_i && input_ready_o)begin $fdisplay(fd,"I %0d %0d %0d %0d %0d %016h",case_no,frame,input_index_i,input_bytes_i,input_last_i,input_data_i);inputs++;end
      if(!external_owner && actual_request.raw_valid && physical_response.raw_ready)begin
        $fdisplay(fd,"Q %0d %0d %0d %0d %0d %0d",case_no,physical_response.raw_core,actual_request.raw_id,actual_request.raw_mode,actual_request.raw_message_len,actual_request.raw_output_len);raw_index=0;
      end
      if(!external_owner && actual_request.raw_input_valid && physical_response.raw_input_ready)begin $fdisplay(fd,"B %0d %0d %016h",case_no,raw_index,actual_request.raw_input_data);raw_index++;raw_words++;end
      if(!external_owner && actual_request.raw_output_ready && physical_response.raw_output_valid)begin $fdisplay(fd,"O %0d %0d %0d %0d %032h",case_no,physical_response.raw_output_core,physical_response.raw_output_id,physical_response.raw_output_bytes,physical_response.raw_output_data);raw_beats++;end
      if(!external_owner && actual_request.raw_done_ready && physical_response.raw_done_valid)$fdisplay(fd,"G %0d %0d %0d",case_no,physical_response.raw_done_core,physical_response.raw_done_id);
      if(!external_owner && service_o.load.done_ready && physical_response.load.done_valid)$fdisplay(fd,"L %0d %0d %0d %0d %016h %0d %0128h",case_no,service_o.load.kind,physical_response.load.done_id,physical_response.load.done_code,physical_response.load.done_regions,physical_response.load.header_bytes,physical_response.load.header);
      if(physical.datapath.subsystem.store.alloc_fire)begin
        $fdisplay(fd,"A %0d %0d %0d %0d %0d %0d %016h",case_no,physical.datapath.subsystem.store.alloc_region,physical.datapath.subsystem.store.alloc_rewrite_i,physical.datapath.subsystem.store.alloc_id_i,physical.datapath.subsystem.store.alloc_mode_i,physical.datapath.subsystem.store.alloc_param_i,physical.datapath.subsystem.store.reserved_o);allocs++;
      end
      if(physical.datapath.subsystem.store.write_fire)begin $fdisplay(fd,"W %0d %0d %0d %0d %06h %0d",case_no,physical.datapath.subsystem.store.write_region,physical.datapath.subsystem.store.write_id_i,physical.datapath.subsystem.store.write_index_i,physical.datapath.subsystem.store.write_data_i,physical.datapath.subsystem.store.write_last_i);writes++;end
      if(physical.datapath.subsystem.store.finish_fire)begin $fdisplay(fd,"M %0d %0d %0d %0d %0d",case_no,physical.datapath.subsystem.store.finish_region,physical.datapath.subsystem.store.finish_id_i,physical.datapath.subsystem.store.finish_code_i,physical.datapath.subsystem.store.writer_count_r[physical.datapath.subsystem.store.finish_core_i]);finishes++;end
      if(physical.datapath.subsystem.store.release_fire)begin $fdisplay(fd,"F %0d %0d",case_no,physical.datapath.subsystem.store.release_region);releases++;end
    end
  end
  task automatic reset_all();
    release physical.datapath.subsystem.verify_loader.done_id_o;
    release physical.datapath.subsystem.verify_loader.done_regions_o;
    release physical.datapath.subsystem.verify_loader.header_bytes_o;
    release physical.datapath.subsystem.producer.raw_output_id_o;
    release physical.datapath.subsystem.store.fault_o;
    rst=1;monitor=0;external_owner=1;external_request='0;command_valid_i=0;input_valid_i=0;done_ready_i=0;clear_valid_i=0;take_valid_i=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || fault_o || context_valid_o || physical_response.reserved || physical_response.active || !command_ready_o)$fatal(1,"Verify preparation reset");
  endtask
  task automatic create_sentinel(input string seedhex);
    byte unsigned b;int parsed;external_owner=1;external_request='0;
    external_request.job_valid=1;external_request.job_mode=2;external_request.job_param=0;external_request.job_id=62000;
    {external_request.job_bank,external_request.job_region}=6'(sentinel);external_request.message_len=66;
    do @(posedge clk);while(!physical_response.job_ready);@(negedge clk);#1;external_request.job_valid=0;
    for(int w=0;w<9;w++)begin
      external_request.input_data=0;
      for(int j=0;j<8;j++)if(8*w+j<66)begin parsed=$sscanf(seedhex.substr(2*(8*w+j),2*(8*w+j)+1),"%h",b);external_request.input_data[8*j+:8]=b;end
      external_request.input_valid=1;do @(posedge clk);while(!physical_response.input_ready);@(negedge clk);#1;external_request.input_valid=0;
    end
    while(!physical_response.status_valid)begin @(negedge clk);#1;end
    if(physical_response.status_code!=0)$fatal(1,"Sentinel setup");
    external_request.status_ready=1;@(posedge clk);@(negedge clk);#1;external_request='0;
    while(physical_response.active!=0)begin @(negedge clk);#1;end
    if(physical_response.reserved!=(64'd1<<sentinel))$fatal(1,"Sentinel ownership");
  endtask
  task automatic send_frame(input int which,input string data);
    int n,size,parsed;byte unsigned octet;n=data.len()/2;frame=which;
    for(int w=0;w<(n+7)/8;w++)begin
      if(rst || done_valid_o || fault_o)return;
      if(w%11==3)begin @(negedge clk);#1;if(rst || done_valid_o || fault_o)return;end
      input_data_i='1;size=n-8*w>=8?8:n-8*w;
      for(int j=0;j<size;j++)begin parsed=$sscanf(data.substr(2*(8*w+j),2*(8*w+j)+1),"%h",octet);if(parsed!=1)$fatal(1,"Verify prepare data");input_data_i[8*j+:8]=octet;end
      input_bytes_i=4'(size);input_index_i=16'(w);input_last_i=8*(w+1)>=n;
      if(which==0)begin
        if(scenario==6 && w==0)input_index_i=1024;
        if(scenario==7 && w==5)input_bytes_i=0;
        if(scenario==8 && w==0)input_last_i=1;
        if(scenario==9 && input_last_i)input_last_i=0;
      end else begin
        if(scenario==10 && w==0)input_index_i=1024;
        if(scenario==11 && w==(p==0?5:p==1?7:9))input_bytes_i=0;
        if(scenario==12 && w==0)input_last_i=1;
        if(scenario==13 && input_last_i)input_last_i=0;
      end
      input_valid_i=1;do @(posedge clk);while(!input_ready_o && !done_valid_o && !fault_o && !rst);
      @(negedge clk);#1;input_valid_i=0;
    end
  endtask
  task automatic read_word(input int region,input int wordno,input bit hold_response);
    external_owner=1;external_request='0;external_request.read_valid=1;{external_request.read_bank,external_request.read_region}=6'(region);external_request.read_word=6'(wordno);
    do @(posedge clk);while(!physical_response.read_ready);@(negedge clk);#1;external_request.read_valid=0;
    while(!physical_response.response_valid)begin @(negedge clk);#1;end
    if(hold_response)begin
      clear_valid_i=1;take_valid_i=1;
      repeat(7)begin @(posedge clk);if(clear_ready_o || take_ready_o)$fatal(1,"Pending read released owner");end
      @(negedge clk);#1;clear_valid_i=0;take_valid_i=0;$fdisplay(fd,"HOLD %0d %0d %0d",case_no,region,wordno);
    end
    $fdisplay(fd,"R %0d %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,{physical_response.response_bank,physical_response.response_region},physical_response.response_word,
      physical_response.response_id,physical_response.response_mode,physical_response.response_param,physical_response.response_ntt_domain,physical_response.response_small,physical_response.response_error,physical_response.response_data);reads++;
    external_request.response_ready=1;@(posedge clk);@(negedge clk);#1;external_request='0;
  endtask
  task automatic release_region(input int region);
    external_owner=1;external_request='0;external_request.release_valid=1;{external_request.release_bank,external_request.release_region}=6'(region);
    do @(posedge clk);while(!physical_response.release_ready);@(negedge clk);#1;external_request='0;
  endtask
  initial begin
    int f,k,l,total;bit hit;string directory,token,seedhex,pkhex,sighex;logic [63:0] expected_regions;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_verify_prepare_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d %s",token,count,seedhex)!=3)$fatal(1,"Prepare Verify inputs");
    fd=$fopen({directory,"/stage5_verify_prepare_outputs.txt"},"w");$fdisplay(fd,"V %s",token);reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %d %d %d %d %d %s %s",case_no,p,jid,base,scenario,abort_phase,adopt,declared,sentinel,expected_code,expected_detail,pkhex,sighex)!=13 || case_no!=c)$fatal(1,"Verify prepare fixture");
      create_sentinel(seedhex);elapsed=0;monitor=1;raw_index=0;
      if(scenario==5)begin
        external_request.read_valid=1;{external_request.read_bank,external_request.read_region}=6'(sentinel);external_request.read_word=0;
        do @(posedge clk);while(!physical_response.read_ready);@(negedge clk);#1;external_request.read_valid=0;
        while(!physical_response.response_valid)begin @(negedge clk);#1;end
      end
      external_owner=0;command_param_i=2'(p);command_id_i=16'(jid);command_signature_len_i=16'(declared);command_base_i=6'(base);command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;
      command_param_i=3;command_id_i=~16'(jid);command_signature_len_i=65535;command_base_i=63;
      fork begin send_frame(0,pkhex);if(!rst && !done_valid_o && !fault_o)send_frame(1,sighex);end join_none
      hit=0;
      if(abort_phase)begin
        while(!hit)begin
          @(negedge clk);#1;
          case(abort_phase)
            1:hit=raw_index==2;
            2:hit=physical.datapath.subsystem.store.write_fire && physical.datapath.subsystem.store.write_index_i==17 && dut.state==3;
            3:hit=raw_index==12;
            4:hit=dut.state==6 && physical.datapath.subsystem.verify_loader.decoder.header_valid_o;
            5:hit=dut.state==6 && physical.datapath.subsystem.verify_loader.decoder.state==4 && physical.datapath.subsystem.verify_loader.decoder.hint_words_r>=1;
            6:hit=done_valid_o;
            7:begin
              if(done_valid_o)begin done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
                external_owner=1;external_request.read_valid=1;{external_request.read_bank,external_request.read_region}=6'(base);external_request.read_word=0;
                do @(posedge clk);while(!physical_response.read_ready);@(negedge clk);#1;external_request.read_valid=0;
                while(!physical_response.response_valid)begin @(negedge clk);#1;end
                clear_valid_i=1;take_valid_i=1;repeat(5)begin @(posedge clk);if(clear_ready_o || take_ready_o)$fatal(1,"Reset pending read owner");end
                @(negedge clk);#1;hit=1;
              end
            end
            8:begin if(done_valid_o)begin done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;clear_valid_i=1;
                do @(posedge clk);while(!clear_ready_o);@(negedge clk);#1;clear_valid_i=0;
                while(!physical.datapath.subsystem.store.release_fire)begin @(negedge clk);#1;end
                @(posedge clk);@(negedge clk);#1;hit=1;
              end end
            9:hit=physical_response.raw_output_valid && !actual_request.raw_output_ready;
            10:if(physical_response.raw_output_valid)begin force physical.datapath.subsystem.producer.raw_output_id_o=16'hf00d;repeat(3)@(negedge clk);#1;hit=fault_o;end
            11:if(dut.state==6 && physical.datapath.subsystem.store.write_fire)begin force physical.datapath.subsystem.store.fault_o=1'b1;repeat(3)@(negedge clk);#1;hit=fault_o;end
          endcase
          if(done_valid_o && abort_phase<6)$fatal(1,"Missed Verify prepare reset");
        end
        if(abort_phase==9)repeat(8)@(negedge clk);#1;
        $fdisplay(fd,"Z %0d %0d %0d %0d %0d %016h %016h",case_no,abort_phase,dut.state,fault_o,physical_response.active,physical_response.reserved,physical_response.complete);abort_count++;
        reset_all();wait fork;continue;
      end
      while(!done_valid_o)begin
        @(negedge clk);#1;
        if(physical_response.load.done_valid && ((scenario==19 && dut.state==6) || (scenario==20 && dut.state==3) || (scenario==21 && dut.state==6)))begin
          if(scenario==19)force physical.datapath.subsystem.verify_loader.done_id_o=16'h1234;
          if(scenario==20)force physical.datapath.subsystem.verify_loader.done_regions_o=64'd0;
          if(scenario==21)force physical.datapath.subsystem.verify_loader.header_bytes_o=7'd0;
          @(posedge clk);@(negedge clk);#1;
          release physical.datapath.subsystem.verify_loader.done_id_o;release physical.datapath.subsystem.verify_loader.done_regions_o;release physical.datapath.subsystem.verify_loader.header_bytes_o;
        end
      end
      repeat(7)@(negedge clk);#1;wait fork;
      if(done_code_o!=expected_code || done_detail_o!=expected_detail || done_id_o!=jid)$fatal(1,"Prepare status case%0d got%0d/%0d expected%0d/%0d",case_no,done_code_o,done_detail_o,expected_code,expected_detail);
      $fdisplay(fd,"D %0d %0d %0d %0d %016h %016h %0d",case_no,done_id_o,done_code_o,done_detail_o,physical_response.reserved,physical_response.complete,physical_response.active);done_count++;
      k=p==0?4:p==1?6:8;l=p==0?4:p==1?5:7;total=2*k+l;expected_regions=0;
      for(int j=0;j<total;j++)if(base+j<64)expected_regions[base+j]=1;
      if(done_code_o==0)begin
        if(!context_valid_o || context_regions_o!=expected_regions)$fatal(1,"Prepare context publication");
        $fdisplay(fd,"Y %0d %0d %0d %016h %064h %0128h %0128h",case_no,context_param_o,context_id_o,context_regions_o,context_rho_o,context_tr_o,context_ctilde_o);
        for(int j=0;j<k;j++)begin $fdisplay(fd,"K %0d 0 %0d %0d",case_no,j,context_t1_o[j]);$fdisplay(fd,"K %0d 2 %0d %0d",case_no,j,context_hints_o[j]);end
        for(int j=0;j<l;j++)$fdisplay(fd,"K %0d 1 %0d %0d",case_no,j,context_z_o[j]);
      end else if(context_valid_o || physical_response.reserved!=(64'd1<<sentinel))$fatal(1,"Prepare error retained payload");
      done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
      if(expected_code==0)begin
        for(int region=base;region<base+total;region++)for(int w=0;w<64;w++)read_word(region,w,region==base && w==0);
        external_owner=0;
        if(adopt)begin
          take_valid_i=1;do @(posedge clk);while(!take_ready_o);$fdisplay(fd,"TAKE %0d %016h",case_no,expected_regions);
          @(negedge clk);#1;take_valid_i=0;if(busy_o || context_valid_o)$fatal(1,"Prepare take retained old owner");
          for(int region=base;region<base+total;region++)release_region(region);
        end else begin
          clear_valid_i=1;take_valid_i=1;do @(posedge clk);while(!clear_ready_o);if(take_ready_o)$fatal(1,"Clear did not win");$fdisplay(fd,"CLEAR %0d %016h",case_no,expected_regions);
          @(negedge clk);#1;clear_valid_i=0;take_valid_i=0;while(busy_o)begin @(negedge clk);#1;end
        end
      end
      if(scenario==5)begin
        external_owner=1;$fdisplay(fd,"R %0d %0d 0 %0d %0d %0d %0d %0d %0d %023h",case_no,{physical_response.response_bank,physical_response.response_region},physical_response.response_id,physical_response.response_mode,physical_response.response_param,physical_response.response_ntt_domain,physical_response.response_small,physical_response.response_error,physical_response.response_data);reads++;
        external_request.response_ready=1;@(posedge clk);@(negedge clk);#1;external_request='0;
      end
      for(int w=0;w<64;w++)read_word(sentinel,w,0);
      $fdisplay(fd,"EXTERNAL_RELEASE %0d %0d",case_no,sentinel);release_region(sentinel);
      if(physical_response.reserved || physical_response.complete || physical_response.active || busy_o)$fatal(1,"Prepare end ownership");
      $fdisplay(fd,"ENDCASE %0d 0",case_no);monitor=0;
    end
    $fdisplay(fd,"END %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",commands,done_count,abort_count,inputs,allocs,writes,finishes,releases,reads,raw_words,raw_beats);
    $fclose(f);$fclose(fd);$display("STAGE5V2A_VERIFY_PREPARE_CAPTURE_PASS:%0d commands/%0d writes/%0d reads",commands,writes,reads);test_passed=1;$finish;
  end
  initial begin #(64'd300000000000);$fatal(1,"Verify prepare global watchdog case%0d",case_no);end
endmodule
