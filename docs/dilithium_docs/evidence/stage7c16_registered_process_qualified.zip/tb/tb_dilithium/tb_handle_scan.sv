`timescale 1ns/1ps
// Actual helper validation with services deliberately non-quiescent: a legal
// descriptor must reach CHECK, and an illegal one must reject before adoption.
module tb_handle_scan;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always #5 clk=~clk;
  logic [1:0] command=0,ready,done,fault;
  logic [1:0][2:0] code;
  logic [1:0] take_vector;logic take_mask;
  logic [1:0] level=0;int k,l,checked=0,valid_count=0,error_count=0,reset_count=0;
  logic [22:0][5:0] keys;
  logic [6:0][5:0] z;
  logic [7:0][5:0] low,high,ct0;
  logic [5:0] chat;
  logic [63:0] key_map,mask_map,attempt_map,product_map;
  logic [511:0] mu=0;
  logic [6:0] digest_bytes;
  request_t requests[0:1];response_t response;
  always_comb begin
    response='0;
    response.reserved=key_map|mask_map|attempt_map|product_map;
    response.complete=response.reserved;
  end
  assign digest_bytes=level==0?7'd32:level==1?7'd48:7'd64;
  sign_attempt_check ucheck(.clk(clk),.rst(rst),.command_valid_i(command[0]),.command_ready_o(ready[0]),
    .fault_o(fault[0]),.command_id_i(16'd9),.key_valid_i(1'b1),.param_i(level),.key_id_i(16'd1),
    .key_regions_i(key_map),.key_handles_i(keys),.vector_valid_i(1'b1),.vector_id_i(16'd2),.vector_high_id_i(16'd3),
    .vector_regions_i(attempt_map),.vector_z_i(z),.vector_low_i(low),.vector_high_i(high),.vector_ct0_i(ct0),
    .vector_mu_i(mu),.vector_seed_i(512'd0),.vector_ctilde_i(512'd0),.vector_bytes_i(digest_bytes),.vector_next_nonce_i(17'(l)),
    .vector_take_valid_o(take_vector[0]),.vector_take_ready_i(1'b0),.done_valid_o(done[0]),.done_ready_i(1'b0),
    .done_code_o(code[0]),.clear_valid_i(1'b0),.take_valid_i(1'b0),.service_o(requests[0]),.service_i(response));
  sign_response_products uproducts(.clk(clk),.rst(rst),.command_valid_i(command[1]),.command_ready_o(ready[1]),
    .fault_o(fault[1]),.command_id_i(16'd9),.key_valid_i(1'b1),.param_i(level),.key_id_i(16'd1),
    .key_regions_i(key_map),.key_handles_i(keys),.mask_valid_i(1'b1),.mask_id_i(16'd4),.mask_nonce_i(16'd0),
    .mask_regions_i(mask_map),.mask_handles_i(z),.mask_mu_i(mu),.mask_seed_i(512'd0),
    .vector_valid_i(1'b1),.vector_id_i(16'd2),.vector_matrix_id_i(16'd3),.vector_regions_i(product_map),
    .vector_low_i(low),.vector_high_i(high),.vector_chat_i(chat),.vector_ctilde_i(512'd0),.vector_bytes_i(digest_bytes),
    .mask_take_valid_o(take_mask),.vector_take_valid_o(take_vector[1]),.mask_take_ready_i(1'b0),.vector_take_ready_i(1'b0),
    .done_valid_o(done[1]),.done_ready_i(1'b0),.done_code_o(code[1]),.clear_valid_i(1'b0),.take_valid_i(1'b0),
    .service_o(requests[1]),.service_i(response));
  task automatic maps();
    key_map=0;mask_map=0;attempt_map=0;product_map=64'd1<<chat;
    for(int j=0;j<l+2*k;j++)key_map[keys[j]]=1;
    for(int j=0;j<l;j++)mask_map[z[j]]=1;
    attempt_map=mask_map;
    for(int j=0;j<k;j++)begin
      attempt_map[low[j]]=1;attempt_map[high[j]]=1;attempt_map[ct0[j]]=1;
      product_map[low[j]]=1;product_map[high[j]]=1;
    end
  endtask
  task automatic reset_all();
    @(negedge clk);rst=1;command=0;repeat(2)@(negedge clk);#1;
    if(ucheck.layout_key_r || ucheck.layout_vector_r || ucheck.layout_duplicate_r ||
       uproducts.layout_key_r || uproducts.layout_mask_r || uproducts.layout_vector_r || uproducts.layout_duplicate_r)
      $fatal(1,"Reset retained scan state");
    rst=0;
  endtask
  task automatic launch(input int which);
    @(negedge clk);if(!ready[which])$fatal(1,"Scanner not ready");command[which]=1;
    @(negedge clk);#1;command=0;
  endtask
  task automatic run_case(input int which,p,kind,index,input int reset_at=-1);
    bit expect_error;int state_value;bit reached;
    level=2'(p);k=p==0?4:p==1?6:8;l=p==0?4:p==1?5:7;mu=0;
    for(int j=0;j<23;j++)keys[j]=6'(j);
    for(int j=0;j<7;j++)z[j]=6'(23+j);
    for(int j=0;j<8;j++)begin low[j]=6'(30+j);high[j]=6'(38+j);ct0[j]=6'(46+j);end
    chat=54;
    case(kind)
      1:keys[index]=keys[0];
      2:z[index]=z[0];
      3:low[index]=which?low[0]:z[0];
      4:high[index]=which?low[0]:z[0];
      5:ct0[index]=z[0];
      6:chat=low[0];
      7:low[0]=keys[0];
      default:;
    endcase
    maps();
    if(kind==8)begin if(which)product_map[63]=1;else attempt_map[63]=1;end
    reset_all();launch(which);
    if(reset_at>=0)begin repeat(reset_at)@(negedge clk);reset_all();reset_count++;launch(which);end
    if(kind==9)begin repeat(8)@(negedge clk);mu[0]=1;@(negedge clk);mu[0]=0;end
    expect_error=kind!=0;reached=0;
    for(int n=0;n<45;n++)begin
      @(negedge clk);#1;
      if(|fault || |take_vector || take_mask || requests[which].op_valid || requests[which].process_valid ||
         requests[which].sign.valid || requests[which].release_valid)$fatal(1,"Fault/adoption/service before validation");
      state_value=which?int'(uproducts.state):int'(ucheck.state);
      if(done[which])begin
        if(!expect_error || code[which]!=1)$fatal(1,"Unexpected scan result helper%0d level%0d kind%0d index%0d",which,p,kind,index);
        error_count++;reached=1;break;
      end
      if(state_value==1)begin
        if(expect_error)$fatal(1,"Invalid descriptor passed helper%0d level%0d kind%0d index%0d",which,p,kind,index);
        valid_count++;reached=1;break;
      end
    end
    if(!reached)$fatal(1,"Scan timeout helper%0d kind%0d",which,kind);
    checked++;
  endtask
  initial begin
    for(int w=0;w<2;w++)for(int p=0;p<3;p++)begin
      run_case(w,p,0,0);
      for(int j=1;j<(p==0?12:p==1?17:23);j++)run_case(w,p,1,j);
      for(int j=1;j<(p==0?4:p==1?5:7);j++)run_case(w,p,2,j);
      for(int j=w?1:0;j<(p==0?4:p==1?6:8);j++)run_case(w,p,3,j);
      for(int j=0;j<(p==0?4:p==1?6:8);j++)begin
        run_case(w,p,4,j);if(!w)run_case(w,p,5,j);
      end
      if(w)run_case(w,p,6,0);
      run_case(w,p,7,0);run_case(w,p,8,0);run_case(w,p,9,0);
      run_case(w,p,0,0,0);run_case(w,p,0,0,9);run_case(w,p,0,0,w?23:31);
    end
    $display("HANDLE_SCAN_PASS:%0d scenarios;%0d valid;%0d rejected;%0d resets/recoveries",checked,valid_count,error_count,reset_count);
    $finish;
  end
  initial begin #1000000;$fatal(1,"Scanner watchdog");end
endmodule
