`timescale 1ps/1ps
module tb_sign_response_products;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,fault_o;logic [15:0] command_id_i=0;
  logic key_valid_i;logic [1:0] param_i;logic [15:0] key_id_i;logic [63:0] key_regions_i;logic [22:0][5:0] key_handles_i;
  logic mask_valid_i;logic [15:0] mask_id_i,mask_nonce_i;logic [63:0] mask_regions_i;logic [6:0][5:0] mask_handles_i;
  logic [511:0] mask_mu_i,mask_seed_i;
  logic vector_valid_i;logic [15:0] vector_id_i,vector_matrix_id_i;logic [63:0] vector_regions_i;
  logic [7:0][5:0] vector_low_i,vector_high_i;logic [5:0] vector_chat_i;logic [511:0] vector_ctilde_i;logic [6:0] vector_bytes_i;
  logic mask_take_valid_o,vector_take_valid_o,mask_take_ready_i,vector_take_ready_i;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o,done_detail_o;logic [15:0] done_id_o;
  logic result_valid_o;logic [63:0] result_regions_o;logic [6:0][5:0] result_z_o;
  logic [7:0][5:0] result_low_o,result_high_o,result_ct0_o;logic [15:0] result_high_id_o;
  logic [511:0] result_mu_o,result_seed_o,result_ctilde_o;logic [6:0] result_bytes_o;logic [16:0] result_next_nonce_o;
  logic clear_valid_i=0,clear_ready_o,take_valid_i=0,take_ready_o;
  request_t service_o,wire_request,consumer='0;response_t service_i,actual;
  logic mtwire,vtwire,mtr,vtr;
  sign_response_products dut(.*);
  sign_products_setup fixture(.clk(clk),.rst(rst),.request_i(wire_request),.response_o(actual),
    .mask_take_valid_i(mtwire),.vector_take_valid_i(vtwire),.mask_take_ready_o(mtr),.vector_take_ready_o(vtr));
  int case_no=-1,p,jid,nonce,inject,abort_phase,count,fd,cycles=0,commands=0,completions=0,errors=0,aborts=0,transfers=0,writes=0,reads=0;
  bit reading=0,monitor=0,force_fault=0,abort_hit=0,test_passed=0;
  logic [63:0] initial_map,blockers=0;logic [6:0][5:0] old_y,z;logic [7:0][5:0] old_low,old_high,ct0;
  logic [5:0] old_chat;logic [63:0] old_mask,old_vector,taken;logic [511:0] old_mu,old_seed,old_ctilde;
  wire gm=cycles%7>2,gv=cycles%11>3,go=cycles%13>4,gs=cycles%17>5;
  always_comb begin
    key_valid_i=fixture.setup.context_valid_i;param_i=fixture.setup.context_param_i;key_id_i=fixture.setup.context_id_i;
    key_regions_i=fixture.setup.context_regions_i;key_handles_i=fixture.setup.kh;
    mask_valid_i=fixture.setup.mask_valid_i;mask_id_i=fixture.setup.mask_id_i;mask_nonce_i=fixture.setup.mask_nonce;
    mask_regions_i=fixture.setup.mask_regions_i;mask_handles_i=fixture.setup.mask_handles_i;mask_mu_i=fixture.setup.mu;mask_seed_i=fixture.setup.seed;
    vector_valid_i=fixture.ctx_valid;vector_id_i=fixture.tid;vector_matrix_id_i=fixture.ctx_matrix_id;
    vector_regions_i=fixture.ctx_regions;vector_low_i=fixture.ctx_low;vector_high_i=fixture.ctx_high;
    vector_chat_i=fixture.ctx_chat;vector_ctilde_i=fixture.ctx_ctilde;vector_bytes_i=fixture.ctx_bytes;
    if(inject==1)mask_handles_i[1]=mask_handles_i[0];
    mask_take_ready_i=mtr && gm;vector_take_ready_i=vtr && gv;mtwire=mask_take_valid_o && gm;vtwire=vector_take_valid_o && gv;
    wire_request=(busy_o || command_valid_i)?service_o:consumer;service_i=actual;
    if(busy_o || command_valid_i)begin
      wire_request.op_valid=service_o.op_valid && go;service_i.op_ready=actual.op_ready && go;
      wire_request.op_done_ready=service_o.op_done_ready && gs;service_i.op_done_valid=actual.op_done_valid && gs;
      wire_request.process_valid=service_o.process_valid && go;service_i.process_ready=actual.process_ready && go;
      wire_request.process_done_ready=service_o.process_done_ready && gs;service_i.process_done_valid=actual.process_done_valid && gs;
      wire_request.release_valid=service_o.release_valid && gv;service_i.release_ready=actual.release_ready && gv;
      if(inject==3 && dut.group_r==0 && dut.ordinal_r==0)wire_request.op_b_id=service_o.op_b_id^16'd1;
      if(inject==4 && dut.group_r==1 && dut.ordinal_r==1 && dut.state==7)wire_request.op_a_id=service_o.op_a_id^16'd1;
      if(inject==5 && dut.group_r==1 && dut.ordinal_r==1)wire_request.process_a_id=service_o.process_a_id^16'd1;
      if(inject==6 && dut.group_r==2 && dut.ordinal_r==1 && dut.state==8)service_i.op_done_id=actual.op_done_id^16'd1;
      if(inject==7 && dut.group_r==0 && dut.ordinal_r==0)service_i.process_done_id=actual.process_done_id^16'd1;
      if(force_fault)service_i.fault=1;
      if(reading)wire_request=consumer;
    end
  end
  bit held=0,rheld=0;logic [21:0] old_done;logic [1825:0] old_result;int elapsed=0;
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held=0;rheld=0;end
    else if(monitor)begin
      elapsed++;if(elapsed>300000)$fatal(1,"Products watchdog case%0d state%0d group%0d poly%0d",case_no,dut.state,dut.group_r,dut.ordinal_r);
      if(actual.fault || fixture.cfault || fixture.tfault || fixture.setup.fault_o || fixture.setup.mfault)$fatal(1,"Products unexpected source/physical fault");
      if(held && (!done_valid_o || {done_code_o,done_detail_o,done_id_o}!==old_done))$fatal(1,"Products held done changed");
      held=done_valid_o && !done_ready_i;old_done={done_code_o,done_detail_o,done_id_o};
      if(rheld && !(clear_valid_i && clear_ready_o) && !(take_valid_i && take_ready_o) && (!result_valid_o ||
        {result_regions_o,result_z_o,result_low_o,result_high_o,result_ct0_o,result_high_id_o,result_mu_o,result_seed_o,result_ctilde_o,result_bytes_o,result_next_nonce_o}!==old_result))$fatal(1,"Products retained context changed");
      rheld=result_valid_o && !(clear_valid_i && clear_ready_o) && !(take_valid_i && take_ready_o);
      old_result={result_regions_o,result_z_o,result_low_o,result_high_o,result_ct0_o,result_high_id_o,result_mu_o,result_seed_o,result_ctilde_o,result_bytes_o,result_next_nonce_o};
      if(!result_valid_o && (result_regions_o || result_z_o || result_low_o || result_high_o || result_ct0_o || result_high_id_o || result_mu_o || result_seed_o || result_ctilde_o || result_bytes_o || result_next_nonce_o))$fatal(1,"Products private result exposed");
      if((mtwire && mtr)!=(vtwire && vtr))$fatal(1,"Products non-atomic adoption");
      if(dut.adopted_r && (fixture.setup.mask_valid_i || fixture.ctx_valid || fixture.setup.mcr || fixture.tcr))$fatal(1,"Products old owner remains live");
      if(command_valid_i && command_ready_o)begin $fdisplay(fd,"C %0d %0d %0d %0d %0d %0d",case_no,p,jid,nonce,inject,abort_phase);commands++;end
      if(mtwire && mtr)begin $fdisplay(fd,"T %0d %016h %016h %012h %0d %0d",case_no,actual.reserved,dut.plan_r,dut.ct0_r,dut.pwm_r,dut.inv_r);transfers++;end
      if(wire_request.op_valid && actual.op_ready)$fdisplay(fd,"O %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,dut.group_r,dut.ordinal_r,wire_request.op,wire_request.op_a_region,wire_request.op_a_id,wire_request.op_b_region,wire_request.op_b_id,wire_request.op_dest_region,wire_request.op_id);
      if(actual.op_done_valid && wire_request.op_done_ready)$fdisplay(fd,"Q %0d %0d %0d %0d %0d %0d",case_no,dut.group_r,dut.ordinal_r,service_i.op_done_code,service_i.op_done_id,service_i.op_done_region);
      if(wire_request.process_valid && actual.process_ready)$fdisplay(fd,"P %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,dut.group_r,dut.ordinal_r,wire_request.process_op,wire_request.process_inplace,wire_request.process_a,wire_request.process_b,wire_request.process_dest,wire_request.process_a_id,wire_request.process_b_id,wire_request.process_id);
      if(actual.process_done_valid && wire_request.process_done_ready)$fdisplay(fd,"R %0d %0d %0d %0d %0d %0d",case_no,dut.group_r,dut.ordinal_r,service_i.process_done_code,service_i.process_done_id,service_i.process_done_dest);
      if(wire_request.release_valid && actual.release_ready)$fdisplay(fd,"F %0d %0d %0d",case_no,dut.state,{wire_request.release_bank,wire_request.release_region});
      if(fixture.setup.services.datapath.subsystem.store.write_fire)begin
        $fdisplay(fd,"X %0d %0d %0d %0d %0d %0d %06h",case_no,dut.group_r,dut.ordinal_r,dut.state,fixture.setup.services.datapath.subsystem.store.write_region,fixture.setup.services.datapath.subsystem.store.write_index_i,fixture.setup.services.datapath.subsystem.store.write_data_i);writes++;
        if(fixture.setup.services.datapath.subsystem.store.write_index_i==31 &&
          ((abort_phase==1 && dut.state==5 && dut.group_r==0 && dut.ordinal_r==0) ||
           (abort_phase==2 && dut.state==8 && dut.group_r==0 && dut.ordinal_r==0) ||
           (abort_phase==3 && dut.state==11 && dut.group_r==0 && dut.ordinal_r==0) ||
           (abort_phase==4 && dut.state==5 && dut.group_r==2 && dut.ordinal_r==1) ||
           (abort_phase==6 && dut.state==5 && dut.group_r==1 && dut.ordinal_r==1)))abort_hit=1;
      end
    end
  end
  task automatic reset_all();
    rst=1;fixture.reset_controls();command_valid_i=0;done_ready_i=0;clear_valid_i=0;take_valid_i=0;consumer='0;monitor=0;reading=0;force_fault=0;blockers=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || actual.reserved || result_valid_o || fault_o)$fatal(1,"Products reset state");
  endtask
  task automatic read_region(input int kind,input int ordinal,input int region);
    reading=1;
    for(int w=0;w<64;w++)begin
      consumer='0;consumer.read_valid=1;{consumer.read_bank,consumer.read_region}=6'(region);consumer.read_word=6'(w);
      do @(posedge clk);while(!actual.read_ready);@(negedge clk);#1;consumer.read_valid=0;
      while(!actual.response_valid)begin @(negedge clk);#1;end if(actual.response_error)$fatal(1,"Products read error");
      $fdisplay(fd,"V %0d %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,kind,ordinal,region,w,actual.response_id,actual.response_mode,actual.response_param,actual.response_ntt_domain,actual.response_data);reads++;
      repeat(w%3)@(negedge clk);#1;consumer.response_ready=1;@(posedge clk);@(negedge clk);#1;consumer='0;
    end reading=0;
  endtask
  task automatic release_external(input int region);
    consumer='0;consumer.release_valid=1;{consumer.release_bank,consumer.release_region}=6'(region);
    do @(posedge clk);while(!actual.release_ready);@(negedge clk);#1;consumer='0;$fdisplay(fd,"L %0d %0d",case_no,region);
  endtask
  initial begin
    int f,free_count,keep;string directory,token,skhex,bodyhex;logic [255:0] rnd;bit aborted;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_sign_products_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d",token,count)!=2)$fatal(1,"Prepare products fixtures");
    fd=$fopen({directory,"/stage5_sign_products_outputs.txt"},"w");$fdisplay(fd,"G %s",token);fixture.setup.fd=fd;reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %h %s %s",case_no,p,jid,nonce,inject,abort_phase,rnd,skhex,bodyhex)!=9 || case_no!=c)$fatal(1,"Products input row");
      monitor=0;if(fixture.setup.context_valid_i && fixture.setup.context_param_i!=p)reset_all();
      fixture.prepare_all(case_no,p,nonce,skhex,bodyhex,rnd);
      old_y=fixture.setup.mask_handles_i;old_low=fixture.ctx_low;old_high=fixture.ctx_high;old_chat=fixture.ctx_chat;
      old_mask=fixture.setup.mask_regions_i;old_vector=fixture.ctx_regions;old_mu=fixture.setup.mu;old_seed=fixture.setup.seed;old_ctilde=fixture.ctx_ctilde;
      blockers=0;if(inject==2)begin
        free_count=0;keep=(p==0?4:(p==1?6:8))+1;
        for(int r=0;r<64;r++)if(!actual.reserved[r])begin if(free_count>=keep)begin fixture.setup.seed_region(r);blockers[r]=1;end free_count++;end
      end
      initial_map=actual.reserved;$fdisplay(fd,"N %0d %016h %016h %016h %011h %012h %012h %0d",case_no,initial_map,old_mask,old_vector,old_y,old_low,old_high,old_chat);
      elapsed=0;abort_hit=0;monitor=1;command_id_i=16'(jid);command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;
      aborted=0;if(abort_phase!=0)begin
        if(abort_phase==5)while(!done_valid_o)begin @(negedge clk);#1;end else while(!abort_hit)begin @(negedge clk);#1;end
        if(abort_phase==6)begin force_fault=1;repeat(3)@(negedge clk);#1;if(!fault_o || done_valid_o || result_valid_o)$fatal(1,"Products fault not halted");end
        $fdisplay(fd,"Z %0d %0d %0d %0d %0d",case_no,abort_phase,dut.state,dut.group_r,dut.ordinal_r);aborts++;aborted=1;reset_all();
      end
      if(!aborted)begin
        while(!done_valid_o)begin @(negedge clk);#1;end
        if(done_code_o==0)$fdisplay(fd,"D %0d %016h %011h %012h %012h %012h %0d %0d %0d %0128h %0128h %0128h",case_no,result_regions_o,result_z_o,result_low_o,result_high_o,result_ct0_o,result_high_id_o,result_bytes_o,result_next_nonce_o,result_mu_o,result_seed_o,result_ctilde_o);
        repeat(7)@(negedge clk);#1;$fdisplay(fd,"E %0d %0d %0d %0d",case_no,done_id_o,done_code_o,done_detail_o);completions++;if(done_code_o)errors++;
        done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
        if(done_code_o==0)begin
          z=result_z_o;ct0=result_ct0_o;
          for(int j=0;j<(p==0?4:(p==1?5:7));j++)read_region(0,j,z[j]);
          for(int j=0;j<(p==0?4:(p==1?6:8));j++)begin read_region(1,j,result_low_o[j]);read_region(2,j,result_high_o[j]);read_region(3,j,ct0[j]);end
          fixture.setup.mclear=1;fixture.tclear=1;repeat(6)begin @(negedge clk);#1;if(fixture.setup.mcr || fixture.tcr)$fatal(1,"Old products source owner can clear");end fixture.setup.mclear=0;fixture.tclear=0;
          reading=1;consumer='0;consumer.read_valid=1;{consumer.read_bank,consumer.read_region}=z[0];
          do @(posedge clk);while(!actual.read_ready);@(negedge clk);#1;consumer.read_valid=0;
          while(!actual.response_valid)begin @(negedge clk);#1;end if(nonce!=0)take_valid_i=1;else clear_valid_i=1;
          repeat(6)begin @(negedge clk);#1;if(clear_ready_o || take_ready_o)$fatal(1,"Products pending read bypassed");end
          $fdisplay(fd,"BARRIER %0d %023h",case_no,actual.response_data);consumer.response_ready=1;@(posedge clk);@(negedge clk);#1;consumer='0;reading=0;
          if(nonce!=0)begin
            taken=result_regions_o;do @(posedge clk);while(!take_ready_o);
            $fdisplay(fd,"A %0d %016h %0d %0128h %0128h",case_no,taken,result_next_nonce_o,result_mu_o,result_seed_o);
            @(negedge clk);#1;take_valid_i=0;for(int r=0;r<64;r++)if(taken[r])release_external(r);
          end else begin do @(posedge clk);while(!clear_ready_o);@(negedge clk);#1;clear_valid_i=0;end
        end
        while(busy_o)begin @(negedge clk);#1;end
        if(inject==1 || inject==2)begin
          for(int j=0;j<(p==0?4:(p==1?5:7));j++)read_region(7,j,old_y[j]);
          for(int j=0;j<(p==0?4:(p==1?6:8));j++)begin read_region(8,j,old_low[j]);read_region(2,j,old_high[j]);end
          read_region(9,0,old_chat);
        end
        for(int j=0;j<(p==0?12:(p==1?17:23));j++)read_region(4,j,fixture.setup.kh[j]);read_region(5,0,50);
        for(int r=0;r<64;r++)if(blockers[r])begin read_region(6,r,r);release_external(r);end
        if(actual.reserved!==(fixture.setup.context_regions_i|(64'd1<<50)|((inject==1 || inject==2)?old_mask|old_vector:64'd0)))$fatal(1,"Products leaked/clobbered memory");
        $fdisplay(fd,"B %0d %016h",case_no,actual.reserved);
      end monitor=0;
    end
    $fdisplay(fd,"END %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",commands,completions,errors,aborts,transfers,writes,reads,fixture.setup.keys,fixture.setup.masks,fixture.setup.matrices);
    $fclose(f);$fclose(fd);$display("STAGE5N4H2_SIGN_PRODUCTS_CAPTURE_PASS:%0d commands,%0d completions,%0d errors,%0d aborts",commands,completions,errors,aborts);test_passed=1;$finish;
  end
  initial begin #(64'd500000000000);$fatal(1,"Products global watchdog case%0d",case_no);end
endmodule
