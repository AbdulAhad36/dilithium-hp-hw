`timescale 1ps/1ps
// Working control client against the actual services tree. The outer owner
// mux is the same boundary used by main KeyGen;consumer reads belong to Sign,
// not to the unrelated host. Explicit adapters inject declared faults/stalls.
module tb_sign_key_prepare;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,service_active_o,fault_o;
  logic [1:0] command_param_i=0;logic [15:0] command_id_i=0;
  logic [5:0] command_base_i=0,command_work_i=0;
  logic input_valid_i=0,input_ready_o,input_last_i=0;logic [63:0] input_data_i=0;
  logic [3:0] input_bytes_i=8;logic [9:0] input_index_i=0;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o,done_detail_o;logic [15:0] done_id_o;
  logic context_valid_o;logic [1:0] context_param_o;logic [15:0] context_id_o;
  logic [63:0] context_regions_o;logic [22:0][5:0] context_handles_o;
  logic [255:0] context_rho_o,context_key_o;logic [511:0] context_tr_o;
  logic clear_valid_i=0,clear_ready_o;
  request_t service_o,host_request='0,consumer_request='0,wire_request;
  response_t service_i,actual_response;
  sign_key_prepare prep(.*);
  dilithium_services dut(.clk(clk),.rst(rst),.request_i(wire_request),.response_o(actual_response));
  int cycles=0,case_no=-1,p,jid,base,work,sentinel,fault_word,fault,abort_phase,inject,target,length,count,fd;
  int completed=0,errors=0,aborts=0,writes=0,reads=0,commands=0,word_count=0;
  int witnesses[9];bit monitor=0,test_passed=0,abort_request=0,global_fault=0,published=0;
  wire owner=busy_o || command_valid_i;
  wire prep_grant=service_active_o || (!busy_o && command_valid_i);
  wire gl=cycles%5>1,gn=cycles%7>2,gr=cycles%11>4,gb=cycles%13>4,go=cycles%17>6;
  always_comb begin
    wire_request=prep_grant?service_o:(busy_o?consumer_request:host_request);
    service_i=actual_response;
    if(busy_o && !service_active_o && clear_valid_i)wire_request.read_valid=0;
    if(prep_grant)begin
      wire_request.load.valid=service_o.load.valid && gl;service_i.load.ready=actual_response.load.ready && gl;
      wire_request.op_valid=service_o.op_valid && gn;service_i.op_ready=actual_response.op_ready && gn;
      wire_request.release_valid=service_o.release_valid && gr;service_i.release_ready=actual_response.release_ready && gr;
      wire_request.load.done_ready=service_o.load.done_ready && gb;service_i.load.done_valid=actual_response.load.done_valid && gb;
      wire_request.op_done_ready=service_o.op_done_ready && go;service_i.op_done_valid=actual_response.op_done_valid && go;
      if(inject==1 && int'(prep.ordinal_r)==target)wire_request.op_a_id=service_o.op_a_id^16'd1;
      if(inject==2 && int'(prep.ordinal_r)==target)service_i.op_done_id=actual_response.op_done_id^16'd1;
      if(inject==3 && int'(prep.ordinal_r)==target)service_i.op_done_region=actual_response.op_done_region^6'd1;
      if(inject==4)service_i.load.done_id=actual_response.load.done_id^16'd1;
      if(inject==5)service_i.load.done_regions=actual_response.load.done_regions^(64'd1<<base);
    end
    if(global_fault)service_i.fault=1;
  end
  logic held=0,context_held=0;logic [21:0] previous_done;
  logic [1243:0] previous_context;
  wire [1243:0] context_payload={context_param_o,context_id_o,context_regions_o,context_handles_o,context_rho_o,context_key_o,context_tr_o};
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held=0;context_held=0;end
    else if(monitor)begin
      if(actual_response.fault || (fault_o && abort_phase!=6))$fatal(1,"Prepare unexpected fault case%0d state%0d",case_no,prep.state);
      if(held && (!done_valid_o || {done_code_o,done_detail_o,done_id_o}!==previous_done))$fatal(1,"Prepare done changed while held");
      held=done_valid_o && !done_ready_i;previous_done={done_code_o,done_detail_o,done_id_o};
      if(context_held && !(clear_valid_i && clear_ready_o) && (!context_valid_o || context_payload!==previous_context))$fatal(1,"Retained key context changed");
      context_held=context_valid_o && !(clear_valid_i && clear_ready_o);previous_context=context_payload;
      if(!context_valid_o && (context_regions_o || context_handles_o || context_key_o || context_tr_o || context_rho_o || context_param_o || context_id_o))$fatal(1,"Prepare exposed tentative context");
      if(busy_o && command_ready_o)$fatal(1,"Prepare accepted a new key over a live owner");
      if(owner)begin
        // Host offers remain present,but no ready/result is routed to that
        // unrelated client while the operation owns these shared resources.
        if(!prep_grant && !busy_o)$fatal(1,"Missing operation owner");witnesses[8]++;
      end
      if(command_valid_i && command_ready_o)$fdisplay(fd,"C %0d %0d %0d %0d %0d %0d",case_no,p,jid,base,work,sentinel);
      if(input_valid_i && input_ready_o)begin
        $fdisplay(fd,"W %0d %0d %0d %0d %016h",case_no,input_index_i,input_bytes_i,input_last_i,input_data_i);word_count++;
      end
      if(service_o.load.valid && !service_i.load.ready)witnesses[2]++;
      if(service_o.op_valid && !service_i.op_ready)witnesses[3]++;
      if(service_o.release_valid && !service_i.release_ready)witnesses[4]++;
      if(actual_response.load.done_valid && !wire_request.load.done_ready)witnesses[5]++;
      if(actual_response.op_done_valid && !wire_request.op_done_ready)witnesses[6]++;
      if(clear_valid_i && !clear_ready_o)witnesses[7]++;
      if(prep_grant && wire_request.load.valid && actual_response.load.ready)$fdisplay(fd,"L %0d %0d %0d %0d",case_no,wire_request.load.param,wire_request.load.id,wire_request.load.base);
      if(prep_grant && actual_response.load.done_valid && wire_request.load.done_ready)
        $fdisplay(fd,"B %0d %0d %0d %016h %0d %0d %016h",case_no,actual_response.load.done_id,actual_response.load.done_code,actual_response.load.done_regions,service_i.load.done_id,service_i.load.done_code,service_i.load.done_regions);
      if(prep_grant && wire_request.op_valid && actual_response.op_ready)begin
        $fdisplay(fd,"N %0d %0d %0d %0d %0d %0d %0d",case_no,prep.ordinal_r,wire_request.op,wire_request.op_a_region,wire_request.op_dest_region,wire_request.op_a_id,wire_request.op_id);commands++;
      end
      if(prep_grant && actual_response.op_done_valid && wire_request.op_done_ready)
        $fdisplay(fd,"O %0d %0d %0d %0d %0d %0d %0d %0d",case_no,prep.ordinal_r,actual_response.op_done_id,actual_response.op_done_region,actual_response.op_done_code,service_i.op_done_id,service_i.op_done_region,service_i.op_done_code);
      if(prep_grant && wire_request.release_valid && actual_response.release_ready)begin
        $fdisplay(fd,"R %0d %0d %0d",case_no,prep.state==6?0:(prep.clearing_r?2:1),{wire_request.release_bank,wire_request.release_region});
        if(abort_phase==4 && prep.state==6)abort_request=1;
      end
      if(busy_o)begin
        if(dut.datapath.subsystem.store.alloc_fire)$fdisplay(fd,"G %0d %0d %0d %0d %0d %0d",case_no,{dut.datapath.subsystem.store.alloc_bank_i,dut.datapath.subsystem.store.alloc_region_i},dut.datapath.subsystem.store.alloc_id_i,dut.datapath.subsystem.store.alloc_mode_i,dut.datapath.subsystem.store.alloc_param_i,dut.datapath.subsystem.store.alloc_ntt_domain_i);
        if(dut.datapath.subsystem.store.write_fire)begin
          $fdisplay(fd,"X %0d %0d %0d %0d %06h %0d",case_no,actual_response.load.busy?0:1,dut.datapath.subsystem.store.write_region,dut.datapath.subsystem.store.write_index_i,dut.datapath.subsystem.store.write_data_i,dut.datapath.subsystem.store.write_last_i);writes++;
        end
        if(dut.datapath.subsystem.store.finish_fire)$fdisplay(fd,"U %0d %0d %0d",case_no,dut.datapath.subsystem.store.finish_region,dut.datapath.subsystem.store.finish_code_i);
        if(actual_response.load.busy && dut.datapath.subsystem.store.release_fire)$fdisplay(fd,"Z %0d %0d",case_no,dut.datapath.subsystem.store.release_region);
        for(int b=0;b<4;b++)begin
          if(dut.datapath.subsystem.store.request_valid[0][b] && dut.datapath.subsystem.store.request_ready[0][b])$fdisplay(fd,"P %0d %0d %0d %023h",case_no,16*b+int'(dut.datapath.subsystem.store.request_address[0][b][9:6]),dut.datapath.subsystem.store.request_address[0][b][5:0],dut.datapath.subsystem.store.request_data[0][b]);
          if(dut.datapath.subsystem.store.response_valid[0][b] && dut.datapath.subsystem.store.response_ready[0][b])$fdisplay(fd,"Q %0d %0d %0d",case_no,16*b+int'(dut.datapath.subsystem.store.response_address[0][b][9:6]),dut.datapath.subsystem.store.response_address[0][b][5:0]);
        end
      end
      if(context_valid_o && !published)begin
        $fdisplay(fd,"H %0d %0d %0d %016h %035h %064h %064h %0128h",case_no,context_id_o,context_param_o,context_regions_o,context_handles_o,context_rho_o,context_key_o,context_tr_o);published=1;
      end
    end
  end
  always @(negedge clk)if(monitor && !rst)begin
    if(abort_phase==2 && actual_response.op_busy && dut.datapath.subsystem.state==6 && dut.datapath.subsystem.load_word_r==7)abort_request=1;
    if(abort_phase==3 && actual_response.op_busy && dut.datapath.subsystem.result_count_r==31)abort_request=1;
    if(abort_phase==6 && actual_response.op_busy && dut.datapath.subsystem.state==6 && dut.datapath.subsystem.load_word_r==7)begin global_fault=1;abort_request=1;end
  end
  task automatic reset_all();
    #1;rst=1;command_valid_i=0;input_valid_i=0;done_ready_i=0;clear_valid_i=0;host_request='0;consumer_request='0;global_fault=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || context_valid_o || done_valid_o || fault_o || actual_response.reserved || context_key_o || context_tr_o || context_rho_o || prep.owned_r)$fatal(1,"Prepare reset retained state");
  endtask
  task automatic seed_sentinel();
    host_request='0;host_request.job_valid=1;{host_request.job_bank,host_request.job_region}=6'(sentinel);
    host_request.job_mode=2;host_request.job_param=0;host_request.job_id=60000;host_request.message_len=66;host_request.status_ready=1;
    do @(posedge clk);while(!actual_response.job_ready);@(negedge clk);#1;host_request.job_valid=0;
    for(int w=0;w<9;w++)begin
      host_request.input_data='1;for(int b=0;b<8 && 8*w+b<66;b++)host_request.input_data[8*b+:8]=8'(case_no+8*w+b);
      host_request.input_valid=1;do @(posedge clk);while(!actual_response.input_ready);@(negedge clk);#1;host_request.input_valid=0;
    end
    while(actual_response.active!=0)begin @(negedge clk);#1;end
    if(!actual_response.complete[sentinel])$fatal(1,"Prepare sentinel missing");host_request='0;
  endtask
  task automatic read_poly(input int ordinal,input int region,input bit consumer);
    for(int w=0;w<64;w++)begin
      if(consumer)begin consumer_request.read_valid=1;{consumer_request.read_bank,consumer_request.read_region}=6'(region);consumer_request.read_word=6'(w);end
      else begin host_request='0;host_request.read_valid=1;{host_request.read_bank,host_request.read_region}=6'(region);host_request.read_word=6'(w);end
      do @(posedge clk);while(!actual_response.read_ready);@(negedge clk);#1;
      if(consumer)consumer_request.read_valid=0;else host_request.read_valid=0;
      while(!actual_response.response_valid)begin @(negedge clk);#1;end
      if(actual_response.response_error)$fatal(1,"Prepare consumer read error");
      $fdisplay(fd,"V %0d %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,ordinal,{actual_response.response_bank,actual_response.response_region},actual_response.response_word,actual_response.response_id,actual_response.response_mode,actual_response.response_param,actual_response.response_ntt_domain,actual_response.response_small,actual_response.response_data);reads++;
      repeat(w%3)@(negedge clk);#1;if(consumer)consumer_request.response_ready=1;else host_request.response_ready=1;
      @(posedge clk);@(negedge clk);#1;if(consumer)consumer_request.response_ready=0;else host_request.response_ready=0;
    end
  endtask
  task automatic clear_context();
    consumer_request.read_valid=1;{consumer_request.read_bank,consumer_request.read_region}=context_handles_o[0];consumer_request.read_word=0;
    do @(posedge clk);while(!actual_response.read_ready);@(negedge clk);#1;consumer_request.read_valid=0;clear_valid_i=1;
    repeat(6)begin @(negedge clk);#1;if(clear_ready_o)$fatal(1,"Clear stole a pending consumer read");end
    while(!actual_response.response_valid)begin @(negedge clk);#1;end
    $fdisplay(fd,"I %0d %0d %0d %023h",case_no,actual_response.response_id,{actual_response.response_bank,actual_response.response_region},actual_response.response_data);
    consumer_request.response_ready=1;@(posedge clk);@(negedge clk);#1;consumer_request.response_ready=0;
    command_valid_i=0;
    do @(posedge clk);while(!clear_ready_o);
    $fdisplay(fd,"E %0d",case_no);@(negedge clk);#1;clear_valid_i=0;consumer_request='0;
    while(busy_o)begin @(negedge clk);#1;end
    if(context_valid_o || prep.owned_r || actual_response.reserved!=(64'd1<<sentinel))$fatal(1,"Prepare clear leaked a key");
  endtask
  task automatic witness();
    $fdisplay(fd,"T %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,witnesses[0],witnesses[1],witnesses[2],witnesses[3],witnesses[4],witnesses[5],witnesses[6],witnesses[7],witnesses[8]);
  endtask
  initial begin
    int f,n,total;string directory,token,hexkey;byte unsigned octet;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_sign_prepare_inputs.txt"},"r");
    if(!f || $fscanf(f,"%s %d",token,count)!=2 || count<160)$fatal(1,"Prepare signing context vectors");
    fd=$fopen({directory,"/stage5_sign_prepare_outputs.txt"},"w");$fdisplay(fd,"S %s",token);reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %d %d %d %d %d %d %s",case_no,p,jid,base,work,sentinel,fault_word,fault,abort_phase,inject,target,length,hexkey)!=13 || case_no!=c || hexkey.len()!=2*length)$fatal(1,"Prepare fixture row");
      total=p==0?12:(p==1?17:23);seed_sentinel();foreach(witnesses[j])witnesses[j]=0;
      abort_request=0;global_fault=0;published=0;word_count=0;monitor=1;
      command_param_i=2'(p);command_id_i=16'(jid);command_base_i=6'(base);command_work_i=6'(work);command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;
      // Retain an invalid new command throughout the live key;it must not
      // overwrite the snapshotted header/level/ID or be accepted a second time.
      command_param_i=3;command_id_i=999;command_base_i=63;command_work_i=63;
      host_request.job_valid=1;host_request.op_valid=1;host_request.process_valid=1;host_request.row_valid=1;
      host_request.load.valid=1;host_request.sign.valid=1;host_request.raw_valid=1;host_request.read_valid=1;host_request.release_valid=1;
      for(int w=0;w<length/8;w++)begin
        if(done_valid_o || abort_request)break;
        input_data_i=0;for(int b=0;b<8;b++)begin n=$sscanf(hexkey.substr(2*(8*w+b),2*(8*w+b)+1),"%h",octet);if(n!=1)$fatal(1,"Prepare key byte");input_data_i[8*b+:8]=octet;end
        input_index_i=10'(w ^ ((fault==1 && w==fault_word)?1:0));input_bytes_i=4'((fault>=10 && w==fault_word)?fault-10:8);
        input_last_i=(w==length/8-1) ^ (fault==2 && w==fault_word);input_valid_i=1;
        do @(posedge clk);while(!input_ready_o && !done_valid_o && !abort_request);
        @(negedge clk);#1;input_valid_i=0;if(abort_request)break;
        if(abort_phase==1 && word_count==3)begin abort_request=1;break;end
        if(w%19==0)begin repeat(2)@(negedge clk);#1;end
      end
      while(!done_valid_o && !abort_request)begin @(negedge clk);#1;end
      if(abort_phase!=0)begin
        if(abort_phase==5)repeat(7)begin @(negedge clk);#1;witnesses[0]++;end
        if(abort_phase==6)begin
          repeat(6)begin @(negedge clk);#1;end
          if(!fault_o || done_valid_o || context_valid_o || command_ready_o || clear_ready_o)$fatal(1,"Prepare fault did not hold lease until reset");
        end
        $fdisplay(fd,"A %0d %0d",case_no,abort_phase);witness();aborts++;monitor=0;reset_all();continue;
      end
      repeat(7)begin @(negedge clk);#1;witnesses[0]++;end
      $fdisplay(fd,"D %0d %0d %0d %0d",case_no,done_code_o,done_detail_o,done_id_o);completed++;if(done_code_o!=0)errors++;
      if(done_code_o!=0)command_valid_i=0;
      done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
      if(context_valid_o)begin
        repeat(9)begin @(negedge clk);#1;witnesses[1]++;end
        if(service_active_o || command_ready_o || !busy_o)$fatal(1,"Missing retained context lease");
        for(int j=0;j<total;j++)read_poly(j,context_handles_o[j],1);
        clear_context();
      end else begin
        if(busy_o || actual_response.reserved!=(64'd1<<sentinel))$fatal(1,"Prepare error cleanup leaked region");
      end
      host_request='0;read_poly(-1,sentinel,0);witness();monitor=0;
      host_request.release_valid=1;{host_request.release_bank,host_request.release_region}=6'(sentinel);
      do @(posedge clk);while(!actual_response.release_ready);@(negedge clk);#1;host_request='0;
      if(actual_response.reserved)$fatal(1,"Prepare test leaked storage");
    end
    $fdisplay(fd,"F %0d %0d %0d %0d %0d %0d %0d",count,completed,errors,aborts,writes,reads,commands);$fclose(f);$fclose(fd);
    $display("STAGE5N4D_SIGN_PREPARE_CAPTURE_PASS:%0d commands,%0d completions,%0d errors,%0d resets,%0d writes,%0d reads,%0d transforms",count,completed,errors,aborts,writes,reads,commands);test_passed=1;$finish;
  end
  initial begin #(64'd90000000000);$fatal(1,"Prepare watchdog case%0d state%0d",case_no,prep.state);end
endmodule
