`timescale 1ps/1ps
module tb_sign_attempt_check;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,fault_o;logic [15:0] command_id_i=0;
  logic key_valid_i;logic [1:0] param_i;logic [15:0] key_id_i;logic [63:0] key_regions_i;logic [22:0][5:0] key_handles_i;
  logic vector_valid_i;logic [15:0] vector_id_i,vector_high_id_i;logic [63:0] vector_regions_i;
  logic [6:0][5:0] vector_z_i;logic [7:0][5:0] vector_low_i,vector_high_i,vector_ct0_i;
  logic [511:0] vector_mu_i,vector_seed_i,vector_ctilde_i;logic [6:0] vector_bytes_i;logic [16:0] vector_next_nonce_i;
  logic vector_take_valid_o,vector_take_ready_i,vtwire,vtr;
  logic done_valid_o,done_ready_i=0,done_reject_o;logic [2:0] done_code_o,done_detail_o,done_reason_o;
  logic [11:0] done_weight_o;logic [15:0] done_id_o;
  logic result_valid_o,result_reject_o;logic [63:0] result_regions_o;logic [6:0][5:0] result_z_o;
  logic [7:0][5:0] result_hint_o;logic [15:0] result_z_id_o;
  logic [511:0] result_mu_o,result_seed_o,result_ctilde_o;logic [6:0] result_bytes_o;logic [16:0] result_next_nonce_o;
  logic clear_valid_i=0,clear_ready_o,take_valid_i=0,take_ready_o;
  request_t service_o,wire_request,consumer='0;response_t service_i,actual;
  sign_attempt_check dut(.*);
  sign_check_setup fixture(.clk(clk),.rst(rst),.request_i(wire_request),.response_o(actual),.take_valid_i(vtwire),.take_ready_o(vtr));
  int case_no=-1,p,jid,nonce,inject,abort_phase,count,fd,cycles=0,elapsed=0;
  int commands=0,completions=0,rejections=0,errors=0,aborts=0,transfers=0,writes=0,reads=0;
  bit monitor=0,reading=0,force_fault=0,abort_hit=0,test_passed=0;
  logic [63:0] initial_map,blocks,taken;logic [6:0][5:0] z;logic [7:0][5:0] hints;
  wire gv=cycles%11>3,go=cycles%13>4,gs=cycles%17>5;
  always_comb begin
    key_valid_i=fixture.key_valid_i;param_i=fixture.param_i;key_id_i=fixture.key_id_i;
    key_regions_i=fixture.key_regions_i;key_handles_i=fixture.key_handles_i;
    vector_valid_i=fixture.result_valid_o;vector_id_i=fixture.done_id_o;vector_high_id_i=fixture.result_high_id_o;
    vector_regions_i=fixture.result_regions_o;vector_z_i=fixture.result_z_o;vector_low_i=fixture.result_low_o;
    vector_high_i=fixture.result_high_o;vector_ct0_i=fixture.result_ct0_o;
    vector_mu_i=fixture.result_mu_o;vector_seed_i=fixture.result_seed_o;vector_ctilde_i=fixture.result_ctilde_o;
    vector_bytes_i=fixture.result_bytes_o;vector_next_nonce_i=fixture.result_next_nonce_o;
    if(inject==1)vector_z_i[1]=vector_z_i[0];
    vector_take_ready_i=vtr && gv;vtwire=vector_take_valid_o && gv;
    wire_request=(busy_o || command_valid_i)?service_o:consumer;service_i=actual;
    if(busy_o || command_valid_i)begin
      wire_request.sign.valid=service_o.sign.valid && go;service_i.sign.ready=actual.sign.ready && go;
      wire_request.sign.done_ready=service_o.sign.done_ready && gs;service_i.sign.done_valid=actual.sign.done_valid && gs;
      wire_request.process_valid=service_o.process_valid && go;service_i.process_ready=actual.process_ready && go;
      wire_request.process_done_ready=service_o.process_done_ready && gs;service_i.process_done_valid=actual.process_done_valid && gs;
      wire_request.release_valid=service_o.release_valid && gv;service_i.release_ready=actual.release_ready && gv;
      if(inject==3 && dut.state==4)wire_request.sign.a_id=service_o.sign.a_id^16'd1;
      if(inject==4 && dut.state==7)wire_request.process_a_id=service_o.process_a_id^16'd1;
      if(inject==5 && dut.state==10)wire_request.sign.b_id=service_o.sign.b_id^16'd1;
      if(inject==6 && dut.state==5)service_i.sign.done_id=actual.sign.done_id^16'd1;
      if(inject==7 && dut.state==8)service_i.process_done_id=actual.process_done_id^16'd1;
      if(force_fault)service_i.fault=1;
      if(reading)wire_request=consumer;
    end
  end
  bit held=0,rheld=0;logic [37:0] old_done;logic [1730:0] old_result;
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held=0;rheld=0;end
    else if(monitor)begin
      elapsed++;if(elapsed>200000)$fatal(1,"Attempt check watchdog case%0d state%0d",case_no,dut.state);
      if(actual.fault || fixture.fault_o)$fatal(1,"Attempt check unexpected source/physical fault");
      if(held && (!done_valid_o || {done_code_o,done_detail_o,done_reason_o,done_reject_o,done_weight_o,done_id_o}!==old_done))$fatal(1,"Check held done changed");
      held=done_valid_o && !done_ready_i;old_done={done_code_o,done_detail_o,done_reason_o,done_reject_o,done_weight_o,done_id_o};
      if(rheld && !(clear_valid_i && clear_ready_o) && !(take_valid_i && take_ready_o) && (!result_valid_o ||
        {result_reject_o,result_regions_o,result_z_o,result_hint_o,result_z_id_o,result_mu_o,result_seed_o,result_ctilde_o,result_bytes_o,result_next_nonce_o}!==old_result))$fatal(1,"Check result changed");
      rheld=result_valid_o && !(clear_valid_i && clear_ready_o) && !(take_valid_i && take_ready_o);
      old_result={result_reject_o,result_regions_o,result_z_o,result_hint_o,result_z_id_o,result_mu_o,result_seed_o,result_ctilde_o,result_bytes_o,result_next_nonce_o};
      if(!result_valid_o && (result_reject_o || result_regions_o || result_z_o || result_hint_o || result_z_id_o || result_mu_o || result_seed_o || result_ctilde_o || result_bytes_o || result_next_nonce_o))$fatal(1,"Check unpublished private output");
      if(command_valid_i && command_ready_o)begin $fdisplay(fd,"C %0d %0d %0d %0d %0d %0d",case_no,p,jid,nonce,inject,abort_phase);commands++;end
      if(vtwire && vtr)begin $fdisplay(fd,"T %0d %016h %0d",case_no,actual.reserved,dut.spare_r);transfers++;end
      if(wire_request.sign.valid && actual.sign.ready)$fdisplay(fd,"O %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,dut.group_r,dut.ordinal_r,wire_request.sign.op,wire_request.sign.kind,wire_request.sign.a,wire_request.sign.b,wire_request.sign.dest,wire_request.sign.a_id,wire_request.sign.b_id,wire_request.sign.id);
      if(actual.sign.done_valid && wire_request.sign.done_ready)$fdisplay(fd,"Q %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,dut.group_r,dut.ordinal_r,service_i.sign.done_code,service_i.sign.done_id,service_i.sign.done_dest,service_i.sign.done_high,service_i.sign.done_reject,service_i.sign.done_weight);
      if(wire_request.process_valid && actual.process_ready)$fdisplay(fd,"P %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,dut.ordinal_r,wire_request.process_op,wire_request.process_inplace,wire_request.process_a,wire_request.process_b,wire_request.process_dest,wire_request.process_a_id,wire_request.process_b_id,wire_request.process_id);
      if(actual.process_done_valid && wire_request.process_done_ready)$fdisplay(fd,"R %0d %0d %0d %0d %0d",case_no,dut.ordinal_r,service_i.process_done_code,service_i.process_done_id,service_i.process_done_dest);
      if(wire_request.release_valid && actual.release_ready)$fdisplay(fd,"F %0d %0d %0d",case_no,dut.state,{wire_request.release_bank,wire_request.release_region});
      if(abort_phase==1 && dut.state==5 && fixture.upstream.setup.services.datapath.subsystem.sign_client.word_r==8)abort_hit=1;
      if(fixture.upstream.setup.services.datapath.subsystem.store.write_fire)begin
        $fdisplay(fd,"X %0d %0d %0d %0d %0d %06h",case_no,dut.ordinal_r,dut.state,fixture.upstream.setup.services.datapath.subsystem.store.write_region,fixture.upstream.setup.services.datapath.subsystem.store.write_index_i,fixture.upstream.setup.services.datapath.subsystem.store.write_data_i);writes++;
        if(fixture.upstream.setup.services.datapath.subsystem.store.write_index_i==31 &&
          ((abort_phase==2 && dut.state==8) || ((abort_phase==3 || abort_phase==5) && dut.state==11)))abort_hit=1;
      end
    end
  end
  task automatic reset_all();
    rst=1;fixture.reset_controls();command_valid_i=0;done_ready_i=0;clear_valid_i=0;take_valid_i=0;consumer='0;monitor=0;reading=0;force_fault=0;blocks=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || actual.reserved || result_valid_o || fault_o)$fatal(1,"Check reset state");
  endtask
  task automatic read_region(input int kind,ordinal,region);
    reading=1;
    for(int w=0;w<64;w++)begin
      consumer='0;consumer.read_valid=1;{consumer.read_bank,consumer.read_region}=6'(region);consumer.read_word=6'(w);
      do @(posedge clk);while(!actual.read_ready);@(negedge clk);#1;consumer.read_valid=0;
      while(!actual.response_valid)begin @(negedge clk);#1;end if(actual.response_error)$fatal(1,"Check read error");
      $fdisplay(fd,"V %0d %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,kind,ordinal,region,w,actual.response_id,actual.response_mode,actual.response_param,actual.response_ntt_domain,actual.response_data);reads++;
      repeat(w%3)@(negedge clk);#1;consumer.response_ready=1;@(posedge clk);@(negedge clk);#1;consumer='0;
    end reading=0;
  endtask
  task automatic release_external(input int region);
    consumer='0;consumer.release_valid=1;{consumer.release_bank,consumer.release_region}=6'(region);
    do @(posedge clk);while(!actual.release_ready);@(negedge clk);#1;consumer='0;$fdisplay(fd,"L %0d %0d",case_no,region);
  endtask
  initial begin
    int f;string directory,token,skhex,bodyhex;logic [255:0] rnd;bit aborted,rejected;int final_code;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_sign_accept_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d",token,count)!=2)$fatal(1,"Prepare check fixtures");
    fd=$fopen({directory,"/stage5_sign_accept_outputs.txt"},"w");$fdisplay(fd,"G %s",token);fixture.upstream.setup.fd=fd;reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %h %s %s",case_no,p,jid,nonce,inject,abort_phase,rnd,skhex,bodyhex)!=9 || case_no!=c)$fatal(1,"Check input row");
      monitor=0;if(fixture.key_valid_i && fixture.param_i!=p)reset_all();
      fixture.prepare_all(case_no,p,nonce,skhex,bodyhex,rnd);
      for(int j=0;j<(p==0?4:(p==1?5:7));j++)read_region(7,j,fixture.result_z_o[j]);
      for(int j=0;j<(p==0?4:(p==1?6:8));j++)begin read_region(8,j,fixture.result_low_o[j]);read_region(9,j,fixture.result_high_o[j]);read_region(10,j,fixture.result_ct0_o[j]);end
      blocks=0;if(inject==2)for(int r=0;r<64;r++)if(!actual.reserved[r])begin fixture.upstream.setup.seed_region(r);blocks[r]=1;end
      initial_map=actual.reserved;$fdisplay(fd,"N %0d %016h",case_no,initial_map);
      elapsed=0;abort_hit=0;monitor=1;command_id_i=16'(jid);command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;
      aborted=0;if(abort_phase!=0)begin
        if(abort_phase==4)while(!done_valid_o)begin @(negedge clk);#1;end else while(!abort_hit)begin @(negedge clk);#1;end
        if(abort_phase==5)begin force_fault=1;repeat(3)@(negedge clk);#1;if(!fault_o || done_valid_o || result_valid_o)$fatal(1,"Check fault not halted");end
        $fdisplay(fd,"Z %0d %0d %0d %0d %0d",case_no,abort_phase,dut.state,dut.group_r,dut.ordinal_r);aborts++;aborted=1;reset_all();
      end
      if(!aborted)begin
        while(!done_valid_o)begin @(negedge clk);#1;end
        rejected=done_reject_o;final_code=done_code_o;
        if(!done_code_o)$fdisplay(fd,"D %0d %0d %016h %011h %012h %0d %0d %0d %0128h %0128h %0128h",case_no,result_reject_o,result_regions_o,result_z_o,result_hint_o,result_z_id_o,result_bytes_o,result_next_nonce_o,result_mu_o,result_seed_o,result_ctilde_o);
        repeat(7)@(negedge clk);#1;$fdisplay(fd,"E %0d %0d %0d %0d %0d %0d %0d",case_no,done_id_o,done_code_o,done_detail_o,done_reject_o,done_reason_o,done_weight_o);
        completions++;if(done_code_o)errors++;else if(done_reject_o)rejections++;
        done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
        if(final_code==0)begin
          z=result_z_o;hints=result_hint_o;
          if(!rejected)begin
            for(int j=0;j<(p==0?4:(p==1?5:7));j++)read_region(0,j,z[j]);
            for(int j=0;j<(p==0?4:(p==1?6:8));j++)read_region(1,j,hints[j]);
          end
          fixture.clear_valid_i=1;repeat(4)begin @(negedge clk);#1;if(fixture.clear_ready_o || fixture.result_valid_o)$fatal(1,"Check old products owner lives");end fixture.clear_valid_i=0;
          reading=1;consumer='0;consumer.read_valid=1;{consumer.read_bank,consumer.read_region}=rejected?6'd50:z[0];
          do @(posedge clk);while(!actual.read_ready);@(negedge clk);#1;consumer.read_valid=0;
          while(!actual.response_valid)begin @(negedge clk);#1;end
          if(case_no%2)take_valid_i=1;else begin clear_valid_i=1;take_valid_i=1;end
          repeat(6)begin @(negedge clk);#1;if(clear_ready_o || take_ready_o)$fatal(1,"Check pending read bypassed");end
          $fdisplay(fd,"BARRIER %0d %023h",case_no,actual.response_data);consumer.response_ready=1;@(posedge clk);@(negedge clk);#1;consumer='0;reading=0;
          if(case_no%2)begin
            taken=result_regions_o;do @(posedge clk);while(!take_ready_o);
            $fdisplay(fd,"A %0d %016h %0d %0128h %0128h",case_no,taken,result_next_nonce_o,result_mu_o,result_seed_o);
            @(negedge clk);#1;take_valid_i=0;for(int r=0;r<64;r++)if(taken[r])release_external(r);
          end else begin
            if(take_ready_o)$fatal(1,"Check take bypassed clear priority");
            do @(posedge clk);while(!clear_ready_o);@(negedge clk);#1;clear_valid_i=0;take_valid_i=0;
          end
        end
        while(busy_o)begin @(negedge clk);#1;end
        for(int j=0;j<(p==0?12:(p==1?17:23));j++)read_region(4,j,fixture.key_handles_i[j]);read_region(5,0,50);
        for(int r=0;r<64;r++)if(blocks[r])begin read_region(6,r,r);release_external(r);end
        if(actual.reserved!==(fixture.key_regions_i|(64'd1<<50)|((inject==1 || inject==2)?fixture.result_regions_o:64'd0)))$fatal(1,"Check memory leak");
        $fdisplay(fd,"B %0d %016h",case_no,actual.reserved);
      end monitor=0;
    end
    $fdisplay(fd,"END %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",commands,completions,rejections,errors,aborts,transfers,writes,reads,fixture.upstream.setup.keys,fixture.upstream.setup.masks,fixture.upstream.setup.matrices);
    $fclose(f);$fclose(fd);$display("STAGE5N4H3_SIGN_ACCEPT_CAPTURE_PASS:%0d commands,%0d completions,%0d rejections,%0d errors,%0d aborts",commands,completions,rejections,errors,aborts);test_passed=1;$finish;
  end
  initial begin #(64'd800000000000);$fatal(1,"Check global watchdog case%0d",case_no);end
endmodule
