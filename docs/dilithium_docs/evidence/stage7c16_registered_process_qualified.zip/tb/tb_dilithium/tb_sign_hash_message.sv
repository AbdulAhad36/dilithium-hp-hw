`timescale 1ps/1ps
// One real main-owned shared service. Raw hashing and mask sampling share its
// existing Keccak pair and banks. Error digests are observed but not committed
// to the dependent-command cache. Only all-owner retirement releases formatter.
module tb_sign_hash_message #(parameter bit STABLE_PREFIX_INPUTS=0);
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o;logic [1:0] command_op_i=0,command_param_i=0;
  logic [15:0] command_id_i=0,command_message_len_i=0,command_nonce_i=0;logic [8:0] command_context_len_i=0;
  logic [511:0] command_tr_i=0,command_mu_i=0,command_mask_seed_i=0;
  logic [255:0] command_key_i=0,command_rnd_i=0;
  logic payload_valid_i=0,payload_ready_o,payload_last_i=0;logic [63:0] payload_data_i=0;
  logic [3:0] payload_bytes_i=0;logic [15:0] payload_index_i=0;
  logic request_valid_o,request_ready_i,request_sampling_o,request_mode_o;
  logic [1:0] request_param_o;logic [15:0] request_id_o,request_message_len_o,request_output_len_o;
  logic input_valid_o,input_ready_i,input_last_o;logic [63:0] input_data_o;
  logic [3:0] input_bytes_o;logic [15:0] input_index_o;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o;logic [15:0] done_id_o;
  sign_hash_message #(.STABLE_PREFIX_INPUTS(STABLE_PREFIX_INPUTS)) format(.*);
  request_t service_request;response_t service_response;
  dilithium_services services(.clk(clk),.rst(rst),.request_i(service_request),.response_o(service_response));
  int cycles=0,case_no=-1,op,p,jid,ctx,mlen,nonce,fault,fw,abort_phase,link,peer,count,bodylen,fd;
  int completions=0,errors=0,aborts=0,total_words=0,total_hashbytes=0,total_coefficients=0,total_peers=0;
  int beats=0,absorbed=0,desc=0,hold_checks=0,request_stalls=0,input_stalls=0,output_stalls=0,payload_stalls=0,owned_checks=0;
  int raw_hold=0,status_hold=0;
  bit enabled=0,manual_peer=0,force_request=1,force_input=0,force_output=0,force_status=0,peer_done=0,own_done=0,abort_now=0,test_passed=0;
  bit expected_core,peer_core;
  logic [511:0] digest_cache[256];int digest_bytes[256];bit cache_valid[256];
  logic rd=0,rr=0,rel=0;logic [5:0] rw=0;
  wire request_gate=!rst && !force_request && cycles%13>=5;
  wire input_gate=!rst && !force_input && cycles%11>=4;
  wire output_gate=!rst && !force_output && cycles%23>=8 && (!peer || desc!=0);
  wire status_gate=!rst && !force_status && cycles%17>=5;
  always @(negedge clk)if(!rst && enabled)begin
    if(force_output && service_response.raw_output_valid && abort_phase!=4 && abort_phase!=3)begin
      raw_hold++;if(raw_hold>=6)force_output=0;
    end
    if(force_status && service_response.status_valid && abort_phase!=5)begin
      status_hold++;if(status_hold>=6)force_status=0;
    end
  end
  assign request_ready_i=enabled && request_gate && (request_sampling_o?service_response.job_ready:service_response.raw_ready);
  assign input_ready_i=enabled && input_gate && (request_sampling_o?service_response.input_ready:service_response.raw_input_ready);
  always_comb begin
    service_request='0;
    service_request.raw_valid=manual_peer || (enabled && request_gate && request_valid_o && !request_sampling_o);
    service_request.raw_mode=manual_peer?1'b1:request_mode_o;
    service_request.raw_id=manual_peer?16'(53000+case_no):request_id_o;
    service_request.raw_message_len=manual_peer?16'd0:request_message_len_o;
    service_request.raw_output_len=manual_peer?16'd16:request_output_len_o;
    service_request.raw_input_data=input_data_o;
    service_request.raw_input_valid=enabled && input_gate && input_valid_o && !request_sampling_o;
    service_request.raw_output_ready=output_gate;service_request.raw_done_ready=status_gate;
    service_request.job_valid=enabled && request_gate && request_valid_o && request_sampling_o;
    service_request.job_id=request_id_o;service_request.job_param=request_param_o;service_request.job_mode=2;
    service_request.message_len=request_message_len_o;service_request.input_data=input_data_o;
    service_request.input_valid=enabled && input_gate && input_valid_o && request_sampling_o;
    service_request.status_ready=status_gate;
    service_request.read_valid=rd;service_request.read_word=rw;service_request.response_ready=rr;
    service_request.release_valid=rel;
  end
  bit ph=0,dh=0,ih=0,rh=0,fh=0;logic [84:0] previous_payload;
  logic [51:0] previous_descriptor;logic [84:0] previous_input;
  logic [149:0] previous_raw;logic [18:0] previous_done;
  wire [84:0] observed_payload={payload_data_i,payload_bytes_i,payload_index_i,payload_last_i};
  wire [51:0] observed_descriptor={request_sampling_o,request_mode_o,request_param_o,request_id_o,request_message_len_o,request_output_len_o};
  wire [84:0] observed_input={input_data_o,input_bytes_o,input_index_o,input_last_o};
  always @(posedge clk)begin
    cycles<=cycles+1;
    if(rst)begin ph=0;dh=0;ih=0;rh=0;fh=0;end
    else begin
      if(service_response.fault)$fatal(1,"Signing hash service fault case%0d",case_no);
      if(ph && !done_valid_o && !format.draining_r && (!payload_valid_i || observed_payload!==previous_payload))$fatal(1,"Held signing payload changed");
      if(dh && (!request_valid_o || observed_descriptor!==previous_descriptor))$fatal(1,"Signing descriptor changed under stall");
      if(ih && (!input_valid_o || observed_input!==previous_input))$fatal(1,"Signing absorption changed under stall");
      if(rh && (!service_response.raw_output_valid || {service_response.raw_output_data,service_response.raw_output_bytes,service_response.raw_output_core,service_response.raw_output_id}!==previous_raw))$fatal(1,"Shared raw output changed");
      if(fh && (!done_valid_o || {done_code_o,done_id_o}!==previous_done))$fatal(1,"Signing formatter completion changed");
      ph=payload_valid_i && !payload_ready_o;previous_payload=observed_payload;
      dh=request_valid_o && !request_ready_i;previous_descriptor=observed_descriptor;
      ih=input_valid_o && !input_ready_i;previous_input=observed_input;
      rh=service_response.raw_output_valid && !service_request.raw_output_ready;
      previous_raw={service_response.raw_output_data,service_response.raw_output_bytes,service_response.raw_output_core,service_response.raw_output_id};
      fh=done_valid_o && !done_ready_i;previous_done={done_code_o,done_id_o};
      request_stalls+=int'(dh);input_stalls+=int'(ih);output_stalls+=int'(rh);payload_stalls+=int'(ph);
      if(service_response.status_valid && !service_request.status_ready)output_stalls++;
      if(service_response.active!=0)owned_checks++;
      if(command_valid_i && command_ready_o)$fdisplay(fd,"C %0d %0d %0d %0d",case_no,command_op_i,command_param_i,command_id_i);
      if(manual_peer && service_response.raw_ready)begin
        peer_core=service_response.raw_core;$fdisplay(fd,"G %0d %0d",case_no,peer_core);
      end
      if(request_valid_o && request_ready_i)begin
        if(desc!=0)$fatal(1,"Duplicate signing descriptor");expected_core=request_sampling_o?service_response.job_core:service_response.raw_core;desc++;
        $fdisplay(fd,"D %0d %0d %0d %0d %0d %0d %0d",case_no,request_sampling_o,request_id_o,request_param_o,request_message_len_o,request_output_len_o,expected_core);
      end
      if(payload_valid_i && payload_ready_o)$fdisplay(fd,"P %0d %0d %0d %0d %016h",case_no,payload_index_i,payload_bytes_i,payload_last_i,payload_data_i);
      if(input_valid_o && input_ready_i)begin
        $fdisplay(fd,"W %0d %0d %0d %0d %016h",case_no,input_index_o,input_bytes_o,input_last_o,input_data_o);absorbed++;total_words++;
      end
      if(service_response.raw_output_valid && service_request.raw_output_ready)begin
        if(peer && service_response.raw_output_id==16'(53000+case_no))begin
          if(service_response.raw_output_core!==peer_core || service_response.raw_output_bytes!=16)$fatal(1,"Peer raw ownership");
          $fdisplay(fd,"H %0d %0d %0d %032h",case_no,peer_core,service_response.raw_output_id,service_response.raw_output_data);
        end else begin
          if(service_response.raw_output_id!==16'(jid) || service_response.raw_output_core!==expected_core || service_response.raw_output_bytes!=16 || beats>=4)$fatal(1,"Signing hash output ownership");
          $fdisplay(fd,"R %0d %0d %0d %0d %0d %032h",case_no,beats,service_response.raw_output_id,service_response.raw_output_core,service_response.raw_output_bytes,service_response.raw_output_data);
          digest_cache[case_no][128*beats+:128]=service_response.raw_output_data;
          beats++;digest_bytes[case_no]+=16;total_hashbytes+=16;
        end
      end
      if(service_response.raw_done_valid && service_request.raw_done_ready)begin
        if(peer && service_response.raw_done_id==16'(53000+case_no))begin
          if(service_response.raw_done_core!==peer_core || peer_done)$fatal(1,"Peer retirement");peer_done=1;total_peers++;
          $fdisplay(fd,"Q %0d %0d %0d",case_no,service_response.raw_done_id,peer_core);
        end else begin
          if(service_response.raw_done_id!==16'(jid) || service_response.raw_done_core!==expected_core || own_done)$fatal(1,"Signing raw retirement");
          own_done=1;$fdisplay(fd,"S %0d %0d %0d",case_no,service_response.raw_done_id,expected_core);
        end
      end
      if(service_response.status_valid && service_request.status_ready)begin
        if(service_response.status_id!==16'(jid) || service_response.status_core!==expected_core || service_response.status_code!=0 || own_done)$fatal(1,"Mask retirement");
        own_done=1;$fdisplay(fd,"S %0d %0d %0d",case_no,service_response.status_id,expected_core);
      end
    end
  end
  task automatic reset_all();
    @(negedge clk);#1;rst=1;command_valid_i=0;payload_valid_i=0;enabled=0;manual_peer=0;rd=0;rr=0;rel=0;done_ready_i=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || request_valid_o || input_valid_o || done_valid_o || service_response.active || service_response.reserved || service_response.raw_output_valid)$fatal(1,"Signing hash reset ownership");
  endtask
  task automatic witness();
    $fdisplay(fd,"T %0d %0d %0d %0d %0d %0d %0d",case_no,hold_checks,request_stalls,input_stalls,output_stalls,payload_stalls,owned_checks);
  endtask
  task automatic read_mask();
    for(int w=0;w<64;w++)begin
      @(negedge clk);#1;rw=6'(w);rd=1;do @(posedge clk);while(!service_response.read_ready);
      @(negedge clk);#1;rd=0;do begin @(negedge clk);#1;end while(!service_response.response_valid);
      if(service_response.response_error || service_response.response_bank!=0 || service_response.response_region!=0 || service_response.response_word!=w)$fatal(1,"Mask result read");
      $fdisplay(fd,"V %0d %0d %023h %0d %0d %0d",case_no,w,service_response.response_data,service_response.response_id,service_response.response_param,service_response.response_ntt_domain);
      total_coefficients+=4;rr=1;@(posedge clk);@(negedge clk);#1;rr=0;
    end
    rel=1;do @(posedge clk);while(!service_response.release_ready);@(negedge clk);#1;rel=0;
  endtask
  initial begin
    int f,index,n;string directory,token,bodyhex;byte unsigned octet;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_sign_hash_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d",token,count)!=2 || count>256)$fatal(1,"Prepare signing hash fixtures");
    fd=$fopen({directory,"/stage5_sign_hash_outputs.txt"},"w");$fdisplay(fd,"H %s",token);
    for(int i=0;i<256;i++)begin digest_cache[i]=0;digest_bytes[i]=0;cache_valid[i]=0;end
    reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %d %d %d %d %d %d %h %h %h %h %h %d %s",case_no,op,p,jid,ctx,mlen,nonce,fault,fw,abort_phase,link,peer,
        command_tr_i,command_key_i,command_rnd_i,command_mu_i,command_mask_seed_i,bodylen,bodyhex)!=19 || case_no!=c)$fatal(1,"Signing hash row");
      desc=0;absorbed=0;beats=0;own_done=0;peer_done=!peer;abort_now=0;
      hold_checks=0;request_stalls=0;input_stalls=0;output_stalls=0;payload_stalls=0;owned_checks=0;
      enabled=0;force_request=1;force_input=0;force_output=1;force_status=op==3;raw_hold=0;status_hold=0;
      if(peer)begin
        manual_peer=1;do @(posedge clk);while(!service_response.raw_ready);@(negedge clk);#1;manual_peer=0;
      end
      command_op_i=2'(op);command_param_i=2'(p);command_id_i=16'(jid);command_context_len_i=9'(ctx);command_message_len_i=16'(mlen);command_nonce_i=16'(nonce);
      if(link>=0)begin
        if(!cache_valid[link] || digest_bytes[link]!=64)$fatal(1,"Uncommitted linked digest");
        if(op==3)command_mask_seed_i=digest_cache[link];else command_mu_i=digest_cache[link];
        $fdisplay(fd,"L %0d %0d %0128h",case_no,link,digest_cache[link]);
      end
      enabled=1;command_valid_i=1;do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;
      // Poison all unowned command ports;descriptor/body must use snapshots.
      if(!STABLE_PREFIX_INPUTS)begin
        command_tr_i='1;command_key_i='1;command_rnd_i='1;command_mu_i='1;command_mask_seed_i='1;
      end
      command_op_i=3;command_param_i=3;command_id_i=0;command_context_len_i=511;command_message_len_i=65535;command_nonce_i=0;
      repeat(6)@(negedge clk);#1;
      if(abort_phase==1)abort_now=1;else force_request=0;
      if(abort_phase==2)begin
        do begin @(negedge clk);#1;end while(absorbed<2);force_input=1;abort_now=1;
      end
      for(int w=0;w<(bodylen+7)/8 && !abort_now;w++)begin
        if(done_valid_o || format.draining_r)break;
        payload_data_i='1;n=bodylen-8*w;if(n>8)n=8;
        for(int b=0;b<n;b++)begin index=$sscanf(bodyhex.substr(2*(8*w+b),2*(8*w+b)+1),"%h",octet);if(index!=1)$fatal(1,"Payload byte");payload_data_i[8*b+:8]=octet;end
        payload_index_i=16'(w ^ ((fault==1 && w==fw)?1:0));payload_bytes_i=(fault==2 && w==fw)?4'd0:4'(n);
        payload_last_i=(8*(w+1)>=bodylen) ^ (fault==3 && w==fw);payload_valid_i=1;
        do @(posedge clk);while(!payload_ready_o && !done_valid_o && !format.draining_r);
        @(negedge clk);#1;payload_valid_i=0;
      end
      if(abort_phase!=0)begin
        case(abort_phase)
          1,2:begin end
          3:do begin @(negedge clk);#1;end while(!done_valid_o);
          4:do begin @(negedge clk);#1;end while(!service_response.raw_output_valid);
          5:do begin @(negedge clk);#1;end while(!service_response.status_valid);
        endcase
        repeat(6)begin @(negedge clk);#1;hold_checks++;end
        $fdisplay(fd,"A %0d %0d",case_no,abort_phase);witness();aborts++;reset_all();continue;
      end
      do begin @(negedge clk);#1;end while(!done_valid_o || (desc && (!own_done || !peer_done || service_response.active!=0)));
      if(desc && op==3)read_mask();
      repeat(6)begin @(negedge clk);#1;hold_checks++;if(command_ready_o)$fatal(1,"Formatter retired before owner release");end
      $fdisplay(fd,"E %0d %0d %0d",case_no,done_id_o,done_code_o);witness();completions++;if(done_code_o!=0)errors++;
      cache_valid[c]=done_code_o==0 && op!=3;done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;enabled=0;
      if(service_response.active || service_response.reserved)$fatal(1,"Signing hash leaked service owner");
    end
    $fdisplay(fd,"F %0d %0d %0d %0d %0d %0d %0d %0d",count,completions,errors,aborts,total_words,total_hashbytes,total_coefficients,total_peers);
    $fclose(f);$fclose(fd);$display("STAGE5N4B_SIGN_HASH_CAPTURE_PASS:%0d commands,%0d completions,%0d errors,%0d resets",count,completions,errors,aborts);
    test_passed=1;$finish;
  end
  initial begin #(64'd100000000000);$fatal(1,"Signing hash watchdog case%0d format%0d",case_no,format.state);end
endmodule
