`timescale 1ps/1ps
module tb_sign_attempt_loop;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,fault_o,context_valid_i;
  logic [1:0] context_param_i;logic [15:0] context_id_i;logic [63:0] context_regions_i;logic [22:0][5:0] context_handles_i;
  logic [255:0] context_rho_i,context_key_i;logic [511:0] context_tr_i;
  logic [15:0] command_id_i=0,command_message_len_i=169;logic [16:0] command_nonce_i=0;
  logic [8:0] command_context_len_i=7;logic [5:0] command_base_i=32;logic [255:0] command_rnd_i=0;
  logic payload_valid_i=0,payload_ready_o;logic [63:0] payload_data_i=0;logic [3:0] payload_bytes_i=8;
  logic [15:0] payload_index_i=0;logic payload_last_i=0;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o,done_stage_o,done_detail_o;logic [15:0] done_id_o;
  logic [16:0] attempts_o,rejections_o,next_nonce_o;logic result_valid_o;logic [63:0] result_regions_o;
  logic [6:0][5:0] result_z_o;logic [7:0][5:0] result_hint_o;logic [511:0] result_ctilde_o;logic [6:0] result_bytes_o;
  logic clear_valid_i=0,clear_ready_o,take_valid_i=0,take_ready_o;
  request_t service_o,wire_request,consumer='0;response_t service_i,actual;
  sign_attempt_loop dut(.*);
  sign_attempt_setup fixture(.clk(clk),.rst(rst),.request_i(wire_request),.response_o(actual));
  int case_no=-1,p,jid,nonce,inject,abort_phase,fd,count,cycles=0,elapsed=0,raw_index=0,job_index=0;
  int commands=0,done_count=0,errors=0,aborts=0,starts=0,rejects=0,raws=0,jobs=0,ywrites=0,reads=0;
  bit monitor=0,reading=0,force_fault=0,abort_hit=0,test_passed=0;
  wire gr=cycles%7>2,gi=cycles%11>3,go=cycles%13>4,gs=cycles%17>5,gl=cycles%5>1;
  always_comb begin
    context_valid_i=fixture.context_valid_i;context_param_i=fixture.context_param_i;context_id_i=fixture.context_id_i;
    context_regions_i=fixture.context_regions_i;context_handles_i=fixture.kh;context_rho_i=fixture.context_rho_i;
    context_key_i=fixture.key;context_tr_i=fixture.tr;
    wire_request=(busy_o || command_valid_i)?service_o:consumer;service_i=actual;
    if(busy_o || command_valid_i)begin
      wire_request.raw_valid=service_o.raw_valid && gr;service_i.raw_ready=actual.raw_ready && gr;
      wire_request.job_valid=service_o.job_valid && gr;service_i.job_ready=actual.job_ready && gr;
      wire_request.raw_input_valid=service_o.raw_input_valid && gi;service_i.raw_input_ready=actual.raw_input_ready && gi;
      wire_request.input_valid=service_o.input_valid && gi;service_i.input_ready=actual.input_ready && gi;
      wire_request.raw_output_ready=service_o.raw_output_ready && go;service_i.raw_output_valid=actual.raw_output_valid && go;
      wire_request.raw_done_ready=service_o.raw_done_ready && gs;service_i.raw_done_valid=actual.raw_done_valid && gs;
      wire_request.status_ready=service_o.status_ready && gs;service_i.status_valid=actual.status_valid && gs;
      wire_request.op_valid=service_o.op_valid && gr;service_i.op_ready=actual.op_ready && gr;
      wire_request.op_done_ready=service_o.op_done_ready && gs;service_i.op_done_valid=actual.op_done_valid && gs;
      wire_request.row_valid=service_o.row_valid && gr;service_i.row_ready=actual.row_ready && gr;
      wire_request.row_done_ready=service_o.row_done_ready && gs;service_i.row_done_valid=actual.row_done_valid && gs;
      wire_request.sign.valid=service_o.sign.valid && gr;service_i.sign.ready=actual.sign.ready && gr;
      wire_request.sign.done_ready=service_o.sign.done_ready && gs;service_i.sign.done_valid=actual.sign.done_valid && gs;
      wire_request.process_valid=service_o.process_valid && gr;service_i.process_ready=actual.process_ready && gr;
      wire_request.process_done_ready=service_o.process_done_ready && gs;service_i.process_done_valid=actual.process_done_valid && gs;
      wire_request.release_valid=service_o.release_valid && gl;service_i.release_ready=actual.release_ready && gl;
      if(inject==2 && dut.retry_r && dut.stage_r==0 && dut.masks.ordinal_r==1)service_i.status_id=actual.status_id^16'd1;
      if(inject==3 && dut.retry_r && dut.stage_r==1)wire_request.op_a_id=service_o.op_a_id^16'd1;
      if(inject==4 && dut.retry_r && dut.stage_r==5)service_i.sign.done_id=actual.sign.done_id^16'd1;
      if(force_fault)service_i.fault=1;
      if(reading)wire_request=consumer;
    end
  end
  logic [75:0] held_done;logic [672:0] held_result;bit held=0,rheld=0;
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held=0;rheld=0;end
    else if(monitor)begin
      elapsed++;if(elapsed>2500000)$fatal(1,"Retry watchdog case%0d state%0d stage%0d attempt%0d",case_no,dut.state,dut.stage_r,attempts_o);
      if(actual.fault || fixture.kfault)$fatal(1,"Retry physical/key fault");
      if(held && (!done_valid_o || {done_code_o,done_stage_o,done_detail_o,done_id_o,attempts_o,rejections_o,next_nonce_o}!==held_done))$fatal(1,"Retry held done changed");
      held=done_valid_o && !done_ready_i;held_done={done_code_o,done_stage_o,done_detail_o,done_id_o,attempts_o,rejections_o,next_nonce_o};
      if(rheld && !(clear_valid_i && clear_ready_o) && !(take_valid_i && take_ready_o) && (!result_valid_o ||
        {result_regions_o,result_z_o,result_hint_o,result_ctilde_o,result_bytes_o}!==held_result))$fatal(1,"Retry retained result changed");
      rheld=result_valid_o && !(clear_valid_i && clear_ready_o) && !(take_valid_i && take_ready_o);
      held_result={result_regions_o,result_z_o,result_hint_o,result_ctilde_o,result_bytes_o};
      if(!result_valid_o && (result_regions_o || result_z_o || result_hint_o || result_ctilde_o || result_bytes_o))$fatal(1,"Retry result exposed early");
      if(command_valid_i && command_ready_o)begin $fdisplay(fd,"C %0d %0d %0d %0d %0d %0d",case_no,p,jid,nonce,inject,abort_phase);commands++;end
      for(int s=0;s<6;s++)begin
        if(dut.cv[s] && dut.cr[s])begin
          $fdisplay(fd,"S %0d %0d %0d %0d",case_no,s==0?attempts_o+1:attempts_o,dut.nonce_r,s);
          if(s==0)starts++;
        end
        if(dut.dv[s] && dut.dr[s])begin
          $fdisplay(fd,"D %0d %0d %0d %0d %0d %0d %0d %0d %016h %0d %0d %0d",case_no,attempts_o,dut.nonce_r,s,dut.dc[s],dut.dd[s],dut.di[s],dut.rv[s],dut.maps[s],s==5?dut.reject:0,s==5?dut.reason:0,s==5?dut.weight:0);
          if(s==0 && dut.dc[0]==0)$fdisplay(fd,"M %0d %0d %0d %016h %011h %0128h %0128h",case_no,attempts_o,dut.nonce_r,dut.maps[0],dut.y,dut.mu,dut.seed);
          if(s==5 && dut.dc[5]==0 && dut.reject)rejects++;
        end
      end
      if(dut.state==4 && dut.tv[5] && dut.tr[5])$fdisplay(fd,"L %0d %0d %0d %0d %016h %0128h %0128h",case_no,attempts_o,dut.nonce_r,dut.out_nonce,actual.reserved,dut.out_mu,dut.out_seed);
      if(wire_request.raw_valid && actual.raw_ready)begin
        raw_index=0;raws++;$fdisplay(fd,"O %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,attempts_o,dut.nonce_r,dut.stage_r,actual.raw_core,wire_request.raw_id,wire_request.raw_message_len,wire_request.raw_output_len,wire_request.raw_mode);
      end
      if(wire_request.raw_input_valid && actual.raw_input_ready)begin $fdisplay(fd,"I %0d %0d %016h",case_no,raw_index,wire_request.raw_input_data);raw_index++;end
      if(actual.raw_output_valid && wire_request.raw_output_ready)$fdisplay(fd,"H %0d %0d %0d %0d %032h",case_no,actual.raw_output_core,actual.raw_output_id,actual.raw_output_bytes,actual.raw_output_data);
      if(actual.raw_done_valid && wire_request.raw_done_ready)$fdisplay(fd,"Q %0d %0d %0d",case_no,actual.raw_done_core,actual.raw_done_id);
      if(dut.stage_r==0 && wire_request.job_valid && actual.job_ready)begin
        job_index=0;jobs++;$fdisplay(fd,"J %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,attempts_o,dut.nonce_r,dut.masks.ordinal_r,actual.job_core,wire_request.job_id,{wire_request.job_bank,wire_request.job_region},wire_request.job_mode,wire_request.message_len,wire_request.job_param);
      end
      if(dut.stage_r==0 && wire_request.input_valid && actual.input_ready)begin $fdisplay(fd,"W %0d %0d %016h",case_no,job_index,wire_request.input_data);job_index++;end
      if(dut.stage_r==0 && actual.status_valid && wire_request.status_ready)$fdisplay(fd,"T %0d %0d %0d %0d",case_no,service_i.status_core,service_i.status_id,service_i.status_code);
      if(inject==3 && dut.retry_r && dut.stage_r==1 && wire_request.op_valid && actual.op_ready)$fdisplay(fd,"BAD %0d %0d %0d %0d",case_no,wire_request.op_a_region,wire_request.op_a_id,wire_request.op_id);
      if(inject==4 && dut.retry_r && dut.stage_r==5 && actual.sign.done_valid && wire_request.sign.done_ready)$fdisplay(fd,"BAD %0d %0d %0d %0d",case_no,actual.sign.done_id,service_i.sign.done_id,service_i.sign.done_code);
      if(fixture.services.datapath.subsystem.store.alloc_fire)$fdisplay(fd,"A %0d %0d %0d %0d %0d %0d %0d %016h",case_no,
        fixture.services.datapath.subsystem.store.alloc_region,fixture.services.datapath.subsystem.store.alloc_rewrite_i,
        fixture.services.datapath.subsystem.store.alloc_id_i,fixture.services.datapath.subsystem.store.alloc_mode_i,
        fixture.services.datapath.subsystem.store.alloc_param_i,
        fixture.services.datapath.subsystem.store.alloc_compute_i?fixture.services.datapath.subsystem.store.alloc_ntt_domain_i:fixture.services.datapath.subsystem.store.alloc_mode_i==0,actual.reserved);
      if(fixture.services.datapath.subsystem.store.finish_fire)$fdisplay(fd,"COM %0d %0d %0d %0d %0d",case_no,
        fixture.services.datapath.subsystem.store.finish_region,fixture.services.datapath.subsystem.store.finish_id_i,
        fixture.services.datapath.subsystem.store.finish_code_i,
        fixture.services.datapath.subsystem.store.writer_count_r[fixture.services.datapath.subsystem.store.finish_core_i]);
      // Observe the physical port too:the row MAC releases scratch internally.
      if(fixture.services.datapath.subsystem.store.release_fire)begin
        if(context_regions_i[fixture.services.datapath.subsystem.store.release_region] || fixture.services.datapath.subsystem.store.release_region==50)$fatal(1,"Retry foreign release");
        $fdisplay(fd,"F %0d %0d %016h",case_no,fixture.services.datapath.subsystem.store.release_region,actual.reserved);
      end
      if(fixture.services.datapath.subsystem.store.write_fire)begin
        if(dut.stage_r==0)begin
          $fdisplay(fd,"X %0d %0d %0d %0d %0d %0d %06h",case_no,attempts_o,dut.nonce_r,dut.masks.ordinal_r,fixture.services.datapath.subsystem.store.write_region,fixture.services.datapath.subsystem.store.write_index_i,fixture.services.datapath.subsystem.store.write_data_i);ywrites++;
          if(dut.retry_r && fixture.services.datapath.subsystem.store.write_index_i==31 && (abort_phase==1 || abort_phase==5))abort_hit=1;
        end
        if(dut.retry_r && dut.stage_r==4 && fixture.services.datapath.subsystem.store.write_index_i==31 && abort_phase==2)abort_hit=1;
      end
      if(dut.retry_r && dut.stage_r==5 && dut.bounds.state==5 && fixture.services.datapath.subsystem.sign_client.word_r==8 && abort_phase==3)abort_hit=1;
    end
  end
  task automatic reset_all();
    rst=1;fixture.reset_controls();command_valid_i=0;done_ready_i=0;clear_valid_i=0;take_valid_i=0;payload_valid_i=0;
    consumer='0;monitor=0;reading=0;force_fault=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || result_valid_o || actual.reserved || fault_o)$fatal(1,"Retry reset state");
  endtask
  task automatic send_body(input string bodyhex);
    int parsed;byte unsigned b;
    for(int w=0;w<22;w++)begin
      payload_data_i=0;for(int j=0;j<8;j++)begin parsed=$sscanf(bodyhex.substr(2*(8*w+j),2*(8*w+j)+1),"%h",b);if(parsed!=1)$fatal(1,"Retry body parse");payload_data_i[8*j+:8]=b;end
      payload_index_i=16'(w);if(inject==1 && w==2)payload_index_i=9;payload_last_i=w==21;payload_valid_i=1;
      do @(posedge clk);while(!payload_ready_o && !done_valid_o && !fault_o && !rst);
      @(negedge clk);#1;payload_valid_i=0;if(done_valid_o || fault_o || rst)return;
    end
  endtask
  task automatic read_region(input int kind,ordinal,region);
    reading=1;
    for(int w=0;w<64;w++)begin
      consumer='0;consumer.read_valid=1;{consumer.read_bank,consumer.read_region}=6'(region);consumer.read_word=6'(w);
      do @(posedge clk);while(!actual.read_ready);@(negedge clk);#1;consumer.read_valid=0;
      while(!actual.response_valid)begin @(negedge clk);#1;end if(actual.response_error)$fatal(1,"Retry read error");
      $fdisplay(fd,"V %0d %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,kind,ordinal,region,w,actual.response_id,actual.response_mode,actual.response_param,actual.response_ntt_domain,actual.response_data);reads++;
      repeat(w%3)@(negedge clk);#1;consumer.response_ready=1;@(posedge clk);@(negedge clk);#1;consumer='0;
    end reading=0;
  endtask
  initial begin
    int f;string directory,token,skhex,bodyhex;bit aborted;logic [63:0] taken;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_sign_retry_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d",token,count)!=2)$fatal(1,"Prepare retry fixtures");
    fd=$fopen({directory,"/stage5_sign_retry_outputs.txt"},"w");$fdisplay(fd,"G %s",token);fixture.fd=fd;reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %h %s %s",case_no,p,jid,nonce,inject,abort_phase,command_rnd_i,skhex,bodyhex)!=9 || case_no!=c)$fatal(1,"Retry input row");
      monitor=0;if(context_valid_i && context_param_i!=p)reset_all();fixture.case_no=case_no;fixture.p=p;fixture.sklen=skhex.len()/2;
      if(!context_valid_i)fixture.prepare_key(skhex);
      monitor=1;elapsed=0;abort_hit=0;command_id_i=16'(jid);command_nonce_i=17'(nonce);command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;
      if(nonce<65536)fork send_body(bodyhex);join_none
      aborted=0;
      if(abort_phase!=0)begin
        if(abort_phase==4)while(!done_valid_o)begin @(negedge clk);#1;end else while(!abort_hit)begin @(negedge clk);#1;end
        if(abort_phase==5)begin force_fault=1;repeat(3)@(negedge clk);#1;if(!fault_o || done_valid_o || result_valid_o)$fatal(1,"Retry fatal not halted");end
        $fdisplay(fd,"Z %0d %0d %0d %0d %0d %0d",case_no,abort_phase,dut.state,dut.stage_r,attempts_o,rejections_o);aborts++;aborted=1;reset_all();wait fork;
      end
      if(!aborted)begin
        while(!done_valid_o)begin @(negedge clk);#1;end
        repeat(7)@(negedge clk);#1;wait fork;
        if(result_valid_o)$fdisplay(fd,"R %0d %016h %011h %012h %0d %0128h",case_no,result_regions_o,result_z_o,result_hint_o,result_bytes_o,result_ctilde_o);
        $fdisplay(fd,"E %0d %0d %0d %0d %0d %0d %0d %0d",case_no,done_id_o,done_code_o,done_stage_o,done_detail_o,attempts_o,rejections_o,next_nonce_o);
        done_count++;if(done_code_o)errors++;
        done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
        if(result_valid_o)begin
          for(int j=0;j<(p==0?4:(p==1?5:7));j++)read_region(0,j,result_z_o[j]);
          for(int j=0;j<(p==0?4:(p==1?6:8));j++)read_region(1,j,result_hint_o[j]);
          reading=1;consumer='0;consumer.read_valid=1;{consumer.read_bank,consumer.read_region}=result_z_o[0];
          do @(posedge clk);while(!actual.read_ready);@(negedge clk);#1;consumer.read_valid=0;
          while(!actual.response_valid)begin @(negedge clk);#1;end
          if(case_no%2)take_valid_i=1;else begin clear_valid_i=1;take_valid_i=1;end
          repeat(6)begin @(negedge clk);#1;if(clear_ready_o || take_ready_o)$fatal(1,"Retry read barrier bypassed");end
          $fdisplay(fd,"BARRIER %0d %023h",case_no,actual.response_data);consumer.response_ready=1;@(posedge clk);@(negedge clk);#1;consumer='0;reading=0;
          if(case_no%2)begin
            taken=result_regions_o;do @(posedge clk);while(!take_ready_o);$fdisplay(fd,"TAKE %0d %016h",case_no,taken);
            @(negedge clk);#1;take_valid_i=0;
            for(int r=0;r<64;r++)if(taken[r])begin consumer.release_valid=1;{consumer.release_bank,consumer.release_region}=6'(r);do @(posedge clk);while(!actual.release_ready);@(negedge clk);#1;consumer='0;end
          end else begin
            if(take_ready_o)$fatal(1,"Retry clear priority bypassed");do @(posedge clk);while(!clear_ready_o);@(negedge clk);#1;clear_valid_i=0;take_valid_i=0;
          end
        end
        while(busy_o)begin @(negedge clk);#1;end
        for(int j=0;j<(p==0?12:(p==1?17:23));j++)read_region(4,j,context_handles_i[j]);read_region(5,0,50);
        if(actual.reserved!==(context_regions_i|(64'd1<<50)))$fatal(1,"Retry leaked memory");
        $fdisplay(fd,"B %0d %016h",case_no,actual.reserved);
      end monitor=0;
    end
    $fdisplay(fd,"END %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",commands,done_count,errors,aborts,starts,rejects,raws,jobs,ywrites,reads,fixture.keys);
    $fclose(f);$fclose(fd);$display("STAGE5N4H4_SIGN_RETRY_CAPTURE_PASS:%0d commands,%0d done,%0d errors,%0d aborts",commands,done_count,errors,aborts);test_passed=1;$finish;
  end
  initial begin #(64'd2000000000000);$fatal(1,"Retry global watchdog case%0d",case_no);end
endmodule
