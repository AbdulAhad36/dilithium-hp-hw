`timescale 1ps/1ps
`define VC dut.g_verify.verifier
`define ST dut.services.datapath.subsystem.store
module tb_full_verify #(parameter bit NIST_VECTORS=0);
  localparam string STEM=NIST_VECTORS?"stage5_nist_verify":"stage5_full_verify";
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic start_valid_i=0,start_ready_o,busy_o;logic [1:0] start_op_i=0,start_param_i=0;
  logic [15:0] start_id_i=0,start_message_len_i=0,start_signature_len_i=0;logic [8:0] start_context_len_i=0;
  logic [255:0] start_seed_i=0,start_rnd_i=0;
  logic verify_input_valid_i=0,verify_input_ready_o,verify_input_last_i=0,verify_accept_o;
  logic [63:0] verify_input_data_i=0;logic [3:0] verify_input_bytes_i=0;logic [15:0] verify_input_index_i=0;
  logic sign_input_valid_i=0,sign_input_ready_o,sign_input_last_i=0;logic [63:0] sign_input_data_i=0;
  logic [3:0] sign_input_bytes_i=0;logic [15:0] sign_input_index_i=0;
  logic signature_valid_o,signature_ready_i=0,signature_last_o;logic [63:0] signature_data_o;
  logic [3:0] signature_bytes_o;logic [9:0] signature_index_o;logic [15:0] signature_id_o;
  logic key_valid_o,key_ready_i=0,key_type_o,key_last_o;logic [63:0] key_data_o;
  logic [3:0] key_bytes_o;logic [9:0] key_index_o;logic [15:0] key_id_o;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o,done_stage_o,done_detail_o;logic [15:0] done_id_o;
  logic [16:0] sign_attempts_o,sign_rejections_o,sign_next_nonce_o;
  logic row_result_valid_o,row_result_ready_i=0;logic [3:0] row_result_index_o;logic [5:0] row_result_region_o;logic [15:0] row_result_id_o;
  logic seed_valid_o;logic [255:0] rho_o,key_o;logic [511:0] rhoprime_o;
  logic read_valid_i=1,read_ready_o,response_valid_o,response_error_o,response_ready_i=1;
  logic [1:0] read_bank_i=3,response_bank_o,response_mode_o,response_param_o;logic [3:0] read_region_i=15,response_region_o;
  logic [5:0] read_word_i=7,response_word_o;logic [91:0] response_data_o;logic [15:0] response_id_o;
  logic response_ntt_domain_o,response_small_o;logic [63:0] reserved_o,complete_o;logic fault_o;
  dilithium #(.FULL_KEYGEN(1)) dut(.*);
  int fd,case_no=-1,op,p,jid,injection,abort_phase,code,stage,detail,ctxlen,mlen,siglen,frame=0,cycles=0,elapsed=0,count;
  int commands=0,completions=0,aborts=0,inputs=0,allocs=0,writes=0,finishes=0,releases=0,ntts=0,processes=0,reads=0,raw_words=0,raw_beats=0;
  int raw_index=0,sample_index=0,phase=0;
  bit monitor=0,test_passed=0,held_input=0,held_done=0,abort_input_hit=0;logic [84:0] input_snapshot;logic [25:0] done_snapshot;
  always @(negedge clk)begin key_ready_i=!rst && cycles%13>4;signature_ready_i=!rst && cycles%17>5;end
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held_input=0;held_done=0;end
    else if(monitor)begin
      elapsed++;if(elapsed>3000000)$fatal(1,"Full Verify watchdog case%0d main%0d verify%0d front%0d math%0d eq%0d",case_no,dut.state,`VC.state,`VC.inputs.state,`VC.math.state,`VC.equation.state);
      if(fault_o && abort_phase!=13 && abort_phase!=14)$fatal(1,"Full Verify fault case%0d",case_no);
      if($countones({dut.keygen_owner,dut.sign_owner,dut.verify_owner})>1)$fatal(1,"Multiple main services owners");
      if(dut.verify_owner && (dut.shared_request!==dut.verify_request || read_ready_o || response_valid_o || sign_input_ready_o || signature_valid_o || key_valid_o || !busy_o))$fatal(1,"Verify services/debug isolation");
      if(!dut.keygen_owner && !dut.sign_owner && !dut.verify_owner && dut.shared_request!=='0)$fatal(1,"Unowned services request");
      if(!dut.verify_owner && verify_input_ready_o)$fatal(1,"Unowned Verify input ready");
      if(busy_o && start_ready_o)$fatal(1,"Busy main accepted work");
      if(verify_accept_o && (!done_valid_o || op!=2 || done_code_o!=0))$fatal(1,"Unqualified Verify accept");
      if(held_done && (!done_valid_o || done_snapshot!=={done_id_o,done_code_o,done_stage_o,done_detail_o,verify_accept_o}))$fatal(1,"Held verdict changed");
      held_done=done_valid_o && !done_ready_i;done_snapshot={done_id_o,done_code_o,done_stage_o,done_detail_o,verify_accept_o};
      if(held_input && !done_valid_o && !fault_o && !rst && (!verify_input_valid_i || input_snapshot!=={verify_input_index_i,verify_input_bytes_i,verify_input_last_i,verify_input_data_i}))$fatal(1,"Host changed held Verify input");
      held_input=verify_input_valid_i && !verify_input_ready_o && op==2 && !done_valid_o && !fault_o;
      input_snapshot={verify_input_index_i,verify_input_bytes_i,verify_input_last_i,verify_input_data_i};
      if(start_valid_i && start_ready_o)begin $fdisplay(fd,"C %0d %0d %0d %0d %0d %0d %0d %064h %064h",case_no,start_op_i,start_param_i,start_id_i,start_context_len_i,start_message_len_i,start_signature_len_i,start_rnd_i,start_seed_i);commands++;end
      if((op==2 && verify_input_valid_i && verify_input_ready_o) || (op==1 && sign_input_valid_i && sign_input_ready_o))begin
        $fdisplay(fd,"I %0d %0d %0d %0d %0d %016h",case_no,frame,op==2?verify_input_index_i:sign_input_index_i,op==2?verify_input_bytes_i:sign_input_bytes_i,op==2?verify_input_last_i:sign_input_last_i,op==2?verify_input_data_i:sign_input_data_i);inputs++;
        if((abort_phase==1 && frame==0 && verify_input_index_i==8) || (abort_phase==2 && frame==1 && verify_input_index_i==8) || (abort_phase==3 && frame==2 && verify_input_index_i==2))abort_input_hit=1;
      end
      if(key_valid_o && key_ready_i)$fdisplay(fd,"KEY %0d %0d %0d %0d %0d %0d %016h",case_no,key_id_o,key_type_o,key_index_o,key_bytes_o,key_last_o,key_data_o);
      if(signature_valid_o && signature_ready_i)$fdisplay(fd,"SIG %0d %0d %0d %0d %0d %016h",case_no,signature_id_o,signature_index_o,signature_bytes_o,signature_last_o,signature_data_o);
      phase=`VC.state==2?1:`VC.state==5?2:3;
      if(op==2)begin
        if(dut.shared_request.load.valid && dut.shared_response.load.ready)$fdisplay(fd,"LD %0d %0d %0d %0d %0d",case_no,dut.shared_request.load.kind,dut.shared_request.load.id,dut.shared_request.load.base,dut.shared_request.load.length);
        if(dut.shared_request.load.done_ready && dut.shared_response.load.done_valid)$fdisplay(fd,"LC %0d %0d %0d %0d %016h %0d %0128h",case_no,dut.shared_request.load.kind,dut.shared_response.load.done_id,dut.shared_response.load.done_code,dut.shared_response.load.done_regions,dut.shared_response.load.header_bytes,dut.shared_response.load.header);
        if(`VC.pdone && `VC.state==2)begin
          $fdisplay(fd,"CH %0d 1 %0d %0d %0d 0 %0128h",case_no,`VC.pdid,`VC.pcode,`VC.pdetail,512'd0);
          if(`VC.pvalid)begin
            $fdisplay(fd,"Y %0d 1 %0d %0d %016h %064h %0128h %0128h",case_no,`VC.pp,`VC.pid,`VC.pregions,`VC.prho,`VC.ptrhash,`VC.pctilde);
            for(int j=0;j<(p==0?4:p==1?6:8);j++)begin $fdisplay(fd,"K %0d 1 0 %0d %0d",case_no,j,`VC.pt1[j]);$fdisplay(fd,"K %0d 1 2 %0d %0d",case_no,j,`VC.ph[j]);end
            for(int j=0;j<(p==0?4:p==1?5:7);j++)$fdisplay(fd,"K %0d 1 1 %0d %0d",case_no,j,`VC.pz[j]);
          end
        end
        if(`VC.mdone && `VC.state==5)begin
          $fdisplay(fd,"CH %0d 2 %0d %0d %0d 0 %0128h",case_no,`VC.mdid,`VC.mcode,`VC.mdetail,512'd0);
          if(`VC.mvalid)begin
            $fdisplay(fd,"Y %0d 2 %0d %0d %016h %064h %0128h %0128h",case_no,`VC.mp,`VC.mid,`VC.mregions,`VC.mrho,`VC.mmu,`VC.mctilde);
            for(int j=0;j<(p==0?4:p==1?6:8);j++)begin $fdisplay(fd,"K %0d 2 0 %0d %0d",case_no,j,`VC.mt1[j]);$fdisplay(fd,"K %0d 2 2 %0d %0d",case_no,j,`VC.mh[j]);end
            for(int j=0;j<(p==0?4:p==1?5:7);j++)$fdisplay(fd,"K %0d 2 1 %0d %0d",case_no,j,`VC.mz[j]);$fdisplay(fd,"K %0d 2 3 0 %0d",case_no,`VC.mc);
          end
        end
        if(`VC.edone && `VC.state==8)$fdisplay(fd,"CH %0d 3 %0d %0d %0d %0d %0128h",case_no,`VC.edid,`VC.ecode,`VC.edetail,`VC.eaccept,`VC.edigest);
        if(`VC.ptake && `VC.ptr)$fdisplay(fd,"T %0d 2 %016h",case_no,`VC.pregions);
        if(`VC.mtake && `VC.mtr)$fdisplay(fd,"T %0d 3 %016h",case_no,`VC.mregions);
        if(dut.shared_request.raw_valid && dut.shared_response.raw_ready)begin $fdisplay(fd,"Q %0d %0d %0d %0d %0d %0d %0d",case_no,phase,dut.shared_response.raw_core,dut.shared_request.raw_id,dut.shared_request.raw_mode,dut.shared_request.raw_message_len,dut.shared_request.raw_output_len);raw_index=0;end
        if(dut.shared_request.raw_input_valid && dut.shared_response.raw_input_ready)begin $fdisplay(fd,"B %0d %0d %0d %016h",case_no,phase,raw_index,dut.shared_request.raw_input_data);raw_index++;raw_words++;end
        if(dut.shared_request.raw_output_ready && dut.shared_response.raw_output_valid)begin $fdisplay(fd,"O %0d %0d %0d %0d %0d %032h",case_no,phase,dut.shared_response.raw_output_core,dut.shared_response.raw_output_id,dut.shared_response.raw_output_bytes,dut.shared_response.raw_output_data);raw_beats++;end
        if(dut.shared_request.raw_done_ready && dut.shared_response.raw_done_valid)$fdisplay(fd,"G %0d %0d %0d %0d",case_no,phase,dut.shared_response.raw_done_core,dut.shared_response.raw_done_id);
        if(dut.shared_request.job_valid && dut.shared_response.job_ready)begin $fdisplay(fd,"J %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,phase,phase==2?0:int'(`VC.equation.row_r),phase==2?0:int'(`VC.equation.column_r),dut.shared_response.job_core,dut.shared_request.job_id,dut.shared_request.job_mode,dut.shared_request.job_param,{dut.shared_request.job_bank,dut.shared_request.job_region},dut.shared_request.message_len);sample_index=0;end
        if(dut.shared_request.input_valid && dut.shared_response.input_ready)begin $fdisplay(fd,"S %0d %0d %0d %016h",case_no,phase,sample_index,dut.shared_request.input_data);sample_index++;end
        if(dut.shared_request.status_ready && dut.shared_response.status_valid)$fdisplay(fd,"H %0d %0d %0d %0d %0d",case_no,phase,dut.shared_response.status_core,dut.shared_response.status_id,dut.shared_response.status_code);
        if(dut.shared_request.op_valid && dut.shared_response.op_ready)begin $fdisplay(fd,"N %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,phase,dut.shared_request.op,dut.shared_request.op_a_region,dut.shared_request.op_b_region,dut.shared_request.op_dest_region,dut.shared_request.op_a_id,dut.shared_request.op_b_id,dut.shared_request.op_id);ntts++;end
        if(dut.shared_request.op_done_ready && dut.shared_response.op_done_valid)$fdisplay(fd,"ND %0d %0d %0d %0d %0d",case_no,phase,dut.shared_response.op_done_id,dut.shared_response.op_done_code,dut.shared_response.op_done_region);
        if(dut.shared_request.process_valid && dut.shared_response.process_ready)begin $fdisplay(fd,"P %0d %0d %0d %0d %0d %0d %0d %0d %0d",case_no,dut.shared_request.process_op,dut.shared_request.process_a,dut.shared_request.process_b,dut.shared_request.process_dest,dut.shared_request.process_a_id,dut.shared_request.process_b_id,dut.shared_request.process_id,dut.shared_request.process_inplace);processes++;end
        if(dut.shared_request.process_done_ready && dut.shared_response.process_done_valid)$fdisplay(fd,"PD %0d %0d %0d %0d",case_no,dut.shared_response.process_done_id,dut.shared_response.process_done_code,dut.shared_response.process_done_dest);
        if(dut.shared_request.pack.command_valid && dut.shared_response.pack.command_ready)$fdisplay(fd,"PC %0d %0d %0d %0d %0d",case_no,`VC.equation.row_r,dut.shared_request.pack.command_id,dut.shared_request.pack.command_op,dut.shared_request.pack.command_param);
        if(dut.shared_request.pack.input_valid && dut.shared_response.pack.input_ready)$fdisplay(fd,"V %0d %0d %0d %06h %0d",case_no,`VC.equation.row_r,dut.shared_request.pack.input_index,dut.shared_request.pack.input_data,dut.shared_request.pack.input_last);
        if(dut.shared_request.pack.output_ready && dut.shared_response.pack.output_valid)$fdisplay(fd,"E %0d %0d %0d %0d %0d %0d %016h",case_no,`VC.equation.row_r,dut.shared_response.pack.output_id,dut.shared_response.pack.output_index,dut.shared_response.pack.output_bytes,dut.shared_response.pack.output_last,dut.shared_response.pack.output_data);
        if(dut.shared_request.pack.done_ready && dut.shared_response.pack.done_valid)$fdisplay(fd,"PKD %0d %0d %0d %0d",case_no,`VC.equation.row_r,dut.shared_response.pack.done_id,dut.shared_response.pack.done_code);
        if(dut.shared_request.response_ready && dut.shared_response.response_valid)begin $fdisplay(fd,"R %0d %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,{dut.shared_response.response_bank,dut.shared_response.response_region},dut.shared_response.response_word,dut.shared_response.response_id,dut.shared_response.response_mode,dut.shared_response.response_param,dut.shared_response.response_ntt_domain,dut.shared_response.response_small,dut.shared_response.response_error,dut.shared_response.response_data);reads++;end
      end
      if(`ST.alloc_fire)begin $fdisplay(fd,"A %0d %0d %0d %0d %0d %0d %0d %0d %016h",case_no,`ST.alloc_region,`ST.alloc_rewrite_i,`ST.alloc_compute_i,`ST.alloc_ntt_domain_i,`ST.alloc_mode_i,`ST.alloc_param_i,`ST.alloc_id_i,`ST.reserved_o);allocs++;end
      if(op==2 && `ST.write_fire)begin $fdisplay(fd,"W %0d %0d %0d %0d %06h %0d",case_no,`ST.write_region,`ST.write_id_i,`ST.write_index_i,`ST.write_data_i,`ST.write_last_i);writes++;end
      if(`ST.finish_fire)begin $fdisplay(fd,"M %0d %0d %0d %0d %0d",case_no,`ST.finish_region,`ST.finish_id_i,`ST.finish_code_i,`ST.writer_count_r[`ST.finish_core_i]);finishes++;end
      if(`ST.release_fire)begin $fdisplay(fd,"F %0d %0d",case_no,`ST.release_region);releases++;end
    end
  end
  task automatic reset_all();
    release `VC.inputs.done_id_o;release `VC.math.done_id_o;release `VC.equation.done_id_o;
    release dut.services.datapath.subsystem.producer.raw_output_id_o;release `ST.fault_o;
    monitor=0;rst=1;start_valid_i=0;verify_input_valid_i=0;sign_input_valid_i=0;done_ready_i=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || fault_o || reserved_o || complete_o || verify_accept_o || !start_ready_o)$fatal(1,"Main Verify reset");
  endtask
  task automatic send_frame(input int which,input string data);
    int n,size,index,parsed;bit last;logic [63:0] word;byte unsigned b;n=data=="-"?0:data.len()/2;frame=which;
    for(int w=0;w<(n+7)/8;w++)begin
      if(rst || done_valid_o || fault_o)return;
      if(w%11==3)begin @(negedge clk);#1;if(rst || done_valid_o || fault_o)return;end
      size=n-8*w>=8?8:n-8*w;index=w;last=8*(w+1)>=n;word='1;
      for(int j=0;j<size;j++)begin parsed=$sscanf(data.substr(2*(8*w+j),2*(8*w+j)+1),"%h",b);word[8*j+:8]=b;end
      if(op==2)begin
        if(injection==4*which+1 && w==0)index=1024;
        if(injection==4*which+2 && w==0)size=0;
        if(injection==4*which+3 && w==0)last=1;
        if(injection==4*which+4 && last)last=0;
        verify_input_index_i=16'(index);verify_input_bytes_i=4'(size);verify_input_last_i=last;verify_input_data_i=word;verify_input_valid_i=1;
        do @(posedge clk);while(!verify_input_ready_o && !rst && !done_valid_o && !fault_o);
      end else begin sign_input_index_i=16'(index);sign_input_bytes_i=4'(size);sign_input_last_i=last;sign_input_data_i=word;sign_input_valid_i=1;
        do @(posedge clk);while(!sign_input_ready_o && !rst && !done_valid_o && !fault_o);end
      @(negedge clk);#1;verify_input_valid_i=0;sign_input_valid_i=0;
    end
  endtask
  initial begin
    int f,cleanup;bit hit;string directory,token,first,second,body;logic [255:0] rnd,xi;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    $display("MAIN_CONFIG FULL_KEYGEN=%0d ENABLE_SIGN=%0d ENABLE_VERIFY=%0d",dut.FULL_KEYGEN,dut.ENABLE_SIGN,dut.ENABLE_VERIFY);
    f=$fopen({directory,"/",STEM,"_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d",token,count)!=2 || count!=(NIST_VECTORS?45:118))$fatal(1,"Prepare full Verify inputs");
    fd=$fopen({directory,"/",STEM,"_outputs.txt"},"w");$fdisplay(fd,"H %s",token);reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %d %d %d %d %d %d %h %h %s %s %s",case_no,op,p,jid,injection,abort_phase,code,stage,detail,ctxlen,mlen,siglen,rnd,xi,first,second,body)!=17 || case_no!=c)$fatal(1,"Full Verify fixture");
      elapsed=0;abort_input_hit=0;monitor=1;start_op_i=2'(op);start_param_i=2'(p);start_id_i=16'(jid);start_seed_i=xi;start_rnd_i=rnd;
      start_signature_len_i=16'(siglen);start_message_len_i=16'(mlen);start_context_len_i=9'(ctxlen);start_valid_i=1;
      do @(posedge clk);while(!start_ready_o);@(negedge clk);#1;start_valid_i=0;
      start_op_i=3;start_param_i=3;start_id_i=~16'(jid);start_message_len_i=65535;start_signature_len_i=65535;start_context_len_i=511;start_seed_i='1;start_rnd_i='1;
      if(op==2 || op==1)fork begin send_frame(0,first);if(!rst && !done_valid_o && !fault_o)begin if(op==2)begin send_frame(1,second);if(!rst && !done_valid_o && !fault_o)send_frame(2,body);end else send_frame(1,body);end end join_none
      if(abort_phase)begin
        hit=0;while(!hit)begin @(negedge clk);#1;
          case(abort_phase)
            1,2,3:hit=abort_input_hit;
            4:hit=`VC.state==3 && `VC.pvalid;
            5:hit=`VC.state==5 && `VC.math.state==8 && `ST.write_fire && `ST.write_index_i==17;
            6:hit=`VC.state==5 && `VC.math.state==12 && `ST.write_fire && `ST.write_index_i==17;
            7:hit=`VC.state==6 && `VC.mvalid;
            8:hit=`VC.state==8 && `VC.equation.state==5 && `ST.write_fire && `ST.write_index_i==17;
            9:hit=`VC.state==8 && `VC.equation.state==7 && `ST.write_fire && `ST.write_index_i==17;
            10:hit=`VC.state==8 && `VC.equation.state==23 && `VC.equation.sent_r==17;
            11:hit=done_valid_o;
            12:hit=`VC.state==8 && `VC.equation.state==27 && `ST.release_fire;
            13:if(`VC.state==5 && dut.shared_response.raw_output_valid)begin force dut.services.datapath.subsystem.producer.raw_output_id_o=16'hf00d;repeat(3)@(negedge clk);#1;hit=fault_o;end
            14:if(`VC.state==8 && `VC.equation.state==7 && `ST.write_fire)begin force `ST.fault_o=1'b1;repeat(3)@(negedge clk);#1;hit=fault_o;end
          endcase
          if(done_valid_o && abort_phase!=11)$fatal(1,"Main Verify missed abort%0d",abort_phase);
        end
        if(abort_phase==11)repeat(7)@(negedge clk);#1;
        $fdisplay(fd,"Z %0d %0d %0d %0d %0d %016h %016h",case_no,abort_phase,dut.state,`VC.state,fault_o,reserved_o,complete_o);aborts++;reset_all();wait fork;
      end else begin
        while(!done_valid_o)begin @(negedge clk);#1;
          if(injection==15 && `VC.pdone)force `VC.inputs.done_id_o=16'hf00d;
          if(injection==16 && `VC.mdone)force `VC.math.done_id_o=16'hf00d;
          if(injection==17 && `VC.edone)force `VC.equation.done_id_o=16'hf00d;
        end
        repeat(7)@(negedge clk);#1;wait fork;
        if(done_id_o!=jid || done_code_o!=code || done_stage_o!=stage || done_detail_o!=detail)$fatal(1,"Full Verify status case%0d got%0d/%0d/%0d expected%0d/%0d/%0d",case_no,done_code_o,done_stage_o,done_detail_o,code,stage,detail);
        if(op!=0 && (reserved_o || complete_o || dut.shared_response.active))$fatal(1,"Completion before cleanup");
        start_valid_i=1;repeat(4)begin @(posedge clk);if(start_ready_o)$fatal(1,"Held done accepted next work");end
        @(negedge clk);#1;start_valid_i=0;$fdisplay(fd,"REFUSE %0d 4",case_no);
        $fdisplay(fd,"D %0d %0d %0d %0d %0d %0d %016h %016h %0d",case_no,done_id_o,done_code_o,done_stage_o,done_detail_o,verify_accept_o,reserved_o,complete_o,dut.shared_response.active);completions++;
        done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
        release `VC.inputs.done_id_o;release `VC.math.done_id_o;release `VC.equation.done_id_o;
        cleanup=0;while(!start_ready_o)begin @(negedge clk);#1;cleanup++;if(cleanup>1000)$fatal(1,"Main cleanup");end
        if(reserved_o || complete_o || busy_o)$fatal(1,"Main Verify inter-command leak");
        $fdisplay(fd,"ENDCASE %0d 0",case_no);
      end monitor=0;$display("%s progress:%0d/%0d",STEM,c+1,count);
    end
    $fdisplay(fd,"END %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",commands,completions,aborts,inputs,allocs,writes,finishes,releases,ntts,processes,reads,raw_words,raw_beats);
    $fclose(f);$fclose(fd);
    if(NIST_VECTORS)$display("STAGE6_NIST_VERIFY_CAPTURE_PASS:%0d commands/%0d completions/%0d aborts",commands,completions,aborts);
    else $display("STAGE5V4_FULL_VERIFY_CAPTURE_PASS:%0d commands/%0d completions/%0d aborts",commands,completions,aborts);
    test_passed=1;$finish;
  end
  initial begin #(64'd4000000000000);$fatal(1,"Full Verify global watchdog case%0d",case_no);end
endmodule
`undef VC
`undef ST
