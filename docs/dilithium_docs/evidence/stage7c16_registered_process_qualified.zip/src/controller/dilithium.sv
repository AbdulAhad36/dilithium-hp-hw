// Main operation FSM and exclusive services owner. op0 KeyGen,op1 Sign,op2 Verify.
// Unsupported operations return code2 without starting the datapath.
`default_nettype none
module dilithium #(parameter bit ROUND_OUTPUTS=0, FULL_KEYGEN=0, ENABLE_SIGN=1, ENABLE_VERIFY=1) (
  output logic key_valid_o,input wire logic key_ready_i,output logic [63:0] key_data_o,
  output logic [3:0] key_bytes_o,output logic key_type_o,key_last_o,
  output logic [9:0] key_index_o,output logic [15:0] key_id_o,
  input wire logic clk,rst,start_valid_i,output logic start_ready_o,busy_o,
  input wire logic [1:0] start_op_i,start_param_i,input wire logic [15:0] start_id_i,
  input wire logic [255:0] start_seed_i,
  input wire logic [15:0] start_message_len_i,input wire logic [8:0] start_context_len_i,
  input wire logic [255:0] start_rnd_i,
  input wire logic sign_input_valid_i,output logic sign_input_ready_o,
  input wire logic [63:0] sign_input_data_i,input wire logic [3:0] sign_input_bytes_i,
  input wire logic [15:0] sign_input_index_i,input wire logic sign_input_last_i,
  input wire logic [15:0] start_signature_len_i,
  input wire logic verify_input_valid_i,output logic verify_input_ready_o,
  input wire logic [63:0] verify_input_data_i,input wire logic [3:0] verify_input_bytes_i,
  input wire logic [15:0] verify_input_index_i,input wire logic verify_input_last_i,
  output logic verify_accept_o,
  output logic signature_valid_o,input wire logic signature_ready_i,
  output logic [63:0] signature_data_o,output logic [3:0] signature_bytes_o,
  output logic [9:0] signature_index_o,output logic signature_last_o,output logic [15:0] signature_id_o,
  output logic [2:0] done_stage_o,done_detail_o,
  output logic [16:0] sign_attempts_o,sign_rejections_o,sign_next_nonce_o,
  output logic row_result_valid_o,input wire logic row_result_ready_i,
  output logic [3:0] row_result_index_o,output logic [5:0] row_result_region_o,
  output logic [15:0] row_result_id_o,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic [2:0] done_code_o,output logic [15:0] done_id_o,
  output logic seed_valid_o,output logic [255:0] rho_o,key_o,output logic [511:0] rhoprime_o,
  input wire logic read_valid_i,input wire logic [1:0] read_bank_i,
  input wire logic [3:0] read_region_i,input wire logic [5:0] read_word_i,
  output logic read_ready_o,response_valid_o,response_error_o,
  output logic [1:0] response_bank_o,response_mode_o,response_param_o,
  output logic [3:0] response_region_o,output logic [5:0] response_word_o,
  output logic [91:0] response_data_o,output logic [15:0] response_id_o,
  output logic response_ntt_domain_o,response_small_o,input wire logic response_ready_i,
  output logic [63:0] reserved_o,complete_o,output logic fault_o
);

  dilithium_service_pkg::request_t keygen_request,sign_request,verify_request,shared_request;
  dilithium_service_pkg::response_t shared_response;
  logic keygen_owner,sign_owner,verify_owner,main_quiescent;

  typedef enum logic [2:0] {IDLE,DISPATCH,WAIT_RESULT,REJECT,SIGN_DISPATCH,SIGN_RESULT,VERIFY_DISPATCH,VERIFY_RESULT} state_e;
  state_e state;
  logic [1:0] param_r;logic [15:0] id_r;logic [255:0] xi_r;
  logic child_ready,child_busy,child_done;logic [2:0] child_code;logic [15:0] child_id;
  logic sign_ready,sign_busy,sign_done,sign_fault,keygen_fault,kg_read_ready,kg_response_valid;
  logic [2:0] sign_code,sign_stage,sign_detail;logic [15:0] sign_id,message_r;
  logic [8:0] context_r;logic [255:0] rnd_r;
  logic [16:0] attempts,rejections,next_nonce;
  logic verify_ready,verify_busy,verify_done,verify_fault,verify_accept;
  logic [2:0] verify_code,verify_stage,verify_detail;logic [15:0] verify_id,siglen_r;
  assign main_quiescent=shared_response.active==0 && !shared_response.op_busy && !shared_response.process_busy &&
    !shared_response.row_busy && !shared_response.sign.busy && !shared_response.load.busy &&
    shared_response.pack.command_ready && !shared_response.pack.done_valid && !shared_response.pack.output_valid &&
    !shared_response.response_valid && shared_response.read_ready;
  assign start_ready_o=!rst && state==IDLE && child_ready && sign_ready && verify_ready && !child_busy && !sign_busy && !verify_busy && main_quiescent && !fault_o;
  assign busy_o=state!=IDLE || child_busy || sign_busy || verify_busy;
  assign done_valid_o=!rst && !fault_o && (state==REJECT || (state==WAIT_RESULT && child_done) || (state==SIGN_RESULT && sign_done) || (state==VERIFY_RESULT && verify_done));
  assign done_code_o=state==REJECT?3'd2:state==SIGN_RESULT?sign_code:state==VERIFY_RESULT?verify_code:child_code;
  assign done_id_o=state==REJECT?id_r:state==SIGN_RESULT?sign_id:state==VERIFY_RESULT?verify_id:child_id;
  assign done_stage_o=state==SIGN_RESULT?sign_stage:state==VERIFY_RESULT?verify_stage:3'd0;
  assign done_detail_o=state==SIGN_RESULT?sign_detail:state==VERIFY_RESULT?verify_detail:3'd0;
  assign verify_accept_o=done_valid_o && state==VERIFY_RESULT && verify_code==0 && verify_accept;
  assign sign_attempts_o=sign_owner?attempts:17'd0;assign sign_rejections_o=sign_owner?rejections:17'd0;
  assign sign_next_nonce_o=sign_owner?next_nonce:17'd0;
  assign fault_o=shared_response.fault || keygen_fault || sign_fault || verify_fault;
  assign read_ready_o=kg_read_ready && !sign_owner && !verify_owner;assign response_valid_o=kg_response_valid && !sign_owner && !verify_owner;
  // Operation ownership includes post-completion cleanup,when main state is IDLE.
  assign keygen_owner=!rst && (state==DISPATCH || child_busy);
  assign sign_owner=!rst && (state==SIGN_DISPATCH || sign_busy);
  assign verify_owner=!rst && (state==VERIFY_DISPATCH || verify_busy);
  assign shared_request=keygen_owner?keygen_request:(sign_owner?sign_request:(verify_owner?verify_request:'0));
  dilithium_services services(.clk(clk),.rst(rst),.request_i(shared_request),.response_o(shared_response));
  keygen #(.ROUND_OUTPUTS(ROUND_OUTPUTS),.FULL_KEYGEN(FULL_KEYGEN)) core(
    .service_o(keygen_request),.service_i(shared_response),
    .start_valid_i(state==DISPATCH),.start_ready_o(child_ready),.busy_o(child_busy),
    .start_param_i(param_r),.start_id_i(id_r),.start_seed_i(xi_r),
    .done_valid_o(child_done),.done_ready_i(state==WAIT_RESULT && done_ready_i),
    .done_code_o(child_code),.done_id_o(child_id),.fault_o(keygen_fault),
    .read_valid_i(read_valid_i && !sign_owner && !verify_owner),.read_ready_o(kg_read_ready),
    .response_valid_o(kg_response_valid),.response_ready_i(response_ready_i && !sign_owner && !verify_owner),.*
  );
  generate if(ENABLE_SIGN)begin:g_sign
    sign signer(.clk(clk),.rst(rst),.start_valid_i(state==SIGN_DISPATCH),.start_ready_o(sign_ready),.busy_o(sign_busy),.fault_o(sign_fault),
      .start_param_i(param_r),.start_id_i(id_r),.start_message_len_i(message_r),.start_context_len_i(context_r),.start_rnd_i(rnd_r),
      .input_valid_i(sign_input_valid_i && sign_owner),.input_ready_o(sign_input_ready_o),.input_data_i(sign_input_data_i),
      .input_bytes_i(sign_input_bytes_i),.input_index_i(sign_input_index_i),.input_last_i(sign_input_last_i),
      .signature_valid_o(signature_valid_o),.signature_ready_i(signature_ready_i),.signature_data_o(signature_data_o),
      .signature_bytes_o(signature_bytes_o),.signature_index_o(signature_index_o),.signature_last_o(signature_last_o),.signature_id_o(signature_id_o),
      .done_valid_o(sign_done),.done_ready_i(state==SIGN_RESULT && done_ready_i),.done_code_o(sign_code),.done_stage_o(sign_stage),
      .done_detail_o(sign_detail),.done_id_o(sign_id),.attempts_o(attempts),.rejections_o(rejections),.next_nonce_o(next_nonce),
      .service_o(sign_request),.service_i(shared_response));
  end else begin:g_no_sign
    assign sign_request='0;assign sign_ready=1;assign sign_busy=0;assign sign_fault=0;assign sign_done=0;
    assign sign_code=0;assign sign_stage=0;assign sign_detail=0;assign sign_id=0;
    assign attempts=0;assign rejections=0;assign next_nonce=0;assign sign_input_ready_o=0;
    assign signature_valid_o=0;assign signature_data_o=0;assign signature_bytes_o=0;
    assign signature_index_o=0;assign signature_last_o=0;assign signature_id_o=0;
  end endgenerate
  generate if(ENABLE_VERIFY)begin:g_verify
    verify verifier(.clk(clk),.rst(rst),.start_valid_i(state==VERIFY_DISPATCH),.start_ready_o(verify_ready),.busy_o(verify_busy),.fault_o(verify_fault),
      .start_param_i(param_r),.start_id_i(id_r),.start_message_len_i(message_r),.start_context_len_i(context_r),.start_signature_len_i(siglen_r),
      .input_valid_i(verify_input_valid_i && verify_owner),.input_ready_o(verify_input_ready_o),.input_data_i(verify_input_data_i),
      .input_bytes_i(verify_input_bytes_i),.input_index_i(verify_input_index_i),.input_last_i(verify_input_last_i),
      .done_valid_o(verify_done),.done_ready_i(state==VERIFY_RESULT && done_ready_i),.done_code_o(verify_code),.done_stage_o(verify_stage),
      .done_detail_o(verify_detail),.done_id_o(verify_id),.done_accept_o(verify_accept),.service_o(verify_request),.service_i(shared_response));
  end else begin:g_no_verify
    assign verify_request='0;assign verify_ready=1;assign verify_busy=0;assign verify_fault=0;assign verify_done=0;
    assign verify_code=0;assign verify_stage=0;assign verify_detail=0;assign verify_id=0;assign verify_accept=0;assign verify_input_ready_o=0;
  end endgenerate
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin state<=IDLE;param_r<=0;id_r<=0;xi_r<=0;message_r<=0;context_r<=0;rnd_r<=0;siglen_r<=0;end
    else case(state)
      IDLE:if(start_valid_i && start_ready_o)begin
        param_r<=start_param_i;id_r<=start_id_i;xi_r<=start_seed_i;
        message_r<=start_message_len_i;context_r<=start_context_len_i;rnd_r<=start_rnd_i;siglen_r<=start_signature_len_i;
        state<=start_op_i==0?DISPATCH:((start_op_i==1 && ENABLE_SIGN)?SIGN_DISPATCH:((start_op_i==2 && ENABLE_VERIFY)?VERIFY_DISPATCH:REJECT));
      end
      DISPATCH:if(child_ready)state<=WAIT_RESULT;
      WAIT_RESULT:if(child_done && done_ready_i)state<=IDLE;
      SIGN_DISPATCH:if(sign_ready)state<=SIGN_RESULT;
      SIGN_RESULT:if(sign_done && done_ready_i)begin rnd_r<=0;state<=IDLE;end
      VERIFY_DISPATCH:if(verify_ready)state<=VERIFY_RESULT;
      VERIFY_RESULT:if(verify_done && done_ready_i)state<=IDLE;
      REJECT:if(done_ready_i)state<=IDLE;
      default:state<=IDLE;
    endcase
  end
endmodule
`default_nettype wire
