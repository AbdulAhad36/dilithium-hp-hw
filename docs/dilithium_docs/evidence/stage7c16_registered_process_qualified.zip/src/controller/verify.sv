// Full pure-ML-DSA Verify. Frames:PK,SIG,ctx||M;each index starts0.
// One exclusive services lease spans all handoffs and cleanup.
// Invalid signatures return code0/accept0;host framing remains an error.
`default_nettype none
module verify (
  input wire logic clk,rst,start_valid_i,output logic start_ready_o,busy_o,fault_o,
  input wire logic [1:0] start_param_i,input wire logic [15:0] start_id_i,start_message_len_i,start_signature_len_i,
  input wire logic [8:0] start_context_len_i,
  input wire logic input_valid_i,output logic input_ready_o,input wire logic [63:0] input_data_i,
  input wire logic [3:0] input_bytes_i,input wire logic [15:0] input_index_i,input wire logic input_last_i,
  output logic done_valid_o,input wire logic done_ready_i,output logic [15:0] done_id_o,
  output logic [2:0] done_code_o,done_stage_o,done_detail_o,output logic done_accept_o,
  output dilithium_service_pkg::request_t service_o,input dilithium_service_pkg::response_t service_i
);
  import dilithium_service_pkg::*;
  typedef enum logic [3:0] {IDLE,INPUT_START,INPUT_WAIT,INPUT_RETIRE,MATH_START,MATH_WAIT,MATH_RETIRE,
    EQUATION_START,EQUATION_WAIT,EQUATION_RETIRE,DROP_MATH,WAIT_MATH,DROP_INPUT,WAIT_INPUT,REPORT,HALT} state_e;
  state_e state;
  logic [1:0] param_r,pp,mp;logic [15:0] id_r,message_r,siglen_r,pid,mid,pdid,mdid,edid;
  logic [8:0] context_r;logic [17:0] message_total;logic accept_r,invalid_r;
  logic pr,pbusy,pfault,pir,pdone,pvalid,pclear,pcr,ptake,ptr;
  logic mr,mbusy,mfault,mir,mdone,mvalid,mclear,mcr,mtake,mtr;
  logic er,ebusy,efault,edone,eaccept;
  logic [2:0] pcode,pdetail,mcode,mdetail,ecode,edetail;
  logic [63:0] pregions,mregions;logic [7:0][5:0] pt1,ph,mt1,mh;logic [6:0][5:0] pz,mz;logic [5:0] mc;
  logic [255:0] prho,mrho;logic [511:0] ptrhash,pctilde,mmu,mctilde,edigest;
  request_t input_request,math_request,equation_request;
  assign message_total=18'd66+18'(start_context_len_i)+18'(start_message_len_i);
  assign start_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault && service_i.reserved==0 &&
    pr && mr && er && !pbusy && !mbusy && !ebusy;
  assign busy_o=state!=IDLE;assign done_valid_o=!rst && state==REPORT && !fault_o;
  assign done_id_o=id_r;assign done_accept_o=done_valid_o && done_code_o==0 && accept_r;
  assign input_ready_o=!rst && !fault_o && ((state==INPUT_WAIT && pir) || (state==MATH_WAIT && mir));
  assign pclear=state==DROP_INPUT && pvalid && !fault_o;assign mclear=state==DROP_MATH && mvalid && !fault_o;
  verify_input_prepare inputs(.clk(clk),.rst(rst),.command_valid_i(state==INPUT_START && !fault_o),.command_ready_o(pr),
    .busy_o(pbusy),.fault_o(pfault),.command_param_i(param_r),.command_id_i(id_r),.command_signature_len_i(siglen_r),.command_base_i(6'd0),
    .input_valid_i(state==INPUT_WAIT && input_valid_i && !fault_o),.input_ready_o(pir),.input_data_i(input_data_i),
    .input_bytes_i(input_bytes_i),.input_index_i(input_index_i),.input_last_i(input_last_i),
    .done_valid_o(pdone),.done_ready_i(state==INPUT_WAIT && !fault_o),.done_code_o(pcode),.done_detail_o(pdetail),.done_id_o(pdid),
    .context_valid_o(pvalid),.context_param_o(pp),.context_id_o(pid),.context_regions_o(pregions),.context_t1_o(pt1),.context_hints_o(ph),
    .context_z_o(pz),.context_rho_o(prho),.context_tr_o(ptrhash),.context_ctilde_o(pctilde),
    .clear_valid_i(pclear),.clear_ready_o(pcr),.take_valid_i(ptake),.take_ready_o(ptr),.service_o(input_request),.service_i(service_i));
  verify_math_prepare math(.clk(clk),.rst(rst),.command_valid_i(state==MATH_START && !fault_o),.command_ready_o(mr),
    .busy_o(mbusy),.fault_o(mfault),.command_id_i(id_r),.command_message_len_i(message_r),.command_context_len_i(context_r),
    .context_valid_i(pvalid),.context_param_i(pp),.context_id_i(pid),.context_regions_i(pregions),.context_t1_i(pt1),.context_hints_i(ph),
    .context_z_i(pz),.context_rho_i(prho),.context_tr_i(ptrhash),.context_ctilde_i(pctilde),.context_take_valid_o(ptake),.context_take_ready_i(ptr),
    .payload_valid_i(state==MATH_WAIT && input_valid_i && !fault_o),.payload_ready_o(mir),.payload_data_i(input_data_i),
    .payload_bytes_i(input_bytes_i),.payload_index_i(input_index_i),.payload_last_i(input_last_i),
    .done_valid_o(mdone),.done_ready_i(state==MATH_WAIT && !fault_o),.done_code_o(mcode),.done_detail_o(mdetail),.done_id_o(mdid),
    .result_valid_o(mvalid),.result_param_o(mp),.result_id_o(mid),.result_regions_o(mregions),.result_t1hat_o(mt1),.result_hints_o(mh),
    .result_zhat_o(mz),.result_chat_o(mc),.result_rho_o(mrho),.result_mu_o(mmu),.result_ctilde_o(mctilde),
    .clear_valid_i(mclear),.clear_ready_o(mcr),.take_valid_i(mtake),.take_ready_o(mtr),.service_o(math_request),.service_i(service_i));
  verify_equation equation(.clk(clk),.rst(rst),.command_valid_i(state==EQUATION_START && !fault_o),.command_ready_o(er),.busy_o(ebusy),.fault_o(efault),
    .command_id_i(id_r),.context_valid_i(mvalid),.context_param_i(mp),.context_id_i(mid),.context_regions_i(mregions),
    .context_t1hat_i(mt1),.context_hints_i(mh),.context_zhat_i(mz),.context_chat_i(mc),.context_rho_i(mrho),.context_mu_i(mmu),.context_ctilde_i(mctilde),
    .context_take_valid_o(mtake),.context_take_ready_i(mtr),.done_valid_o(edone),.done_ready_i(state==EQUATION_WAIT && !fault_o),
    .done_id_o(edid),.done_code_o(ecode),.done_detail_o(edetail),.done_accept_o(eaccept),.done_digest_o(edigest),.service_o(equation_request),.service_i(service_i));
  always_comb begin
    service_o='0;
    case(state)
      INPUT_START,INPUT_WAIT,INPUT_RETIRE,DROP_INPUT,WAIT_INPUT:service_o=input_request;
      MATH_START,MATH_WAIT,MATH_RETIRE,DROP_MATH,WAIT_MATH:service_o=math_request;
      EQUATION_START,EQUATION_WAIT,EQUATION_RETIRE:service_o=equation_request;
      default:service_o='0;
    endcase
    if(fault_o)service_o='0;
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin state<=IDLE;param_r<=0;id_r<=0;message_r<=0;siglen_r<=0;context_r<=0;accept_r<=0;invalid_r<=0;
      done_code_o<=0;done_stage_o<=0;done_detail_o<=0;fault_o<=0;end
    else if(state!=IDLE && (service_i.fault || pfault || mfault || efault))begin fault_o<=1;state<=HALT;end
    else case(state)
      IDLE:if(start_valid_i && start_ready_o)begin
        param_r<=start_param_i;id_r<=start_id_i;message_r<=start_message_len_i;siglen_r<=start_signature_len_i;context_r<=start_context_len_i;
        done_code_o<=0;done_stage_o<=0;done_detail_o<=0;accept_r<=0;invalid_r<=0;
        if(start_param_i==3 || start_context_len_i>255 || message_total>65535)begin done_code_o<=1;state<=REPORT;end
        else if(start_signature_len_i!=(start_param_i==0?16'd2420:start_param_i==1?16'd3309:16'd4627))state<=REPORT;
        else state<=INPUT_START;
      end
      INPUT_START:if(pr)state<=INPUT_WAIT;
      INPUT_WAIT:if(pdone)begin
        if(pdid!=id_r || (pcode==0 && (!pvalid || pid!=id_r || pp!=param_r)))begin done_code_o<=6;done_stage_o<=1;end
        else if(pcode==5 && pdetail==2)invalid_r<=1;
        else if(pcode!=0)begin done_code_o<=3;done_stage_o<=1;done_detail_o<=pcode;end
        state<=INPUT_RETIRE;
      end
      INPUT_RETIRE:if(!pdone && (pvalid || !pbusy))state<=(done_code_o==0 && !invalid_r)?MATH_START:DROP_MATH;
      MATH_START:if(mr)state<=MATH_WAIT;
      MATH_WAIT:if(mdone)begin
        if(mdid!=id_r || (mcode==0 && (!mvalid || mid!=id_r || mp!=param_r)))begin done_code_o<=6;done_stage_o<=2;end
        else if(mcode!=0)begin done_code_o<=4;done_stage_o<=2;done_detail_o<=mcode;end
        state<=MATH_RETIRE;
      end
      MATH_RETIRE:if(!mdone && (mvalid || !mbusy))state<=done_code_o==0?EQUATION_START:DROP_MATH;
      EQUATION_START:if(er)state<=EQUATION_WAIT;
      EQUATION_WAIT:if(edone)begin
        if(edid!=id_r)begin done_code_o<=6;done_stage_o<=3;end
        else if(ecode!=0)begin done_code_o<=5;done_stage_o<=3;done_detail_o<=ecode;end
        else accept_r<=eaccept;
        state<=EQUATION_RETIRE;
      end
      EQUATION_RETIRE:if(!ebusy)state<=DROP_MATH;
      DROP_MATH:if(mclear && mcr)state<=WAIT_MATH;else if(!mbusy)state<=DROP_INPUT;
      WAIT_MATH:if(!mbusy)state<=DROP_INPUT;
      DROP_INPUT:if(pclear && pcr)state<=WAIT_INPUT;else if(!pbusy)state<=REPORT;
      WAIT_INPUT:if(!pbusy)state<=REPORT;
      REPORT:if(done_ready_i)state<=IDLE;
      HALT:state<=HALT;
      default:begin fault_o<=1;state<=HALT;end
    endcase
  end
endmodule
`default_nettype wire
