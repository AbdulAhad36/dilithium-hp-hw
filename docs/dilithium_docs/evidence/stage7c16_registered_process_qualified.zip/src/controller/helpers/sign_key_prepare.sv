// Control-only signing-key preparation client. Caller grants the ONE services
// tree through service_active_o;the outer Sign owner protects the key for the
// entire busy interval,including retained READY context and child handoffs.
// One spare region rotates through the raw source slots;no polynomial RAM.
`default_nettype none
module sign_key_prepare (
  input wire logic clk,rst,command_valid_i,
  output logic command_ready_o,busy_o,service_active_o,fault_o,
  input wire logic [1:0] command_param_i,input wire logic [15:0] command_id_i,
  input wire logic [5:0] command_base_i,command_work_i,
  input wire logic input_valid_i,output logic input_ready_o,
  input wire logic [63:0] input_data_i,input wire logic [3:0] input_bytes_i,
  input wire logic [9:0] input_index_i,input wire logic input_last_i,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic [2:0] done_code_o,done_detail_o,output logic [15:0] done_id_o,
  output logic context_valid_o,output logic [1:0] context_param_o,
  output logic [15:0] context_id_o,output logic [63:0] context_regions_o,
  output logic [22:0][5:0] context_handles_o,
  output logic [255:0] context_rho_o,context_key_o,output logic [511:0] context_tr_o,
  input wire logic clear_valid_i,output logic clear_ready_o,
  output dilithium_service_pkg::request_t service_o,
  input dilithium_service_pkg::response_t service_i
);
  typedef enum logic [3:0] {IDLE,CHECK,LOAD_START,LOAD_WAIT,OP_START,OP_WAIT,
    FREE_SOURCE,REPORT,READY,CLEAN,HALT} state_e;
  state_e state;
  logic [1:0] param_r;logic [15:0] id_r;logic [5:0] base_r,work_r,total_r,small_r,ordinal_r,source_r,scan_r;
  logic [63:0] plan_r,owned_r;logic [22:0][5:0] handles_r;
  logic [255:0] rho_r,key_r;logic [511:0] tr_r;
  logic [2:0] code_r,detail_r;logic clearing_r;
  logic [6:0] command_total,command_small,command_end;logic [63:0] command_plan;
  logic quiescent,load_bad,op_bad;
  always_comb begin
    command_total=command_param_i==0?7'd12:(command_param_i==1?7'd17:7'd23);
    command_small=command_param_i==0?7'd8:(command_param_i==1?7'd11:7'd15);
    command_end={1'b0,command_base_i}+command_total;
    command_plan=0;
    for(int i=0;i<64;i++)if(i>=int'(command_base_i) && i<int'(command_end))command_plan[i]=1;
  end
  assign quiescent=service_i.active==0 && !service_i.op_busy && !service_i.process_busy &&
    !service_i.sign.busy && !service_i.load.busy && !service_i.row_busy &&
    !service_i.response_valid && service_i.read_ready;
  assign command_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault;
  assign busy_o=state!=IDLE;
  assign service_active_o=state!=IDLE && state!=READY;
  assign input_ready_o=!rst && state==LOAD_WAIT && service_i.load.input_ready && !fault_o;
  assign done_valid_o=!rst && state==REPORT && !fault_o;
  assign done_code_o=code_r;assign done_detail_o=detail_r;assign done_id_o=id_r;
  assign context_valid_o=!rst && !fault_o && ((state==REPORT && code_r==0) || state==READY);
  assign context_param_o=context_valid_o?param_r:2'd0;assign context_id_o=context_valid_o?id_r:16'd0;
  assign context_regions_o=context_valid_o?owned_r:64'd0;
  assign context_handles_o=context_valid_o?handles_r:'0;
  assign context_rho_o=context_valid_o?rho_r:256'd0;assign context_key_o=context_valid_o?key_r:256'd0;
  assign context_tr_o=context_valid_o?tr_r:512'd0;
  assign clear_ready_o=!rst && state==READY && quiescent && !fault_o && !service_i.fault;
  assign load_bad=service_i.load.done_id!=id_r ||
    (service_i.load.done_code==0 && (service_i.load.done_regions!=plan_r ||
      (service_i.reserved & plan_r)!=plan_r || (service_i.complete & plan_r)!=plan_r));
  assign op_bad=service_i.op_done_id!=id_r || service_i.op_done_region!=work_r ||
    (service_i.op_done_code==0 && (!service_i.reserved[work_r] || !service_i.complete[work_r]));
  always_comb begin
    service_o='0;
    service_o.load.valid=state==LOAD_START && !fault_o;
    service_o.load.param=param_r;service_o.load.id=id_r;service_o.load.base=base_r;
    service_o.load.input_valid=state==LOAD_WAIT && input_valid_i && !fault_o;
    service_o.load.input_data=input_data_i;service_o.load.input_bytes=input_bytes_i;
    service_o.load.input_index=input_index_i;service_o.load.input_last=input_last_i;
    service_o.load.done_ready=state==LOAD_WAIT && !fault_o;
    service_o.op_valid=state==OP_START && !fault_o;
    service_o.op=ordinal_r<small_r?2'd3:2'd0;
    service_o.op_a_region=source_r;service_o.op_a_id=id_r;
    service_o.op_dest_region=work_r;service_o.op_id=id_r;
    service_o.op_done_ready=state==OP_WAIT && !fault_o;
    service_o.release_valid=!fault_o && (state==FREE_SOURCE || (state==CLEAN && owned_r[scan_r]));
    {service_o.release_bank,service_o.release_region}=state==FREE_SOURCE?source_r:scan_r;
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;id_r<=0;base_r<=0;work_r<=0;total_r<=0;small_r<=0;
      ordinal_r<=0;source_r<=0;scan_r<=0;plan_r<=0;owned_r<=0;handles_r<=0;
      rho_r<=0;key_r<=0;tr_r<=0;code_r<=0;detail_r<=0;clearing_r<=0;fault_o<=0;
    end else if(service_i.fault && state!=IDLE)begin fault_o<=1;state<=HALT;end
    else case(state)
      IDLE:if(command_valid_i && command_ready_o)begin
        param_r<=command_param_i;id_r<=command_id_i;base_r<=command_base_i;work_r<=command_work_i;
        total_r<=command_total[5:0];small_r<=command_small[5:0];plan_r<=command_plan;
        owned_r<=0;handles_r<=0;rho_r<=0;key_r<=0;tr_r<=0;ordinal_r<=0;scan_r<=0;
        source_r<=command_base_i;code_r<=0;detail_r<=0;clearing_r<=0;
        for(int j=0;j<23;j++)if(j<int'(command_total))handles_r[j]<=command_base_i+6'(j);
        if(command_param_i==3)begin code_r<=1;state<=REPORT;end
        else if(command_end>64 || command_plan[command_work_i])begin code_r<=2;state<=REPORT;end
        else state<=CHECK;
      end
      CHECK:begin
        // The outer operation owner must drain the previous services lease
        // BEFORE granting this control client;never consume another owner's done.
        if(!quiescent)begin code_r<=6;state<=REPORT;end
        else if(service_i.reserved[work_r])begin code_r<=3;state<=REPORT;end
        else if((service_i.reserved & plan_r)!=0)begin code_r<=4;detail_r<=4;state<=REPORT;end
        else state<=LOAD_START;
      end
      LOAD_START:if(service_i.load.ready)state<=LOAD_WAIT;
      LOAD_WAIT:if(service_i.load.done_valid)begin
        // All these regions were free at CHECK and only this owner can allocate.
        // Track actual reservations even if a result tag/mask is malformed.
        owned_r<=service_i.reserved & plan_r;
        if(((service_i.reserved & plan_r) & ~service_i.complete)!=0)begin fault_o<=1;state<=HALT;end
        else if(load_bad || service_i.load.done_code!=0)begin
          code_r<=load_bad?3'd6:3'd4;detail_r<=service_i.load.done_code;scan_r<=0;state<=CLEAN;
        end else begin
          rho_r<=service_i.load.rho;key_r<=service_i.load.key;tr_r<=service_i.load.tr;state<=OP_START;
        end
      end
      OP_START:if(service_i.op_ready)state<=OP_WAIT;
      OP_WAIT:if(service_i.op_done_valid)begin
        if(service_i.reserved[work_r])owned_r[work_r]<=1;
        if(service_i.reserved[work_r] && !service_i.complete[work_r])begin fault_o<=1;state<=HALT;end
        else if(op_bad || service_i.op_done_code!=0)begin
          code_r<=op_bad?3'd6:3'd5;detail_r<=service_i.op_done_code;scan_r<=0;state<=CLEAN;
        end else begin handles_r[ordinal_r]<=work_r;state<=FREE_SOURCE;end
      end
      FREE_SOURCE:if(service_i.release_ready)begin
        owned_r[source_r]<=0;work_r<=source_r;
        if(ordinal_r==total_r-1'b1)state<=REPORT;
        else begin ordinal_r<=ordinal_r+1'b1;source_r<=handles_r[ordinal_r+1'b1];state<=OP_START;end
      end
      REPORT:if(done_ready_i)state<=code_r==0?READY:IDLE;
      READY:if(clear_valid_i && clear_ready_o)begin
        rho_r<=0;key_r<=0;tr_r<=0;handles_r<=0;scan_r<=0;clearing_r<=1;state<=CLEAN;
      end
      CLEAN:if(!owned_r[scan_r] || service_i.release_ready)begin
        owned_r[scan_r]<=0;
        if(scan_r==63)begin
          rho_r<=0;key_r<=0;tr_r<=0;handles_r<=0;state<=clearing_r?IDLE:REPORT;
        end else scan_r<=scan_r+1'b1;
      end
      HALT:state<=HALT;
      default:begin fault_o<=1;state<=HALT;end
    endcase
  end
endmodule
`default_nettype wire
