// PK/signature front-end owner. Caller grants one exclusive services lease.
// PK bytes fork to Verify decoding and SHAKE256(H(PK));one elastic word stores
// independent sink credits. Error paths finish raw absorption with zeros and
// clean all frame regions before publishing an error. No key/signature RAM.
`default_nettype none
module verify_input_prepare (
  input wire logic clk,rst,command_valid_i,output logic command_ready_o,busy_o,fault_o,
  input wire logic [1:0] command_param_i,input wire logic [15:0] command_id_i,command_signature_len_i,
  input wire logic [5:0] command_base_i,
  input wire logic input_valid_i,output logic input_ready_o,input wire logic [63:0] input_data_i,
  input wire logic [3:0] input_bytes_i,input wire logic [15:0] input_index_i,input wire logic input_last_i,
  output logic done_valid_o,input wire logic done_ready_i,output logic [2:0] done_code_o,done_detail_o,
  output logic [15:0] done_id_o,
  output logic context_valid_o,output logic [1:0] context_param_o,output logic [15:0] context_id_o,
  output logic [63:0] context_regions_o,output logic [7:0][5:0] context_t1_o,context_hints_o,
  output logic [6:0][5:0] context_z_o,output logic [255:0] context_rho_o,
  output logic [511:0] context_tr_o,context_ctilde_o,
  input wire logic clear_valid_i,output logic clear_ready_o,input wire logic take_valid_i,output logic take_ready_o,
  output dilithium_service_pkg::request_t service_o,input dilithium_service_pkg::response_t service_i
);
  typedef enum logic [3:0] {IDLE,CHECK,PK_START,PK_WAIT,PK_JOIN,SIG_START,SIG_WAIT,SIG_RETIRE,REPORT,READY,CLEAN,HALT} state_e;
  state_e state;
  logic [1:0] param_r;logic [15:0] id_r,siglen_r;logic [5:0] base_r,k_r,l_r,scan_r;
  logic [63:0] plan_r,pk_plan_r,sig_plan_r,owned_r;logic [2:0] code_r,detail_r;
  logic [255:0] rho_r;logic [511:0] tr_r,ctilde_r;logic clearing_r;
  logic slot_r,dec_pending_r,hash_pending_r;logic [63:0] data_r;
  logic [15:0] index_r;logic [3:0] bytes_r;logic last_r;
  logic raw_started_r,raw_core_r,raw_retired_r;logic [15:0] raw_words_r;logic [6:0] raw_bytes_r;
  logic [6:0] cmd_end;logic [5:0] cmd_k,cmd_l;logic [63:0] cmd_plan,cmd_pk,cmd_sig;
  logic [15:0] pk_len;logic quiescent,host_fire,dec_fire,hash_fire,out_fire,raw_done,load_bad,raw_bad;
  always_comb begin
    cmd_k=command_param_i==0?6'd4:command_param_i==1?6'd6:6'd8;
    cmd_l=command_param_i==0?6'd4:command_param_i==1?6'd5:6'd7;
    cmd_end={1'b0,command_base_i}+7'(2*cmd_k+cmd_l);cmd_plan=0;cmd_pk=0;cmd_sig=0;
    for(int j=0;j<64;j++)begin
      if(j>=int'(command_base_i) && j<int'(cmd_end))begin
        cmd_plan[j]=1;if(j<int'(command_base_i)+int'(cmd_k))cmd_pk[j]=1;else cmd_sig[j]=1;
      end
    end
  end
  assign pk_len=param_r==0?16'd1312:param_r==1?16'd1952:16'd2592;
  assign quiescent=service_i.active==0 && !service_i.op_busy && !service_i.process_busy && !service_i.row_busy &&
    !service_i.sign.busy && !service_i.load.busy && !service_i.response_valid && service_i.read_ready &&
    service_i.pack.command_ready && !service_i.pack.output_valid && !service_i.pack.done_valid;
  assign command_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault;
  assign busy_o=state!=IDLE;assign done_valid_o=!rst && state==REPORT && !fault_o;
  assign done_code_o=code_r;assign done_detail_o=detail_r;assign done_id_o=id_r;
  assign context_valid_o=!rst && !fault_o && ((state==REPORT && code_r==0) || state==READY);
  assign context_param_o=context_valid_o?param_r:2'd0;assign context_id_o=context_valid_o?id_r:16'd0;
  assign context_regions_o=context_valid_o?owned_r:64'd0;
  assign context_rho_o=context_valid_o?rho_r:256'd0;assign context_tr_o=context_valid_o?tr_r:512'd0;
  assign context_ctilde_o=context_valid_o?ctilde_r:512'd0;
  always_comb begin
    context_t1_o=0;context_z_o=0;context_hints_o=0;
    if(context_valid_o)begin
      for(int j=0;j<8;j++)begin
        if(j<int'(k_r))begin context_t1_o[j]=base_r+6'(j);context_hints_o[j]=base_r+k_r+l_r+6'(j);end
      end
      for(int j=0;j<7;j++)if(j<int'(l_r))context_z_o[j]=base_r+k_r+6'(j);
    end
  end
  assign clear_ready_o=!rst && state==READY && quiescent && !fault_o && !service_i.fault;
  assign take_ready_o=clear_ready_o && !clear_valid_i;
  assign input_ready_o=!rst && !fault_o && ((state==PK_WAIT && !slot_r && service_i.load.input_ready && !service_i.load.done_valid) ||
    (state==SIG_WAIT && service_i.load.input_ready && !service_i.load.done_valid));
  assign host_fire=input_valid_i && input_ready_o;
  assign dec_fire=service_o.load.input_valid && service_i.load.input_ready;
  assign hash_fire=service_o.raw_input_valid && service_i.raw_input_ready;
  assign out_fire=service_i.raw_output_valid && service_o.raw_output_ready;
  assign raw_done=service_i.raw_done_valid && service_o.raw_done_ready;
  always_comb begin
    load_bad=service_i.load.done_id!=id_r;
    if(service_i.load.done_code==0)begin
      if(state==PK_WAIT)load_bad|=service_i.load.done_regions!=pk_plan_r || service_i.load.header_bytes!=32 ||
        (service_i.reserved & pk_plan_r)!=pk_plan_r || (service_i.complete & pk_plan_r)!=pk_plan_r;
      else load_bad|=service_i.load.done_regions!=sig_plan_r || service_i.load.header_bytes!=(param_r==0?7'd32:param_r==1?7'd48:7'd64) ||
        (service_i.reserved & sig_plan_r)!=sig_plan_r || (service_i.complete & sig_plan_r)!=sig_plan_r;
    end
    raw_bad=out_fire && (service_i.raw_output_core!=raw_core_r || service_i.raw_output_id!=id_r || service_i.raw_output_bytes!=16 ||
      raw_bytes_r>48 || raw_retired_r || raw_words_r!=(pk_len>>3));
    if(raw_done)raw_bad|=service_i.raw_done_core!=raw_core_r || service_i.raw_done_id!=id_r || raw_retired_r ||
      raw_bytes_r+(out_fire?7'd16:7'd0)!=64;
  end
  always_comb begin
    service_o='0;
    service_o.load.valid=(state==PK_START || state==SIG_START) && !fault_o;
    service_o.load.verify=1;service_o.load.kind=state==SIG_START || state==SIG_WAIT || state==SIG_RETIRE;
    service_o.load.param=param_r;service_o.load.id=id_r;service_o.load.base=service_o.load.kind?base_r+k_r:base_r;
    service_o.load.length=service_o.load.kind?siglen_r:pk_len;
    service_o.load.input_valid=!fault_o && ((state==PK_WAIT && slot_r && dec_pending_r) || (state==SIG_WAIT && input_valid_i));
    service_o.load.input_data=state==SIG_WAIT?input_data_i:data_r;
    service_o.load.input_bytes=state==SIG_WAIT?input_bytes_i:bytes_r;
    {service_o.load.input_index_hi,service_o.load.input_index}=state==SIG_WAIT?input_index_i:index_r;
    service_o.load.input_last=state==SIG_WAIT?input_last_i:last_r;
    service_o.load.done_ready=(state==PK_WAIT || state==SIG_WAIT) && !fault_o;
    service_o.raw_valid=state==PK_START && !fault_o;service_o.raw_mode=1;service_o.raw_id=id_r;
    service_o.raw_message_len=pk_len;service_o.raw_output_len=64;
    service_o.raw_input_valid=!fault_o && raw_started_r && !raw_retired_r &&
      ((slot_r && hash_pending_r) || (state==PK_JOIN && code_r!=0 && !slot_r && raw_words_r<(pk_len>>3)));
    service_o.raw_input_data=slot_r?data_r:64'd0;
    service_o.raw_output_ready=!fault_o && raw_started_r && !raw_retired_r;
    service_o.raw_done_ready=!fault_o && raw_started_r && !raw_retired_r;
    service_o.release_valid=state==CLEAN && owned_r[scan_r] && !fault_o;
    {service_o.release_bank,service_o.release_region}=scan_r;
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;id_r<=0;siglen_r<=0;base_r<=0;k_r<=0;l_r<=0;scan_r<=0;
      plan_r<=0;pk_plan_r<=0;sig_plan_r<=0;owned_r<=0;code_r<=0;detail_r<=0;rho_r<=0;tr_r<=0;ctilde_r<=0;clearing_r<=0;
      slot_r<=0;dec_pending_r<=0;hash_pending_r<=0;data_r<=0;index_r<=0;bytes_r<=0;last_r<=0;
      raw_started_r<=0;raw_core_r<=0;raw_retired_r<=0;raw_words_r<=0;raw_bytes_r<=0;fault_o<=0;
    end else if((service_i.fault && state!=IDLE) || raw_bad)begin fault_o<=1;state<=HALT;end
    else begin
      if(host_fire && state==PK_WAIT)begin slot_r<=1;dec_pending_r<=1;hash_pending_r<=1;data_r<=input_data_i;index_r<=input_index_i;bytes_r<=input_bytes_i;last_r<=input_last_i;end
      if(dec_fire && state==PK_WAIT)dec_pending_r<=0;
      if(hash_fire)begin raw_words_r<=raw_words_r+1'b1;if(slot_r)hash_pending_r<=0;end
      if(slot_r && (!dec_pending_r || dec_fire || state==PK_JOIN) && (!hash_pending_r || hash_fire))slot_r<=0;
      if(out_fire)begin tr_r[128*(raw_bytes_r>>4)+:128]<=service_i.raw_output_data;raw_bytes_r<=raw_bytes_r+16;end
      if(raw_done)raw_retired_r<=1;
      case(state)
        IDLE:if(command_valid_i && command_ready_o)begin
          param_r<=command_param_i;id_r<=command_id_i;siglen_r<=command_signature_len_i;base_r<=command_base_i;k_r<=cmd_k;l_r<=cmd_l;
          plan_r<=cmd_plan;pk_plan_r<=cmd_pk;sig_plan_r<=cmd_sig;owned_r<=0;scan_r<=0;code_r<=0;detail_r<=0;
          rho_r<=0;tr_r<=0;ctilde_r<=0;clearing_r<=0;slot_r<=0;dec_pending_r<=0;hash_pending_r<=0;
          raw_started_r<=0;raw_retired_r<=0;raw_words_r<=0;raw_bytes_r<=0;
          if(command_param_i==3 || command_signature_len_i!=(command_param_i==0?16'd2420:command_param_i==1?16'd3309:16'd4627))begin code_r<=1;state<=REPORT;end
          else if(cmd_end>64)begin code_r<=3;state<=REPORT;end else state<=CHECK;
        end
        CHECK:if(!quiescent)begin code_r<=2;state<=REPORT;end
          else if((service_i.reserved & plan_r)!=0)begin code_r<=3;detail_r<=4;state<=REPORT;end else state<=PK_START;
        PK_START:begin
          if(service_i.load.ready!=service_i.raw_ready)begin fault_o<=1;state<=HALT;end
          else if(service_i.load.ready)begin raw_core_r<=service_i.raw_core;raw_started_r<=1;state<=PK_WAIT;end
        end
        PK_WAIT:if(service_i.load.done_valid)begin
          owned_r<=service_i.reserved & plan_r;dec_pending_r<=0;
          if(((service_i.reserved & plan_r) & ~service_i.complete)!=0)begin fault_o<=1;state<=HALT;end
          else begin
            if(load_bad || service_i.load.done_code!=0)begin code_r<=load_bad?3'd6:3'd4;detail_r<=service_i.load.done_code;end
            else rho_r<=service_i.load.header[255:0];
            state<=PK_JOIN;
          end
        end
        PK_JOIN:if(!service_i.load.busy && raw_retired_r && service_i.active==0 && !slot_r)begin
          if(code_r!=0)begin scan_r<=0;state<=CLEAN;end else state<=SIG_START;
        end
        SIG_START:if(service_i.load.ready)state<=SIG_WAIT;
        SIG_WAIT:if(service_i.load.done_valid)begin
          owned_r<=service_i.reserved & plan_r;
          if(((service_i.reserved & plan_r) & ~service_i.complete)!=0)begin fault_o<=1;state<=HALT;end
          else begin
            if(load_bad || service_i.load.done_code!=0)begin code_r<=load_bad?3'd6:3'd5;detail_r<=service_i.load.done_code;end
            else ctilde_r<=service_i.load.header;
            state<=SIG_RETIRE;
          end
        end
        SIG_RETIRE:if(!service_i.load.busy)begin
          if(code_r!=0)begin scan_r<=0;state<=CLEAN;end else state<=REPORT;
        end
        REPORT:if(done_ready_i)state<=code_r==0?READY:IDLE;
        READY:if(clear_valid_i && clear_ready_o)begin clearing_r<=1;scan_r<=0;rho_r<=0;tr_r<=0;ctilde_r<=0;state<=CLEAN;end
          else if(take_valid_i && take_ready_o)begin owned_r<=0;rho_r<=0;tr_r<=0;ctilde_r<=0;state<=IDLE;end
        CLEAN:if(!owned_r[scan_r] || service_i.release_ready)begin
          owned_r[scan_r]<=0;
          if(scan_r==63)begin rho_r<=0;tr_r<=0;ctilde_r<=0;state<=clearing_r?IDLE:REPORT;end else scan_r<=scan_r+1'b1;
        end
        HALT:state<=HALT;
        default:begin fault_o<=1;state<=HALT;end
      endcase
    end
  end
endmodule
`default_nettype wire
