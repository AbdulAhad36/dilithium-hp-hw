// Adopt one accepted attempt;stream FIPS204 ctilde||z||sparse-hints.
// No signature RAM. Bytes are provisional until held done_code==0 retires.
// Upstream must retain the descriptor until take;after take this client owns
// all payload regions and releases them on completion or recoverable failure.
`default_nettype none
module sign_signature_encode (
  input wire logic clk,rst,command_valid_i,output logic command_ready_o,busy_o,fault_o,
  input wire logic [1:0] param_i,input wire logic [15:0] command_id_i,
  input wire logic source_valid_i,input wire logic [15:0] source_id_i,
  input wire logic [63:0] source_regions_i,
  input wire logic [6:0][5:0] source_z_i,input wire logic [7:0][5:0] source_hint_i,
  input wire logic [511:0] source_ctilde_i,input wire logic [6:0] source_bytes_i,
  output logic source_take_valid_o,input wire logic source_take_ready_i,
  output logic output_valid_o,input wire logic output_ready_i,
  output logic [63:0] output_data_o,output logic [3:0] output_bytes_o,
  output logic [9:0] output_index_o,output logic output_last_o,output logic [15:0] output_id_o,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic [2:0] done_code_o,output logic [15:0] done_id_o,
  output dilithium_service_pkg::request_t service_o,
  input dilithium_service_pkg::response_t service_i
);
  typedef enum logic [4:0] {IDLE,CHECK,TAKE,DIGEST,ZCMD,READ_REQ,READ_RESP,
    ZFEED,ZDRAIN,HSCAN,HPAD,HCOUNT,FLUSH,CLEAN,REPORT,HALT} state_e;
  state_e state;
  logic [1:0] param_r,lane_r;
  logic [15:0] id_r,sid_r;
  logic [63:0] source_r,owned_r,input_map;
  logic [6:0][5:0] z_r;logic [7:0][5:0] hint_r;
  logic [511:0] digest_r;logic [6:0] bytes_r;
  logic [3:0] rows_r,columns_r,poly_r,header_r,count_index_r;
  logic [5:0] word_r,scan_r;
  logic [91:0] cache_r;
  logic hints_r,layout_bad,source_changed,quiescent,pop;
  logic [7:0] omega_r,weight_r,hbytes_r;
  logic [7:0][7:0] counts_r;
  logic [63:0] buffer_r;logic [3:0] fill_r;
  logic [6:0] pack_word_r;
  logic [12:0] length_r,sent_r;
  logic [5:0] region;
  logic [22:0] coefficient;
  logic pack_phase,pack_bad;
  logic [31:0][5:0] input_list;logic [31:0] input_active;
  always_comb begin
    input_list='0;input_active=0;
    for(int j=0;j<7;j++)if(j<(param_i==0?4:param_i==1?5:7))begin
      input_list[j]=source_z_i[j];input_active[j]=1;
    end
    for(int j=0;j<8;j++)if(j<(param_i==0?4:param_i==1?6:8))begin
      input_list[7+j]=source_hint_i[j];input_active[7+j]=1;
    end
    input_map=dilithium_service_pkg::handle_mask(input_list,input_active);
    layout_bad=dilithium_service_pkg::handle_count(input_map)!=(param_i==0?7'd8:param_i==1?7'd11:7'd15);
    layout_bad|=input_map!=source_regions_i || source_bytes_i!=(param_i==0?32:param_i==1?48:64) ||
      (param_i==0 && source_ctilde_i[511:256]!=0) || (param_i==1 && source_ctilde_i[511:384]!=0);
  end
  assign source_changed=!source_valid_i || source_id_i!=sid_r || source_regions_i!=source_r ||
    source_z_i!=z_r || source_hint_i!=hint_r || source_bytes_i!=bytes_r || source_ctilde_i!=digest_r || param_i!=param_r;
  assign quiescent=service_i.active==0 && !service_i.op_busy && !service_i.process_busy && !service_i.sign.busy &&
    !service_i.load.busy && !service_i.row_busy && service_i.pack.command_ready &&
    !service_i.pack.done_valid && !service_i.pack.output_valid && service_i.read_ready && !service_i.response_valid;
  assign command_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault;
  assign busy_o=state!=IDLE;
  assign source_take_valid_o=!rst && state==TAKE && quiescent && !source_changed && !fault_o;
  assign done_valid_o=!rst && state==REPORT && !fault_o;
  assign done_id_o=id_r;assign output_id_o=id_r;
  assign region=hints_r?hint_r[poly_r]:z_r[poly_r];
  assign coefficient=cache_r[23*lane_r+:23];
  assign pack_phase=!hints_r && (state==READ_REQ || state==READ_RESP || state==ZFEED || state==ZDRAIN);
  assign pack_bad=service_i.pack.output_id!=id_r || service_i.pack.output_bytes!=8 ||
    service_i.pack.output_index!=pack_word_r || service_i.pack.output_last!=(pack_word_r==(param_r==0?71:79));
  always_comb begin
    output_valid_o=0;output_data_o=0;output_bytes_o=8;output_last_o=0;
    if(!rst && !fault_o)begin
      if(state==DIGEST)begin output_valid_o=1;output_data_o=digest_r[64*header_r+:64];end
      else if(pack_phase)begin output_valid_o=service_i.pack.output_valid && !pack_bad;output_data_o=service_i.pack.output_data;end
      else if(state==READ_REQ || state==READ_RESP || state==HSCAN || state==HPAD || state==HCOUNT || state==FLUSH)begin
        output_valid_o=fill_r==8 || (state==FLUSH && fill_r!=0);
        output_data_o=buffer_r;output_bytes_o=fill_r;
        output_last_o=state==FLUSH && sent_r+13'(fill_r)==length_r;
      end
    end
  end
  assign pop=output_valid_o && output_ready_i;
  always_comb begin
    service_o='0;
    service_o.pack.command_valid=!rst && !fault_o && state==ZCMD;
    service_o.pack.command_op=4;service_o.pack.command_param=param_r;service_o.pack.command_id=id_r;
    service_o.pack.input_valid=!rst && !fault_o && state==ZFEED && !service_i.pack.done_valid;
    service_o.pack.input_data=coefficient;service_o.pack.input_index={word_r,lane_r};
    service_o.pack.input_last=word_r==63 && lane_r==3;
    service_o.pack.output_ready=pack_phase && output_ready_i && !pack_bad && !fault_o;
    service_o.pack.done_ready=pack_phase && !fault_o;
    service_o.read_valid=!rst && !fault_o && state==READ_REQ && (hints_r || !service_i.pack.done_valid);
    {service_o.read_bank,service_o.read_region}=region;service_o.read_word=word_r;
    // A recoverable bad hint response may end the frame. First retire any
    // full output word so valid/data cannot disappear under backpressure.
    service_o.response_ready=!fault_o && state==READ_RESP && (!hints_r || fill_r<8);
    service_o.release_valid=!rst && !fault_o && state==CLEAN && owned_r[scan_r];
    {service_o.release_bank,service_o.release_region}=scan_r;
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;lane_r<=0;id_r<=0;sid_r<=0;source_r<=0;owned_r<=0;z_r<=0;hint_r<=0;
      digest_r<=0;bytes_r<=0;rows_r<=0;columns_r<=0;poly_r<=0;header_r<=0;count_index_r<=0;
      word_r<=0;scan_r<=0;cache_r<=0;hints_r<=0;omega_r<=0;weight_r<=0;hbytes_r<=0;counts_r<=0;
      buffer_r<=0;fill_r<=0;pack_word_r<=0;length_r<=0;sent_r<=0;output_index_o<=0;done_code_o<=0;fault_o<=0;
    end else if(state!=IDLE && (service_i.fault || (owned_r!=0 &&
      ((service_i.reserved & owned_r)!=owned_r || (service_i.complete & owned_r)!=owned_r))))begin
      fault_o<=1;state<=HALT;
    end else if(pack_phase && service_i.pack.output_valid && pack_bad)begin fault_o<=1;state<=HALT;
    end else if(pack_phase && service_i.pack.done_valid &&
      (service_i.pack.done_id!=id_r || state!=ZDRAIN || service_i.pack.done_code!=0))begin
      // A failed packer has retired;no speculative read may still be live.
      if(service_i.pack.done_id!=id_r || state==READ_RESP)begin fault_o<=1;state<=HALT;end
      else begin done_code_o<=2;scan_r<=0;state<=CLEAN;end
    end else begin
      if(pop)begin sent_r<=sent_r+13'(output_bytes_o);output_index_o<=output_index_o+1'b1;end
      if(pop && hints_r)begin fill_r<=0;buffer_r<=0;end
      case(state)
        IDLE:if(command_valid_i && command_ready_o)begin
          param_r<=param_i;id_r<=command_id_i;sid_r<=source_id_i;source_r<=source_regions_i;
          z_r<=source_z_i;hint_r<=source_hint_i;digest_r<=source_ctilde_i;bytes_r<=source_bytes_i;
          rows_r<=param_i==0?4:param_i==1?6:8;columns_r<=param_i==0?4:param_i==1?5:7;
          omega_r<=param_i==0?80:param_i==1?55:75;length_r<=param_i==0?2420:param_i==1?3309:4627;
          owned_r<=0;poly_r<=0;header_r<=0;count_index_r<=0;word_r<=0;lane_r<=0;scan_r<=0;hints_r<=0;
          weight_r<=0;hbytes_r<=0;counts_r<=0;buffer_r<=0;fill_r<=0;pack_word_r<=0;sent_r<=0;
          output_index_o<=0;done_code_o<=0;
          if(!source_valid_i || param_i==3 || layout_bad)begin done_code_o<=1;state<=REPORT;end else state<=CHECK;
        end
        CHECK:if(source_changed || (service_i.reserved & source_r)!=source_r || (service_i.complete & source_r)!=source_r)begin done_code_o<=1;state<=REPORT;end
          else if(quiescent)state<=TAKE;
        TAKE:if(source_changed)begin done_code_o<=1;state<=REPORT;end
          else if(source_take_valid_o && source_take_ready_i)begin owned_r<=source_r;state<=DIGEST;end
        DIGEST:if(pop)begin if(header_r+1=={1'b0,bytes_r[6:3]})begin header_r<=0;state<=ZCMD;end else header_r<=header_r+1'b1;end
        ZCMD:if(service_i.pack.command_ready)begin word_r<=0;lane_r<=0;pack_word_r<=0;state<=READ_REQ;end
        READ_REQ:if(service_i.read_ready && service_o.read_valid)state<=READ_RESP;
        READ_RESP:if(service_i.response_valid && service_o.response_ready)begin
          if(service_i.response_error || {service_i.response_bank,service_i.response_region}!=region || service_i.response_word!=word_r ||
            service_i.response_id!=sid_r || service_i.response_param!=param_r || service_i.response_mode!=(hints_r?0:2) || service_i.response_ntt_domain)begin
            // Z has a live pack command and cannot be canceled without reset.
            if(!hints_r)begin fault_o<=1;state<=HALT;end else begin done_code_o<=3;scan_r<=0;state<=CLEAN;end
          end else begin cache_r<=service_i.response_data;lane_r<=0;state<=hints_r?HSCAN:ZFEED;end
        end
        ZFEED:if(service_i.pack.input_ready)begin
          if(lane_r==3)begin lane_r<=0;if(word_r==63)state<=ZDRAIN;else begin word_r<=word_r+1'b1;state<=READ_REQ;end end
          else lane_r<=lane_r+1'b1;
        end
        ZDRAIN:if(service_i.pack.done_valid)begin
          if(pack_word_r!=(param_r==0?72:80))begin fault_o<=1;state<=HALT;end
          else if(poly_r+1<columns_r)begin poly_r<=poly_r+1'b1;state<=ZCMD;end
          else begin hints_r<=1;poly_r<=0;word_r<=0;lane_r<=0;state<=READ_REQ;end
        end
        HSCAN:if(fill_r<8)begin
          if(coefficient>1 || (coefficient==1 && weight_r==omega_r))begin done_code_o<=3;scan_r<=0;state<=CLEAN;end
          else begin
            if(coefficient==1)begin buffer_r[8*fill_r+:8]<={word_r,lane_r};fill_r<=fill_r+1'b1;weight_r<=weight_r+1'b1;hbytes_r<=hbytes_r+1'b1;end
            if(lane_r!=3)lane_r<=lane_r+1'b1;
            else if(word_r!=63)begin lane_r<=0;word_r<=word_r+1'b1;state<=READ_REQ;end
            else begin
              counts_r[poly_r]<=weight_r+8'(coefficient);
              if(poly_r+1<rows_r)begin poly_r<=poly_r+1'b1;word_r<=0;lane_r<=0;state<=READ_REQ;end
              else state<=HPAD;
            end
          end
        end
        HPAD:if(hbytes_r==omega_r)state<=HCOUNT;
          else if(fill_r<8)begin buffer_r[8*fill_r+:8]<=0;fill_r<=fill_r+1'b1;hbytes_r<=hbytes_r+1'b1;end
        HCOUNT:if(fill_r<8)begin
          buffer_r[8*fill_r+:8]<=counts_r[count_index_r];fill_r<=fill_r+1'b1;
          if(count_index_r+1==rows_r)state<=FLUSH;else count_index_r<=count_index_r+1'b1;
        end
        FLUSH:if(pop)begin
          if(sent_r+13'(output_bytes_o)!=length_r)begin fault_o<=1;state<=HALT;end
          else begin scan_r<=0;state<=CLEAN;end
        end
        CLEAN:if(!owned_r[scan_r] || service_i.release_ready)begin
          owned_r[scan_r]<=0;
          if(scan_r==63)begin digest_r<=0;state<=REPORT;end else scan_r<=scan_r+1'b1;
        end
        REPORT:if(done_ready_i)state<=IDLE;
        HALT:state<=HALT;
        default:begin fault_o<=1;state<=HALT;end
      endcase
      if(pack_phase && pop)pack_word_r<=pack_word_r+1'b1;
    end
  end
endmodule
`default_nettype wire
