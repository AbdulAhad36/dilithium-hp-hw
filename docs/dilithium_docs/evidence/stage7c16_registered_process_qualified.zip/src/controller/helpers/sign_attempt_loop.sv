// Signing attempt loop over the existing shared engines/banks. No message or
// polynomial RAM. Initial mu/seed hash occurs once; retries reuse both headers.
`default_nettype none
module sign_attempt_loop (
  input wire logic clk,rst,command_valid_i,output logic command_ready_o,busy_o,fault_o,
  input wire logic context_valid_i,input wire logic [1:0] context_param_i,
  input wire logic [15:0] context_id_i,input wire logic [63:0] context_regions_i,
  input wire logic [22:0][5:0] context_handles_i,
  input wire logic [255:0] context_rho_i,context_key_i,input wire logic [511:0] context_tr_i,
  input wire logic [15:0] command_id_i,command_message_len_i,input wire logic [16:0] command_nonce_i,
  input wire logic [8:0] command_context_len_i,input wire logic [5:0] command_base_i,
  input wire logic [255:0] command_rnd_i,
  input wire logic payload_valid_i,output logic payload_ready_o,input wire logic [63:0] payload_data_i,
  input wire logic [3:0] payload_bytes_i,input wire logic [15:0] payload_index_i,input wire logic payload_last_i,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic [2:0] done_code_o,done_stage_o,done_detail_o,output logic [15:0] done_id_o,
  output logic [16:0] attempts_o,rejections_o,next_nonce_o,
  output logic result_valid_o,output logic [63:0] result_regions_o,
  output logic [6:0][5:0] result_z_o,output logic [7:0][5:0] result_hint_o,
  output logic [511:0] result_ctilde_o,output logic [6:0] result_bytes_o,
  input wire logic clear_valid_i,output logic clear_ready_o,
  input wire logic take_valid_i,output logic take_ready_o,
  output dilithium_service_pkg::request_t service_o,input dilithium_service_pkg::response_t service_i
);
  import dilithium_service_pkg::*;
  typedef enum logic [3:0] {IDLE,START,WAIT_CHILD,RETIRE,RETRY_TAKE,REPORT,READY,CLEAN_START,CLEAN_WAIT,HALT} state_e;
  state_e state;
  logic [2:0] stage_r,clean_r,code_r,detail_r,error_stage_r;
  logic [1:0] param_r;logic [3:0] length_r;logic [15:0] id_r,key_id_r,mlen_r;
  logic [8:0] ctx_r;logic [5:0] base_r;logic [16:0] nonce_r,attempts_r,rejections_r;
  logic [17:0] nonce_end;logic [63:0] key_regions_r;logic [22:0][5:0] keys_r;
  logic [255:0] rho_r,key_r,rnd_r;logic [511:0] tr_r,retry_mu_r,retry_seed_r;
  logic retry_r,clearing_r,quiescent,changed;
  request_t req[0:5];logic [5:0] cv,cr,cbusy,cfault,dv,dr,rv,clv,clr,tv,tr;
  logic [2:0] dc[0:5],dd[0:5];logic [15:0] di[0:5];logic [63:0] maps[0:5];
  logic [6:0][5:0] y,yhat,z,out_z;
  logic [7:0][5:0] matrix_low,matrix_high,trans_low,trans_high,prod_low,prod_high,ct0,out_hint;
  logic [5:0] challenge_region,chat;logic [15:0] trans_matrix_id,prod_high_id,z_id;
  logic [511:0] mu,seed,challenge_digest,trans_digest,prod_mu,prod_seed,prod_digest,out_mu,out_seed,out_digest;
  logic [6:0] challenge_bytes,trans_bytes,prod_bytes,out_bytes;
  logic [16:0] prod_nonce,out_nonce;logic reject,result_reject;logic [2:0] reason;logic [11:0] weight;
  logic transform_matrix_take,transform_challenge_take,products_mask_take,products_vector_take,check_vector_take;
  logic mpready;
  assign dd[0]=0;
  sign_mask_prepare masks(.clk(clk),.rst(rst),.command_valid_i(cv[0]),.command_ready_o(cr[0]),.busy_o(cbusy[0]),.fault_o(cfault[0]),
    .context_valid_i(context_valid_i),.context_param_i(param_r),.context_id_i(key_id_r),.context_regions_i(key_regions_r),
    .context_key_i(key_r),.context_tr_i(tr_r),.command_id_i(id_r),.command_message_len_i(mlen_r),.command_nonce_i(nonce_r[15:0]),
    .command_context_len_i(ctx_r),.command_base_i(base_r),.command_rnd_i(rnd_r),
    .command_retry_i(retry_r),.command_retry_mu_i(retry_mu_r),.command_retry_seed_i(retry_seed_r),
    .payload_valid_i(payload_valid_i && state==WAIT_CHILD && stage_r==0 && !retry_r),.payload_ready_o(mpready),
    .payload_data_i(payload_data_i),.payload_bytes_i(payload_bytes_i),.payload_index_i(payload_index_i),.payload_last_i(payload_last_i),
    .done_valid_o(dv[0]),.done_ready_i(dr[0]),.done_code_o(dc[0]),.done_id_o(di[0]),
    .result_valid_o(rv[0]),.result_mu_o(mu),.result_seed_o(seed),.result_regions_o(maps[0]),.result_handles_o(y),
    .clear_valid_i(clv[0]),.clear_ready_o(clr[0]),.take_valid_i(tv[0]),.take_ready_o(tr[0]),.service_o(req[0]),.service_i(service_i));
  sign_matrix_prepare matrix(.clk(clk),.rst(rst),.command_valid_i(cv[1]),.command_ready_o(cr[1]),.busy_o(cbusy[1]),.fault_o(cfault[1]),
    .command_id_i(id_r),.context_valid_i(context_valid_i),.context_param_i(param_r),.context_id_i(key_id_r),
    .context_regions_i(key_regions_r),.context_rho_i(rho_r),.mask_valid_i(rv[0]),.mask_id_i(di[0]),.mask_regions_i(maps[0]),.mask_handles_i(y),
    .done_valid_o(dv[1]),.done_ready_i(dr[1]),.done_code_o(dc[1]),.done_detail_o(dd[1]),.done_id_o(di[1]),
    .result_valid_o(rv[1]),.result_regions_o(maps[1]),.result_yhat_o(yhat),.result_low_o(matrix_low),.result_high_o(matrix_high),
    .clear_valid_i(clv[1]),.clear_ready_o(clr[1]),.take_valid_i(tv[1]),.take_ready_o(tr[1]),.service_o(req[1]),.service_i(service_i));
  sign_challenge_prepare challenge(.clk(clk),.rst(rst),.command_valid_i(cv[2]),.command_ready_o(cr[2]),.busy_o(cbusy[2]),.fault_o(cfault[2]),
    .command_id_i(id_r),.context_valid_i(rv[1]),.context_param_i(param_r),.context_id_i(di[1]),.context_regions_i(maps[1]),
    .context_high_i(matrix_high),.context_mu_i(mu),.done_valid_o(dv[2]),.done_ready_i(dr[2]),.done_code_o(dc[2]),
    .done_detail_o(dd[2]),.done_id_o(di[2]),.result_valid_o(rv[2]),.result_ctilde_o(challenge_digest),
    .result_bytes_o(challenge_bytes),.result_region_o(challenge_region),.clear_valid_i(clv[2]),.clear_ready_o(clr[2]),
    .take_valid_i(tv[2]),.take_ready_o(tr[2]),.service_o(req[2]),.service_i(service_i));
  assign maps[2]=rv[2]?(64'd1<<challenge_region):64'd0;
  sign_challenge_transform transform(.clk(clk),.rst(rst),.command_valid_i(cv[3]),.command_ready_o(cr[3]),.busy_o(cbusy[3]),.fault_o(cfault[3]),
    .command_id_i(id_r),.key_valid_i(context_valid_i),.mask_valid_i(rv[0]),.param_i(param_r),.key_id_i(key_id_r),.mask_id_i(di[0]),
    .key_regions_i(key_regions_r),.mask_regions_i(maps[0]),.matrix_valid_i(rv[1]),.matrix_id_i(di[1]),.matrix_regions_i(maps[1]),
    .matrix_yhat_i(yhat),.matrix_low_i(matrix_low),.matrix_high_i(matrix_high),.challenge_valid_i(rv[2]),.challenge_id_i(di[2]),
    .challenge_region_i(challenge_region),.challenge_bytes_i(challenge_bytes),.challenge_ctilde_i(challenge_digest),
    .matrix_take_valid_o(transform_matrix_take),.challenge_take_valid_o(transform_challenge_take),.matrix_take_ready_i(tr[1]),.challenge_take_ready_i(tr[2]),
    .done_valid_o(dv[3]),.done_ready_i(dr[3]),.done_code_o(dc[3]),.done_detail_o(dd[3]),.done_id_o(di[3]),
    .result_valid_o(rv[3]),.result_regions_o(maps[3]),.result_low_o(trans_low),.result_high_o(trans_high),.result_matrix_id_o(trans_matrix_id),
    .result_chat_o(chat),.result_ctilde_o(trans_digest),.result_bytes_o(trans_bytes),
    .clear_valid_i(clv[3]),.clear_ready_o(clr[3]),.take_valid_i(tv[3]),.take_ready_o(tr[3]),.service_o(req[3]),.service_i(service_i));
  sign_response_products products(.clk(clk),.rst(rst),.command_valid_i(cv[4]),.command_ready_o(cr[4]),.busy_o(cbusy[4]),.fault_o(cfault[4]),
    .command_id_i(id_r),.key_valid_i(context_valid_i),.param_i(param_r),.key_id_i(key_id_r),.key_regions_i(key_regions_r),.key_handles_i(keys_r),
    .mask_valid_i(rv[0]),.mask_id_i(di[0]),.mask_nonce_i(nonce_r[15:0]),.mask_regions_i(maps[0]),.mask_handles_i(y),.mask_mu_i(mu),.mask_seed_i(seed),
    .vector_valid_i(rv[3]),.vector_id_i(di[3]),.vector_matrix_id_i(trans_matrix_id),.vector_regions_i(maps[3]),
    .vector_low_i(trans_low),.vector_high_i(trans_high),.vector_chat_i(chat),.vector_ctilde_i(trans_digest),.vector_bytes_i(trans_bytes),
    .mask_take_valid_o(products_mask_take),.vector_take_valid_o(products_vector_take),.mask_take_ready_i(tr[0]),.vector_take_ready_i(tr[3]),
    .done_valid_o(dv[4]),.done_ready_i(dr[4]),.done_code_o(dc[4]),.done_detail_o(dd[4]),.done_id_o(di[4]),
    .result_valid_o(rv[4]),.result_regions_o(maps[4]),.result_z_o(z),.result_low_o(prod_low),.result_high_o(prod_high),.result_ct0_o(ct0),
    .result_high_id_o(prod_high_id),.result_mu_o(prod_mu),.result_seed_o(prod_seed),.result_ctilde_o(prod_digest),
    .result_bytes_o(prod_bytes),.result_next_nonce_o(prod_nonce),.clear_valid_i(clv[4]),.clear_ready_o(clr[4]),
    .take_valid_i(tv[4]),.take_ready_o(tr[4]),.service_o(req[4]),.service_i(service_i));
  sign_attempt_check bounds(.clk(clk),.rst(rst),.command_valid_i(cv[5]),.command_ready_o(cr[5]),.busy_o(cbusy[5]),.fault_o(cfault[5]),
    .command_id_i(id_r),.key_valid_i(context_valid_i),.param_i(param_r),.key_id_i(key_id_r),.key_regions_i(key_regions_r),.key_handles_i(keys_r),
    .vector_valid_i(rv[4]),.vector_id_i(di[4]),.vector_high_id_i(prod_high_id),.vector_regions_i(maps[4]),.vector_z_i(z),
    .vector_low_i(prod_low),.vector_high_i(prod_high),.vector_ct0_i(ct0),.vector_mu_i(prod_mu),.vector_seed_i(prod_seed),.vector_ctilde_i(prod_digest),
    .vector_bytes_i(prod_bytes),.vector_next_nonce_i(prod_nonce),.vector_take_valid_o(check_vector_take),.vector_take_ready_i(tr[4]),
    .done_valid_o(dv[5]),.done_ready_i(dr[5]),.done_code_o(dc[5]),.done_detail_o(dd[5]),.done_reason_o(reason),
    .done_reject_o(reject),.done_weight_o(weight),.done_id_o(di[5]),.result_valid_o(rv[5]),.result_reject_o(result_reject),
    .result_regions_o(maps[5]),.result_z_o(out_z),.result_hint_o(out_hint),.result_z_id_o(z_id),
    .result_mu_o(out_mu),.result_seed_o(out_seed),.result_ctilde_o(out_digest),.result_bytes_o(out_bytes),.result_next_nonce_o(out_nonce),
    .clear_valid_i(clv[5]),.clear_ready_o(clr[5]),.take_valid_i(tv[5]),.take_ready_o(tr[5]),.service_o(req[5]),.service_i(service_i));
  assign nonce_end={1'b0,nonce_r}+18'(length_r);
  assign changed=!context_valid_i || context_param_i!=param_r || context_id_i!=key_id_r || context_regions_i!=key_regions_r ||
    context_handles_i!=keys_r || context_rho_i!=rho_r || context_key_i!=key_r || context_tr_i!=tr_r;
  assign quiescent=service_i.active==0 && !service_i.op_busy && !service_i.process_busy && !service_i.sign.busy &&
    !service_i.load.busy && !service_i.row_busy && service_i.pack.command_ready && !service_i.pack.output_valid &&
    !service_i.pack.done_valid && !service_i.response_valid && service_i.read_ready;
  assign command_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault && cfault==0;
  assign busy_o=state!=IDLE;assign payload_ready_o=state==WAIT_CHILD && stage_r==0 && !retry_r && mpready && !fault_o;
  assign done_valid_o=!rst && !fault_o && state==REPORT;assign done_code_o=code_r;assign done_detail_o=detail_r;
  assign done_stage_o=error_stage_r;assign done_id_o=id_r;assign attempts_o=attempts_r;assign rejections_o=rejections_r;
  assign next_nonce_o=nonce_r;
  assign result_valid_o=!rst && !fault_o && ((state==REPORT && code_r==0) || state==READY);
  assign result_regions_o=result_valid_o?maps[5]:64'd0;assign result_ctilde_o=result_valid_o?out_digest:512'd0;
  assign result_bytes_o=result_valid_o?out_bytes:7'd0;
  assign result_z_o=result_valid_o?out_z:'0;assign result_hint_o=result_valid_o?out_hint:'0;
  assign clear_ready_o=!rst && !fault_o && state==READY && quiescent && clr[5];
  assign take_ready_o=clear_ready_o && !clear_valid_i && tr[5];
  always_comb begin
    cv=0;dr=0;clv=0;tv=0;
    if(state==START && !fault_o && !(stage_r==0 && nonce_end>65536))cv[stage_r]=1;
    if(state==WAIT_CHILD && !fault_o)dr[stage_r]=1;
    tv[0]=products_mask_take;tv[1]=transform_matrix_take;tv[2]=transform_challenge_take;tv[3]=products_vector_take;tv[4]=check_vector_take;
    tv[5]=!fault_o && ((state==RETRY_TAKE && quiescent) || (state==READY && take_valid_i && !clear_valid_i && quiescent));
    if(state==CLEAN_START && rv[clean_r] && !fault_o)clv[clean_r]=1;
    service_o=(state==CLEAN_START || state==CLEAN_WAIT)?req[clean_r]:req[stage_r];
    if(state==IDLE || state==HALT || fault_o)service_o='0;
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;stage_r<=0;clean_r<=5;code_r<=0;detail_r<=0;error_stage_r<=0;param_r<=0;length_r<=0;
      id_r<=0;key_id_r<=0;mlen_r<=0;ctx_r<=0;base_r<=0;nonce_r<=0;attempts_r<=0;rejections_r<=0;
      key_regions_r<=0;keys_r<=0;rho_r<=0;key_r<=0;tr_r<=0;rnd_r<=0;retry_mu_r<=0;retry_seed_r<=0;
      retry_r<=0;clearing_r<=0;fault_o<=0;
    end else if(state!=IDLE && (service_i.fault || cfault!=0 || ((state!=REPORT || code_r==0) && changed)))begin
      fault_o<=1;state<=HALT;
    end else case(state)
      IDLE:if(command_valid_i && command_ready_o)begin
        param_r<=context_param_i;key_id_r<=context_id_i;key_regions_r<=context_regions_i;keys_r<=context_handles_i;
        rho_r<=context_rho_i;key_r<=context_key_i;tr_r<=context_tr_i;rnd_r<=command_rnd_i;
        id_r<=command_id_i;mlen_r<=command_message_len_i;ctx_r<=command_context_len_i;base_r<=command_base_i;nonce_r<=command_nonce_i;
        length_r<=context_param_i==0?4'd4:(context_param_i==1?4'd5:4'd7);stage_r<=0;code_r<=0;detail_r<=0;error_stage_r<=0;
        attempts_r<=0;rejections_r<=0;retry_r<=0;retry_mu_r<=0;retry_seed_r<=0;clearing_r<=0;
        if(!context_valid_i || context_param_i==3)begin code_r<=1;state<=REPORT;end else state<=START;
      end
      START:if(stage_r==0 && nonce_end>65536)begin code_r<=6;error_stage_r<=0;clean_r<=5;state<=CLEAN_START;end
        else if(cv[stage_r] && cr[stage_r])begin if(stage_r==0)attempts_r<=attempts_r+1'b1;state<=WAIT_CHILD;end
      WAIT_CHILD:if(dv[stage_r])begin
        if(dc[stage_r]!=0)begin code_r<=2;detail_r<=dc[stage_r];error_stage_r<=stage_r;end
        else if(di[stage_r]!=id_r || !rv[stage_r])begin code_r<=3;error_stage_r<=stage_r;end
        state<=RETIRE;
      end
      RETIRE:if(!dv[stage_r])begin
        if(code_r!=0)begin clean_r<=5;state<=CLEAN_START;end
        else if(stage_r!=5)begin stage_r<=stage_r+1'b1;state<=START;end
        else if(reject)begin rejections_r<=rejections_r+1'b1;state<=RETRY_TAKE;end
        else begin nonce_r<=out_nonce;state<=REPORT;end
      end
      RETRY_TAKE:if(tv[5] && tr[5])begin
        if(!rv[5] || !result_reject || maps[5]!=0 || out_nonce<=nonce_r || out_nonce!={1'b0,nonce_r[15:0]}+17'(length_r))begin fault_o<=1;state<=HALT;end
        else begin retry_mu_r<=out_mu;retry_seed_r<=out_seed;nonce_r<=out_nonce;retry_r<=1;stage_r<=0;state<=START;end
      end
      REPORT:if(done_ready_i)state<=code_r==0?READY:IDLE;
      READY:if(clear_valid_i && clear_ready_o)begin clearing_r<=1;clean_r<=5;state<=CLEAN_START;end
        else if(take_valid_i && take_ready_o)begin retry_mu_r<=0;retry_seed_r<=0;state<=IDLE;end
      CLEAN_START:if(!rv[clean_r] && !cbusy[clean_r])begin
        if(clean_r==0)begin retry_mu_r<=0;retry_seed_r<=0;state<=clearing_r?IDLE:REPORT;end else clean_r<=clean_r-1'b1;
      end else if(clv[clean_r] && clr[clean_r])state<=CLEAN_WAIT;
      CLEAN_WAIT:if(!cbusy[clean_r])begin
        if(clean_r==0)begin retry_mu_r<=0;retry_seed_r<=0;state<=clearing_r?IDLE:REPORT;end
        else begin clean_r<=clean_r-1'b1;state<=CLEAN_START;end
      end
      HALT:state<=HALT;
      default:begin fault_o<=1;state<=HALT;end
    endcase
  end
endmodule
`default_nettype wire
