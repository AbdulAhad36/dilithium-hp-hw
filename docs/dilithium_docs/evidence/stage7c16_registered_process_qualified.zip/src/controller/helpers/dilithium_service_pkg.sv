// Shared engine/packed-bank service types. Request fields drive engine inputs.
// No data queues or protocol conversion:all payloads/tags retain their widths.
package dilithium_service_pkg;
  // Decode independently; inactive payload bits have no effect. For N active
  // handles, this union contains N bits exactly when all handles are distinct.
  function automatic logic [63:0] handle_mask(
    input logic [31:0][5:0] handles, input logic [31:0] active);
    logic [63:0] mask;
    mask=0;
    for(int j=0;j<32;j++)if(active[j])mask|=64'd1<<handles[j];
    return mask;
  endfunction
  // Explicit balanced tree, seven bits including the all-64-regions case.
  // One count of the combined sets replaces quadratic pairwise comparisons.
  function automatic logic [6:0] handle_count(input logic [63:0] mask);
    logic [6:0] tree[0:126];
    for(int j=0;j<64;j++)tree[63+j]={6'd0,mask[j]};
    for(int j=62;j>=0;j--)tree[j]=tree[2*j+1]+tree[2*j+2];
    return tree[0];
  endfunction
  // One exclusive streamed-key client of the existing physical banks.
  typedef struct packed {
    logic valid;
    // Zero retains the expanded-secret-key client. Verify uses full16-bit
    // indices split across the original low field and input_index_hi.
    logic verify,kind;
    logic [15:0] length;
    logic [5:0] input_index_hi;
    logic [1:0] param;
    logic [15:0] id;
    logic [5:0] base;
    logic input_valid;
    logic [63:0] input_data;
    logic [3:0] input_bytes;
    logic [9:0] input_index;
    logic input_last,done_ready;
  } sign_load_request_t;
  typedef struct packed {
    logic ready,busy,input_ready,done_valid;
    logic [2:0] done_code;
    logic [15:0] done_id;
    logic [63:0] done_regions;
    logic [255:0] rho,key;
    logic [511:0] tr;
    logic [511:0] header;
    logic [6:0] header_bytes;
  } sign_load_response_t;
  typedef struct packed {
    logic valid;
    logic [1:0] op,param,kind;
    logic [5:0] a,b,dest,high;
    logic [15:0] a_id,b_id,id;
    logic done_ready;
  } sign_request_t;
  typedef struct packed {
    logic ready,busy,done_valid;
    logic [2:0] done_code;
    logic [15:0] done_id;
    logic [5:0] done_dest,done_high;
    logic done_reject;
    logic [8:0] done_weight;
  } sign_response_t;
  typedef struct packed {
    logic command_valid;
    logic [2:0] command_op;
    logic [1:0] command_param;
    logic [15:0] command_id;
    logic input_valid;
    logic [22:0] input_data;
    logic [7:0] input_index;
    logic input_last;
    logic output_ready;
    logic done_ready;
  } pack_request_t;
  typedef struct packed {
    logic command_ready;
    logic input_ready;
    logic output_valid;
    logic [63:0] output_data;
    logic [3:0] output_bytes;
    logic [6:0] output_index;
    logic output_last;
    logic [15:0] output_id;
    logic done_valid;
    logic [2:0] done_code;
    logic [15:0] done_id;
  } pack_response_t;
  typedef struct packed {
    logic raw_valid;
    logic raw_mode;
    logic [15:0] raw_id;
    logic [15:0] raw_message_len;
    logic [15:0] raw_output_len;
    logic [63:0] raw_input_data;
    logic raw_input_valid;
    logic raw_output_ready;
    logic raw_done_ready;
    logic job_valid;
    logic [1:0] job_bank;
    logic [1:0] job_mode;
    logic [1:0] job_param;
    logic [3:0] job_region;
    logic [15:0] job_id;
    logic [15:0] message_len;
    logic [63:0] input_data;
    logic input_valid;
    logic status_ready;
    logic read_valid;
    logic [1:0] read_bank;
    logic [3:0] read_region;
    logic [5:0] read_word;
    logic response_ready;
    logic release_valid;
    logic [1:0] release_bank;
    logic [3:0] release_region;
    logic op_valid;
    logic [1:0] op;
    logic [5:0] op_a_region;
    logic [5:0] op_b_region;
    logic [5:0] op_dest_region;
    logic [15:0] op_a_id;
    logic [15:0] op_b_id;
    logic [15:0] op_id;
    logic op_done_ready;
    logic process_valid;
    logic [1:0] process_op;
    logic process_inplace;
    logic [5:0] process_a;
    logic [5:0] process_b;
    logic [5:0] process_dest;
    logic [5:0] process_high;
    logic [15:0] process_a_id;
    logic [15:0] process_b_id;
    logic [15:0] process_id;
    logic process_done_ready;
    logic row_valid;
    logic [1:0] row_param;
    logic [3:0] row_index;
    logic [15:0] row_id;
    logic [5:0] row_acc;
    logic [5:0] row_scratch;
    logic [5:0] row_result;
    logic [6:0][5:0] row_a;
    logic [6:0][5:0] row_s;
    logic [6:0][15:0] row_a_id;
    logic [6:0][15:0] row_s_id;
    logic row_done_ready;
    pack_request_t pack;
    sign_request_t sign;
    sign_load_request_t load;
  } request_t;
  typedef struct packed {
    logic raw_ready;
    sign_response_t sign;
    sign_load_response_t load;
    logic raw_core;
    logic raw_input_ready;
    logic raw_output_valid;
    logic raw_output_core;
    logic [15:0] raw_output_id;
    logic [127:0] raw_output_data;
    logic [4:0] raw_output_bytes;
    logic raw_done_valid;
    logic raw_done_core;
    logic [15:0] raw_done_id;
    logic job_ready;
    logic job_core;
    logic input_ready;
    logic status_valid;
    logic status_core;
    logic [15:0] status_id;
    logic [2:0] status_code;
    logic [1:0] active;
    logic read_ready;
    logic response_valid;
    logic response_error;
    logic [1:0] response_bank;
    logic [1:0] response_mode;
    logic [1:0] response_param;
    logic [3:0] response_region;
    logic [5:0] response_word;
    logic [91:0] response_data;
    logic [15:0] response_id;
    logic response_ntt_domain;
    logic response_small;
    logic release_ready;
    logic [63:0] reserved;
    logic [63:0] complete;
    logic fault;
    logic op_ready;
    logic op_busy;
    logic op_done_valid;
    logic [2:0] op_done_code;
    logic [15:0] op_done_id;
    logic [5:0] op_done_region;
    logic process_ready;
    logic process_busy;
    logic process_done_valid;
    logic [2:0] process_done_code;
    logic [15:0] process_done_id;
    logic [5:0] process_done_dest;
    logic [5:0] process_done_high;
    logic row_ready;
    logic row_busy;
    logic row_done_valid;
    logic [2:0] row_done_code;
    logic [2:0] row_completed_terms;
    logic [15:0] row_done_id;
    logic [5:0] row_done_region;
    pack_response_t pack;
  } response_t;
endpackage
