// Verify frame -> existing scalar bank writer. All region commits are tentative
// until the whole frame decodes successfully. No extra coefficient RAM.
`default_nettype none
module verify_frame_load (
  input wire logic clk,rst,command_valid_i,output logic command_ready_o,busy_o,fault_o,
  input wire logic command_kind_i,input wire logic [1:0] command_param_i,
  input wire logic [15:0] command_id_i,command_length_i,input wire logic [5:0] command_base_i,
  input wire logic input_valid_i,output logic input_ready_o,input wire logic [63:0] input_data_i,
  input wire logic [3:0] input_bytes_i,input wire logic [15:0] input_index_i,input wire logic input_last_i,
  output logic done_valid_o,input wire logic done_ready_i,output logic [2:0] done_code_o,
  output logic [15:0] done_id_o,output logic [63:0] done_regions_o,
  output logic [511:0] header_o,output logic [6:0] header_bytes_o,
  input wire logic [63:0] reserved_i,output logic [63:0] release_locks_o,hidden_o,
  output logic alloc_valid_o,output logic [5:0] alloc_region_o,output logic [15:0] alloc_id_o,
  output logic [1:0] alloc_mode_o,alloc_param_o,input wire logic alloc_ready_i,
  output logic write_valid_o,write_last_o,output logic [15:0] write_id_o,
  output logic [7:0] write_index_o,output logic [22:0] write_data_o,input wire logic write_ready_i,
  output logic finish_valid_o,output logic [15:0] finish_id_o,output logic [2:0] finish_code_o,
  input wire logic finish_ready_i,output logic release_valid_o,output logic [5:0] release_region_o,
  input wire logic release_ready_i
);
  typedef enum logic [3:0] {IDLE,CHECK,START,ALLOC,RUN,COMMIT,WAIT_DONE,ABORT_PARTIAL,CLEAN,REPORT,HALT} state_e;
  state_e state;
  logic kind_r,active_r;logic [1:0] param_r;logic [15:0] id_r,length_r;
  logic [5:0] base_r,ordinal_r,total_r,l_r,scan_r;logic [7:0] index_r;logic [2:0] code_r;
  logic [63:0] plan_r,committed_r,command_plan;logic [6:0] command_total,command_end;
  logic [511:0] header_r;logic [6:0] bytes_r;
  logic dr,db,di,dh,dv,dl,df,dd;logic [2:0] dc,dp;logic [1:0] ds;
  logic [7:0] dx;logic [22:0] data;logic [15:0] did,hid,doneid;logic [511:0] header;logic [6:0] bytes;
  logic bad;logic [1:0] section;logic [5:0] poly;
  always_comb begin
    command_total=command_param_i==0?7'd4:command_param_i==1?7'd6:7'd8;
    if(command_kind_i)command_total=command_total+(command_param_i==0?7'd4:command_param_i==1?7'd5:7'd7);
    command_end={1'b0,command_base_i}+command_total;command_plan=0;
    for(int j=0;j<64;j++)if(j>=int'(command_base_i) && j<int'(command_end))command_plan[j]=1;
  end
  assign command_ready_o=!rst && state==IDLE && !fault_o;assign busy_o=state!=IDLE;
  assign done_valid_o=!rst && state==REPORT && !fault_o;assign done_code_o=code_r;assign done_id_o=id_r;
  assign done_regions_o=done_valid_o && code_r==0?plan_r:64'd0;
  assign header_o=done_valid_o && code_r==0?header_r:512'd0;
  assign header_bytes_o=done_valid_o && code_r==0?bytes_r:7'd0;
  assign release_locks_o=busy_o?plan_r:64'd0;
  assign hidden_o=busy_o && !(state==REPORT && code_r==0)?plan_r:64'd0;
  assign alloc_valid_o=!rst && state==ALLOC && !fault_o;assign alloc_region_o=base_r+ordinal_r;
  assign alloc_id_o=id_r;assign alloc_param_o=param_r;
  assign alloc_mode_o=kind_r && ordinal_r<l_r?2'd2:2'd3;
  assign section=!kind_r?2'd0:ordinal_r<l_r?2'd1:2'd2;
  assign poly=kind_r && ordinal_r>=l_r?ordinal_r-l_r:ordinal_r;
  assign bad=ds!=section || {3'd0,dp}!=poly || dx!=index_r || did!=id_r || dl!=(index_r==255) || df!=(index_r==255 && ordinal_r==total_r-1'b1);
  assign input_ready_o=!rst && state==RUN && di && !fault_o;
  assign write_valid_o=!rst && state==RUN && active_r && dv && !bad && !fault_o;
  assign write_data_o=data;assign write_index_o=dx;assign write_last_o=dl;assign write_id_o=id_r;
  assign finish_valid_o=!rst && !fault_o && (state==COMMIT || (state==ABORT_PARTIAL && active_r));
  assign finish_id_o=id_r;assign finish_code_o=state==COMMIT?3'd0:3'd1;
  assign release_valid_o=!rst && state==CLEAN && committed_r[scan_r] && !fault_o;assign release_region_o=scan_r;
  verify_decode decoder(.clk(clk),.rst(rst || state==IDLE),.command_valid_i(state==START),.command_ready_o(dr),.busy_o(db),
    .command_kind_i(kind_r),.command_param_i(param_r),.command_id_i(id_r),.command_length_i(length_r),
    .input_valid_i(state==RUN && input_valid_i && !fault_o),.input_ready_o(di),.input_data_i(input_data_i),
    .input_bytes_i(input_bytes_i),.input_index_i(input_index_i),.input_last_i(input_last_i),
    .header_valid_o(dh),.header_ready_i(state==RUN && !fault_o),.header_data_o(header),.header_bytes_o(bytes),.header_id_o(hid),
    .output_valid_o(dv),.output_ready_i(state==RUN && active_r && write_ready_i && !bad && !fault_o),
    .output_data_o(data),.output_section_o(ds),.output_poly_o(dp),.output_index_o(dx),.output_last_poly_o(dl),.output_last_frame_o(df),.output_id_o(did),
    .done_valid_o(dd),.done_ready_i(state==WAIT_DONE || state==ABORT_PARTIAL),.done_code_o(dc),.done_id_o(doneid));
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;kind_r<=0;active_r<=0;param_r<=0;id_r<=0;length_r<=0;base_r<=0;ordinal_r<=0;total_r<=0;l_r<=0;
      scan_r<=0;index_r<=0;code_r<=0;plan_r<=0;committed_r<=0;header_r<=0;bytes_r<=0;fault_o<=0;
    end else case(state)
      IDLE:if(command_valid_i && command_ready_o)begin
        kind_r<=command_kind_i;param_r<=command_param_i;id_r<=command_id_i;length_r<=command_length_i;base_r<=command_base_i;
        ordinal_r<=0;total_r<=command_total[5:0];l_r<=command_param_i==0?6'd4:command_param_i==1?6'd5:6'd7;
        active_r<=0;scan_r<=0;index_r<=0;code_r<=0;committed_r<=0;header_r<=0;bytes_r<=0;
        if(command_param_i==3 || command_length_i!=(command_kind_i?(command_param_i==0?16'd2420:command_param_i==1?16'd3309:16'd4627):
            (command_param_i==0?16'd1312:command_param_i==1?16'd1952:16'd2592)))begin plan_r<=0;code_r<=1;state<=REPORT;end
        else if(command_end>64)begin plan_r<=0;code_r<=5;state<=REPORT;end
        else begin plan_r<=command_plan;state<=CHECK;end
      end
      CHECK:if((reserved_i & plan_r)!=0)begin code_r<=4;plan_r<=0;state<=REPORT;end else state<=START;
      START:if(dr)state<=ALLOC;
      ALLOC:if(alloc_ready_i)begin active_r<=1;state<=RUN;end
      RUN:begin
        if(dh)begin
          if(hid!=id_r)begin fault_o<=1;state<=HALT;end
          else begin header_r<=header;bytes_r<=bytes;end
        end
        if(dv && bad)begin fault_o<=1;state<=HALT;end
        else if(dd)begin
          if(doneid!=id_r)begin fault_o<=1;state<=HALT;end
          else begin code_r<=dc;state<=ABORT_PARTIAL;end
        end
        else if(write_valid_o && write_ready_i)begin index_r<=index_r+1'b1;if(write_last_o)state<=COMMIT;end
      end
      COMMIT:if(finish_ready_i)begin
        active_r<=0;committed_r[alloc_region_o]<=1;
        if(ordinal_r==total_r-1'b1)state<=WAIT_DONE;else begin ordinal_r<=ordinal_r+1'b1;state<=ALLOC;end
      end
      WAIT_DONE:if(dd)begin
        code_r<=dc;
        if(doneid!=id_r || (dc==0 && committed_r!=plan_r))begin fault_o<=1;state<=HALT;end
        else if(dc==0)state<=REPORT;else begin scan_r<=0;state<=CLEAN;end
      end
      ABORT_PARTIAL:if(!active_r || finish_ready_i)begin active_r<=0;scan_r<=0;state<=CLEAN;end
      CLEAN:if(!committed_r[scan_r] || release_ready_i)begin
        committed_r[scan_r]<=0;if(scan_r==63)begin header_r<=0;bytes_r<=0;state<=REPORT;end else scan_r<=scan_r+1'b1;
      end
      REPORT:if(done_ready_i)begin state<=IDLE;plan_r<=0;committed_r<=0;end
      HALT:state<=HALT;
      default:begin fault_o<=1;state<=HALT;end
    endcase
  end
endmodule
`default_nettype wire
