// FIPS204 UseHint on canonical a and a FULL-WIDTH stored hint coefficient.
// Positive low part increments high;zero/negative low decrements it.
`default_nettype none
module use_hint (
  input wire logic [1:0] param_i,input wire logic [22:0] coefficient_i,hint_i,
  output logic [5:0] high_o,output logic error_o
);
  logic [5:0] high;logic signed [18:0] low;
  decompose split(.param_i(param_i),.coefficient_i(coefficient_i),.high_o(high),.low_o(low));
  always_comb begin
    error_o=param_i==3 || coefficient_i>=23'd8380417 || hint_i>1;
    high_o=high;
    if(hint_i==1)begin
      if(param_i==0)high_o=low>0?(high==43?6'd0:high+6'd1):(high==0?6'd43:high-6'd1);
      else high_o=low>0?6'((high+6'd1)&6'd15):6'((high-6'd1)&6'd15);
    end
    if(error_o)high_o=0;
  end
endmodule
`default_nettype wire
