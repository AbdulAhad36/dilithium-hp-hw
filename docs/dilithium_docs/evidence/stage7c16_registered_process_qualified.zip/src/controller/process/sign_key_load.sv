// Expanded-key ingestion client for the EXISTING memory allocator/packer.
// The caller grants exclusive memory-client ownership through done retirement.
// Consecutive regions hold s1[l],s2[k],t0[k];no encoded-key/poly RAM is added.
// COMPLETE in the primitive is tentative:hide the entire plan until success.
`default_nettype none
module sign_key_load (
  input wire logic clk,rst,command_valid_i,
  output logic command_ready_o,busy_o,fault_o,
  input wire logic [1:0] command_param_i,input wire logic [15:0] command_id_i,
  input wire logic [5:0] command_base_i,
  input wire logic input_valid_i,output logic input_ready_o,
  input wire logic [63:0] input_data_i,input wire logic [3:0] input_bytes_i,
  input wire logic [9:0] input_index_i,input wire logic input_last_i,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic [2:0] done_code_o,output logic [15:0] done_id_o,
  output logic [63:0] done_regions_o,
  output logic [255:0] header_rho_o,header_key_o,output logic [511:0] header_tr_o,
  input wire logic [63:0] reserved_i,
  output logic [63:0] release_locks_o,hidden_o,
  output logic alloc_valid_o,output logic [5:0] alloc_region_o,
  output logic [15:0] alloc_id_o,output logic [1:0] alloc_mode_o,alloc_param_o,
  input wire logic alloc_ready_i,
  output logic write_valid_o,write_last_o,output logic [15:0] write_id_o,
  output logic [7:0] write_index_o,output logic [22:0] write_data_o,
  input wire logic write_ready_i,
  output logic finish_valid_o,output logic [15:0] finish_id_o,
  output logic [2:0] finish_code_o,input wire logic finish_ready_i,
  output logic release_valid_o,output logic [5:0] release_region_o,
  input wire logic release_ready_i
);
  typedef enum logic [3:0] {IDLE,CHECK,START,ALLOC,RUN,COMMIT,WAIT_DONE,
    ABORT_PARTIAL,CLEAN,REPORT,HALT} state_e;
  state_e state;
  logic [1:0] param_r;logic [15:0] id_r;logic [5:0] base_r,ordinal_r,total_r,l_r,k_r,scan_r;
  logic [7:0] index_r;logic [2:0] code_r;logic active_r;
  logic [63:0] plan_r,committed_r,command_plan;
  logic [6:0] command_total,command_end;
  logic dec_ready,dec_busy,dec_header,dec_valid,dec_last,dec_key_last,dec_done,dec_input_ready;
  logic [1:0] dec_section;logic [2:0] dec_poly,dec_code;
  logic [7:0] dec_index;logic [15:0] dec_id,dec_header_id,dec_done_id;
  logic [22:0] dec_data;logic [255:0] dec_rho,dec_key;logic [511:0] dec_tr;
  logic [1:0] expected_section;logic [5:0] expected_poly;logic output_bad;
  always_comb begin
    command_total=command_param_i==0?7'd12:(command_param_i==1?7'd17:7'd23);
    command_end={1'b0,command_base_i}+command_total;
    command_plan=0;
    for(int i=0;i<64;i++)if(i>=int'(command_base_i) && i<int'(command_end))command_plan[i]=1;
  end
  assign command_ready_o=!rst && state==IDLE && !fault_o;
  assign busy_o=state!=IDLE;
  assign done_valid_o=!rst && state==REPORT && !fault_o;
  assign done_code_o=code_r;assign done_id_o=id_r;
  assign done_regions_o=done_valid_o && code_r==0?plan_r:64'd0;
  // Private header is never published for an erroneous or partial key.
  assign header_rho_o=done_valid_o && code_r==0?dec_rho:256'd0;
  assign header_key_o=done_valid_o && code_r==0?dec_key:256'd0;
  assign header_tr_o=done_valid_o && code_r==0?dec_tr:512'd0;
  assign release_locks_o=busy_o?plan_r:64'd0;
  assign hidden_o=busy_o && !(state==REPORT && code_r==0)?plan_r:64'd0;
  assign alloc_valid_o=!rst && state==ALLOC && !fault_o;
  assign alloc_region_o=base_r+ordinal_r;
  assign alloc_id_o=id_r;assign alloc_param_o=param_r;
  assign alloc_mode_o=ordinal_r<l_r+k_r?2'd1:2'd3; // secret / decoded t0
  assign expected_section=ordinal_r<l_r?2'd0:(ordinal_r<l_r+k_r?2'd1:2'd2);
  assign expected_poly=ordinal_r<l_r?ordinal_r:(ordinal_r<l_r+k_r?ordinal_r-l_r:ordinal_r-l_r-k_r);
  assign output_bad=dec_section!=expected_section || {3'd0,dec_poly}!=expected_poly ||
    dec_index!=index_r || dec_id!=id_r || dec_last!=(index_r==255) ||
    dec_key_last!=(index_r==255 && ordinal_r==total_r-1'b1);
  assign write_valid_o=!rst && state==RUN && active_r && dec_valid && !output_bad && !fault_o;
  assign write_data_o=dec_data;assign write_index_o=dec_index;assign write_last_o=dec_last;assign write_id_o=id_r;
  assign finish_valid_o=!rst && !fault_o && (state==COMMIT || (state==ABORT_PARTIAL && active_r));
  assign finish_id_o=id_r;assign finish_code_o=state==COMMIT?3'd0:3'd1;
  assign release_valid_o=!rst && state==CLEAN && committed_r[scan_r] && !fault_o;
  assign release_region_o=scan_r;
  assign input_ready_o=!rst && state==RUN && dec_input_ready && !fault_o;
  sign_key_decode decoder(
    .clk(clk),.rst(rst || state==IDLE),.command_valid_i(state==START),.command_ready_o(dec_ready),.busy_o(dec_busy),
    .command_param_i(param_r),.command_id_i(id_r),
    .input_valid_i(input_valid_i && state==RUN && !fault_o),.input_ready_o(dec_input_ready),
    .input_data_i(input_data_i),.input_bytes_i(input_bytes_i),.input_index_i(input_index_i),.input_last_i(input_last_i),
    .header_valid_o(dec_header),.header_ready_i(state==RUN),.header_rho_o(dec_rho),.header_key_o(dec_key),
    .header_tr_o(dec_tr),.header_id_o(dec_header_id),
    .output_valid_o(dec_valid),.output_ready_i(state==RUN && active_r && write_ready_i && !output_bad && !fault_o),
    .output_data_o(dec_data),.output_section_o(dec_section),.output_poly_o(dec_poly),.output_index_o(dec_index),
    .output_last_poly_o(dec_last),.output_last_key_o(dec_key_last),.output_id_o(dec_id),
    .done_valid_o(dec_done),.done_ready_i(state==WAIT_DONE || state==ABORT_PARTIAL),.done_code_o(dec_code),.done_id_o(dec_done_id)
  );
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;id_r<=0;base_r<=0;ordinal_r<=0;total_r<=0;l_r<=0;k_r<=0;scan_r<=0;
      index_r<=0;code_r<=0;active_r<=0;plan_r<=0;committed_r<=0;fault_o<=0;
    end else case(state)
      IDLE:if(command_valid_i && command_ready_o)begin
        param_r<=command_param_i;id_r<=command_id_i;base_r<=command_base_i;
        ordinal_r<=0;index_r<=0;code_r<=0;active_r<=0;committed_r<=0;scan_r<=0;
        total_r<=command_total[5:0];l_r<=command_param_i==0?6'd4:(command_param_i==1?6'd5:6'd7);
        k_r<=command_param_i==0?6'd4:(command_param_i==1?6'd6:6'd8);
        if(command_param_i==3 || command_end>64)begin
          plan_r<=0;code_r<=command_param_i==3?3'd1:3'd5;state<=REPORT;
        end else begin plan_r<=command_plan;state<=CHECK;end
      end
      CHECK:if((reserved_i & plan_r)!=0)begin code_r<=4;plan_r<=0;state<=REPORT;end else state<=START;
      START:if(dec_ready)state<=ALLOC;
      ALLOC:if(alloc_ready_i)begin active_r<=1;state<=RUN;end
      RUN:begin
        if(dec_valid && output_bad)begin fault_o<=1;state<=HALT;end
        else if(dec_done)begin code_r<=dec_code;state<=ABORT_PARTIAL;end
        else if(write_valid_o && write_ready_i)begin
          index_r<=index_r+1'b1;if(write_last_o)state<=COMMIT;
        end
      end
      COMMIT:if(finish_ready_i)begin
        active_r<=0;committed_r[alloc_region_o]<=1;
        if(ordinal_r==total_r-1'b1)state<=WAIT_DONE;
        else begin ordinal_r<=ordinal_r+1'b1;state<=ALLOC;end
      end
      WAIT_DONE:if(dec_done)begin
        code_r<=dec_code;
        if(dec_done_id!=id_r)begin fault_o<=1;state<=HALT;end
        else if(dec_code==0)state<=REPORT;
        else begin scan_r<=0;state<=CLEAN;end
      end
      ABORT_PARTIAL:if(!active_r || finish_ready_i)begin active_r<=0;scan_r<=0;state<=CLEAN;end
      CLEAN:if(!committed_r[scan_r] || release_ready_i)begin
        committed_r[scan_r]<=0;
        if(scan_r==63)state<=REPORT;else scan_r<=scan_r+1'b1;
      end
      REPORT:if(done_ready_i)begin state<=IDLE;plan_r<=0;committed_r<=0;end
      HALT:state<=HALT;
      default:begin fault_o<=1;state<=HALT;end
    endcase
  end
endmodule
`default_nettype wire
