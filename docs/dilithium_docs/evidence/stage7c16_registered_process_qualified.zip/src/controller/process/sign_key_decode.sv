// Expanded FIPS204 secret-key stream:rho32 || K32 || tr64 || s1 || s2 || t0.
// First byte in data[7:0]. All input words have8 valid bytes. A76-bit bit
// reservoir replaces a full encoded-key RAM. Outputs are tentative until
// done_code==0;the future memory owner must discard the entire key on error.
// Strictly rejects unused eta encodings;does not check key algebraic consistency.
`default_nettype none
module sign_key_decode (
  input wire logic clk,rst,command_valid_i,output logic command_ready_o,busy_o,
  input wire logic [1:0] command_param_i,input wire logic [15:0] command_id_i,
  input wire logic input_valid_i,output logic input_ready_o,
  input wire logic [63:0] input_data_i,input wire logic [3:0] input_bytes_i,
  input wire logic [9:0] input_index_i,input wire logic input_last_i,
  output logic header_valid_o,input wire logic header_ready_i,
  output logic [255:0] header_rho_o,header_key_o,output logic [511:0] header_tr_o,
  output logic [15:0] header_id_o,
  output logic output_valid_o,input wire logic output_ready_i,
  output logic [22:0] output_data_o,output logic [1:0] output_section_o,
  output logic [2:0] output_poly_o,output logic [7:0] output_index_o,
  output logic output_last_poly_o,output_last_key_o,output logic [15:0] output_id_o,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic [2:0] done_code_o,output logic [15:0] done_id_o
);
  typedef enum logic [2:0] {IDLE,HEADER,HEADER_OUT,PAYLOAD,REPORT} state_e;
  state_e state;
  logic [1:0] param_r,section_r;
  logic [3:0] k_r,l_r;logic [2:0] poly_r;
  logic [7:0] index_r;logic [9:0] word_r,total_words_r;
  logic [75:0] bits_r;logic [6:0] count_r;
  logic [4:0] width;logic [12:0] encoded,center;
  logic ended_r,bad_frame,bad_value,push,pop;
  assign width=section_r==2?5'd13:(param_r==1?5'd4:5'd3);
  assign center=section_r==2?13'd4096:(param_r==1?13'd4:13'd2);
  assign encoded=bits_r[12:0] & ((13'd1<<width)-1'b1);
  assign bad_value=section_r!=2 && encoded>(center<<1);
  assign bad_frame=input_bytes_i!=8 || input_index_i!=word_r ||
    input_last_i!=(word_r==total_words_r-1'b1);
  assign command_ready_o=!rst && state==IDLE;
  assign busy_o=state!=IDLE;
  assign input_ready_o=!rst && (state==HEADER || (state==PAYLOAD && count_r<7'(width) && !ended_r));
  assign header_valid_o=!rst && state==HEADER_OUT;
  assign header_id_o=done_id_o;assign output_id_o=done_id_o;
  assign output_valid_o=!rst && state==PAYLOAD && count_r>=7'(width) && !bad_value;
  assign output_section_o=section_r;assign output_poly_o=poly_r;assign output_index_o=index_r;
  assign output_last_poly_o=index_r==255;
  assign output_last_key_o=section_r==2 && {1'b0,poly_r}==k_r-1'b1 && index_r==255;
  assign output_data_o=encoded<=center?23'(center-encoded):23'd8380417-23'(encoded-center);
  assign done_valid_o=!rst && state==REPORT;
  assign push=input_valid_i && input_ready_o;assign pop=output_valid_o && output_ready_i;
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;section_r<=0;k_r<=0;l_r<=0;poly_r<=0;index_r<=0;
      word_r<=0;total_words_r<=0;bits_r<=0;count_r<=0;ended_r<=0;
      header_rho_o<=0;header_key_o<=0;header_tr_o<=0;done_code_o<=0;done_id_o<=0;
    end else case(state)
      IDLE:if(command_valid_i)begin
        param_r<=command_param_i;done_id_o<=command_id_i;done_code_o<=0;
        section_r<=0;poly_r<=0;index_r<=0;word_r<=0;bits_r<=0;count_r<=0;ended_r<=0;
        header_rho_o<=0;header_key_o<=0;header_tr_o<=0;
        k_r<=command_param_i==0?4'd4:(command_param_i==1?4'd6:4'd8);
        l_r<=command_param_i==0?4'd4:(command_param_i==1?4'd5:4'd7);
        total_words_r<=command_param_i==0?10'd320:(command_param_i==1?10'd504:10'd612);
        if(command_param_i==3)begin done_code_o<=1;state<=REPORT;end
        else state<=HEADER;
      end
      HEADER:if(push)begin
        if(bad_frame)begin done_code_o<=3;state<=REPORT;end
        else begin
          if(word_r<4)header_rho_o[64*word_r+:64]<=input_data_i;
          else if(word_r<8)header_key_o[64*(word_r-4)+:64]<=input_data_i;
          else header_tr_o[64*(word_r-8)+:64]<=input_data_i;
          word_r<=word_r+1'b1;
          if(word_r==15)state<=HEADER_OUT;
        end
      end
      HEADER_OUT:if(header_ready_i)state<=PAYLOAD;
      PAYLOAD:begin
        if(push)begin
          if(bad_frame)begin done_code_o<=3;bits_r<=0;count_r<=0;state<=REPORT;end
          else begin
            bits_r<=bits_r | (76'(input_data_i)<<count_r);count_r<=count_r+7'd64;
            word_r<=word_r+1'b1;ended_r<=input_last_i;
          end
        end
        if(count_r>=7'(width) && bad_value)begin done_code_o<=2;bits_r<=0;count_r<=0;state<=REPORT;end
        else if(pop)begin
          bits_r<=bits_r>>width;count_r<=count_r-7'(width);index_r<=index_r+1'b1;
          if(output_last_key_o)begin
            if(!ended_r || count_r!=7'(width) || word_r!=total_words_r)done_code_o<=3;
            state<=REPORT;
          end else if(index_r==255)begin
            if({1'b0,poly_r}==(section_r==0?l_r:k_r)-1'b1)begin poly_r<=0;section_r<=section_r+1'b1;end
            else poly_r<=poly_r+1'b1;
          end
        end
      end
      REPORT:if(done_ready_i)state<=IDLE;
      default:begin done_code_o<=3;state<=REPORT;end
    endcase
  end
endmodule
`default_nettype wire
