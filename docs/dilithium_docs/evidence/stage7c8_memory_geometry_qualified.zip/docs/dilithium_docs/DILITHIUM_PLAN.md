# Dilithium design and integration plan

## Active Stage7C: reconstruct the full published LightHD architecture

**Stage7C.8 source/routed checkpoint complete:** simplify the bank-port command range checks
without adding registers,states or command clocks. Sequential bursts compare
`base+words` with1024;stride-two bursts compare `words+floor(base/2)` with512.
Pre-NTT reads and compact-secret reads use their original fixed spans;tagged
writes preserve their original bypass. Zero/oversize counts,mask checks and
the special32/64-word requirements remain. The actual new RTL matches the
frozen C7 acceptance expression in16842752 exhaustive/multi-bank cases.
Direct-memory,160 real-bank NTT operations and mixed official diagnostic9
pass fresh independent checks. Full210/protocol88/checker90 and main33 UVM/
negative pass. All native records after source headers and all30 UVM latency
rows are exact C7. Same-device full compile/ASM/STA and retained/four-corner
analysis pass:34333 placed ALMs,25358 registers,59M10Ks,8DSP. Worst Fmax55.53MHz
(+7.24%),setup-11.251ns,hold+0.121ns. The148MHz target still fails setup.
Freeze `evidence/stage7c8_memory_geometry_qualified.zip` before the next edit.

**Next7C.9:** separate command capture from validation in the bank-port FSM.
Reuse the already captured per-bank base/count/mode/write registers;add one
admission state instead of a copied payload/descriptor queue. Preserve all
cross-bank checks and atomic same-owner read-to-write renewal. Each memory
command gains one validation clock;measure whole-operation cost versus any
Fmax gain. Requalify memory/NTT,full native/protocol/main UVM and physical
gates before accepting the change. Keep engine mathematics and public ports.

**Current execution:7C.7 source/routed checkpoint complete;148MHz setup open.**
The shared decode handoff now has two validated packet slots,and BitUnpkg
uses cached refill thresholds. Source qualification passes9216 equivalence
combinations,BitUnpkg89/shared-decoder71,Sign-input135,Verify-input105,
mixed diagnostic9,full production210/protocol88/checker90 and main UVM33/
negative. All published output/status/attempt records remain exact7C.6.
Operation cycles are remeasured;Sign means rise0.011..0.029%,Verify means
0.065..0.089% in the full-vector suite. UVM early-invalid Verify peaks0.67511%.

Full compile/retained-hardware/four-corner analysis pass,no combinational
loops. Actual placed ALMs34302 (+478 versus C6),registers25337,M10Ks59,DSP8.
Worst reported Fmax51.78MHz/setup-12.556ns/hold+0.103ns;the148MHz target still
fails. Functional116/170;overall enabled code114789/159142=72.13%.
Freeze `evidence/stage7c7_decode_handoff_qualified.zip` before further edits.
This does not mark performance accepted or advance to Stage8.

**Next7C.8:** target the measured memory-command arbitration/validation path
(owner register through NTT renewal/command selection and geometry checks
into scheduler error/state). First simplify the default span check from
`base + (words-1) +1` to `base + words`,retaining zero/oversize word rejection,
Pre-NTT/secret special spans and all write-mode rules. Prove equivalence,
then repeat direct-memory/NTT and complete source/physical gates. This first
candidate should preserve command latency. If further registered admission is
needed,retain atomic ownership renewal and measure its cycle/area cost.
Do not remove useful guards,relax clocks/hold rules,or claim paper benchmarks.

### Frozen7C.6 checkpoint

Stage7C.6 memory-response and hint-path optimization.
The7C.5 production baseline is frozen in
`evidence/stage7c5_production_loop_baseline.zip`,SHA256
`aae6e30d500b2832f53c307e0dbf78bcc1734ae19ed25e2479fb05eecd2779b6`
(201 members,12031034 bytes;56 prior archive pairs verified).

Production memory now has two response slots per port with registered
occupancy,and HintUnpkg reads four candidate suffix indices in parallel.
The public streams,canonical validation,engine arithmetic and constraints
remain unchanged. Fresh foundation gates pass:23397 RAM requests,28 direct
memory commands,160 real-bank NTT operations/40960 coefficients,106 hint
cases/21510 exact masks and18 checker faults. Full production210/protocol88/checker90 and main UVM33/negative pass. All
capture/cycle records and30 UVM latency rows are exact7C.5. Same-device full
compile/retained-hardware/four-corner reports pass without combinational loops.
Actual placed ALMs33824,registers25092,M10Ks59,DSP8. Worst Fmax39.37MHz,
setup-18.645ns,hold+0.127ns:the148MHz target remains open. Functional116/170;
code114324/158664. Freeze7C.6 evidence before further source edits.

**Next7C.7:** shorten the measured shared-decoder/service/Verify-control path
(`width_r` to Verify-input `state.NORM_RUN`,25.212ns data delay). Qualify any
registered service/handshake boundary with backpressure and reset recovery;
retain canonical validation,identity checks and all public frames. Measure
cycle impact and actual placed area,then repeat full output/UVM/physical gates.
Review public-scheduler reachability in the broad fabric coverage bins before
claiming final coverage closure. Do not advance to Stage8 or relax constraints.

### Frozen7C.5 production handoff
Stage7C.4 is frozen in `evidence/stage7c4_main_qualified.zip` (179 members,
12274889 bytes),SHA256 `6c74b0b61fc5069558b425022f221f1a916396b0663fabe6723ea0e169c72702`.
Its source-qualified mixed main passes210 official commands:75 KeyGen,
90 Sign,45 Verify;744280 exact key/signature bytes,9 valid/36 invalid
verdicts and35 independent Verify equation digests. Protocol88 passes29
errors,3 normal invalids,12 resets,44 same-ID cross-operation recoveries and
44 blocked busy probes;148704 emitted prefix/full bytes are checked.
The checkers reject90/90 deliberate corruptions. Archive manifest hashes pass.

Production `dilithium_fpga` now selects `lighthd_dilithium`,with the same51
signal groups/1027 bits. QSF lists only the55 new production dependencies.
Every non-source QSF line and the SDC are exact7B.9:the same Cyclone V,
6.757ns clock,hold rules,seed and physical options. Main completion now
requires matching child ID before publishing success. Main UVM observes
actual8 physical bank-port owners and datapath idle;the obsolete allocator
and legacy-debug probes are not connected or credited. The former pool
occupancy coverage is replaced by actual port occupancy0..8,not relabeled
64-slot data. All results require fresh production/UVM qualification.

The Quartus elaborator compatibility rewrite is now qualified by fresh210/88
and main UVM33 gates. The full compile and retained-hardware/four-corner
analysis complete. Actual placed ALMs fall51162 to34170;registers24376,
M10Ks59,DSP8. Reported worst Fmax31.89MHz/setup-24.598ns/hold+0.099ns;
setup fails and a145-node post-fit combinational backpressure loop remains.
These are diagnostic timing figures,not accepted operating performance.

Freeze this source/evidence baseline before Stage7C.6. Then replace the
memory ready-feedback path with registered two-slot response occupancy and
remove the measured four-dependent-byte HintUnpkg chain. Preserve one
request/port/clock unstalled throughput,all canonical-format validation,
reset/identity/ownership guards and public streams. Requalify direct RAM/NTT,
Hint106/checker18,full production210/protocol88/checker90 and main UVM/negative;
repeat same-FPGA implementation. Actual phase/cycle changes must be reported.
The engine arithmetic and external clock/hold constraints remain unchanged.

The following7C.2/7C.3 records are preserved functional milestones:

Current execution:7C.2 compact KeyGen qualifies with paired A production and
early A/s2 sampling during the remaining secret transforms. All75 official
keypairs match433600 published bytes;protocol20 and checker25 also pass under
token`1648e985aacec89c00b32feabbf3e70cae6362b758bc6501c0c2580d7b67c742`.
Active operation:7C.3 compact Sign. Its direct FSM now connects the shared
key decoder, cached secret transforms, matrix/Y producer, row-local Process,
one rejection loop and streamed signature packing through the actual shared
datapath. The refreshed90-case gate matches all310680 published signature
bytes, every attempt hash and justified rejection. Protocol69 passes24 errors,
12 targeted resets and33 same-ID recoveries. The comparator rejects62/62
deliberate capture corruptions. The public launcher passes diagnostic Sign,
protocol Sign and protocol KeyGen through the same `run.do`. KeyGen75/protocol20 also re-pass
after the shared decoder changes;its published bytes and overlap counts hold.
The production top still uses
the preserved7B.9 implementation;compact Verify and the final top are
pending. Stage7C.3 evidence is preserved in `evidence/stage7c3_sign_qualified.zip`
and its SHA256 sidecar. Next is7C.4 compact Verify/main, beginning with streamed
PK/signature decoding into fixed banks. No replacement whole-design PPA or
main-UVM coverage is claimed.

The foundation now includes direct bank-port scheduling/router,packed sampler
B-port writes shared by interleaved contexts,the Fig5 secret regrouping,
bank-streamed NTT/fused MAC and one shared x4 Process/BitPkg path. Source and
test paths are listed in ARCHITECTURE.md and PROCESS_BLOCKS.md. Current-source
qualification and the final immutable evidence package follow source freeze;
earlier focused captures are not silently retagged after interface edits.

The user's latest instruction replaces the narrow timing-only task with a full
controller,memory-scheduling and Process rebuild. Keep the accepted Keccak,
sampler and four-BU/three-FIFO NTT arithmetic as the engine foundation;adapt
their bank interfaces where the current scalar wrappers prevent the published
schedule. Do not call the current helper/allocator system a complete replica.
The complete7B.9 source and routed evidence remain immutable in the archive
below. The current production top stays operational until its replacement
passes the full output checks. No commit,branch change or archive deletion.

Primary source:Ni et al.,LightHD,IEEE TC75(5),2007-2019,
DOI10.1109/TC.2026.3666457. Figures1/2/5/6/7 and SectionsIII/IV were read
and visually inspected from the repository PDF. Missing unpublished FSM tables
must be independently reconstructed;compliance means every published
architectural mechanism and schedule is implemented and checked,not identical
author RTL. Final FIPS204 encoding/hashing and the approved public interface
remain required adaptations. Every other architectural difference stays visible.

### Required structure and completion evidence

|Published requirement|Replacement and evidence required|Status at start|
|---|---|---|
|Four1024x92 dual-port banks|Direct bank addresses;one physical coefficient array,not a second pool|Geometry exists;control rebuild required|
|Separate FSMs for BRAM A/B ports|Independent transfers on both ports,including simultaneous different-address sampling/compute|Not reproduced by current exclusive service scheduling|
|Fig2 fixed secret/work roles|BRAM1:y/s2;BRAM2:t0/w0/scratch;BRAM3:s1/yhat/packed w1;BRAM4:A then z/chat/r0|Current allocator differs|
|Fig7 one reused accumulator/scratch|Finish each row/component before reuse;no retained full matrix/product-vector workspace|Current hierarchy uses extra staging/contexts|
|Cached secret transforms|Pre-NTT s1/s2 and FNTT t0 once per loaded key;retain through rejection retries|Functional reuse exists;move to fixed roles|
|Fused PWM accumulation|Read operands and prior accumulator,add to PWM result in its streaming writeback|Current separate product/ADD commands differ|
|Bank-width NTT ingress/egress|Expose the accepted core through packed transfers,qualify32-cycle forward loading|Current scalar adapter does not comply|
|Pre regroup/LUT second-stage start|Preserve lookup domain and word ordering;qualify direct-bank loading|Core feature exists;adapter integration required|
|Decompose x4/CNBs/MHint/P2R shared Process|Bank-word arithmetic and bounded arithmetic widths;no unrelated private copies|Blocks exist;datapath/scheduling rebuild required|
|Unified selectable BitPkg|Process packed words directly;all FIPS key,w1,z formats and backpressure checked|Current one-coefficient transport differs|
|Fig7 row-local INTT then process|w1 packing and w0 storage finish before next scratch reuse|Reconstruct exact lifetimes|
|Early NTT while sampling continues|Launch at available polynomial boundaries,not after every secret finishes|Current exclusive service schedule differs|
|A sampling ring and pauses|Levels2/3 nine-polynomial ring;bounded producer/consumer counts;pause/resume at published row boundaries|Not reproduced|
|Interleave A/s2 sampling in KeyGen|Avoid overwriting the bounded A buffer;trace both cores and bank ports|Not reproduced|
|One signing rejection loop|No duplicate arithmetic engine or second rejection pipeline|Preserve|
|Full KeyGen/Sign/Verify outputs|Fresh75/90/45 official commands plus negative/reset/framing checks|7B.9 historical;replacement pending|
|Area/frequency/cycle claims|Fresh actual placed ALMs,registers,DSP/RAM and four-corner timing;per-phase cycle ledger|Replacement unmeasured|

### Fixed Sign geometry from Figure2

Addresses below are92-bit words;bank numbers match the paper,not zero-based RTL.
One full polynomial occupies64 words. Narrow w1 storage is phase-specific.

|Bank|Word addresses|Live Sign role|
|---|---|---|
|BRAM1|0..447|Up to7 raw y polynomials|
|BRAM1|448..959|Up to8 cached s2 transforms|
|BRAM1|960..1023|Unused in the peak Sign figure;available only by an audited lifetime|
|BRAM2|0..63|Reused row accumulator;last w0 at level5 after final row|
|BRAM2|64..575|Up to8 cached t0 transforms|
|BRAM2|576..1023|First7 w0 polynomials|
|BRAM3|0..447|Up to7 cached s1 transforms|
|BRAM3|448..895|Up to7 yhat polynomials|
|BRAM3|896..1023|Packed w1 stream,not8 full-width coefficient polynomials|
|BRAM4|Phase-dependent ring|Sampled A during matrix multiplication|
|BRAM4|0..447 after A phase|Up to7 z polynomials|
|BRAM4|448..511 after A phase|Challenge transform chat|
|BRAM4|512..1023 after A phase|Up to8 r0=w0-cs2 polynomials|

The z and r0 roles are not simultaneously compatible with a live A ring;
phase transition must drain reads/writes before reassignment. Source-key fields
remain protected across retries. Public input validation/reset recovery stays;
general-purpose per-helper lease adoption and copied metadata are not required.

### Execution stages

1. **7C.0 paper audit and fixed address contract:**freeze baseline,record every
   structural/schedule requirement,explicit errata and unavoidable FIPS/I/O
   adaptations. Table entries only become complete with implementation evidence.
2. **7C.1 bank/Process foundation:**direct A/B port scheduling,fixed maps,
   packed x4 arithmetic/packing and bank-width NTT adapter. Test collisions,
   stalls,reset,all parameter sets and independent arithmetic equivalence.
3. **7C.2 compact KeyGen:**replace helper/allocator transactions with phase
   counters and fixed banks;exercise early secret transforms/A-s2 sampling and
   row-local accumulator reuse. Compare75 official complete keypairs.
4. **7C.3 compact Sign:**one retained key context,fixed secrets/workspaces,
   rejection retry counters,row-local w1/w0,z/r0/ct0/hint processing and shared
   packing. Compare90 official signatures and all retry/reset/invalid-frame gates.
5. **7C.4 compact Verify/main:**reuse physical Process/banks,integrate approved
   public streams;compare45 official verdicts and malformed/frame/reset tests.
6. **7C.5 qualify and measure the complete replacement:**main UVM/current-token
   checker faults,all210 official commands,fresh same-device compile/retention/
   four-corner reports. Remove unused old production hierarchy only after the
   replacement passes. Compare measured area,counters and latency to7B.9 and
   LightHD;continue optimization from actual bottlenecks.

Announce each transition and report what passes/what remains. Do not silently
advance a failed stage or claim replication from successful arithmetic alone.
Bring any major decision that contradicts the paper or approved public
contracts to the user;routine details within this reconstruction are authorized.

### Benchmarks and interpretation

The paper's TableIII reports20623 LUTs,13854 FFs,8 DSPs,12 BRAMs and212.8MHz
on Artix-7 XC7A200T. Level2/3/5 KeyGen cycles are4.2k/6.4k/10.6k;best Sign
12.2k/17.8k/25.6k;average Sign41.4k/68.6k/82.9k;Verify5.5k/8.2k/12.4k.
These rounded totals are references,not simulator acceptance constants.
The target is substantial area/cycle reduction and eventually better measured
performance. Count actual final-placement Cyclone V ALMs,not packing estimates.
Do not equate an ALM to one LUT or an M10K to one Artix BRAM. The four logical
banks contain376832 payload bits;physical RAM counts differ by FPGA primitive.
TableII's listed block rows sum14983 LUTs/9292 FFs,below its stated total;
the residual5640 LUTs/4562 FFs is unattributed,not an explicit controller figure.

Fig7's z caption/body mixes s1/s2 and k/l. Use the verified FIPS equations:
w=A*y hasK rows/L terms,z=y+c*s1 hasL polynomials,r0=w0-c*s2 andh haveK.
Do not reproduce mathematical typos or revert the approved64-byte tr format.

## Stage7B.9 complete: production boundary and routed baseline

The user approved a normal KeyGen/Sign/Verify command/data/status top with
debug retained for verification. Stop7B.8's obsolete-interface fitter trial;
archive it as ABORTED,not a routing result. Added dilithium_fpga.sv wraps the
unchanged74 RTL with all three operations hard-enabled. Main UVM and the
main QPF now use the production wrapper. It has51 signal groups/1027 bits,
with1324 seed/debug/occupancy bits kept internal. No ALM saving is inferred
from those port counts.

Refresh fixtures and requalify the actual production top:main33/current-token
negative,independent references,then full same-FPGA compile and retained-bit/
four-corner reports. Preserve6.757ns and the existing hold constraints. Only
after actual routing may placed area or timing be reported. Legacy raw-core
and standalone verification remain available. This stays within Stage7;
no Stage8/netlist/FPGA/signoff/commit is implied.

Current source gate is complete:main33 passes30 checked completions/3 resets
with zero UVM errors/fatals;the same-token corrupted-key check rejects byte0
with zero checked outcomes/0of170 bins. All30 timestamps and every latency CSV
field equal7B.7. Functional121/170;overall code316722/397459=79.69%. Independent
references and freshness pass. The full same-FPGA compile successfully routes
and assembles at51162 actual placed ALMs,62 M10Ks and27 DSPs. Retention checks
pass. Worst Fmax23.97MHz,setup−34.965ns and hold+0.099ns:the6.757ns target is
NOT met. This closes the production-boundary baseline,not Stage7 timing or
broader coverage work. THROUGHPUT.md records every corner and metric scope.
Create-only evidence:[production baseline](evidence/stage7b9_production_top_baseline.zip)
and its SHA256 sidecar contain current sources,fixtures,captures,coverage,
physical reports and manifest. Earlier48 archive pairs remain unchanged.

## Next Stage7C: measured Verify timing path

The critical path crosses lane selection,Decompose/UseHint,service routing and
Bitpkg into the packer's reservoir. Preserve the routed7B.9 evidence before
new source changes. Review the lane-select index multiply and arithmetic widths
first;prove full canonical-domain behavior against the independent reference.
Then evaluate pipeline boundaries if needed,measuring operation-cycle and
throughput effects explicitly. A significant interface/scheduling tradeoff must
be presented to the user before implementation. Keep all three operations,
validation/ownership guards,the same FPGA,6.757ns clock and hold constraints.
Requalify each retained source candidate and rerun physical measurement.
No Stage8/netlist/board work or commit is implied by this baseline.

## Stage7B.8: interrupted on approved interface switch

7B.7 source qualification passes,but placement-only50059 ALMs/5341 LABs still
fails routing. Its immutable archive is
evidence/stage7b7_aligned_decoder_route_failure.zip +SHA256. Trial7B.8 reuses
exactly that mapped design with the native
FITTER_AGGRESSIVE_ROUTABILITY_OPTIMIZATION=ALWAYS override. No RTL,clock or
hold constraint changes during the trial. If successful,run ASM/STA and the
retained-storage/four-corner reports,persist the matching physical recipe and
keep its fingerprint separate from the already qualified source captures.

The user subsequently approved the production top-level interface.
The existing2351 bits including clock contain1324 seed/debug/occupancy bits;
the proposed normal command/data/status interface has1027 bits. All three
crypto operations and standalone verification assets would remain. This is
a port-count change,not an ALM savings claim;implementation is in7B.9 above.

## Next Stage7B.7: aligned decoder writes

7B.6 preserves every measured operation cycle and passes all source gates,
but routing still fails at51760 placed-only ALMs/5531 LABs. Freeze its evidence.
The Verify decoder is now among the largest local blocks. Replace eight
variable-position hint-byte writes with one aligned64-bit word write per
accepted input word. Keep valid-byte masking,all malformed-frame checks,
external timing and outputs. Narrow header write addressing only where the
HEADER state guarantees its range. Compare against the archived decoder
cycle by cycle in the existing focused suite,then independent C/Python,
main33 UVM/current-token negative and fresh same-FPGA fit. No new fitter
option or relaxed timing constraint is retained.

## Stage7B.6: reduce memory descriptor cost

7B.4 passes placement but fails routing. The7B.5 aggressive-routability trial
also fails;no new fitter option is retained. Keep the same Cyclone V and
6.757ns target. Replace64 register-based mutable descriptor records with two
active writer records and64 x22-bit completed-tag RAM. Preserve all64 regions,
four coefficient banks,guards,public ports and qualified read timing.

The isolated old/new pin comparison passes4418 reads and16647 writes across
all64 slots. Next gates:full33 main UVM with an external old-memory comparator,
independent C/Python checks,focused helper/fault regression and fresh complete
Quartus compile. Confirm actual RAM inference and routing before reporting
placed area or timing. MEMORY_MAP.md documents storage and the read paths.

## Active Stage7B.4: remove parallel descriptor-validation hardware

The7B.2 counting rewrite passes all33 main UVM and59 helper cases,but remains
68 LABs over capacity. Explicit minimum-area packing7B.3 gives the identical
failure and is archived;no packing-option change is retained.
Serialize validation in only the two largest Sign helpers:32 cycles before
attempt-check adoption and24 before products adoption. Keep all useful guards,
snapshot inputs,ownership barriers and engine sequencing. This adds56 cycles
per signing attempt;measure the real latency/Fmax/area tradeoff. It does not
change polynomial arithmetic or outputs. All other72 RTL and the6.757ns QSF/SDC
stay exact. New validation-specific tests pass256 scenarios,including18 resets
and one-cycle source changes. Full main UVM/helper regression and fresh fit
must pass before this is treated as the fitting design.

## Active Stage7B: fit the SAME Cyclone V

First guard candidate7B.1 passes all33 main-UVM scenarios and59 helper/fault
cases. All30 checked completion times exactly match Stage7A. Current-token
negative gives0/170 credit;118 helper-checker corruptions reject.
It reduces the failed allocation by6409 ALMs to57873, but fitting still fails
(6044 LAB required/5648 available). No placed PPA or timing is accepted.
Freeze this attempt and continue within Stage7B. The next candidate replaces
pairwise duplicate detection with compact balanced population counting and
uses area-oriented fitting. Keep all operations, guards,clock constraint and
device. Measure timing honestly after a successful fit; no frequency claim
is inferred from area savings.

## Active: Stage7A UVM foundation and whole-main implementation baseline

The first 33-scenario campaign passes: 30 checked completions, three reset
aborts, zero UVM errors/fatals; 121/170 functional and 314371/393251 raw DUT
code bins. Whole-main synthesis succeeds, but the first fit fails: 6674 LABs
required versus 5648 available. Its partial allocation of 64282 ALMs exceeds
the 56480-device capacity; it is not an accepted placed-area result. Timing
is unavailable because fitting failed. Keep the 6.757ns constraint.

**User decision: fit this same Cyclone V.** Stage7B will remove excessive
control-helper implementation cost, initially replacing serial combinational
bitmap updates with equivalent mask/uniqueness logic. Preserve duplicate,
overlap, ownership and output checks. Recheck outputs and synthesize/fit each
bounded candidate; do not strip working algorithm features or change FPGA.
Freeze the Stage7A evidence before changing RTL. Latency CSVs from the first
run were overwritten by an accidental stopped rerun; no latency claim uses them.

Create the real UVM environment under tb_uvm/tb_uvm_dilithium with independently
monitored traffic, separate published expectations and scoreboard-qualified
coverage. First campaign: 33 scenarios / 30 expected completions / 3 resets.
Collect raw functional and code coverage, latency/event CSVs and a specific
checker-negative gate. Report honest initial gaps; broader Stage7 coverage
and optimization remain subsequent bounded work. COVERAGE.md and the expanded
INTEGRATION_VERIFICATION_TESTPLAN.md define the checks and remaining features.

Preserve the old subsystem Quartus project. Use the new whole-main project
quartus/dilithium/dilithium_full.qpf with FULL_KEYGEN=1 and Sign/Verify enabled,
same device and 6.757ns SDC. The first compile exposed Quartus front-end limits:
explicit generate/genvar declarations and package-typed ports without an
explicit wire keyword are required. These mechanical compatibility edits
change no algorithm or pipeline; stage7a_source_audit.log verifies exactly
those transformations across 21 files, with 53 RTL and all21 production C/H
unchanged. Fresh UVM checks the resulting actual outputs before baseline use.
Stage6's immutable archive remains the accepted prior official qualification.

## Completed: Stage6 current-source full-operation qualification

The current main, with FULL_KEYGEN=1 and both Sign/Verify enabled, passes
all selected published pure external suites: 75/75 KeyGen keypairs (433600
exact bytes), 90/90 Sign signatures (310680 bytes) and 45/45 Verify verdicts
(9 valid, 36 invalid). All three suites share one fresh source fingerprint.
The independent C preparation gates also agree with the published outputs.
Checker faults reject 41/41 KeyGen, 152/152 Sign and 158/158 Verify corruptions.
No official case is silently replaced by a generated expectation. The full
360-case Sign / 180-case Verify audits retain the 270 / 135 excluded prehash,
external-mu and internal-message-interface cases as unsupported, not passed.

All 74 production RTL files, 21 production C/H files and 6.757ns SDC remain
byte-identical to Stage5V.4. Sign peaks at 33/45/61 regions; Verify at 22/30/40
in the same 64-region/four-bank pool. Verify checks 1328384 exact writes and
26880 reads. No new RAM, arithmetic engine or interface is introduced.
The dedicated nist_verify selector joins nist_keygen/nist_sign in the same
single DO/Python flow. Legacy DILITHIUM_STAGE=5 still selects controller tests;
Stage6 names the completed qualification milestone. See universal
REFERENCE_VERIFICATION.md for exact commands, exclusions and study order.
Evidence: evidence/stage6_full_operation_qualification.zip and SHA256.

**Next: Stage7 full-system UVM and implementation baseline.** Build the main
reusable UVM environment and meaningful functional/code coverage around the
complete KeyGen/Sign/Verify interface. Establish a fresh Quartus baseline for
the full-operation main, then improve measured Fmax, placed area, throughput
and slack while retaining the official-output gates. Preserve the 6.757ns
benchmark. Existing subsystem fits are not full-main PPA results. Stage7 is
not started by this qualification; no new netlists, FPGA, commit or branch
operation is included. Ask for material architectural/resource decisions.

## Completed:Stage5V.4 main Verify integration

The three existing clients now sequence through controller/verify.sv and main
op2. Use the approved PK/signature/ctx||M stream;one exclusive services lease
continues through all child handoffs and cleanup. Invalid length,norm and
hint encodings produce normal invalidity;host framing and child-service
failures are distinct errors. Keep existing KeyGen/Sign interfaces and engines.
The full-operation configuration is FULL_KEYGEN=1,ENABLE_SIGN=1,ENABLE_VERIFY=1;
the prior partial-KeyGen generic remains available for its legacy tests.

Fresh118-scenario capture/comparison passes:23 valid Verify,60 invalid Verify,
19 expected errors,14 resets/faults,one actual KeyGen and one actual Sign.
All45 official pure verdicts match (9 valid,36 invalid),including10 structural
invalids that stop before arithmetic.2624604 exact Verify writes/51466 reads;
170/170 checker corruptions rejected. C/Python60 distinct whole inputs agree.
Fresh Sign45 (21 signatures/63204 exact bytes) and KeyGen-only16 (8 keypairs)
compatibility pass. Same fingerprint across all gates. Only main RTL changed;
72 prior RTL/21 production C/H/SDC unchanged,one new module gives74 RTL files.
Evidence:evidence/stage5v4_full_verify.zip and SHA256. Universal reference,
process,memory,pin and throughput docs contain commands/results/study order.

**Next:Stage6 current-source full-operation qualification.** Consolidate the
supported pure API and run the full published75 KeyGen/90 Sign/45 Verify suites
against the current full-operation main configuration,with direct output-file
comparison and explicit unsupported-mode audit. Preserve the current source
and compatibility evidence. Stage7 full UVM/synthesis/optimization follows
that functionality gate;do not begin PPA work or netlists by implication.

## Completed:Stage5V.3 Verify equation component

Implement the equation with existing services:expand A,accumulate Ahat*zhat,
subtract chat*t1hat in NTT domain,and run one inverse per row. UseHint feeds
the shared Bitpkg and SHAKE formatter;compare recomputed c2 with ctilde.
Validate actual prior-stage handoff,all coefficient/hash values,ownership,
backpressure,errors and reset recovery with independent C/Python expectations.
No new memory bank or duplicate engine. Main host op2 stays a separate bounded
5V.4 milestone. Fresh87 scenarios pass:19 valid,35 cryptographically invalid,
23 expected errors,10 reset/fault aborts;2104627 exact writes/49903 reads.
All35 original structurally valid official verdicts agree (9 valid,26 invalid).
966 UseHint unit cases pass;172/172 checker corruptions reject. C/Python44
inputs/519168 equation values agree. Fresh prior verify_math134-scenario
regression passes unchanged under the same source fingerprint. All71 prior
RTL and the6.757ns SDC are unchanged;two modules are added. Private peaks
22/30/40 fit the unchanged pool. Evidence:evidence/stage5v3_verify_equation.zip
and SHA256;universal reference/throughput docs own exact counts and commands.

**Next5V.4:**create src/controller/verify.sv to sequence existing input prep,
math prep and equation clients through one services lease,then connect main
op2. Use the already approved64-bit three-frame PK/signature/ctx||M stream.
Test complete main-top official verdicts,early structural-invalid rejection,
host framing,lengths,backpressure,debug isolation,cleanup and reset recovery.
Preserve KeyGen/Sign compatibility. Keep functionality-first order;no new
PPA/full-system UVM/netlist stage or commit is implied by this milestone.

## Completed:Stage5V.2b message,challenge and NTT preparation

The math preparer atomically adopts the successful5V.2a context and consumes
the approved third ctx||M frame. Reuse the existing pure-message formatter
and shared SHAKE256 to compute mu=H(tr||00||ctxlen||ctx||M).64. Expand c from
the original signature's ctilde with shared SampleInBall. Transform shifted
t1 and z with normal FNTT,then c with the existing small-coefficient Pre-NTT.
Keep hints in coefficient form. A free region rotates through the sources;
the same four banks and all existing engines remain unchanged.

Retain13/18/24 result regions (K t1hat,L zhat,K hints,chat),rho,mu and ctilde.
Peak private reservation is14/19/25 regions,excluding unrelated owners.
Validate upstream identity/layout and complete leases before adoption;reject
bad commands without taking ownership. After adoption,drain malformed message
hashes,retire sampler/NTT requests and release every owned region on error.
Clear/take remain atomic and blocked by pending reads. Test independent
C/Python math,real upstream handoff,full packed readback,parameter/length/
framing failures,metadata faults,workspace exhaustion reports and resets.

This is still preparation,not a final signature verdict. Next5V.3 implements
Az-c*(2^13*t1),inverse NTT,UseHint,w1 packing and challenge recomputation.
Main op2 follows in5V.4. Keep functionality-first order and6.757ns constraint.

Gate passed:134 requests=65 transformed contexts+57 expected errors+12
reset/fault aborts;112/112 checker corruptions rejected. C/Python agree on56
inputs/191232 challenge-and-NTT coefficients. Fresh5V.2a133-scenario loading
revalidation passes. All70 prior RTL and the timing constraint are unchanged.
Evidence:evidence/stage5v2b_verify_math.zip with separate SHA256. Commands,
results and study order are in REFERENCE_VERIFICATION.md;geometry/lifetimes
and diagram are in MEMORY_MAP.md. **Next:5V.3 Verify equation and challenge
comparison**,using the retained transformed context and existing services.

## Completed:Stage5V.2a Verify bank loading and PK hashing

Split5V.2 into two bounded gates. **5V.2a** implements the first two approved
frames (PK,signature),shared bank ownership and SHAKE256(PK)->64-byte tr.
It uses the same four banks and one services tree. **5V.2b** will consume the
third ctx||M frame,compute mu,expand the challenge and prepare NTT handles.
The full approved three-frame host interface is unchanged. Main op2 remains
unsupported until5V.4;successful preparation does not mean a valid signature.

5V.2a retains K shifted-t1,L z and K dense-hint polynomials in contiguous
regions (12/17/23 total). A one-word PK fork independently tracks decoder and
hash acceptance. The existing scalar load service gains a Verify mode;PK load
and its matching raw hash descriptor start on the same edge. All other bank
clients wait until that loader retires. No encoded-key/signature RAM is added.
Malformed frames must drain the finite hash owner and release only their own
regions before error completion. Clear frees the context;take transfers it.
Pending read responses block both. Fatal service protocol faults need reset.

Gate requirements:independent C/Python hash and decoding cross-checks;exact RTL
scalar writes,packed reads,headers and digests;bad framing/norms/hints,foreign
region preservation,metadata faults,reset/recovery and checker corruptions.
Rerun shared Sign-load,main Sign and full KeyGen compatibility because load
arbitration changed. Keep6.757ns SDC and the existing synthesis top unchanged.
No commit,optimization,new netlists or full-system UVM in this checkpoint.

Gate passed:133 requests,49 prepared contexts,73 expected errors,11 resets/
faults,87/87 checker corruptions. Fresh SK-load138,KeyGen16 and main Sign45
compatibility scenarios pass;their physical counts remain unchanged. Results
and reproducible commands are in REFERENCE_VERIFICATION.md;memory lifetimes
and diagram are in MEMORY_MAP.md. Frozen evidence is
evidence/stage5v2a_verify_prepare.zip with a separate SHA256 file.
**Next:5V.2b**,third-frame message hashing,challenge and NTT preparation.

## Latest checkpoint:Stage5V.1 Verify decoding complete

USER APPROVED main Verify interface:one64-bit input stream with three ordered
frames,PK then signature then ctx||M. Each restarts index0 and has its own last
flag. Start metadata includes context/message/signature lengths;completion
reports valid/invalid. Preserve this decision;do not ask it again. No full
encoded-key/signature RAM is requested. This is the intended main interface;
op2 is still unsupported until the actual Verify controller is connected.

Execute Verify in bounded checkpoints:

1. **5V.1,complete:**strict PK/signature decoding,independent Python/C bit-layout
   and norm/hint checks,official sigVer audit/software verdict cross-check,
   directed framing/reset tests and checker validation. This is a component
   gate;decoding a signature does not establish cryptographic validity.
2. **5V.2:**connect decoded t1/z/h to the existing four-bank pool,hash the
   streamed public key to tr,and prepare mu/challenge/NTT handles with full
   ownership and cleanup. Keep the approved host ordering.
3. **5V.3:**shared-engine Az-c*(2^13*t1),inverse NTT,UseHint,packed w1 and
   challenge recomputation/comparison. Verify valid and invalid arithmetic
   cases with independent C/Python before main dispatch.
4. **5V.4:**wire verify.sv to main op2,retain Sign/KeyGen behavior,run original
   official pure-API Verify verdicts with framing,errors,resets and backpressure.
5. After complete KeyGen/Sign/Verify outputs,advance to full-system UVM and PPA
   under the existing overall plan. No synthesis optimization in these steps.

The new NIST sigVer corpus at the existing pinned commit has180 cases.45
pure public-API cases (15 per level2/3/5) target the approved interface;135
prehash/internal-API cases are retained and audited as unsupported. Official
expected verdicts comprise9 valid/36 invalid. The decoder only checks encoding
and z bounds;altered messages/challenges need the later arithmetic schedule.

Fresh383 decoder scenarios check117458 accepted input words and705010 decoded
values:275 structural successes,99 expected errors,9 resets;37 checker
corruptions reject. C/Python303 distinct frames/664576 values agree;full C
Verify matches all45 official verdicts. Decoder rejects10 official invalid
signatures;26 invalid signatures correctly pass structural checks and await
the arithmetic verifier. Fresh full-KeyGen compatibility8complete/3rejects/
5aborts plus37checker faults PASS. All67 prior RTL and6.757ns SDC unchanged;
one decoder added. Evidence:evidence/stage5v1_verify_decode.zip and SHA256.
**Next:5V.2 bank loading and PK hashing**,under the approved streamed interface.

## Previous checkpoint:Stage5N.4h.7 official NIST Sign complete

Downloaded original sigGen prompt/expected JSON at the same pinned NIST
revision as KeyGen. Audit all360 cases;select90 pure public-API cases,15
deterministic+15 randomized at each level2/3/5. Prehash/internal-message/
external-mu API cases remain explicitly unsupported (270 total). The existing
main Sign interface accepts every selected case unchanged. Software C and
actual main-top RTL both match90/90 official signatures/310680 bytes.
152/152 checker corruptions reject. Fresh local full_sign compatibility also
passes45 scenarios:21 Sign/63204 bytes,1 actual KeyGen/3872 bytes,14 expected
errors,9 aborts;196/196 checker corruptions reject. Counts equal4h.6. No RTL/
SDC change. Immutable evidence:evidence/stage5n4h7_nist_sign.zip and SHA256.
The single Python/DO now select nist_sign;the shared reference document owns
provenance,commands,files,study guide and final results. After this gate,the
next functionality task is main Verify;PPA/full UVM remain later work.

## Previous checkpoint:Stage5N.4h.6 main Sign complete

The user approved the streamed two-frame interface below. `sign.sv` now connects
key preparation,the attempt/retry loop and signature encoding;`dilithium.sv`
dispatches op1 to it. The45-case focused main-top gate and affected KeyGen
compatibility gates PASS. No encoded key/message buffer is added. The prepared
key is reloaded and freed per request.

Fresh45 commands=21 complete Sign/63204 exact signature bytes+1 actual
KeyGen/3872 key bytes+14 expected errors+9 reset/fault aborts.196/196 checker
corruptions reject.13356 accepted input words,9113 signature words including
abort prefixes,484 key words,76 attempt starts. Physical ledger:11253
allocations=8901 new+2352 rewrites;11251 finishes=11246 success+5 discards;
8778 releases and118 region lifetimes ended by reset (including2 open writes).
Peak regions33/45/61 at levels2/3/5;no new bank or payload RAM.

Fresh compatibility:encoded KeyGen8 complete/3 rejects/5 aborts and37 checker
faults;rounded/debug-read KeyGen7 complete/3 rejects/4 aborts,190224 scalar
values/12800 packed reads and36 checker faults. Main test uses default enabled
Sign and an actual KeyGen-to-Sign handoff. Legacy KeyGen-only tests select
ENABLE_SIGN0 to preserve their old unsupported-operation cases.

Reference C12 distinct fixtures/41424 bytes pass unchanged production Sign+
Verify;three also equal independent Python math. Expected Sign results remain
local reference-derived from official KeyGen SKs,not official NIST Sign vectors.
65 prior RTL,production C/H and6.757ns SDC unchanged;only the old main top
changes and one Sign client is added,making67 RTL. Immutable evidence:
`evidence/stage5n4h6_full_sign.zip` plus create-only SHA256 sidecar.

**Next Stage5N.4h.7:**obtain/audit official NIST ACVP ML-DSA sigGen vectors,
declare the supported pure/internal-mu host modes and map original inputs to
the approved stream. Capture actual main outputs and compare exact official
signature bytes through the same single Python/DO flow. Then implement main
Verify. External-mu/prehash support,full UVM/coverage and PPA optimization remain
later decisions/work;do not imply those are complete or optimize prematurely.

### Approved streamed request

| Boundary | Contract |
|---|---|
|Operation|Existing start command:0 KeyGen,1 Sign;Verify remains unsupported until implemented |
|Sign command metadata|Parameter2,operation ID16,message length16,context length9,explicit rnd256;pure final FIPS204 under labels2/3/5 |
|Input|One64-bit valid/ready stream with bytes4,index16,last1 |
|Frame1|Expanded SK2560/4032/4896 bytes;index starts0,last on its final word |
|Frame2|ctx||message;index restarts0,last on its final word;zero-length body needs no beat |
|Between frames|Input ready may pause during secret-key transformation;the producer holds the first body beat until ready |
|Length limits|Context<=255;66+context+message<=65535 for the current finite hash descriptor |
|Signature output|Separate64-bit valid/ready stream with bytes4,index10,last1,ID16;2420/3309/4627 bytes |
|Output validity|Bytes are provisional until matching successful held completion;error/reset discards the frame |
|Key lifetime|Reload each request and free prepared-key regions before completion;retention between requests is outside this configuration |

Main ownership must span key preparation,attempt/retry,encoding and cleanup.
Keep one physical services tree. Do not grant another command merely because
the main completion has retired while a child still owns cleanup. Mask external
debug read ready/valid during Sign so another consumer cannot steal its response.
Preserve existing KeyGen behavior and test its shared-interface compatibility.
Host index high bits must be checked before narrowing the SK index to10 bits.
Normal errors clean adopted payload and key ownership in dependency order;
noncancelable/fatal child faults require global reset.

### Reference work completed before host wiring

New test-only `tb/tb_dilithium/full_sign_reference.c` takes original SK,matching
PK,ctx,message and explicit rnd. It calls unchanged production
`crypto_sign_signature_internal` and verifies the resulting signature with
`crypto_sign_verify_internal`. It aborts if internal signing requests platform
randomness. It receives no RTL intermediates or expected signature bytes.

Fresh preflight:12 cases/41424 signature bytes PASS,4 per level2/3/5:
ctx7+message169,empty ctx/message,ctx255+message1,and ctx0+message1. The first
case at each level also equals the existing independent Python mathematical
attempt/encoding result. The other cases currently use the production C oracle.
Log:`sim/dilithium/stage5_full_sign_reference_preflight.log`. These are local
reference-derived signatures from official KeyGen keypairs,not official NIST
signature-output vectors. That preflight was software-only;the main-top results
above now establish the RTL checkpoint. No new PPA/full-coverage claim is made.
The adapter now joins the single Python's fingerprint/build and full_sign
selector;no second Python or .do is added.

Main Sign is enabled by default with ENABLE_SIGN1;the legacy
KeyGen-only tests explicitly select ENABLE_SIGN0. The new main-top gate uses
the default enabled Sign and includes an actual KeyGen-to-Sign handoff.
No branch change,commit or optimization authorized.

## Prior checkpoint:Stage5N.4h.5 signature encoding complete

`sign_signature_encode` adopts the accepted attempt,uses shared Bitpkg op4 for
z,and streams final-format ctilde||z||sparse-hints. Preflight preserves the old
owner;one atomic take transfers the whole payload. Read metadata,binary hints,
omega,output framing/stalls and whole-map cleanup are checked. Output is
provisional until matching code0;recoverable failure discards the frame and
adopted payload,fatal/noncancelable failures require global reset. The prepared
key stays retained. No new bank,signature RAM or duplicate arithmetic/packer.

Fresh24 scenarios:7 complete signatures/25339 exact bytes,9 expected errors,
8 reset/fault aborts;21 takes,6810 exact output words,8880 packed reads,
149 releases,11 actual key preparations.163/163 checker mutations reject.
Independent C/Python6 fixtures/22030 bytes agree;three nonce-zero fixtures
also match unchanged full C signing. These are local reference-derived
signatures using official KeyGen SKs,not official NIST signature-output vectors.
Expanded188-case shared packer/15 checker faults and full KeyGen8 complete
keypairs/3 rejects/5 aborts/37 checker faults PASS at the same source token.
Both compatibility gates are included in the checkpoint evidence. Focused testing;
no new PPA/full-UVM/netlist/FPGA/security signoff.

The shared pack op widens to3 bits;existing op numbers are unchanged. Only
Bitpkg,the service package and KeyGen encoder op width change among65 prior
RTL;62 stay byte-identical. New encoder makes66 RTL. Production C/H and6.757ns
SDC remain unchanged. Preserve prior archives/uncommitted work. New evidence:
`evidence/stage5n4h5_sign_encode.zip` and create-only SHA256 sidecar.

**Next Stage5N.4h.6:**implement the real main Sign client and host dispatch,
connecting prepared-key loading,initial message/context/rnd intake,the verified
attempt/retry loop and this encoder to the existing shared services. Define
framing/ownership and errors before wiring the host path. Compare full outputs
through the actual main top. Then official full-operation NIST signing and
main Verify. Keep functionality/exact bytes first. No commit,branch change,
optimization/full-UVM/netlist action is implied by this checkpoint.

## Prior checkpoint:Stage5N.4h.4 attempt/retry loop complete

New sign_attempt_loop connects the existing six attempt clients to one shared
services tree. Stream ctx/message once;derive mu/private seed once. Normal
rejections atomically transfer mu/seed/nextnonce after payload cleanup,then
the mask helper's new seed-only retry command bypasses those two derivations.
The key remains live.17-bit nonce/18-bit bound arithmetic stops before a
wrapped vector can launch. Actual service errors stop and reverse-clear
live child contexts;fatal failures require global reset. Accepted z/hints/
ctilde remain retained for clear/take,with pending-read and clear-priority rules.

Fresh47 cases PASS:19 accepted parent results,12 expected service failures,
5 nonce-exhaustion stops,11 reset/fault aborts;87 attempts,45 real rejections.
Every actual hash byte,105667 y coefficients,56256 packed reads and physical
allocation/commit/release record matches.152/152 checker corruptions reject.
Independent C/Python13 starting fixtures/26 full attempts/24064 accepted
z/hint coefficients PASS. Fresh default mask78-case regression and85/85
checker faults PASS. Only prior sign_mask_prepare RTL changes;the other63
prior RTL and6.757ns SDC are unchanged. Three old TB instantiations tie new
retry inputs low. New parent makes65 current RTL. No new engine/bank/payload
RAM or arbitrary-message replay buffer;no synthesis/PPA/netlist/full-UVM run.

Frozen evidence:evidence/stage5n4h4_sign_retry.zip plus create-only SHA256.
Universal specification,memory/process/reference/throughput/pin docs include
interfaces,limits,examples,run commands and study order. These are local
FIPS-derived intermediate/candidate results,not official signature outputs.

**Next Stage5N.4h.5:**encode accepted ctilde,z,h into the final level2/3/5
signature byte formats,using the existing shared packing/bank infrastructure.
Define result ownership and64-bit output/backpressure through packing;compare
whole signatures with the unchanged software reference,including canonical
sparse hint encoding. Then connect the main Sign host/controller dispatch.
Main Verify remains unfinished. Continue functionality/exact bytes first;
no branch,commit,PPA/full-UVM/netlist action is authorized by this checkpoint.

## Prior checkpoint:Stage5N.4h.3 candidate checks complete

New helpers/sign_attempt_check.sv adopts z/r0/w1/ct0 and private headers from
the products owner,checks CNB across z/r0/ct0,then uses existing in-place ADD
and shared Mhint. A12-bit vector-weight sum enforces omega80/55/75. One
rotating hint destination reuses freed low-row storage;no new bank/payload
RAM or arithmetic engine. Accepted results retain z/hints/ctilde;normal
rejections discard all attempt payloads and retain mu/seed/17-bit nextnonce.
Service/protocol errors have separate nonzero codes;fatal faults need reset.
Clear/take wait for pending reads,clear wins and old owners invalidate.

Fresh59 cases PASS:18 accepted candidates,5 genuine algorithmic rejections,
21 expected errors,15 reset/fault aborts;53 whole takes,70944 exact writes,
157888 exact packed reads. Eight local FIPS-derived fixtures use three
published KeyGen SK inputs. Python mathematical HighBits/centered norms and
unchanged C agree on25794 values;118/118 corrupted captures reject. Not
official signature-output vectors or completed signatures. All63 prior RTL
and6.757ns SDC are unchanged;new helper makes64 current RTL files.
Fresh preceding sign_products63-case regression and84/84 checker faults
also PASS at the same source token. Frozen evidence:
evidence/stage5n4h3_sign_accept.zip plus create-only SHA256 sidecar.
Universal specification/memory/process/reference/throughput docs contain
the contracts,run commands,counting arithmetic and visible test limits.

**Next Stage5N.4h.4:**connect rejection/nonce retry using retained mu/private
seed,nextnonce and prepared key without replaying the message or rehashing
the private seed. Define atomic header transfer and region lifetime before
reusing ExpandMask. Guard the17-bit65536 boundary before narrowing a nonce;
test successive real rejects followed by acceptance,backpressure,service
errors and reset/recovery. Then signature packing and working main Sign;
main Verify remains open. Stay functionality/bytes first;no PPA/full-UVM/
netlist,branch change or commit is authorized here.

## Prior checkpoint:Stage5N.4h.2 products and response arithmetic complete

New helpers/sign_response_products.sv adopts raw-y/retry headers and the
w0/w1/chat context atomically. Shared PWM/INTT calculates cs1,cs2,ct0;existing
in-place ADD/SUB rewrites y->z and w0->r0. w1 and the prepared key stay intact.
The result retains z,r0,w1,ct0,mu,private mask seed,ctilde and17-bit next nonce.
Two scratch addresses are reused;ct0 uses k existing regions. Old mask owner
adds take and invalidates before destructive writes. Whole-context clear/take
controls the result lifetime;normal errors discard the whole adopted attempt.

Fresh63 cases PASS:24 complete arithmetic schedules,21 expected errors,
18 reset/fault aborts;425955 exact intermediate writes,99584 packed reads.
Independent sparse convolution and unchanged C agree on6 fixtures/44032
product/z/r0 coefficients;84/84 checker corruptions reject. Fresh prior
sign_transform51 and64/64 checker faults also pass. No new arithmetic/banks/
payload RAM;other61 prior RTL and6.757ns SDC unchanged. Evidence:
evidence/stage5n4h2_sign_products.zip +create-only SHA256 sidecar.

**Next Stage5N.4h.3:**adopt the arithmetic context with its private headers;
reduce CNB results over z,r0,ct0 at their mode-specific bounds. For candidates
passing norms,add ct0 into the corrected low part and make hints against w1;
reduce total hint weight against omega80/55/75. Distinguish algorithmic reject
from a service/protocol error. Discard rejected payloads while preserving
mu/private seed/next nonce for retry. Add legitimate level5 nonce fixtures
which reach the hint path;the current six include genuine norm rejections.
Then connect nonce retry/ExpandMask seed reuse,signature packing and main Sign.
Main Verify remains open. Arithmetic completion is not signature acceptance.
Stay functionality/bytes first;no PPA/full-UVM/netlist,branch or commit here.

## Prior checkpoint:Stage5N.4h.1 ownership and challenge transform complete

Matrix/challenge READY clients now support explicit whole-context take.
New helpers/sign_challenge_transform.sv adopts both atomically,releases dead
yhat,computes ordinary FNTT(c),validates complete destination/child retirement,
then releases raw c. w0/w1/chat and ctilde remain retained for the products.
Key/raw y survive. Clear or another whole-context transfer ends ownership.
No new engine,banks or payload RAM;steady live regions drop29/40/54 ->
25/35/47 at levels2/3/5,excluding the test sentinel/capacity blockers.

Fresh51 cases PASS:24 successes,12 expected errors,15 reset/fault aborts;
42 atomic handoffs,7875 exact transform writes,85760 packed reads. Python/C
agree on6 fixtures/1536 c+1536 chat values;64/64 checker faults reject.
Fresh prior challenge81-case regression and77/77 checker faults also pass.
Only two prior control helpers gain take;other59 prior RTL and6.757ns SDC
are unchanged. Evidence:evidence/stage5n4h1_sign_transform.zip +SHA256.

**Next Stage5N.4h.2:**connect chat*s1,chat*s2,chat*t0 and inverse transforms,
then z and w0 corrections. Reuse transferred attempt regions only after their
last read. The existing mask client still owns raw y and mu/private seed:
define its handoff/header retention before destructive reuse or retries.
Follow with norm/hint checks,rejection/nonce retry and signature packing.
Stage5N.4h and main Sign/Verify remain unfinished. Stay functionality-first;
no new PPA/full-UVM/netlist,branch or commit is authorized by this checkpoint.

## Prior checkpoint:Stage5N.4g challenge generation complete

helpers/sign_challenge_prepare.sv connects retained w1 through shared Bitpkg
op3,the existing mu||w1 formatter,shared SHAKE256 and SampleInBall. Actual
ctilde32/48/64 bytes feed c generation;whole success waits for complete c
storage and service retirement. One additional existing region stores c;
normal clear/errors preserve prepared key,y,yhat,w0,w1. Invalid hash paths
drain/discard and never launch dependent sampling;fatal faults require reset.

Fresh81-command gate PASS:24 successes,39 expected errors,18 reset/fault
aborts;8640 exact c writes,171264 packed reads,3216 actual digest bytes.
Python/C agree on6 fixtures:5120 packed w1 bytes,288 ctilde bytes and1536 c
coefficients.77/77 corrupt captures reject. Extended shared Bitpkg136 cases
and15/15 checker faults pass. Fresh fullKeyGen8/3/5 and37/37 checker faults
pass. All59 other prior RTL and6.757ns SDC unchanged;
only existing Bitpkg gains w1 encoding,plus the new control helper.
Universal reference/specification/memory/process docs carry the contracts.
Frozen evidence:evidence/stage5n4g_sign_challenge.zip plus SHA256 sidecar.

**Next Stage5N.4h:**define safe subset ownership handoffs/reuse in the64-region
pool,then connect challenge transform and secret products,z,w0 corrections,
hint/norm checks and rejection/retry with private-seed reuse. yhat becomes
dead after A*y,but current matrix READY owns it together with w0/w1:explicit
handoff/release is required before reuse,not overwriting child-owned regions.
Keep mu and mask seed across retries without replaying arbitrary message RAM.
Signature packing and working main Sign follow. Main Sign/Verify and overall
Stage5N.4 remain unfinished. Continue functionality/bytes first;PPA/full-UVM/
netlists remain later. No commit,branch or constraint change is authorized.

## Prior checkpoint:Stage5N.4f matrix/decomposition complete

New helpers/sign_matrix_prepare.sv connects retained y to ordinary FNTT,
samples all rows of A directly in NTT representation,uses the shared row
PWM/ADD/INTT service,and decomposes each w row through the existing x4 DMA.
Original y and prepared secrets remain retained. Free-address planning uses
19/25/33 workspace addresses inside the unchanged64-region banks;A/raw-w
temporaries are reused per row. Full yhat/w0/w1 publication waits for every
row and both decomposition commits. Errors roll back all workspace;clear
releases the new retained vectors without releasing key/y or other clients.

Fresh gate PASS:66 commands =24 successful executions +24 expected errors
+18 reset/fault aborts;1060230 exact scalar writes and102336 packed reads.
Successful executions reuse six distinct level/nonce combinations,including
recovery runs. Python/C agree on6 complete vector fixtures/96256 values.
66/66 corrupted-capture tests reject. Fresh full-KeyGen8/3/5 regression and
37/37 checker faults also pass. All59 prior RTL and6.757ns SDC are unchanged;
no new physical engines,banks or polynomial/message RAM. Evidence:
evidence/stage5n4f_sign_matrix.zip and its create-only SHA256 sidecar.

**Next Stage5N.4g:**encode the retained w1 vector through shared Bitpkg,hash
mu || encoded_w1 with the verified challenge formatter,and SampleInBall to
produce c using the same Keccak/sampler/memory. Then connect challenge/secret
products,z,w0 corrections,hints/norm checks,rejection/retry/seed reuse and
signature packing into a working main Sign. Main Sign/Verify and overall
Stage5N.4 remain unfinished. Continue functionality/bytes first;PPA/full-UVM/
netlists remain later. No commit,branch or constraint change is authorized.

## Prior checkpoint:Stage5N.4e retained-key hashes and mask vector complete

New helpers/sign_mask_prepare.sv consumes the validated retained K/tr context,
computes pure-message mu,derives the private mask seed,and generates the full
y vector(4/5/7 polynomials) through the same shared Keccak/sampler/banks.
No reference digest is injected into RTL. Each descriptor waits for formatter
AND physical-owner retirement;sampling complete is validated after the memory
finish handshake. Layout/nonce overflow reject before hashing. Invalid results
never feed dependent work;rollback/clear releases masks while retaining the key.

Gate PASS:78 commands,27 successes,36 expected errors,15 reset/fault aborts;
6800 exact physical digest bytes,49094 scalar writes,83136 packed reads.
18 real preparations reuse three published NIST KeyGen SK inputs. Python/C
agree on462 intended component messages/336 mask polynomials;expected
intermediates are local FIPS-derived vectors,not official signature outputs.
85/85 corrupted-capture checks reject. Fresh local full-KeyGen comparison
and37/37 checker faults pass. All58 earlier RTL and6.757ns SDC are unchanged.
Evidence:evidence/stage5n4e_sign_masks.zip and its create-only SHA256 sidecar.
Full contracts,arithmetic counts and run commands are in the universal docs.

**Next Stage5N.4f:**connect coefficient-domain y to ordinary forward NTT,
shared matrix/vector multiplication A*y and decomposition. Keep raw y for
later z;eligible secret Pre-NTT does not apply to these wide mask coefficients.
Then challenge/secret products,hints/norm checks,rejection/retry/seed reuse,
signature packing and working main Sign. Main Sign/Verify and overall Stage5N.4
remain unfinished. No PPA optimization,netlist/full-UVM,branch or commit is
authorized by this checkpoint;functionality/bytes first,6.757ns unchanged.

## Prior checkpoint:Stage5N.4d retained key context and shared transforms

New helpers/sign_key_prepare.sv controls the existing loader and shared NTT
engine. It retains validated rho/K/tr,level,ID and polynomial handles. One
free scratch rotates through released raw-source regions;peak storage is
N+1 and the retained prepared key uses N=12/17/23 existing regions. s1/s2
use eligible Pre-NTT,t0 uses ordinary forward NTT. Header/handles remain
private until the full key is transformed and every old source released.

Successful done moves to retained READY;new commands cannot overwrite it.
The outer Sign owner may use other privileged service clients in READY.
Explicit clear drains pending consumers,invalidates context and releases
all owned regions. Normal errors clean earlier transformed replacements too;
physical faults halt under the same owner until global reset. No duplicate
engines/memory or encoded-key/polynomial RAM is added. Main Sign stays pending.

The final gate checks165 commands including all75 official KeyGen SKs,valid
retention/clear,real transform rejection,wrong child result tags/masks,eight
resets/fault recoveries and unrelated sentinel preservation. Independent
direct-evaluation Python and unchanged C unpack_sk/poly_ntt agree on164 full
source fixtures/709632 values. All3 fresh gates pass:preparation55 checker
corruptions,shared loader95,and local full-KeyGen37. Counts and limits are
in REFERENCE_VERIFICATION.md;create-only evidence is frozen in
evidence/stage5n4d_key_prepare.zip with its SHA256 sidecar. Prior archives stay
unchanged. Main Sign/Verify and the overall Stage5N.4 remain unfinished.

**Next Stage5N.4e:**connect retained header/key fields to the already verified
signing-message hash and mask-generation clients,then vector arithmetic/
reductions,retry and signature packing. Main Sign/Verify and Stage5N.4 remain
unfinished. Keep functionality first and6.757ns;no PPA/netlist/UVM/commit or
branch action is part of this continuation.

## Prior checkpoint:Stage5N.4c2 key loader in production shared services

The existing dilithium_services tree now owns the loader behind its row and
bank arbiters. Nested load request/response fields carry the same streamed
key input and validated header/region result. KeyGen explicitly disables
this client;no second engine or memory tree is added. Five previous RTL files
change(types,wrappers,KeyGen tie-off);the decoder,loader,primitive memory,
Keccak,sampler,NTT and arithmetic RTL are unchanged.

The shared gate checks138 key commands,all75 published KeyGen secret keys,
449992 exact scalar writes and105728 exact packed reads. Each of the three
levels tests eight prior-owner blocking phases,same-edge read/release priority,
isolated competing request classes,held-done ownership and queued-row
retirement. Real SHAKE/sampling supplies sentinel data;successful decoded
secrets are handed to existing CNB. Full results/checker counts and fresh
regression evidence are recorded in REFERENCE_VERIFICATION.md.
All seven fresh gates pass,including95/95 shared-loader checker corruptions.
Frozen evidence:evidence/stage5n4c2_shared_key_load.zip +.sha256;prior archives
remain unchanged. This completes the bounded4c2 milestone,not main Sign.

**Next Stage5N.4d:**retain validated header/key-region handles in a signing
client and schedule secret transforms using the shared engines(Pre-NTT only
where eligible,ordinary forward NTT for t0). Then connect the validated hash
formatter/mask path,vector arithmetic/reductions,retry and signature packing.
Main Sign/Verify and Stage5N.4 overall remain unfinished. Continue functionality
first;6.757ns unchanged,no new PPA/netlist/full-UVM/commit or branch action.

## Prior checkpoint:Stage5N.4c1 whole-key bank ingestion client

The first bounded part of Stage5N.4c is implemented in sign_key_load.sv.
It streams the existing decoder into the existing memory allocator/packer
and four banks in a focused client harness. A configurable contiguous plan
stores s1[l],s2[k],t0[k],using12/17/23 regions for levels2/3/5. No encoded-key
or polynomial RAM is added. Every key remains private until all decoding and
memory acknowledgments succeed. Late errors discard the active partial
allocation and release all earlier commits;held completion retains leases.

Gate:138 commands,133 completions(95 success,38 expected errors),5 resets;
449992 exact scalar writes,105728 exact92-bit reads,75 official KeyGen SKs.
Physical shared-service wiring is NOT claimed by this client gate. No existing
RTL or6.757ns constraint is changed;no new PPA result.
61/61 loader checker corruptions reject. Fresh local full-KeyGen regression
passes8 complete/3 rejects/5 resets and37 checker faults. Evidence is frozen
in evidence/stage5n4c1_sign_load.zip and its create-only SHA256 sidecar.

**Next Stage5N.4c2:**connect this client to the one production services tree;
extend arbitration,acceptance-edge locks,public read/release blocking and
owner retirement. Test clashes with existing row/NTT/process/sampling clients,
pending public reads and held done,then retain header/key handles for Sign.
After that:secret transforms,mask generation,vector reductions,retry and
signature packing/control. Main Sign/Verify and Stage5N.4 remain unfinished.

## Prior checkpoint:Stage5N.4b signing hash-message client

New process/sign_hash_message.sv formats pure-message mu,private mask seed,
challenge and one mask-polynomial nonce descriptor. The focused harness drives
the actual main-owned dilithium_services,using its existing Keccak pair,sampler
and banks. No previous RTL or6.757ns SDC changes,no duplicate engine tree.

Gate PASS:167 commands,162 completions(128 success,34 expected errors),5 resets;
52618 exact absorption words,7760 SHAKE bytes,6400 canonical mask coefficients.
6464 SHAKE bytes belong to successful requests;1296 are rejected-request drain
diagnostics and never enter the valid dependent-digest cache.29 peer-core jobs
and9 actual RTL digest forwards exercise stream/owner separation.61 checker
corruptions reject. Python/C agree on154 intended messages/420639 bytes and26
mask polynomials,using unchanged C SHAKE,w1 packing and mask sampling.
Fresh decoder,shared-process and local full-KeyGen regressions also pass.
Frozen evidence:evidence/stage5n4b_sign_hash.zip +.sha256;prior archives preserved.

The client snapshots command fields,merges arbitrary byte-aligned payloads
with prefixes,checks payload index/byte count/last,and holds outputs under
stalls. Invalid commands never launch. A bad payload AFTER launch triggers
zero-filling of the remaining descriptor length;the entire result is invalid.
Future Sign ownership MUST discard that hash and wait for raw/sampler
retirement before accepting formatter done. This drain is not SHAKE padding;
the existing hash core still applies standard SHAKE padding.

**Next Stage5N.4c:**connect decoded-key ingestion to shared-bank ownership,
keep the entire key private until complete-key success,and test rollback/
reset/reuse. Then connect retained key/hash fields,secret transforms,mask
generation and signing schedule. RTL w1/z/h encoding,vector norm/hint
reductions,retry and full signatures remain pending. Formatter consumes
already encoded w1;it does not yet pack it in RTL. Stage5N.4/Stage5N overall
remain incomplete;main Sign/Verify are unsupported. Keep functionality first;
no commit/branch/synthesis/netlist/full-UVM/PPA advancement.

## Prior checkpoint:Stage5N.4a expanded signing-key decoder

New process/sign_key_decode.sv streams an expanded secret key into rho,K,tr
and tagged canonical s1/s2/t0 coefficients. It uses128 bytes of retained header
plus a76-bit reservoir;no full encoded-key or polynomial RAM. It checks complete
word framing and unused eta encodings,holds outputs under backpressure and
cancels state on reset. All outputs remain tentative until overall done_code=0.

Focused gate PASS:129 commands,124 completions(92 success,32 expected errors),
5 reset aborts and436424 exact emitted coefficients. All75 published NIST
KeyGen secret keys decode correctly. This tests decoding of official keys;
it is NOT a NIST Sign operation test. Independent Python/C agree on128 full
key fixtures and549888 coefficients,with unchanged unpack_sk/pack_sk roundtrip.
All35 deliberately corrupted captures are rejected.
Fresh sign_service and local full_keygen regressions also pass;all54 prior RTL
files/6.757ns SDC are unchanged. Frozen evidence:
evidence/stage5n4a_sign_decode.zip and.sha256 sidecar;prior archives preserved.

**Next Stage5N.4b:**signing hash-message formatting and real shared-Keccak checks:
mu from tr plus pure-ML-DSA context/message prefix;rho-prime from K,rnd,mu;
challenge seed from mu and encoded w1. Preserve final FIPS204 byte lengths
and add signing-mask nonce formatting without KeyGen-only nonce limits.
Then connect decoded-key ingestion to bank ownership,vector checks,retry and
signature packing. Main Sign/Verify remain unsupported. Stage5N.4 and Stage5N
overall are not complete. No existing production RTL changes,no main port
changes,no synthesis/PPA/netlists/full UVM,commit or branch operation.
Execution/evidence details are in REFERENCE_VERIFICATION.md;earlier milestones
below describe their historical boundaries.

## Prior milestone:Stage5N.3 shared signing-process memory service

sign_process_dma now runs inside the one main-owned banked service through
request_t.sign / response_t.sign. It checks every read's owner,address,level,
coefficient domain and retained mode;validates full23-bit highs before narrowing;
stores signed lows canonically;and protects sources/results until done retires.
Decompose publishes both results after all acknowledged writes. Late errors
discard tentative destinations. CNB returns a polynomial rejection flag;
Mhint writes hint bits and returns a9-bit polynomial count.

| New gate | Result |
|---|---|
| sign_dma |71 commands,65 completions,21 expected errors,6 reset aborts;14284 exact scalar writes,3570 packed ACKs;32 checker corruptions rejected |
| sign_service |33 commands,30 completions,9 expected errors,3 reset aborts;192 sampled source words,768 exact result words;33 checker corruptions rejected |

The service gate uses actual SHAKE/sampling and the existing shared banks.
It checks row/NTT/scalar/pending-read priority,held-completion leases,exclusive
ownership and atomic result visibility at levels2/3/5. These component fixtures
are locally generated FIPS-derived cases,not published standalone NIST Sign
vectors. Fresh regression results/evidence are in REFERENCE_VERIFICATION.md.
All six current gates pass,including local full_keygen and all75 official
nist_keygen keypairs(433600 exact bytes). Frozen evidence:
evidence/stage5n3_sign_memory.zip and.sha256 sidecar;prior archives preserved.

**Next Stage5N.4:**signing key/input decoding and hash-message formatting,
with independent field/byte checks. Then vector-wide norm/hint reductions,
retry control and signature packing. Stage5N overall is unfinished;main
Sign/Verify remain unsupported. No duplicate engine tree,polynomial RAM,encoded
key RAM or external dilithium.sv ports were added. KeyGen drives sign='0.
Keep functionality first,the four-bank/shared-engine architecture and6.757ns
constraint. No full UVM/PPA/netlist stage advance,commit or branch operation.
Ask about material scope/interface/resource departures;routine choices remain
delegated. Earlier milestone sections below describe their historical state.

## Prior milestone:Stage5N.2 signing-process arithmetic

Working Decompose x4,CNB and Mhint arithmetic now sits behind sign_process,
a one-stage elastic x4 packet transport. It checks64 ordered groups,locks
ID/op/level/relevant kind,and returns Decompose high/low,per-lane norm/hint
results,sticky polynomial norm rejection and polynomial hint count.
It supports all levels2/3/5. Errors invalidate tentative packet output;reset
clears pending output and reductions. No source/model imports from RTL.

Current focused gate:7752 accepted groups,7746 exact results,45 expected
invalid-input/protocol errors,6 reset aborts,117 complete polynomials and27
checker corruptions rejected. Python/C agree on30996 scalar fixtures;the
unchanged C decomposition also passes all8380417 residues at each level.
Concrete tie/wrap/bound/sticky/hint witnesses are in the universal test plan.

All three current-source gates pass:sign_process,full_keygen(8 complete,
3 rejects,5 resets,37 checker faults),nist_keygen(75 exact keypairs,41 faults).
All48 pre-existing RTL files and6.757ns SDC are unchanged. Earlier diagnostic
results remain in Stage5N.1 evidence,not claimed newly rerun here. No synthesis,
new PPA,main Sign implementation or external top-level port change.
Frozen evidence:evidence/stage5n2_sign_process.zip and SHA256 sidecar.

Next Stage5N.3:connect the x4 process to shared banks with checked command,
read/metadata and write-acknowledgement ownership. Convert signed Decompose
lows to canonical23-bit residues and validate full stored highs before6-bit
narrowing. Keep tentative results unpublished until full error-free packets;
retain sources/results through completion retirement. Exercise reject/error,
backpressure/reset and same-ID reuse through the real memory path.
Then continue signing key/input decoding,hash formatting,vector reductions,
retry and signature packing in bounded steps. Sign/Verify remain unsupported;
Stage5N overall is not complete. Preserve full-KeyGen/NIST gates;stay with the
agreed LightHD shared-engine/four-bank architecture. No commit/branch operation
or synthesis;ask for material scope/interface/resource departures.

## Prior milestone:Stage5N.1 main-owned shared services

dilithium.sv now owns one dilithium_services instance containing the existing
banked SHAKE/sampler/NTT/process/row service and one unchanged Bitpkg. KeyGen
and its encoder are clients of packed request/response records defined in
helpers/dilithium_service_pkg.sv. No external top-level port changes,new engine
copies,bank RAM or pipeline registers are introduced by this boundary.
The main ownership gate stays active through post-completion cleanup,even
when the main FSM has returned to IDLE. Idle/unowned requests are zero.

Four current-source gates and their checker fault tests pass:

| Selector | Current result |
|---|---|
| nist_keygen |75 official keypairs,433600 exact bytes;41 checker corruptions rejected |
| full_keygen |8 complete,3 rejects,5 reset aborts;37 checker corruptions rejected |
| keygen |7 complete,3 rejects,4 reset aborts;34 rows,172304 scalar writes,8448 reads;29 checker faults |
| rounded_keygen |7 complete,3 rejects,4 reset aborts;34 rows,190224 writes,12800 reads;36 checker faults |

Local and NIST captures are identical to Stage5M apart from freshness headers
and the new Q ownership witness. All25 accepted engine files,the row wrapper,
Bitpkg and6.757ns SDC are unchanged. No new PPA result is claimed.
Frozen evidence:evidence/stage5n1_shared_services.zip and matching SHA256.

Next Stage5N.2:implement Decompose x4,CNB and Mhint as working shared process
blocks with independent Python/C boundary checks and focused RTL capture.
Then connect their memory/DMA use,signing inputs/key decoding,hash formatting
and retry/packing control in further bounded substeps. Do not add placeholder
Sign/Verify implementations or duplicate engine trees. The Sign controller,
remaining signing formats and Verify are still unimplemented;Stage5N as a
whole is not complete. Preserve current KeyGen/NIST gates during new work.
Keep functionality-first integration;no synthesis,commit or branch operation.
Ask for material scope/interface/resource departures;routine agreed choices
remain delegated. Universal docs and one launcher/Python flow continue.

## Prior milestone:Stage5M official NIST KeyGen

All75 published NIST ACVP KeyGen cases pass through the complete RTL path:
25 each at ML-DSA-44/65/87,called levels2/3/5 here. All433600 key bytes match
the downloaded expected keys. Actual PK hash input,tr,read ownership,ID wrap
and cleanup/reuse are checked;39 deliberate checker corruptions reject.
The existing full-KeyGen bench/one launcher/one Python script are reused.
Official files and pinned provenance are under NIST/ML-DSA-keyGen-FIPS204/.
All46 production RTL files remain identical to Stage5L;no PPA change is claimed.
The local reset/recovery/rejection full_keygen gate also freshly passes with
35 checker faults. These are the two current-token gates;the earlier16-gate
regression remains preserved in Stage5L. Frozen Stage5M evidence:
evidence/stage5m_nist_keygen.zip and stage5m_nist_keygen.sha256.

Next Stage5N:begin Sign by exposing shared engine/bank/packer ownership to
main-controller arbitration,and implement the remaining Decompose/CNB/MakeHint
processing and signing schedule in bounded steps. Keep complete KeyGen/NIST
tests passing during refactoring. Sign/Verify remain unsupported until their
actual output gates pass. Stage6 whole-operation scope remains open for those
operations;Stage7 full UVM/PPA and Stage8 netlists/FPGA are not started.
Routine choices follow the agreed LightHD reconstruction/shared-memory model;
ask the user for a material scope/interface/resource departure. No commit,
branch operation or synthesis is authorized by this continuation.
See REFERENCE_VERIFICATION.md for provenance,commands and detailed results.

## Prior milestone:Stage5L complete software-reference KeyGen

FULL_KEYGEN=1 now connects the retained banks to Bitpkg,streams the public key
to output and the same Keccak raw service,collects tr=SHAKE256(pk,64),then
streams rho,K,tr,s1,s2,t0 as the complete secret key. The main operation FSM
waits for all output/hash/packet work before held completion and cleanup.
Default0 preserves earlier polynomial inspection modes.

Eight complete keypair operations at levels2/3/5 match the unchanged software
KeyGen byte-for-byte. Three expected rejects and five reset/recovery cases
also pass. The capture checks5433 key words,2058 PK hash input words,656 tr
bytes and11179 field-read metadata records;35 checker corruptions reject.
No additional encoded-key RAM or hash engine is introduced.

All16 focused integration gates and their checker fault tests freshly pass
on the same source token. Frozen source,reference,captures,logs and docs are in
evidence/stage5l_full_keygen.zip with stage5l_full_keygen.sha256. All25 imported
Keccak/sampler/NTT SystemVerilog files remain byte-identical to Stage5K.

Next Stage5M:obtain official NIST full-KeyGen vectors,validate source/provenance
and compare the exact published key bytes through this RTL path. After this
conformance gate,continue the Sign controller and remaining LightHD CNB,
Decompose x4,Mhint/Bitpkg extensions,then Verify. Keep the shared controller/
memory reuse architecture;document compatibility decisions and measure any
claimed improvements. Comprehensive full-system UVM/PPA remain after supported
outputs. No commit,branch change,synthesis or netlist run in this continuation.

## Prior milestone:Stage5K rounding and Bitpkg

The ROUND_OUTPUTS=1 KeyGen path now stores t1/t0 after each t row and retains
both arrays through overall completion. It uses existing bank2/3 regions8..15,
not extra memory banks. Default0 preserves the earlier polynomial gate.
Seven successful operations,three expected rejects,four reset cases and34
delivered rows pass:190224 scalar values,12800 exact92-bit reads and36 checker
corruptions. Retained rounded arrays are released only during final cleanup.

process/bitpkg.sv now implements t1,t0 and secret polynomial field packing.
97 commands include60 valid packets,31 errors and6 resets;2482 exact64-bit
words and15 checker corruptions pass.66 full valid fixtures/18496 bytes agree
with unchanged software C packers at levels2/3/5. The other LightHD process
blocks remain in their planned Sign/Verify stages.
All15 focused integration gates and checker fault tests pass on one current
source token;the previous13 remain selectable and independently checked.

Next:connect bank reads to Bitpkg,serialize the complete key fields,and
hash the encoded public key into tr. The user reaffirmed reconstruction of
LightHD's shared controller/memory reuse with justified improvements and
delegated compatible architecture decisions. Select tagged64-bit key streaming,
retaining t1/t0 in existing banks and adding no encoded-key RAM. This selection
is our interface decision,not a claim about unpublished LightHD port signals.
Stage5L will connect bank reads/Bitpkg,PK word forking to host/shared hash,
tr collection,then SK field order and final cleanup. Do not begin PK hashing
before the final matrix sampling has completed. This stage does not claim
complete encoded keys;see SPECIFICATION.md for the selected next interface.
Keep the one launcher/script,universal docs,accepted engines and6.757ns target.
No PPA optimization,commit,branch operation or new netlist run.

## Prior milestone:Stage5J autonomous polynomial phase

The requested root controller organization is now active:memory.sv,keygen.sv
and dilithium.sv contain working RTL. sign.sv and verify.sv are the designated
files for their implementation steps. Shared data/memory/control helpers are
kept in subfolders. All processing arithmetic/formatting belongs under process/,
including working power2round.sv. The requested LightHD process inventory is
CNB,Decompose x4,Mhint,Bitpkg and P2R plus required UseHint/checking helpers;
see PROCESS_BLOCKS.md for current/planned status.

keygen.sv now autonomously expands xi,samples every s1/s2 nonce,retains raw
secrets,Pre-transforms s1 once,processes every A_hat row,and adds s2[i] after
inverse NTT. It presents coefficient-domain t rows and cleans up all regions
after overall completion acceptance. The bench no longer schedules these
internal commands. Seven polynomial-phase operations,three expected rejects,
four reset cases and34 t rows pass independent comparisons;29 corrupted
captures are rejected. All13 focused gates and checker fault tests pass on the
same source token. Old scalar/banked/row gates remain selectable.

Next bounded step:connect Power2Round to the KeyGen scheduler and implement
Bitpkg for t1/t0 and secrets,then public-key hashing and exact encoded key
outputs. Ask before major external key-storage/interface decisions. Only after
full KeyGen output checks advance to Sign/Verify controller/process steps.
Complete FIPS204 bytes use level2/3/5 names. No new PPA optimization,commit,
branch operation or netlist simulation is authorized by this continuation.

## Prior milestone:Stage5I seed-driven row path PASS

The RTL seed collector and message formatter are now connected to the real
banked Keccak/sampler/NTT/row path through keygen_sample_source.sv.
Selector5/seed_row passes190 commands:20 seed expansions,163 sampling jobs and
7 expected adapter errors. All2560 seed bytes and1103 sampling absorption words
match Python;retained rho,rho-prime,K match. The existing row workload passes
13 complete rows,27 rejections,7 reset aborts and12544 exact92-bit readbacks.
23 seed-path checker corruptions are rejected;all eleven earlier focused
gates also pass on the current source token.

This is a verified command adapter connection,not full KeyGen. The bench still
schedules sampling/NTT/row descriptors. Connected tests cover s1 and two matrix
rows per level2/3/5;all s2 nonces and remaining rows await the next schedule.
Next Stage5J:implement autonomous KeyGen polynomial scheduling,retain s2,
add s2[i] to inverse rows,then connect Power2Round and key serialization in
bounded follow-ups. Establish exact public/secret-key outputs before Sign/Verify
and before PPA/full-system UVM optimization. Keep the accepted engine RTL,
LightHD-shaped four banks,one launcher/script and universal documentation.
No new commit,branch change,synthesis or netlist simulation is part of this gate.

## 1. Purpose and current status

**Current user decision (2026-10-20): functionality first.** Stop the Stage2
timing optimization campaign and proceed with incremental integration. Establish
correct outputs through memory, NTT, processing and full KeyGen/Sign/Verify
before optimizing Fmax, placed area and throughput in Stage7. The existing
6.757 ns synthesis constraint remains a benchmark; meeting it is not a gate
before Stage3. This supersedes the earlier timing-first instruction.

**Integration means the Dilithium project.** This is the shared roadmap for
connecting our accepted Keccak, sampler and NTT, building the controller and
memory, adding the remaining processing blocks, and verifying the complete
accelerator. Do not create a second plan for the same work under another name.

The working branch is `integration`, created from `sampler_v1` at `e1b9c84`.
The sampler is already present. Its accepted Stage4.9r implementation has
3537 actual placed ALMs, 164.74 MHz worst Fmax, +0.430 ns setup and +0.141 ns
hold at a 6.500 ns constraint. Stage5 source, post-synthesis and post-fit checks
passed. These are **standalone sampler results**, not integrated design metrics.

Keccak is imported from `keccak_v2` at `fe54a78` and its standalone relocation
checks pass. NTT is imported from `ntt_v2` at `577a34b` with its standalone
UVM,reference,simulation,Quartus and documentation assets. Complete encoded
KeyGen/Sign/Verify now pass the fresh Stage6 official-output suites in the
full-operation configuration. Whole-main UVM/PPA is next in Stage7.
The active four-bank memory supersedes the preserved Stage3 scalar pool.
See SPECIFICATION.md for exact snapshot provenance.

The user has approved this structure and incremental import approach and has
authorized incremental integration. Ask before major architecture decisions,report what
was done and verified at each stage,and always state the next step. Do not
commit or push subsequent work without an explicit request.

## 2. Agreed folder structure

```text
src/
  keccak/                         # Keccak RTL, imported when needed
  ntt/                            # NTT/INTT/PWM/Pre-NTT RTL
  sampler/                        # Accepted sampler RTL
  controller/
    memory.sv                     # Active four-bank ownership/packing controller
    keygen.sv                     # KeyGen scheduling;polynomial phase implemented
    sign.sv                       # Planned Sign FSM,added when implemented
    verify.sv                     # Planned Verify FSM,added when implemented
    dilithium.sv                  # Main operation FSM
    process/                      # P2R,Decompose x4,CNB,Mhint,Bitpkg,etc.
    memory/                       # Four-bank/BRAM implementation primitives
    datapath/                     # Shared Keccak/sampler/NTT/row connections
    helpers/                      # Seed collection and row command scheduling
    legacy/                       # Preserved older scalar-pool regression helpers

tb_uvm/
  tb_uvm_reusable/                 # Shared reusable verification components
  <individual module UVM folders>/
  tb_uvm_dilithium/                # Full Dilithium UVM, when that stage begins

tb/
  tb_dilithium/                    # Focused integration testbenches as needed

sim/
  keccak/                         # Individual Keccak simulation
  ntt/                            # Individual NTT simulation
  sampler/                        # Individual sampler simulation
  dilithium/                      # Evolving full-design simulation project

quartus/
  keccak/                         # Individual Keccak synthesis project
  ntt/                            # Individual NTT synthesis project
  sampler/                        # Individual sampler synthesis project
  dilithium/                      # Evolving full-design synthesis project

docs/
  keccak_docs/                     # Imported module documentation/evidence
  ntt_docs/                        # Imported module documentation/evidence
  sampler_docs/                    # Existing module documentation/evidence
  dilithium_docs/                  # Universal full-design documentation
    DILITHIUM_PLAN.md
    ...
```

Use the spelling `controller` consistently. `dilithium.sv` is the main
controller/top. Operation FSMs live beside it;shared helpers use the subfolders
above. All processing arithmetic and formatting belongs under
`src/controller/process/`. Sign/Verify and remaining process files are added
with working logic at their implementation steps. Additional files must have a
clear purpose rather than forcing an entire subsystem into one large file.

Testbench source belongs in `tb/` or `tb_uvm/`, RTL in `src/`, launchers and
generated simulation output in `sim/`, and synthesis projects in `quartus/`.
Create folders and runnable scripts when used; do not create empty test launchers.

## 3. Import an individual module as a complete package

Bring modules in as integration reaches them. Each import includes:

1. The selected accepted RTL and required ROM/table/initialization files.
2. Its existing UVM testbench and independent reference/checking assets.
3. Its standalone simulation launchers and required vector/reference files.
4. Its standalone Quartus project, constraints and synthesis helper scripts.
5. Its module documentation and relevant accepted evidence.

Keep standalone module verification and synthesis runnable on this branch.
Retain each module's existing UVM folder name unless an actual naming conflict
requires a documented change. Map imported RTL to `src/keccak/` and `src/ntt/`,
and update file lists, relative paths, include paths, ROM paths and project
assignments. Check for package/module/library collisions before compiling all
three together. Re-run the relevant standalone checks after relocation.

Record branch, commit, original paths, destination paths, changes and verification
in the shared Dilithium specification. Preserve frozen imported evidence exactly;
its historical paths and standalone metrics describe the original build. New
verification records must identify the relocated build separately.

Do not merge whole branches or import historical experiment trees and obsolete
generated databases merely to obtain a module. Preserve the accepted branches.
The evolving `sim/dilithium/` and `quartus/dilithium/` projects must use the current
combined source set as each part is added.

## 4. One documentation set for all integration milestones

All integration work updates **the same documents in `docs/dilithium_docs/`**.
A Keccak-to-sampler milestone and a later memory-to-NTT milestone are sections
of these documents, not separate documentation suites. Individual imported
module documentation remains under its own module folder for standalone use.

| Document | Contents and when to create/update it |
|---|---|
| DILITHIUM_PLAN.md | This roadmap, agreed structure, stages, current status and next work |
| README.md | Navigation, actual simulation/synthesis commands and current supported scope |
| SPECIFICATION.md | Supported algorithm/version/parameters, exact imported snapshots, ports, reset/clock and command contracts |
| ARCHITECTURE.md | Datapath, controller, adapters, routing and memory connections |
| PROCESS_FLOW.md | Step-by-step data movement, scheduling and eventual KeyGen/Sign/Verify sequences |
| PROCESS_BLOCKS.md | Purpose,math,representations,interfaces,status and verification of arithmetic/rounding/hints/norms/packing/hash-format blocks |
| MEMORY_MAP.md | Polynomial layout, banks/ports, allocation, addresses, lifetimes, ownership and arbitration |
| INTEGRATION_VERIFICATION_TESTPLAN.md | Full-design requirements, independent checking, tests and later detailed UVM/coverage plan |
| THROUGHPUT.md | Measurement boundaries, cycles, stalls, loading/compute/output time, system throughput, placed ALMs, Fmax and slack |
| COVERAGE.md | Functional/code coverage, bin-hit justification, observed gaps and implementation-verification scope |
| PIN_CONFIG.md | Full-design top-level virtual pins, widths and meaning; physical assignments only when actually selected |
| REFERENCE_VERIFICATION.md | Reference provenance, vectors, file formats, preparation/capture/comparison commands and measured results |

Create each document when its work becomes concrete and maintain it throughout
the project. Do not fill documents with invented results or runnable placeholders.
Separate proposed targets, standalone historical metrics and measured system data.
Store only useful milestone evidence; avoid a new JSON/archive for every small trial.

## 5. Initial architecture and interface decisions

The starting datapath is:

```text
Commands / seeds / messages
             |
    dilithium.sv controller
      | scheduling / memory ownership / error handling
      v
 Keccak -> Sampler -> Polynomial memory <-> NTT/INTT/PWM/Pre-NTT
                            ^
                            |
                  controller/process blocks
```

This is a starting structure; finalize the detailed contracts before wiring it.

- Keep Keccak's shared 64-bit input and tagged 128-bit output interfaces.
  The current sampler accepts 128-bit beats and processes ordered 64-bit chunks
  internally. This does not become native128 sampling merely through connection.
- Associate the sampler job with Keccak's actual accepted core assignment.
  Maintain the complete job ID, sampling mode, parameters, seed/nonce and
  destination. A core/context number alone is not a permanent polynomial ID.
- Define continuous SHAKE operation, sampler completion/stop requests,
  already-offered output handling and safe context reuse. Finite-source handling
  must not repeat SHAKE prefixes, insert zero padding or silently truncate data.
- Resolve reset conventions at the top level. Preserve each module's defined
  reset behavior and verify cancellation, draining and subsequent fresh work.
- Keep canonical 23-bit residues at the current sampler/NTT boundary. Check
  transform ordering, modular representation and scaling explicitly when
  comparing software; do not equate an intermediate Montgomery representation
  with canonical coefficients without the required conversion.
- Matrix A sampling already produces transform-domain values. Route them to
  operand storage/PWM, not through an unnecessary forward NTT. Ordinary secrets
  can use forward NTT or the existing eligible Pre-NTT operation. Assign one
  owner for Pre-NTT so its first stage is never applied twice.
- Use one shared clock initially, with an operating target selected from the
  imported modules' constraints and actual integrated timing. Standalone sampler
  Fmax is not an integrated Fmax guarantee.

### Memory decisions to settle before implementation

The sampler can interleave two jobs; the current NTT wrapper handles one complete
operation at a time and transfers one 23-bit coefficient per beat. Use memory
to separate polynomial ownership and production/consumption schedules.

Define 256-coefficient polynomial storage, coefficient addresses, domain metadata,
slot allocation and states such as free/writing/complete/in-use. Set the actual
bank/slot count from the first workload and expected live ranges. Do not invent
a large all-parameter memory allocation before deriving capacity and port demand.

Mark a sampled polynomial usable only after successful completion. Invalidate
partial results on errors/abort. Track both PWM operands, writeback ownership,
simultaneous read/write hazards and reset/reuse. Preserve input polynomials still
needed by later operations. Add ping-pong storage or more ports when measurements
justify them. Wider NTT ports and deeper queues are later measured changes.

## 6. Execution stages and completion gates

Announce the stage before starting it. Work in bounded steps and update these
universal docs after each meaningful milestone. A passing subset must not be
reported as complete Dilithium or complete verification.

| Stage | Work | Evidence required before moving on |
|---|---|---|
| 1 — Contracts and imports | Inspect accepted snapshots, import Keccak with its standalone assets, define commands/reset/tags and initial memory contracts | Relocated standalone checks pass; interface and source provenance documented |
| 2 — Keccak + sampler | Feed real SHAKE outputs into all four sampling modes; handle two contexts, stop/drain, valid bytes and backpressure | Seeded polynomial outputs match independent expectations; ordering, context reuse, reset and errors checked |
| 3 — Memory | Implement memory.sv, allocation, write/read paths, completion validity and arbitration | Exact polynomial readback; no mixing, overwrite, stale reuse or premature reads under stalls/abort |
| 4 — NTT integration | Import accepted NTT with all standalone assets; connect load/command/result paths through memory | Sampled/transformed outputs and polynomial operations match software with explicit domain/scaling conventions |
| 5 — Controller and remaining processes | Build dilithium.sv scheduling and required process blocks; begin with sequential operation schedules | Each added process and full supported flow produces independently checked outputs; rejection/retry and error handling exercised |
| 6 — Full-operation reference/NIST flow | Complete the supported KeyGen/Sign/Verify interfaces and file-based capture/comparison | Exact official-vector comparisons for the declared algorithm/parameter/mode; limitations and unsupported cases explicit |
| 7 — Full UVM and synthesis optimization | Build comprehensive Dilithium UVM/coverage, synthesize the whole design and improve timing/area/throughput | Correctness retained; detailed functional/code coverage and honest gaps; fresh measured PPA and positive timing at the agreed operating clock |
| 8 — Implementation and FPGA verification | Verify distinct whole-design synthesis/fit netlists, then board interfaces and hardware testing | Implementation checks and timing reports; FPGA results only after actual execution |

The remaining processing work includes polynomial add/subtract, matrix-vector
accumulation, rounding/Power2Round, decomposition, norm checks, hint creation/use,
packing/unpacking, signing rejection/retry control, and seed/nonce/message/key
handling. Define and verify the exact required subset as each algorithm flow is
implemented. Three connected engines alone do not implement all these functions.

### Testing during integration

Focused, efficient non-UVM integration testbenches are explicitly allowed.
Use them to supply real jobs, exercise boundary conditions, dump outputs and
compare with independent models. They must be self-checking and reproducible.
They do not replace the imported standalone UVM suites or justify later full
UVM coverage claims. Keep focused testbench source under `tb/tb_dilithium/`.

After one connection produces the required outputs, add the next block and
repeat independent checking. Start with serial schedules to make faults easy
to locate. During the later optimization stage, overlap sampling, arithmetic
and memory traffic only with ownership/dependency checks and measured benefit.

The full-fledged Dilithium UVM campaign and primary PPA optimization follow
correct end-to-end outputs and the full-operation reference/vector milestone.
Earlier compile/synthesis checks may establish feasibility, RAM inference and
resource limits; they do not imply that full verification or optimization is done.

### Full-operation vector flow

Use the same explainable pattern as Keccak: input vectors -> RTL execution ->
captured outputs -> a separately executed Python comparison command -> explicit
PASS/FAIL with case counts and mismatch details. Keep the reference independent.

At that stage obtain official NIST/ACVP full-operation vectors and record exact
source/version/provenance. The user selected final FIPS204 ML-DSA-44/65/87,
retaining level2/3/5 names (parameter encodings0/1/2). Define exact
message/context formatting and supported operation interfaces. Never silently
mix incompatible vectors or assume legacy reference code is a full FIPS oracle.
Control the specified seed/randomness inputs for exact randomized-operation
comparisons; verification vectors require correct accept/reject outcomes too.

Do not claim official standalone sampler or NTT vectors. Their existing
FIPS-derived/reference checks remain useful component evidence. Full-operation
vector equality is not itself NIST validation or certification.

### Later full UVM, synthesis and optimization

Define the complete feature/test/coverage plan, then exercise modes/parameters,
command sequences, queues, memory hazards, concurrent jobs, stalls, invalid
requests, reset/abort/recovery and signing retries. Credit successful functional
observations only after independent checking. Report raw and averaged coverage
metrics clearly; do not fabricate bins or suppress hits to impose a percentage.

Measure full command-to-completion latency and sustained completion interval,
SHAKE/sampler waiting, memory occupancy/conflicts, NTT load/compute/output and
controller overhead. Report actual placed ALMs, registers, RAM/DSP, worst Fmax,
constraint and worst-corner setup/hold/TNS. Standalone virtual-pin closure is
not board I/O closure. Preserve correctness while improving measured bottlenecks.

The full design will have three main `.do` launchers when implemented: source
UVM with GUI/waves/functional and code coverage, post-synthesis, and post-fit.
Focused early tests can use selectable modes or supporting Tcl/scripts in the
same `sim/dilithium/` project. Use supported vendor functional netlists and
TimeQuest timing evidence; do not promise unsupported Cyclone V SDF simulation.

## 7. Next action and status tracking

**Active Stage5H:reusable row multiply/accumulate scheduler PASS.**
row_accumulate plus keccak_sampler_row schedule one complete staged matrix row
through the single existing NTT/process/bank subsystem. Source descriptors cover
4/5/7 columns at levels2/3/5. Sources are validated/leased before any arithmetic.
First PWM writes the accumulator;later PWMs use one reusable scratch region,
followed by explicit destructive ADD back into the same accumulator. Scratch
is released after each addition. The final inverse NTT produces coefficient-
domain u_i=(A*s1)_i;the accumulator is then released for the next row. Retained
matrix/secret operands are not overwritten. No new polynomial RAM or engines.

The new process_inplace_i flag is explicit and defaults to0 in existing tests.
The store permits private reads only beyond the rewritten coefficient frontier;
both source words are cached before any lane is overwritten. A reset invalidates
the partially rewritten accumulator. This supersedes the earlier distinct-result-
only limitation;the ordinary process/P2R commands retain their existing behavior.

Source/Python/C PASS:13 completed rows,27 expected rejections,7 reset aborts;
163 real SHAKE/sampling jobs,161 NTT/Pre/PWM/INTT commands,55 in-place additions.
96264 scalar writes,24066 packed writes/acks,12544 exact92-bit public readbacks
and6918 old-word cache reads are checked. Six full reference rows also agree
with independent coefficient-domain schoolbook multiplication.26 deliberate
capture corruptions are rejected. Stored transformed secrets are reused across
two different matrix rows per level;eligible secrets exercise Pre-NTT too.
All ten earlier source gates and checker selftests freshly PASS. Create-only
evidence:evidence/stage5h_row.zip and stage5h_row.sha256;earlier archives remain
unchanged. Member hashes/bytes and archive CRC are verified.

Use selector5/row and Python --stage 5 --unit row. The default/Quartus top remains
the preserved scalar baseline;no new PPA or full-system UVM result. Next bounded
step:connect shared seed expansion and seed/nonce message formatting to the
KeyGen sampling schedule,then add s2 to each u_i,Power2Round and final key byte
encoding/reference comparison. Full KeyGen output is still unimplemented.

**Prior Stage5G:banked ADD/SUB/Power2Round and NTT chains PASS.**
poly_process_dma shares the existing four banks through the optional
PROCESS_SERVICE=1 path in keccak_sampler_ntt_banks. Sampling,NTT and processing
have exclusive sequential ownership. ADD/SUB require matching domains/parameters;
Power2Round requires coefficient domain. Source leases and explicit destination
checks apply throughout. Power2Round writes canonical low modulo q and high
into two distinct caller-selected regions,using the two existing packers.
Both outputs become visible together after acknowledged commit;both remain
protected while their completion is held. No extra polynomial payload RAM.

23 actual sample jobs,15 NTT commands and71 process commands pass:34 process
successes,33 expected rejections and4 reset aborts. Python and C independently
match8976 completed arithmetic results from8978 accepted process inputs.
The full ledger checks22297 scalar writes,5574 packed writes/acknowledgements
and8512 exact92-bit readbacks. Stored canonical low parts feed real forward NTTs.
Twenty-nine checker corruptions are rejected,including missing high-part commit
and partial-publication evidence. See REFERENCE_VERIFICATION.md for execution.
All nine earlier source gates/checker selftests are freshly revalidated. Frozen
evidence:evidence/stage5g_bank_process.zip and stage5g_bank_process.sha256,
with create-only archive/checksum writes and verified per-member hashes.

Use selector5/bank_process and Python --stage 5 --unit bank_process. The legacy
default4/Quartus top and all earlier selectors remain available;PROCESS_SERVICE
defaults to0 for the preserved banked NTT-only test. No full KeyGen,NIST/UVM
coverage or new PPA result is claimed. Next bounded step:row multiply/accumulate
scheduling over the verified PWM/ADD/INTT path,then connect real seed/nonce
formatting and key encoding in the first level2 KeyGen controller. Functionality
remains first;no new timing campaign is authorized by this milestone.
Stage5H above adds explicit destructive row accumulation and the first row
reuse schedule. Full KeyGen/Sign phase lifetimes remain to be derived/verified.

**Prior Stage5F:real sampling -> four banks -> NTT -> four banks PASS.**
keccak_sampler_ntt_banks adds sequential word DMA and result packing around the
unchanged NTT engine. Each92-bit read supplies four23-bit engine beats;PWM loads
A then B. Accepted source leases block release through completion retirement.
Caller-selected destination must differ from the sources;an occupied destination
waits while unrelated regions can be released. Completion waits for all256 results,
64 physical write acknowledgements and engine completion. A held result cannot
be released before its completion handshake. No new hash/NTT cores are added.

16 real sample jobs and54 compute commands pass:30 results,21 expected rejections
and3 reset aborts. Independent Python checks4096 sample coefficients,9746 DMA
values,7712 NTT outputs,2952 packed writes/2951 acknowledgements and2944 exact
92-bit readbacks. Same/different-bank operands/destinations,all four banks,
all four operations/three parameters,round trips,source preservation,Pre bounds,
ID/domain/parameter/alias errors,occupied destinations and reset recovery pass.
Nineteen deliberately corrupted captures are rejected. These are focused source
checks,not full-operation NIST,UVM coverage or new synthesis/PPA results.
All eight earlier focused gates and checker selftests were freshly rerun PASS.
Create-only evidence:evidence/stage5f_bank_ntt.zip and stage5f_bank_ntt.sha256;
preserve the earlier checkpoints unchanged.

Run selector5/bank_ntt and Python --stage 5 --unit bank_ntt,as documented in
REFERENCE_VERIFICATION.md. Default selector4 and the Quartus top remain the
preserved scalar baseline;the banked full connection has its own explicit selector.
Stage5G above connects bank reads/writeback to modular ADD/SUB/Power2Round.
Next:build row accumulation and the first level2 KeyGen schedule around the
verified hash/seed service. Full key encoding and whole-operation comparison
remain required. Optimize PPA after functionality,as already agreed.

**Prior Stage5E:real sampling -> packed banks -> protected readback PASS.**
keccak_sampler_banks connects the existing producer to bank_poly_store and the
four banks. The caller selects aligned bank/region destinations;two packers
keep contexts separate. Publication waits for256 coefficients,64 write acks
and successful external status. Reads/releases check committed ownership and
hold metadata through stalls.104 jobs pass:88 complete,8 expected errors,
8 reset aborts;5632 exact92-bit words=22528 completed coefficients read back.
All64 regions/24 core-mode-parameter combinations,occupied-region stalls,
reuse and reset recovery are covered. Eight malformed write/status fault kinds
are contained;12 capture corruptions rejected. No new PPA/UVM coverage claim.
All seven earlier gates were freshly rerun with passing checker selftests.
Preserved evidence:evidence/stage5e_bank_store.zip plus its create-only SHA256
sidecar;115 manifest/member bytes verified. Keep earlier archives unchanged.

Stage5F above completes NTT word-read DMA,source leases and packed result
writeback. The preserved sampling-only gate remains selector5/bank_store.
No full KeyGen/controller/process migration is claimed by the storage gate.

**Prior Stage5D:LightHD memory selected;four-bank foundation PASS.**
The user answered the storage question:"whatever LightHD is doing do that".
Adopt the paper's four logical1024x92-bit dual-port banks,retained secret data
and row-by-row temporary reuse. This supersedes both scalar-pool proposals;
do not automatically add their extra encoded-key buffers. Final FIPS204 bytes
with level2/3/5 names stay selected. MEMORY_MAP.md now gives the published
dimensions,Figure2 peak Sign regions,and the migration boundaries.

poly_bram.sv/memory_banks.sv pass14872 requests,9509 exact92-bit reads,5355
write acknowledgements,8 reset-aborted acknowledgements and12 checker faults.
All4096 words are covered,with independent ports,collisions,stalls and reset
retention. This is the bank foundation only;the Stage4 top remains on its old
four-slot pool pending migration. No new physical RAM/PPA result is claimed.

**Prior Stage5C:shared raw-SHAKE and seed collection source/reference PASS.**
The existing keccak_sampler now supports optional finite raw hashes through the
same two physical cores. keygen_seed_collect retains rho/rho-prime/K until
accepted. The focused gate passes26 commands,1699 exact SHAKE bytes and1792
coefficients sampled from RTL-collected seeds. Twelve checker corruptions are
rejected. Both raw/raw and raw/sampling ownership,stalls,arbitration,rate-boundary
short beats and three reset/recovery cases are checked. Main Stage4 wrappers
explicitly disable the optional route;no public port/capacity changes yet.
PROCESS_BLOCKS.md now specifies implemented/planned processing blocks;
MEMORY_MAP.md contains a dimensioned implemented memory diagram and the concrete
next KeyGen storage decision,now resolved in favor of LightHD's four banks.

**Prior Stage5B:final FIPS204 selected;KeyGen message formatter PASS.**
The audit found a mismatch between LightHD's displayed32-byte tr and our local
software's final-format64-byte tr,parameter-bound seed expansion and level-
dependent challenge lengths. The user resolved this on2026-10-20:implement
final ML-DSA-44/65/87 with LightHD-style level2/3/5 names. Keep parameter
encodings0/1/2. SPECIFICATION.md records the mapping and audit;legacy round-3
byte compatibility is not implied by those labels.

keygen_hash_message.sv now builds the final-standard seed-expansion,matrix and
KeyGen-secret messages. Focused real-Keccak/Python checks pass165 commands,
162 completions(including14 expected errors),3 reset aborts,883 absorption words
and5888 SHAKE bytes. All102 matrix positions and34 secret nonces are exercised.
Twelve checker corruptions are rejected. The formatter is not yet connected
to the Stage4 main top;shared raw hash/seed collection now pass Stage5C above.

Independent common arithmetic was implemented under src/controller/process:
modular ADD/SUB and Power2Round.10349 accepted cases/10346 outputs/3 reset aborts/
13 expected errors PASS,with12 checker corruptions rejected. The unchanged C
Power2Round reference passes all8380417 canonical inputs;RTL uses targeted
boundaries/random cases,not an exhaustive8.3-million-value simulation.
Stage5G above now connects the unit to memory;no full KeyGen output is claimed.
Preserved evidence:evidence/stage5a_process.zip and stage5a_process.sha256.
The archive records the pending format/architecture choices explicitly;it is
not a completed Stage5 checkpoint. Earlier Stage2/3/4 regressions were refreshed.

Next:extend the verified banked NTT/process path with shared hash scheduling,
row accumulation and key encoding in the first
level2 controller. The old four-slot/ten-slot plans are superseded. Do not
duplicate Keccak cores or claim LightHD's32-cycle input loading through the
current scalar NTT wrapper. PPA optimization remains deferred.

**Prior milestone:Stage4 NTT integration functional PASS;PPA deferred.**
The real path is Keccak -> sampler -> four-slot memory -> NTT -> memory.
The imported six NTT RTL files and existing UVM remain byte-identical to
ntt_v2:577a34b2fff19864cb16b490b7629ed211613000;path adapters and original/destination
hashes are in ntt_import_manifest.csv. Relocated standalone checks pass748 UVM
jobs/191488 coefficients and18 Python cases/4608 coefficients. These are source
checks;no fresh relocated synthesis or netlist simulation was run.

Focused integration checks16 sampled jobs and50 NTT commands:30 complete,
17 rejected and3 reset-aborted.4096 sampled values,9745 DMA operands,7713 NTT
outputs (7680 complete+33 aborted-prefix values) and11776 stored readbacks match
independent Python expectations. All4 operations,all3 parameter encodings,
source retention,Pre eligibility,domain/ID checks,full-pool waiting,stalls and
reset/recovery at load/compute/writeback pass.12 checker corruptions are rejected.
Stage2/3 remain selectable and independently checked. There is no Stage4 PPA,
full-system UVM,full-operation official-vector or FPGA claim.
Frozen Stage4 source/import/capture evidence:evidence/stage4_subsystem.zip and
stage4_subsystem.sha256. Its manifest distinguishes unchanged imported RTL/UVM,
path adapters and the new integration helper/memory extension.

Stage5 follow-up:the user selected final FIPS204 bytes with level2/3/5 labels;
derive the first level2 KeyGen schedule and polynomial live ranges,then add
required arithmetic/rounding/packing blocks incrementally. Confirm major
algorithm/memory/interface decisions with the user. Do not begin PPA optimization.

**Prior milestone:Stage3 memory functional PASS;PPA optimization deferred.**
The user approved a configurable four-slot pool on2026-10-20. Real
Keccak-sampler outputs now write src/controller/memory.sv through
keccak_sampler_memory.sv.104 jobs pass:88 complete,8 expected errors,8 reset
aborts;23180 exact writes and22528 exact readbacks.88 releases,99 invalid reads,
full-pool backpressure and concurrent reads/writes pass.8 protocol fault kinds
are contained and12 checker corruptions rejected. Stage2 remains reproducible
and passes unchanged. No Stage3 fitted PPA or full-operation output is claimed.
Next:Stage4 accepted NTT package import and memory-to-NTT load/result control.
Frozen source/test/capture evidence:evidence/stage3_subsystem.zip and its
SHA256 sidecar. It contains no Stage3 fitted PPA claim.
Finalize ordering,scaling,representation and operand/destination lifetimes
before arithmetic comparisons. Read MEMORY_MAP.md for the implemented contract.

**Prior milestone:Stage2 functional PASS;148MHz timing target OPEN.**
The real Keccak+sampler helper is implemented under src/controller and exercised
by the focused testbench under tb/tb_dilithium.104 jobs pass:88 complete,
8 expected parameter errors,8 reset aborts,and23089 exact coefficient checks
on the current two-slot registered-credit bridge (trial8 functional source).
All24 mode/parameter/context combinations are observed;12 checker corruptions
are rejected. The user chose about148MHz as the initial combined synthesis
target:6.757ns. The first combined fit has11059 placed ALMs,129.18MHz Fmax,-0.984ns setup
and+0.166ns hold at that unchanged target;the148MHz goal is not met.
Original sampler structural guards pass. Evidence:evidence/stage2_subsystem_initial.zip.
Timing trials are recorded in THROUGHPUT.md. Trial6 cuts the measured sampler
stop/ready path into Keccak using a two-slot register queue;source checking
includes full-queue reset and simultaneous push/pop. The unchanged148MHz
target remains open until a fresh complete fit and structural guards pass.
Clean trial6c reached134.17MHz/-0.696ns at12542 placed ALMs. Active trial7
restores the smaller ordinary clock-enable mapping and predecodes absorb-ready
in each core. Source104 jobs/23089 values and full904-transaction Keccak+dual
regressions and6364-output NIST comparison pass;no added processing cycles.
Trial7 fit still misses at124.72MHz/-1.261ns,but area recovers to11204 placed
ALMs. Active trial8 removes sampler-ready gating redundant with ownership;
104 jobs/23089 values and12 checker faults pass,with identical cycle records.
The completed main seed1 fit reaches137.74MHz worst Fmax at11293 placed ALMs,
with-0.503ns setup and+0.157ns hold at6.757ns;structural guards pass.
Timing remains open and its optimization is deferred by the user's latest
decision. No further timing experiment is required before adding memory.
No polynomial memory,NTT connection,main algorithm controller or full-operation
NIST/UVM completion is claimed. See ARCHITECTURE.md,PROCESS_FLOW.md,
REFERENCE_VERIFICATION.md and THROUGHPUT.md.

**Prior milestone:Stage1 Keccak import and standalone revalidation PASS.**
Keccak RTL/UVM/vector/module-doc assets are imported,with original RTL/UVM
bytes preserved. Path adapters pass the904-transaction source suite plus dual
regressions,and all6364 captured outputs match3182 published NIST cases on
both cores. Fresh standalone Quartus:8058 actual placed ALMs,149.63MHz Fmax,
setup+0.074ns/hold+0.166ns at6.757ns. All four corners have zero setup/hold TNS.
These are standalone metrics from the prior import milestone.
Evidence:evidence/keccak_import.zip+SHA256.

Current source snapshot:keccak_v2 at fe54a782e3df9ed684dc960b0067b39ce323289d.
See SPECIFICATION.md for source provenance,path mapping and initial contracts.
Next:Stage5 controller/process work. Keep the verified functional source and accepted
standalone baselines. The four-slot memory proposal is approved and verified;
later major architecture changes still need agreement. The user selected LightHD's full CRYSTALS-Dilithium
scope:KeyGen,Sign and Verify at all three security levels2/3/5;bring up level2
first. Final FIPS204 was selected explicitly on2026-10-20;choose its official
NIST/reference vector suite. The paper's level names and draft-standard citation
alone do not establish final-byte compatibility. See the
algorithm-scope decision in SPECIFICATION.md. The initial clock is now6.757ns;
later major changes require user agreement.

| Milestone | Revision and workload | Result | Limitation / next action |
|---|---|---|---|
| Stage5L complete encoded KeyGen |8 complete C-reference keypairs,3 rejects,5 aborts |5433 exact key words,2058 PK hash words,656 tr bytes,11179 read metadata records;35 checker faults | Next:official NIST KeyGen vectors,then Sign;no new PPA/full-system UVM claim |
| Stage5K rounded KeyGen and Bitpkg |34 rounded rows;97 packet commands |190224 scalar values,12800 exact92-bit reads,36 rounded checker faults;2482 exact packed words,15 packer checker faults;C66 fixtures/18496 bytes | Next:bank-to-Bitpkg routing,full key field order and public-key hashing;external full-key interface pending |
| Stage5J autonomous KeyGen polynomial phase |14 operations;7 complete,3 rejected,4 aborted;34 t rows |172304 scalar values,8448 exact92-bit reads,29 checker corruptions;all levels/s1/s2/matrix rows | Next:P2R,Bitpkg,public-key hash and complete encoded keys;Sign/Verify remain unimplemented;no new PPA |
| Stage5I seed-driven rows |190 commands;20 seed expansions;163 RTL-formatted samples;13 successful rows |2560 exact SHAKE bytes,1103 absorption words,12544 exact92-bit reads;23 checker faults;all12 focused gates PASS | Command adapter connected;bench schedules work;all s2 nonces/full KeyGen controller and key bytes next;no new PPA claim |
| Stage5H row scheduler |163 samples;161 NTT commands;55 in-place ADDs;12544 exact92-bit reads | Source/Python/C PASS;13 rows,27 rejections,7 aborts;26 checker faults;6 schoolbook reference rows | Staged sequential rows,not full KeyGen;s2/rounding/key encoding and seed scheduling next;no PPA claim |
| Stage5G banked process arithmetic |23 samples;15 NTT commands;71 process commands;8512 exact92-bit reads | Source/Python/C PASS;34 process successes,33 expected rejections,4 aborts;29 checker faults | Sequential process DMA;row scheduling/full KeyGen next;no new PPA/coverage claim |
| Stage5F banked NTT connection |16 real sample jobs;54 compute commands;2944 exact92-bit reads | Source/Python PASS;30 results,21 rejections,3 aborts;19 checker faults | Sequential scalar engine DMA;banked process/row scheduling next;no new PPA/full KeyGen claim |
| Stage5E sampled polynomials in packed banks |104 jobs;5632 completed92-bit read words | Source/Python PASS;88 successes,8 errors,8 aborts;8 protocol faults contained;12 checker faults | Sampling/storage connected;NTT DMA and compute leases/writeback next;no PPA claim |
| Stage5D LightHD memory foundation |Four1024x92-bit dual-port banks;14872 requests | Source/Python PASS;9509 exact reads,5355 acks,8 reset aborts;12 checker faults | Foundation only;controller/DMA migration next;no RAM inference/PPA claim |
| Stage5C shared raw hash and seed collection |26 commands;18 raw requests;7 sampler jobs;1699 SHAKE bytes;1792 coefficients | Source/Python PASS;7 seed results including1 error,3 resets;12 checker faults | Optional route tested;main top unchanged;memory choice subsequently resolved to LightHD banks |
| Stage5B KeyGen message formatting |165 commands;883 absorption words;5888 real-Keccak output bytes | Source/Python PASS;102 matrix positions,34 secret nonces;14 errors,3 resets;12 checker faults | Isolated formatter;shared raw-hash routing/seed collection next;no main KeyGen/PPA claim |
| Stage5A shared arithmetic |10349 accepted arithmetic/framing cases;exhaustive C rounding reference | Source/Python/C PASS;10346 outputs,3 aborts,13 errors;12 checker faults | Not memory-connected;not exhaustive RTL rounding or full KeyGen |
| Stage4 NTT package and memory datapath |748 standalone UVM jobs;18 Python cases;16 integrated sample jobs/50 commands/11776 readbacks | Source/Python PASS;30 NTT results,17 rejections,3 reset aborts;12 checker faults | No Stage4 PPA/full-operation claim;next algorithm audit and Stage5 controller/process work |
| Stage3 polynomial memory |104 jobs;23180 write checks;22528 readbacks;8 injected memory faults;12 checker corruptions | Source/Python PASS;four slots,ownership,commit,read/release,reset/reuse | Historical memory gate without synthesis/PPA;NTT added in Stage4 |
| Stage1 Keccak package relocation | keccak_v2 fe54a782e3df9ed684dc960b0067b39ce323289d;904 source UVM transactions plus dual suites;3182 NIST cases per core;full standalone Quartus compile | PASS;RTL/UVM unchanged;6364 exact NIST matches;positive multicorner timing | No new netlist simulation or connected datapath. Next:Stage2 adapter and user-confirmed major decisions |
| Stage2 real Keccak-sampler source connection |104 generated subsystem jobs;88 complete,8 expected errors,8 aborts;23089 exact values;12 checker faults | Source/Python PASS;four reset phases,stop/drain,backpressure and same-ID recovery exercised | Current main fit11293 placed ALMs/137.74MHz/-0.503ns setup at6.757ns;structural guards PASS;timing optimization deferred;next Stage3 memory |

Maintain a concise milestone table here with the stage, source revision,
workload, explicit check result, measured limitations and next action. Keep the
same specification, process, memory, throughput and verification documents as
the system grows; do not start a parallel suite for each pair of modules.
