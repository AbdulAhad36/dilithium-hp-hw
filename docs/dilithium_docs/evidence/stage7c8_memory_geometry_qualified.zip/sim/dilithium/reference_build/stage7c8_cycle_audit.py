from pathlib import Path
import csv,json
from collections import defaultdict
from statistics import mean
here=Path('sim/dilithium');baseline=here/'reference_build/stage7c8_baseline_c7'
report=[];cycles=defaultdict(list)
for name,count in [('stage7c4_main_outputs.txt',210),('stage7c4_main_protocol_outputs.txt',88)]:
 old=(baseline/name).read_text().splitlines();new=(here/name).read_text().splitlines()
 assert new[-1]==f'F {count}',f'Incomplete capture {name}'
 assert old[1:]==new[1:],f'C8 capture differs beyond source token:{name}'
 report.append(f'{name}:ALL {len(new)-1} records after token exact C7,including every cycle')
 if count==210:
  for line in new[1:]:
   s=line.split()
   if s[0]=='J':op,p=int(s[2]),int(s[4])
   elif s[0]=='D':cycles[str((op,p))].append(int(s[8]))
for name in ['stage7_uvm_latency.csv','stage7_uvm_checked.csv']:
 old=list(csv.DictReader((baseline/name).open()));new=list(csv.DictReader((here/name).open()))
 if name=='stage7_uvm_checked.csv':
  assert all(r['source_token']=='8424f166c0efb7b95dffc2959c2e3eacbc2a58a8a58bbdeda38d1b969da365c9' for r in old)
  token=(here/'stage7_uvm_inputs.txt').read_text().split()[0]
  assert all(r['source_token']==token for r in new)
  old=[{k:v for k,v in r.items() if k!='source_token'} for r in old]
  new=[{k:v for k,v in r.items() if k!='source_token'} for r in new]
 assert len(new)==30 and old==new,f'C8 UVM rows changed:{name}'
 report.append(f'{name}:ALL30 rows and fields exact C7'+(';each original source token separately validated' if name=='stage7_uvm_checked.csv' else ''))
for key,values in cycles.items():report.append(f'{key}:n{len(values)} min{min(values)} max{max(values)} mean{mean(values):.2f}')
(here/'reference_build/stage7c8_cycles.json').write_text(json.dumps(cycles,indent=2)+'\n')
report.append('STAGE7C8_CYCLE_AUDIT_PASS:no extra command/cycle cost in complete native and main-UVM campaigns')
(here/'stage7c8_cycle_audit.log').write_text('\n'.join(report)+'\n')
print('\n'.join(report))
