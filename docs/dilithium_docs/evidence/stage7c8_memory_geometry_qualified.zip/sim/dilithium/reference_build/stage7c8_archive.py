from pathlib import Path
import hashlib,json,re,zipfile
root=Path.cwd();ev=root/'docs/dilithium_docs/evidence';here=root/'sim/dilithium'
name='stage7c8_memory_geometry_qualified';target=ev/(name+'.zip');side=ev/(name+'.sha256')
assert not target.exists() and not side.exists(),'Create-only checkpoint already exists'
# Every previous checkpoint is immutable and must verify before a new freeze.
prior=sorted(ev.glob('*.sha256'))
for s in prior:
 words=s.read_text().split();p=s.parent/words[1]
 assert hashlib.sha256(p.read_bytes()).hexdigest()==words[0],str(p)
base=ev/'stage7c7_decode_handoff_qualified.zip'
with zipfile.ZipFile(base) as z:
 names=z.namelist()
 paths={n for n in names if n.startswith(('src/','tb/','tb_uvm/','NIST/','FIPS204_'))}
 paths|={n for n in names if n.startswith('docs/dilithium_docs/')}
 paths|={n for n in names if n.startswith('quartus/dilithium/') and not Path(n).name.startswith('stage7c7')}
paths.add('AGENTS.md');paths.add('tb/tb_dilithium/tb_lighthd_memory_geometry.sv')
for name2 in ('README.md','dilithium_vectors.py','run.do','run_uvm.do','report_uvm_coverage.tcl'):
 paths.add('sim/dilithium/'+name2)
for pattern in ('stage7_uvm*','stage7c8*'):
 for p2 in here.glob(pattern):
  if p2.is_file() and p2.suffix in ('.txt','.csv','.rpt','.log','.ucdb') and 'console' not in p2.name:
   paths.add(p2.relative_to(root).as_posix())
for name2 in ('stage7c4_main_inputs.txt','stage7c4_main_outputs.txt','stage7c4_main_diagnostic_inputs.txt',
 'stage7c4_main_diagnostic_outputs.txt','stage7c4_main_protocol_inputs.txt','stage7c4_main_protocol_outputs.txt',
 'stage7c_ntt_inputs.txt','stage7c_ntt_expected.txt','stage7c1_ntt_dma_outputs.txt',
 'stage7c4_hint_inputs.txt','stage7c4_hint_expected.txt','stage7c4_hint_outputs.txt'):
 paths.add('sim/dilithium/'+name2)
for p2 in (here/'reference_build').glob('stage7c8*'):
 if p2.is_file() and p2.suffix in ('.py','.ps1','.do','.json'):paths.add(p2.relative_to(root).as_posix())
for p2 in (here/'reference_build/stage7c8_baseline_c7').glob('*'):
 if p2.is_file():paths.add(p2.relative_to(root).as_posix())
for name2 in ('stage7c8_compile.log','stage7c8_report_full.log'):paths.add('quartus/dilithium/'+name2)
files={n:(root/n).read_bytes() for n in sorted(paths)}
results=json.loads((here/'reference_build/stage7c8_results.json').read_text())
assert results['source_qualified'] and results['routed'],'Cannot archive incomplete candidate as qualified'
results['prior_archives_verified']=len(prior)
files['RESULTS.json']=(json.dumps(results,indent=2)+'\n').encode()
manifest={n:hashlib.sha256(data).hexdigest() for n,data in files.items()}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as z:
 for n,data in sorted(files.items()):z.writestr(n,data)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in manifest.items())
h=hashlib.sha256(target.read_bytes()).hexdigest()
with side.open('x') as f:f.write(h+'  '+target.name+'\n')
print(f'C8_ARCHIVE_CREATE_VERIFY_PASS:{len(files)}members/{target.stat().st_size}bytes/{len(prior)}prior SHA pairs;SHA256 '+h)
