from pathlib import Path
from statistics import mean
import json
h=Path('sim/dilithium/reference_build')
m=json.loads((h/'stage7c10_metrics.json').read_text());f=min(c['fmax_mhz']for c in m['corners'])
c10=json.loads((h/'stage7c10_cycles.json').read_text());c9=json.loads((h/'stage7c9r1_cycles.json').read_text())
rows=[]
for op in range(3):
 for p,level in enumerate((2,3,5)):
  key=str((op,p));cycles=c10['full'][key]['new_mean'];base=c9['full'][key]['old_mean']
  if op==2:
   cycles=mean(v[1]for v in c10['valid_verify'][str(p)]);base=mean(v[0]for v in c9['valid_verify'][str(p)])
  r=dict(operation=('KeyGen','Sign mean','Verify valid')[op],level=level,cycles=cycles,latency_us=cycles/f,operations_per_second=f*1e6/cycles,
   C8_baseline_cycles=base,C8_operations_per_second=55.53e6/base,throughput_gain_vs_C8_pct=100*((f/55.53)*(base/cycles)-1),
   throughput_gain_vs_C7_pct=100*((f/51.78)*(base/cycles)-1))
  rows.append(r)
(h/'stage7c10_throughput.json').write_text(json.dumps(dict(worst_fmax_mhz=f,reported_period_ns=1000/f,rows=rows),indent=2)+'\n')
print('|Operation|Level|Cycles|Latency us|Operations/s|Gain vs C8|')
print('|---|---:|---:|---:|---:|---:|')
for r in rows:print(f'|{r["operation"]}|{r["level"]}|{r["cycles"]:.2f}|{r["latency_us"]:.1f}|{r["operations_per_second"]:.1f}|{r["throughput_gain_vs_C8_pct"]:+.2f}%|')
print('These are latency-based sequential estimates at reported Fmax,not board measurements or initiation intervals.')
