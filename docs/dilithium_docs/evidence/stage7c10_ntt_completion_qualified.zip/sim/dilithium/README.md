# Dilithium simulation

## Active compact production flow (Stage7C.10)

Current source passes full210/protocol88/main33 UVM/negative. Geometry and
registered admission checks are separate focused benches;main UVM remains
the functional/code coverage source. The expanded NTT DMA bench deliberately
splits48 A/B renewals and checks retained ownership and all arithmetic outputs.
The initial failed C9 trial and the frozen-C8 counterexample remain diagnostic
evidence;neither is reported as a passed source campaign.

Main UVM,with GUI waves and functional/code summaries in the Questa Transcript:

```tcl
do sim/dilithium/run_uvm.do
```

Run `python sim/dilithium/dilithium_vectors.py uvm_prepare` first whenever
production RTL,UVM,synthesis source list or checker code changes. Main UVM
instantiates `dilithium_fpga`,which now selects the compact shared datapath.
Its `peak_bank_ports` CSV column counts actual occupied physical ports0..8.
Old allocator-equivalence mode belongs only to the historical7B design.

For the separate fast production capture,from the repository root:

```tcl
set DILITHIUM_STAGE 7
set DILITHIUM_TEST lighthd_main
do sim/dilithium/run.do
```

Then execute the independent comparison yourself:

```powershell
python sim/dilithium/dilithium_vectors.py lighthd_main_compare
```

Use `lighthd_main_diagnostic` for9 mixed official commands,and compare with
`lighthd_main_diagnostic_compare`. Use `lighthd_main_protocol` for88 error,
reset and cross-operation recovery commands,and compare with
`lighthd_main_protocol_compare`. These selectors capture outputs without
running the full UVM campaign. A capture-complete footer is not comparison
PASS;the separate Python command checks all published bytes/verdicts.
Only one process may mutate a given simulation work library at a time.


## Stage7C compact operation checks

These focused selectors exercise the compact controllers and actual shared
datapath. The production `run_uvm.do` now uses the compact main as well.
Focused operation checks do not create main-UVM coverage credit.

From the repository root, in the Questa Transcript:

```tcl
set DILITHIUM_STAGE 7
set DILITHIUM_TEST lighthd_sign_diagnostic
do sim/dilithium/run.do
```

The launcher prepares inputs through the same single Python, runs three fast
published cases (one per level), and sets up GUI waves. Compare separately:

```powershell
python sim/dilithium/dilithium_vectors.py lighthd_sign_diagnostic_compare
```

For the full90 official Sign cases, change the selector to `lighthd_sign` and
compare with `lighthd_sign_compare`. For69 error/reset/recovery scenarios use
`lighthd_sign_protocol` then `lighthd_sign_protocol_compare`. After both full
and protocol captures exist for current sources, run `lighthd_sign_selftest`.
KeyGen selectors are `lighthd_keygen` and `lighthd_keygen_protocol`, with the
matching `lighthd_keygen_compare` and `lighthd_keygen_protocol_compare` commands.
Run one selector at a time: each uses the same fixtures and capture filenames.

`stage7c3_sign_outputs.txt` is the RTL signature/attempt trace;
`stage7c3_sign_cycles.csv` is the per-phase clock ledger. Expected signatures
remain in pinned `NIST/ML-DSA-sigGen-FIPS204/expectedResults.json`. The Python
independently checks arithmetic traces and compares actual bytes to NIST.
GUI mode retains internal wave access and may run more slowly; batch mode
omits broad access while retaining every assertion and exact output check.

## Stage7 main UVM

At repository root run `python sim/dilithium/dilithium_vectors.py uvm_prepare`.
Then in the Questa GUI Transcript, cwd sim/, run `do dilithium/run_uvm.do`.
This uses the actual production top `dilithium_fpga`, with full KeyGen, Sign
and Verify hard-enabled, and the real UVM environment in
tb_uvm/tb_uvm_dilithium. Debug and ownership observations are internal probes;
the driver uses only production ports. Input and published expected files stay separate;
the scoreboard reads the expectations. GUI waves, functional/code panes and
both overall coverage summaries are opened/printed automatically.
Detailed rules, files, study diagram and coverage gaps are in the universal
docs/dilithium_docs/COVERAGE.md. Stage7A is the 33-scenario foundation campaign;
it is distinct from the broader verification/optimization work that follows.
The earlier run.do remains the focused integration/component launcher.

Stage6 official qualification uses the existing `run.do`: after Python
`prepare`, set `DILITHIUM_STAGE 5` and choose `DILITHIUM_TEST nist_keygen`,
`nist_sign` or `nist_verify` in the Questa GUI Transcript. Run the selectors
separately, then Python `compare --stage 5 --unit <selector>` and `selftest`
with the same arguments. All three instantiate the full-operation main
(FULL_KEYGEN=1, ENABLE_SIGN=1, ENABLE_VERIFY=1), printed as MAIN_CONFIG.
The suites contain 75 KeyGen, 90 Sign and 45 Verify cases respectively.
Each writes `stage5_<selector>_outputs.txt`; expectations and input fixtures
use the same stem. See the universal REFERENCE_VERIFICATION.md for complete
commands, mode exclusions and evidence. These focused benches precede the
full-system UVM and PPA stage.

Fresh Stage6 results: KeyGen75 matches 433600 published key bytes; Sign90
matches 310680 signature bytes; Verify45 matches 9 valid / 36 invalid verdicts
and 1328384 exact scalar writes / 26880 packed reads. Checkers reject 41/41,
152/152 and 158/158 corruptions. All three suites enable all operations and
share token 0d69fb8112a49d70fd4080a017e94538c64bf9ca0f3a59e372dc40e471b4a03a.
Raw run logs are stage6_nist_<operation>.log; comparison/checker logs keep the
stage5_nist_<operation> stem. Frozen evidence and manifest are in
docs/dilithium_docs/evidence/stage6_full_operation_qualification.zip +SHA256.

Whole main Verify:prepare with the same Python,then use
`set DILITHIUM_STAGE 5`,`set DILITHIUM_TEST full_verify`,and
`do dilithium/run.do` from sim/. Compare/selftest with
`--stage 5 --unit full_verify` at repository root. Files:
stage5_full_verify_inputs.txt and stage5_full_verify_outputs.txt. The118-case
main-top gate includes all45 official pure Verify verdicts,errors/resets and
actual mixed KeyGen/Sign. GUI waves expose main/child ownership and all three
frames. Detailed commands/results/provenance/study order remain in universal
docs/dilithium_docs/REFERENCE_VERIFICATION.md. Fresh118 scenarios pass:
23 valid Verify,60 invalid Verify,19 errors,14 reset/fault aborts,two mixed
operations. All45 official pure verdicts agree;170/170 checker faults reject.
Fresh Sign45 and KeyGen-only16 compatibility pass under the same fingerprint.

Verify equation component:prepare with the same Python,then select
`DILITHIUM_STAGE 5` / `DILITHIUM_TEST verify_equation` in the same DO.
Compare/selftest with `--stage 5 --unit verify_equation` at repository root.
Inputs/outputs:stage5_verify_equation_inputs.txt and
stage5_verify_equation_outputs.txt. The primary bench uses the real PK/SIG/
body prep chain,one services tree and shared banks. Waves show context take,
row/column,PWM/ADD/SUB/inverse,UseHint,packer,SHAKE and verdict cleanup.
Main op2 is still pending. Universal REFERENCE_VERIFICATION.md owns commands,
provenance,study order and final measured results. Fresh87 scenarios pass:
19 valid,35 cryptographically invalid,23 expected errors,10 resets/faults;
2104627 exact writes/49903 reads,966 UseHint units,172/172 checker faults
rejected. Fresh verify_math134 compatibility passes unchanged. Same final
fingerprint,all71 old RTL/SDC unchanged. Main Verify/op2 is next5V.4.

Verify math preparation:run the same Python prepare,then in Questa Transcript
from sim/: `set DILITHIUM_STAGE 5`, `set DILITHIUM_TEST verify_math`,
`do dilithium/run.do`. Compare/selftest at repository root with
`--stage 5 --unit verify_math`. Files:stage5_verify_math_inputs.txt and
stage5_verify_math_outputs.txt. This connects real PK/signature preparation,
third-frame mu hashing,challenge sampling and shared NTT/Pre-NTT. GUI waves
show context take,message/engine handshakes,scratch rotation and result leases.
Main Verify equation/verdict is still pending. The universal reference doc
contains original-vector provenance,commands,results and study order.

Fresh verify_math gate:134 scenarios,65 transformed contexts,57 expected
errors,12 reset/fault aborts;236834 exact writes/84099 reads;848 NTT commands
including68 Pre-NTTs;112/112 checker corruptions reject. Fresh earlier
verify_prepare133-scenario capture/compare passes. Next5V.3:Verify equation,
UseHint and w1/challenge comparison. All70 prior RTL and the SDC stay unchanged.

Verify input preparation:use the same Python prepare,then Questa Transcript
`set DILITHIUM_STAGE 5`, `set DILITHIUM_TEST verify_prepare`, `do dilithium/run.do`
from sim/. Compare/selftest using `--stage 5 --unit verify_prepare` at repo root.
The inputs/outputs are stage5_verify_prepare_inputs.txt and
stage5_verify_prepare_outputs.txt. GUI waves include PK fork credits,bank
services,headers,raw hash progress and context handoff. This tests real PK/SIG
bank loading and tr hashing;it does not implement main RTL Verify/op2.
Universal REFERENCE_VERIFICATION.md owns commands,results and study order.

Fresh gate:133 scenarios,49 prepared contexts,73 expected errors,11reset/fault
cases;360545 checked writes/61827 reads;87/87 checker faults reject. Shared
SK-load138,full KeyGen16 and actual main Sign45 compatibility scenarios pass.
Next5V.2b consumes ctx||M and prepares mu/challenge/NTT;main op2 is not ready.

Verify decoder component:prepare with the same Python below,then select
`DILITHIUM_STAGE 5` / `DILITHIUM_TEST verify_decode` in the same .do. Compare
and selftest with `--stage 5 --unit verify_decode`. Files are
stage5_verify_decode_inputs.txt and stage5_verify_decode_outputs.txt. This
checks383 decoding/framing/reset scenarios,not main RTL Verify. The official
Verify audit/software verdicts and the approved future three-frame interface
are documented in the universal REFERENCE_VERIFICATION.md/DILITHIUM_PLAN.md.

Official NIST pure Sign gate:use the same commands below with `nist_sign`
instead of `full_sign`. Preparation writes stage5_nist_sign_inputs.txt,
stage5_nist_sign_expected.txt and a360-case audit CSV. Questa uses the same
actual main-top bench and writes stage5_nist_sign_outputs.txt. Python compares
all90 selected signatures directly with NIST's published bytes.45 deterministic
and45 randomized cases cover levels2/3/5. The270 prehash/internal-API cases are
explicitly unsupported,not passed. See the universal REFERENCE_VERIFICATION.md
for pinned provenance,mode definitions,study order and measured results.

Fresh official results:90/90 signatures/310680 bytes match;152/152 checker
corruptions reject. The observed batch simulation took47m54s on this machine;
this is simulator wall time with deliberate stalls,not hardware latency.

Actual main Sign and shared KeyGen/Sign ownership gate:

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST full_sign
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit full_sign
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit full_sign
```

The45-case gate writes stage5_full_sign_outputs.txt from the actual main top.
Inputs:stage5_full_sign_inputs.txt. Expected software bytes:
stage5_full_sign_expected.txt,never supplied to RTL.21 complete signatures,
one mixed KeyGen,14 expected errors and9 aborts pass;196 checker mutations reject.
The main uses the approved SK frame then ctx||M frame. Both restart index0.
Output is provisional until matching successful main completion. The one Python
builds unchanged C Sign/Verify references;these are local fixtures,not official
NIST signature-output vectors. Official Sign vectors and main Verify are next.
For compatibility,use full_keygen or rounded_keygen with this same .do.

Complete signature-encoding gate (real key preparation+attempt/retry path):

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_encode
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_encode
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_encode
```

Inputs:`stage5_sign_encode_inputs.txt`;actual output:
`stage5_sign_encode_outputs.txt`.24 scenarios include7 complete signatures,
9 errors and8 aborts. Successful output is provisional until code0. All levels
use final FIPS204 bytes under labels2/3/5. Expected signatures are local C/Python
reference results,not official NIST signature vectors. Main Sign/Verify host
dispatch remains open. Use selectors bitpkg/full_keygen for compatibility;
all selectors use this one .do and Python. Universal docs have the study guide.

Automatic attempt/retry gate:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_retry
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_retry
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_retry
```

Files use stage5_sign_retry_* names. This gate streams ctx/message once,
retries real rejected candidates with the retained private seed,and checks
actual SHAKE/mask data,nonce limits,ownership and final z/hints/ctilde.
No encoded signature/main Sign completion is claimed. Universal reference
documentation explains the files,study order,results and remaining work.

Norm/hint candidate gate(use the same single Python and DO launcher):

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_accept
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_accept
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_accept
```

Inputs/capture/compare/checker logs use stage5_sign_accept_* names here.
Python mathematical HighBits/C norm-MakeHint agreement is in
stage5_sign_accept_c_reference.log. Details,limits and study order are in
docs/dilithium_docs/REFERENCE_VERIFICATION.md. Normal rejection preserves
mu/seed/nextnonce for retry;this is not yet full signing/signature encoding.

Response products gate:

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_products
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_products
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_products
```

Python creates stage5_sign_products_inputs.txt;Questa writes _outputs.txt.
Comparison checks every shared PWM/INTT/ADD-SUB write,final z/r0/w1/ct0,
retry headers and ownership/cleanup. sign_products_setup.sv prepares the real
upstream chain using one services tree. Python's sparse schoolbook oracle is
cross-checked with unchanged C through a test-only adapter. No full signature
or norm/hint/retry acceptance is implied. Universal docs contain the results.

Ownership/challenge-transform gate:

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_transform
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_transform
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_transform
```

Python generates stage5_sign_transform_inputs.txt with source SK/message/rnd
and test controls. Questa writes _outputs.txt;Python checks exact chat,retained
sources,ownership/release order and recovery. The same script builds the C
poly_challenge/poly_ntt adapter. GUI waves include both take handshakes and
the new helper's state/owned mask. Selector sign_challenge retains its prior
flow with take disabled. Universal docs contain contracts and measured results.

Challenge gate uses the same single launcher/script:

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_challenge
do dilithium/run.do
```

```powershell
# Repository root,after simulation finishes
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_challenge
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_challenge
```

Python creates stage5_sign_challenge_inputs.txt with source SK,message,rnd,
nonce and test controls. Questa writes stage5_sign_challenge_outputs.txt
from the actual connected clients. Python compares packed w1,absorbed hash
bytes,ctilde,c and retained sources. The C adapter independently checks six
expected-value fixtures. These are local FIPS-derived signing intermediates;
the SK inputs are published KeyGen vectors,not official signature vectors.
Use selector bitpkg to run the extended136-case shared-packer regression;
use full_keygen for the local full-KeyGen regression. See universal
docs/dilithium_docs/REFERENCE_VERIFICATION.md for results and study pointers.

Matrix/decomposition gate uses the same single launcher/script:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_matrix
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_matrix
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_matrix
```

stage5_sign_matrix_inputs.txt is generated by Python;_outputs.txt is captured
from the actual retained-key,mask,matrix and shared-services chain. GUI waves
show the workspace plan,row/column progress,service requests and private
result handles. Independent Python/C expectations are local FIPS-derived
intermediates;the three SK inputs come from the existing official KeyGen
corpus. This is not an official sigGen or complete signature test. Full counts,
contracts and study flow are in universal docs/dilithium_docs documents.

Latest hash/mask-vector gate uses the same single launcher/script:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_mask
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_mask
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_mask
```

stage5_sign_mask_inputs.txt comes from Python;_outputs.txt comes from actual
RTL. This test prepares a real key,then derives mu/private seed and writes
all4/5/7 y polynomials through shared Keccak/sampler/banks. GUI waves show
retained context,phase,ordinal,private results and service handoffs. Require
capture,independent compare and negative-checker PASS separately. The universal
REFERENCE_VERIFICATION.md gives counts,provenance and remaining Sign scope.

Stage5N.4d preparation client uses the same single script and launcher:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_prepare
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_prepare
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_prepare
```

The helper loads expanded SKs,retains the validated header,uses one rotating
scratch for shared Pre/FNTT,and retains the resulting context until clear.
stage5_sign_prepare_inputs.txt and _outputs.txt are fixture/capture files;
GUI waves show context,owned map,scratch,ordinal and the owner/service mux.
Require capture/comparison/checker PASS separately. It uses actual services
and banks but is not yet connected to unfinished main Sign/Verify. Full
contracts and final results belong in universal REFERENCE_VERIFICATION.md.

Latest Stage5N.4c2 runs the actual production shared service:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_load_service
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_load_service
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_load_service
```

The same stage5_sign_load_inputs.txt drives standalone and shared gates.
Shared outputs/logs use stage5_sign_load_service_*;GUI waves show the services
record,private region mask,loader state,arbiter fields and physical ACKs.
Require capture,exact comparison and checker-fault PASS separately. This is
key ingestion/ownership,not complete Sign. Full results are in the universal
REFERENCE_VERIFICATION.md;no additional launcher or Python file is added.

Prior Stage5N.4c1 uses the same single script and launcher:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_load
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_load
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_load
```

Require separate capture,comparison and checker PASS markers.138 commands;
449992 scalar writes;105728 exact92-bit reads;75 official KeyGen SKs;late
rollback,occupied/overflow plans,stalls and5 resets. GUI waves show the plan,
commit mask,private visibility and memory handshakes. This is a focused real-
memory client gate;production service wiring is next. Full details in the
universal REFERENCE_VERIFICATION.md,not a separate pair-integration document.

Stage5N.4b signing-message gate uses the same prepare/launcher/single Python:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_hash
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_hash
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_hash
```

Require capture/comparison/checker PASS separately.167 commands/162 completions/
34 expected errors/5 resets;52618 exact absorption words,7760 raw bytes,6400 mask
coefficients,29 peer-core jobs,9 actual digest forwards and61 corruptions rejected.
7760 includes1296 error-drain diagnostic bytes;6464 are successful raw results.
The harness uses actual dilithium_services;GUI waves include merge/prefix/drain,
payload framing and ownership. This is not a full Sign or NIST sigGen gate.

Stage5N.4a expanded signing-key decoder:

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa GUI Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_decode
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_decode
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_decode
```

Require separate capture/compare/checker PASS.129 commands,124 completions,
32 expected errors,5 resets,436424 exact coefficients;75/75 official KeyGen
secret keys decoded;35 checker corruptions rejected. The single Python script
also checks128 full source keys/549888 coefficients against unchanged C
unpack_sk/pack_sk. This is not full Sign or official sigGen testing. Files use
stage5_sign_decode_ prefix;GUI waves include header/coefficient/framing state.
Earlier stage summaries below describe their original boundaries.

Stage5N.3 uses the same single prepare/launcher/Python flow. Prepare from the
repository root,then use the Questa GUI Transcript from sim/:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_service
do dilithium/run.do
# Select sign_dma for the deeper real-memory fault/reset test.
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_service
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_service
# After capturing sign_dma,compare/selftest with --unit sign_dma.
```

Require capture,comparison and checker PASS separately. sign_dma:71 commands,
65 completions,21 expected errors,6 resets,14284 exact scalar writes,3570 ACKs,
32 rejected corruptions. sign_service:33 commands,30 completions,9 expected
errors,3 resets,192 source words and768 exact result words,33 corruptions
rejected. GUI wave setup is included for both selectors. No extra .do or
Python launcher is added. Main Sign control remains pending. Older status
paragraphs below record their historical stage boundaries.

Stage5N.2 signing arithmetic uses the same prepare command,then select
DILITHIUM_STAGE=5 and DILITHIUM_TEST=sign_process in Questa. After capture:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_process
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit sign_process
```

Require DILITHIUM_STAGE5N2_SIGN_PROCESS_CAPTURE_PASS,the complete comparison
and27/27 checker PASS. Inputs,golden and captured output use the
stage5_sign_process_ prefix. Reference verification and concrete boundary
witnesses are documented in the universal Dilithium docs. This is a standalone
process gate;main Sign and shared-bank process DMA remain later work.

Stage5N.1 uses the same selectors after moving the engine/Bitpkg instances
under dilithium.services. prepare hashes the new package and service wrapper.
The full-key bench checks ownership,including cleanup after main done;its
Q record contains owned,cleanup-owner and idle cycle counts. The local checker
now rejects37 corruptions;the official-vector checker tests41,including
missing ownership evidence and a zero cleanup-owner count. Require fresh
capture/compare/selftest verdicts after prepare. Historical counts below
describe their original checkpoints;current results are in the universal
REFERENCE_VERIFICATION.md.

Official KeyGen selector:use the same prepare command and launcher with
DILITHIUM_STAGE=5,DILITHIUM_TEST=nist_keygen. It runs all75 published NIST
cases through tb_full_keygen(NIST_VECTORS=1),without altering RTL.
Then run:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit nist_keygen
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit nist_keygen
```

Require stage5_nist_keygen_CAPTURE_PASS plus the separate NIST comparison
and checker PASS. Corpus/provenance,exact GUI commands and results are in
docs/dilithium_docs/REFERENCE_VERIFICATION.md. Expected keys come directly
from the pinned NIST JSON files,not from the C/Python implementation.
Stage5M result:75/75 keypairs,433600 exact key bytes and39 checker faults PASS.
The local full_keygen suite also freshly passes8 complete,3 rejects,5 resets
and35 checker faults. Other earlier selectors retain their historical Stage5L
evidence;rerun them after prepare if a current-token capture is wanted.

Latest complete KeyGen selector:prepare the single Python script,then:

```tcl
# Questa Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST full_keygen
do dilithium/run.do
```

```powershell
# Repository root,after simulation
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit full_keygen
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit full_keygen
```

Require stage5_full_keygen_CAPTURE_PASS,the independent whole-key
comparison and35/35 checker-fault PASS. The bench drives only start/output/
done/reset controls. Inputs:stage5_full_keygen_inputs.txt;C expected keys:
stage5_full_keygen_expected.txt;capture:stage5_full_keygen_outputs.txt.
Eight complete keypairs at all3 levels match unchanged software KeyGen.
These are deterministic local-reference vectors,not official NIST KATs.
See universal REFERENCE_VERIFICATION.md for exact workload and scope.

Latest selectors:rounded_keygen enables ROUND_OUTPUTS=1 and checks retained
t1/t0 arrays;bitpkg checks polynomial field encoding against Python/C.
Use the existing prepare command,then select one in the Questa Transcript:

```tcl
set DILITHIUM_STAGE 5
set DILITHIUM_TEST rounded_keygen
do dilithium/run.do
# For the packet block,use DILITHIUM_TEST bitpkg instead.
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit rounded_keygen
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit rounded_keygen
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit bitpkg
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit bitpkg
```

Run each corresponding simulation before its compare/selftest.
Rounded KeyGen:190224 scalar values,12800 exact92-bit reads,36 checker faults.
Historical Stage5K Bitpkg:97 commands,2482 exact output words,15 checker faults.
Stage5N.4g expands it to136 commands and2996 exact output words,including w1;
current prepare checks96 valid C fixtures/22976 bytes.15 checker faults pass.
The above block-only selectors are preserved diagnostic gates;full_keygen
implements complete encoded keys and the public-key hash.

Latest autonomous polynomial phase:prepare with the existing Python script,
then set DILITHIUM_STAGE5 and DILITHIUM_TEST keygen in Questa:

```tcl
set DILITHIUM_STAGE 5
set DILITHIUM_TEST keygen
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit keygen
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit keygen
```

Inputs:stage5_keygen_inputs.txt(operation/level/ID/xi/reset phase only).
Captures/verdicts:stage5_keygen_outputs.txt,stage5_keygen_compare.log,
stage5_keygen_checker_selftest.log.7 complete polynomial-phase operations,
3 rejects,4 resets,34 t=A*s1+s2 rows;29 corrupted captures rejected.
The bench drives no sample/NTT/process/row descriptors in this selector.
This still precedes rounding/encoded-key outputs. The previous selectors
below remain regression baselines after controller/helper relocation.

Stage5I is the latest seed-driven row connection. From the repository root:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

In the Questa GUI Transcript,with working directory sim/:

```tcl
set DILITHIUM_STAGE 5
set DILITHIUM_TEST seed_row
do dilithium/run.do
```

Then from the repository root:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit seed_row
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit seed_row
```

Require DILITHIUM_STAGE5I_SEED_ROW_CAPTURE_PASS,the Python seed/row comparison,
ROW_SCHOOLBOOK_PASS,C_ROW_ADD_PASS and the23/23 checker-fault verdict.
20 actual RTL seed expansions produce2560 exact bytes;163 RTL-formatted
sampling jobs feed13 successful row outputs,27 row rejections and7 reset cases.
Input stage5_seed_inputs.txt contains xi only;RTL constructs all absorption
messages. Outputs/verdicts:stage5_seed_row_outputs.txt,stage5_seed_row_compare.log,
stage5_seed_row_checker_selftest.log. GUI adds seed,raw service and formatter
waves alongside row/NTT/process waves. Scope:REFERENCE_VERIFICATION.md in the
universal docs. Full KeyGen scheduling,s2/rounding/key encoding remain next.
Selector row below preserves the fixture-driven Stage5H baseline.

Stage5H runs the latest staged-row scheduler:

```powershell
# Repository root,first
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST row
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit row
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit row
```

Require DILITHIUM_STAGE5H_ROW_CAPTURE_PASS and the separate Python whole-row,
schoolbook and C ADD PASS markers.13 completed rows,27 expected rejections,
7 reset aborts;163 sample jobs,161 NTT commands,55 destructive ADDs and12544
exact92-bit public reads;26 checker corruptions rejected. Inputs:
stage5_row_samples.txt/stage5_row_expected.txt. Capture/verdicts:
stage5_row_outputs.txt,stage5_row_compare.log,stage5_row_checker_selftest.log.
GUI waves include row state,column,leases,child commands and accumulator data.
Full scope/limits:docs/dilithium_docs/REFERENCE_VERIFICATION.md. This returns
u=A*s1,not an encoded key;full KeyGen/synthesis/UVM/PPA remain later work.

Stage5G runs the latest banked process/NTT connection:

```powershell
# Repository root,first
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST bank_process
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit bank_process
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit bank_process
```

Require DILITHIUM_STAGE5G_CAPTURE_PASS,Python COMPARE PASS and C_BANK_PROCESS_PASS.
23 samples,15 NTT commands,71 process commands;34 successes,33 expected rejections,
4 reset aborts;8512 exact92-bit reads;29 checker corruptions rejected. Prepared
schedule:stage5_process_banks_inputs.txt;capture:stage5_process_banks_outputs.txt;
verdicts:stage5_process_banks_compare.log,stage5_process_banks_c_reference.log,
stage5_process_banks_checker_selftest.log. GUI waves include process leases,
word caches,arithmetic low/high outputs and physical packed write acknowledgements.
Full scope:docs/dilithium_docs/REFERENCE_VERIFICATION.md. Default selector4 and
Quartus top preserve the old scalar baseline;no full-KeyGen/PPA result implied.

Stage5F runs the new complete banked connection:

```powershell
# Repository root,first
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST bank_ntt
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit bank_ntt
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit bank_ntt
```

Require DILITHIUM_STAGE5F_CAPTURE_PASS and the separate Python COMPARE PASS.
16 real sample jobs,54 commands,30 results,21 expected rejections,3 reset aborts,
2944 exact92-bit reads and19 rejected checker corruptions. Capture/verdict names:
stage5_ntt_banks_outputs.txt,stage5_ntt_banks_compare.log and
stage5_ntt_banks_checker_selftest.log. GUI waves include leases,word/lane DMA,
engine streams and packed write acknowledgements. Full scope/results are in
docs/dilithium_docs/REFERENCE_VERIFICATION.md. Default stage4 remains the old
scalar regression;no synthesis or full-operation result is implied by this test.

Stage5E connects the real producer to the new banks:

```tcl
# Questa Transcript,from sim/;prepare vectors from repository root first
set DILITHIUM_STAGE 5
set DILITHIUM_TEST bank_store
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit bank_store
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit bank_store
```

Require DILITHIUM_STAGE5_STORE_PASS,BANK_STORE_PROTOCOL_PASS and Python COMPARE
PASS.104 jobs,88 completed polynomials,5632 exact92-bit words(22528 coefficients),
8 expected errors/8 reset aborts;8 protocol faults contained/12 capture corruptions
rejected. All64 regions fill/protect/reuse. Source:tb/tb_dilithium;capture:
stage5_store_outputs.txt. Stage5F above adds banked NTT DMA/writeback;default
stage4 remains the prior scalar path. No complete KeyGen or PPA claim.

Stage5C shared raw-SHAKE/seed test uses the same launcher and Python script:

```tcl
# Questa Transcript,from sim/;run Python prepare from repository root first
set DILITHIUM_STAGE 5
set DILITHIUM_TEST shared_hash
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit shared_hash
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit shared_hash
```

26 commands,1699 exact SHAKE bytes and1792 exact sampled coefficients PASS.
The sampled seeds come from the real RTL collector. Includes1 parameter error,
3 resets,raw/raw and raw/sampling ownership,stalls and12 checker corruptions.
Capture:stage5_shared_outputs.txt. Main connected top remains Stage4;no complete
KeyGen or synthesis claim. Shared docs give the protocol and result arithmetic.

Current `run.do` exercises Stage4's real Keccak→sampler→memory→NTT path using a focused
non-UVM testbench under `tb/tb_dilithium/`. Main Dilithium UVM and implementation
launchers will replace/extend this evolving project at their actual stages.

Stage5A also adds an isolated process gate:in Questa use
`set DILITHIUM_STAGE 5` and `set DILITHIUM_TEST process` before this launcher;then Python compare/selftest
with `--stage 5`. It checks ADD/SUB/Power2Round:10349 accepted,10346 exact outputs,
3 reset aborts,13 expected errors. It does not run full KeyGen. Preparation
now needs GCC for the unchanged C rounding reference;it is available as
C:/MinGW/bin/gcc.exe in this workspace. Return to selector4 for the connected test.

Stage5B tests final FIPS204 seed/nonce formatting using level2/3/5 labels for
ML-DSA-44/65/87. Prepare as below,then in the Questa Transcript (from sim/):

```tcl
set DILITHIUM_STAGE 5
set DILITHIUM_TEST hash_format
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit hash_format
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit hash_format
```

165 commands/162 message completions/14 expected errors/3 reset aborts PASS;
883 absorption words and5888 SHAKE bytes match. Captures:stage5_hash_outputs.txt;
inputs:stage5_hash_inputs.txt. This gate uses one existing Keccak instance in
a focused harness;the formatter is not connected to the main top yet. Sampling
messages are hashed for32 bytes here,not sampled into polynomials. Full commands,
file formats and limits:docs/dilithium_docs/REFERENCE_VERIFICATION.md.

Repository-root terminal:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

Questa GUI Transcript,working directory `sim/`:

```tcl
do dilithium/run.do
```

Repository-root terminal after capture:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 4
python sim/dilithium/dilithium_vectors.py selftest --stage 4
```

16 sampling jobs and50 compute commands:30 completed,17 rejected,3 reset-aborted.
Require `DILITHIUM_STAGE4_CAPTURE_PASS` and independent
`DILITHIUM STAGE4 COMPARE PASS`;4096 sampled values,9745 DMA operands,7713 NTT
outputs and11776 stored readbacks match. All12 checker corruptions are rejected.
GUI waves include commands,DMA progress,NTT streams and memory lifecycle.
No complete Dilithium UVM/coverage/PPA claim.

To rerun the preserved Stage2 test in Questa:

```tcl
set DILITHIUM_STAGE 2
do dilithium/run.do
```

Then use Python compare/selftest with `--stage 2`. Set `DILITHIUM_STAGE 3`
for the preserved sampling-memory test (104 jobs/22528 readbacks),and use
`--stage 3` for its Python verdict. Set `DILITHIUM_STAGE 4` to return to the
current all-engine test. All stages use the same sampling input/expected files
and the same Python script. Stage4 adds stage4_expected.txt with26 independently
calculated arithmetic expectations. Stage-specific captures are named
stage2_outputs.txt,stage3_outputs.txt andstage4_outputs.txt. Python defaults to4.

Golden vectors bind to the source/test/launcher/reference hash;rerun prepare and
capture after changing them. Current workload cycle witnesses are in
stage2_jobs.csv. Universal docs:docs/dilithium_docs/REFERENCE_VERIFICATION.md,
ARCHITECTURE.md and THROUGHPUT.md. Standalone module projects remain separate.
