# Dilithium integration

This is the universal documentation set for the `integration` branch. Add each
integration milestone to these documents as the complete design grows.

| Document | Purpose |
|---|---|
| [DILITHIUM_PLAN.md](DILITHIUM_PLAN.md) | Agreed layout,stages,decision gates and next work |
| [SPECIFICATION.md](SPECIFICATION.md) | Imported source provenance,current interfaces and relocation results |
| [ARCHITECTURE.md](ARCHITECTURE.md) | Current connected datapath,ownership,bridge and drain contract |
| [MEMORY_MAP.md](MEMORY_MAP.md) | Approved Stage3 slot memory,ownership,readback and measured results |
| [PROCESS_FLOW.md](PROCESS_FLOW.md) | Current transaction steps and planned algorithm processing |
| [REFERENCE_VERIFICATION.md](REFERENCE_VERIFICATION.md) | One-script prepare/capture/compare flow and measured results |
| [INTEGRATION_VERIFICATION_TESTPLAN.md](INTEGRATION_VERIFICATION_TESTPLAN.md) | Focused integration requirements/checks;later full UVM scope |
| [THROUGHPUT.md](THROUGHPUT.md) | Current cycle witnesses and combined implementation measurements |
| [PIN_CONFIG.md](PIN_CONFIG.md) | Current subsystem top ports and virtual-pin assignments |

Comprehensive coverage documentation will be added when that work begins.
Do not create a separate documentation suite for each module pair.

Current direction (2026-10-20):integrate for correct functionality and outputs
first,then optimize Fmax,area and throughput. Stage4 all-engine functional checks
pass;next is Stage5 algorithm audit/controller/process work. The open148MHz
goal does not block that work.

Stage5A has now completed the initial audit and shared arithmetic unit tests:
10349 accepted cases,10346 outputs,3 reset aborts and13 expected errors.
The full-operation byte-format decision is pending. See SPECIFICATION.md for
the paper/software mismatch and MEMORY_MAP.md for the proposed KeyGen live ranges.
Selector5 in the existing launcher tests only the process unit;the default4
continues to test the current all-engine connected subsystem.

Current runnable projects are standalone:

- Keccak: [simulation](../../sim/keccak/README.md),
  [Quartus](../../quartus/keccak/README.md).
- Sampler: [simulation](../../sim/sampler/README.md),
  [Quartus](../../quartus/sampler/README.md).
- NTT: [simulation](../../sim/ntt/README.md),
  [Quartus](../../quartus/ntt/README.md);source/UVM relocated unchanged from ntt_v2.

The current connected Stage4 top is src/controller/keccak_sampler_ntt.sv;
focused tests use [sim/dilithium](../../sim/dilithium/README.md),and the evolving
combined project is [quartus/dilithium](../../quartus/dilithium/README.md).
The main algorithm controller and remaining process blocks follow the shared
roadmap. Standalone metrics are not system metrics.
