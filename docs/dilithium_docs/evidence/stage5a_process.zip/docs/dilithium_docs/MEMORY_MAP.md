# Dilithium polynomial memory

## Stage5A KeyGen live-range proposal - not implemented

Level2 needs k=l=4. Four slots are sufficient for a sequential mathematical
row schedule if secrets are regenerated when needed and results are delivered
to a separately defined key-output destination. This differs from caching all
four s1 polynomials and their transforms. No expanded memory allocation or
key-output protocol is approved by this proposal.

| Step in row i,column j | Live polynomial roles at peak | Action releasing capacity |
|---|---|---|
| Sample A_hat[i,j] and s1[j];transform s1[j] |Accumulator,A_hat,s1,s1_hat:4 |Release coefficient s1 after transform;regenerate it for later rows/key encoding|
| PWM(A_hat,s1_hat) |Accumulator,A_hat,s1_hat,product:4 |Release A_hat and s1_hat after PWM|
| Add product into NTT-domain accumulator |Old accumulator,product,new accumulator:3 |Release old accumulator/product;first column can keep product directly|
| Finish row |Accumulator,INTT result:2 |Release transform accumulator|
| Add sampled s2[i] |INTT result,s2,t:3 |Release INTT result and s2|
| Power2Round/pack |t plus external key-output storage |Release t only after both t1/t0 are delivered safely|

For this regeneration schedule,level2 uses16 forward transforms,16 PWM,12
transform-domain additions,4 inverse transforms and4 coefficient-domain error
additions. Cached s1_hat would require only4 forward transforms;the extra12
transforms are an explicit tradeoff,not an unnoticed throughput result.
These are logical operation counts,not measured hardware cycle counts.

Key output is a separate unresolved lifetime:pk needs rho and all t1 rows;
sk needs rho,K,tr,s1,s2,t0. tr depends on the complete encoded pk. t0 rows must
survive until written in the chosen output/key-storage protocol. A four-slot
coefficient pool does not itself store all encoded keys. Options to review are
addressed key-byte output or explicit byte storage;neither is implemented yet.

Raw SHAKE is another pending connection:seed expansion and H(pk) need hash
bytes directly,while the current Keccak helper routes output to the sampler.
Use the existing dual-core engine through a shared service when designed;
do not silently instantiate another complete Keccak for those hashes.
Finalize these architecture decisions after the algorithm-format answer.

## Stage4 extension:NTT ownership and writeback

The approved four-slot capacity is unchanged. memory.sv now adds a sequential
compute reservation,source locks and a distinct result writer,used by
keccak_sampler_ntt.sv. The preserved Stage3 wrapper explicitly disables these
ports;its regression still checks the earlier sampling-only contract below.

Slot states are now FREE,WRITING,COMPLETE and IN_USE. Compute reservation
validates source state,expected IDs,domain,parameter agreement and bounded
Pre eligibility before changing ownership. Invalid commands return code1 or2
without allocation/engine activity. Valid commands wait for a free destination
and for an old read response to drain. The helper protects source release
immediately on command acceptance,including the destination-capacity wait.
Unrelated completed slots can still be released to supply capacity.
At reservation,sources transition COMPLETE -> IN_USE;
the destination transitions FREE -> WRITING. PWM may read one source twice.

Locked slots cannot be released/reallocated. The internal DMA may read IN_USE
slots;the public read path waits during compute. The helper accepts compute
commands only after active sampling contexts retire,and pauses new sampling
until completion is accepted. Consequently the first schedule is sequential.
The RAM's result write has priority over a sampler write;if a future scheduler
permits overlap,it must verify that arbitration and revise this contract.

After256 correct result writes and engine done,destination becomes COMPLETE
and sources return COMPLETE. Reset invalidates all roles and pending replies.
An internal write/ordering fault prevents valid publication and requires reset.
No partially written result is readable as a completed polynomial.

Domain is now an explicit metadata bit,independent of original sampling mode.
For example INTT(A) retains mode=A but has coefficient-domain output. Compute
results inherit source A's mode/parameter and receive the new result job ID.
NTT/Pre/PWM output is transform-domain;INTT output is coefficient-domain.
The per-slot bounded flag is accumulated from actual values,including writeback.

Source interfaces,run commands and measured Stage4 gates are in the shared
SPECIFICATION.md,REFERENCE_VERIFICATION.md and INTEGRATION_VERIFICATION_TESTPLAN.md.
There is no new fitted PPA/physical RAM-packing result for this extension.

## Preserved Stage3 sampling contract

The user approved the simple four-slot pool on2026-10-20. It is implemented in
src/controller/memory.sv and connected through keccak_sampler_memory.sv.
Functionality-first integration continues;PPA optimization is deferred until
correct full-operation outputs. No Stage3 synthesis/PPA result is claimed.

The implementation uses a configurable shared pool of four polynomial slots, simple
arbitration and sequential NTT scheduling. This is an initial integration
configuration, not the final capacity for full KeyGen/Sign/Verify.

| Item | Implemented contract |
|---|---|
| Polynomial |256 coefficients,23 bits each|
| Initial capacity |4 slots;4 x256 x23=23552 coefficient bits=2944 bytes|
| Slot address |2-bit slot number plus8-bit coefficient index|
| Allocation |Reserve a free slot before accepting a sampling job|
| Ownership |Record actual assigned core,job ID,mode and domain for that reservation|
| Sampling states |FREE,WRITING,COMPLETE;only FREE slots may be allocated;Stage4 adds IN_USE for compute sources|
| Writes |Accept only the owning job's next coefficient;check index,last and count|
| Completion |Exactly256 accepted coefficients plus successful matching status|
| Reads |Only COMPLETE slots return valid payload;other requests return an error response;ready/valid holds stalled responses|
| Release |Explicit controller release after all scheduled consumers finish|
| Errors/reset |Invalidate affected partial slots;reset clears metadata rather than bulk RAM contents|
| Arbitration |Shared sampler write stream plus independent synchronous read port;read wins a simultaneous same-slot release;pending responses block release|

Three slots allow two retained PWM operands and a separate result destination.
A fourth provides another reservation for the producer. This does not promise
unrestricted simultaneous dual-job sampling and NTT operation. If all slots
are reserved, stall new commands. First schedules will be serial;derive larger
capacity and ports from actual algorithm live ranges before supporting overlap.

The arithmetic above counts coefficient storage only. Metadata, handshake
registers and physical FPGA RAM packing add resources;no M10K/area result is
claimed before implementation and measurement. These are logical slots, not
a promise of four physical RAM blocks or a particular banking layout.

## Domain and interface obligations

The sampler emits tagged23-bit coefficients with8-bit index and last flag.
Retirement status follows SHAKE drain;receiving the last coefficient alone
must not publish a polynomial as valid. Job IDs can be reused after retirement;
slot ownership and lifecycle must prevent old contents from being mistaken
for a new polynomial.

Matrix A values are already in the transform domain. Secret/mask/challenge
polynomials begin in the coefficient domain. Preserve this distinction in
metadata;NTT representation/scaling metadata will be finalized in Stage4.

Successful status and slot commit are the same external handshake. Status
stall keeps the slot WRITING even after coefficient255. Ordinary sampler errors
free the reservation. An owned malformed write is consumed but poisons the slot;
wrong-owner traffic and premature success also raise sticky fault_o. A poisoned
slot cannot become COMPLETE. fault_o is an internal protocol failure,requires
coordinated reset,and must be handled by the future controller;it is distinct
from an expected sampler parameter-error status. Read errors are ordinary
responses and do not set fault_o. Error-response data is unspecified;ignore it.

Reads are synchronous with one response register,which can be replaced on the
same edge the previous response is accepted. Metadata is captured with each
read,so stalls cannot change its ID,domain or parameter. Reset clears metadata
and pending responses,not payload RAM;this provides validity isolation,not
secure erasure. Do not interpret two-bit slot addresses as permanent job IDs.

Read-only inspection of ntt_v2:src/ntt_LightHD/ntt_engine.sv confirms one23-bit
coefficient per accepted beat. NTT/INTT load256 values;PWM loads256 A followed
by256 B;results stream256 values with backpressure. Do not import that package
or implement its controller until Stage4. Memory has no dependency on its
internal bank organization.

## Stage3 verification gate

- Feed independently checked SHAKE-sampler jobs into allocated slots;read back
  and compare all256 coefficients,IDs,indices and domains.
- Interleave both contexts with different jobs and hold input/read/status
  handshakes;verify no mixing,overwrite or changing stalled response.
- Reject reads before successful retirement,including after coefficient255.
- Exercise pool exhaustion,explicit release and reuse with different contents.
- Inject expected parameter errors and reset during partial writes/read stalls;
  prove no partial or stale polynomial becomes readable afterward.
- Preserve the existing Stage2 checker and standalone module tests.

## Measured Stage3 source results

104 jobs:88 complete,8 expected errors,8 reset aborts.23180 input coefficients
match independently computed expectations:22528 complete values plus652 aborted
prefix values. All88 successful slots are read back exactly once:22528 values,
including ID,index,mode,parameter and domain.88 explicit releases and99 invalid
reads pass. Full-pool blocking is witnessed for8 cycles,read-response stalls
for1321 cycles and concurrent read/write for170 cycles in this workload.

The companion memory_protocol_test uses SLOTS=3 to check non-power-of-two bounds.
It rejects8 fault kinds:wrong index,wrong last,noncanonical value,wrong write ID,
premature success,simultaneous early write/success,extra257th coefficient,and
wrong finish ID. It also checks consecutive read-response replacement,
simultaneous same-slot read/release priority and reset of a stalled valid read.
The integrated test resets partial writes and a pending error response,checks
post-reset invalid reads,and reuses IDs with different messages.

The separate Python lifecycle checker confirms ownership,commit/release/reset,
all stored outputs and exact totals.12/12 deliberately corrupted captures are
rejected. The preserved Stage2 regression also passes104 jobs/23089 values and
12 checker faults. See REFERENCE_VERIFICATION.md for commands and evidence.
