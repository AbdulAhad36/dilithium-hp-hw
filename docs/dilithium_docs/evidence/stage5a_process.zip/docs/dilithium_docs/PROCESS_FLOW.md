# Dilithium processing flow

## Stage5A candidate first KeyGen schedule

This schedule is a proposal pending the algorithm byte-format answer and memory/
key-output decision. It is not executed by a hardware main controller yet.

1. Expand a test-supplied32-byte seed into rho,rho-prime and K using the selected
   reference's exact input formatting. Raw SHAKE output needs a shared hash
   service path;the current sampling helper is not that interface.
2. For each matrix row i and column j,sample A_hat[i,j] and s1[j] using exact
   row/column/secret nonces. A_hat is already transformed. Use Pre/NTT for s1.
3. Compute PWM and accumulate the row in transform domain using modular ADD.
   With four slots,regenerate s1 for later rows and release temporary inputs.
4. Inverse-transform the row sum,sample s2[i],and add it modulo q.
5. Power2Round each t coefficient into t1 and t0;encode them using the selected
   byte format. Preserve t0 until the chosen key-output/storage destination owns it.
6. Hash the complete encoded public key to obtain tr;encode the secret key
   with the required seed/hash/secret/t0 fields. Byte order and hash length
   must follow the selected version. Compare complete keys with its reference.

The shared coefficient ADD/SUB/Power2Round unit now passes its isolated tests.
Still required:raw hash service,seed/nonce builder,process/memory routing,
byte serializers/key storage and the actual main-controller schedule.

## Current Stage4 sampled-polynomial arithmetic

1. Submit real sampling jobs and wait for successful slot commit using the
   producer/storage flow below. Keep Matrix A marked transform-domain.
2. Present opcode,source slot(s),expected source ID(s) and a new result ID.
   The helper accepts the command after active sampling and old reads retire.
3. Memory validates state/IDs/domain/Pre eligibility and PWM parameter agreement.
   Invalid requests return a held rejection reply without starting the engine.
4. For a valid request,wait for a free destination,lock sources and reserve it.
   Inputs remain stored. The four-slot pool may need an unrelated slot released
   before proceeding;no implicit overwrite or automatic input release occurs.
5. DMA reads A indices0..255,and B0..255 for PWM,with one outstanding read.
   Engine arithmetic uses normal canonical residues;INTT includes its scaling.
6. Write results0..255 into the reserved slot. Wait for engine done,then commit
   the destination and unlock sources. Offer the tagged completion until accepted.
7. Read/consume the completed result and explicitly release slots after their
   scheduled consumers finish. A new NTT job is not loaded while one is active.

Tested mathematical chain:A_hat (directly sampled) and s -> NTT(s) ->
PWM(A_hat,NTT(s)) -> INTT -> coefficient polynomial. Python independently
checks this against schoolbook(inverse(A_hat),s) in Z_q[x]/(x^256+1).
Pre(s) equals NTT(s),and INTT(NTT(s)) equals s exactly. Reset cancels the
whole subsystem during DMA load,core execution or writeback;new jobs recover
with fresh messages,including reusing the same source/result IDs.

This is still a subsystem flow. Full KeyGen/Sign/Verify scheduling,seed/nonce
assembly and remaining process blocks come in Stage5.

## Preserved Stage3 memory transaction

1. Reserve a free polynomial slot on the same handshake that accepts the job;
   capture job_slot_o and actual job_core_o for the future controller.
2. Run the Stage2 SHAKE/sampling flow below. Tagged coefficient writes must
   match the slot owner,index,last and canonical range.
3. Keep the slot WRITING through all256 writes and source drain. A premature
   read returns an error;the last coefficient alone does not commit the slot.
4. Successful external status acceptance commits COMPLETE. An expected error
   frees the slot;reset invalidates all slots and pending responses.
5. Request coefficients by slot/index. A synchronous response carries data,
   job ID,mode,parameter and domain;hold it stable under backpressure.
6. Release the slot explicitly after its scheduled consumers finish. A pending
   read response blocks release. Pool exhaustion stalls new jobs.

The focused testbench drives public reads/releases. Stage4 additionally supplies
NTT compute descriptors and checks DMA/result/commit behavior.

## Preserved Stage2 producer transaction

1. Present the sampling mode,parameter encoding,ID and absorption-message length.
2. Hold the descriptor until ready/valid accepts it;capture assigned core.
3. Feed exactly the declared message on64-bit beats,earliest byte in bits7:0.
   Keccak handles the final partial word using the declared byte length.
4. Keccak absorbs,pads,permutes and produces a tagged SHAKE stream.
5. The shared two-slot registered-credit queue passes data/byte count/core to the matching
   sampler context. Concurrent jobs keep separate parser/carry state.
6. The sampler emits256 canonical23-bit coefficients,with job ID,core,index and
   last. The Stage3 receiver is polynomial memory;the preserved Stage2 test
   still checks the producer stream directly.
7. On sampler stop,the adapter drains/discards surplus,then stops Keccak after
   releasing its held output. It waits for old source tokens to retire.
8. The external status handshake releases the context for a new job.

Invalid parameter3 produces the existing parameter-error status after safe
upstream retirement. A coordinated reset cancels both jobs;partial polynomials
must be discarded. The focused test checks accepted partial prefixes and then
checks same-ID recovery with different messages.

## Implemented versus planned

| Operation | Current ownership |
|---|---|
| Raw absorbed message generation | Testbench/Python inputs;future controller handles seeds/nonces/messages |
| SHAKE128/256 | Accepted Keccak RTL |
| A/secret/mask/challenge sampling | Accepted sampler RTL |
| Job binding,two-slot credit bridge,stop/drain | controller/keccak_sampler.sv |
| Polynomial allocation and memory writes/readback | controller/memory.sv and keccak_sampler_memory.sv;Stage3 source PASS |
| NTT/INTT/PWM/Pre-NTT | src/ntt/ imported unchanged;controller/keccak_sampler_ntt.sv DMA/source locks/result commit;Stage4 source PASS |
| Modular ADD/SUB and Power2Round | controller/process/poly_process.sv;isolated Stage5A unit PASS,not memory-connected |
| Full KeyGen/Sign/Verify schedules,decompose/hints/encoding | Later controller/process stages |

A is already transform-domain data and will go to operand storage/PWM. Small
secrets can later use ordinary NTT or eligible Pre-NTT with one owner for the
first-stage work. Exact full-operation formatting/version and the memory
schedule must be settled before claiming LightHD-equivalent complete outputs.
