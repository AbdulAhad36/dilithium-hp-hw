# Dilithium verification test plan

## Stage5A process-unit gate

tb_poly_process.sv checks the shared one-stage coefficient arithmetic unit.
It does not instantiate a full KeyGen/controller. Expected math is generated
by the existing singular Python script and cross-checked with the unchanged C
rounding reference plus ordinary modular arithmetic in process_reference.c.

| Requirement | Check |
|---|---|
| Canonical add/sub |Directed q/zero/half-range boundaries and512 deterministic random pairs for both operations|
| Power2Round ties/width |9208 canonical cases spanning every high-part region with low offsets0,1,4094..4098,8190,8191 where valid|
| Signed/packed low |Exact signed14-bit low and13-bit 4096-low;reconstruction and strict tie interval|
| Relevant operands |ADD/SUB require both canonical;rounding ignores an intentionally noncanonical unused B|
| Framing/errors |13 invalid opcode,noncanonical operand or last/index errors;zero arithmetic results,metadata retained|
| Stalls/pipeline |10009 simultaneous output/input transfers,3505 blocked-input and3511 held-output observations|
| Reset and ID reuse |Three operation-specific pending outputs aborted;one reset also cancels an unaccepted blocked input;fresh recovery reuses IDs|
| Checker integrity |12 corruptions of arithmetic/signedness/packing/opcode/tag/framing/sequence rejected|

PASS:10349 accepted,10346 compared outputs (including13 expected errors),
3 reset aborts. C separately checks all8380417 canonical Power2Round values
against reconstruction/range constraints. This exhaustive reference check
does not mean exhaustive RTL simulation or full functional/code coverage.
Memory routing,packing,stateful polynomial sequencing and KeyGen remain untested
until implemented after the required architecture decisions.

## Current Stage4 focused tests

tb_keccak_sampler_ntt.sv connects all three real engines through memory. It uses
generated independent expectations and writes a trace consumed by the separate
Python checker. Standalone NTT UVM is retained and revalidated independently.

| Requirement | Observed check |
|---|---|
| Four arithmetic operations |NTT,INTT,PWM,Pre;canonical values and exact root/order/scaling|
| All parameter levels |Three Matrix A/secret chains with parameter encodings0/1/2|
| Matrix A bypass |Already-transformed A enters PWM;attempted forward NTT(A) is rejected|
| Independent product |INTT(PWM(A_hat,NTT(s))) equals schoolbook(inverse(A_hat),s)|
| Pre eligibility |Bounded secret and challenge accepted;unbounded mask rejected|
| Round trips |Secret,mask and challenge recovered exactly after NTT/INTT|
| Operand preservation/alias |A and s remain exact after use;PWM may read the same NTT slot twice|
| DMA order/tags |9745 accepted values checked against the exact source ID,slot,index and value|
| Result publication |256 results plus engine done precede commit and completion reply|
| Full-pool handling |24 reservation-wait cycles;release unrelated Pre result to allow PWM destination|
| Source locks |33 successful reservations checked;source complete bits clear while IN_USE|
| Rejection containment |17 stale/free/domain/Pre/parameter errors;zero engine launches,loads or outputs for them|
| Stalls |188 held completion cycles and699 held read-response cycles;payload/metadata stable|
| Reset/recovery |Load17 values,coreRUN after256 loads,and writeback after32 outputs;reset clears all roles and six old-slot reads fail|
| Checker integrity |12 corruptions of DMA/output/read/tag/domain/reservation/completion records rejected|

Source/Python PASS:16 sampled jobs,4096 sampled values;50 compute commands,
30 complete,17 rejected,3 reset aborts;7713 output values (7680 complete+33
aborted prefix) and11776 exact stored reads. Stage2 andStage3 regressions remain
separate and pass their existing gates. This is not full-operation verification,
integration functional/code coverage or formal proof. Compute/sampling overlap,
multi-consumer schedules and general process-block arbitration are not tested.

Relocated NTT standalone UVM:748 jobs,191488 values,32 group type mean90.4731%;
raw DUT code12990/14093=92.17%. Python18 cases/4608 values PASS. These figures
belong solely to standalone NTT,not the connected subsystem.

## Preserved Stage3 focused tests

tb_keccak_sampler_memory.sv uses the real producer and memory. The separate
memory_protocol_test.sv companion injects faults into a three-slot configuration.
Stage2 remains a selectable regression in the same launcher.

| Requirement | Observed check |
|---|---|
| Atomic allocation and both contexts |104 accepted jobs;slot/core/ID binding checked;full pool refuses new commands|
| Stored contents and metadata |88 x256=22528 readbacks match independent values,IDs,mode,param,domain and index|
| Commit only on success |Reads rejected during writes and after coefficient255 while status is held|
| Concurrent traffic |170 read-request/write-accept overlaps on different slots;exact readback|
| Stable stalled response |1321 held-response cycles;payload and all metadata immutable|
| Release arbitration |Outstanding response blocks release;same-slot read wins simultaneous release|
| Invalidation/reuse |8 parameter errors,8 reset aborts,99 rejected reads;88 releases;ID reuse with new messages|
| Read pipeline/reset |Back-to-back response replacement;reset cancels stalled valid and error responses|
| Protocol containment |8 injected faults cannot publish COMPLETE;sticky fault detected|
| Configuration bounds |Three-slot companion rejects encoded slot3|
| Independent checker integrity |12/12 corrupted Stage3 captures rejected|

Source and Python gates pass:104 jobs,88 complete,8 expected errors,8 aborts,
23180 exact writes and22528 exact reads. Stage2 also freshly passes104 jobs,
23089 values and12 checker faults. This is focused verification,not comprehensive
coverage,formal proof or a full-operation Dilithium output claim.

## Preserved Stage2 focused tests

The user authorized efficient non-UVM tests during integration. The current
testbench is `tb/tb_dilithium/tb_keccak_sampler.sv`. Accepted individual UVM
environments remain intact. Full-design UVM and detailed covergroups/crosses
will be developed after complete operation outputs and reference/vector gates.

| Requirement | Current stimulus | Check/evidence |
|---|---|---|
| Both contexts/all sampling parameters |24 baseline jobs:4 modes*3 parameters*2 contexts | Python confirms all24 mode/parameter/actual-core combinations |
| Independent simultaneous operations |32 jobs covering16 ordered mode pairs | Exact per-job polynomial and tags;overlap witness |
| Empty,partial and multi-rate absorption |24 jobs with lengths0,1,7,8,9,15,16,17,33,34,65,66,135,136,137,167,168,169,271,272,273,335,336,337 | Hashlib+scalar expected values;unused high input bytes poisoned |
| Parameter error with live SHAKE source |8 jobs:param3 in4 modes on2 contexts | Parameter-error status,no coefficients,safe upstream drain |
| Output/status backpressure |Periodic stalls,forced stalls for reset targets | Held public value/core/ID/index/last and status stable |
| Shared Keccak lock and cancellation |Observed blocked hash offer,bridge cancellation and stop/drain | Hash offer stable;each stop rise must follow a discarded accepted beat |
| Reset and same-ID reuse |8 aborted jobs at4 observed phases,then8 recovery jobs | Accepted old prefixes exact;no old status/data crosses reset/reuse |
| Completion and source retirement |Every job | Status cannot retire a busy hash core or matching bridge token |
| Registered-credit queue |Two slots,forced full-queue reset,observed concurrent push/pop | Occupancy bounds,ordered values,tags retained,both slots drained before status |
| Ownership |Every accepted command/hash/bridge/output/status transfer | No unowned token or premature context reuse |
| Comparison integrity |12 deliberately corrupted captures | All rejected without changing DUT output or expected models |

Observed source gate:104 jobs,88 complete,8 expected errors,8 aborts,23089 exact
coefficient comparisons. Four reset targets are explicitly reached with both
ownership bits asserted. Raw witnesses:drops99,bridge cancellations140,blocked
hash cycles33316,dual-owned cycles37383,upstream-retirement wait cycles293,
full-queue cycles34198,simultaneous push/pop128.
These event counts describe this workload;they are not throughput rates.

## Remaining verification work

- Future NTT writeback/consumer leases,multi-consumer slot lifetimes and broader memory arbitration.
- Full-operation polynomial lifetimes,matrix-vector accumulation and remaining arithmetic/processes.
- Controller seed/nonce formation,parameter schedules,encoding and signing retries.
- Broader reset points,malformed/incomplete traffic,finite-source semantics and
  independent cancel/timeout features if they are added to the interface.
- Comprehensive UVM functional/code coverage and justified reachable gaps.
- Distinct integrated implementation netlists,physical I/O/FPGA and security review.

Do not interpret104 passing jobs or24 observed combinations as full verification
or a measured overall functional-coverage percentage. The imported components'
standalone coverage figures must not be summed into integrated coverage.
