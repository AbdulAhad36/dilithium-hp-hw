# Focused integration regression;full Dilithium UVM comes later.
# Questa GUI,from sim/: do dilithium/run.do
# Default Stage4;set DILITHIUM_STAGE 2 or3 to rerun earlier connection gates.
if {![info exists DILITHIUM_STAGE]} {set DILITHIUM_STAGE 4}
if {$DILITHIUM_STAGE ni {2 3 4 5}} {error "DILITHIUM_STAGE must be2,3,4 or5 (process unit gate)"}
if {[batch_mode]} {onerror {quit -code 1 -f}} else {onerror {abort}}
set launch [file normalize [pwd]]
if {[file exists [file join $launch stage2_inputs.txt]]} {
    set here $launch
} elseif {[file exists [file join $launch dilithium run.do]]} {
    set here [file join $launch dilithium]
} else {
    set here [file join $launch sim dilithium]
}
set repo [file normalize [file join $here .. ..]]
if {[catch {exec python [file join $here dilithium_vectors.py] check} freshness]} {error $freshness}
echo $freshness
set workdir [file join $here work]
if {![file exists $workdir]} {vlib $workdir}
vmap dilithium_work $workdir
set rtl [file join $repo src]
vlog -sv -work dilithium_work [file join $rtl keccak keccak_pkg.sv]
foreach n {keccak_param_unit keccak_absorb_unit theta_step rho_step pi_step chi_step iota_step keccak_step_unit keccak_output_unit keccak_core keccak_dual_interleaved} {
    vlog -sv -work dilithium_work [file join $rtl keccak ${n}.sv]
}
vlog -sv -work dilithium_work [file join $rtl sampler sampler_pkg.sv]
foreach n {sampler_secret_lane sampler_mask_unpack sampler_input_prepare sampler_ball sampler_compact sampler} {
    vlog -sv -work dilithium_work [file join $rtl sampler ${n}.sv]
}
vlog -sv -work dilithium_work [file join $rtl ntt ntt_pkg.sv]
foreach n {mod_mul butterfly_unit twiddle_rom ntt_core ntt_engine} {
    vlog -sv -work dilithium_work [file join $rtl ntt ${n}.sv]
}
vlog -sv -work dilithium_work [file join $rtl controller keccak_sampler.sv] [file join $rtl controller memory.sv] [file join $rtl controller keccak_sampler_memory.sv] [file join $rtl controller keccak_sampler_ntt.sv]
vlog -sv -work dilithium_work [file join $rtl controller process poly_process.sv]
if {$DILITHIUM_STAGE == 5} {
    set top tb_poly_process
    vlog -sv -work dilithium_work [file join $repo tb tb_dilithium ${top}.sv]
} elseif {$DILITHIUM_STAGE == 4} {
    set top tb_keccak_sampler_ntt
    vlog -sv -work dilithium_work [file join $repo tb tb_dilithium ${top}.sv]
} elseif {$DILITHIUM_STAGE == 3} {
    set top tb_keccak_sampler_memory
    vlog -sv -work dilithium_work [file join $repo tb tb_dilithium memory_protocol_test.sv] [file join $repo tb tb_dilithium ${top}.sv]
} else {
    set top tb_keccak_sampler
    vlog -sv -work dilithium_work [file join $repo tb tb_dilithium ${top}.sv]
}
vsim -voptargs=+acc -wlf [file join $here stage${DILITHIUM_STAGE}.wlf] dilithium_work.$top +STAGE2_DIR=$here
onfinish stop
if {![batch_mode]} {
    view transcript;view wave
    add wave /$top/clk /$top/rst
    if {$DILITHIUM_STAGE == 5} {
      add wave -divider {Process input and output}
      add wave /$top/input_* /$top/output_*
    } else {
    add wave -divider {Descriptor and absorption}
    add wave /$top/job_* /$top/input_*
    add wave -divider {Coefficient and completion}
    add wave /$top/status_*
    if {$DILITHIUM_STAGE >= 3} {
        add wave -divider {Slot ownership and readback}
        add wave /$top/reserved_o /$top/complete_o /$top/fault_o
        add wave /$top/read_* /$top/response_* /$top/release_*
        add wave /$top/dut/coeff_* /$top/dut/store/count_r /$top/dut/store/state_r
        if {$DILITHIUM_STAGE == 4} {
            add wave -divider {NTT command and DMA}
            add wave /$top/op_* /$top/dut/state /$top/dut/load_index_r /$top/dut/result_count_r
            add wave /$top/dut/ntt_* /$top/dut/s_* /$top/dut/m_*
        }
    } else {
        add wave /$top/output_*
        add wave -divider {Bridge,drain and ownership}
        add wave /$top/dut/owned_r /$top/dut/drain_r /$top/dut/stop_r
        add wave /$top/dut/bridge_valid_r /$top/dut/hash_valid /$top/dut/hash_ready
    }
    }
    log /$top/*
}
run -all
if {[examine -radix unsigned /$top/test_passed] != 1} {
    error "Stage$DILITHIUM_STAGE test did not reach its explicit completion gate"
}
if {![batch_mode]} {wave zoom full}
echo "Run python sim/dilithium/dilithium_vectors.py compare --stage $DILITHIUM_STAGE from repository root for the independent verdict."
