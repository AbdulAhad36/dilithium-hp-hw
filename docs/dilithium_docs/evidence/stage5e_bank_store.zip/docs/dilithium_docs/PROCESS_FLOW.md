# Dilithium processing flow

## Selected first KeyGen direction — LightHD memory/reuse

Final FIPS204 bytes are selected,with level2/3/5 names. The user chose LightHD's
four-bank organization and reuse strategy. The bank foundation passes its tests;
Stage5E now connects sampling,per-context word packing and region ownership;
main-controller scheduling/NTT migration is not implemented yet. Figure2 is the peak
Sign memory map,so complete KeyGen addresses/ownership must be derived and
checked rather than assumed to be fully specified by that figure.

1. Expand a test-supplied32-byte seed into rho,rho-prime and K using the selected
   reference's exact input formatting. The optional shared raw-hash service and
   keygen_seed_collect now pass their focused gate. The tested
   keygen_hash_message builder now emits SHAKE256(xi32||K||L),requesting128 bytes.
   Collect bytes0..31 as rho,32..95 as rho-prime,and96..127 as K(key seed).
2. Sample s1 and retain secret data for key encoding/subsequent signing. Schedule
   s2 once alongside the matrix stream as capacity permits. Use eligible
   Pre/NTT for s1 and retain transformed s1 for reuse across matrix rows.
   For each matrix row i and column j,sample A_hat[i,j] using exact
   row/column/secret nonces. The formatter emits rho||column||row for A and
   rho-prime||nonce_le16 for secrets. s1 uses0..L-1;s2 uses L..L+K-1.
   A_hat is already transformed;do not forward-transform it again.
3. Compute PWM and accumulate the row in transform domain using modular ADD.
   Reuse a64-word accumulator region across columns. Consume bounded A staging
   entries as they are generated;do not regenerate s1 for each row as in the
   superseded four-slot proposal. Prove read-before-overwrite on accumulator reuse.
4. Inverse-transform the row sum,obtain the stored/scheduled s2[i],and add it
   modulo q. Preserve each raw secret until key encoding has consumed it;do not
   overwrite its only copy merely because a transformed cache exists.
5. Power2Round each t coefficient into t1 and t0;encode them using the selected
   byte format. Preserve t0 until the chosen key-output/storage destination owns it.
6. Hash the complete encoded public key to obtain tr;encode the secret key
   with the required seed/hash/secret/t0 fields. Byte order and hash length
   must follow the selected version. Compare complete keys with its reference.

The shared coefficient ADD/SUB/Power2Round unit now passes its isolated tests.
The shared raw hash service,seed/nonce builder and seed collector now pass
focused tests using one real Keccak-sampler helper. Still required:main-top
connection,process/memory routing,byte serializers/key storage and the actual
main-controller schedule. See MEMORY_MAP.md for the selected dimensions and
published Sign regions. The prior four-slot regeneration/ten-slot proposals
are superseded. Extra encoded-key buffers are not silently allocated.

## Current Stage4 sampled-polynomial arithmetic

1. Submit real sampling jobs and wait for successful slot commit using the
   producer/storage flow below. Keep Matrix A marked transform-domain.
2. Present opcode,source slot(s),expected source ID(s) and a new result ID.
   The helper accepts the command after active sampling and old reads retire.
3. Memory validates state/IDs/domain/Pre eligibility and PWM parameter agreement.
   Invalid requests return a held rejection reply without starting the engine.
4. For a valid request,wait for a free destination,lock sources and reserve it.
   Inputs remain stored. The four-slot pool may need an unrelated slot released
   before proceeding;no implicit overwrite or automatic input release occurs.
5. DMA reads A indices0..255,and B0..255 for PWM,with one outstanding read.
   Engine arithmetic uses normal canonical residues;INTT includes its scaling.
6. Write results0..255 into the reserved slot. Wait for engine done,then commit
   the destination and unlock sources. Offer the tagged completion until accepted.
7. Read/consume the completed result and explicitly release slots after their
   scheduled consumers finish. A new NTT job is not loaded while one is active.

Tested mathematical chain:A_hat (directly sampled) and s -> NTT(s) ->
PWM(A_hat,NTT(s)) -> INTT -> coefficient polynomial. Python independently
checks this against schoolbook(inverse(A_hat),s) in Z_q[x]/(x^256+1).
Pre(s) equals NTT(s),and INTT(NTT(s)) equals s exactly. Reset cancels the
whole subsystem during DMA load,core execution or writeback;new jobs recover
with fresh messages,including reusing the same source/result IDs.

This is still a subsystem flow. Full KeyGen/Sign/Verify scheduling,seed/nonce
assembly and remaining process blocks come in Stage5.

## Preserved Stage3 memory transaction

1. Reserve a free polynomial slot on the same handshake that accepts the job;
   capture job_slot_o and actual job_core_o for the future controller.
2. Run the Stage2 SHAKE/sampling flow below. Tagged coefficient writes must
   match the slot owner,index,last and canonical range.
3. Keep the slot WRITING through all256 writes and source drain. A premature
   read returns an error;the last coefficient alone does not commit the slot.
4. Successful external status acceptance commits COMPLETE. An expected error
   frees the slot;reset invalidates all slots and pending responses.
5. Request coefficients by slot/index. A synchronous response carries data,
   job ID,mode,parameter and domain;hold it stable under backpressure.
6. Release the slot explicitly after its scheduled consumers finish. A pending
   read response blocks release. Pool exhaustion stalls new jobs.

The focused testbench drives public reads/releases. Stage4 additionally supplies
NTT compute descriptors and checks DMA/result/commit behavior.

## Preserved Stage2 producer transaction

1. Present the sampling mode,parameter encoding,ID and absorption-message length.
2. Hold the descriptor until ready/valid accepts it;capture assigned core.
3. Feed exactly the declared message on64-bit beats,earliest byte in bits7:0.
   Keccak handles the final partial word using the declared byte length.
4. Keccak absorbs,pads,permutes and produces a tagged SHAKE stream.
5. The shared two-slot registered-credit queue passes data/byte count/core to the matching
   sampler context. Concurrent jobs keep separate parser/carry state.
6. The sampler emits256 canonical23-bit coefficients,with job ID,core,index and
   last. The Stage3 receiver is polynomial memory;the preserved Stage2 test
   still checks the producer stream directly.
7. On sampler stop,the adapter drains/discards surplus,then stops Keccak after
   releasing its held output. It waits for old source tokens to retire.
8. The external status handshake releases the context for a new job.

Invalid parameter3 produces the existing parameter-error status after safe
upstream retirement. A coordinated reset cancels both jobs;partial polynomials
must be discarded. The focused test checks accepted partial prefixes and then
checks same-ID recovery with different messages.

## Implemented versus planned

| Operation | Current ownership |
|---|---|
| Raw absorbed message generation | Stage4 uses test vectors;isolated keygen_hash_message now formats final KeyGen seed/A/secret messages;not connected to main top |
| Raw hash/seed collection | Optional service in keccak_sampler plus keygen_seed_collect;focused seed-to-real-sampler gate PASS;main Stage4 top disables the raw client |
| SHAKE128/256 | Accepted Keccak RTL |
| A/secret/mask/challenge sampling | Accepted sampler RTL |
| Job binding,two-slot credit bridge,stop/drain | controller/keccak_sampler.sv |
| Polynomial allocation and memory writes/readback | controller/memory.sv and keccak_sampler_memory.sv;Stage3 source PASS |
| NTT/INTT/PWM/Pre-NTT | src/ntt/ imported unchanged;controller/keccak_sampler_ntt.sv DMA/source locks/result commit;Stage4 source PASS |
| Modular ADD/SUB and Power2Round | controller/process/poly_process.sv;isolated Stage5A unit PASS,not memory-connected |
| Full KeyGen/Sign/Verify schedules,decompose/hints/encoding | Later controller/process stages |

A is already transform-domain data and will go to operand storage/PWM. Small
secrets can later use ordinary NTT or eligible Pre-NTT with one owner for the
first-stage work. Final FIPS204 is the selected format;complete controllers,
memory scheduling and exact-output checks remain before a full-operation claim.
