# Dilithium reference verification

## Current scope

### Stage5E real sampling into packed banks

New RTL:bank_poly_store.sv and keccak_sampler_banks.sv under src/controller/.
Tests:tb_keccak_sampler_banks.sv and bank_store_protocol_test.sv under
tb/tb_dilithium/. Same single Python script and run.do;the common104-job
stage2_inputs/expected files drive the actual SHAKE/sampler engines.

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST bank_store
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit bank_store
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit bank_store
```

Require DILITHIUM_STAGE5_STORE_PASS,BANK_STORE_PROTOCOL_PASS and DILITHIUM
STAGE5 STORE COMPARE PASS. Output:stage5_store_outputs.txt;comparison and fault
checker logs:stage5_store_compare.log/stage5_store_checker_selftest.log.

Results:104 accepted jobs,88 completed,8 expected errors,8 reset aborts.
23173 accepted coefficients match Python;5792 physical packed writes and5790
acknowledgements are checked. Readback5632 words equals22528 completed-polynomial
coefficients. MEMORY_MAP.md explains aborted prefixes and the two unaccepted
write acknowledgements. All64 aligned regions are filled/inspected,occupied
regions reject replacement until released,and fresh jobs overwrite/revalidate
them. Both contexts and all four modes/three parameters are checked.

Capture:J descriptor/core/region/ID,W coefficient,K92-bit bank write,B write
ack,S external retirement,R checked word response,E rejected read,L release,
A abort,X reset,G protocol-fault gate,F totals. Python independently checks
coefficient values,23-bit lane order,physical word addresses,write acknowledgements,
publication,IDs/domain/bounds metadata,read order,region reuse and exact totals.
It rejects12 intentional corruptions,including removing a physical write.

The companion injects wrong coefficient index,last,value,ID,core;premature or
wrong-ID success;and a257th coefficient. All raise sticky fault without any
successful publication. Reset recovery is checked between faults. Main tests
also reset held successful/error read responses and invalidate stale regions.
These are focused integration checks;no new full-system UVM/coverage/PPA or
full-operation result is claimed. Default Stage4 remains the old all-engine
baseline until NTT DMA/writeback is migrated to the new banks.

### Stage5D LightHD four-bank memory foundation

User selected the published four1024x92-bit dual-port logical banks over the
earlier scalar-pool proposals. Files:src/controller/poly_bram.sv,
src/controller/memory_banks.sv,tb/tb_dilithium/tb_memory_banks.sv. Same Python
script and launcher;no new full-system UVM or standalone .do is added.

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,from sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST bank_memory
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit bank_memory
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit bank_memory
```

Require DILITHIUM_STAGE5_BANKS_PASS and DILITHIUM STAGE5 BANKS COMPARE PASS.
Input:stage5_banks_inputs.txt;capture:stage5_banks_outputs.txt;verdict and checker
logs:stage5_banks_compare.log,stage5_banks_checker_selftest.log. The generated
program has14880 offers:14872 accepted,8 deliberately blocked/canceled on reset.
Of the14872 accepted requests,14864 receive responses and8 write acknowledgements
are canceled by reset. The writes themselves had committed and persist.
Responses comprise9509 exact92-bit reads plus5355 write acknowledgements.

Python keeps a separate(bank,address)->92-bit word model and a pending response
per port. Each accepted read snapshots its expected value;responses must match
ID,port,address,operation and data and occur after their acceptance edge. Write
acknowledgement payload is unspecified and not compared. Reset cancels queued
responses without clearing modeled payload. Recovery reads prove that accepted
writes persist and unaccepted blocked writes did not happen.

The program writes/reads every one of4096 bank words,then tests same-address
read/read,read/write,write/write,independent ports,random traffic,stalls and
reset. Witnesses:73 collisions,4112 same-address dual-read pairs,1031 cycles
with eight accepted requests,3075 request stalls,3034 response stalls,14807
same-edge response replacements. Twelve capture corruptions are rejected.
Capture records:J accepted request,R response,A reset-aborted response,X reset,
F totals. All prior six integration/process/hash gates were freshly rerun PASS.

The bank primitive is not an ownership controller. This gate does not prove
correct KeyGen scheduling,packing/Pre regrouping,physical BRAM inference or
LightHD's32-cycle NTT input loading. The legacy Stage4 top remains unchanged.
Current NTT ports are scalar23-bit,so wide memory alone does not provide that
loading rate. MEMORY_MAP.md lists migration work and the inspected paper regions.

### Stage5C shared hash service and RTL seed collection

Files:the optional RAW_SERVICE route in src/controller/keccak_sampler.sv,
src/controller/keygen_seed_collect.sv,and tb/tb_dilithium/tb_shared_hash.sv.
The existing single Python script/launcher now support unit shared_hash.
Stage3/4 wrappers tie the route off;their main ports/capacity are unchanged.

```powershell
# Repository root
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST shared_hash
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit shared_hash
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit shared_hash
```

Require DILITHIUM_STAGE5_SHARED_HASH_PASS and DILITHIUM STAGE5 SHARED HASH
COMPARE PASS. Generated input:stage5_shared_inputs.txt;capture:
stage5_shared_outputs.txt;verdict/selftest:stage5_shared_compare.log and
stage5_shared_checker_selftest.log. These are local component vectors,not
official full-operation NIST vectors.

Measured:26 accepted commands,18 raw hash requests,7 completed sampled
polynomials,7 seed results(including1 expected parameter error),3 reset aborts.
The18 raw requests are9 expansion attempts plus9 direct finite hashes;the
rejected parameter case issues no hash. Six expansion results succeed;one
additional128-byte hash finishes before its held seed result is reset.
Reset-aborted input and output attempts contribute no completed seed result.

**1699 SHAKE bytes** match hashlib:6 successful expansions*128 +16 accepted
bytes before an output reset +128 bytes before a held-result reset +787 direct
raw bytes. The partial-input reset contributes no hash bytes. **1792 sampled
coefficients=7*256** match the independent sampler model. Three A/secret pairs
cover all parameters,and one additional A job runs alongside a raw job.

Crucially,the sampling message formatter consumes rho/rho-prime from the actual
RTL collector via the harness's seed-cache registers. Expected Python seed
material is used only for checking,not to drive the sampler. The main controller
and persistent polynomial/key-storage schedule are not implemented by this test.

Cases include empty/partial/multi-rate absorption,output lengths1/15/16/17/
32/128/137/169/272,both SHAKE modes,both physical cores,two raw jobs,raw+sampling,
simultaneous request arbitration,held raw completion while a peer finishes,
held seed results and ID reuse after reset. Resets target two accepted input
words,one accepted output beat,and a complete but unaccepted seed result.
Ownership overlap witnesses:mixed raw/sampling67 cycles,two raw333 cycles.
Held raw output/completion/seed-result witnesses:60/298/44 cycles;one raw-priority
arbitration edge is observed. These are ownership/workload observations,not
measurements of simultaneous permutation throughput.

Capture:J accepted command,R raw descriptor,W raw absorption,O tagged raw byte
beat,D raw completion,Z collected seed fields,S sampling descriptor,P sampling
absorption,C coefficient,T sampling status,A abort,X reset,F totals. Python
checks live core ownership,exact bytes/fields/order,completion boundaries and
all totals. Only output_bytes low bytes are compared;SHAKE rate boundaries can
produce short beats before the next permutation. Twelve corrupted captures
(raw data/core/ID/size,seeds,coefficients,error,completion and token) are rejected.
No new main-top PPA,netlist,full-operation or integrated coverage claim.

Frozen evidence:evidence/stage5c_shared_hash.zip with
stage5c_shared_hash.sha256.99 members preserve current RTL/references,all six
focused captures/verdicts and the then-current docs. CRC,manifest/member bytes
and archive SHA256 were verified. The mutable PROCESS_BLOCKS.md subsequently
corrects its shift-range explanation:valid t1 shifted by13 already fits0..q-1;
this documentation correction changes no RTL or measured result.

### Stage5B final-standard KeyGen message formatting

The chosen algorithm is final FIPS204 ML-DSA-44/65/87,called level2/3/5 in our
interface/docs. This gate checks only seed expansion and the absorbed matrix/
secret sampling messages,not full KeyGen keys or sampled coefficients.

Files added:src/controller/keygen_hash_message.sv and
tb/tb_dilithium/tb_keygen_hash_message.sv. The existing single Python script,
launcher and Quartus source list are extended. No standalone engine is changed.
Normative rules:FIPS204 Algorithms6,32,33;local sign.c/symmetric-shake.c agree.
These are generated component vectors,not published NIST full-operation vectors.

Flow:Python generates commands -> RTL formatter -> existing dual-Keccak in the
focused test -> stage5_hash_outputs.txt -> separate Python hashlib comparison.
Expected bytes are not used by RTL. The TB additionally checks every accepted
absorption word against the independently generated message. SHAKE samples use
rho/rho-prime derived from the fixed test seed for the selected parameter set.

```powershell
# Repository root; needs GCC for the other Stage5 process-reference gate.
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,working directory sim/
set DILITHIUM_STAGE 5
set DILITHIUM_TEST hash_format
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit hash_format
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit hash_format
```

Require DILITHIUM_STAGE5_HASH_FORMAT_PASS and DILITHIUM STAGE5 HASH FORMAT
COMPARE PASS. Measured2026-10-20:165 accepted,162 message completions including
14 expected errors,3 reset aborts;883 absorption words,5888 exact SHAKE bytes.
The148 successful hashes are12 seed expansions and136 sampling-message hashes:
102 matrix coordinates(16+30+56) and34 secret nonces(8+11+15).
Twelve seed expansions include3 same-ID reset recoveries plus9 pattern/parameter
cases. Output bytes=12*128+136*32=5888. Absorption words=12*5+102*5+34*9+7
aborted-prefix words=883. Seed output slicing is rho32,rho-prime64,K32;an RTL
collector is now tested by Stage5C above;the Stage5B gate itself only checks bytes.

Errors cover parameter3,opcode3,out-of-range row/column and secret nonces.
Resets hit a held descriptor,after two absorption words,and a held message
completion;all coordinate/hash state resets together. Request/input/done/hash
stalls observe111/288/757/671 cycles;all held offers stay stable. The command
ports are poisoned after acceptance to check snapshots. Both physical core
tags are observed. Twelve intentional checker corruptions are rejected.

Capture records:J command,D descriptor,W absorption word,V SHAKE beat,S message
completion,A abort,E finished hash/error case,X reset,F totals. Python checks
ownership,ordering,bytes,IDs,errors and exact totals. Sampling descriptors retain
output_len0;the test service substitutes32 bytes only to bound the hash test.
Continuous-XOF sampling/drain remains covered by the earlier connected gates.
No main-top connection,full-operation key output,new coverage or PPA claim.

To return to the arithmetic unit:set DILITHIUM_TEST process with stage5.
The default connected gate remains DILITHIUM_STAGE4.

### Stage5A process-unit reference and execution

The algorithm choice is now final FIPS204;these ADD/SUB/Power2Round rules are
also common to the earlier candidate versions. The same Python file generates
stage5_process_inputs.txt with10349 arithmetic/framing cases. During prepare,
GCC builds tb/tb_dilithium/process_reference.c plus the unchanged local rounding.c
under sim/dilithium/reference_build/. Its exhaustive Power2Round reference
check and Python/C agreement appear in stage5_c_reference.log. The C program
uses the original power2round function;no RTL math is called.

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,from sim/:isolated process gate,not complete Stage5/KeyGen
set DILITHIUM_STAGE 5
set DILITHIUM_TEST process
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5
python sim/dilithium/dilithium_vectors.py selftest --stage 5
```

Require DILITHIUM_STAGE5_PROCESS_PASS and DILITHIUM STAGE5 PROCESS COMPARE PASS.
10349 accepted cases produce10346 exact outputs,3 reset aborts and13 expected
error outputs. C separately checks8380417 canonical inputs;RTL checks9208 dense
rounding points plus modular arithmetic/error/transport cases. Error outputs
count among the10346 compared beats,not extra transactions.12 checker corruptions
are rejected. Source/reference/C-adapter hashes bind the generated file and capture.

stage5_outputs.txt records J(accepted case),P(error,residue,high,signed low,
packed low,ID,index,last,opcode),A(reset abort),X(reset),F(totals). Separate Python
comparison verifies exact arithmetic,metadata,elastic ordering and totals.
GCC is needed only by prepare;Questa's freshness check does not compile C.
The default run and Python --stage remain4 for the current connected subsystem.
No complete KeyGen or official full-operation vector comparison is claimed.
Create-only evidence/stage5a_process.zip and stage5a_process.sha256 preserve
the audit manifest,current source/references,test inputs/captures/verdicts and
shared docs. Its immutable RESULT.txt records the then-pending decisions;
the byte-format choice is resolved above,while key storage remains open.

Stage4 now checks real Keccak -> sampling -> memory -> NTT -> memory. It uses
the same Python script and locally generated subsystem vectors;these are not
official full-operation Dilithium/ML-DSA vectors. Main default commands:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

```tcl
# Questa Transcript,from sim/
set DILITHIUM_STAGE 4
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 4
python sim/dilithium/dilithium_vectors.py selftest --stage 4
```

Preparation writes the shared sampling files and stage4_expected.txt with26
arithmetic polynomials. Python imports the unchanged mathematical functions in
FIPS204_NTT/ntt_vectors.py. Direct polynomial evaluation/inverse evaluation
provide transform expectations;independent schoolbook multiplication checks
the Matrix A/secret product chain. The SV test does not generate expected
NTT values using the DUT or a mirrored RTL function.

stage4_outputs.txt records J/W/S sampling lifecycle,O(compute descriptor),
V(reservation decision/destination),T(each DMA value with source slot/ID/index),
K(each NTT output/index/last),D(public completion),B(reset abort),R(stored
readback including domain),E(rejected read),L(release),X(reset) andF(totals).
The separate Python checker maintains slot ownership and source locks,
derives eligibility from actual expected values,checks every transfer and
all metadata,and requires exact lifecycle/totals. It computes each operation
again from the expected source polynomials;captured RTL values are never
used as the golden input to later expected arithmetic.

PASS:16 sampled jobs,50 commands,30 successes,17 rejects,3 reset aborts;
4096 sampled values,9745 DMA values,7713 result values and11776 stored reads.
Result arithmetic:30*256=7680 completed values plus33 accepted before reset.
All16 source polynomials and30 completed results are read in full:46*256=11776.
The three aborted destinations never publish complete results. Reset also
invalidates their source slots;43 explicit releases and6 invalid reads pass.
12 checker corruptions cover output,DMA value/ID,stored value/domain,source ID,
reservation/completion,missing output/commit,stale token and extra read.
Logs:stage4.log,stage4_compare.log,stage4_checker_selftest.log.

Relocated standalone NTT source UVM passes748 jobs/191488 values;18 original
standalone Python cases/4608 values match. Logs under sim/ntt/import_* identify
this relocation separately from historical branch evidence. No fresh standalone
or integrated synthesis/netlist run was made in this functionality-first stage.
Create-only evidence/stage4_subsystem.zip and stage4_subsystem.sha256 preserve
the imported module package,current integration source/reference/tests,
prepared projects,source captures/verdicts and universal docs. MANIFEST.csv
hashes each member;RESULT.txt states functional scope and unrun PPA/netlist work.

## Preserved Stage3 scope and commands

Stage3 extends the same one-script flow to real sampled polynomial storage.
Select DILITHIUM_STAGE=3 to run tb_keccak_sampler_memory. Inputs and expected
polynomials remain stage2_inputs.txt/stage2_expected.txt for both stages;these
names preserve the original generated format. Stage3 writes a distinct
stage3_outputs.txt with slot lifecycle and stored readbacks.

Current commands after `prepare`,from the Questa GUI Transcript in sim/:

```tcl
set DILITHIUM_STAGE 3
do dilithium/run.do
```

Then from the repository root:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 3
python sim/dilithium/dilithium_vectors.py selftest --stage 3
```

Require DILITHIUM_STAGE3_CAPTURE_PASS,MEMORY_PROTOCOL_PASS and the independent
DILITHIUM STAGE3 COMPARE PASS.104 jobs pass:88 complete,8 expected errors,
8 aborts;23180 exact writes (22528 complete+652 aborted-prefix values),22528
exact stored readbacks,88 releases,99 invalid reads and5 integrated resets.
All24 successful mode/parameter/actual-core combinations are present.
The three-slot fault companion separately proves8 protocol-fault cases,bounds,
pipelined read responses and reset of a stalled successful response.

Stage3 capture records:J(case,core,slot,ID),W(case,core,index,value,last),
S(case,core,status),A(case,core,prefix count),R(case,slot,index,value,ID,mode,
parameter,domain),E(slot,index rejected),L(slot release),X(reset),F(totals).
Python maintains its own slot/live-job model;it checks allocation,publication,
every write/read,release/reset and exact totals against the independent golden
polynomials.12 deliberate corruptions cover data,slot,index,ID,mode,parameter,
domain,missing read,duplicate job,missing commit,stale token and extra read.
All are rejected. stage3.log,stage3_compare.log and stage3_checker_selftest.log
record the verdicts. No official full-operation vectors or full UVM claim.
The create-only evidence/stage3_subsystem.zip and stage3_subsystem.sha256
preserve current RTL,testbenches,independent script,vectors,captures,logs,
universal docs and prepared Quartus files. MANIFEST.csv lists each member's
SHA256. RESULT.txt distinguishes source verification from unrun Stage3 synthesis.

## Preserved Stage2 flow

Stage2 checks the real SHAKE-to-sampling connection. The vectors are generated
locally;they are not official full-operation NIST vectors. The absorbed messages
include deterministic seeded bytes and arbitrary boundary lengths. This does
not validate full KeyGen/Sign/Verify seed expansion,encoding or signing randomness.

One script,`sim/dilithium/dilithium_vectors.py`,provides prepare/check/compare and
checker self-test. It uses Python hashlib SHAKE128/SHAKE256 and the unchanged
independent scalar sampler reference in `FIPS204_SAMPLER/sampler_vectors.py`.
No RTL function or SV golden result is used to generate the expected polynomial.

## Simple flow and commands

```text
Python messages -> SHAKE in hashlib -> independent sampling -> expected file
       |
       +-> input file -> real Keccak+sampler RTL -> captured output file
                                                      |
                          separate Python compare ----+-> PASS/FAIL
```

From repository root:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

From `sim/` in the Questa GUI Transcript:

```tcl
set DILITHIUM_STAGE 2
do dilithium/run.do
```

From repository root after capture:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 2
python sim/dilithium/dilithium_vectors.py selftest --stage 2
```

| File under sim/dilithium/ | Producer and meaning |
|---|---|
| stage2_inputs.txt | Python:case index,ID,mode,param,abort flag,byte length,message hex |
| stage2_expected.txt | Python:expected status/abort/count and canonical coefficients |
| stage2_outputs.txt | Simulator:J descriptor,C coefficient,S status,A abort,F totals |
| stage2.log | Saved headless Transcript;GUI displays its own Transcript |
| stage2_compare.log | Separate Python verdict |
| stage2_checker_selftest.log | Deliberate-corruption rejection verdict |
| stage2.wlf | Wave database;GUI launcher adds public and bridge/control waves |

The two input/golden files carry the same SHA256 token,bound to their contents,
reference and actual source/test/launcher files. The launcher checks freshness
before compilation;comparison recomputes it. Re-run prepare and capture after
source changes. Do not compare an old capture against a different token.

The simulator checks values/index/core/ID/last and status against the generated
golden file,plus independent protocol/ownership assertions. It requires an
explicit test_passed flag after all104 jobs. A fatal or watchdog without that
flag makes the launcher fail. The separate Python checker verifies all records
and exact totals again;process exit alone is not a passing result.

## Measured source results

104 accepted jobs:88 complete polynomials,8 expected invalid-parameter errors,
8 reset aborts. Current two-slot bridge:23089 coefficients match:22528 from88*256
complete polynomials plus561 accepted aborted-prefix coefficients. All24 combinations
of4 modes,3 valid parameters and2 contexts are observed in successful jobs.

Four reset targets reach both owned contexts:full blocked bridge,held Keccak output,
drain pending,and externally stalled status. Recovery reuses the same IDs with
different messages. All12 checker corruptions are rejected:value,index,core,
job ID,last,status,case,footer,missing coefficient,duplicate descriptor,extra
coefficient and stale token.

The queue reaches full occupancy for34198 observed cycles and simultaneous
push/pop128 times. Status checks both queued tags before retirement. The
initial one-slot workload checked23081 values;that historical capture remains
in evidence/stage2_subsystem_initial.zip. Changed abort timing explains the
different number of checked prefix values;all88 complete polynomials stay256
coefficients long. See THROUGHPUT.md for workload cycles and timing-trial status.

These are focused source tests. Full Dilithium UVM coverage,full-operation
official-vector checks,new integrated netlist simulation and FPGA testing remain
future stages. The standalone Keccak NIST suite is separately documented.
