# Agent onboarding - integration

ACTIVE7C.4 full MAIN210 now running in work_lighthd_load. Hidden PS19200,
runner reference_build/stage7c4_main_runner.ps1;progress main_full.log,
final main_runner.log/main_runner_error.log. Frozen token
6270b2cad0147c256d8eb84798cef422b8d419201bbcab96243b0eaab78ffe61.
DO NOT edit lighthd RTL/Python/tb_lighthd_main/token inputs or duplicate this
library. Runner does full210 compare then main_selftest. Main protocol88
already passes29errors/3normal invalids/12resets/44published recoveries with
44blocked busy probes;148704exact prefix/full bytes. Shared-response test
found KeyGen IDLE erroneously raw-ready before its first use;fixed by gating
raw.output_ready to SEED_CMD..SEED_WAIT. All active KeyGen behavior unchanged.
Do not drop guards or add wide response masks to hide the issue.
Parallel secondary rollup in separate work_lighthd,exec77360,does fresh main9,
Verify-input105 and Hint106 plus independent compares/checker18. Its progress
unit_rollup.log,outputs unit_compare.log. Both libraries have distinct output
files;only read shared main fixtures. Main210 source/fixtures stay frozen.
Latest main9 prior fix passes27700NIST bytes/3VF digests;final secondary redo
includes the idle-gate fix. Production dilithium_fpga/QSF/main UVM STILL7B.9.
NEXT:finish actual210+checker and secondary gates;final docs/evidence before
production selection/main UVM and fresh same-CycloneV PPA. No commit/branch.

ACTIVE7C.4 compact main construction. NO native process active. Verify45
passes9valid/36invalid plus35 exact independent equation digests at token
c890a53e517904f82b1b70920832523ad9e6c44901626b8066be1e8ced8cb62d.
Frozen create-only stage7c4_verify_official_initial.zip/SHA
4ccad7b198fe7130c26583c414c07b934a2c904e05851f56ea0c9c1baf17aae2;
137members2789718bytes;54prior archive pairs verified. No production switch.
New lighthd_verify_input qualified105cmd/44rawcontexts/13encoding-invalid/
39errors/9resets/48832exact physical words (historical token95ab013...);
same-ID reset recoveries use DIFFERENT valid PK/SIG data. HintUnpkg106cases/
21510x4 masks/9resets/18checker faults pass (historical tokencd9f59...).
Later full-Verify Python/source additions make these broad fingerprints stale;
refresh those unit gates after source settles,never retag captures.
New lighthd_verify uses one fixed row accumulator:MAC Ahat*zhat,CT1 product,
SUB before INTT,UseHint+shared BitPkg. Bank0upper=T1hat/tail=scratch;bank2low=
Zhat/tail896=Chat;bank1[64..575]=hints,[576..703max]=packedW1;bank3=A ring.
These Verify lifetimes are inferred on the SAME four banks,not extra RAM.
Parent raw response checks MUST gate raw_phase:input child owns/validates
PK-hash responses;first diagnostic exposed and corrected that ownership bug.
Diagnostic3 cycles11282/16829/27414;no PPA claim. Full45native overlaps248832
sampling/NTT cycles,peak ring14(of16 atlevel5;9limit levels2/3).
src/controller/lighthd_dilithium.sv now CREATED but NOT compiled/qualified.
Same51 production port groups;one physical lighthd_datapath,three compact
controllers,5-state owner FSM;command metadata latched directly by child,
no extra seed/context copies. Old dilithium_fpga/QSF/main UVM STILL7B.9.
NEXT:add single-Python combined75KG/90Sign/45Verify fixtures+comparator and
tb_lighthd_main.sv;interleave operations,first diagnostic9 then full210.
Use actual shared datapath and public streams,host stalls,foreign-stream
isolation,busy/retirement gates. Then full-controller reset/error/checker
tests BEFORE selecting production replacement. No commit/branch/Stage8/PPA.

ACTIVE7C.4 compact Verify reconstruction begins. Stage7C.3 frozen create-only:
stage7c3_sign_qualified.zip SHA256
d35d7064499a80ffc3974eac04dbabf266837d51974667a214bd586d93a2e8b0;
173members7804044bytes;53prior archive pairs verified. All final Sign90/69/
checker62 and KG75/20/checker25 pass;see qualified archive/RESULTS.json.
First C4 block is bounded sparse hint decoding for streamed signature input,
then compact PK/SIG load/hash/norm path and row-local Verify equation.
No new source gate/PPA/current-main coverage until measured. Production7B.9
still unchanged. Adding C4 source/Python makes the broad Sign fingerprint
stale by design;do not retag old captures. Prior qualified milestones remain
scoped to their frozen sources. Keep same FPGA/6.757ns/hold/public streams.
No commit/branch changes. Only one process per library;no native job active.

LATEST7C.3 functional qualification COMPLETE. No native process active.
Sign token b5c7cf95c4c0cce20bac03c4615e96c1116b023d4373ae18893c3b8bbedb3a22:
90official signatures310680bytes,all attempt hashes/rejection reasons PASS.
Protocol69=24errors/12targeted resets/33same-ID recoveries with33busy probes;
113916 full bytes/64reset-prefix bytes exactNIST. Checker62/62 corruptions
reject. Actual shared decoder71packets/29invalid/6resets cleanup re-passes.
KeyGen75/protocol20/checker25 freshly pass after shared decoder changes;
scoped token2348b298abbc9c680cc023a767d41673ab8cad5ce19c44eaddfa65f4e6d137ea.
Public run.do Stage7 lighthd_* selectors now pass batch Sign diagnostic3,
Sign protocol69 and KG protocol20. Inputs automatically prepared;comparison
is separate. Completion gate reads bench footer,not optimized-away counter.
GUI access/wave setup retained,but not visually inspected. Root cwd retained
while simulation loaded (Questa prohibits cd until quit-sim). Single Python.
Sign CSV90:phase sum+1=total;level2/3/5min19118/28738/43160,max240198/266678/
313329,means69203.37/81817.80/131553.10. No new main-PPA/UVM claim. Main/QSF
still7B.9;do NOT call full reconstruction complete. Next7C.4 Verify/main.
Freeze create-only stage7c3_sign_qualified.zip/SHA before C4 source edits.
Initial90 archive97434a67e26a9936b1272a586ead0d69706d92e09a64b26fc5e88c6a0f4a9f9f
is immutable. Earlier active-process entries are historical/superseded.
No commit/branch/cleanup/clock or hold changes/netlists/Stage8 authorized.

ACTIVE7C.3 full Sign90 native run in work_lighthd,exec59763,vsimk2596.
Do NOT edit current lighthd RTL/main Sign bench/Python/token inputs or start
another work_lighthd process until completion. Diagnostic3 matches10356 NIST
signature bytes plus all attempt hashes under token
f0ab7bf11d3e944b637cc0f65040bdbbe2362e5086bcaf2f00751a5b736cd36f.
New tb_lighthd_sign_protocol.sv qualifies69 commands(24errors/12resets/33valid
same-ID recoveries with33 busy probes) in separate work_lighthd_sign_protocol.
Independent Python diagnostic matches113916 full bytes/64 reset-prefix bytes.
Partial-load reset explicitly requires decoder32..255 committed;initial trial
had a weaker phase trigger and is preserved under reference_build,not final.
Protocol bench is outside current full-run fingerprint;add it and protocol
compare/checker commands to the SINGLE Python AFTER current90 completes,
then fresh final90/protocol runs. Initial+acc full run stopped after31cases;
not accepted. Its log/capture retained under reference_build. Restart uses
same sources/fixtures/assertions with no broad +acc,around4x faster. Current
first-case23 attempts progresses normally;100k messages are not a hang.
Main remains7B.9. No replacement-main PPA/coverage/complete-replica claim.
No new PPA/replication-complete/main-UVM claim;no commit/branch change.

ACTIVE7C.3 compact Sign construction.7C.2 paired/early-A KeyGen qualifies:
75 official keypairs433600bytes,protocol20 (9valid/3reject/8reset prefixes),
checker25 all PASS. Token1648e985aacec89c00b32feabbf3e70cae6362b758bc6501c0c2580d7b67c742.
Immutable stage7c2_keygen_paired_schedule.zip/SHA
66a8fc799bc0ce65b85d56f2437a75c93daa89bfd5231a772d2ba5104cd1d7fd;
71members1661899bytes;50prior archive pairs verified. Initial/qualified
pre-refinement archives also retained.75cycle ranges8653..8818,15088..15222,
24301..24561;averages8723.04/15144.16/24438.12. All phase sums+1=total.
88533 secret-phase overlap cycles/368768aggregate,peakAring4of9. Still above
paper cycle totals;matrix waiting dominates. No replacement-main PPA/coverage.
No native process active. Current main/QSF still7B.9;do not call it replaced.
New C3-only modules were outside the exact C2 compile/fingerprint boundary:
lighthd_load_decode (shared BitUnpkg+manual writer route) focused71packets/
29invalid/6reset recoveries/3472RAMwords;sign_input135cmd105complete published
SK loads/21reject/9resets PASS independent integer-unpack diagnostic;hintpkg
43packets/6algorithmic rejects/10format errors/3cancel/3reset PASS. These are
focused/source-only diagnostics until the single Python gains final C3 gates.
Next connect decode route to SAME hash_sampler writer/regroup/physical banks,
then implement full Sign FSM and rejection loop with shared Process/MHint
hint-suffix callbacks. No commits/branch changes/Stage8. Keep same FPGA and
6.757ns,public streams and FIPS204 levels2/3/5. Preserve all checkpoints.
Do not stop after key loading;full Sign90 and Verify45 remain authorized.

ACTIVE7C.2 compact KeyGen full75 official run,hidden PS11972. Source token
1ef5ea62a260e3acc7709ddb744ee19d54236c99b41d42940510c85eb37417fe.
Do not edit token inputs/new lighthd_ RTL/bench/Python or launch another
work_lighthd process until it finishes. Logs stage7c2_keygen_full.log/status.log/
compare.log under sim/dilithium. Current main/QSF remains old7B.9 deliberately;
replacement Sign/Verify/main NOT complete. New lighthd_keygen + sole physical
lighthd_datapath implement fixed roles,9-slot A ring,early secret Pre-NTT,
A/s2 producer interleave,row-local fused MAC/INTT/ADD/P2R,packed PK then shared
SHAKE tr64 and streamed SK through ONE shared BitPkg. Diagnostic cases0/25/50
PASS exact complete published NIST PK/SK;latencies10261/17263/28474 cycles
under measured host stalls,not paper-cycle equality. Peak A ring2 and12621
aggregate NTT/sampling overlap cycles across diagnostic3. No PPA/coverage claim.
Recent foundation:hash/sampler/actualRAM104cmd88polys/8reject/8resets plus3raw
SHAKEs PASS independent Python. Process DMA64cases/11008coeff/464packedRAMwords,
all5 stream formats,3negatives/3reset-recoveries PASS. Sampler writer uses SAME
B-port stream for both contexts via tagged write mode2 (reads mode2=Pre);
memory adds live write_address bus. Atomic read->write renewal retains owner
on in-place NTT;different-bank output lanes reserved BEFORE compute start.
Old C1 captures predate latest added source/API refinements;fresh rollup is
still needed after sources settle. No old capture retagging. Continue complete
published reconstruction;do not stop after KeyGen. No commit/branch/Stage8.

ACTIVE7C.1 foundation reconstruction in progress. Current main has NOT been
replaced/requalified. No main PPA claims. Focused gates:direct memory28commands/
6208writes/10661reads/max8physical requests;Process exhaustive all8380417
canonical inputs at all3levels;BitPkg125packets;BitUnpkg89packets/29invalid/
6reset recoveries. Packed sampler144jobs passes independent Python28672 full
valid coefficients plus checked error/reset prefixes,448regrouped words;
legacy scalar pin behavior preserved. Direct NTT160cases/40960coefficients
pass independent Python through actual four-bank RAM/router,with10240other-
client writes ALL overlapping active compute and exact readback. New files
have lighthd_ prefix under existing src/controller folders;verification refs
stay under tb/. No engine arithmetic changed. NTT BANK_IO=1 streams first
stage32pairs and direct final writes;PWM fuses accumulator via existing BF.
Core inclusive busy counts267/267/75/235 (FNTT/INTT/PWM/Pre);do not confuse
start-to-done intervals266/266/74/234 with paper counting conventions.
Next qualify packed sampler writer on same fabric,shared Process DMA,then
compact KeyGen. Source fingerprints must include new connected RTL/benches;
refresh fixtures/captures after edits,never retag old results. Only one
Questa process may use work_lighthd. No native job active at this handoff.
Standalone Process fit ONLY:1561placed ALMs/1038regs/0DSP,Fmax102.52MHz;
this is not whole-main PPA and still fails6.757ns. Full reconstruction and
later timing work remain authorized;do not stop at a foundation-only report.

ACTIVE Stage7C:USER EXPLICITLY orders full published LightHD controller,
memory and Process reconstruction,then improvement/area reduction. This
SUPERSEDES the narrower Verify-path-only next step below. No commit/branch
change. Preserve immutable7B.9 archive and current working/user files. Keep
same Cyclone V/6.757ns/hold rules and final FIPS204 levels2/3/5/public streams.
Read paper Figures1/2/5/6/7 and SectionsIII/IV;visual inspection completed.
Required:fixed bank-role lifetimes;independent A/B port scheduling;row-local
PWM/MAC+inverse+process;shared x4 process/packing;A-ring/early sampling/NTT
overlap;cached secret transforms;one rejection loop. Replace general allocator/
lease/helper snapshot control with compact direct scheduling,not rename it.
Existing NTT CORE is four-BU/three-FIFO,however its current integration adapter
is scalar23bit/beat;paper's wide32cycle loading needs a qualified bank adapter.
Retain verified engine arithmetic;qualify any new direct-bank interfaces.
Current main is still7B.9 until replacement actually passes end-to-end gates.
No new PPA/replication-complete claims yet. Use universal DILITHIUM docs/plan.
Paper lacks full FSM truth tables:implement every published structural/schedule
feature;mark inferred details and FIPS-format adaptations explicitly. Fig7's
z caption/body have s1/s2 and k/l typos;FIPS/C reference defines mathematics.
Temporary PDF runtime/renderings are ignored under tmp/,not project dependencies.

LATEST Stage7B.9 COMPLETE:approved production top now source-qualified AND
successfully routed on SAME Cyclone V. Full compile/ASM/STA exit0;strictly
scoped final report_full analysis exit0. Actual placed[A]ALMs51162/56480,
5306LABs,47735registers,62M10Ks,27DSP,416589block bits. NOT the headline
packing estimate. Four-corner worstFmax23.97MHz/slow0C,setup-34.965ns/slow0C,
hold+0.099ns/fast0C. Setup endpointTNS worst-705626.710ns/slow85C;holdTNS0.
148MHz/6.757ns target FAILS;no clock/hold relaxation or user metric acceptance.
Criticalpath:Verify equation lane_r->Decompose/UseHint->shared request->Bitpkg
bits_r,23logic levels/40.962ns data delay. Next Stage7C targets that path,
first lane selection/arithmetic-width proofs,then explicit pipeline/schedule
proposal if needed. Do not advance to Stage8 or hide timing with constraints.
All75RTL/main UVM/QSF source token1011eeaaaa7947e5ef646419987d3dcbd3c0ec62f2c96fd5ef7a97cd931489e6
remains unchanged since capture. Original74RTL exact7B.7;wrapper stateless.
Main33/byte0 negative PASS;30 timestamps/all latency CSV fields exact7B.7.
Functional121/170;module316708/397445,package14/14,overall316722/397459=79.69%.
Memory comparator9318041cycles/2579302writes/858082reads. Independent reference
prepare and final freshness PASS. Final FSM queries count8main/28KeyGen/
16Sign/16Verify,not the initial broad state-array matches. Required engine,
sampler,writer,decoder and Sign scan bits retained. No process remains active.
Frozen create-only evidence:stage7b9_production_top_baseline.zip/SHA under
docs/dilithium_docs/evidence;262members/9335855bytes;48prior SHA pairs verified.
SHA256:3b468cd66c2b449e68991c4d5572820597c019c0ea390b3b23640381b140505b.
All manifest hashes and current75RTL bytes verified. Do not overwrite archives.
No7C source optimization started,no commit/push/branch/netlist/FPGA/security
signoff. Earlier entries historical and superseded by this completed handoff.

ACTIVE Stage7B.9:USER APPROVED production top,debug retained for verification.
Added src/controller/dilithium_fpga.sv;all74 previous RTL remain EXACT7B.7.
Wrapper hardwires FULL_KEYGEN/ENABLE_SIGN/ENABLE_VERIFY=1. Production interface
51signals/1027bits inclclock,1026 virtual nonclock bits. Internal seed/debug/
occupancy1324bits remain in original dilithium core and standalone benches.
Main UVM now instantiates ACTUAL production top;observes memory/owner/legacy
guard status internally. No fake external debug stimulus or credit;170 bins
unchanged. QSF main top=dilithium_fpga;75sources;old top parameter assignments
removed because wrapper enables all3 operations. Clock/physical options unchanged.
7B.8 fitter trial ABORTED,not failed/accepted,on approved interface switch;
evidence stage7b8_routability_trial_aborted.zip/SHA
a8a3564f6be5ef0332b9ae881a618e80a073c2c004a7351636fc90965a8251d0.
Next actual-production main33/negative,independent fixture refresh and full
compile. No old source/PPA retagging. Keep6.757ns/same FPGA/hold rules;no
commit/branch/netlist simulation. Earlier entries superseded.
Interrupted production runs were found stopped after13/33 scenarios and early
fitting,without completion evidence. Partial logs/captures preserved in ignored
sim/dilithium/reference_build/stage7b9_interrupted_20261025/;not accepted results.
Unchanged-source restart:hidden main33/negative PS17552;full compile PS10072.
Reference preparation completed successfully and was not duplicated. Main token
1011eeaaaa7947e5ef646419987d3dcbd3c0ec62f2c96fd5ef7a97cd931489e6;
legacy prepared957955980feba83cd419421c1432c291476636f612e5b4007ef90b4ae8c9af11.
Production-source qualification COMPLETE:full33 UVM30 checked completions/3
resets,zero UVM errors/fatals. Current-token negative rejects byte0 with zero
checked outcomes/0of170 bins. Memory trace matches9318041 cycles/2579302 writes/
858082 reads. All30 timestamps and every latency CSV field EXACT7B.7.
Functional121/170;module316708/397445,package14/14,overall316722/397459=79.69%.
Final main/reference freshness pass. No Questa remains active. Full compile
PS10072/quartus_fit16572 STILL ACTIVE;no production-top routed PPA yet.
Do not edit token inputs or launch duplicate project processes while fitting.

ACTIVE Stage7B.8:fitter-only aggressive routability on exact7B.7 RTL.
7B.7 frozen:stage7b7_aligned_decoder_route_failure.zip/SHA
a10545d4ec8125bb3ca6fc1c43999f8a19f1d8d51aca9450d19cbb21d13055a3;
265members/14903977bytes;46 prior SHA pairs verified. Source33 UVM/decoder383/
current-token negative/37 checker faults PASS;all30 latency rows exact7B.6.
CLI override FITTER_AGGRESSIVE_ROUTABILITY_OPTIMIZATION=ALWAYS;read settings ON,
write settings OFF. QSF/SDC/RTL unchanged during trial. One hidden runner
sim/dilithium/reference_build/stage7b8_quartus_runner.ps1,progress in
sim/dilithium/stage7b8_quartus_runner.log. Do not launch duplicate project jobs.
If routed:manual ASM/STA/report_full retained-bit/four-corner reports follow;
then persist matching QSF recipe,document source-vs-physical fingerprints.
Do not retag old captures or call manual steps a new full-flow compile.
No accepted routed PPA yet. Keep same FPGA/6.757ns/hold rules;no commits,
branch changes/netlist simulations. Earlier process entries are historical.
Active hidden PS4656/fitter8952. A separate USER CHOICE is pending on a
production wrapper exposing only normal command/data/status while keeping
debug access internally/for verification. Existing top2351 bits inclclock;
1324 debug/seed/occupancy bits would become internal,leaving1027 production
port bits. These are NOT area estimates. Do not implement that interface
change without the reply;the current fitter-only trial continues independently.

LATEST Stage7B.7 source COMPLETE:33 UVM30 completions/3resets,zero errors;
functional121/170;module315810/396415,package14/14,overall315824/396429=79.67%.
All30 timestamps and every latency CSV field exactly equal7B.6. Decoder383/
705010values/37checker faults PASS;current-token negative rejects byte0 with
0checked/0of170 bins. ROUTING FAILS:50059 placed-onlyALMs/5341LABs,47530regs,
62M10Ks/27DSP. No accepted routed PPA/timing. No processes remain active.
Freeze7B.7 create-only before overriding fitting. Next7B.8 is fitter-only
FITTER_AGGRESSIVE_ROUTABILITY_OPTIMIZATION=ALWAYS on this smaller netlist.
No RTL/QSF/SDC change during trial;persist matching recipe only if useful.
No source rerun/retagging for a physical-only setting. No new device,
commit/branch/netlist simulation. Earlier active-process entries are historical.

ACTIVE Stage7B.7:aligned hint-word writes and bounded HEADER index in
verify_decode.sv. No FSM/port/latency change. Other73 RTL/QSF/SDC/C-H exact
to7B.6. Source qualification/fitting pending;do not quote old PPA as current.
7B.6 is frozen create-only:stage7b6_metadata_route_failure.zip/SHA
bd7e02f5ecb2f749837be24581f1c5b62416ec1070553612ba20f50236592800
(259members/12187906bytes;45 previous pairs verified). Its source gates pass,
but routing fails at51760 placed-only ALMs/5531LABs. No accepted routed PPA.
Next qualify old/new decoder pin timing in existing383-case focused gate,
then fresh independent references/main33/negative and same-FPGA compile.
No clock relaxation,commit/branch/netlist simulation. Earlier entries below
are historical. Diagnostic383-case old/new decoder trace PASS1206629 cycles,
348 headers/705010 coefficients/374 completions. This old-fixture diagnostic
is not the final reference gate. Background runners active:main33/negative
PS20092;independent prepare+decoder383/checker PS23692;full Quartus PS23084.
Main token dedb784f7c9dae486655e4e2970e115218ebf19729b60a9d94670ffd5f5f71f4.
Fresh C/Python prepare PASS;legacy token
f34e38e12ccc59126a1f03262a9ad7202acb9353a0829f8bf49a7d7f77083bac.
Fresh decoder383 PASS374 completions/99expectederrors/9resets;117458input
words/705010coefficients. Old/new trace matches1206629 cycles/348headers/
374completions;37/37checker corruptions reject. Decoder runner completed.
Synthesis PASS:decoder4911->1667ALUTs,1420->1449 local registers. These are
NOT placed ALMs. Whole map47808registers/416589block bits/27DSP. Same62M10Ks.
Full33 main UVM and full Quartus fit17860 remain active;no fitted result yet.
Do not edit token inputs or launch duplicate library/project jobs while active.

ACTIVE Stage7B.6: SAME-FPGA memory metadata area reduction. 7B.5 routing
also FAILED;no fitter-only option retained. Its source/reports are frozen in
stage7b5_routability_failure.zip/SHA
24f68893039f79a54a274c5009974494742cff9ea0c75e163722fcccdd1e21a8.
Only production memory.sv changes from7B.4:64x22 completed tags use synchronous
M10K storage;mutable metadata/count/rewrite reside in the two active writers.
Public interface/qualified read latency unchanged;reset invalidates states,
not tag RAM. Same-address tag read/write excluded by COMPLETE/WRITING states.
Quick equivalence unit PASS:64 slots,16647 writes,4418 reads,rewrites/cancel/
reset/faults. Previous memory RTL is a verification-only reference outside DUT.
Main33 UVM runs with MEMORY_EQUIVALENCE=1 comparing qualified outputs every
cycle,plus independent published-output scoreboard. Token:
4000cb5adb20c00dc5154d0338650fbf58bef54cb8a00602c12ccfed817048bf.
Independent C/Python preparation PASS (legacy token
b81e840c0d83b02b4629e44d246d0be936baaa2f7d2aa8520bf8994bdf62cbe9).
Initial synthesis infers all1408 tag bits in M10K;local store registers
2543->560/local ALUT3972->1919 versus7B.4 synthesis. These are NOT placed ALMs.
Two foreground full-UVM attempts were interrupted;neither is final evidence.
Hidden background runners now survive chat interruptions:main/negative
PS28900,focused59/checker PS26708,full Quartus PS14864. Progress logs are
stage7b6_uvm_runner.log,stage7b6_helper_runner.log,stage7b6_quartus_runner.log.
Scripts are ignored generated helpers in sim/dilithium/reference_build/.
Do NOT launch duplicate Questa/project processes while these runners live.
Full33 UVM COMPLETE:30 completions/3 resets,zero errors;functional121/170;
modules315685/396290,package14/14,overall315699/396304=79.66%.
Memory trace matches9318041 cycles/2579302 writes/858082 reads. All30 timestamps
and ALL latency CSV fields exactly equal7B.4. Negative COMPLETE:first key
byte mismatch,zero checked outcomes/0of170 bins. Focused59 and118 checker
faults PASS. No Questa remains active;UVMan/helper runners completed.
Quartus COMPLETE but ROUTING FAILS:51760 placed-only ALMs/5531LABs,47502regs,
62M10Ks/27DSP. No accepted routed PPA/timing. Hold-repair cumulative delay
1890.4ns is a routing diagnostic,NOT slack. No clock/hold constraint relaxed.
No process remains active. Freeze7B.6 create-only before new source edits.
Next7B.7:aligned64-bit hint writes and bounded header indexing in verify_decode,
with prior-decoder cycle comparison,existing383-case reference gate and main
UVM/fitter requalification. Retain useful checks/ports/cycles;no new option,
branch,commit or netlist simulation. Earlier process entries are historical.
Do not edit token inputs while captures run. Preserve6.757ns/device/features.
No commits/branch changes/netlist tests. Earlier active-process entries below
are historical and superseded by this paragraph.

ACTIVE Stage7B.5 FITTING-ONLY aggressive routability trial. Stage7B.4 passes
placement53190ALMs/5624LABs (below5648),but ROUTING fails congestion. Hence
NO completed fit/PPA/timing yet. 49485regs/61M10Ks/27DSP are failed-route values.
Full source qualification passes33 UVM,256 scan,59 helper,118 checker faults
and same-token corrupted-key rejection0/170. Frozen create-only in
stage7b4_serial_route_failure.zip/SHA
b107c67ffb604654a53c6ca830df12d9c10859e0d92dc604c650a2293f8bdd1a;
43 prior archive pairs verified. Do not call placed-only success a routed fit.
7B.5 CLI:quartus_fit dilithium_full -c dilithium_full --read_settings_files=on
--write_settings_files=off --set=FITTER_AGGRESSIVE_ROUTABILITY_OPTIMIZATION=ALWAYS.
Same74 qualified RTL/QSF/SDC,NO source change/no extra cycles. No Questa runs
active. Persist matching QSF only if useful;then assembler/STA,retained regs,
four-corner reports. Respect source vs fitter-recipe fingerprints;never retag
old captures after a QSF-only change. Still fit same FPGA,no new device/commit.

LATEST Stage7B.4 source qualification COMPLETE:main33 UVM30 completions/3
resets,zero errors. Functional121/170;modules315612/396220;package14/14;
overall315626/396234=79.66%. Focused scan256,helper59 and118 checker faults
pass. Sign latency increases0.022-0.060% in measured profiles;first23-attempt
case2141901->2143189 exactly+1288=56*23. Verify rows equal;KG-3/-6 fromstallphase.
Current-token negative running96368;full compile81544 still fitting.
Do not edit source/token inputs;no fitted PPA yet. Next finish actualfit,
retained-register/multicorner reports,universal docs and create-only archive.

ACTIVE Stage7B.4: serialized layout validation in sign_attempt_check and
sign_response_products. ALL other72 RTL/C/H/QSF/SDC exact to7B.2. Ports,
service outputs and all CHECK-and-later engine sequencing remain exact.
Append VALIDATE/VALIDATE_DONE enum values;preserve every old state number.
Two captured seen sets scan31clocks+final check (32cycles) in attempt_check;
three sets scan23clocks+final check (24cycles) in products. Duplicates,
cross-set aliases,exact bitmap matches and source mutation checks retained.
No ownership adoption/engine request before validation. Reset and new-command
clear all seen masks/index/duplicate. Added56cycles per signing attempt;
measure actual latency/profile stalls and throughput impact,do not claim zero.
Focused new tb_handle_scan PASS256 scenarios:24valid/232reject/18reset-recovery,
including every active alias,last entries,cross aliases,bitmap mismatch and
one-cycle source mutation. Main33 UVM session11659 and full compile81544 active;
Python/C prepare61954 active. Token9baca0f0b5e2e627ce3b6b902732021f6236de900915613087904b26141813df.
No token-input edits while captures run;no commits/branch changes/netlist tests.
7B.3 packing trial FAILED identically5716LAB/54612partialALMs;no QSF packing
change retained. Frozen stage7b3_packing_attempt.zip/SHA
05eda027b290edc2d86700f8fd60f52b92852f991529fb3a36e499c5960f49a7.
Still fit the SAME Cyclone V;no larger-device question. No accepted PPA yet.

Stage7B.2 frozen:stage7b2_population_area_attempt.zip/SHA
4688bd0f2a4af700de22a73f07b5c3f6187cd65168bf03d5ebef39e16655a758.
244 members/11797260bytes;41 earlier SHA archives verified. Full33 UVM,
current-token negative0/170,59 helper cases/118 checker faults all complete.
No Questa run remains active. Canonical QSF/source still7B.2;Stage7B.3 is
ONLY a CLI packing trial in flight(session48998),using SAME mapped netlist.
Do not change RTL while fitting. If packaging fits,persist matching QSF
assignment,run assembler/STA/retained-register check,report actual placed
ALMs and four-corner timing. No PPA acceptance until actual fit succeeds.

LATEST Stage7B.2 full33 UVM PASS30 completions/3 aborts,zero errors.
All30 completion timestamps EXACTLY equal Stage7A;no added operation cycles.
Functional121/170;module315817/397721;package14/14;overall315831/397735=79.41%.
Current-token negative refresh is running (session75038) before freezing7B.2.
59 sign_accept cases and118/118 checker faults pass freshly;7B.2 source
audit proves all six sequential blocks exact. QSF area mode/dupOFF only.
Fit FAILED:5716LAB required/5648,partial allocation54612ALMs,61M10Ks/27DSP.
Failed reports preserved under quartus/dilithium/failed_stage7b2/ BEFORE refit.
Stage7B.3 PACKING-ONLY trial session48998 now runs quartus_fit with
--pack_register=minimize_area --read_settings_files=on --write_settings_files=off.
NO RTL or QSF change for this trial;still token24ed3f8e031ea0b6d6dd6c3f295f77ace06b352e0041e834baf01132ca8e912d.
If this fits,persist matching QSF packing assignment after7B.2 capture/archive,
then run assembler/STA and retained-register/multicorner reports. Record that
source qualification is byte-identical RTL to7B.2;do not retag old captures
after a QSF-only fingerprint change. No accepted placed PPA yet.

ACTIVE Stage7B.2: count unique bits instead of pairwise handle comparisons.
Same FPGA/6.757ns;QSF AGGRESSIVE AREA,register duplication OFF. Seven RTL
files change from7B.1;67 exact,all six sequential blocks exact,C/H/SDC exact.
Each helper ORs decoded active handles and checks combined union cardinality
against total active handle count. 7-bit balanced popcount supports all64.
Duplicate/overlap/region-equality and scalar/ownership guards remain.
45841 equivalence cases+65 count widths PASS. Main UVM now INSTRUMENTS the
executable service package and reports modules+package without double counting.
Current33 UVM session99869;full compile session46805;both running. Token:
24ed3f8e031ea0b6d6dd6c3f295f77ace06b352e0041e834baf01132ca8e912d.
No current fit/PPA accepted yet. Do not edit token inputs while captures run.
Stage7B.1 frozen create-only in stage7b1_guard_area_attempt.zip/SHA
a0f4ec1b3ea7b85682de04bf6cff36411cbabaf9f453680152f166e8d5d46b7a;
40 prior archive SHA pairs verified. Its final33 UVM passes and118 checker
faults pass,fit fails6044LABs/partial57873ALMs. Do not call those placed PPA.
Stay optimizing SAME FPGA;no commit/push/branch change or new netlist runs.

LATEST Stage7B.1 complete,NOT fitting yet. Full33 UVM passes30 completions/
3 aborts,zero errors;121/170 functional,316363/399028 raw module code.
All30 completion timestamps equal Stage7A exactly;current CSVs survive.
Same-token negative specifically rejects first key byte,0/170 credit.
Guard equivalence45841 and separate package statements9/9,branches4/4,
conditions3/3 pass (unit-only,not merged into main coverage). Focused59
sign_accept passes18 accepted/5 algorithmic rejections/21 errors/15 aborts;
70944 writes/157888 reads checked;fresh118/118 checker faults rejected.
Fit FAILED:6044 LAB required/5648 available;partial allocation57873 ALMs,
down6409 from64282. No accepted placed PPA/timing. Keep device/6.757ns.
Freeze this candidate create-only before edits. Next Stage7B.2 replaces
pairwise uniqueness with balanced population counts and targets area packing;
all guards/algorithm features retained. User authorizes optimizing SAME FPGA.

ACTIVE Stage7B: SAME-Cyclone-V area optimization explicitly authorized.
Stage7A frozen in evidence/stage7a_uvm_full_baseline.zip (SHA7ed1f55a0ddf70cd2d8549efe63dcdef4c243a76c1a0dab29116dc8ace12b14c),
39 prior archives verified. Primary33 UVM passes30 completions/3resets with
121/170 functional and314371/393251 code bins. Same-token negative rejects
first corrupt byte with0/170 credit. No Stage7A latency CSV survives.
Candidate7B replaces feedback-indexed mask construction in SIX helpers with
parallel handle decoding and six-bit pairwise duplicate checks. Package adds
checked_handle_set;all guard conditions retained;NO FSM/pipeline/cycle change.
45841 equivalence cases PASS against original bitmap insertion. Whole-main
Quartus compile and full33 main UVM now running. Candidate token:
860b1624afd4fef25fc9f10d5feb1b5c829943cff8f384c728d289d2e5e09fda.
Do not edit source/token inputs while these captures are active. No fitted
area/timing or new coverage result yet. Do not reuse Stage7A failed reports
as current PPA. Fit this device;no larger FPGA/commit/push/branch change.

ACTIVE Stage7A:real main UVM foundation and whole-main Quartus baseline.
User's latest continue authorizes this stage;no commit/push/branch change.
UVM in tb_uvm/tb_uvm_dilithium:agent/sequencer/driver/monitor/scoreboard and
coverage subscriber.33 scenarios=18 published+6 command errors+3 wrong-length
invalids+3 reset aborts+3 same-ID published recoveries.9groups/22CP/8crosses/
170 defined bins;credit only after checked result AND empty-pool retirement.
Current token63246d3b14c4c41c1ccad7fb551fbd972769ca05d1f856186a20b0958add7929.
Same single Python adds uvm_prepare/uvm_check;sim/dilithium/run_uvm.do is the
new GUI/waves/functional+code launcher. Source UVM explicitly enables allfeatures.
Current primary full33 run is stage7a_uvm_diagnostic.log (exec session75437),
with IterationLimit200;it is a full campaign,not a reduced subset. It advances
normally;first published Sign needs23 attempts/22 rejections (known Stage6
D0 counters),and code instrumentation is slow. Do NOT mistake this for a hang.
Progress prints each100k cycles;command watchdog3M. Earlier a850... run was
stopped after case0 to add diagnostics and is NOT a completed gate.
Old-token negative retry3 rejected first corrupted key byte with0/170 credit;
rerun the negative gate under the FINAL token after the primary completes.
Whole-main Quartus uses quartus/dilithium/dilithium_full.qpf,all features1,
same device/6.757ns;old dilithium.qpf/subsystem retained. Full compile4 is
FAILED (exec session57575 closed):requires6674LABs versus5648 available.
Failed-fit report [A] allocation64282 ALMs exceeds56480 capacity;this is NOT
a valid completed placement. No accepted placed ALMs/Fmax/slack/TNS exist.
Failed-map/fit reports:49148 registers,61M10Ks,27DSP (diagnostic scope only).
Largest local failed-fit allocations:sign_attempt_check6801.1,
sign_response_products6180.4,verify_equation4375.6,sign_challenge_transform3693.5.
Hierarchy analysis in stage7a_failed_fit_hierarchy.log. User explicitly chose
the SAME Cyclone V and authorized area optimization/sharing/serialization to
make the complete design fit. Do not ask again about a larger device.
Primary33 UVM completed:30 checked completions/3 resets,zero errors/fatals;
121/170 functional bins,314371/393251 raw DUT code bins. A mistaken second
invocation used an environment variable instead of the Tcl negative switch
and was stopped;it overwrote the CSV files. Preserve the completed primary
log and copied stage7a_positive UCDB/reports;do NOT claim latency CSV evidence.
Current-token negative is being rerun with the actual Tcl switch. Freeze the
baseline create-only before Stage7B RTL edits,then optimize the guard chains.
Quartus Standard requires explicit generate/genvar and package-typed ports
without explicit wire.21 source files receive ONLY those transformations;
53 RTL/all21 production C/H/SDC unchanged. stage7a_source_audit.log verifies
the exact substitutions against Stage6 ZIP;no arithmetic/pipeline edits.
Tiny type_probe confirmed imported wire-struct syntax unsupported;its temporary
folder was removed safely. Do not adopt a new RTL architecture on that basis.
After primary:current-token negative,report_full.tcl with quartus_sta after
fit,actual placed ALMs/multicorner Fmax/setup/hold/TNS,universal docs/results,
create-only stage7a evidence archive with source/captures/coverage/reports.
Stage7B broader coverage/PPA optimization remains next;do not claim Stage7
closure from this initial checkpoint. No new netlists/FPGA/commit authorized.

LATEST Stage6 current-source official qualification COMPLETE. Token:
0d69fb8112a49d70fd4080a017e94538c64bf9ca0f3a59e372dc40e471b4a03a.
All74 RTL/21 production C/H/6.757ns SDC match Stage5V.4 byte-for-byte.
Only test selection/fixtures/checking change. nist_keygen now enables both
Sign/Verify;legacy local full_keygen keeps them disabled. New nist_verify
selector reuses tb_full_verify with NIST_VECTORS=1 and first45 original cases.
Same single DO/Python;DILITHIUM_STAGE remains5 for these controller selectors.
Prepare passes all independent C/Python gates. Fresh KeyGen75 capture/compare
passes all433600 key bytes and41/41 checker corruptions. Sign90 capture/compare
passes all310680 signature bytes;75469 allocations/finishes and58802 releases,
peak regions33/45/61;152/152 checker corruptions reject. Verify45 matches all
9 valid/36 invalid published verdicts;1328384 exact writes/26880 packed reads,
5199 allocations/finishes,3995 releases,private peaks22/30/40.158/158 checker
faults reject. All210 official commands complete without errors/resets.
Final source freshness passes;all38 prior archive SHA sidecars pass unchanged.
Universal docs updated;create-only evidence stage6_full_operation_qualification
ZIP/SHA under docs/dilithium_docs/evidence. Unsupported audits retain270 Sign
and135 Verify prehash/external-mu/internal-message cases as excluded,not passed.
Do not edit/retag archived captures. Only one Questa process may mutate the
shared work library at a time. Next Stage7:full main UVM/coverage and a fresh
whole-main Quartus baseline,then measured Fmax/area/throughput/slack work.
No Stage7 work,new PPA/netlists/FPGA,commit,push,cleanup or branch change yet.

LATEST Stage5V.4 COMPLETE:controller/verify.sv sequences actual input prep,
math prep and equation clients under one lease;main op2 now supports Verify.
Approved frames:PK,SIG,ctx||M on verify_input64/index16/bytes4/last. New command
start_signature_len16;verify_accept1 qualified by done/code0. Signature length,
norm and hint encoding failures are normal invalid0,not service errors.
Main defaults ENABLE_SIGN1/ENABLE_VERIFY1;FULL_KEYGEN1 selects complete keys.
No added RAM/engine. Debug reads blocked through Verify ownership/cleanup.
Fresh118cmd=104completions+14reset/fault aborts:23valid Verify+60invalid Verify+
19expectederrors+one real KeyGen+one real Sign.115 Verify commands,one op3 probe.
All45 original official pure verdicts match:9valid/36invalid;10 structural
invalids stop before arithmetic,26 invalids fail equation hash. C/Python60
distinct whole inputs agree (9valid/51invalid).170/170 checker corruptions reject.
2624604exact Verify writes/51466packed reads;10576alloc/rewrite events,
10569finishes,7977releases across the mixed campaign.118fresh scenarios include
framing/metadata failures,14 reset/fault phases and same-ID valid recovery.
Fresh Sign45 passes21 signatures/63204 bytes+one actual KeyGen/14errors/9resets.
Its unsupported-op2 probe becomes op3;Verify remains enabled for this campaign.
Fresh KeyGen-only16 passes8keypairs/3rejects/5resets;features Sign/Verify disabled
explicitly,5433key words/2058PK hash words/656tr bytes/11179field reads.
Final token:40eb550853678a7d9af083eaeec93801e596ff2c8deceefbbc00e46806453356.
Only old main dilithium.sv changes;72 other prior RTL,21 production C/H and
6.757ns SDC are byte-identical. verify.sv added,total74 RTL. Three old benches
get explicit port adapters;legacy KeyGen-only benches disable later features.
Verify peaks22/30/40 regions;primary mixed peaks33/30/40;Sign compat33/45/61.
These are logical pool regions,not ALMs/M10Ks. Same64-region/four-bank pool.
Create-only evidence:docs/dilithium_docs/evidence/stage5v4_full_verify.zip and
SHA256. Universal docs updated;same Python/DO selector full_verify. Diagnostics,
reset-probe correction and old-token subset runs excluded;no retagging.
NEXT Stage6:run full current-source75official KeyGen/90Sign/45Verify suites
under full-operation configuration,retain unsupported-mode audits and direct
output comparison. Current stage reruns local compatibility,not all published
KG/Sign vectors. Stage7 full UVM/synthesis/optimization follows that gate.
No new PPA/netlist/FPGA/security signoff,branch change,cleanup or commit.
Preserve all prior archives and uncommitted user work. Ask for big decisions.

PRIOR Stage5V.3 COMPLETE:verify_equation.sv consumes the actual raw/math prep
chain. Shared sampler expands Ahat;PWM/ADD/SUB computes Ahat*zhat-chat*t1hat
in NTT domain,then one inverse per row. New scalar use_hint.sv reuses existing
decompose;shared Bitpkg/formatter/SHAKE recompute c2 and compare to ctilde.
Every adopted/new region is freed before held valid/invalid completion.
Fresh87cmd=19valid+35crypto-invalid+23expectederrors+10reset/fault aborts PASS.
80adoptions;2104627exact writes/49903packed reads;8226alloc/rewrite events,
8221full finishes,7208releases.2473matrix samples;3308NTTs=2880PWM+428inverse;
2446in-place ADD/SUBs.966UseHint unit cases pass (918valid/48invalid).
172/172checker corruptions reject,including verdict/digest/domain/operands.
Original35structural-valid official inputs give9valid/26invalid;the10malformed
official inputs remain covered by earlier decode/load gates. C/Python44inputs/
519168equation values and918valid UseHint boundary cases agree.
Fresh verify_math134capture/compare passes unchanged under final token:
03631da8c81b893af1261188d22469daa9e5f4e575050d121cdec2a5f8df2d0d.
All71prior RTL,21production C/H and6.757ns SDC byte-identical;two RTL added.
Private peaks22/30/40,conservative plans23/31/41;same64-region/four-bank pool.
Counters exclude real upstream setup traffic. No new polynomial RAM/engines.
Read/packer errors zero-drain finite operations;fatal raw/physical faults halt
until reset. Before-take errors preserve upstream context;foreign leases stay
intact. Final diagnostics excluded;no captures retagged. New negative test
targets alloc domain on compute writes;sampler writes ignore that raw port.
Create-only evidence:evidence/stage5v3_verify_equation.zip +SHA256 under
docs/dilithium_docs/. Same Python/DO selector verify_equation. Universal docs
own commands/results/study order,memory geometry/diagram and block interfaces.
NEXT5V.4:create controller/verify.sv,sequence the three helpers under one lease,
wire main op2 using approved PK/SIG/ctx||M frames,then full official verdicts
and KeyGen/Sign compatibility. Main op2 is STILL unsupported at this checkpoint.
No PPA optimization,new synthesis/fullUVM/netlists/FPGA/security signoff,
branch change or commit. Preserve all prior evidence archives and user work.

PRIOR Stage5V.2b COMPLETE:verify_math_prepare.sv adopts real5V.2a context,
hashes pure-message mu using unchanged sign_hash_message op0,samples c from
ctilde through shared mode3,and FNTTs shifted t1,z,c using rotating scratch.
Challenge uses existing Pre-NTT op3;hints stay raw. Same4banks/engines,one new
RTL module (71total);all70prior RTL and6.757ns SDC remain unchanged.
Independent C/Python56distinct inputs/191232challenge-and-NTT values agree.
Fresh134cmd=65transformed contexts+57expected errors+12reset/fault aborts PASS.
112actual adoptions;236834exact scalar writes/84099packed reads;848NTT commands
including68Pre-NTTs;18612mu absorption words/437digest beats.112/112checker
corruptions rejected. Final token:
46bb7af1709019014aba17c5162be6ab4b04b9d2e44e8b1d4b26bae3b181a719.
Fresh earlier5V.2a133capture/compare also passes with unchanged counts.
Initial checker diagnostics exposed allocator-port domain vs effective stored
domain distinction:sample allocations use mode when alloc_compute=0;raw domain
port is ignored. New capture logs alloc_compute explicitly;no RTL fix needed.
Diagnostic runs/header-collision selftest bug were excluded;all final gates
rerun after fresh prepare. Do NOT retag captures. Preserve5V.2a archive.
Use same Python/DO selector verify_math and focused tb_verify_math.sv. New C
adapter op4 uses unchanged SHAKE256,poly_challenge,poly_shiftl/poly_ntt.
Result13/18/24regions=K t1hat+L zhat+K raw hints+chat;peak14/19/25regions before
counting foreign owners. Pre-adoption errors leave old owner intact;adopted
errors drain and clear all owned regions. Clear/take wait for pending reads.
Main op2/Verify equation remain unsupported;next5V.3 arithmetic/challenge check.
No optimization,new synthesis/fullUVM/netlists/FPGA/security signoff or commit.
Create-only evidence:docs/dilithium_docs/evidence/stage5v2b_verify_math.zip
andSHA256. Universal docs contain exact counts,commands,study guide and memory
diagram. No old Sign/KeyGen RTL changed;their compatibility remains frozen in
5V.2a rather than rerun here. NEXT5V.3:Verify equation/UseHint/w1 challenge hash.

LATEST Stage5V.2a COMPLETE:Verify first-two-frame load/hash owner implemented.
Fresh133cmd=49contexts+73expected errors+11reset/fault cases;360545exact
scalar writes,61827packed reads,60646host words,27921raw words/453digest beats
PASS.87/87checker corruptions rejected. C/Python45distinct PK hashes agree.
Token3991be05559b5a564a050afe7361d1906313ffe000988db091d7575cd3b38e64.
Shared SK load138commands/449992writes/105728reads and95/95checker faults PASS.
Full KeyGen8complete/3reject/5reset,5433key words/656tr bytes and37faults PASS.
Main full_sign45commands:21exact signatures/63204bytes,1mixedKG,14errors,
9reset/fault cases PASS;11253alloc/11251finish/8778release counts unchanged.
Fresh captures and independent compares all use the same final token.
New helpers/verify_input_prepare.sv and process/verify_frame_load.sv;existing
load service gains verify/kind/length/index high bits/header response and
paired PK raw/load descriptor admission. Same4banks;12/17/23context regions.
One-word PK fork tracks two independent credits;failed PK zero-fills only
remaining finite hash absorption,then releases owned regions before error.
Signature errors roll back z/h and free PK. Foreign leases preserved.
Clear/take wait for pending reads;clear wins;take transfers without freeing.
Fatal raw/service faults halt until reset. Main op2 still unsupported.
Approved PK/signature/ctx||M host unchanged;third frame,mu,challenge and NTT
preparation are NEXT5V.2b. No PPA/new synthesis/fullUVM/netlists/commit.
AgainstV1:only service package/backend change,two new RTL files;all21production
C/H and6.757ns SDC unchanged. Diagnostic runs with old headers get no credit;
final133capture/compare/selftest rerun fresh. Preserve all older archives.
Create-only evidence:docs/dilithium_docs/evidence/stage5v2a_verify_prepare.zip
andSHA256;universal docs contain results,commands,study guide and memory diagram.
Previous fullSign196-fault validation remains historical;this compatibility
run reruns the full45-scenario capture/compare,not that unchanged checker suite.

LATEST Stage5V.1 COMPLETE:Verify PK/signature decoder,NOT main Verify.
USER APPROVED three-frame64-bit main input:PK,signature,ctx||M;index0/last per
frame;context/message/signature lengths in command;valid/invalid completion.
Do not ask this choice again. Main op2 remains unsupported until wired later.
New process/verify_decode.sv uses84-bit reservoir,512-bit header and84-byte
hint suffix;no whole encoded-key/signature RAM or extra banks. t1<<13,z and
dense hints are canonical23-bit;all output tentative until done0. Codes1bad
command/length,2norm/hints,3framing. Strict z bound,ordered per-row indices,
monotonic counts<=omega,zero padding;legal cross-row index repeats preserved.
Fresh383cmd=374completions(275success/99errors)+9resets;errors14command+
37norm/hint+48framing.117458input words/705010decoded values;37/37checker
mutations rejected. Origins90Verify frames+90Sign signatures+75KeyGen PKs+
128directed. C/Python303distinct frames/664576full-unpack coefficients agree.
Official sigVer180cases retained/pinned at NIST/ML-DSA-sigVer-FIPS204;45pure
public API(15per level) selected,135unsupported audited. Full SOFTWARE C Verify
matches45/45 official verdicts,9valid/36invalid. Decoder rejects10invalid;
26invalid are structurally valid and REQUIRE future arithmetic/challenge check.
Do NOT describe decoder acceptance or C verdicts as main RTL Verify support.
Fresh full-KeyGen compatibility8complete/3rejects/5aborts,5433key words,
2058PK hash words/656tr bytes/11179read words;37/37checker faults PASS.
Final token:f4636b613b2aa57ed0c16e1e9aa87d6de54631543fcfcd13f430c709a17fc655.
Initial decimal-literal whitespace compile error fixed;diagnostic old-header
run receives no final credit. Then prepare/full capture/compare/selftests rerun
fresh. No retagging. Prior67RTL+21production C-H+6.757ns SDC unchanged;68RTL
now. QSF adds source only,legacy synthesis top unchanged;no PPA/netlist/fullUVM.
Single Python/DO selector verify_decode;focused TB under tb/tb_dilithium/.
Universal docs and create-only evidence stage5v1_verify_decode.zip/SHA256
under docs/dilithium_docs/evidence/. Preserve older archives/uncommitted work.
NEXT5V.2:decoded t1/z/h bank ownership,streamed PK hash->tr,mu/challenge/NTT
preparation using same services/four-bank pool. Then5V.3UseHint/Verify equation/
challenge comparison;5V.4main op2+official RTL verdicts. Keep approved framing.
No commit/branch change,new synthesis/PPA,fullUVM/netlist/FPGA/security signoff.

LATEST Stage5N.4h.7 COMPLETE:official NIST ACVP pure/public Sign90/90,
310680 exact published bytes;15deterministic+15randomized per level2/3/5.
152/152 checker mutations reject. All360 original sigGen cases retained at
NIST/ML-DSA-sigGen-FIPS204 with pinned URLs/commit/SHA provenance;270 prehash/
internal-API/external-mu cases are unsupported,audited,NOT credited as passes.
Commit2972def23bf9f3680c2c531561ed9bdd0f1086ad matches KeyGen corpus pin.
Single Python nist_sign_corpus audits/joins TG/TC,prepares original inputs,
compares RTL directly to published signatures. C90/310680 also match;test-only
--sign-only accepts original SK/ctx/M/rnd without PK,so no C Verify claim for
these official cases. Local default C adapter still signs+verifies12fixtures.
Same actualmain tb_full_sign,NIST_VECTORS1;one DO selector nist_sign. No newTB,
Python,RTL,engine,RAM,ports or SDC change. All67RTL+21production C-H+SDC equal
4h.6 archive. Input87433words/output38880words;433attempts/343rejections,
1..23attempts per case. Physical75469allocs=58802new+16667rewrites,
75469successful finishes/58802releases;zero ownership before every done.
Peaks33/45/61regions. Fresh local full_sign compatibility45commands:
21Sign/63204bytes+1actualKG/3872bytes+14errors+9aborts,196checker faults;
all previous physical/stream counts unchanged. Same final source token:
00b60421e4f5f8901c80c8df29182984c482d8bc0c3c3e4901663537d44b08ca.
Universal docs updated with scope,files,commands,results,diagram and study guide.
Create-only evidence:stage5n4h7_nist_sign.zip +SHA256 under docs/dilithium_docs/
evidence/. Preserve all older archives/uncommitted work. No retagging captures.
Next:main Verify controller and official vector flow;ask for material host/
memory decisions before implementing them. Keep pure final FIPS204 under2/3/5
labels. No new PPA/full-UVM/netlist/FPGA/security signoff,commit or branch change.

LATEST Stage5N.4h.6 COMPLETE. USER APPROVED streamed two-frame Sign:
expanded SK then ctx||M,each frame index0/last,lengths+rnd in start command.
Reload/free key per request;do not ask this choice again. New sign.sv connects
key preparation,attempt/retry and encoding to ONE services tree. Main op1 now
works with default ENABLE_SIGN1;op2Verify/op3 unsupported. KeyGen-only legacy
tests explicitly ENABLE_SIGN0;main-top gate uses enabled Sign and actual KG.
Main owner spans child cleanup and masks external debug responses during Sign.
High SK index bits checked BEFORE narrowing. Signature provisional until code0;
all key/attempt regions free before normal Sign done. Fatal memory/child errors
HALT until global reset. Pure/internal-mu,ctx<=255,total66+ctx+M<=65535;
external-mu/prehash not implemented. No key/message/signature RAM/new engine.
Fresh45cmd:21Sign/63204exact bytes+1actualKG/3872bytes+14expected errors+
9reset/fault aborts.196/196checker mutations reject.13356input words,9113sig
words(including aborts),484key words,76attempt starts. Physical11253allocs=
8901new+2352rewrites;11251finishes=11246success+5discards;8778releases,
118reset-held regions(including2open writes). Peak33/45/61regions. Exact
input/output framing,metadata snapshots,busy refusals,read isolation,owner
transitions and full physical lifetimes checked. Initial fatal probe fired
on retained encoder hint-state too early;restricted to active ENCODE_WAIT/
READ_RESP,then prepare/full capture/compare/selftest rerun fresh. No retagging.
Final token:76ed6917df74705e5c7c248401a4c5129e42f94d54d2da58efde1a07ddfb2d8c.
Full C Sign+Verify12distinct original-input fixtures/41424bytes;3also Python
math. Local reference-derived signatures from official KeyGen pairs,NOT
official NIST Sign outputs. C adapter/fingerprints/build in the one Python;
one DO selector full_sign;tb/tb_dilithium/tb_full_sign.sv actualmainbench.
Fresh encoded KG8complete/3rejects/5aborts,5433key words/2058hash words/
656tr bytes/11179reads,37checker faults;rounded KG7complete/3rejects/4aborts,
34rows/190224scalar writes/12800reads,36checker faults+schoolbook row0 PASS.
65prior RTL/production C-H/6.757ns SDC unchanged;old main top changes+new
Sign control client make67RTL. QSF source updated;selected legacy synth top
unchanged. Universal docs updated;create-only evidence stage5n4h6_full_sign.zip
and SHA256 in docs/dilithium_docs/evidence/. Preserve all older archives/work.
Next4h.7:official NIST ACVP sigGen audit,declare supported modes,main capture/
exact official byte compare;then implement main Verify. Main encoder/protocol
error propagation combinations remain for broader UVM. No new synthesis/PPA,
full-UVM/netlist/FPGA/security signoff,commit or branch change authorized.

LATEST Stage5N.4h.5 COMPLETE:sign_signature_encode adopts accepted z/hints/
ctilde from the real attempt loop,uses shared Bitpkg op4 z(18/20-bit),streams
ctilde||z||sparse-hints,then releases adopted regions before held completion.
No signature RAM/new bank/duplicate packer. Shared pack op widens2->3 bits;
old op values unchanged. Preflight code1 preserves owner;after take,code2
packer/code3 hint-read failures discard provisional frame and owned payload.
Noncancelable Z read/pack framing/physical failures HALT until GLOBAL reset.
Key/service lease stays outside encoder. Main host Sign/Verify still open.
Fresh24cmd=7complete signatures/25339bytes+9errors+8reset/fault aborts;
21takes,6810exact output words,8880encoder reads,149encoder releases,11keys.
163/163checker mutations reject. C/Python6fixtures/22030whole bytes agree;
three nonce-zero fixtures also match unchanged full C signing. Local derived
signatures from official KeyGen SKs,NOT official NIST signature-output vectors.
Output IDs are source IDs+256 in tests;source reads/output/done check distinct
tags. Review fixed recoverable hint-read error discarding a stalled full word:
response_ready now waits for fill<8 and READ_RESP only consumes handshake.
Directed HOLD witness proves pending bad response while full output stalled.
Earlier reset probe/readiness and hexadecimal checker-generator bugs fixed.
Final source token:
509806b1621e1427f831d216959bbdb293406280a61bdde4fbad6cd1bb56c686.
Expanded packer188cmd/108success/62errors/18aborts,34467inputs/5690words;
15/15checker faults. Fresh full KeyGen8complete/3rejects/5aborts,
5433key words/2058PK hash words/656tr bytes/11179reads;37/37checker faults.
All gates share the final token. Only3of65prior RTL change:Bitpkg,service package,
KeyGen encoder op width;62prior RTL/production C-H/6.757ns SDC unchanged.
New helper makes66RTL. One Python/DO selector sign_encode,TBunder
tb/tb_dilithium/. Universal docs updated;archive stage5n4h5_sign_encode.zip
and create-only SHA256 under docs/dilithium_docs/evidence/. Preserve prior
archives and all uncommitted work. No commit/branch/PPA/full-UVM/netlist/FPGA/
security signoff. Next4h.6:real src/controller/sign.sv/main host dispatch,
SK/message/context/rnd framing,prepared-key/attempt/encoder service ownership.
Then official full-operation NIST signing and main Verify. Functionality/bytes
first;do not optimize silently or treat focused harness as main Sign support.

LATEST Stage5N.4h.4 COMPLETE:sign_attempt_loop connects masks,matrix,
challenge,transform,products,checks to ONE physical services tree. Initial
ctx/message streamed once;mu/private seed derived once. Normal rejection
takes headers atomically after all payloads are freed,then masks retry
command bypasses initial derivations and uses seed||LE16(nextnonce+j).
Key stays live;service errors stop+reverse-clear children. Fatal/context
fault HALTs until GLOBAL reset.17-bit nonce/18-bit end check BEFORE16-bit
narrowing;no arbitrary retry limit. Final accepted vector may end65536;
rejected final vector returns code6 without nonce0. Parent codes0accepted,
1badcontext,2childerror(stage0..5/detail=childcode),3observed publication,
6exhausted. Accepted z/hints/ctilde retained through held done/READY;clear
wins,take transfers,read responses block both. Main Sign/Verify unfinished.
Fresh47cmd=19accepted parent results+12service failures+5exhaustions+
11reset/fault aborts;87attempts/45genuine rejections,157rawhashes,
418maskjobs,105667exact y values,56256packed reads,14actual key preparations.
152/152checker faults PASS;full independent C/Python13starts/26attempts/
24064accepted coefficients PASS. C adapter takes SK/message/rnd only.
Fresh defaultmask78cmd/27success/36errors/15aborts,49094writes/83136reads
and85/85checker faults PASS. Other intermediate scalar writes not claimed
by this loop gate;prior component evidence covers those. Every physical
allocation/commit/release is reconstructed,including internal row scratch.
Diagnostic initially missed those releases and temporary row IDs;monitor/
checker fixed,then prepare/full primary+legacy comparison/fault gates fresh.
Only prior sign_mask_prepare RTL changes;63other prior RTL/6.757ns SDC
unchanged. Three prior TB instantiations tie added retry ports low. New
parent makes65RTL. Source token:
06c54ff503a5e6e90186ee329daec1a35d97e81f728788db5aa8c4fd1d1728bc.
One Python/DO selector sign_retry;tb/tb_dilithium/tb_sign_attempt_loop.sv.
Evidence stage5n4h4_sign_retry.zip +create-only SHA256 under universal
docs/dilithium_docs/evidence/. Preserve all prior archives/uncommitted work.
No new PPA/full-UVM/netlist/FPGA/security signoff,branch change or commit.
Next4h.5:signature encoding of ctilde/z/h with64-bit backpressure and proper
region ownership,compare whole bytes with unchanged C. Then main Sign
host/controller dispatch;main Verify remains open. Keep functionality/
exact bytes first;optimization later. Matrix is resampled per attempt now.

LATEST Stage5N.4h.3 COMPLETE:helpers/sign_attempt_check adopts
products z/r0/w1/ct0+mu/private seed/ctilde/17-bit nextnonce. Existing CNB
checks z,r0,ct0;in-place ADD combines low+ct0;shared Mhint makes each row.
12-bit sum rejects above omega80/55/75. One first hint spare then rotate
freed low-row handles;release low/high/ct0 only after child retirement.
Normal rejection code0/reject1 frees ALL attempt payloads but retains
mu/seed/nextnonce. Reasons1z/2r0/3ct0/4omega. Errors code1badinput/2capacity/
3signservice/4ADD/5observedprotocol publish no result. Fatal fault/context
loss HALTs until GLOBAL reset. Accept retains z/hints/ctilde+headers.
Whole READY clear/take honors pending consumers and clear priority;old
products owner invalidates before writes. Key remains live. No new banks/
payload RAM/arithmetic engines. Phase key+attempt peak29/41/55 without
sentinel;accepted20/28/38 regions,rejected12/17/23 key regions+small headers.
Fresh59cmd=18accepted candidates+5genuine rejects+21errors+15aborts;
53takes,70944exact writes,157888packed reads;18key/53upstream preparations.
Python/C8fixtures/25794norm-weight-combined-hint values PASS;118/118 checker
faults PASS. Three published KeyGen SK inputs;intermediates local FIPS-derived,
NOT official signature-output vectors. Real clean nonces2/4,3/0,5/28;
norm rejects2/0,3/5,5/0,5/7;norm-clean3/455 rejects56hints>omega55.
All63 prior RTL/6.757ns SDC unchanged;new helper makes64RTL. Source token
b8717adda3ecae125922d467c29f5d458d04b2a4caf3be8e22fe42e5327a04c4.
First diagnostic elaboration reset-probe path fixed;release-state checker
and clear-priority test hardened,then prepare/full capture/compare/selftest
freshly rerun at this token. Never retag old captures. One Python/DO selector
sign_accept. Fresh products regression63cmd/425955writes/99584reads and
84/84checker faults PASS. Evidence stage5n4h3_sign_accept.zip and create-only
SHA256 under docs/dilithium_docs/evidence/;archive source/fixtures/fresh
primary+compatibility captures/logs/docs/manifest. Preserve it unchanged.
Next4h.4:rejection retry with retained mu/private seed/nonce,
prepared-key reuse and no message replay/seed rehash. Guard17-bit65536
before narrowing nonce. Then signature packing/main Sign. Main Verify open.
No commit/branch/PPA/full-UVM/netlist action. Preserve all uncommitted4a-h3
work and immutable archives;stay functionality/exact outputs first.

LATEST Stage5N.4h.2 COMPLETE:helpers/sign_response_products adopts raw y and
w0/w1/chat with mu/private seed/ctilde atomically. Mask helper adds take;old
owners invalidate before destructive writes. Prepared-key lease stays live.
Use existing PWM/INTT for cs1/cs2/ct0;in-place ADD y->z,SUB w0->r0;w1 stays
unchanged. Plan k+2 free addresses:k retained ct0 and2 reusable scratch.
Free scratch after last reads,chat after all groups. Retain z/r0/w1/ct0,
mu/seed/ctilde and17-bit nonce+l through done/READY,clear or whole-context take.
Normal preflight errors preserve old owners;post-adoption errors discard ALL
attempt regions,including rewritten prefixes. Key survives. Physical/context
fault or partial-write failure HALT requires GLOBAL reset. No new arithmetic/
bank/payload RAM. Peak30/42/56regions without sentinel;retained28/40/54.
Fresh63cmd=24arithmetic completions+21expected errors+18reset/faultaborts;
57atomic takes,425955exact intermediate writes/99584packed reads.21key and
57mask/matrix preparations. Six local FIPS-derived level/nonce fixtures use
three published KeyGen SK inputs,not official signature output vectors.
Python sparse convolution/C6fixtures/44032values PASS;84/84checker faults PASS.
Fresh prior transform51cmd/7875writes/85760reads and64/64checker faults PASS.
Only prior sign_mask_prepare RTL changes;other61/6.757ns SDC identical to4h1;
new helper makes63RTL. Source token:
f91cf9ef1f257ec5d9b2a0894b5ef05c5cbba4fbd2d462403360bd05ea01db5b.
One Python/DO selector sign_products. Diagnostic checker expected held-done
ordinal k-1 incorrectly;helper resets it0. Fixed checker,then full final gates
freshly rerun at this token,no retagging. Evidence:stage5n4h2_sign_products.zip
and create-only SHA256 under docs/dilithium_docs/evidence/. Preserve4a-h2 work.
Next4h.3:CNB across z/r0/ct0,combine low+ct0,Mhint and total omega80/55/75.
Algorithmic reject must retain mu/private seed/next nonce even after freeing
attempt payload. Current6fixtures include genuine norm failures;add level5
nonce reaching hints. Then rejection/nonce retry with seed reuse,signature
packing/main Sign. Main Sign/Verify and4h remain unfinished. No branch/commit/
PPA/UVM/netlist action;functionality/bytes first. No new synthesized metrics.

LATEST Stage5N.4h.1 COMPLETE:sign_challenge_transform adopts matrix/challenge
READY contexts atomically,without physical release. Both previous helpers
add take_valid/ready;clear wins,pending consumers/services block take. Old
owners invalidate and cannot clear adopted data. New owner releases yhat,
ordinary FNTT(c),checks complete storage after child retirement,then frees
raw c. Retain w0/w1/chat+ctilde;explicit clear or whole-context take ends it.
Outer owner preserves key/raw-y leases across gaps,held done,READY/cleanup.
Preflight rejection leaves old contexts intact;post-adoption normal error
releases ALL adopted/new attempt regions;key/raw y remain. Fatal/context loss
HALTs until GLOBAL reset. No new engine/bank/payload RAM;steady live regions
29/40/54 ->25/35/47,excluding sentinel/blockers. Physical services unchanged.
Fresh51cmd=24success+12errors+15reset/faultaborts;42atomic transfers,
7875exact chat writes/85760packed reads.18key/24mask/51matrix preparations.
Python/C6fixtures/1536c+1536chat values PASS;64/64 checker faults PASS.
Fresh prior sign_challenge81cmd/8640c writes/171264reads and77/77 faults PASS.
Two prior helpers gain take;other59prior RTL/6.757ns SDC identical to4g.
62current RTL. Source token:
4661ce647abb7ed7b2cdbe1d6630f9dd161df7d1e33750a6a6784f8d22c621d3.
One Python/DO selector sign_transform. Evidence:stage5n4h1_sign_transform.zip
and create-only SHA256 under docs/dilithium_docs/evidence/. No failed run or
retagging in this checkpoint. Preserve all uncommitted4a-h1 work/archives.
Next4h.2:chat*s1/s2/t0,INTTs,z/w0 corrections,then norm/hints/retry/signature.
Mask owner still holds y and private mu/seed;define handoff before destructive
reuse and preserve headers for retry without replaying message RAM. Products
must adopt transferred matrix/chat context before changing/releasing it.
Main Sign/Verify and4h remain unfinished. No branch/commit/PPA/UVM/netlist
action without authorization;functionality/bytes first.

LATEST Stage5N.4g COMPLETE:helpers/sign_challenge_prepare.sv controls retained
w1 -> shared Bitpkg op3 -> mu64||encoded_w1 -> actual SHAKE256 ctilde ->
shared SampleInBall c. Levels2/3/5 use6/4/4-bit w1,ctilde32/48/64 bytes,tau
39/49/60. One services tree,no new engine/poly/message RAM. One92-bit cache,
private512-bit digest and one existing c region. Parent retains key,y,matrix
leases and outer owner through gaps/held done/READY/clear. Only existing
Bitpkg changes among60 prior RTL;other59 and6.757ns SDC byte-identical to4f.
Invalid read/pack errors drain current packet,zero-fill formatter remainder,
discard diagnostic hash;bad hash never samples. Bad observed sampler status
releases completed c before error. Clear blocks pending consumers;releases c
only. Physical/context loss HALT requires GLOBAL reset. Main Sign/Verify
remain unsupported;no retry/signature yet.
Fresh81cmd=24success+39errors+18reset/faultaborts;90895 pack inputs,6317
packed words,3216 digest bytes,8640 c writes,171264 packed reads.21 real key
preparations/27 source mask-matrix vectors;three published KeyGen SK inputs,
local FIPS-derived intermediate expectations. Python/C6fixtures:5120 w1
bytes,288 ctilde bytes,1536 c coefficients PASS.77/77 checker faults PASS.
Extended Bitpkg136cmd=84success+40errors+12aborts,2996 exact words,15/15
checker faults PASS. Fresh fullKeyGen8complete/3reject/5reset comparison and
37/37 checker faults PASS.
Source token244ba6450bfa78dc10e6514fd8cf7677a0e6a729746f9db110d449e33bdca7b3.
One Python/DO selector sign_challenge. Two diagnostic captures were corrected
then final gates freshly rerun,not retagged:wait temporary pack command ready;
assert TB reset before next edge so checkpoint cannot gain an extra input.
Evidence:evidence/stage5n4g_sign_challenge.zip +.sha256,create-only.
Next4h:safe subset ownership transfer/release,challenge transform/products,
z,w0 correction,hints/norms,retry with mu/private-seed reuse,signature/main
Sign. Current matrix READY owns yhat/w0/w1 together;explicit handoff needed
before dead yhat space can be reused. Stay functionality-first,no branch/
commit/PPA/UVM/netlist action without authorization. Preserve all uncommitted
4a-g work and immutable archives.

LATEST Stage5N.4f COMPLETE:helpers/sign_matrix_prepare.sv controls ordinary
FNTT(y),all k A rows via SHAKE128(rho||column||row),shared row PWM/ADD/INTT,
and shared x4 Decompose. No new engine/bank/poly RAM;59 prior RTL unchanged.
Caller retains key AND raw-y contexts plus outer owner through gaps/READY/
cleanup. Auto lowest-free plan:19/25/33 addresses=yhat[l],Arow[l],w0[k],w1[k],
acc,scratch,w. Largest source+workspace plan63,plus test sentinel fills64.
Actual normal peaks with sentinel34/46/62;capacity blockers create46/46/62.
Raw y stays for z;A row/raw w released each row. Publish only whole yhat/w0/
w1 vector,retain through done/READY;clear releases own results only. Validate
IDs,regions,term count and acknowledged completeness;sign DMA source w stays
hidden through its REPORT,so whole-plan completeness waits for child retire.
Normal errors roll back earlier output rows too;physical/context faults HALT
until GLOBAL reset. Main Sign/Verify still unsupported;one attempt only.
Final66cmd=24success+24errors+18reset/faultaborts;1060230 scalar writes,
102336 packed reads,21key preparations/27mask vectors. Success executions
reuse six level/nonce combinations;three published KeyGen SK inputs only.
Python/C6fixtures/96256 y,yhat,A,w,w0,w1 values PASS.66/66 checker faults PASS.
Fresh fullKeyGen8complete/3reject/5reset and37/37 checker faults PASS.
SDC6.757ns unchanged. Source token:
e08c7d68837cb2a9a702ebe761af37a6ed53429299bf49947ded7d95f7a99025.
Evidence:evidence/stage5n4f_sign_matrix.zip +.sha256,create-only. All universal
docs updated;one Python/DO selector sign_matrix. First diagnostic capture
was not retagged;final gates freshly rerun at this token. No commit/branch/
PPA/UVM/netlist action. Next4g:shared w1 Bitpkg,mu||w1 challenge hash,then
SampleInBall(c);later secret products,z/hints/norms/retry/signature/main Sign.

LATEST Stage5N.4e COMPLETE:helpers/sign_mask_prepare.sv connects retained K/tr
to pure-message mu,private mask seed and4/5/7 ExpandMask polynomials. Actual
RTL digests feed dependent descriptors;one services tree,no new engines/RAM.
Caller retains prepared-key lease and outer owner across client gaps/READY.
Command snapshots ID/message/context/nonce/base/rnd;reject length/alias/bounds/
nonce+l>65536 and occupied plan before hashing. Validate raw ID/core/count,
sampler status and post-retirement complete;formatter done alone is not enough.
Sampling status commits memory finish on the SAME edge;complete must be
checked AFTER that acknowledgment. Initial premature check was corrected.
Success retains private mu512/seed512/mask handles until explicit clear;
clear/normal-error rollback releases only masks,never prepared key/sentinel.
Context valid/ID/level/map loss or physical fault HALTs until GLOBAL reset.
One attempt only;retry seed reuse/nonce scheduling remains for main Sign.
Final78cmd=27success+36errors+15reset/faultaborts,63normaldone.4464absorption
words,6800physicaldigestbytes,49094scalarwrites,83136packedreads.18realkey
preparations reuse three published KeyGen SK inputs;expected intermediates
are FIPS-derived,not official sigGen vectors. Python/C462messages/336mask
polys agree;85/85 checker faults reject. Fresh fullKeyGen8/3/5 plus37/37
faults PASS. All58 earlier RTL and6.757ns SDC byte-identical to4d.
Token53e7a2e7883166e9b384e8b8dbbe8f6fe9d5b01037e8c045c800832f67edd78b.
Evidence:evidence/stage5n4e_sign_masks.zip +.sha256,create-only.
Next4f:ordinary FNTT(y),shared A*y and decomposition;retain raw y for z.
Then challenge/products,hints/norm/rejection/retry/signature packing/main
Sign;Verify also pending. No commit/branch/PPA/netlist/full-UVM authorized.
Use same single run.do/Python with selector sign_mask;universal docs updated.

LATEST Stage5N.4d COMPLETE:helpers/sign_key_prepare.sv is a control-only client
of actual dilithium_services,not yet connected to unfinished main Sign.
Command level/ID/base/work;validate free raw12/17/23 plan +one spare outside.
Load validated SK;retain rho256/K256/tr512. Pre op3 for s1/s2,ordinary FNTT0
for t0. Validate child IDs/destination/completed reservation;release old raw
source only after success,then reuse it as next scratch. Final handles
[initial_work,base,...,base+N-2];base+N-1 freed. PeakN+1,steadyN regions.
Context fields/handles remain private until all transforms/source releases.
Successful done retires to retained READY,busy stays1,service_active becomes0
so future Sign may route privileged clients. Clear requires quiescent service
and no NEW consumer requests;pending responses still drain. Clear zeroes
exposed context and releases all owned regions;busy0/command_ready1 ends it.
Caller owns the outer services lease for ENTIRE busy,including child gaps/
READY/cleanup;do not expose underlying complete to unrelated host clients.
Normal errors drain child status and clean raw/replacement/new result regions.
Physical faults HALT(no done),require GLOBAL reset;no secure RAM erasure.
Parent codes0success,1level,2layout,3occupied scratch,4load,5NTT,6identity/grant;
detail carries child code. Child payload and code contracts unchanged.
All57 prior RTL and6.757ns SDC byte-identical to4c2. No new engines/poly RAM.
Final RTL165 keys/157 completions(95success,62errors)/8 resets;1013992
writes,115776 reads,1816 requests(1200Pre/616FNTT),all75 official KeyGen SKs.
Python/C164 fixtures/709632 transformed values PASS(direct evaluation vs
unchanged C unpack_sk/poly_ntt). All3 fresh gates PASS:sign_prepare55/55
checker faults,shared loader95/95,fullKeyGen8 complete/3 rejects/5 resets
and37/37 checker faults. PhysicalNTT1805 successes/6 rejections/5 interrupted;
six bad observed result tags discarded;96 context publications include one
held-done reset,not an extra successful command. Peak13/18/24 key regions.
Frozen evidence:evidence/stage5n4d_key_prepare.zip +.sha256,create-only.
Token a72c6cc1cabf9338fd0ac684f6393e7c44ff05e4cc5aa571d57c6305f1926647.
Next4e:retained-key signing hashes/mask generation,then vector/retry/packing.
Main Sign/Verify still unsupported;no commit/branch/PPA/UVM/netlist action.
Preserve all prior immutable evidence. Universal docs describe contracts.

LATEST Stage5N.4c2 COMPLETE:sign_key_load is in the ONE production services tree.
New nested request/response load record;KeyGen drives load='0. Row wrapper
masks only NEW load commands;payload and done-ready of an owned key pass
even with row_valid held. Row/NTT/scalar/sign priority,prior raw/sampler and
public-read retirement precede load acceptance. Bank client mux includes
loader allocations/writes/finish;internal rollback release selects the SAME
primitive port. External release blocks on acceptance and throughout busy;
public reads/descriptors block until held done retires. complete masks l_hidden.
Five previous RTL files change;52 remain byte-identical to4c1,including the
loader/decoder,memory,Keccak,sampler,NTT and arithmetic.6.757ns unchanged.
Shared gate138 keys(95 success,38 errors,5 resets),449992 scalar writes,
105728 packed reads;all75 official KeyGen SKs.133 sampled sentinels/8512
packed words,three17-byte raw hashes/held public reads,95 real CNB handoffs.
Eight six-cycle prior-owner probes at each level;isolated request classes
during payload,all together at held done. Reset prefixes/reuse unchanged.
All7 current-source gates PASS:shared load95 checker faults,standalone load61,
sign_service33,sign_hash61,full_keygen37,seed_row23,bank_process29.
Local full-KeyGen8 complete/3 rejects/5 resets;prior all75 full-KeyGen RTL
evidence remains Stage5N.3,not rerun. C software still checks all75 keypairs.
One negative test was corrected:positive owner witnesses are not exact cycle
totals;the corruption removes the required witness instead of changing N to N+1.
Frozen evidence:evidence/stage5n4c2_shared_key_load.zip +.sha256,create-only.
Token ed9bd7a5ea0a278d435f14b49c2360a93bda066d2392894e7485d9f2b62e9af8.
Next4d:key/header-handle retention and shared secret transforms;then hash/
mask/vector/retry/packing control. Main Sign/Verify still unsupported.
No commit/branch/synthesis/netlist/full-UVM/PPA action;preserve all evidence.

LATEST Stage5N.4c1:process/sign_key_load.sv connects the existing decoder to
real memory/packer/four banks in a focused harness. NOT yet connected to
dilithium_services/main Sign:next Stage5N.4c2 adds shared arbitration/handoff.
Command level/ID/base6;contiguous s1[l],s2[k],t0[k] plan12/17/23 regions.
Validate7-bit end<=64;reject occupied plans before decoder/input/allocation.
Coefficient domain throughout,mode1 s1/s2,mode3 decoded t0;core0 packer.
Same key ID across regions. Header/plan private until WHOLE decode success
and64 ACKs/poly. Error:finish1 active partial,release ALL earlier commits.
done0 success,1 level,2 eta,3 framing,4 occupied,5 bounds;internal ordering
mismatch faults/HALT with leases until reset. Caller MUST grant exclusive
memory ownership through held done,mask complete with hidden,and block public
reads;masking complete alone does not stop primitive reads. Reset invalidates
ownership,not secure RAM erasure. Missing stream needs reset. No key/poly RAM.
Gate138 commands/133 complete(95 success+38 errors)/5 resets;449992 scalar
writes/105728 packed reads;75 official KeyGen SKs loaded. No new production
engine/bank tree.61/61 checker corruptions reject;fresh full-KeyGen gate passes
8 complete/3 rejects/5 resets/37 checker faults. All56 prior RTL/SDC unchanged.
Token bfeaf559c72686430b40bed7c81df00e7000e9cf62a73d5f90951f35129a9e77.
Frozen evidence:evidence/stage5n4c1_sign_load.zip +.sha256,create-only. No
commit/branch/synthesis/netlist/PPA/full-UVM action;
6.757ns unchanged. Preserve prior evidence. Universal docs record scope.

LATEST Stage5N.4b:process/sign_hash_message.sv formats pure-message mu,
private mask seed(K||rnd||mu),challenge(mu||encoded_w1),and seed||nonce_le16.
Raw outputs64/64/32,48,64 bytes;mask route uses existing sampler mode2.
Prefix1024 +merge128 bits;no whole-message RAM,new engine or prior RTL change.
All55 previous RTL and6.757ns SDC byte-identical to Stage5N.4a.
Payload64/index16/bytes4/last;ignore poisoned unused bytes. Full16-bit
per-polynomial nonce through65535;future vector controller must prevent wrap.
Invalid level/context>255/total>65535 rejects before descriptor. After a
bad payload beat,finish declared absorption with zero-filled dummy bytes,
done_code2,discard entire digest. Owner MUST wait for raw/sampler retirement
before accepting formatter done(absorption completion only). Normal code0.
The formatter is a standalone client tested against actual dilithium_services,
not yet in main Sign. w1 is already encoded input;RTL w1 packing is pending.
Local component gate167 commands/162 completions(128 success+34 expected
errors)/5 resets;52618 absorption words/7760 SHAKE bytes/6400 mask values.
7760=6464 valid raw+1296 discarded error diagnostics.29 peer jobs add464
separate bytes;9 actual RTL digest forwards;61 checker corruptions rejected.
Python/C154 intended messages/420639 bytes/26 masks agree(C uses unchanged
SHAKE,w1 packing,mask sampling;one mask source belongs to reset-aborted test).
Fresh current gates:sign_hash,sign_decode(75 official KeyGen keys/436424
coefficients/35 faults),sign_service(33 faults),full_keygen8/3rejects/5aborts/
37 faults. Prior all75 full-KeyGen RTL evidence remains Stage5N.3,not rerun.
Token4e1391e067ed91c2497802338b6bc22b6e8242d19548366db80048158a913b73.
Frozen evidence:evidence/stage5n4b_sign_hash.zip +.sha256;create-only.
Next Stage5N.4c:decoded-key bank ingestion with whole-key private allocations,
success publication,rollback/reset/reuse;then key/hash retention,transforms,
mask generation,vector reductions,retry and signature packing/control.
Main Sign/Verify and Stage5N.4/Stage5N overall unfinished. Keep functionality
first;no commit/branch/synthesis/netlist/full-UVM/PPA advance. Preserve all
prior evidence. Full interface/limits/results are in universal docs below.

LATEST Stage5N.4a:standalone process/sign_key_decode.sv streams expanded SK:
rho32||K32||tr64||s1[l]||s2[k]||t0[k]. Input64/index10/bytes4/last,exact8
bytes/beat;320/504/612 words for levels2/3/5. Header1024 +reservoir76 bits;
no full-key/poly RAM. Output canonical23-bit coefficients,section2/poly3/
index8/last-poly/last-key/ID16. Header/coefficient/done held under stalls.
Strict unused-eta rejection is our validation choice;C/FIPS skDecode can
decode malformed eta patterns out of range. done0 validates ENTIRE key;
future bank owner must discard all earlier output on error. Missing data
without terminal input cannot be detected;reset cancels truncated streams.
No algebraic-key/security claim. Decoder is not yet connected to bank DMA,
main Sign or shared hash formatting. Existing54 RTL files unchanged.
Focused129 commands/124 completions(92 success,32 expected errors)/5 resets;
436424 exact emitted coefficients =409600 success+16585 error+10239 abort.
All75 published KeyGen secret keys decode(332800 coefficients);NOT sigGen.
Python/C128 full fixtures/549888 coefficients +byte roundtrip PASS;
35 capture corruptions rejected,including bad/missing reset prefixes.
Five reset checkpoints have exact prefixes;recovery reuses ID with new key.
Selector sign_decode uses existing single run.do/Python;no extra launchers.
Token8987bbbd148fec599b1b951fc16a6531f13baaea31dfc8a7d0cae5863ca45eae.
Next Stage5N.4b:signing hash-message formatting and real shared-Keccak checks;
then key-memory ingestion,vector reductions,retry/signature packing.
Main Sign/Verify still unsupported;Stage5N.4/Stage5N overall incomplete.
No commit/branch/synthesis/netlist/full-UVM/PPA action.6.757ns unchanged.
All3 current-source gates PASS:sign_decode,sign_service,full_keygen.
Service33 commands/30 complete/9 expected errors/3 resets/33 checker faults;
localKeyGen8 complete/3 rejects/5 resets/37 checker faults. Prior all75
official full-KeyGen RTL result remains in Stage5N.3 archive,not newly rerun.
Frozen evidence:evidence/stage5n4a_sign_decode.zip +.sha256,create-only.
Detailed execution/results in REFERENCE_VERIFICATION.md;preserve all prior
immutable archives. Historical milestone descriptions follow.

LATEST Stage5N.3:sign_process_dma connected to main-owned dilithium_services
through nested sign request/response records,row wrapper and bank arbitration.
One existing memory tree;no polynomial/key RAM or external top ports added.
KeyGen drives sign='0;main Sign/Verify remain unsupported. New DMA checks
every source read's owner/region/word/level/coefficient-domain/retained mode,
validates high23 before6-bit narrowing,and stores negative low19 modulo q.
CNB returns polynomial OR,Mhint writes0/1 and returns9-bit polynomial weight.
No in-place signing writes. Sources/results leased through held done;both
Decompose results publish after all64 word ACKs and both finish handshakes.
Late read/data/high errors drain/discard tentative allocations via nonzero
finish and clear process packet/reduction state;same-ID recovery is tested.
Focused DMA PASS:71 commands/65 completions/21 expected errors/6 resets;
14284 exact scalar writes/3570 packed ACKs,including1108/276 reset prefixes;
32 checker corruptions rejected. Shared service PASS:33 commands/30 completions/
9 expected errors/3 resets;192 sampled source words/768 exact result words;
33 checker faults. All levels2/3/5;actual SHAKE/sampler sources/shared banks.
Row/NTT/scalar/pending-read priority,held ownership and atomic publication pass.
Selectors sign_dma/sign_service use existing run.do/single Python script.
Current token:b224a41318be58d790ee39d066ce6d27290538fdf003a7ea282e7162265a86ac.
All six current-source gates PASS:sign_dma,sign_service,sign_process,
bank_process,full_keygen,nist_keygen. Local fullKeyGen8/3rejects/5aborts/
37 checker faults;official NIST75/75 keypairs/433600 exact bytes/41 faults.
All48 other prior RTL files/6.757ns unchanged. Only five previous RTL files
change(service types/wrappers and KeyGen zero assignment),plus new DMA.
Frozen evidence:evidence/stage5n3_sign_memory.zip +.sha256,create-only;
preserve prior archives. Details in REFERENCE_VERIFICATION.md.
Next Stage5N.4:signing key/input decode and hash formatting with independent
byte/field checks;then vector norm/hint reduction,retry and signature packing.
Stage5N overall unfinished. Keep functionality first/shared LightHD engines/
four-bank memory and6.757ns SDC. No PPA/netlist/UVM stage advance,commit or
branch operation. Ask only material decisions;routine choices delegated.
Universal docs updated;preserve all immutable archives. Historical status below.

LATEST Stage5N.2:working process/decompose.sv,decompose_x4.sv,cnb.sv,mhint.sv,
sign_process.sv. One elastic x4 transport,64 ordered groups/polynomial;
op0 Decompose,1 CNB,2 optimized low/high Mhint. Canonical23-bit inputs;
Decompose low is signed19-bit,high6. CNB kind0/1/2 = z/r0/ct0 bounds.
Lock ID/op/param/relevant kind;last iff63. Errors zero result and flush packet;
reset cancels held result/tracker/prefix reductions. Per-polynomial CNB sticky
OR and hint count9;vector reduction/retry/control remain later work.
Focused PASS:7752 accepted/7746 outputs/45 expected errors/6 aborted groups/
117 full packets(53 Decompose,44 CNB,20 Mhint),27 checker corruptions rejected.
30996 Python/C lane fixtures PASS;C decomposition exhaustively passes8380417
canonical inputs at each level. Do not call RTL tests exhaustive.
Early CNB failure followed by passing groups,reset after nonzero prefix,
isolated changing-op metadata and hint count256 are explicitly checked.
Three current gates PASS:sign_process,full_keygen8/3/5/37 checker faults,
nist_keygen75 keypairs/433600 bytes/41 checker faults. Source token:
9c78215f9e0edec3dfd474b7999acd338ba37a30f6ab46c46d9ed4ed55d19bd2.
All48 prior RTL files/6.757ns unchanged;full-key event streams equal Stage5N.1
excluding freshness. No current-source rerun claim for older diagnostic gates.
Immutable evidence:docs/dilithium_docs/evidence/stage5n2_sign_process.zip and
stage5n2_sign_process.sha256;create-only,preserve prior archives.
New selector sign_process uses same run.do/single Python prepare/compare/selftest.
No integration into main Sign/memory DMA yet. Main Sign/Verify unsupported.
Next Stage5N.3:checked shared-bank DMA/leases/acknowledged publication for x4
processes;coefficient domain/owner/parameter checks;canonical low conversion;
full stored-high validation before narrowing;error/abort/private partial data.
Then signing input/key decode/hash/vector reduction/retry/signature packing.
Stay within Stage5N;do not claim full Sign or start full UVM/PPA/netlists.
No commit,branch operation or synthesis. Ask about material scope/interface/
resource departures;routine shared LightHD-compatible choices are delegated.
Earlier status paragraphs below describe historical accepted milestones.

LATEST Stage5N.1:main dilithium.sv owns dilithium_services(one existing
keccak_sampler_row RAW_SERVICE=1 and one Bitpkg). keygen/keygen_encode are
clients;new helpers/dilithium_service_pkg.sv defines packed full-width ports.
No additional engine/bank/key RAM or request/response pipeline is introduced.
keygen_owner covers DISPATCH and child_busy,including post-done cleanup while
main is IDLE. Unowned requests zero;responses/faults remain visible.
Full-key TB verifies routed requests,unowned quiescence and cleanup lifetime.
Current gates PASS:full_keygen8/3rejects/5aborts/37faults;
nist_keygen75pairs/433600bytes/41faults;keygen7/3/4,34rows/172304writes/
8448reads/29faults;rounded_keygen7/3/4,34rows/190224writes/12800reads/36faults.
Source token830c05c8b16215688d1923497ed1b147ecf6b2aea526d4cf54688e8a0ab4a345.
Q local988082owned/195cleanup/52idle;NIST9142284/2225/151. Local campaign
6676943064ps unchanged. All local/NIST events equal Stage5M except token/Q.
All25 engines,row wrapper,Bitpkg and6.757ns unchanged. No PPA/synthesis claim.
Frozen evidence:docs/dilithium_docs/evidence/stage5n1_shared_services.zip and
stage5n1_shared_services.sha256;create-only,preserve previous archives.
Next Stage5N.2:working Decompose x4,CNB,Mhint blocks with independent Python/C
boundary tests;then shared DMA,signing input/key decode/hash/retry/packing
substeps. Sign/Verify are still unsupported;Stage5N is not complete overall.
Never duplicate accelerator trees or add fake sign/verify placeholders.
Preserve complete KeyGen/NIST gates. Four gates above are freshly rerun;
other historical focused results stay in prior archives. Same launcher/script
and universal docs. No commit,branch operation or synthesis in this stage.
Ask the user about material scope/interface/resource departures;routine
LightHD-compatible choices are delegated. Earlier milestone text is historical.

LATEST Stage5M:all75 official NIST ACVP KeyGen cases PASS,25 each at
ML-DSA-44/65/87(level2/3/5).54200 exact64-bit key words/433600 bytes,
18300 PK hash words,4800 tr bytes,112000 field-read metadata records.
39/39 checker corruptions rejected. nist_keygen uses the same run.do,
dilithium_vectors.py and tb_full_keygen(NIST_VECTORS=1);expected keys are
copied directly from pinned NIST JSON,not generated by C/Python.
Corpus:NIST/ML-DSA-keyGen-FIPS204;commit2972def23bf9f3680c2c531561ed9bdd0f1086ad.
Raw files have script-pinned SHA256 and provenance.json. All75 C pairs also
agree with NIST. Source token22f42dd20700ee8b0e014dee66c45118bcb0edc647f8ded54949f658bd0a6461.
The local full_keygen gate freshly repeats8 success/3 rejects/5 aborts and
35 checker faults on that token. These two current gates pass;the prior
all16-gate result is preserved in Stage5L,not claimed freshly rerun here.
All46 RTL SV files and6.757ns SDC unchanged from Stage5L.
Frozen evidence:evidence/stage5m_nist_keygen.zip and stage5m_nist_keygen.sha256
under docs/dilithium_docs;create-only,preserve earlier archives.
Next Stage5N:shared-resource Sign integration,remaining Decompose/CNB/MakeHint
and signing control in bounded steps. Expose existing datapath/packer ownership
at main-controller arbitration;never duplicate whole accelerator trees.
Keep full-KeyGen/NIST byte tests passing. Ask for material scope/interface/
resource departures;routine LightHD-compatible choices are delegated.
No Sign/Verify implementation,full UVM/PPA advance,commit/branch operation,
synthesis or netlist run is claimed/authorized by this stage.
Earlier Stage5L and older status statements below are historical milestones.

Current Stage5L:FULL_KEYGEN=1 on dilithium/keygen implements complete encoded
PK/SK output through helpers/keygen_encode.sv,using existing banks/Bitpkg/raw
Keccak. It enables P2R,accepts internal rows,hashes full PK into64-byte tr,
then emits SK. Separate host/hash word acknowledgements prevent duplicates.
No encoded-key RAM or second hash engine. Default0 preserves diagnostic modes.
key_valid/ready,data64,bytes4,type1,index10,last1,ID16 ports now exist.
External polynomial inspection is disabled in full-key mode.

Selector5/full_keygen passes8 complete C-reference keypairs(all3 levels),
3 expected rejects,5 reset aborts;5433 exact output words,2058 hash words,
656 tr bytes,11179 read-metadata records.35 checker corruptions reject.
434 host-ahead/1939 hash-ahead cycles witness independent acknowledgement order.
Test randombytes injects xi into unchanged C crypto_sign_keypair;13 valid
fixture seeds produce complete expected pairs. These are local reference
vectors,NOT official downloaded NIST conformance yet.
All16 focused integration gates and their checker fault tests freshly PASS on
source token b4c3284a2fe1cacad64c73cde32f43674e3ad3c17fd04b6197bd033a0b6b55b6.
Frozen evidence:docs/dilithium_docs/evidence/stage5l_full_keygen.zip and
stage5l_full_keygen.sha256;create-only,preserve all earlier archives.
Next Stage5M:official NIST KeyGen vectors/provenance and exact comparison;
then Sign/remaining LightHD blocks/Verify. No PPA/UVM-stage advance until
required supported outputs. No commit/branch/netlist/synthesis authorized here.
When adding Sign/Verify,lift/expose the existing datapath/packer ownership to
main-controller arbitration;operation FSMs must share the current engines and
banks,not instantiate duplicate accelerator trees. Keep whole-KeyGen byte
tests passing through that future refactor.
Older Stage5K planned-interface statements below are historical;Stage5L above
is current. Keep all immutable archives and accepted engine sources.

Stage5K frozen evidence:all15 focused gates,independent comparisons and checker
fault tests freshly PASS on one source token. Preserve create-only archive
docs/dilithium_docs/evidence/stage5k_rounding_bitpkg.zip and SHA256 sidecar.

User direction reaffirmed2026-10-21:reconstruct LightHD's complete controller,
shared processing blocks and four-bank reuse schedule;improve measured
weaknesses and adapt interfaces for our accepted engines. Make routine
architecture choices that support that goal;do not repeatedly ask for them.
Do not claim source-identical reconstruction from an incomplete paper or treat
compatibility changes as measured PPA improvements.
Selected full-key output:tagged64-bit words with byte count/backpressure,
retain t1/t0 in existing banks,no extra encoded-key RAM. This is our compatible
interface choice,not a claimed published LightHD port specification.
Next key sequencer should start SHAKE256(pk,64) only after matrix sampling
finishes,share the existing raw Keccak service,and fork stable PK words to
both hash/host sinks exactly once. Collect tr,then emit SK fields;cleanup
waits for key output/completion acceptance. Specification records the planned
word tags/order. This interface is selected,not yet implemented.

Stage5K:ROUND_OUTPUTS=1 on keygen/dilithium connects P2R and retains t0 at56+i,
t1 at40+i through overall completion;cleanup releases them after raw secrets.
Default0 preserves Stage5J. rounded_keygen test:7 complete,3 rejects,4 resets,
34 rows,190224 scalar values,12800 exact92-bit reads,36 checker faults PASS.
No additional physical/logical banks;both arrays use existing regions8..15.

process/bitpkg.sv implements t1(10 bits),t0(13),eta-s(3/4) polynomial encoding.
One87-bit reservoir;tagged64-bit words,held completion;not a complete key-byte
sequencer yet. bitpkg test:97 commands,60 successes,31 expected errors,6 resets,
18292 input values,2482 exact words,15 checker faults. Python/C packers agree on
66 valid fixture packets/18496 bytes;prepare builds C models at levels2/3/5.
New C wrapper:tb/tb_dilithium/bitpkg_reference.c;source token hashes dependencies.
Use selectors5/rounded_keygen and5/bitpkg in the same run.do/Python.
Next:bank read/Bitpkg routing,full key field order and SHAKE256(pk,64).
User delegated the choice:use tagged64-bit key streaming and retained rounded
arrays in existing banks,without encoded-key RAM. Independent rounding/packing
work is authorized. No new PPA/commit/branch/netlist work.

Current Stage5J:controller/keygen.sv autonomously samples all s1/s2 and all
matrix rows,retains/Pre-transforms s1,and returns t=A*s1+s2 at all3 levels.
controller/dilithium.sv is the actual operation FSM;op0 polynomial phase works;
Sign/Verify explicitly unsupported(code2),not implemented. Invalid level code1.
7 complete operations,3 rejects,4 reset aborts;34 rows,172304 exact scalar
writes,8448 exact92-bit reads,29 checker corruptions PASS. Same-ID different-xi
recovery,16-bit ID wrap and cleanup/restart are checked.136 pending-read
handoff checks protect the final response before freeing output regions.
All13 focused source/comparison/checker gates freshly PASS on one source token.
Create-only evidence:docs/dilithium_docs/evidence/stage5j_keygen_polynomials.zip
and matching SHA256 sidecar;preserve all checkpoints.
Select5/keygen;read REFERENCE_VERIFICATION.md and MEMORY_MAP.md before edits.

User's current layout:root memory.sv,keygen.sv,sign.sv,verify.sv,dilithium.sv;
Sign/Verify files added with working implementation later,not placeholder FSMs.
All LightHD process blocks belong in process/:P2R,Decompose x4,CNB,Mhint,
Bitpkg plus required UseHint/checking helpers. power2round.sv now contains
working extracted arithmetic;other new process blocks remain planned.
Active bank_poly_store renamed module memory in root memory.sv;the historical
scalar memory is slot_memory under legacy/. Other helper paths:datapath/,
helpers/,memory/;build scripts/QSF/tests updated. Historical snapshots keep
their old filenames;do not alter immutable archives. Engine RTL unchanged.
Next:connect P2R and key bit packing,hash encoded public key,and compare full
KeyGen key bytes. Ask about major external key storage/output choices.
No new synthesis/PPA,netlist,commit or branch action authorized by continuation.

Latest Stage5I PASS:seed-retaining keygen_sample_source.sv now drives actual
sampling through optional RAW_SERVICE=1 on banked NTT/row wrappers. One shared
dual Keccak,not a second hash engine. Test selector5/seed_row uses the existing
tb_row_accumulate parameter SEED_SOURCE=1;selector row preserves its old path.
190 commands=20 successful seed expansions+163 samples+7 adapter rejections.
2560 exact hash bytes,1103 absorption words;rho/rho-prime/K match Python.
13 complete rows,27 row rejections,7 row abort/recovery cases,12544 exact92-bit
readbacks PASS;23 checker corruptions rejected. All11 prior focused gates
freshly PASS on the same current source token. No new synthesis/PPA claim.
Read REFERENCE_VERIFICATION.md for commands and exact scope. Seed fixtures are
local FIPS-derived,not official full-KeyGen vectors. The bench still schedules
commands;connected tests use s1 and two matrix rows per level. Next Stage5J:
autonomous KeyGen polynomial scheduling,retain s2 and add it to inverse rows,
then connect rounding/key encoding. Keep functionality-first scope and6.757ns.
No commit/branch/netlist/synthesis work authorized by an ordinary continuation.
Create-only Stage5I evidence:evidence/stage5i_seed_row.zip plus SHA256 sidecar
under docs/dilithium_docs. Preserve it and all prior immutable archives.

## Active direction: functionality first (user decision 2026-10-20)

The user explicitly stopped timing optimization before memory. Integrate the
remaining blocks and establish correct full-operation outputs first; optimize
Fmax, actual placed ALMs and throughput afterward in Stage7. This supersedes
the earlier timing-first gate. Keep the 6.757 ns benchmark constraint; it is
not a requirement for starting Stage3. Do not start more timing experiments.

Branch: integration, created from sampler_v1 at e1b9c84. No commit or push
without explicit instruction. Announce each stage, ask about major architecture
decisions and report completed work with evidence and the next action.
Preserve accepted standalone source/evidence and existing uncommitted work.

Read docs/dilithium_docs/DILITHIUM_PLAN.md first. Integration == Dilithium:
one universal documentation suite under docs/dilithium_docs. RTL layout is
src/keccak, src/ntt, src/sampler, src/controller/process,
src/controller/memory.sv and src/controller/dilithium.sv. Import each accepted
module with its standalone UVM, sim, Quartus and docs assets when needed.
Focused non-UVM tests under tb/tb_dilithium are authorized during integration.
Full-operation reference checks precede comprehensive full-system UVM/PPA work.

Stage1 Keccak import from keccak_v2 fe54a78 is complete: 904 source UVM
transactions plus dual suites and 6364 published NIST output comparisons PASS.
Its immutable import archive preserves the original RTL and standalone PPA.
Current integration Keccak has subsequently verified control changes; do not
apply historical standalone PPA to the modified source.

Stage2 functional PASS. Current trial8 source has atomic ownership/command
binding, a two-slot registered-credit bridge and handshake-before-stop draining.
104 jobs: 88 complete, 8 expected errors, 8 reset aborts; 23089 exact coefficient
checks. All24 mode/parameter/context combinations and12 checker faults PASS.
The modified Keccak core also passes904 transactions plus dual suites and6364
NIST outputs. Sampler RTL is unchanged. Trial8 cycle rows match trial7.
Launcher:sim/dilithium/run.do; checker:sim/dilithium/dilithium_vectors.py.
No full-operation Dilithium/NIST/UVM or integrated netlist completion is claimed.

Historical Stage2 main seed1 fit:11293 PLACED ALMs,7557 registers,15970 ALUTs,
one M10K/1024bits,zero DSP;137.74MHz worst Fmax,setup-0.503ns/hold+0.157ns
at6.757ns. All original sampler/Keccak structural guards PASS. Timing is OPEN.
Main and isolated seed2 compiles have finished;seed2 is not selected.
Keep verified trial8 functional RTL; no new timing experiments before memory.
Initial evidence archive stage2_subsystem_initial.zip is immutable and describes
the earlier single-slot source,not current-source PPA.

Stage3 is complete for the focused functional gate. The user approved the
configurable four-slot pool on2026-10-20. memory.sv and keccak_sampler_memory.sv
implement it.104 jobs/88 complete/8 errors/8 aborts,23180 exact writes and22528
exact readbacks PASS;88 releases,99 rejected reads,8 pool-stall cycles,1321
read-stall cycles and170 concurrent read/write cycles.8 memory fault kinds
are contained;12 Python corruptions rejected. Stage2 freshly passes unchanged.
Commit requires256 writes plus successful matching external status acceptance.
Read data/metadata hold under stalls;release waits for pending responses;
reset invalidates metadata,not RAM. Sticky protocol faults require reset.
Read MEMORY_MAP.md for the full contract;Stage4 below adds the IN_USE leases.
Create-only evidence:docs/dilithium_docs/evidence/stage3_subsystem.zip and
stage3_subsystem.sha256;preserve them. The archive includes source/checker
manifests and captures;no Stage3 fitted PPA is claimed.
Stage4 is complete for its focused functional gate. Imported57 NTT package files
from ntt_v2:577a34b2fff19864cb16b490b7629ed211613000. Six RTL files and existing
UVM are byte-identical;ntt_import_manifest.csv records path adapters/provenance.
Locations:src/ntt,tb_uvm/tb_uvm_ntt_LightHD,sim/ntt,quartus/ntt,FIPS204_NTT,
docs/ntt_docs. No obsolete experiment tree or generated build database imported.
Relocated standalone UVM748 jobs/191488 values PASS;32 group type mean90.4731%,
raw code12990/14093=92.17%. Standalone Python18 cases/4608 values PASS.
These are NTT-only results,not integrated coverage or a fresh synthesis result.

New helper:keccak_sampler_ntt. Same four-slot pool now supports IN_USE locks,
separate result reservations and explicit domain/bounded-eligibility metadata.
Sequential sampling/compute;one outstanding DMA read. NTT uses canonical23-bit
residues and Dilithium ordering;INTT scales by1/256. Matrix A goes straight to
PWM. Pre checks all values represent[-4,4]. Invalid/stale source code1;domain/
parameter/Pre rejection code2;success0. Invalid commands never start the engine.
Compute source slots are protected even while waiting for a free destination;
only unrelated slots may be released then. Inputs are preserved;PWM aliasing
is allowed. Results publish only after256 writes and engine done. Faults halt
the helper until coordinated reset. Do not mistake mode metadata for domain.

Stage4 source/Python PASS:16 sampled jobs,50 commands,30 complete results,
17 rejects,3 reset aborts.4096 sampled values,9745 DMA values,7713 NTT outputs
(7680 complete+33 aborted-prefix values),11776 readbacks.43 releases,6 invalid
reads,4 resets. Witnesses:24 pool-wait cycles,188 completion-stall cycles,
699 read-stall cycles,33 source locks.12 checker corruptions rejected.
Reset targets:load17 values,coreRUN after256 loads,and writeback after32 outputs;
same IDs recover using different messages. Stage2/3 freshly revalidated.

Default sim/dilithium/run.do runs Stage4;set DILITHIUM_STAGE 2 or3 for old gates.
One Python prepare/check/compare/selftest script;--stage 2/3/4,default4.
Shared sampling files plus stage4_expected.txt with26 arithmetic expectations.
Quartus top is now keccak_sampler_ntt,294 virtual non-clock bits;6.757ns unchanged.
NO Stage4 synthesis/fit/netlist/PPA run. Old Stage2 reports are historical only.
Create-only Stage4 evidence:docs/dilithium_docs/evidence/stage4_subsystem.zip
and stage4_subsystem.sha256. Preserve all existing milestone archives unchanged.
Stage5A audit/shared arithmetic is implemented;Stage5 full controller is NOT done.
User decision2026-10-20:implement final FIPS204 ML-DSA-44/65/87,retaining
LightHD-style level2/3/5 names. Parameter port0/1/2 maps to44/65/87.
These are naming aliases,not a claim of legacy round-3 byte equivalence.
The user previously chose LightHD's full scope,but
its printed32-byte tr/challenge rules conflict with our local software's64-byte
tr,parameter-bound seed expansion and32/48/64-byte challenge lengths. The cited
2023 draft itself uses64-byte tr. Do not infer a byte-exact paper implementation.
Final FIPS204 now governs dependent seed/message/key bytes.
Audit evidence/table and25-file reference_manifest.csv are in universal docs.

Shared controller/process/poly_process.sv is independent of this choice:
opcode0 ADD,1 SUB,2 Power2Round,3 invalid;canonical23-bit residues,D=13;
rounding high10,signed low14,packed t0=4096-low13. Positive tie4096 is retained.
One elastic stage transports ID/index/last;13 errors cover bad opcode,operand
and framing. Scalar unit has no polynomial ordering/memory ownership yet.
PASS:10349 accepted,10346 exact outputs,3 reset aborts,13 expected errors;
9208 dense rounding points;10009 replacements,3505 input/3511 output stalls.
Python/C agree on all cases;unchanged C Power2Round separately passes8380417
canonical inputs(checksum1c750000). That exhaustive C check is NOT exhaustive RTL.
12 process checker corruptions rejected. Stage2/3/4 all freshly pass again.

Main top/default stage remains4(keccak_sampler_ntt). Select DILITHIUM_STAGE 5
and Python --stage 5 for the isolated process gate,NOT full KeyGen. prepare now
needs GCC at C:/MinGW/bin/gcc.exe;build outputs stay in sim/dilithium/reference_build.
No existing software/sampler RTL/UVM/Quartus source was changed. Quartus lists
the process source but it is not connected to the top;294 virtual non-clock bits
and6.757ns remain. No PPA work or new synthesis/netlist run.
Create-only Stage5A evidence:evidence/stage5a_process.zip and .sha256 under
docs/dilithium_docs. Preserve earlier archives unchanged.

Stage5B keygen_hash_message.sv formats xi32||K||L,rho32||column||row,and
rho-prime64||nonce_le16. Validates parameter,row/column and KeyGen secret nonce.
165 commands/162 done(14 expected errors)/3 reset aborts PASS.883 absorption
words and5888 exact real-Keccak SHAKE bytes match Python;12 corruptions rejected.
All102 matrix positions/34 secret nonces tested. This is a message builder,
not a seed-result collector or main-controller connection. Done means message
accepted,not hash complete. Seed expansion requests128 finite bytes;sampling
requests continuous0. Focused hash-only TB bounds sampling to32 output bytes.
In Tcl:set DILITHIUM_STAGE 5;set DILITHIUM_TEST hash_format.
Python:--stage 5 --unit hash_format. No accepted engine source changed.

Stage5C optional RAW_SERVICE in keccak_sampler and keygen_seed_collect now PASS.
Same two hash cores;captured per-core type/ID/remaining bytes;registered held
raw completion;ingress owner routes64-bit input;raw output bypasses sampler.
Finite raw lengths1..65535;zero refuses raw request. Raw descriptor priority.
26 commands,18 raw requests,7 sampled polynomials,7 seed results(including1
parameter error),3 reset aborts;1699 exact SHAKE bytes/1792 coefficients PASS.
Sampling uses actual RTL-collected rho/rho-prime,not Python seed injection.
Both core tags,rate-boundary short beats,raw/raw and raw/sampling ownership,
arbitration,held completions and coordinated reset/ID reuse pass.12 corruptions
rejected. All Stage2/3/4 and Stage5 process/hash_format gates freshly pass.
Use DILITHIUM_TEST shared_hash with stage5;Python --stage 5 --unit shared_hash.
Main Stage3/4 wrappers tie raw ports off;top ports/four-slot capacity unchanged.
New PROCESS_BLOCKS.md specifies implemented/planned processing;MEMORY_MAP.md
has dimensioned memory diagram and the concrete KeyGen storage proposal.

User resolved the storage choice2026-10-20:"whatever LightHD is doing do that".
Follow published four logical1024x92-bit dual-port banks,not either proposed
scalar-pool alternative. Capacity376832bits=47104bytes=46KiB;this is NOT four
physical M10Ks. Read MEMORY_MAP.md selected architecture/Sign region map.
Do not allocate old proposal's extra7488 encoded-key bytes automatically.
Final FIPS204 bytes/level2/3/5 labels remain selected.

Stage5D foundation poly_bram.sv/memory_banks.sv now source/Python PASS.
Full-word92-bit writes,independent A/B response slots per bank,A-priority
serialization when same-address pair contains a write;dual reads allowed.
14872 accepted/14864 responses,9509 exact92-bit reads,5355 write acks,
8 reset-aborted acks and8 unaccepted blocked offers canceled.4096 words covered;
73 collision events,4112 dual-read pairs,1031 all-eight-port cycles;12 corruptions
rejected. No RAM reset;payload retention checked. RAM inference/PPA not measured.
Use stage5,DILITHIUM_TEST bank_memory;Python --stage 5 --unit bank_memory.
The old Stage4 top still uses memory.sv/four slots. Do not claim bank migration
or LightHD32-cycle NTT loading:current NTT input remains scalar23-bit.

Stage5E bank_poly_store/keccak_sampler_banks now connect real sampling to banks.
Caller-select bank2/region4;64 aligned64-word regions. Per-core92-bit packing,
tag/index/canonical checks,64 write acks before successful external status
commit;protected92-bit reads/release;domain and[-4,4]metadata;sticky fault/reset.
PASS104 jobs:88 complete,8 errors,8 aborts;23173 coefficient checks,
5792 packed writes,5790 acks,5632 read words=22528 complete coefficients.
Partial aborted work accounts for645 coefficients/160 writes/158 acks;two
writes are reset before ack acceptance;five coefficients remain partial words.
All64 regions,24 core/mode/param combinations;occupied-target stalls8,read
stalls1070,read/write overlaps50,held-read resets2,invalidreads11.
Eight protocol fault cases contained;12 checker corruptions rejected.
Use stage5,DILITHIUM_TEST bank_store;Python --stage 5 --unit bank_store.
Main defaultStage4 still old all-engine top;bank sampler is a new connected
path,not yet NTT or process migration. No new synthesis/netlist/PPA/coverage.
All seven previous gates and their checker selftests freshly PASS. Immutable
evidence:docs/dilithium_docs/evidence/stage5e_bank_store.zip and .sha256;
115 members verified;do not overwrite. New source/TB files are captured there.

Stage5F completes the banked NTT connection through keccak_sampler_ntt_banks.
Sampling/compute are sequential;the existing bank_poly_store packer0 is reused
after sampling drains. New allocation flags set computed domain explicitly.
Sources lease at acceptance;release blocked through held completion retirement.
Explicit destination aliases reject(code3);busy distinct destinations wait while
unrelated regions may release. External pending reads block compute acceptance;
allocated results cannot release before completion retirement. Each92-bit read
feeds four23-bit scalar engine beats;PWM loads A then B. Publication waits for
256 results,64 write acknowledgements and engine completion. No extra cores.
Source/Python PASS:16 sample jobs,54 commands,30 results,21 rejections,3 aborts;
4096 sample coefficients,9746 DMA values,7712 NTT outputs,2952 packed writes,
2951 acks,2944 exact92-bit reads. Four banks,same-bank/cross-bank,A==B,all ops/
params,source preservation,Pre bounds and resets tested. Ownership witnesses:
24 destination waits,33 leases,4 read-lock checks,120 held-result checks.
Checker19/19 faults rejected. All eight earlier focused gates and selftests
freshly PASS at the current token. Use stage5/bank_ntt,Python --stage 5 --unit
bank_ntt. Default4 and Quartus top remain legacy
scalar baselines. No new PPA/netlist/full-system coverage/full-KeyGen claim.

Stage5G completes banked process reads/writeback. New process/poly_process_dma.sv
uses the existing poly_process arithmetic and two92-bit caches. Optional
PROCESS_SERVICE=1 in keccak_sampler_ntt_banks enables it;default0 preserves the
NTT-only gate. Same four banks/two packers;exclusive sampling/NTT/process access.
ADD/SUB require matching domains/parameters;P2R coefficient domain only. Source
leases protect accepted commands while waiting for distinct explicit destinations.
P2R low is canonical modulo q,high zero-extended10-bit,in separate64-word regions.
No encoded-key bytes or extra polynomial RAM. Low/high commit separately but
public visibility is atomic;both result/source leases last through held completion.
Status0 success,1 source,2 domain/param,3 alias,4 invalid op. Fault requires reset.
Source/Python/C PASS:23 samples,15 NTT commands,71 process commands(34 successes,
33 rejections,4 aborts);8978 process inputs,8976 completed results,22297 scalar
writes,5574 packed writes/acks,8512 exact92-bit reads. All three parameters,
real PWM/ADD/SUB/INTT/P2R and canonical-low -> NTT chains,source preservation,
busy destinations,held results and resets tested. Reset phases:initial DMA,
partial writeback,between low/high writes,and after low commit before high commit.
Witnesses36 wait checks,188 held-result checks,4 pending-read checks,22 actual
partial-publication snapshots.29 checker corruptions rejected. Use selector5/
bank_process and Python --stage 5 --unit bank_process. Main/default Quartus top
remains legacy;no synthesis/netlist/PPA/full-system coverage/full-KeyGen claim.
Exact commands and representation limits are in shared REFERENCE_VERIFICATION,
MEMORY_MAP and PROCESS_BLOCKS docs. Preserve all earlier checkpoints unchanged.
All nine earlier source/checker gates freshly pass at the current token.
Create-only evidence:docs/dilithium_docs/evidence/stage5g_bank_process.zip and
stage5g_bank_process.sha256;verify CRC/manifest/member hashes before reporting.
That Stage5G snapshot uses distinct destinations;Stage5H below adds explicit
destructive row accumulation with checked ownership/read-before-write.

Stage5H completes staged-row scheduling through row_accumulate.sv and
keccak_sampler_row.sv(one existing banked subsystem,not another engine/RAM).
Level2/3/5 use4/5/7 staged A_hat/s1_hat pairs. Validate all sources before child
arithmetic;retain/lease sources throughout. First PWM initializes accumulator;
later PWMs use scratch;explicit in-place ADD overwrites accumulator;release
scratch after each ADD;final inverse writes u=A*s1;release accumulator.
Hold output/source leases through row completion retirement. Busy/alias workspace
code3 rejects before work;source1/domain-level2/invalid-param-row4;success0.
Unexpected child errors halt until reset. Three workspace regions are caller-
selected and distinct from sources. All outside interfaces block while row owns.
Row index input4bits validates against k4/6/8;descriptor arrays7entries use l.

New process_inplace_i defaults0 in old benches;1 allows ADD/SUB dest=A only.
P2R still rejects in-place. Store alloc_rewrite_i rebinds a COMPLETE source to
WRITING under new ID;private reads allowed only when4*word>=scalar write count.
DMA caches both92-bit source words before writing any lane,so original values
are consumed in order. Reset invalidates partial rewrite;payload RAM not reset.
Ordinary flag0 process commands retain prior behavior. Row tests exercise ADD
in-place,not in-place SUB. Old source A is consumed;retained secrets/B untouched.

Source/Python/C PASS:47 row commands=13 successes+27 rejections+7 aborts;
163 real samples,161 NTT/Pre/PWM/INTT commands,55 in-place ADDs;96264 scalar
writes,24066 packed writes/acks,12544 exact92-bit public reads,6918 checked
old-word cache reads.6 reference rows also match independent coefficient-domain
schoolbook products;C ADD13833 inputs/13832 completed results.26 checker faults
rejected. Two different matrix rows reuse transformed secrets per level;eligible
secrets use Pre-NTT and ordinary NTT. Resets:validation,PWM,first accumulator,
partial destructive ADD,scratch release,inverse execution,held row completion.
160 held-row refusal checks,4 pending-read checks;IDs reused with different row.
Use selector5/row and Python --stage 5 --unit row. Fixture messages are final
FIPS formatted but seed collection/message RTL are not connected by this gate.
No full KeyGen,NIST whole-operation,UVM coverage or new synthesis/PPA claim.
Default4 and Quartus top remain scalar baselines. Preserve earlier archives.
All ten earlier source gates/checker selftests freshly PASS at the current
source token. Create-only evidence:docs/dilithium_docs/evidence/stage5h_row.zip
and stage5h_row.sha256;verify CRC,manifest hashes and member bytes. Keep all
earlier checkpoints unchanged. No extra trial JSON/checkpoint trees are needed.

NEXT:shared seed/hash/nonce scheduling for first level2 KeyGen,then s2 addition,
Power2Round and key byte encoding/full-reference comparison. Follow LightHD secret retention,row accumulator
reuse,bounded A staging and later port-overlap schedule. Figure2 describes peak
Sign regions,not a complete KeyGen FSM table;derive/check missing lifetimes.
NTT still accepts
one23-bit coefficient per beat;do not claim32-cycle loading yet. Aligned-region
sampling metadata is not the final packed w1/key-field ownership policy.
No extra key buffers/ports or PPA optimization silently added.
Create-only Stage5C evidence:docs/dilithium_docs/evidence/stage5c_shared_hash.zip
and stage5c_shared_hash.sha256.99 members verified;do not overwrite. Current
PROCESS_BLOCKS corrects the snapshot's t1-shift explanation(1023<<13=q-1);
no RTL/result changes from that documentation correction.
MEMORY_MAP.md retains superseded scalar-pool proposals for context. The shared raw service is
tested but not wired into the main Stage4 top;do not duplicate full engines.
Do not silently expand memory or add key-output interfaces. Ask major decisions.
Do not start PPA optimization or claim full Dilithium/KeyGen.
Keep native128 sampler processing deferred:input beats still issue64-bit chunks.

Scope:final FIPS204 KeyGen/Sign/Verify,using level2/3/5 names for44/65/87,
starting level2. Full-operation official vectors must match this selected format.
No full-operation conformance is established by the component tests.

The sampler history below is accepted standalone evidence. Its old instructions
restricting integration are superseded by the user's integration authorization.

## Accepted sampler baseline inherited from sampler_v1

User accepted Stage4.9r on2026-10-19. Main baseline:3537 actual placed ALMs,
164.74MHz worst Fmax,+0.430ns setup,+0.141ns hold at unchanged6.500ns.
3931 registers,4256 ALUTs,one M10K/1024bits,zero DSP. All4 corners0TNS.
Quartus seed1,HIGH PERFORMANCE EFFORT,physical register retiming OFF.
Original payload/sign/reservation structural guards pass. Area ALWAYS means
actual final-placement ALMs. Never use needed estimates for area claims.

Read README.md and docs/sampler_docs/post_midyear/SAMPLER_PLAN.md before work,
then SPECIFICATION.md,COVERAGE.md,THROUGHPUT.md,STAGE4_9R_RESULTS.json and the
user's docs/sampler_docs/LIGHTHD_SAMPLER.md and SAMPLER.md.
Main UVM621 complete/182 expected errors/51 aborts/159628 comparisons PASS;
functional1652/1721=95.99%,code15093/15799=95.53%. Python104/19456,C48/12288,
checker12,performance96 and five zero-credit fault gates PASS. Source checks
reuse byte-identical O after26 hashes;R has fresh fit/timing/structural evidence.
All96 performance rows match the preceding selected implementation.

Stage5 completed on2026-10-19 using DISTINCT current synthesis/fit netlists.
Each main-UVM run:184 jobs,156 complete,24 expected errors,4 reset aborts,
39936 checks,zero errors/fatals. All104-job source/synthesis/fit captures match
byte-for-byte and Python19456 values. Fresh source621/159628,P/C48/12288,
checker12 pass. Source functional95.99%,code95.53%;netlists1255/1721=72.92%,
source-only groups unsampled. Timing/structural refresh passes unchanged.
Read SAMPLER_NETLIST_RESULTS.json and evidence/sampler_stage5.zip. Preserve
both accepted R and Stage5 evidence. The96 performance CSV rows match accepted
archive;not rerun. CycloneV netlists are functional only;TimeQuest is timing.
Next Stage6 requires separate integration-branch/import authorization. Do not
start integration,change branches,import modules or commit without instruction.

RTL:src/sampler;UVM:tb_uvm/tb_uvm_sampler;common templates:tb_uvm/tb_uvm_reusable;
simulation:sim/sampler;Quartus:quartus/sampler;docs:docs/sampler_docs/post_midyear.
Keep exactly3 .do launchers:run_uvm.do,run_post_synthesis.do,run_post_fit.do.
Vectors/performance are modes of the main UVM. Independent models must not call
DUT functions. Coverage credits only scoreboard-accepted observations. Genuine
gaps stay visible;no artificial percentage ceiling or impossible bins.

Native128 remains inactive:tagged128-bit beats issue64-bit chunks. Current
pipeline:capture→staged prepare→extract→local compact→packed/admit→aligned
commit→32-entry/context collectors→per-context read→shared formatted output.
Mask conversion stays before packing;secret values remain4-bit encoded until
output formatting. Preserve complete state,credit/quota ownership and drain
before reuse. Do not relax6.500ns or waive original register guards.

Frozen Stage4.9r JSON/ZIP/SHA are immutable;never overwrite them. Its recorded
acceptance-pending field predates the explicit user acceptance. Mutable docs
record that acceptance. User-confirmed cleanup on2026-10-19 removed obsolete
checkpoint records/archives and leftover sim/ntt_LightHD and quartus/ntt_LightHD
folders. Stage4.9r evidence remains,with the new Stage5 result/archive/checksum added. All49 protected
source/model/settings/evidence files passed before/after hash checks. Two Python
analysis/checkpoint helpers remain after automatic review rejected their deletion.
