onerror {quit -code 1 -f}
vlib sim/dilithium/work_lighthd_load
vmap lighthd_load_work sim/dilithium/work_lighthd_load
vlog -sv -work lighthd_load_work src/keccak/keccak_pkg.sv
foreach n {keccak_param_unit keccak_absorb_unit theta_step rho_step pi_step chi_step iota_step keccak_step_unit keccak_output_unit keccak_core keccak_dual_interleaved} {vlog -sv -work lighthd_load_work src/keccak/$n.sv}
vlog -sv -work lighthd_load_work src/sampler/sampler_pkg.sv src/sampler/sampler_input_prepare.sv src/sampler/sampler_mask_unpack.sv src/sampler/sampler_secret_lane.sv src/sampler/sampler_compact.sv src/sampler/sampler_ball.sv src/sampler/sampler.sv src/ntt/ntt_pkg.sv src/ntt/mod_mul.sv src/ntt/butterfly_unit.sv src/ntt/twiddle_rom.sv src/ntt/ntt_core.sv src/controller/helpers/lighthd_pkg.sv src/controller/memory/poly_bram.sv src/controller/memory/memory_banks.sv src/controller/memory/lighthd_memory_port.sv src/controller/memory/lighthd_memory.sv src/controller/memory/lighthd_memory_router.sv src/controller/memory/lighthd_bank_fabric.sv src/controller/process/lighthd_secret_regroup.sv src/controller/process/power2round.sv src/controller/process/cnb.sv src/controller/process/mhint.sv src/controller/process/lighthd_process.sv src/controller/process/lighthd_bitpkg.sv src/controller/datapath/keccak_sampler.sv src/controller/datapath/lighthd_sampler_writer.sv src/controller/process/lighthd_bitunpkg.sv src/controller/datapath/lighthd_load_decode.sv src/controller/datapath/lighthd_hash_sampler.sv src/controller/datapath/lighthd_ntt_dma.sv src/controller/datapath/lighthd_process_dma.sv src/controller/datapath/lighthd_datapath.sv src/controller/process/lighthd_hintunpkg.sv src/controller/lighthd_verify_input.sv src/controller/process/sign_hash_message.sv src/controller/lighthd_verify.sv src/controller/lighthd_keygen.sv src/controller/lighthd_sign_input.sv src/controller/process/lighthd_hintpkg.sv src/controller/lighthd_sign.sv src/controller/lighthd_dilithium.sv tb/tb_dilithium/tb_lighthd_main.sv
vsim -gDIAGNOSTIC=0 -gPROTOCOL=1 lighthd_load_work.tb_lighthd_main
run -all
quit -f






