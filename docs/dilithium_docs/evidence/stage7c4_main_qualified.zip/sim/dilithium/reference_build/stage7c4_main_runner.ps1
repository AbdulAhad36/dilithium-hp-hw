$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l sim/dilithium/stage7c4_main_full.log -do sim/dilithium/reference_build/stage7c4_main_full.do *> sim/dilithium/stage7c4_main_full_console.log
if ($LASTEXITCODE -ne 0) {throw 'Native full-main run failed'}
& 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py lighthd_main_compare *> sim/dilithium/stage7c4_main_full_compare.log
if ($LASTEXITCODE -ne 0) {throw 'Full-main independent comparison failed'}
& 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py lighthd_main_selftest *> sim/dilithium/stage7c4_main_selftest.log
if ($LASTEXITCODE -ne 0) {throw 'Main checker selftest failed'}
'STAGE7C4_MAIN_RUNNER_PASS'
