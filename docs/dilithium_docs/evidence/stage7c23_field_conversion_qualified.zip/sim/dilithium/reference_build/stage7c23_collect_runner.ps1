param([int]$NativeId)
$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
Wait-Process -Id $NativeId -ErrorAction SilentlyContinue
$jobIds=Get-Content -LiteralPath sim/dilithium/reference_build/stage7c23_job_ids.json -Raw | ConvertFrom-Json
foreach ($jobId in @($jobIds.uvm,$jobIds.quartus)) {Wait-Process -Id $jobId -ErrorAction SilentlyContinue}
foreach ($kind in @('native','uvm','quartus')) {
  $marker='STAGE7C23_'+$kind.ToUpper()+'_RUNNER_PASS'
  if (-not (Select-String -LiteralPath "sim/dilithium/stage7c23_${kind}_runner.log" -Pattern $marker -Quiet)) {throw "C18 qualification incomplete: $kind"}
}
foreach ($reader in @('source_audit','proof_reuse','metrics','admission_registers','native_structure','shared_hint_registers','operand_registers','stream_registers','lifetime_registers','writer_registers','area_delta','throughput','cycle_audit')) {
  & 'C:/Python314/python.exe' "sim/dilithium/reference_build/stage7c23_${reader}.py" *> "sim/dilithium/stage7c23_${reader}_console.log"
  if ($LASTEXITCODE -ne 0) {throw "C18 result reader failed: $reader"}
}
& 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py uvm_check *> sim/dilithium/stage7c23_final_uvm_check.log
if ($LASTEXITCODE -ne 0) {throw 'C18 final UVM freshness failed'}
'STAGE7C23_RESULT_COLLECTION_PASS'
