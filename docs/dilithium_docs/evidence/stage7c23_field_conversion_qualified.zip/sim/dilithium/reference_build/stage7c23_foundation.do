onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vlib sim/dilithium/work_lighthd_foundation
vmap lighthd_foundation_work sim/dilithium/work_lighthd_foundation
set fd [open quartus/dilithium/dilithium_full.qsf r]
set settings [read $fd];close $fd
foreach line [split $settings "\n"] {
  if {[regexp {SYSTEMVERILOG_FILE\s+(.+)$} [string trim $line] -> source]} {
    vlog -sv -work lighthd_foundation_work [file normalize [file join quartus/dilithium $source]]
  }
}
vlog -sv -work lighthd_foundation_work tb/tb_dilithium/lighthd_bitunpkg_c22_reference.sv tb/tb_dilithium/tb_lighthd_decode_fields.sv tb/tb_dilithium/lighthd_bitunpkg_c21_reference.sv tb/tb_dilithium/tb_lighthd_unpack_counter.sv tb/tb_dilithium/tb_lighthd_operand_queue.sv tb/tb_dilithium/lighthd_sign_input_c20_reference.sv tb/tb_dilithium/lighthd_sign_c20_reference.sv tb/tb_dilithium/lighthd_verify_input_c20_reference.sv tb/tb_dilithium/lighthd_verify_c20_reference.sv tb/tb_dilithium/tb_lighthd_controller_lifetimes.sv tb/tb_dilithium/tb_lighthd_sign_input.sv tb/tb_dilithium/lighthd_service_fixture.sv tb/tb_dilithium/tb_lighthd_verify_input.sv tb/tb_dilithium/tb_lighthd_sampler_writer.sv tb/tb_dilithium/tb_lighthd_sampler_writer_mixed.sv tb/tb_dilithium/tb_lighthd_sampler_writer_queue.sv tb/tb_dilithium/tb_lighthd_hash_sampler.sv tb/tb_dilithium/lighthd_process_c17_reference.sv tb/tb_dilithium/lighthd_verify_c17_reference.sv tb/tb_dilithium/tb_lighthd_process_payload.sv tb/tb_dilithium/tb_lighthd_verify_lifetime.sv tb/tb_dilithium/lighthd_process_c16_reference.sv tb/tb_dilithium/lighthd_bitunpkg_c16_reference.sv tb/tb_dilithium/lighthd_hint_decode_stage_reference.sv tb/tb_dilithium/tb_lighthd_process_alu.sv tb/tb_dilithium/tb_lighthd_bitunpkg_ring.sv tb/tb_dilithium/lighthd_cnb_c15_reference.sv tb/tb_dilithium/lighthd_mhint_c15_reference.sv tb/tb_dilithium/tb_lighthd_process_ranges.sv tb/tb_dilithium/tb_lighthd_process.sv tb/tb_dilithium/lighthd_memory_router_c12_reference.sv tb/tb_dilithium/tb_lighthd_memory_switch.sv tb/tb_dilithium/lighthd_hint_compat.sv tb/tb_dilithium/lighthd_hintpkg_c13_reference.sv tb/tb_dilithium/lighthd_hintunpkg_c13_reference.sv tb/tb_dilithium/lighthd_process_dma_c12_reference.sv tb/tb_dilithium/tb_lighthd_process_ports.sv tb/tb_dilithium/tb_lighthd_hint_shared.sv tb/tb_dilithium/tb_lighthd_hintpkg.sv tb/tb_dilithium/lighthd_bank_fixture.sv tb/tb_dilithium/tb_lighthd_process_dma.sv tb/tb_dilithium/tb_lighthd_main.sv tb/tb_dilithium/tb_lighthd_bram.sv tb/tb_dilithium/tb_lighthd_memory.sv tb/tb_dilithium/tb_lighthd_ntt_dma.sv tb/tb_dilithium/tb_lighthd_hintunpkg.sv
foreach top {tb_lighthd_decode_fields tb_lighthd_unpack_counter tb_lighthd_operand_queue tb_lighthd_sign_input tb_lighthd_verify_input tb_lighthd_controller_lifetimes tb_lighthd_sampler_writer_queue tb_lighthd_sampler_writer tb_lighthd_hash_sampler tb_lighthd_verify_lifetime tb_lighthd_bitunpkg_ring tb_lighthd_process_ranges tb_lighthd_process tb_lighthd_memory_switch tb_lighthd_process_ports tb_lighthd_hint_shared tb_lighthd_hintpkg tb_lighthd_process_dma tb_lighthd_bram tb_lighthd_memory tb_lighthd_ntt_dma tb_lighthd_hintunpkg tb_lighthd_main} {
  if {$top eq "tb_lighthd_process_payload"} {vsim -L cyclonev_ver -gEXHAUSTIVE=1 lighthd_foundation_work.$top} elseif {$top eq "tb_lighthd_process" || $top eq "tb_lighthd_process_alu"} {vsim -L cyclonev_ver -gEXHAUSTIVE=0 lighthd_foundation_work.$top} else {vsim -L cyclonev_ver lighthd_foundation_work.$top}
  onfinish stop
  run -all
  quit -sim
}
foreach different {0 1} {
  vsim -L cyclonev_ver -gDIFFERENT_BANKS=$different lighthd_foundation_work.tb_lighthd_sampler_writer_mixed
  onfinish stop
  run -all
  quit -sim
}
vsim -L cyclonev_ver -gDIAGNOSTIC=0 -gPROTOCOL=1 lighthd_foundation_work.tb_lighthd_controller_lifetimes
onfinish stop
run -all
quit -f
