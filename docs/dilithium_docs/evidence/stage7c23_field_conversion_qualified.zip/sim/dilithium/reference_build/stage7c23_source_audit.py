from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c22_source_hashes.json').read_text());new=json.loads((rb/'stage7c23_source_hashes.json').read_text())
for n,d in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
assert len(new)==261 and len(set(new)-set(old))==2
assert {n for n in old if old[n]!=new[n]}=={'src/controller/process/lighthd_bitunpkg.sv','sim/dilithium/dilithium_vectors.py'}
print('C23_SOURCE_AUDIT_PASS:261 frozen/one field-arithmetic RTL change/2new reference-test files;all other RTL,Process/engine arithmetic,RAM rules,QSF,SDC/report exact C22')
