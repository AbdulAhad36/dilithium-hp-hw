from pathlib import Path
import json,re

r=Path.cwd();q=r/'quartus/dilithium';h=r/'sim/dilithium/reference_build'
settings=(q/'dilithium_full.qsf').read_text()
assert len(re.findall(r'^set_global_assignment -name SYSTEMVERILOG_FILE .*lighthd_hint_codec\.sv$',settings,re.M))==1
assert not re.search(r'^set_global_assignment -name SYSTEMVERILOG_FILE .*lighthd_hint(?:pkg|unpkg)\.sv$',settings,re.M)
names=(q/'critical_full/mapped_register_names.rpt').read_text().splitlines()
counts={}
for label,expr,wanted in [('indices',r'\|lighthd_hint_codec:.*\|indices_r',640),('counts',r'\|lighthd_hint_codec:.*\|counts_r',64)]:
    hits=[n for n in names if re.search(expr,n)]
    assert len(hits)==wanted,(label,len(hits),wanted)
    counts[label]={'bits':len(hits),'names':hits}
codec_paths={re.search(r'^(.*\|lighthd_hint_codec:[^|]+)\|',n)[1] for n in names if '|lighthd_hint_codec:' in n}
assert len(codec_paths)==1,codec_paths
assert not any('|lighthd_hintpkg:' in n or '|lighthd_hintunpkg:' in n for n in names)
assert 'shared_hint_indices:640' in (q/'critical_full/retained_registers.rpt').read_text()
result={'instance_paths':sorted(codec_paths),'suffix_storage':counts,'private_hint_instances':0}
(h/'stage7c23_shared_hint_registers.json').write_text(json.dumps(result,indent=2)+'\n')
print('C23_SHARED_HINT_HARDWARE_GUARD_PASS:one codec/640 index bits/64 count bits/no private Sign-Verify hint instances')
