from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
manifest=json.loads((rb/'stage7c23_validity_sources.json').read_text())
main=json.loads((rb/'stage7c23_source_hashes.json').read_text())
for n,d in manifest.items():
 assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
 if n in main:assert main[n]==d,n
text=(r/'sim/dilithium/stage7c23_validity_isolation.log').read_text()
assert 'C23_VALIDITY_ISOLATION_PASS:896 vectors/9728 lane results/608 valid/288 invalid' in text
assert '# ** Fatal:' not in text and '# ** Error:' not in text
print('C23_SUPPLEMENTAL_VALIDITY_PROOF_PASS:896isolated vectors/9728lanes/608valid/288invalid;independent4-file fingerprint matches frozen C23 RTL/ref;field-only,not main-UVM coverage')
