from pathlib import Path
import json,sys
r=Path.cwd();u={}
s=(r/'tmp/c23_lighthd_bitunpkg.sv').read_text()
s=s.replace("      1:decoded[lane]=decode_centered(field[lane],5'd13);\n",'')
s=s.replace('      4:decoded[lane]=decode_centered(field[lane],width_r);','      1,4:decoded[lane]=decode_centered(field[lane],width_r);')
u['tmp/c23_lighthd_bitunpkg_shared.sv']=s
s=(r/'tmp/c23_probe.do').read_text().replace('work_c23_probe','work_c23_shared_probe').replace('c23_probe','c23_shared_probe').replace('tmp/c23_lighthd_bitunpkg.sv','tmp/c23_lighthd_bitunpkg_shared.sv')
u['tmp/c23_shared_probe.do']=s
s=(r/'tmp/c23_decode_exhaustive.do').read_text().replace('c23_decode','c23_decode_shared').replace('tmp/c23_lighthd_bitunpkg.sv','tmp/c23_lighthd_bitunpkg_shared.sv')
# Module name is the actual existing field bench,not a duplicate test body.
s=s.replace('tb_c23_decode_shared_exhaustive','tb_c23_decode_exhaustive')
u['tmp/c23_decode_shared.do']=s
s=(r/'tmp/stage7c23_bitunpkg_map_candidate/probe.qsf').read_text().replace('tmp/c23_lighthd_bitunpkg.sv','tmp/c23_lighthd_bitunpkg_shared.sv')
u['tmp/stage7c23_bitunpkg_map_shared/probe.qsf']=s
u['tmp/stage7c23_bitunpkg_map_shared/probe.qpf']='PROJECT_REVISION = "probe"\n'
patch='*** Begin Patch\n'
for n,v in u.items():
 if len(sys.argv)>1 and Path(n).name not in sys.argv[1:]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in v.splitlines())
print(json.dumps(patch+'*** End Patch'))
