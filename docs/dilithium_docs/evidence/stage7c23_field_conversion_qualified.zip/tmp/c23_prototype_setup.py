from pathlib import Path
import json,sys
r=Path.cwd();u={}
s=(r/'src/controller/process/lighthd_bitunpkg.sv').read_text()
s=s.replace('  logic [19:0] gamma_r;\n','')
anchor='  always_comb begin\n    case(read_slot_r)'
fn='''  // All signed packed fields have bound2^p. The encoded high bit chooses
  // positive bound-x versus canonical q-x. A zero negative magnitude is0,
  // not q. Use one selected-bias subtraction;no variable gamma comparator.
  function automatic logic [22:0] decode_centered(input logic [19:0] encoded,input logic [4:0] width);
    logic negative;logic [18:0] magnitude;logic [22:0] power,bias;
    case(width)
      13:begin negative=encoded[12];magnitude={7'd0,encoded[11:0]};power=23'd4096;end
      18:begin negative=encoded[17];magnitude={2'd0,encoded[16:0]};power=23'd131072;end
      default:begin negative=encoded[19];magnitude=encoded[18:0];power=23'd524288;end
    endcase
    bias=negative?23'd8380417:power;
    return (negative && magnitude==0)?23'd0:bias-{4'd0,magnitude};
  endfunction
'''
assert anchor in s;s=s.replace(anchor,fn+anchor)
s=s.replace("bad_value|=field[lane]>20'(eta_r<<1);", "bad_value|=width_r==3?(field[lane][2] && (|field[lane][1:0])):\n          (field[lane][3] && (|field[lane][2:0]));")
s=s.replace("      1:decoded[lane]=field[lane]<=4096?23'd4096-23'(field[lane]):23'd8384513-23'(field[lane]);", "      1:decoded[lane]=decode_centered(field[lane],5'd13);")
s=s.replace("      3:begin decoded[lane]=23'(field[lane]);bad_value|=field[lane]>(width_r==6?43:15);end", "      3:begin\n        decoded[lane]=23'(field[lane]);\n        bad_value|=width_r==6 && field[lane][5] && (field[lane][4] || (field[lane][3] && field[lane][2]));\n      end")
s=s.replace("      4:decoded[lane]=field[lane]<=gamma_r?23'(gamma_r)-23'(field[lane]):\n        23'd8380417+23'(gamma_r)-23'(field[lane]);", "      4:decoded[lane]=decode_centered(field[lane],width_r);")
s=s.replace('eta_r<=0;gamma_r<=0;','eta_r<=0;').replace("eta_r<=command_param_i==1?4:2;gamma_r<=command_param_i==0?20'd131072:20'd524288;",'eta_r<=command_param_i==1?4:2;')
assert 'gamma_r' not in s
u['tmp/c23_lighthd_bitunpkg.sv']=s
u['tmp/lighthd_bitunpkg_c22_reference.sv']=(r/'src/controller/process/lighthd_bitunpkg.sv').read_text().replace('module lighthd_bitunpkg (','module lighthd_bitunpkg_c22_reference (')
patch='*** Begin Patch\n'
for n,v in u.items():
 if len(sys.argv)>1 and Path(n).stem not in sys.argv[1:]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in v.splitlines())
print(json.dumps(patch+'*** End Patch'))
