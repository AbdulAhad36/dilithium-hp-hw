from pathlib import Path
import json,difflib,sys
r=Path.cwd();u={}
u['src/controller/process/lighthd_bitunpkg.sv']=(r/'tmp/c23_lighthd_bitunpkg_shared.sv').read_text(encoding='utf-8')
u['tb/tb_dilithium/lighthd_bitunpkg_c22_reference.sv']=(r/'tmp/lighthd_bitunpkg_c22_reference.sv').read_text(encoding='utf-8')
u['tb/tb_dilithium/tb_lighthd_decode_fields.sv']=(r/'tmp/tb_c23_decode_exhaustive.sv').read_text().replace('module tb_c23_decode_exhaustive;','module tb_lighthd_decode_fields;').replace('C23_DECODE_DOMAIN_PASS','LIGHTHD_DECODE_DOMAIN_PASS').replace('C23_DECODE_FIELD_EXHAUSTIVE_PASS','LIGHTHD_DECODE_FIELD_EXHAUSTIVE_PASS')
patch='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and Path(n).stem not in sys.argv[1:]:continue
 p=r/n
 if not p.exists():patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
 else:
  d=list(difflib.unified_diff(p.read_text(encoding='utf-8').splitlines(True),s.splitlines(True)))
  patch+='*** Update File: '+n+'\n'+''.join('@@\n' if x.startswith('@@') else x for x in d[2:])
print(json.dumps(patch+'*** End Patch'))
