onerror {quit -code 1 -f}
vlib sim/dilithium/work_c23_decode_shared
vmap c23_decode_shared sim/dilithium/work_c23_decode_shared
vlog -sv -work c23_decode_shared tmp/c23_lighthd_bitunpkg_shared.sv tmp/lighthd_bitunpkg_c22_reference.sv tmp/tb_c23_decode_exhaustive.sv
vsim c23_decode_shared.tb_c23_decode_exhaustive
onfinish stop
run -all
quit -f
