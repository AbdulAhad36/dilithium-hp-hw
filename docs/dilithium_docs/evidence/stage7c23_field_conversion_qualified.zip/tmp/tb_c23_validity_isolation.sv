`timescale 1ns/1ps
// Supplemental field-only proof,with its own source fingerprint. One lane
// varies while all other lanes remain valid,so OR-reduced errors cannot hide
// a missing lane check. No transport/main-UVM coverage is credited here.
module tb_c23_validity_isolation;
  logic clk=0,rst=1,command_valid_i=0;logic [2:0] command_op_i=0;
  logic [1:0] command_param_i=0;logic [15:0] command_id_i=0;
  logic input_valid_i=0,input_last_i=0,output_ready_i=0,done_ready_i=0;
  logic [63:0] input_data_i=0;logic [6:0] input_index_i=0;logic [3:0] input_bytes_i=8;
  logic [79:0] window=0;logic [91:0] actual,reference_data,gold;
  int vectors=0,lanes=0,valid_cases=0,invalid_cases=0;
  lighthd_bitunpkg dut(.command_ready_o(),.input_ready_o(),.output_valid_o(),.output_data_o(actual),
    .output_count_o(),.output_index_o(),.output_last_o(),.output_id_o(),.done_valid_o(),.done_code_o(),.done_id_o(),.*);
  lighthd_bitunpkg_c22_reference baseline(.command_ready_o(),.input_ready_o(),.output_valid_o(),.output_data_o(reference_data),
    .output_count_o(),.output_index_o(),.output_last_o(),.output_id_o(),.done_valid_o(),.done_code_o(),.done_id_o(),.*);
  task automatic tick;#2;clk=1;#2;clk=0;endtask
  initial begin
    force dut.bits_r=window;force baseline.bits_r=window;
    for(int op=2;op<=3;op++)for(int level=0;level<3;level++)begin
      int width,limit,amount,eta,bound;
      rst=1;tick();rst=0;command_op_i=3'(op);command_param_i=2'(level);command_id_i++;
      command_valid_i=1;tick();command_valid_i=0;
      width=op==2?(level==1?4:3):(level==0?6:4);limit=1<<width;
      amount=op==2?16:4;eta=level==1?4:2;bound=op==2?2*eta:(level==0?43:15);
      for(int isolated=0;isolated<amount;isolated++)for(int raw=0;raw<limit;raw++)begin
        bit invalid;invalid=raw>bound;window=0;gold=0;
        for(int b=0;b<width;b++)window[isolated*width+b]=(raw>>b)&1;
        for(int lane=0;lane<amount;lane++)begin
          int value;value=lane==isolated?raw:0;
          if(op==2)gold[4*lane+:4]=4'(eta-value);else gold[23*lane+:23]=23'(value);
          lanes++;
        end
        #1;
        if(actual!==gold || reference_data!==gold || dut.bad_value!==invalid || baseline.bad_value!==invalid)
          $fatal(1,"Validity isolation op%0d level%0d lane%0d raw%0d error%b/%b want%b",op,level,isolated,raw,dut.bad_value,baseline.bad_value,invalid);
        vectors++;if(invalid)invalid_cases++;else valid_cases++;
      end
    end
    if(vectors!=896 || lanes!=9728 || valid_cases==0 || invalid_cases==0)$fatal(1,"Incomplete validity isolation");
    $display("C23_VALIDITY_ISOLATION_PASS:%0d vectors/%0d lane results/%0d valid/%0d invalid;each lane/all field values,others valid",vectors,lanes,valid_cases,invalid_cases);
    $finish;
  end
endmodule
