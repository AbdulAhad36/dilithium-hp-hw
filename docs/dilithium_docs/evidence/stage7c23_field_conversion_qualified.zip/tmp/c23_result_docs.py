from pathlib import Path
import json,re,sys,difflib
r=Path.cwd();h=r/'sim/dilithium';rb=h/'reference_build'
def readlog(path):
 b=path.read_bytes();return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8',errors='replace')
assert 'STAGE7C23_RESULT_COLLECTION_PASS' in (h/'stage7c23_collect_runner.log').read_text()
assert 'C23_SUPPLEMENTAL_VALIDITY_PROOF_PASS' in readlog(h/'stage7c23_validity_check_console.log')
m=json.loads((rb/'stage7c23_metrics.json').read_text());old=json.loads((rb/'stage7c22_metrics.json').read_text());a=m['area']
f=min(c['fmax_mhz'] for c in m['corners']);setup=min(c['setup_ns'] for c in m['corners']);hold=min(c['hold_ns'] for c in m['corners'])
delta=a['placed_ALMs']-old['area']['placed_ALMs'];gain=100*(f/68.23-1)
cycles=json.loads((rb/'stage7c23_cycle_deltas.json').read_text());assert len(cycles['native'])==286 and len(cycles['UVM'])==30
native=[x['delta'] for x in cycles['native']];uvm=[n for x in cycles['UVM'] for n in x['delta'].values()]
cycle_note='All286 completed official/protocol latencies and30 main-UVM latency rows exactly match C22;the12 reset-prefix records also match. No operation cycles were added.' if all(n==0 for n in native+uvm) else f'Completed native latency deltas range{min(native):+}..{max(native):+} clocks;main-UVM field deltas range{min(uvm):+}..{max(uvm):+}. Detailed operation means and differences are recorded in the cycle audit.'
u=(h/'stage7c23_uvm.log').read_text(encoding='utf-8',errors='replace');bins={}
for key,label in [('functional','OVERALL FUNCTIONAL COVERAGE'),('module','DUT MODULE CODE COVERAGE'),('package','SHARED DUT PACKAGE CODE COVERAGE'),('overall','OVERALL DUT CODE COVERAGE')]:
 z=re.search(re.escape(label)+r'.*?:\s*(\d+) / (\d+)',u);assert z,label;bins[key]=tuple(map(int,z.groups()))
token=(h/'stage7c4_main_inputs.txt').read_text().split()[0];uvmtoken=re.search(r'[0-9a-f]{64}',(h/'stage7_uvm_inputs.txt').read_text())[0]
status=f'''## C23 correct but rejected performance trial

**C23 is rejected as the working performance baseline.** It saves462 placed
ALMs versus C22 but loses8.52% Fmax and estimated operation rates. The saved
C21 checkpoint is both smaller and faster than C23. Preserve this verified
trial;after its immutable archive and extraction replay,restore C22's exact
source and matching saved fixtures. This is not user performance acceptance.

All261 source hashes,fresh foundation/field/stream tests,210 official commands,
88 protocol commands,90 checker corruptions and main33UVM/negative pass.
Actual final placement: **{a['placed_ALMs']:,} ALMs**,{a['registers']:,} registers,
{a['M10Ks']} M10Ks and{a['DSPs']} DSPs. Worst Fmax **{f:.2f}MHz**,setup **{setup:+.3f}ns**,
hold **{hold:+.3f}ns**. Versus C22:{delta:+,} placed ALMs,{gain:+.2f}% Fmax.
The same Cyclone V,6.757ns and hold constraints remain. Under20K/148MHz and
user performance acceptance remain open;C20/C21/C22 are preserved. Whole-fit
counts are actual final placed ALMs. Full corner/rate tables are in THROUGHPUT.md.

{cycle_note}

Physical completion: {m['physical_flow']}.

'''
common='''Only BitUnpkg's field conversion changes in production RTL. t0/z share one
power-of-two sign/magnitude conversion and selected-bias subtraction per lane.
Zero negative magnitude maps to0,not q. Fixed-width eta/w1 rejection predicates
remain exact. No new pipeline or RAM is added;the old gamma register is absent
from routed hardware. All other RTL,QSF/SDC/report and engine/Process math are
byte-identical to C22. The384-bit operand queue/writer214/native DSP8 and prior
retention guards remain satisfied.

The fresh actualRTL field proof checks2390144mixed vectors/9560960lane results,
all encodings/all6formats/all3levels,against C22 actual logic and an integer
oracle. It forces the selected80-bit window:field-only,not transport coverage.
Unforced1241packet/174350-clock tests separately check streaming,state/count/
ring positions,framing,reset,stall,valid payload and completion behavior.

The supplementary validity gate checks896 one-lane vectors/9728lane results,
608valid/288invalid. Each secret/w1 lane sees every field value with all other
lanes valid. Its own4-file fingerprint matches the main261 RTL/reference
hashes;it is outside the main compile boundary and earns no main UVM credit.
The separate-call prototype maps1241ALUT/261regs;the selected shared version
maps1078/261 versus1577/263 baseline. Those isolated counts are not placed ALMs.

'''
corner_table='|Corner|Fmax MHz|Setup ns|Setup TNS ns|Hold ns|Hold TNS ns|\n|---|---:|---:|---:|---:|---:|\n'
for c in m['corners']:corner_table+=f"|{c['corner']}|{c['fmax_mhz']:.2f}|{c['setup_ns']:+.3f}|{c['setup_tns_ns']:.3f}|{c['hold_ns']:+.3f}|{c['hold_tns_ns']:.3f}|\n"
t=json.loads((rb/'stage7c23_throughput.json').read_text());rates='|Operation|Level|Mean cycles|Cycle delta vs C22|Estimated latency us|Estimated operations/s|Rate delta vs C22|\n|---|---:|---:|---:|---:|---:|---:|\n'
for row in t['rows']:rates+=f"|{row['operation']}|{row['level']}|{row['cycles']:.2f}|{row['cycle_delta_vs_C22']:+.2f}|{row['latency_us']:.1f}|{row['operations_per_second']:.1f}|{row['rate_gain_vs_C22_pct']:+.2f}%|\n"
cov='|Main coverage|Hit / defined|Percent|\n|---|---:|---:|\n'
for key,label in [('functional','Functional'),('module','RTL module raw code'),('package','Executable shared package raw code'),('overall','Overall DUT raw code')]:
 hit,total=bins[key];cov+=f'|{label}|{hit} / {total}|{100*hit/total:.2f}%|\n'
proof='''Focused field/validity hits are not merged into main coverage. Current-token
corrupted first key byte rejects with no credited outcomes. The unchanged
full Process-domain proof is reused from C18R1 via10 byte-identical files;
it is not rerun or retagged as fresh. C23 field proofs are fresh executions.

'''
worst=min(m['corners'],key=lambda c:c['setup_ns']);text=(r/f"quartus/dilithium/critical_full/{worst['corner']}_setup.rpt").read_text(errors='replace')
path=None
for line in text.splitlines():
 c=[x.strip() for x in line.split(';')[1:-1]]
 if len(c)==8 and re.fullmatch(r'-?\d+\.\d+',c[0]):path=c;break
assert path
levels=re.search(r'; Number of Logic Levels\s*;\s*;\s*(\d+)',text);assert levels
short=lambda node:'|'.join(node.split('|')[-2:])
nextnote=f'''Fresh worst setup path ({worst['corner']}):`{short(path[1])}` to
`{short(path[2])}`,{levels[1]} logic levels/{path[-1]}ns data delay. Use this
path and disjoint placed-area scopes to choose the next Stage7C trial.
The next timing target is the Process-to-BitPkg packing path;C23 unpacker
arithmetic narrowing did not resolve that path. Restore the faster C22
baseline before another production trial.
Another{max(0,a['placed_ALMs']-19999)} actual placed ALMs must be removed to reach19999.
No target acceptance,Stage8,commit,branch change or complete unpublished-RTL
replica claim follows from these gates.

Create-only evidence:`evidence/stage7c23_field_conversion_qualified.zip` and
its SHA256 sidecar. Fresh extraction replay is required before handoff;it
checks saved evidence without fixture regeneration or native reruns.

'''
extras={'DILITHIUM_PLAN.md':common+nextnote,'THROUGHPUT.md':common+corner_table+'\n'+rates+'\nRates use measured cycles and actual worst Fmax;sequential estimates,not board measurements or command initiation interval.\n\n','MEMORY_MAP.md':common,'PROCESS_BLOCKS.md':common,'COVERAGE.md':cov+'\n'+proof,'REFERENCE_VERIFICATION.md':common+f'Main token `{token}`.\n\nUVM token `{uvmtoken}`.\n\n'+proof,'SPECIFICATION.md':common}
patch='*** Begin Patch\n'
for leaf,extra in extras.items():
 if len(sys.argv)>1 and leaf not in sys.argv[1:]:continue
 p=r/'docs/dilithium_docs'/leaf;s=p.read_text(encoding='utf-8');title,tail=s.split('\n\n',1)
 if tail.startswith('## C23'):
  z=re.search(r'\n## C22 ',tail);assert z,leaf;tail=tail[z.start()+1:]
 new=title+'\n\n'+status+extra+tail
 d=list(difflib.unified_diff(s.splitlines(True),new.splitlines(True)))
 patch+='*** Update File: '+p.relative_to(r).as_posix()+'\n'+''.join('@@\n' if x.startswith('@@') else x for x in d[2:])
print(json.dumps(patch+'*** End Patch'))
