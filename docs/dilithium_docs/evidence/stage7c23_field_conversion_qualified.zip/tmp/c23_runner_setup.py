from pathlib import Path
import json,hashlib,sys
r=Path.cwd();rb=r/'sim/dilithium/reference_build';u={}
names=('native_runner.ps1','quartus_runner.ps1','foundation_runner.ps1','production_runner.ps1','uvm_runner.ps1','collect_runner.ps1','foundation.do','production.do','metrics.py','admission_registers.py','native_structure.py','shared_hint_registers.py','operand_registers.py','stream_registers.py','lifetime_registers.py','writer_registers.py','area_delta.py','throughput.py','cycle_audit.py','proof_reuse.py')
for name in names:
 s=(rb/('stage7c22_'+name)).read_text(encoding='utf-8').replace('stage7c22','stage7c23').replace('STAGE7C22','STAGE7C23').replace('C22_','C23_')
 if name=='foundation.do':
  s=s.replace('vlog -sv -work lighthd_foundation_work tb/tb_dilithium/lighthd_bitunpkg_c21_reference.sv','vlog -sv -work lighthd_foundation_work tb/tb_dilithium/lighthd_bitunpkg_c22_reference.sv tb/tb_dilithium/tb_lighthd_decode_fields.sv tb/tb_dilithium/lighthd_bitunpkg_c21_reference.sv')
  s=s.replace('foreach top {tb_lighthd_unpack_counter','foreach top {tb_lighthd_decode_fields tb_lighthd_unpack_counter')
 if name=='foundation_runner.ps1':
  s=s.replace("@('LIGHTHD_UNPACK_COUNTER_CYCLE_PASS", "@('LIGHTHD_DECODE_FIELD_EXHAUSTIVE_PASS:2390144 vectors/9560960 lane results','LIGHTHD_UNPACK_COUNTER_CYCLE_PASS",1)
 if name in ('area_delta.py','throughput.py'):
  s=s.replace('stage7c21_area_inventory.json','stage7c22_area_inventory.json').replace('stage7c21_throughput.json','stage7c22_throughput.json').replace('C21','C22').replace('63.37','68.23')
 if name=='cycle_audit.py':s=s.replace('stage7c23_baseline_c21','stage7c23_baseline_c22').replace('C21','C22')
 if name=='proof_reuse.py':s=s.replace('fresh C22 execution','fresh C23 execution')
 u['sim/dilithium/reference_build/stage7c23_'+name]=s
u['sim/dilithium/reference_build/stage7c23_source_audit.py']='''from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c22_source_hashes.json').read_text());new=json.loads((rb/'stage7c23_source_hashes.json').read_text())
for n,d in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
assert len(new)==261 and len(set(new)-set(old))==2
assert {n for n in old if old[n]!=new[n]}=={'src/controller/process/lighthd_bitunpkg.sv','sim/dilithium/dilithium_vectors.py'}
print('C23_SOURCE_AUDIT_PASS:261 frozen/one field-arithmetic RTL change/2new reference-test files;all other RTL,Process/engine arithmetic,RAM rules,QSF,SDC/report exact C22')
'''
old=json.loads((rb/'stage7c22_source_hashes.json').read_text());paths=set(old)
paths|={'tb/tb_dilithium/'+n+'.sv' for n in ('lighthd_bitunpkg_c22_reference','tb_lighthd_decode_fields')}
assert len(paths)==261
u['sim/dilithium/reference_build/stage7c23_source_hashes.json']=json.dumps({n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in sorted(paths)},indent=2)+'\n'
patch='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and Path(n).name not in sys.argv[1:]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
