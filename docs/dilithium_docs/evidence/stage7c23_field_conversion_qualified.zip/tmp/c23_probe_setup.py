from pathlib import Path
import json,sys
r=Path.cwd();u={}
s=(r/'sim/dilithium/reference_build/stage7c22_foundation.do').read_text()
s=s.replace('work_lighthd_foundation','work_c23_probe').replace('lighthd_foundation_work','c23_probe')
s=s.replace('    vlog -sv -work c23_probe [file normalize [file join quartus/dilithium $source]]','''    set stem [file rootname [file tail $source]]
    if {$stem eq "lighthd_bitunpkg"} {vlog -sv -work c23_probe tmp/c23_lighthd_bitunpkg.sv} else {
      vlog -sv -work c23_probe [file normalize [file join quartus/dilithium $source]]
    }''')
a=s.index('foreach top {');b=s.index(' {\n',a)
s=s[:a]+'foreach top {tb_lighthd_unpack_counter tb_lighthd_bitunpkg_ring tb_lighthd_controller_lifetimes}'+s[b:]
a=s.index('foreach different {');b=s.index('vsim -L cyclonev_ver -gDIAGNOSTIC=0',a);s=s[:a]+s[b:]
main=(r/'tb/tb_dilithium/tb_lighthd_main.sv').read_text()
for leaf in ('outputs.txt','diagnostic_outputs.txt','protocol_outputs.txt'):main=main.replace('stage7c4_main_'+leaf,'stage7c23_probe_main_'+leaf)
u['tmp/tb_c23_main_probe.sv']=main
s=s.replace('tb/tb_dilithium/tb_lighthd_main.sv','tmp/tb_c23_main_probe.sv');u['tmp/c23_probe.do']=s
maps=(r/'tmp/c22_map_setup.py').read_text().replace('stage7c22','stage7c23').replace('tmp/c22_','tmp/c23_').replace("('bitunpkg','process_dma')","('bitunpkg',)")
u['tmp/c23_map_setup.py']=maps
patch='*** Begin Patch\n'
for n,v in u.items():
 if len(sys.argv)>1 and Path(n).stem not in sys.argv[1:]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in v.splitlines())
print(json.dumps(patch+'*** End Patch'))
