onerror {quit -code 1 -f}
vlib sim/dilithium/work_c23_validity
vmap c23_validity sim/dilithium/work_c23_validity
vlog -sv -work c23_validity src/controller/process/lighthd_bitunpkg.sv tb/tb_dilithium/lighthd_bitunpkg_c22_reference.sv tmp/tb_c23_validity_isolation.sv
vsim c23_validity.tb_c23_validity_isolation
onfinish stop
run -all
quit -f
