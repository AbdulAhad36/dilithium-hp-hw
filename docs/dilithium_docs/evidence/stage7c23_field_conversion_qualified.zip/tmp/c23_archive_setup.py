from pathlib import Path
import json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
s=(rb/'stage7c22_archive.py').read_text(encoding='utf-8').replace('stage7c22','stage7c23').replace('STAGE7C22','STAGE7C23').replace('C22_','C23_')
s=s.replace('ready_isolation_qualified','field_conversion_qualified')
s=s.replace("('quartus_recovery_r1.log','STAGE7C23_MANUAL_POSTFIT_RECOVERY_PASS')","('quartus_runner.log','STAGE7C23_QUARTUS_RUNNER_PASS')")
s=s.replace("assert 'C23_MANUAL_ASSEMBLER_RECOVERY_PASS' in read(h/'stage7c23_quartus_recovery.log')\n",'').replace("assert 'C23_MANUAL_STA_RECOVERY_PASS' in read(h/'stage7c23_quartus_recovery_r1.log')\n",'')
s=s.replace("stage='7C.22 unpacker bookkeeping and two-entry Process ready isolation'","stage='7C.23 shared power-of-two packed-field conversion'")
s=s.replace("physical_completion='Original full flow routed successfully then ASM crashed293007;manual ASM succeeds;STA CLI option corrected and R1 STA/retained/four-corner report succeeds. Not a new full-flow compile.'", "physical_completion=metrics['physical_flow']")
for leaf in ('metrics','area_inventory','source_hashes','throughput'):
 s=s.replace('stage7c21_'+leaf+'.json','stage7c22_'+leaf+'.json')
# Keep old proof provenance;only current-stage scratch paths are changed.
s=s.replace("(r/'tmp').glob('c22*.py')","(r/'tmp').glob('c23*.py')").replace("('c22_probe.do','c22_queue.do')","('c23_probe.do','c23_shared_probe.do','c23_decode_exhaustive.do','c23_decode_shared.do','c23_validity_isolation.do')")
s=s.replace("(r/'tmp').glob('*c22*.sv')","(r/'tmp').glob('*c23*.sv')").replace("r/'tmp/c22_map_baseline'","r/'tmp/stage7c23_map_baseline'")
s=s.replace("(r/'tmp').glob('lighthd_bitunpkg_c21_reference.sv')","(r/'tmp').glob('lighthd_bitunpkg_c22_reference.sv')")
s=s.replace("for folder in ('stage7c23_bitunpkg_map_baseline','stage7c23_bitunpkg_map_candidate','stage7c23_process_dma_map_baseline','stage7c23_process_dma_map_candidate'):","for folder in ('stage7c23_bitunpkg_map_baseline','stage7c23_bitunpkg_map_candidate','stage7c23_bitunpkg_map_shared','stage7c23_separate_calls'):")
s=s.replace("for leaf in ('stage7c23_asm_recovery.log','stage7c23_sta_recovery.log','stage7c23_sta_recovery_r1.log'):\n    paths.add('quartus/dilithium/'+leaf)\n",'')
s=s.replace('fresh_C22_execution=False','fresh_C23_execution=False')
s=s.replace("private_probes='Unpacker174350 cycles/DMA64/main9/protocol88 pass;initial full-reset test lacked forced bank pressure and failed its missing-reset witness;corrected test checks both phases'","private_probes='Separate-call then shared-call versions both field/stream/controller PASS;shared selected1078ALUT/261regs vs1577/263 baseline;independent validity isolation fingerprint retained'")
s=s.replace("memory_contract='Polynomial RAM/collision rules and214bit writer unchanged;Process raw operand queue384bits/admission by registered occupancy;unpacker count keeps validation/error priority'","memory_contract='C22 RAM/collision/384bit operand queue/214bit writer/ring/framing/counter controls unchanged;field conversion only,with no extra pipeline/storage'")
anchor="assert 'LIGHTHD_PROCESS_OPERAND_STAGE_PASS:' in foundation"
s=s.replace(anchor,anchor+"\nassert 'LIGHTHD_DECODE_FIELD_EXHAUSTIVE_PASS:2390144 vectors/9560960 lane results' in foundation\nassert 'C23_SUPPLEMENTAL_VALIDITY_PROOF_PASS' in read(h/'stage7c23_validity_check_console.log')")
s=s.replace(" counter_model_combinations=32768,unpacker_exact_RTL_cycles=174350,"," counter_model_combinations=32768,unpacker_exact_RTL_cycles=174350,\n field_vectors=2390144,field_lane_results=9560960,\n supplemental_field_only_validity=dict(vectors=896,lane_results=9728,valid=608,invalid=288,main_UVM_credit=False,source_fingerprint='stage7c23_validity_sources.json'),")
replay=(rb/'stage7c22_archive_replay.py').read_text(encoding='utf-8').replace('stage7c22','stage7c23').replace('C22_','C23_').replace('ready_isolation','field_conversion')
replay=replay.replace("('source_audit','proof_reuse'","('source_audit','validity_check','proof_reuse'")
u={'sim/dilithium/reference_build/stage7c23_archive.py':s,'sim/dilithium/reference_build/stage7c23_archive_replay.py':replay}
print(json.dumps('*** Begin Patch\n'+''.join('*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in v.splitlines()) for n,v in u.items())+'*** End Patch'))
