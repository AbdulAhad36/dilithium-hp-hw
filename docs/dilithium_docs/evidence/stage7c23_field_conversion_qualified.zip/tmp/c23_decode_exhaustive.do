onerror {quit -code 1 -f}
vlib sim/dilithium/work_c23_decode
vmap c23_decode sim/dilithium/work_c23_decode
vlog -sv -work c23_decode tmp/c23_lighthd_bitunpkg.sv tmp/lighthd_bitunpkg_c22_reference.sv tmp/tb_c23_decode_exhaustive.sv
vsim c23_decode.tb_c23_decode_exhaustive
onfinish stop
run -all
quit -f
