$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l sim/dilithium/stage7c17_foundation.log -do sim/dilithium/reference_build/stage7c17_foundation.do *> sim/dilithium/stage7c17_foundation_console.log
if ($LASTEXITCODE -ne 0) {throw 'Native foundation failed'}
foreach ($marker in @('LIGHTHD_PROCESS_ALU_PIPELINE_EQUIVALENCE_PASS:','LIGHTHD_BITUNPKG_RING_CYCLE_PASS:','SHARED_HINT_REGISTERED_FINAL_STALL_PASS:','LIGHTHD_PROCESS_RANGE_EXHAUSTIVE_PASS:norm134217728','LIGHTHD_PROCESS_PASS:','LIGHTHD_PROCESS_OPERAND_STAGE_PASS:','LIGHTHD_MEMORY_DIRECT_DATA_PASS:400000','LIGHTHD_PROCESS_PHASE_PORT_PASS:2097152','SHARED_HINT_MODE_SWITCH_PASS:60','LIGHTHD_HINTPKG_PASS:packets43','LIGHTHD_PROCESS_DMA_PASS:cases64','BRAM_FIFO_PASS','LIGHTHD_DIRECT_MEMORY_PASS','LIGHTHD_NTT_DMA_CAPTURE_PASS','LIGHTHD_HINT_CAPTURE_PASS','LIGHTHD_MAIN_CAPTURE_PASS:9')) {
  if (-not (Select-String -LiteralPath sim/dilithium/stage7c17_foundation.log -Pattern $marker -Quiet)) {throw "Missing gate $marker"}
}
foreach ($gate in @('lighthd_dma_compare','lighthd_hint_compare','lighthd_hint_selftest','lighthd_main_diagnostic_compare')) {
  & 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py $gate *> "sim/dilithium/stage7c17_${gate}.log"
  if ($LASTEXITCODE -ne 0) {throw "Foundation comparison failed: $gate"}
}
'STAGE7C17_FOUNDATION_RUNNER_PASS'
