onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vlib sim/dilithium/work_lighthd_foundation
vmap lighthd_foundation_work sim/dilithium/work_lighthd_foundation
set fd [open quartus/dilithium/dilithium_full.qsf r]
set settings [read $fd];close $fd
foreach line [split $settings "\n"] {
  if {[regexp {SYSTEMVERILOG_FILE\s+(.+)$} [string trim $line] -> source]} {
    vlog -sv -work lighthd_foundation_work [file normalize [file join quartus/dilithium $source]]
  }
}
vlog -sv -work lighthd_foundation_work tb/tb_dilithium/lighthd_process_c16_reference.sv tb/tb_dilithium/lighthd_bitunpkg_c16_reference.sv tb/tb_dilithium/lighthd_hint_decode_stage_reference.sv tb/tb_dilithium/tb_lighthd_process_alu.sv tb/tb_dilithium/tb_lighthd_bitunpkg_ring.sv tb/tb_dilithium/lighthd_cnb_c15_reference.sv tb/tb_dilithium/lighthd_mhint_c15_reference.sv tb/tb_dilithium/tb_lighthd_process_ranges.sv tb/tb_dilithium/tb_lighthd_process.sv tb/tb_dilithium/lighthd_memory_router_c12_reference.sv tb/tb_dilithium/tb_lighthd_memory_switch.sv tb/tb_dilithium/lighthd_hint_compat.sv tb/tb_dilithium/lighthd_hintpkg_c13_reference.sv tb/tb_dilithium/lighthd_hintunpkg_c13_reference.sv tb/tb_dilithium/lighthd_process_dma_c12_reference.sv tb/tb_dilithium/tb_lighthd_process_ports.sv tb/tb_dilithium/tb_lighthd_hint_shared.sv tb/tb_dilithium/tb_lighthd_hintpkg.sv tb/tb_dilithium/lighthd_bank_fixture.sv tb/tb_dilithium/tb_lighthd_process_dma.sv tb/tb_dilithium/tb_lighthd_main.sv tb/tb_dilithium/tb_lighthd_bram.sv tb/tb_dilithium/tb_lighthd_memory.sv tb/tb_dilithium/tb_lighthd_ntt_dma.sv tb/tb_dilithium/tb_lighthd_hintunpkg.sv
foreach top {tb_lighthd_process_alu tb_lighthd_bitunpkg_ring tb_lighthd_process_ranges tb_lighthd_process tb_lighthd_memory_switch tb_lighthd_process_ports tb_lighthd_hint_shared tb_lighthd_hintpkg tb_lighthd_process_dma tb_lighthd_bram tb_lighthd_memory tb_lighthd_ntt_dma tb_lighthd_hintunpkg tb_lighthd_main} {
  if {$top eq "tb_lighthd_process" || $top eq "tb_lighthd_process_alu"} {vsim -L cyclonev_ver -gEXHAUSTIVE=0 lighthd_foundation_work.$top} else {vsim -L cyclonev_ver lighthd_foundation_work.$top}
  onfinish stop
  run -all
  quit -sim
}
quit -f
