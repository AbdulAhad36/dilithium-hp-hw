$ErrorActionPreference='Stop'
foreach ($variant in @('baseline','shared_alu')) {
  Set-Location -LiteralPath "D:\GitHub\dilithium-hp-hw\tmp\stage7c17_process_map_$variant"
  & F:/altera/quartus/bin64/quartus_map.exe probe -c probe --read_settings_files=on --write_settings_files=off *> map.log
  if ($LASTEXITCODE -ne 0) {throw "Process synthesis probe failed: $variant"}
  "PROCESS_ALU_MAP_PASS:$variant"
}
