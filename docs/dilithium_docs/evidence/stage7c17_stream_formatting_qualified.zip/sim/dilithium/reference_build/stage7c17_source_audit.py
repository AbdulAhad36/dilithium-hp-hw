from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c16_source_hashes.json').read_text());new=json.loads((rb/'stage7c17_source_hashes.json').read_text())
for n,d in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
changed=[n for n in old if old[n]!=new[n]]
assert set(changed)=={'src/controller/process/lighthd_process.sv','src/controller/process/lighthd_bitunpkg.sv',
 'src/controller/process/lighthd_hint_codec.sv','tb/tb_dilithium/tb_lighthd_hint_shared.sv',
 'sim/dilithium/dilithium_vectors.py','quartus/dilithium/report_full.tcl'},changed
added=sorted(set(new)-set(old));assert len(added)==5,added
for stem in ('lighthd_process','lighthd_bitunpkg'):
 ref=(r/('tb/tb_dilithium/'+stem+'_c16_reference.sv')).read_text().replace('module '+stem+'_c16_reference (','module '+stem+' (')
 candidates=(ref.encode(),ref.replace('\n','\r\n').encode())
 assert any(hashlib.sha256(b).hexdigest()==old['src/controller/process/'+stem+'.sv'] for b in candidates),stem
(rb/'stage7c17_source_audit.json').write_text(json.dumps(dict(frozen_files=len(new),changed_existing=changed,added_proof_sources=added,unchanged_existing=len(old)-len(changed),engines_QSF_SDC='exact C16'),indent=2)+'\n')
print('C17_SOURCE_AUDIT_PASS:245 frozen files;3 Process/format RTL and explicit tests/fingerprint/guards;NTT/Keccak/sampler/QSF/SDC exact C16')
