from pathlib import Path
import hashlib,json,subprocess,sys,zipfile

r=Path.cwd();archive=r/'docs/dilithium_docs/evidence/stage7c17_stream_formatting_qualified.zip'
out=r/'tmp/stage7c17_archive_replay'
assert not out.exists(),'Use a fresh extraction path;do not overwrite a failed replay'
with zipfile.ZipFile(archive) as z:
    for n in z.namelist():assert not n.startswith(('/', '\\')) and '..' not in Path(n).parts,n
    z.extractall(out)
manifest=json.loads((out/'MANIFEST.json').read_text())

def verify():
    for n,d in manifest.items():assert hashlib.sha256((out/n).read_bytes()).hexdigest()==d,n

verify()
commands=[['sim/dilithium/dilithium_vectors.py',x] for x in ('lighthd_dma_compare','lighthd_hint_compare','lighthd_hint_selftest','lighthd_main_diagnostic_compare','lighthd_main_compare','lighthd_main_protocol_compare','lighthd_main_selftest','uvm_check')]
commands += [['sim/dilithium/reference_build/stage7c17_'+x+'.py'] for x in ('source_audit','cycle_audit','metrics','admission_registers','native_structure','shared_hint_registers','operand_registers','stream_registers','area_delta','throughput')]
for args in commands:
    print('REPLAY_COMMAND:'+str(args),flush=True)
    p=subprocess.run([sys.executable,*args],cwd=out,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    print(p.stdout,flush=True)
    assert p.returncode==0,args
verify()
print('C17_ARCHIVE_REPLAY_PASS:all native readers,cycle/PPA/retained guards;no prepare or fixture regeneration;all manifest files unchanged')
