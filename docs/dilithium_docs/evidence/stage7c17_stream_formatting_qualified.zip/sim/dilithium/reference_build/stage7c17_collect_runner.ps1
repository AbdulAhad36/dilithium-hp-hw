$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
foreach ($jobId in @(22376,17748,17700)) {Wait-Process -Id $jobId -ErrorAction SilentlyContinue}
foreach ($kind in @('native','uvm','quartus')) {
  $marker='STAGE7C17_'+$kind.ToUpper()+'_RUNNER_PASS'
  if (-not (Select-String -LiteralPath "sim/dilithium/stage7c17_${kind}_runner.log" -Pattern $marker -Quiet)) {throw "C17 qualification incomplete: $kind"}
}
foreach ($reader in @('source_audit','metrics','admission_registers','native_structure','shared_hint_registers','operand_registers','stream_registers','area_delta','throughput','cycle_audit')) {
  & 'C:/Python314/python.exe' "sim/dilithium/reference_build/stage7c17_${reader}.py" *> "sim/dilithium/stage7c17_${reader}_console.log"
  if ($LASTEXITCODE -ne 0) {throw "C17 result reader failed: $reader"}
}
& 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py uvm_check *> sim/dilithium/stage7c17_final_uvm_check.log
if ($LASTEXITCODE -ne 0) {throw 'C17 final UVM freshness failed'}
'STAGE7C17_RESULT_COLLECTION_PASS'
