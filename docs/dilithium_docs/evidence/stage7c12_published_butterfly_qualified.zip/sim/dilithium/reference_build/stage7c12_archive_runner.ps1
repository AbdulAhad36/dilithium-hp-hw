$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/GitHub/dilithium-hp-hw'
& 'C:/Python314/python.exe' sim/dilithium/reference_build/stage7c12_archive.py *> sim/dilithium/stage7c12_archive.log
if($LASTEXITCODE -ne 0){throw 'Create-only C12 archive failed'}
& 'C:/Python314/python.exe' sim/dilithium/reference_build/stage7c12_archive_replay.py *> sim/dilithium/stage7c12_archive_replay.log
if($LASTEXITCODE -ne 0){throw 'Fresh archive replay failed'}
'STAGE7C12_ARCHIVE_AND_REPLAY_PASS'
