$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw\tmp\stage7c12_bf_fit_native'
& 'F:/altera/quartus/bin64/quartus_sh.exe' --flow compile probe *> 'D:\GitHub\dilithium-hp-hw/sim/dilithium/stage7c12_bf_fit_native.log'
if ($LASTEXITCODE -ne 0) {throw 'BF standalone fit failed'}
'STAGE7C12_BF_NATIVE_FIT_PASS'
