onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vlib sim/dilithium/work_lighthd_bf_c12
vmap lighthd_bf_c12 sim/dilithium/work_lighthd_bf_c12
vlog -sv -work lighthd_bf_c12 src/ntt/ntt_pkg.sv src/ntt/mod_mul.sv src/ntt/butterfly_unit.sv src/ntt/lighthd_butterfly_fused.sv tb/tb_dilithium/butterfly_unit_c11_reference.sv tb/tb_dilithium/tb_lighthd_butterfly_fused.sv src/ntt/twiddle_rom.sv src/ntt/ntt_core.sv tb/tb_dilithium/tb_lighthd_ntt_decoders.sv
vsim -L cyclonev_ver lighthd_bf_c12.tb_lighthd_butterfly_fused
onfinish stop
run -all
quit -sim
vsim -L cyclonev_ver lighthd_bf_c12.tb_lighthd_ntt_decoders
onfinish stop
run -all
quit -f

