$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/GitHub/dilithium-hp-hw/sim'
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l dilithium/stage7c12_standalone_ntt.log -do 'do ntt/run_uvm.do; quit -f' *> dilithium/stage7c12_standalone_ntt_console.log
if($LASTEXITCODE -ne 0){throw 'Standalone NTT UVM failed'}
'STAGE7C12_STANDALONE_NTT_RUNNER_DONE:inspect UVM summary and scoreboard PASS'
