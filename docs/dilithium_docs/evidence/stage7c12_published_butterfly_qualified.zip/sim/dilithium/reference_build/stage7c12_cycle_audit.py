from pathlib import Path
import csv,json
h=Path('sim/dilithium');base=h/'reference_build/stage7c12_baseline_c11r1'
report=[]
for leaf,footer in [('stage7c4_main_outputs.txt','F 210'),('stage7c4_main_protocol_outputs.txt','F 88')]:
    a=(base/leaf).read_text().splitlines();b=(h/leaf).read_text().splitlines()
    assert a[-1]==b[-1]==footer,(leaf,'incomplete capture')
    assert a[1:]==b[1:],(leaf,'changed payload/status/attempt/cycle record')
    report.append(leaf+': all non-token records EXACT C11R1,including every measured cycle')
for leaf in ('stage7_uvm_latency.csv','stage7_uvm_checked.csv'):
    a=list(csv.DictReader((base/leaf).open()));b=list(csv.DictReader((h/leaf).open()))
    assert len(a)==len(b)==30,(leaf,'incomplete UVM')
    for x,y in zip(a,b):
        assert all(x[k]==y[k] for k in x if k!='source_token'),(leaf,x,y)
    report.append(leaf+': all30 rows exact C11R1,excluding changed source identity')
report.append('STAGE7C12_CYCLE_AUDIT_PASS: no measured operation-cycle reduction or penalty')
(h/'stage7c12_cycle_audit.log').write_text('\n'.join(report)+'\n')
print('\n'.join(report))
