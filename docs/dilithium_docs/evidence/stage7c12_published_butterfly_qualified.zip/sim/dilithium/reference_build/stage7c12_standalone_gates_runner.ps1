$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/GitHub/dilithium-hp-hw/sim'
foreach($test in @('ntt_coverage_gate_test','ntt_routing_operand_fault_test','ntt_routing_writeback_fault_test','ntt_gs_sum_gate_test')){
 $cmd="set NTT_TEST $test; do ntt/run_uvm.do; quit -f"
 $log="dilithium/stage7c12_${test}.log"
 & 'C:/questasim64_2024.1/win64/vsim.exe' -c -l $log -do $cmd *> "dilithium/stage7c12_${test}_console.log"
 if($LASTEXITCODE -ne 0){throw "Checker process failed:$test"}
 if(-not (Select-String -LiteralPath $log -Pattern 'UVM (COVERAGE GATE|ROUTING CHECKER|GS SUM GATE) PASS' -Quiet)){throw "Missing specific sensitivity PASS:$test"}
 if(-not (Select-String -LiteralPath $log -Pattern 'UVM_ERROR :\s+0' -Quiet)){throw "Unexpected uncaught UVM errors:$test"}
 "C12_STANDALONE_SENSITIVITY_PASS:$test"
}
'STAGE7C12_STANDALONE_SENSITIVITY_PASS'
