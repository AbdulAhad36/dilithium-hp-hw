onerror {quit -code 1 -f}
set script_dir [file normalize sim/dilithium/reference_build/stage7c12_cells]
do sim/keccak/setup_cyclonev_libs.do
vlib sim/dilithium/work_lighthd_dsp_c12
vmap lighthd_dsp_c12 sim/dilithium/work_lighthd_dsp_c12
vlog -sv -work lighthd_dsp_c12 tmp/stage7c12_dsp_chain/probe.sv tmp/stage7c12_dsp_chain/tb.sv
vsim -L cyclonev_ver lighthd_dsp_c12.tb
onfinish stop
run -all
quit -f
