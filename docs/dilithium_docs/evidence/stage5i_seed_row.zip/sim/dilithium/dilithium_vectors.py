"""Real SHAKE -> sampling -> memory -> NTT: independent file comparison.

These are locally generated subsystem vectors, not full-operation NIST vectors.
One script is extended as the Dilithium subsystem grows.
"""
import argparse
import hashlib
import importlib.util
import random
import shutil
import subprocess
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
REF = ROOT / 'FIPS204_SAMPLER/sampler_vectors.py'
spec = importlib.util.spec_from_file_location('sampler_reference', REF)
reference = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reference)
NTT_REF = ROOT / 'FIPS204_NTT/ntt_vectors.py'
ntt_spec = importlib.util.spec_from_file_location('ntt_reference', NTT_REF)
ntt_reference = importlib.util.module_from_spec(ntt_spec)
ntt_spec.loader.exec_module(ntt_reference)


def cases():
    result = []
    def add(mode, param, label, length=None, abort=False, job_id=None):
        i = len(result)
        length = (34 if mode == 0 else 66 if mode in (1, 2) else 32) if length is None else length
        message = hashlib.shake_256(label.encode()).digest(length)
        # Raw absorbed messages exercise the engine connection; full seed/nonce
        # formatting is a later controller/version contract.
        if param == 3:
            values, code = [], 3
        else:
            stream = (hashlib.shake_128 if mode == 0 else hashlib.shake_256)(message).digest(4096)
            values, _ = reference.sample(mode, param, stream)
            assert len(values) == 256
            code = 0
        result.append(dict(i=i, id=1000+i if job_id is None else job_id,
                           mode=mode, param=param, message=message,
                           abort=abort, code=code, values=values))
    # Twelve pairs establish both contexts in every mode/parameter combination.
    for mode in range(4):
        for param in range(3):
            for slot in range(2):
                add(mode, param, f'base-{mode}-{param}-{slot}')
    # All sixteen ordered mode pairs, including independent live peer modes.
    for first in range(4):
        for second in range(4):
            param = (first+second) % 3
            add(first, param, f'mixed-{first}-{second}-a')
            add(second, param, f'mixed-{first}-{second}-b')
    # Empty/partial/multi-rate absorption; unused high input bytes are poisoned.
    lengths = [0, 1, 7, 8, 9, 33, 34, 65, 66, 135, 136, 137,
               167, 168, 169, 271, 272, 273, 335, 336, 337, 15, 16, 17]
    for i, length in enumerate(lengths):
        add(i % 4, (i//4) % 3, f'length-{i}', length)
    assert len(result) == 80
    for mode in range(4):
        for slot in range(2):
            add(mode, 3, f'invalid-{mode}-{slot}')
    for phase in range(4):
        for slot in range(2):
            add((phase+slot) % 4, phase % 3, f'abort-{phase}-{slot}', abort=True,
                job_id=2000+phase*2+slot)
        for slot in range(2):
            add((phase+slot) % 4, phase % 3, f'recover-{phase}-{slot}',
                job_id=2000+phase*2+slot)
    assert len(result) == 104
    return result


@lru_cache(maxsize=1)
def arithmetic_vectors():
    rows=cases(); result=[]
    ntt_reference.check_reference()
    for p in range(3):
        a=rows[2*p]['values'];s=rows[6+2*p]['values']
        ia=ntt_reference.direct_inverse(a);ns=ntt_reference.direct_forward(s)
        pwm=ntt_reference.pointwise(a,ns)
        product=ntt_reference.schoolbook(ia,s)
        assert ntt_reference.direct_inverse(pwm)==product
        for poly in (ia,ns,s,ns,ntt_reference.pointwise(ns,ns),pwm,product):
            result.append(poly)
    for i in (12,18):
        result += [ntt_reference.direct_forward(rows[i]['values']), rows[i]['values']]
    result.append(ntt_reference.direct_forward(rows[7]['values']))
    assert len(result)==26
    return result


@lru_cache(maxsize=1)
def process_cases():
    result=[]
    def add(op,a,b=0,abort=False,job_id=None,bad_last=False):
        i=len(result);index=i%256;last=int(index==255)^int(bad_last)
        error=int(op==3 or a>=8_380_417 or (op<2 and b>=8_380_417) or bad_last)
        residue=high=low=packed=0
        if not error:
            if op==0:residue=(a+b)%8_380_417
            elif op==1:residue=(a-b)%8_380_417
            else:
                high,low=divmod(a,8192)
                if low>4096:high+=1;low-=8192
                packed=4096-low
        result.append([i,op,a,b,9000+i//2 if job_id is None else job_id,index,last,
                       int(abort),error,residue,high,low,packed])
    for op,a,b,recover_op,recover_a,recover_b in [
        (0,0,8_380_416,0,8_380_416,8_380_416),
        (1,0,8_380_416,2,4096,8_388_607),
        (2,4097,0,2,8_380_416,0)]:
        add(op,a,b,True);add(recover_op,recover_a,recover_b)
    for high in range(1024):
        for offset in (0,1,4094,4095,4096,4097,4098,8190,8191):
            a=high*8192+offset
            if a<8_380_417:add(2,a,8_388_607) # unused B must not affect rounding
    boundaries=sorted({0,1,4096,4097,4_190_208,8_380_415,8_380_416})
    for op in (0,1):
        for a in boundaries:
            for b in boundaries:add(op,a,b)
    rng=random.Random(0x5A2026)
    for _ in range(512):
        a=rng.randrange(8_380_417);b=rng.randrange(8_380_417)
        add(0,a,b);add(1,a,b)
    for op in range(3):
        add(op,8_380_417);add(op,8_388_607)
        add(op,1,8_380_417,bad_last=(op==2));add(op,1,bad_last=True)
    add(3,0)
    assert len(result)<16000 and sum(r[7] for r in result)==3
    return result


def check_process_c():
    gcc=shutil.which('gcc')
    if not gcc:raise ValueError('GCC is needed by prepare for the independent process reference')
    build=HERE/'reference_build';build.mkdir(exist_ok=True)
    exe=build/'process_reference.exe'
    subprocess.run([gcc,'-std=c99','-O2','-DDILITHIUM_MODE=2','-I',str(ROOT/'dilithium-sw-model/ref'),
                    str(ROOT/'tb/tb_dilithium/process_reference.c'),str(ROOT/'dilithium-sw-model/ref/rounding.c'),
                    '-o',str(exe)],check=True,capture_output=True,text=True)
    report=subprocess.run([str(exe),'--selftest'],check=True,capture_output=True,text=True).stdout
    if not report.startswith('C_PROCESS_REFERENCE_PASS:8380417 '):raise ValueError('C reference selftest marker missing')
    rows=process_cases()
    values=subprocess.run([str(exe)],input=''.join(f'{r[1]} {r[2]} {r[3]}\n' for r in rows),
                          check=True,capture_output=True,text=True).stdout.splitlines()
    if len(values)!=len(rows):raise ValueError('C process oracle count')
    for r,line in zip(rows,values,strict=True):
        observed=list(map(int,line.split()))
        if r[6]!=int(r[5]==255):observed=[1,0,0,0,0] # framing is checked by the transport
        if observed!=r[8:13]:raise ValueError('Python/C process mismatch at case'+str(r[0]))
    report+=f'PYTHON_C_PROCESS_PASS:{len(rows)} arithmetic/framing cases\n'
    (HERE/'stage5_c_reference.log').write_text(report);print(report,end='')


def artifacts():
    rows = cases()
    stimuli, golden = [], []
    for c in rows:
        stimuli.append(f"{c['i']} {c['id']} {c['mode']} {c['param']} {int(c['abort'])} {len(c['message'])} {c['message'].hex() or '-'}")
        golden.append(f"{c['i']} {c['code']} {int(c['abort'])} {len(c['values'])} " +
                      ' '.join(f'{v:06x}' for v in c['values']))
    body = '\n'.join(stimuli)+'\n'
    expected = '\n'.join(golden)+'\n'
    math_body='\n'.join(str(i)+' '+' '.join(f'{v:06x}' for v in poly)
                        for i,poly in enumerate(arithmetic_vectors()))+'\n'
    process_body='\n'.join(' '.join(map(str,r)) for r in process_cases())+'\n'
    sources = [Path(__file__).resolve(), REF, NTT_REF, ROOT/'sim/dilithium/run.do']
    sources += [ROOT/'tb/tb_dilithium/process_reference.c']
    sources += [ROOT/'dilithium-sw-model/ref'/n for n in ('rounding.c','rounding.h','params.h','config.h')]
    sources += sorted((ROOT/'src/keccak').glob('*.sv'))
    sources += sorted((ROOT/'src/sampler').glob('*.sv'))
    sources += sorted((ROOT/'src/controller').rglob('*.sv'))
    sources += sorted((ROOT/'src/ntt').glob('*.sv'))
    sources += sorted((ROOT/'tb/tb_dilithium').glob('*.sv'))
    h = hashlib.sha256((body+expected+math_body+process_body).encode())
    for p in sources:
        h.update(p.relative_to(ROOT).as_posix().encode()); h.update(p.read_bytes())
    token = h.hexdigest()
    header = f'{token} {len(rows)}\n'
    return rows, token, header+body, header+expected, f'{token} 26\n'+math_body, f'{token} {len(process_cases())}\n'+process_body


@lru_cache(maxsize=1)
def hash_format_cases():
    """Final FIPS 204 KeyGen messages; level labels remain 2/3/5.

    Locally generated component vectors, not published NIST full-operation KATs.
    """
    result=[]
    def add(op,p,seed,row=0,column=0,nonce=0,abort=0,job_id=None):
        i=len(result);k,l=[(4,4),(6,5),(8,7),(0,0)][p]
        error=int(p==3 or op==3 or (op==1 and (row>=k or column>=l)) or
                  (op==2 and nonce>=k+l))
        message=b''
        if not error:
            if op==0:message=seed[:32]+bytes([k,l])
            elif op==1:message=seed[:32]+bytes([column,row])
            else:message=seed[:64]+nonce.to_bytes(2,'little')
        mode=int(op!=1);outlen=128 if op==0 else 0
        # Bound the test service to32 output bytes for sample-message checks.
        # The RTL descriptor remains continuous (outlen0); this test does not sample.
        digest=((hashlib.shake_256 if mode else hashlib.shake_128)(message).digest(
            128 if op==0 else 32)) if not error else b''
        result.append(dict(i=i,op=op,p=p,seed=seed.ljust(64,b'\xa5'),row=row,column=column,
                           nonce=nonce,abort=abort,id=12000+i if job_id is None else job_id,
                           error=error,message=message,mode=mode,outlen=outlen,digest=digest))
    for phase in (1,2,3):
        seed=hashlib.shake_256(f'abort{phase}'.encode()).digest(32)
        add(0,phase-1,seed,abort=phase,job_id=11999+phase)
        add(0,phase-1,bytes(x^255 for x in seed),job_id=11999+phase)
    for p,(k,l) in enumerate(((4,4),(6,5),(8,7))):
        for seed in (bytes(32),bytes([255])*32,bytes(range(32))):add(0,p,seed)
        expanded=hashlib.shake_256(bytes(range(32))+bytes([k,l])).digest(128)
        for row in range(k):
            for column in range(l):add(1,p,expanded[:32],row=row,column=column)
        for nonce in range(k+l):add(2,p,expanded[32:96],nonce=nonce)
        add(1,p,expanded[:32],row=k)
        add(1,p,expanded[:32],column=l)
        add(2,p,expanded[32:96],nonce=k+l)
    for op in range(3):add(op,3,bytes(64))
    add(3,0,bytes(64));add(2,0,bytes(64),nonce=65535)
    return result


def hash_format_artifact(token):
    rows=hash_format_cases()
    body='\n'.join(f"{r['i']} {r['op']} {r['p']} {r['id']} {r['row']} {r['column']} "
                   f"{r['nonce']} {r['abort']} {r['error']} "
                   f"{int.from_bytes(r['seed'],'little'):0128x} "
                   f"{int.from_bytes(r['message'],'little'):0132x}" for r in rows)+'\n'
    return f'{token} {len(rows)}\n'+body


@lru_cache(maxsize=1)
def shared_hash_cases():
    rows=[];expanded={}
    def add(kind,p=0,mode=1,abort=0,seed=b'',message=b'',outlen=128,nonce=0,row=0,column=0,job_id=None):
        i=len(rows);error=int(kind==1 and p==3)
        if kind==1:
            message=b'' if error else seed+bytes([(4,6,8)[p],(4,5,7)[p]])
        if kind==2:
            material=expanded[p]
            message=(material[:32]+bytes([column,row])) if mode==0 else material[32:96]+nonce.to_bytes(2,'little')
            outlen=0
        digest=b'' if error or kind==2 else (hashlib.shake_256 if mode else hashlib.shake_128)(message).digest(outlen)
        values=[]
        if kind==2:
            values,_=reference.sample(mode,p,(hashlib.shake_128 if mode==0 else hashlib.shake_256)(message).digest(4096))
        rows.append(dict(i=i,kind=kind,p=p,mode=mode,abort=abort,seed=seed.ljust(32,b'\0'),message=message,
                         outlen=outlen,nonce=nonce,row=row,column=column,id=13000+i if job_id is None else job_id,
                         error=error,digest=digest,values=values))
    for phase in (1,2,3):
        add(1,abort=phase,seed=hashlib.shake_256(f'shared-abort-{phase}'.encode()).digest(32),job_id=12990+phase)
        add(1,seed=hashlib.shake_256(f'shared-recover-{phase}'.encode()).digest(32),job_id=12990+phase)
    for p,(k,l) in enumerate(((4,4),(6,5),(8,7))):
        seed=hashlib.shake_256(f'shared-main-{p}'.encode()).digest(32)
        expanded[p]=hashlib.shake_256(seed+bytes([k,l])).digest(128)
        add(1,p,seed=seed)
        add(2,p,mode=0,row=k-1,column=l-1)
        add(2,p,mode=1,nonce=k+l-1)
    add(1,3,seed=bytes(32))
    for i,(length,outlen) in enumerate(((0,1),(1,15),(7,16),(8,17),(136,137),(169,169),(273,272),(34,32))):
        add(0,mode=i%2,message=hashlib.shake_256(f'raw-{i}'.encode()).digest(length),outlen=outlen)
    add(0,message=bytes(range(17)),outlen=128)
    add(2,1,mode=0,row=5,column=4)
    return rows


def shared_hash_artifact(token):
    rows=shared_hash_cases()
    body='\n'.join(f"{r['i']} {r['kind']} {r['p']} {r['id']} {r['mode']} {r['abort']} "
                   f"{len(r['message'])} {r['outlen']} {r['nonce']} {r['row']} {r['column']} "
                   f"{int.from_bytes(r['seed'],'little'):064x} "
                   f"{int.from_bytes(r['message'],'little'):0800x}" for r in rows)+'\n'
    return f'{token} {len(rows)}\n'+body


@lru_cache(maxsize=1)
def bank_memory_cases():
    rows=[];rng=random.Random(0xB4921024)
    def add(phase,b,p,write,address,data=0):
        rows.append([len(rows),phase,b,p,write,address,data])
    for b in range(4):
        for p in range(2):
            for j in range(512):add(0,b,p,1,2*j+p,rng.getrandbits(92))
            for j in range(1024):add(1,b,p,0,j)
            for j in range(16):add(2,b,p,int(p==0),0,rng.getrandbits(92))
            add(3,b,p,1,5,(1<<92)-1 if p else 0)
            add(4,b,p,p,9,rng.getrandbits(92))
            for j in range(300):add(5,b,p,rng.randrange(2),rng.randrange(1024),rng.getrandbits(92))
            add(6,b,p,1,10+p,((b+1)<<80)|((p+1)<<64)|0xABCDEF)
            add(7,b,p,1,20+p,(1<<92)-1) # never accepted:blocked offer canceled by reset
            for address in (10,11,20,21):add(8,b,p,0,address)
    return rows


def bank_memory_artifact(token):
    rows=bank_memory_cases()
    return f'{token} {len(rows)}\n'+'\n'.join(' '.join(map(str,r[:6]))+f' {r[6]:023x}' for r in rows)+'\n'


def prepare():
    check_process_c()
    rows, token, stimuli, golden, arithmetic, process = artifacts()
    (HERE/'stage2_inputs.txt').write_text(stimuli, encoding='ascii')
    (HERE/'stage2_expected.txt').write_text(golden, encoding='ascii')
    (HERE/'stage4_expected.txt').write_text(arithmetic, encoding='ascii')
    (HERE/'stage5_process_inputs.txt').write_text(process, encoding='ascii')
    (HERE/'stage5_hash_inputs.txt').write_text(hash_format_artifact(token),encoding='ascii')
    (HERE/'stage5_shared_inputs.txt').write_text(shared_hash_artifact(token),encoding='ascii')
    (HERE/'stage5_banks_inputs.txt').write_text(bank_memory_artifact(token),encoding='ascii')
    (HERE/'stage5_process_banks_inputs.txt').write_text(process_bank_artifact(token),encoding='ascii')
    (HERE/'stage5_seed_inputs.txt').write_text(seed_input_artifact(token),encoding='ascii')
    (HERE/'stage5_row_samples.txt').write_text(row_sample_artifact(token),encoding='ascii')
    (HERE/'stage5_row_expected.txt').write_text(row_expected_artifact(token),encoding='ascii')
    print(f'PREPARE PASS:{len(rows)} sampling cases plus26 arithmetic expectations;token {token}')


def check():
    rows, token, stimuli, golden, arithmetic, process = artifacts()
    if ((HERE/'stage2_inputs.txt').read_text() != stimuli or
        (HERE/'stage2_expected.txt').read_text() != golden or
        (HERE/'stage4_expected.txt').read_text() != arithmetic or
        (HERE/'stage5_process_inputs.txt').read_text() != process or
        (HERE/'stage5_hash_inputs.txt').read_text() != hash_format_artifact(token) or
        (HERE/'stage5_shared_inputs.txt').read_text() != shared_hash_artifact(token) or
        (HERE/'stage5_banks_inputs.txt').read_text() != bank_memory_artifact(token) or
        (HERE/'stage5_process_banks_inputs.txt').read_text() != process_bank_artifact(token) or
        (HERE/'stage5_seed_inputs.txt').read_text() != seed_input_artifact(token) or
        (HERE/'stage5_row_samples.txt').read_text() != row_sample_artifact(token) or
        (HERE/'stage5_row_expected.txt').read_text() != row_expected_artifact(token)):
        raise ValueError('Stale source/reference/vector files: rerun prepare and capture')
    return rows, token


def verify(lines):
    rows, token = check()
    if not lines or lines[0] != 'H '+token:
        raise ValueError('Capture token differs;rerun simulation after prepare')
    opened, counts, finished = {}, {}, {}
    total_values = 0
    footer = None
    for line in lines[1:]:
        f = line.split()
        if f[0] == 'F':
            if footer is not None: raise ValueError('Duplicate footer')
            footer = list(map(int, f[1:]));continue
        i, core = map(int, f[1:3])
        if not 0 <= i < len(rows) or core not in (0, 1): raise ValueError('Unknown job/core')
        c = rows[i]
        if f[0] == 'J':
            if i in opened or int(f[3]) != c['id']: raise ValueError('Repeated/wrong descriptor')
            opened[i] = core;counts[i] = 0;continue
        if opened.get(i) != core or i in finished: raise ValueError('Unowned/retired output')
        if f[0] == 'C':
            index, value, last = int(f[3]), int(f[4],16), int(f[5])
            if index != counts[i] or index >= len(c['values']) or value != c['values'][index] or last != int(index==255):
                raise ValueError(f'Coefficient mismatch:case{i},index{index},observed{value}')
            counts[i] += 1;total_values += 1
        elif f[0] == 'S':
            if c['abort'] or int(f[3]) != c['code'] or counts[i] != len(c['values']):
                raise ValueError(f'Wrong status/count for case{i}')
            finished[i] = 'S'
        elif f[0] == 'A':
            if not c['abort'] or int(f[3]) != counts[i]: raise ValueError('Unexpected abort/count')
            finished[i] = 'A'
        else:raise ValueError('Unknown capture record')
    if len(opened) != 104 or len(finished) != 104 or footer != [104,88,8,8,total_values]:
        raise ValueError('Missing/extra jobs or incorrect footer')
    combinations = {(opened[c['i']],c['mode'],c['param']) for c in rows if not c['abort'] and c['code']==0}
    if len(combinations) != 24:raise ValueError('Missing mode/parameter/context combination')
    message = (f'DILITHIUM STAGE2 COMPARE PASS:104 jobs,88 complete,8 expected errors,8 reset aborts;'
               f'{total_values} exact coefficients (22528 complete-polynomial values plus checked aborted prefixes);'
               '24 mode/parameter/context combinations\n')
    return message


def verify_memory(lines):
    rows, token = check()
    if not lines or lines[0] != 'H '+token:
        raise ValueError('Memory capture token differs')
    opened, counts, finished, read_counts = {}, {}, {}, {}
    slots, live = {}, {}
    writes = reads = invalid = releases = resets = 0
    footer = None
    for line in lines[1:]:
        if footer is not None: raise ValueError('Record after memory footer')
        f = line.split()
        kind = f[0]
        if kind == 'F':
            footer = list(map(int, f[1:])); continue
        if kind == 'X':
            if live: raise ValueError('Reset omitted live-job abort records')
            slots.clear(); resets += 1; continue
        if kind in ('E', 'L'):
            slot = int(f[1])
            if not 0 <= slot < 4: raise ValueError('Bad memory slot')
            if kind == 'E':
                if slot in slots and slots[slot][1]: raise ValueError('Readable slot reported error')
                if not 0 <= int(f[2]) < 256: raise ValueError('Bad invalid-read index')
                invalid += 1
            else:
                if slot not in slots or not slots[slot][1]: raise ValueError('Release of incomplete slot')
                if read_counts.get(slots[slot][0], 0) != 256: raise ValueError('Released before full readback')
                del slots[slot]; releases += 1
            continue
        if kind not in ('J', 'W', 'S', 'A', 'R'): raise ValueError('Unknown memory record')
        i = int(f[1])
        if not 0 <= i < len(rows): raise ValueError('Bad memory case')
        c = rows[i]
        if kind == 'J':
            core, slot, job_id = map(int, f[2:])
            if core not in (0, 1) or core in live or not 0 <= slot < 4 or slot in slots:
                raise ValueError('Memory allocation reused live owner')
            if i in opened or job_id != c['id']: raise ValueError('Repeated/wrong memory descriptor')
            opened[i] = (core, slot); counts[i] = read_counts[i] = 0
            slots[slot] = (i, False); live[core] = i
        elif kind == 'R':
            slot, index = map(int, f[2:4])
            if slots.get(slot) != (i, True) or opened.get(i, (None,None))[1] != slot:
                raise ValueError('Read before commit, after release/reset, or from wrong slot')
            if index != read_counts.get(i) or index >= 256: raise ValueError('Read order/count mismatch')
            if (int(f[4],16) != c['values'][index] or
                list(map(int,f[5:])) != [c['id'],c['mode'],c['param'],int(c['mode']==0)]):
                raise ValueError('Memory data or metadata mismatch')
            reads += 1; read_counts[i] += 1
        else:
            core = int(f[2])
            if live.get(core) != i: raise ValueError('Write/status without live owner')
            slot = opened[i][1]
            if kind == 'W':
                index = int(f[3])
                if index != counts[i] or index >= len(c['values']): raise ValueError('Write index mismatch')
                if int(f[4],16) != c['values'][index] or int(f[5]) != int(index==255):
                    raise ValueError('Write data/last mismatch')
                counts[i] += 1; writes += 1
            else:
                if kind == 'S':
                    if c['abort'] or int(f[3]) != c['code'] or counts[i] != len(c['values']):
                        raise ValueError('Incorrect memory completion')
                    if c['code']==0: slots[slot] = (i,True)
                    else: del slots[slot]
                elif not c['abort'] or int(f[3]) != counts[i]:
                    raise ValueError('Incorrect memory abort')
                finished[i] = kind; del live[core]
    successful = [c['i'] for c in rows if not c['abort'] and c['code']==0]
    combinations = {(opened[i][0],rows[i]['mode'],rows[i]['param']) for i in successful}
    if (len(opened)!=104 or len(finished)!=104 or live or slots or
        footer != [104,88,8,8,writes,reads] or reads!=22528 or releases!=88 or
        invalid<90 or resets!=5 or len(combinations)!=24 or any(read_counts[i]!=256 for i in successful)):
        raise ValueError('Incomplete memory lifecycle/readback gate')
    return (f'DILITHIUM STAGE3 COMPARE PASS:104 jobs,88 complete,8 expected errors,8 reset aborts;'
            f'{writes} exact writes,22528 exact readbacks;88 releases,{invalid} invalid reads,5 resets\n')


@lru_cache(maxsize=128)
def arithmetic_result(operation, a, b=()):
    if operation in (0,3): return tuple(ntt_reference.direct_forward(list(a)))
    if operation==1:return tuple(ntt_reference.direct_inverse(list(a)))
    return tuple(ntt_reference.pointwise(list(a),list(b)))


def verify_ntt(lines,banked=False):
    rows, token=check()
    if not lines or lines[0]!='H '+token:raise ValueError('NTT capture token differs')
    slots={};jobs={};live={};operations={};pending=None;footer=None
    samples=successes=rejections=aborts=writes=results=reads=resets=loads=releases=invalid=0
    op_kinds=set();rejection_kinds=set();sample_modes=set();regions=set();physical=acks=0
    capacity=64 if banked else 4;witnesses=None
    def eligibility(o):
        if banked and (o['dest']==o['a'] or (o['op']==2 and o['dest']==o['b'])):return 3
        a=slots.get(o['a']);b=slots.get(o['b']);op=o['op']
        if (a is None or a['state']!='complete' or a['id']!=o['aid'] or
            (op==2 and (b is None or b['state']!='complete' or b['id']!=o['bid']))):return 1
        if ((op in (0,3) and a['domain']) or (op in (1,2) and not a['domain']) or
            (op==3 and any(4<v<ntt_reference.Q-4 for v in a['values'])) or
            (op==2 and (not b['domain'] or b['param']!=a['param']))):return 2
        return 0
    for line in lines[1:]:
        if footer is not None:raise ValueError('Records after NTT footer')
        f=line.split();kind=f[0]
        if kind=='F':footer=list(map(int,f[1:]));continue
        if banked and kind=='G':
            if witnesses is not None:raise ValueError('Duplicate bank witnesses')
            witnesses=list(map(int,f[1:]));continue
        if kind=='X':
            if live or pending is not None:raise ValueError('Reset lacks abort/retirement records')
            slots.clear();resets+=1;continue
        if banked and kind in ('P','Q'):
            family=f[1];owner,region,word=map(int,f[2:5])
            if family not in ('S','N'):raise ValueError('Invalid packed writer')
            o=jobs.get(owner) if family=='S' else operations.get(owner)
            if o is None or (family=='S' and (live.get(o['core'])!=owner or o['done'])) or (family=='N' and (pending!=owner or o['code']!=0)):
                raise ValueError('Packed word without owner')
            dest=o['slot'] if family=='S' else o['dest']
            values=slots[dest]['values'];pc=o.get('packed',0);ac=o.get('acks',0)
            if region!=dest or not 0<=word<64:raise ValueError('Packed region/address mismatch')
            if kind=='P':
                expected=sum(values[4*word+lane]<<(23*lane) for lane in range(4))
                if word!=pc or o['count']<4*(word+1) or int(f[5],16)!=expected:raise ValueError('Packed value/order mismatch')
                o['packed']=pc+1;physical+=1
            else:
                if word!=ac or ac>=pc:raise ValueError('Packed acknowledgement without write')
                o['acks']=ac+1;acks+=1
            continue
        if kind=='J':
            j,c,core,s,jobid=map(int,f[1:])
            if (j!=samples or not 0<=c<len(rows) or rows[c]['code']!=0 or core not in (0,1) or
                core in live or not 0<=s<capacity or s in slots or pending is not None):
                raise ValueError('Bad sampled allocation')
            jobs[j]=dict(case=c,core=core,slot=s,count=0,done=False);live[core]=j
            r=rows[c];slots[s]=dict(id=jobid,mode=r['mode'],param=r['param'],domain=int(r['mode']==0),
                                  values=r['values'],state='writing',reads=0)
            sample_modes.add(r['mode']);regions.add(s);samples+=1;continue
        if kind in ('W','S'):
            j=int(f[1]);job=jobs.get(j)
            if job is None or live.get(job['core'])!=j or job['done']:raise ValueError('Sample without owner')
            s=slots[job['slot']]
            if kind=='W':
                index=int(f[2])
                if index!=job['count'] or index>=256 or int(f[3],16)!=s['values'][index] or int(f[4])!=int(index==255):
                    raise ValueError('Sample write mismatch')
                job['count']+=1;writes+=1
            else:
                if job['count']!=256 or list(map(int,f[2:]))!=[s['id'],0]:raise ValueError('Premature/wrong sample status')
                if banked and (job.get('packed')!=64 or job.get('acks')!=64):raise ValueError('Sample published before packed acknowledgements')
                s['state']='complete';job['done']=True;del live[job['core']]
            continue
        if kind=='O':
            run,op,a,aid,b,bid,resultid=map(int,f[1:8])
            if run!=len(operations) or op not in range(4) or a not in range(capacity) or b not in range(capacity) or pending is not None or live:
                raise ValueError('Overlapping/invalid compute command')
            operations[run]=dict(op=op,a=a,aid=aid,b=b,bid=bid,id=resultid,code=None,count=0,loads=0,done=False)
            if banked:operations[run]['dest']=int(f[8])
            pending=run;continue
        if kind in ('V','T','K','D','B'):
            run=int(f[1]);o=operations.get(run)
            if o is None or pending!=run or o['done']:raise ValueError('NTT event without live operation')
            if kind=='V':
                code,dest=map(int,f[2:])
                if o['code'] is not None or code!=eligibility(o):raise ValueError('Wrong reservation/domain decision')
                if banked and dest!=o['dest']:raise ValueError('Changed requested destination')
                o['code']=code;o['dest']=dest
                if code==0:
                    if dest not in range(capacity) or dest in slots:raise ValueError('Overwritten live polynomial')
                    a=slots[o['a']];b=slots.get(o['b'])
                    o['a_values']=tuple(a['values']);o['b_values']=tuple(b['values']) if o['op']==2 else ()
                    o['expected']=arithmetic_result(o['op'],o['a_values'],o['b_values'])
                    a['state']='in_use'
                    if o['op']==2:b['state']='in_use'
                    slots[dest]=dict(id=o['id'],mode=a['mode'],param=a['param'],domain=int(o['op']!=1),
                                     values=o['expected'],state='writing',reads=0)
                    regions.add(dest)
                elif not banked and dest!=0:raise ValueError('Rejected reservation returned destination')
            elif kind=='T':
                index,s,jobid,coefficient=map(int,f[2:6]);value=int(f[6],16)
                source=o['a'] if index<256 else o['b'];srcid=o['aid'] if index<256 else o['bid']
                expected=o.get('a_values',()) if index<256 else o.get('b_values',())
                if (o['code']!=0 or index!=o['loads'] or not expected or index>=len(o['a_values'])+len(o['b_values']) or
                    s!=source or jobid!=srcid or coefficient!=index%256 or value!=expected[index%256]):
                    raise ValueError('DMA operand/value/tag/order mismatch')
                o['loads']+=1;loads+=1
            elif kind=='K':
                index=int(f[2])
                if (o['code']!=0 or o['loads']!=(512 if o['op']==2 else 256) or index!=o['count'] or index>=256 or
                    int(f[3],16)!=o['expected'][index] or int(f[4])!=int(index==255)):
                    raise ValueError('NTT output/last mismatch')
                o['count']+=1;results+=1
            elif kind=='D':
                code,dest,resultid=map(int,f[2:])
                if code!=o['code'] or dest!=o['dest'] or resultid!=o['id']:raise ValueError('Wrong compute retirement')
                if code==0:
                    if o['count']!=256 or o['loads']!=(512 if o['op']==2 else 256):raise ValueError('Premature compute commit')
                    if banked and (o.get('packed')!=64 or o.get('acks')!=64):raise ValueError('Result published before packed acknowledgements')
                    slots[dest]['state']='complete';slots[o['a']]['state']='complete'
                    if o['op']==2:slots[o['b']]['state']='complete'
                    successes+=1;op_kinds.add(o['op'])
                else:
                    if o['count'] or o['loads']:raise ValueError('Rejected compute changed arithmetic')
                    rejections+=1;rejection_kinds.add(code)
                o['done']=True;pending=None
            else:
                if o['code']!=0 or int(f[2])!=o['count']:raise ValueError('Bad compute abort')
                o['done']=True;pending=None;aborts+=1
            continue
        if kind in ('R','E','L'):
            s=int(f[1]);v=slots.get(s)
            if not 0<=s<capacity:raise ValueError('Bad read/release slot')
            if kind=='E':
                if v is not None and v['state']=='complete':raise ValueError('Readable slot rejected')
                if not 0<=int(f[2])<256:raise ValueError('Bad rejected read index')
                invalid+=1
            elif kind=='L':
                if (v is None or v['state']!='complete' or v['reads']!=256 or
                    (banked and pending is not None and (s==operations[pending]['a'] or
                     (operations[pending]['op']==2 and s==operations[pending]['b'])))):
                    raise ValueError('Release of locked/incomplete/unread slot')
                del slots[s];releases+=1
            else:
                index=int(f[2])
                if (v is None or v['state']!='complete' or index!=v['reads'] or index>=256 or
                    int(f[3],16)!=v['values'][index] or
                    list(map(int,f[4:]))!=[v['id'],v['mode'],v['param'],v['domain']]+(
                      [int(all(x<=4 or x>=ntt_reference.Q-4 for x in v['values']))] if banked else [])):
                    raise ValueError('Stored NTT value/domain/metadata mismatch')
                v['reads']+=1;reads+=1
            continue
        raise ValueError('Unknown Stage4 capture record')
    commands=54 if banked else 50;reject_count=21 if banked else 17
    if (footer!=[16,commands,30,reject_count,3,4096,results,11776] or samples!=16 or len(operations)!=commands or
        (successes,rejections,aborts,writes,reads,resets,releases)!=(30,reject_count,3,4096,11776,4,43) or
        (not banked and loads!=9745) or
        slots or live or pending is not None or any(not j['done'] for j in jobs.values()) or
        any(not o['done'] for o in operations.values()) or op_kinds!={0,1,2,3} or
        rejection_kinds!=({1,2,3} if banked else {1,2}) or sample_modes!={0,1,2,3} or invalid!=6):
        raise ValueError(f'Incomplete Stage4 gate:{samples,len(operations),successes,rejections,aborts,writes,results,reads,resets,loads,releases}')
    if banked:
        aborted_ops=[o for o in operations.values() if o['code']==0 and o['count']<256]
        if ([o['loads'] for o in aborted_ops][1:]!=[256,256] or
            not 17<=aborted_ops[0]['loads']<=18 or [o['count'] for o in aborted_ops][:2]!=[0,0] or
            not 32<=aborted_ops[2]['count']<=33 or {s//16 for s in regions}!={0,1,2,3} or
            not any(o['code']==0 and o['a']//16==o['dest']//16 for o in operations.values())):
            raise ValueError('Incomplete bank/abort campaign')
        if witnesses is None or witnesses[0]<18 or witnesses[1:]!=[33,4,120]:raise ValueError('Missing ownership witnesses')
        return (f'DILITHIUM STAGE5F BANK NTT COMPARE PASS:16 sample jobs,54 commands,30 results,21 rejections,3 aborts;'
                f'4096 sample coefficients,{loads} DMA values,{results} NTT outputs,2944 exact packed readbacks;'
                f'{physical} packed writes,{acks} acknowledgements;all four banks\n')
    return (f'DILITHIUM STAGE4 COMPARE PASS:16 sampled jobs,50 commands,30 arithmetic results,17 rejected,3 reset aborts;'
            f'4096 sampled coefficients,{loads} DMA operands,{results} NTT outputs,11776 exact stored readbacks\n')


def verify_process(lines):
    _,token=check();rows=process_cases()
    if not lines or lines[0]!='H '+token:raise ValueError('Process capture token differs')
    opened=set();finished=set();queue=[];footer=None;resets=complete=aborts=errors=0
    for line in lines[1:]:
        if footer is not None:raise ValueError('Record after process footer')
        f=line.split();kind=f[0]
        if kind=='F':footer=list(map(int,f[1:]));continue
        if kind=='X':
            if queue:raise ValueError('Reset omitted accepted abort')
            resets+=1;continue
        if kind not in ('J','P','A'):raise ValueError('Unknown process record')
        i=int(f[1])
        if not 0<=i<len(rows):raise ValueError('Unknown process case')
        r=rows[i]
        if kind=='J':
            if i!=len(opened) or i in opened or queue:raise ValueError('Process input sequence/elastic ownership')
            opened.add(i);queue.append(i)
        else:
            if not queue or queue.pop(0)!=i or i in finished:raise ValueError('Output/abort without matching input')
            if kind=='A':
                if not r[7]:raise ValueError('Unexpected process abort')
                aborts+=1
            else:
                if r[7] or list(map(int,f[2:]))!=r[8:13]+[r[4],r[5],r[6],r[1]]:
                    raise ValueError('Process arithmetic/rounding/framing/tag mismatch')
                complete+=1;errors+=r[8]
            finished.add(i)
    if (len(opened)!=len(rows) or len(finished)!=len(rows) or queue or resets!=4 or aborts!=3 or
        complete!=len(rows)-3 or errors!=13 or footer!=[len(rows),complete,3,13]):
        raise ValueError('Incomplete process gate')
    return (f'DILITHIUM STAGE5 PROCESS COMPARE PASS:{len(rows)} accepted,{complete} exact outputs,'
            '3 reset aborts,13 expected errors;all canonical high-part rounding boundaries exercised\n')


def verify_hash_format(lines):
    _,token=check();rows=hash_format_cases()
    if not lines or lines[0]!='H '+token:raise ValueError('Hash-format capture token')
    opened=set();finished=set();state=None;totals=[0]*6;footer=None;resets=0;cores=set()
    for line in lines[1:]:
        if footer is not None:raise ValueError('Record after hash-format footer')
        f=line.split();kind=f[0]
        if kind=='X':
            if state is not None:raise ValueError('Reset without formatter abort')
            resets+=1;continue
        if kind=='F':footer=list(map(int,f[1:]));continue
        i=int(f[1])
        if not 0<=i<len(rows):raise ValueError('Unknown formatter case')
        r=rows[i]
        if kind=='J':
            if state is not None or i!=len(opened):raise ValueError('Formatter ownership/sequence')
            opened.add(i);state=dict(i=i,d=0,w=0,v=0,s=0);totals[0]+=1;continue
        if state is None or state['i']!=i:raise ValueError('Unowned formatter event')
        if kind=='D':
            if r['error'] or state['d'] or list(map(int,f[2:]))!=[r['mode'],len(r['message']),r['outlen']]:
                raise ValueError('SHAKE descriptor mismatch')
            state['d']=1
        elif kind=='W':
            n=state['w'];word=r['message'][8*n:8*n+8].ljust(8,b'\0')
            if not state['d'] or int(f[2])!=n or n*8>=len(r['message']) or int(f[3],16)!=int.from_bytes(word,'little'):
                raise ValueError('Seed/nonce absorption message mismatch')
            state['w']+=1;totals[4]+=1
        elif kind=='V':
            n=state['v'];core=int(f[4]);offset=16*n
            if (not state['d'] or state['w']!=(len(r['message'])+7)//8 or int(f[2])!=n or
                int(f[3])!=16 or core not in (0,1) or offset>=len(r['digest']) or
                int(f[5],16)!=int.from_bytes(r['digest'][offset:offset+16],'little')):
                raise ValueError('SHAKE output mismatch')
            if n and core!=state['core']:raise ValueError('Hash core changed within job')
            state['core']=core;cores.add(core);state['v']+=1;totals[5]+=1
        elif kind=='S':
            if state['s'] or list(map(int,f[2:]))!=[r['id'],r['error']]:raise ValueError('Formatter completion mismatch')
            if state['w']!=(len(r['message'])+7)//8:raise ValueError('Completion before full message')
            state['s']=1;totals[1]+=1;totals[2]+=r['error']
        elif kind=='A':
            if not r['abort'] or int(f[2])!=r['abort'] or state['s'] or state['v']:
                raise ValueError('Unexpected formatter abort')
            if (state['d'],state['w'])!=[(0,0),(1,2),(1,5)][r['abort']-1]:raise ValueError('Wrong reset phase')
            totals[3]+=1;finished.add(i);state=None
        elif kind=='E':
            if r['abort'] or not state['s'] or state['d']!=int(not r['error']) or state['v']!=len(r['digest'])//16:
                raise ValueError('Incomplete formatter/hash result')
            finished.add(i);state=None
        else:raise ValueError('Unknown formatter record')
    if (state is not None or len(opened)!=len(rows) or len(finished)!=len(rows) or resets!=4 or
        cores!={0,1} or totals!=footer or totals[3]!=3):raise ValueError('Incomplete formatter gate')
    return (f'DILITHIUM STAGE5 HASH FORMAT COMPARE PASS:{totals[0]} accepted,'
            f'{totals[1]} completions,{totals[2]} expected errors,3 reset aborts;'
            f'{totals[4]} absorption words,{16*totals[5]} exact SHAKE bytes;'
            'all102 matrix entries and34 secret nonces across levels2/3/5\n')


def verify_shared_hash(lines):
    _,token=check();rows=shared_hash_cases()
    if not lines or lines[0]!='H '+token:raise ValueError('Shared hash capture token')
    jobs={};owners={};finished=set();resets=0;footer=None;totals=[0]*7
    for line in lines[1:]:
        if footer is not None:raise ValueError('Record after shared footer')
        f=line.split();kind=f[0]
        if kind=='X':
            if owners or any(i not in finished for i in jobs):raise ValueError('Reset omitted live owner/abort')
            resets+=1;continue
        if kind=='F':footer=list(map(int,f[1:]));continue
        i=int(f[1])
        if not 0<=i<len(rows):raise ValueError('Unknown shared case')
        r=rows[i]
        if kind=='J':
            if i in jobs:raise ValueError('Duplicate shared command')
            jobs[i]=dict(desc=False,w=0,n=0,c=0,d=False);totals[0]+=1;continue
        if i not in jobs or i in finished:raise ValueError('Unowned/retired shared event')
        s=jobs[i]
        if kind in ('R','S'):
            core=int(f[2])
            if core not in (0,1) or core in owners or s['desc'] or r['error']:
                raise ValueError('Descriptor overwrote owner')
            expected=([r['id'],r['mode'],r['p'],len(r['message'])] if kind=='S' else
                      [r['id'],r['mode'],len(r['message']),r['outlen']])
            if list(map(int,f[3:]))!=expected or (kind=='S')!=(r['kind']==2):raise ValueError('Shared descriptor mismatch')
            s['desc']=True;s['core']=core;owners[core]=i;totals[2 if kind=='S' else 1]+=1
        elif kind in ('W','P'):
            n=s['w'];word=r['message'][8*n:8*n+8].ljust(8,b'\0')
            if (not s['desc'] or (kind=='P')!=(r['kind']==2) or int(f[2])!=n or
                n*8>=len(r['message']) or int(f[3],16)!=int.from_bytes(word,'little')):
                raise ValueError('Shared absorption mismatch')
            s['w']+=1
        elif kind=='O':
            core,job_id,offset,n=map(int,f[2:6]);rate=136 if r['mode'] else 168
            expected_n=min(16,len(r['digest'])-s['n'],rate-s['n']%rate)
            expected=r['digest'][s['n']:s['n']+n]
            if (r['kind']==2 or owners.get(core)!=i or job_id!=r['id'] or offset!=s['n'] or
                n!=expected_n or n<=0 or s['w']!=(len(r['message'])+7)//8 or
                int(f[6],16)&((1<<(8*n))-1)!=int.from_bytes(expected,'little')):
                raise ValueError(f'Shared raw bytes/tag mismatch:case{i},offset{offset}')
            s['n']+=n;totals[5]+=n
        elif kind=='D':
            core,job_id=map(int,f[2:])
            if owners.get(core)!=i or job_id!=r['id'] or s['d'] or s['n']!=len(r['digest']):
                raise ValueError('Premature/wrong raw completion')
            s['d']=True;del owners[core]
            if r['kind']==0:finished.add(i)
        elif kind=='Z':
            error,job_id,p=map(int,f[2:5]);material=bytes(128) if r['error'] else r['digest']
            expected=[int.from_bytes(material[:32],'little'),int.from_bytes(material[32:96],'little'),
                      int.from_bytes(material[96:128],'little')]
            if (r['kind']!=1 or r['abort'] or [error,job_id,p]!=[r['error'],r['id'],r['p']] or
                list(int(v,16) for v in f[5:])!=expected or s['desc']!=bool(not error) or
                (not error and not s['d'])):raise ValueError('Seed material/metadata mismatch')
            totals[3]+=1;finished.add(i)
        elif kind=='C':
            core,job_id,index=map(int,f[2:5])
            if (r['kind']!=2 or owners.get(core)!=i or job_id!=r['id'] or index!=s['c'] or index>=256 or
                int(f[5],16)!=r['values'][index] or int(f[6])!=int(index==255) or
                s['w']!=(len(r['message'])+7)//8):raise ValueError('Derived-seed sampler mismatch')
            s['c']+=1;totals[6]+=1
        elif kind=='T':
            core,code=map(int,f[2:])
            if owners.get(core)!=i or r['kind']!=2 or code!=0 or s['c']!=256:raise ValueError('Sampling completion mismatch')
            del owners[core];finished.add(i)
        elif kind=='A':
            if not r['abort'] or int(f[2])!=r['abort']:raise ValueError('Unexpected shared abort')
            if (s['w'],s['n'],s['d'])!=[(2,0,False),(5,16,False),(5,128,True)][r['abort']-1]:
                raise ValueError('Shared reset phase mismatch')
            if owners.get(s.get('core'))==i:del owners[s['core']]
            totals[4]+=1;finished.add(i)
        else:raise ValueError('Unknown shared event')
    if (len(jobs)!=len(rows) or len(finished)!=len(rows) or owners or resets!=4 or totals!=footer or
        totals!=[26,18,7,7,3,1699,1792]):raise ValueError('Incomplete shared hash gate')
    return ('DILITHIUM STAGE5 SHARED HASH COMPARE PASS:26 commands,18 raw hashes,7 sampled polynomials,'
            '7 seed results(including1 expected parameter error),3 reset aborts;1699 exact SHAKE bytes,'
            '1792 exact coefficients from RTL-collected seeds;both raw and sampled ownership checked\n')


def verify_bank_memory(lines):
    _,token=check();rows=bank_memory_cases()
    if not lines or lines[0]!='H '+token:raise ValueError('Bank capture token')
    memory={};pending={};opened=set();finished=set();expected={};totals=[0]*5;resets=0;footer=None
    for line in lines[1:]:
        if footer is not None:raise ValueError('Record after bank footer')
        f=line.split();kind=f[0]
        if kind=='F':footer=list(map(int,f[1:]));continue
        if kind=='X':
            if pending:raise ValueError('Reset omitted bank response abort')
            resets+=1;continue # payload survives reset;ownership does not
        i=int(f[1])
        if not 0<=i<len(rows):raise ValueError('Unknown bank command')
        r=rows[i];_,phase,b,p,write,address,data=r;port=(b,p)
        if kind=='J':
            cycle=int(f[2])
            if i in opened or port in pending or phase==7 or list(map(int,f[3:7]))!=[b,p,write,address] or int(f[7],16)!=data:
                raise ValueError('Bank accepted request/order mismatch')
            opened.add(i);pending[port]=i;expected[i]=(cycle,None if write else memory.get((b,address)))
            if not write and expected[i][1] is None:raise ValueError('Read of uninitialized test word')
            if write:memory[b,address]=data
            totals[0]+=1
        elif kind=='R':
            cycle=int(f[2])
            if pending.get(port)!=i or i in finished or list(map(int,f[3:7]))!=[b,p,write,address] or cycle<=expected[i][0]:
                raise ValueError('Bank response ownership/latency mismatch')
            if not write and int(f[7],16)!=expected[i][1]:raise ValueError(f'Bank read mismatch:bank{b},word{address}')
            del pending[port];finished.add(i);totals[1]+=1;totals[4 if write else 3]+=1
        elif kind=='A':
            if phase!=6 or list(map(int,f[2:]))!=[b,p] or pending.get(port)!=i:raise ValueError('Unexpected bank abort')
            del pending[port];finished.add(i);totals[2]+=1
        else:raise ValueError('Unknown bank record')
    required={r[0] for r in rows if r[1]!=7}
    reads=sum(r[4]==0 for r in rows if r[1]!=7)
    if (opened!=required or finished!=required or pending or resets!=2 or totals!=footer or
        totals!=[len(required),len(required)-8,8,reads,len(required)-8-reads]):raise ValueError('Incomplete bank gate')
    return (f'DILITHIUM STAGE5 BANKS COMPARE PASS:{totals[0]} accepted,{totals[1]} responses,'
            f'{totals[3]} exact92-bit reads,{totals[4]} write acknowledgements,8 reset-aborted acknowledgements;'
            'all4096 words initialized/read across four1024x92-bit banks;8 blocked offers canceled\n')


def verify_bank_store(lines):
    rows,token=check()
    if not lines or lines[0]!='H '+token:raise ValueError('Bank-store capture token')
    jobs={};owners={};regions={};totals=[0]*8;resets=0;invalid=0;footer=None;fault_gate=False
    def slot_for(i):return {1:16,16:1,3:17,17:3}.get(i%64,i%64)
    def packed(r,w):return sum(v<<(23*k) for k,v in enumerate(r['values'][4*w:4*w+4]))
    for line in lines[1:]:
        if footer is not None:raise ValueError('Record after bank-store footer')
        f=line.split();kind=f[0]
        if kind=='F':footer=list(map(int,f[1:]));continue
        if kind=='G':
            if fault_gate or f!=['G','8']:raise ValueError('Missing protocol fault gate')
            fault_gate=True;continue
        if kind=='X':
            if owners:raise ValueError('Bank reset omitted live-job abort')
            regions.clear();resets+=1;continue
        if kind=='L':
            s=int(f[1]);i=regions.get(s)
            if i is None or jobs[i]['done']!='S' or rows[i]['code'] or jobs[i]['read']!=64:
                raise ValueError('Release uncommitted/unread region')
            del regions[s];continue
        if kind=='E':
            s,w=map(int,f[1:]);i=regions.get(s)
            if not 0<=s<64 or not 0<=w<64 or (i is not None and jobs[i]['done']=='S'):
                raise ValueError('Readable region reported as error')
            invalid+=1;continue
        i=int(f[1])
        if not 0<=i<len(rows):raise ValueError('Unknown bank-store job')
        r=rows[i]
        if kind=='J':
            core,s,job_id=map(int,f[2:])
            if i in jobs or core not in (0,1) or core in owners or s in regions or s!=slot_for(i) or job_id!=r['id']:
                raise ValueError('Bank region/context ownership overwrite')
            jobs[i]=dict(core=core,slot=s,n=0,k=0,b=0,read=0,done=None);owners[core]=i;regions[s]=i;totals[0]+=1;continue
        if i not in jobs:raise ValueError('Bank-store event without command')
        j=jobs[i];s=j['slot']
        if kind=='R':
            small=int(all(v<=4 or v>=8_380_413 for v in r['values']))
            if (regions.get(s)!=i or j['done']!='S' or r['code'] or int(f[2])!=s or int(f[3])!=j['read'] or
                j['read']>=64 or int(f[4],16)!=packed(r,j['read']) or
                list(map(int,f[5:]))!=[r['id'],r['mode'],r['param'],int(r['mode']==0),small]):
                raise ValueError('Bank packed readback/metadata mismatch')
            j['read']+=1;totals[7]+=1;continue
        if j['done'] is not None or owners.get(j['core'])!=i or regions.get(s)!=i:
            raise ValueError('Bank traffic after retirement/abort')
        if kind=='W':
            core,index,value,last=int(f[2]),int(f[3]),int(f[4],16),int(f[5])
            if core!=j['core'] or index!=j['n'] or index>=len(r['values']) or value!=r['values'][index] or last!=int(index==255):
                raise ValueError('Bank input coefficient mismatch')
            j['n']+=1;totals[4]+=1
        elif kind=='K':
            if int(f[2])!=s or int(f[3])!=j['k'] or 4*j['k']+4>j['n'] or int(f[4],16)!=packed(r,j['k']):
                raise ValueError('Packed four-lane physical write mismatch')
            j['k']+=1;totals[5]+=1
        elif kind=='B':
            if int(f[2])!=s or int(f[3])!=j['b'] or j['b']>=j['k']:raise ValueError('Bank acknowledgement order/owner')
            j['b']+=1;totals[6]+=1
        elif kind=='S':
            if (r['abort'] or list(map(int,f[2:]))!=[j['core'],r['code']] or j['n']!=len(r['values']) or
                (r['code']==0 and (j['k'],j['b'])!=(64,64))):raise ValueError('Premature bank publication')
            j['done']='S';del owners[j['core']];totals[2 if r['code'] else 1]+=1
            if r['code']:del regions[s]
        elif kind=='A':
            if not r['abort'] or list(map(int,f[2:]))!=[j['core'],j['n']]:raise ValueError('Wrong bank reset abort')
            j['done']='A';del owners[j['core']];totals[3]+=1
        else:raise ValueError('Unknown bank-store record')
    combinations={(j['core'],rows[i]['mode'],rows[i]['param']) for i,j in jobs.items() if not rows[i]['code'] and not rows[i]['abort']}
    if (len(jobs)!=104 or owners or any(j['done'] is None for j in jobs.values()) or totals!=footer or
        totals[:4]!=[104,88,8,8] or totals[7]!=5632 or resets!=5 or invalid!=11 or not fault_gate or len(combinations)!=24 or
        any(j['read']!=64 for i,j in jobs.items() if not rows[i]['code'] and not rows[i]['abort'])):
        raise ValueError('Incomplete connected bank-store gate')
    return (f'DILITHIUM STAGE5 STORE COMPARE PASS:104 jobs,88 complete,8 expected errors,8 reset aborts;'
            f'{totals[4]} exact coefficients,{totals[5]} packed writes,{totals[6]} write acks;'
            '5632 exact92-bit read words=22528 complete coefficients;all64 regions/24 mode-parameter-core combinations;'
            '8 protocol fault kinds contained\n')


@lru_cache(maxsize=1)
def process_bank_program():
    program=[];owners={}
    def emit(kind,op=0,a=0,b=0,dest=0,high=0,aid=0,bid=0,jobid=0,code=0,wait=-1,abort=-1):
        program.append((kind,op,a,b,dest,high,aid,bid,jobid,code,wait,abort))
    def sample(case,region,jobid=None):
        jobid=cases()[case]['id'] if jobid is None else jobid
        emit('S',case,region,jobid=jobid);owners[region]=jobid
    def read(region,invalid=False):emit('R',region,int(invalid))
    def reset():emit('X');owners.clear()
    def ntt(op,a,b,dest):
        jobid=12000+len(program);emit('N',op,a,b,dest,aid=owners[a],bid=owners[b],jobid=jobid)
        owners[dest]=jobid;read(dest)
    def process(op,a,b,dest,high=0,code=0,da=0,db=0,wait=-1,abort=-1):
        jobid=14000+len(program)
        emit('P',op,a,b,dest,high,owners.get(a,0)+da,owners.get(b,0)+db,jobid,code,wait,abort)
        if abort>=0:owners.clear();return
        if code==0:
            if wait>=0:del owners[wait]
            owners[dest]=jobid
            if op==2:owners[high]=jobid
            read(dest)
            if op==2:read(high)
    reset()
    for p in range(3):
        sample(2*p,0);sample(6+2*p,17);sample(7+2*p,18);sample(12+2*p,19)
        process(0,17,18,1);process(1,1,18,2)
        ntt(0,17,17,32);ntt(0,18,18,33);ntt(2,0,32,48)
        process(0,48,48,49);process(1,49,48,50);ntt(1,50,50,51)
        process(0,51,17,52);process(2,52,0,3,4);ntt(0,3,3,34)
        process(1,18,17,5);process(2,19,0,6,7)
        process(0,32,33,4,wait=4);process(2,52,0,8,4,wait=4)
        sample(6+2*((p+1)%3),20)
        process(3,17,18,9,code=4);process(0,17,18,9,code=1,da=1)
        process(0,17,62,9,code=1);process(0,17,18,9,code=1,db=1)
        process(0,32,17,9,code=2);process(0,17,20,9,code=2);process(2,32,0,9,10,code=2)
        process(0,17,18,17,code=3);process(1,17,18,18,code=3)
        process(2,17,0,9,17,code=3);process(2,17,0,9,9,code=3)
        for region in sorted(owners):read(region)
        reset()
    for phase in range(4):
        sample(6,0);read(0)
        process(0 if phase<2 else 2,0,0,1,17,abort=phase)
        read(0,True);read(1,True);read(17,True)
        sample(7,0,cases()[6]['id']);process(2,0,0,1,17);read(0);reset()
    return tuple(program)


def process_bank_artifact(token):
    rows=process_bank_program()
    return f'{token} {len(rows)}\n'+'\n'.join(' '.join(map(str,row)) for row in rows)+'\n'


def verify_process_banks(lines):
    rows,token=check();program=process_bank_program();q=ntt_reference.Q
    if not lines or lines[0]!='H '+token:raise ValueError('Bank process capture token')
    slots={};pending=None;finished=set();read_counts={};reset_steps=set();witness=None;footer=None
    samples=ntts=processes=aborts=values=words=acks=reads=success=reject=inputs=outputs=atomic_seen=0
    def expect(test,message):
        if not test:raise ValueError(message)
    for line in lines[1:]:
        expect(footer is None,'Record after process footer');f=line.split();kind=f[0]
        if kind=='F':footer=list(map(int,f[1:]));continue
        if kind=='G':
            expect(witness is None,'Duplicate process witnesses');witness=list(map(int,f[1:]));continue
        step=int(f[1]);expect(0<=step<len(program),'Invalid program step');r=program[step]
        action,op,a,b,dest,high,aid,bid,jobid,code,wait,abort=r
        if kind=='X':
            expect(pending is None and step not in reset_steps,'Reset without abort/retirement')
            expect(action=='X' or (action=='P' and abort>=0 and step in finished),'Unexpected process reset')
            slots.clear();reset_steps.add(step)
            if action=='X':finished.add(step)
            continue
        if kind in ('J','O','C'):
            expect(pending is None and step not in finished,'Overlapping bank process command')
            p=dict(step=step,kind=action,op=op,id=jobid,code=0,alloc={},expected={},bindings={},commits=set(),
                   loads=0,inputs=0,outputs=0,ntt_outputs=0,wait_released=wait<0,low=[],high=[])
            if kind=='J':
                case,core,region,observedid=map(int,f[2:]);expect(action=='S' and [case,region,observedid]==[op,a,jobid] and core in (0,1),'Sample command mismatch')
                c=rows[case];expect(c['code']==0,'Unexpected bad sample case')
                p['expected'][a]=dict(id=jobid,mode=c['mode'],param=c['param'],domain=int(c['mode']==0),data=tuple(c['values']))
                p['sample_core']=core;samples+=1
            else:
                expected_args=[op,a,b,dest,aid,bid,jobid] if kind=='O' else [op,a,b,dest,high,aid,bid,jobid]
                expect(action==('N' if kind=='O' else 'P') and list(map(int,f[2:]))==expected_args,'Compute command mismatch')
                ar=slots.get(a);br=slots.get(b);binary=(op==2 if action=='N' else op<2)
                status=0
                if action=='P' and op==3:status=4
                elif dest==a or (binary and dest==b) or (action=='P' and op==2 and (high==a or high==dest)):status=3
                elif ar is None or ar['state']!='complete' or ar['id']!=aid or (binary and (br is None or br['state']!='complete' or br['id']!=bid)):status=1
                elif action=='N':
                    if ((op in (0,3) and ar['domain']) or (op in (1,2) and not ar['domain']) or
                        (op==3 and any(4<x<q-4 for x in ar['data'])) or
                        (op==2 and (not br['domain'] or ar['param']!=br['param']))):status=2
                elif (op==2 and ar['domain']) or (binary and (ar['domain']!=br['domain'] or ar['param']!=br['param'])):status=2
                expect(status==code,'Prepared process decision disagrees with independent model');p['code']=status
                if status==0:
                    p['a']=ar['data'];p['b']=br['data'] if binary else ();p['sources']={a,b} if binary else {a}
                    if action=='N':data=arithmetic_result(op,p['a'],p['b']);domain=int(op!=1)
                    elif op<2:
                        data=tuple((x+y if op==0 else x-y)%q for x,y in zip(p['a'],p['b'],strict=True));domain=ar['domain']
                    else:
                        highs=tuple((x+4095)//8192 for x in p['a']);lows=tuple(x-8192*h for x,h in zip(p['a'],highs,strict=True))
                        p['low']=lows;p['high']=highs;data=tuple(x%q for x in lows);domain=0
                        p['expected'][high]=dict(id=jobid,mode=ar['mode'],param=ar['param'],domain=0,data=highs)
                    p['expected'][dest]=dict(id=jobid,mode=ar['mode'],param=ar['param'],domain=domain,data=data)
                if action=='N':ntts+=1
                else:processes+=1
            pending=p;continue
        if kind in ('R','E'):
            expect(pending is None and action=='R','Public read while process owns bank')
            region=int(f[2]);expect(region==op,'Read region mismatch');s=slots.get(region)
            if kind=='E':
                expect(a==1 and s is None and step not in finished,'Readable/reset region incorrectly rejected');finished.add(step);continue
            word=int(f[3]);expect(a==0 and s is not None and s['state']=='complete' and word==read_counts.get(step,0) and word<64,'Word read order/publication mismatch')
            expected=sum(s['data'][4*word+lane]<<(23*lane) for lane in range(4))
            metadata=[s['id'],s['mode'],s['param'],s['domain'],int(all(x<=4 or x>=q-4 for x in s['data']))]
            expect(int(f[4],16)==expected and list(map(int,f[5:]))==metadata,'Bank process stored data/metadata mismatch')
            read_counts[step]=word+1;s['reads']+=1;reads+=1
            if word==63:finished.add(step)
            continue
        if kind=='L':
            region=int(f[2]);s=slots.get(region)
            expect(pending is not None and pending['step']==step and wait==region and not pending['wait_released'] and
                   region not in pending['sources'] and s is not None and s['state']=='complete' and s['reads']>=64,
                   'Released source/incomplete/unread/wrong waiting destination')
            del slots[region];pending['wait_released']=True;continue
        expect(pending is not None and pending['step']==step,'Process event without accepted command');p=pending
        if kind=='Y':
            expect(action=='P' and op==2 and p['code']==0 and dest in p['commits'] and
                   list(map(int,f[2:]))==[dest,high,0,0,1,0],'Power2Round partial publication visible/wrong witness')
            atomic_seen+=1;continue
        if kind=='V':
            core,region,vid,mode,param,domain=map(int,f[2:]);expected=p['expected'].get(region)
            expect(p['code']==0 and core in (0,1) and core not in p['bindings'] and region not in slots and expected is not None and
                   [vid,mode,param,domain]==[expected['id'],expected['mode'],expected['param'],expected['domain']],'Wrong process allocation/overwrite')
            if action=='P':expect(core==int(op==2 and region==high),'Power2Round destination/core mismatch')
            if action=='N':expect(core==0,'NTT result allocated wrong packer')
            if action=='S':expect(core==p['sample_core'],'Sample packer changed core')
            slots[region]=dict(**expected,state='writing',count=0,packed=0,acks=0,reads=0)
            p['bindings'][core]=region;p['alloc'][region]=core;continue
        if kind=='W':
            core,index=int(f[2]),int(f[3]);region=p['bindings'].get(core);s=slots.get(region)
            expect(s is not None and s['state']=='writing' and index==s['count'] and index<256 and
                   int(f[4],16)==s['data'][index] and int(f[5])==int(index==255),'Process coefficient write/tag/value/order mismatch')
            s['count']+=1;values+=1;continue
        if kind in ('P','Q'):
            region,word=map(int,f[2:4]);s=slots.get(region)
            expect(region in p['alloc'] and s is not None and s['state']=='writing' and word<64,'Packed process event without owner')
            if kind=='P':
                expected=sum(s['data'][4*word+lane]<<(23*lane) for lane in range(4))
                expect(word==s['packed'] and s['count']>=4*(word+1) and int(f[4],16)==expected,'Packed process value/address/order mismatch')
                s['packed']+=1;words+=1
            else:
                expect(word==s['acks'] and word<s['packed'],'Packed acknowledgement without prior write');s['acks']+=1;acks+=1
            continue
        if kind=='U':
            core=int(f[2]);region=p['bindings'].get(core);s=slots.get(region)
            expect(s is not None and s['count']==256 and s['packed']==64 and s['acks']==64 and region not in p['commits'],'Premature/duplicate process publication')
            p['commits'].add(region);continue
        if kind=='T':
            region,index=int(f[2]),int(f[3]);value=int(f[4],16);n=p['loads'];source=a if n<256 else b
            data=p['a'] if n<256 else p['b']
            expect(action=='N' and p['code']==0 and data and n<(512 if op==2 else 256) and region==source and index==n%256 and value==data[index],'Banked NTT DMA mismatch')
            p['loads']+=1;continue
        if kind=='N':
            index=int(f[2]);expect(action=='N' and p['code']==0 and index==p['ntt_outputs'] and index<256 and
                p['loads']==(512 if op==2 else 256) and int(f[3],16)==p['expected'][dest]['data'][index] and
                int(f[4])==int(index==255),'Chained NTT output mismatch')
            p['ntt_outputs']+=1;continue
        if kind=='I':
            index=int(f[2]);expect(action=='P' and p['code']==0 and index==p['inputs'] and index<256 and
                int(f[3],16)==p['a'][index] and (op==2 or int(f[4],16)==p['b'][index]),'Process DMA input mismatch')
            p['inputs']+=1;inputs+=1;continue
        if kind=='K':
            index=int(f[2]);expect(action=='P' and p['code']==0 and index==p['outputs'] and index<p['inputs'],'Process output without ordered input')
            residue=p['expected'][dest]['data'][index] if op<2 else 0
            h=p['high'][index] if op==2 else 0;l=p['low'][index] if op==2 else 0;t0=4096-l if op==2 else 0
            expect(list(map(int,f[3:6]))==[0,op,jobid] and int(f[6],16)==residue and
                   list(map(int,f[7:]))==[h,l,t0,int(index==255)],'Process arithmetic/rounding/tag mismatch')
            p['outputs']+=1;outputs+=1;continue
        if kind in ('S','D'):
            if kind=='S':expect(action=='S' and list(map(int,f[2:]))==[jobid,0],'Sample retirement mismatch')
            else:
                expect(f[2]==action and list(map(int,f[3:]))==[p['code'],jobid,dest,high],'Process retirement metadata mismatch')
                if p['code']==0:
                    expect(p['wait_released'],'Busy destination was silently overwritten')
                    expect((action=='N' and p['ntt_outputs']==256) or (action=='P' and p['inputs']==256 and p['outputs']==256),'Incomplete arithmetic completion')
                    if action=='P':success+=1
                else:
                    expect(not p['alloc'] and p['inputs']==0 and p['outputs']==0,'Rejected process had side effects');reject+=1
            expect(set(p['expected'])==p['commits'],'Completion before every destination committed')
            for region in p['alloc']:slots[region]['state']='complete'
            finished.add(step);pending=None;continue
        if kind=='A':
            phase,seen=map(int,f[2:]);expect(action=='P' and phase==abort and phase in range(4) and seen==p['inputs'],'Wrong process reset target')
            expect((phase==0 and seen==0) or (phase==1 and seen==9) or
                   (phase==2 and seen==9 and slots[dest]['count']==9 and slots[high]['count']==8) or
                   (phase==3 and p['commits']=={dest} and p['outputs']==256),'Reset did not reach required process boundary')
            aborts+=1;finished.add(step);pending=None;continue
        raise ValueError('Unknown bank process record:'+kind)
    expect(finished==set(range(len(program))) and pending is None and not slots,'Missing/unfinished process program actions')
    expect((samples,ntts,processes,aborts,success,reject)==(23,15,71,4,34,33),'Incomplete process campaign')
    expect(footer==[samples,ntts,processes,aborts,values,words,reads],'Process footer differs from observed ledger')
    expect(witness==[36,188,4,atomic_seen] and atomic_seen>=6,'Missing process ownership/atomicity witnesses')
    return (f'DILITHIUM STAGE5G BANK PROCESS COMPARE PASS:23 sample jobs,15 NTT commands,71 process commands;'
            f'34 process successes,33 expected rejections,4 reset aborts;{inputs} process inputs,{outputs} exact process outputs;'
            f'{values} coefficient writes,{words} packed writes,{acks} acknowledgements,{reads} exact92-bit reads\n')


@lru_cache(maxsize=1)
def row_cases():
    result=[]
    for p,(k,l) in enumerate(((4,4),(6,5),(8,7))):
        xi=hashlib.sha256(f'banked-row-level-{p}'.encode()).digest()
        material=hashlib.shake_256(xi+bytes((k,l))).digest(128)
        for mode,row,col in [(1,0,j) for j in range(l)]+[(0,i,j) for i in range(2) for j in range(l)]:
            message=(material[32:96]+col.to_bytes(2,'little')) if mode else material[:32]+bytes((col,row))
            stream=(hashlib.shake_128 if mode==0 else hashlib.shake_256)(message).digest(4096)
            values,_=reference.sample(mode,p,stream);i=len(result)
            result.append(dict(case=i,id=2000+i,mode=mode,param=p,row=row,col=col,message=message,values=tuple(values)))
    assert len(result)==48
    return result


def row_sample_artifact(token):
    return f'{token} 48\n'+'\n'.join(f"{c['case']} {c['id']} {c['mode']} {c['param']} {c['row']} {c['col']} {len(c['message'])} {c['message'].hex()}" for c in row_cases())+'\n'


@lru_cache(maxsize=6)
def row_expected(p,row):
    table={(c['mode'],c['param'],c['row'],c['col']):c['values'] for c in row_cases()}
    total=[0]*256
    for j in range((4,5,7)[p]):
        product=arithmetic_result(2,table[0,p,row,j],arithmetic_result(0,table[1,p,0,j]))
        total=[(x+y)%ntt_reference.Q for x,y in zip(total,product,strict=True)]
    return arithmetic_result(1,tuple(total))


def row_expected_artifact(token):
    return f'{token} 6\n'+'\n'.join(f'{p} {row} '+' '.join(f'{v:06x}' for v in row_expected(p,row)) for p in range(3) for row in range(2))+'\n'


def row_scenarios():
    return sum(([(p,0,-1,-1)]+[(p,1,v,-1) for v in range(9)]+[(p,1,-1,-1)] for p in range(3)),[])+sum(([(0,0,-1,phase),(0,1,-1,-1)] for phase in range(7)),[])


def verify_rows(lines):
    _,token=check();q=ntt_reference.Q;fixtures=row_cases();scenarios=row_scenarios()
    if not lines or lines[0]!='H '+token:raise ValueError('Row capture freshness')
    lookup={(c['mode'],c['param'],c['row'],c['col']):c for c in fixtures}
    slots={};child=None;row=None;serial=0;runs=0;footer=None;witness=None
    samples=ntts=processes=good=bad=aborts=values=words=acks=reads=rewrites=readbacks=0
    completed=set();public_reads={};partial=None
    def require(ok,message):
        if not ok:raise ValueError(message)
    def meta(s):return [s['id'],s['mode'],s['param'],s['domain']]
    for line in lines[1:]:
        require(footer is None,'Record after row footer');f=line.split();kind=f[0]
        if kind=='F':footer=list(map(int,f[1:]));continue
        if kind=='G':require(witness is None,'Duplicate row witnesses');witness=list(map(int,f[1:]));continue
        if kind=='B':
            require(row is None and child is None and runs<len(scenarios),'Overlapping/extra row')
            run,param,index,acc,tmp,out,rid=map(int,f[1:8]);p,expected_row,variant,phase=scenarios[runs];l=(4,5,7)[p]
            require(run==runs and param==(3 if variant==0 else p) and index==((4,6,8)[p] if variant==1 else expected_row) and
                acc==(48 if variant==2 else 1 if variant==3 else 16) and [tmp,out,rid]==[17,18,5000+16*p],'Wrong row command/scenario')
            descriptors=[list(map(int,f[8+4*j:12+4*j])) for j in range(7)]
            require(len(f)==36,'Wrong row descriptor length')
            for j in range(7):
                expected=[0,0,0,0]
                if j<l:
                    a=lookup[0,p,expected_row,j];s=lookup[1,p,0,j];expected=[48+j,a['id'],32+j,3000+s['case']]
                    if j==0:
                        if variant==4:expected[1]^=1
                        if variant==5:expected[3]^=1
                        if variant==6:expected[:2]=[62,lookup[0,(p+1)%3,0,0]['id']]
                        if variant==7:expected[2:]=[1,s['id']]
                        if variant==8:expected[:2]=[61,0]
                require(descriptors[j]==expected,'Wrong row operand descriptor')
            code=0
            if param==3 or index>=(4,6,8)[param]:code=4
            elif len({acc,tmp,out})!=3 or any(r in (acc,tmp,out) for d in descriptors[:l] for r in (d[0],d[2])) or any(r in slots for r in (acc,tmp,out)):code=3
            else:
                for a,aid,s,sid in descriptors[:l]:
                    ar=slots.get(a);sr=slots.get(s)
                    if ar is None or sr is None or ar['state']!='complete' or sr['state']!='complete' or ar['id']!=aid or sr['id']!=sid:code=1;break
                    if not ar['domain'] or not sr['domain'] or ar['param']!=param or sr['param']!=param:code=2;break
            expected_code=4 if variant in (0,1) else 3 if variant in (2,3) else 1 if variant in (4,5,8) else 2 if variant in (6,7) else 0
            require(code==expected_code,'Row eligibility differs from scenario')
            row=dict(run=run,p=p,index=expected_row,l=l,desc=descriptors,acc=acc,tmp=tmp,out=out,id=rid,code=code,
                     phase='error' if code else 'pwm',column=0,terms=0,abort=phase,acc_id=0)
            runs+=1;continue
        if kind=='DROW':
            require(row is not None and child is None,'Row completion without owner');r=row
            require(list(map(int,f[1:]))==[r['run'],r['code'],r['id'],r['out'],0 if r['code'] else r['l']],'Row completion identity/count mismatch')
            if r['code']==0:
                require(r['abort']<0 and r['phase']=='report' and r['acc'] not in slots and r['tmp'] not in slots and
                    slots[r['out']]['data']==row_expected(r['p'],r['index']),'Incomplete/incorrect whole row')
                good+=1;completed.add((r['p'],r['index']))
            else:require(r['phase']=='error','Rejected row changed engines');bad+=1
            row=None;continue
        if kind=='Z':
            require(row is not None and child is None,'Row abort without retirement');r=row;phase=r['abort']
            require(list(map(int,f[1:]))==[r['run'],phase] and phase in range(7),'Wrong row abort phase')
            if phase==0:require(r['terms']==0 and r['phase']=='pwm' and partial is None,'Validation reset wrong boundary')
            elif phase in (1,5):require(partial is not None and partial['kind']=='N' and partial['outputs']==0 and
                partial['loads']==(512 if phase==1 else 256),'Engine reset wrong boundary')
            elif phase==2:require(r['terms']==1 and r['phase']=='pwm' and partial is None,'First accumulator reset wrong boundary')
            elif phase==3:require(partial is not None and partial['kind']=='P' and partial['inputs']==9 and partial['outputs']==8 and
                slots[r['acc']]['count']==8,'Destructive update reset wrong boundary')
            elif phase==4:require(r['terms']==2 and r['phase']=='free_scratch' and partial is None,'Scratch-release reset wrong boundary')
            else:require(r['terms']==4 and r['phase']=='report' and slots[r['out']]['data']==row_expected(0,0),'Held row completion reset wrong boundary')
            row=None;partial=None;aborts+=1;continue
        if kind=='X':
            require(row is None and child is None,'Reset lacks abort/retirement');slots.clear();public_reads.clear();continue
        if kind=='L':
            region,internal=map(int,f[1:]);s=slots.get(region)
            require(child is None and s is not None and s['state']=='complete','Release of active/invalid polynomial')
            if internal:
                require(row is not None and row['code']==0,'Unowned row release')
                if row['phase']=='free_scratch':
                    require(region==row['tmp'],'Row released retained operand instead of scratch')
                    if row['column']==row['l']-1:row['phase']='inverse'
                    else:row['column']+=1;row['phase']='pwm'
                else:require(row['phase']=='free_acc' and region==row['acc'],'Wrong accumulator release');row['phase']='report'
            else:require(row is None,'External release during row')
            del slots[region];continue
        if kind in ('R','E'):
            require(row is None and child is None and int(f[1])==serial-1,'Public read during row/child')
            region=int(f[2]);s=slots.get(region)
            if kind=='E':require(s is None,'Live region rejected');continue
            word=int(f[3]);require(s is not None and s['state']=='complete' and word==public_reads.get(region,0),'Public word order/ownership')
            expected=sum(s['data'][4*word+j]<<(23*j) for j in range(4))
            require(int(f[4],16)==expected and list(map(int,f[5:]))==meta(s)+[int(all(x<=4 or x>=q-4 for x in s['data']))],'Whole-row readback mismatch')
            public_reads[region]=(word+1)%64;reads+=1;continue
        if kind in ('J','O','C'):
            require(child is None and int(f[1])==serial,'Overlapping/out-of-order row child');serial+=1
            c=dict(serial=serial-1,expected={},bindings={},commits=set(),inputs=0,outputs=0,loads=0,memory_reads=0)
            if kind=='J':
                case,core,region,jid=map(int,f[2:]);fixture=fixtures[case]
                require(row is None and jid==fixture['id'] and core in (0,1),'Wrong fixture sampling command')
                c.update(kind='S',id=jid,core=core)
                c['expected'][region]=dict(id=jid,mode=fixture['mode'],param=fixture['param'],domain=int(fixture['mode']==0),data=fixture['values'],case=case)
                samples+=1
            else:
                if kind=='O':op,a,b,dest,aid,bid,jid=map(int,f[2:]);inplace=False
                else:op,a,b,dest,high,aid,bid,jid,inplace=map(int,f[2:]);require(high==0 and op==0 and inplace==1,'Unexpected row process operation')
                ar=slots.get(a);br=slots.get(b);binary=kind=='C' or op==2
                require(ar is not None and ar['state']=='complete' and ar['id']==aid and
                    (not binary or (br is not None and br['state']=='complete' and br['id']==bid and ar['param']==br['param'])),'Wrong child source owner')
                if row is not None:
                    r=row;j=r['column'];require(r['code']==0,'Rejected row issued arithmetic')
                    if kind=='C':
                        require(r['phase']=='add' and [a,b,dest,aid,bid,jid]==[r['acc'],r['tmp'],r['acc'],r['acc_id'],r['id']+2+2*j,r['id']+3+2*j],'Row ADD schedule mismatch')
                    elif op==2:
                        require(r['phase']=='pwm' and [a,aid,b,bid]==r['desc'][j] and dest==(r['acc'] if j==0 else r['tmp']) and
                            jid==r['id']+(1 if j==0 else 2+2*j),'Row PWM schedule mismatch')
                    else:require(r['phase']=='inverse' and op==1 and [a,dest,aid,jid]==[r['acc'],r['out'],r['acc_id'],r['id']],'Row inverse schedule mismatch')
                else:require(kind=='O' and op in (0,3) and ar['mode']==1 and not ar['domain'] and
                    (op!=3 or all(x<=4 or x>=q-4 for x in ar['data'])) and
                    a==fixtures[ar['case']]['col']+1 and dest==a+31,'Unexpected external row operation')
                if kind=='C':require(ar['domain']==br['domain'] and dest==a,'Invalid in-place ADD domain/alias');data=tuple((x+y)%q for x,y in zip(ar['data'],br['data'],strict=True));domain=ar['domain'];processes+=1;rewrites+=1
                else:
                    require((op in (0,3) and not ar['domain']) or (op==1 and ar['domain']) or (op==2 and ar['domain'] and br['domain']),'Wrong NTT child domain')
                    data=arithmetic_result(op,ar['data'],br['data'] if op==2 else ());domain=int(op!=1);ntts+=1
                c.update(kind='P' if kind=='C' else 'N',op=op,a=a,b=b,dest=dest,aid=aid,bid=bid,id=jid,old_a=ar['data'],old_b=br['data'] if binary else (),inplace=bool(inplace))
                c['expected'][dest]=dict(id=jid,mode=ar['mode'],param=ar['param'],domain=domain,data=data,case=ar['case'])
            child=c;continue
        require(child is not None and int(f[1])==child['serial'],'Row child event has no owner');c=child
        if kind=='V':
            core,region,jid,mode,param,domain=map(int,f[2:]);expected=c['expected'].get(region)
            require(core in (0,1) and core not in c['bindings'] and expected is not None and [jid,mode,param,domain]==meta(expected),'Wrong row destination allocation')
            if c.get('inplace'):require(region==c['a'] and slots[region]['state']=='complete','In-place destination ownership lost')
            else:require(region not in slots,'Row overwrote retained polynomial')
            slots[region]=dict(**expected,state='writing',count=0,packed=0,acks=0);public_reads.pop(region,None);c['bindings'][core]=region;continue
        if kind=='W':
            core,index=int(f[2]),int(f[3]);s=slots.get(c['bindings'].get(core))
            require(s is not None and s['state']=='writing' and index==s['count'] and index<256 and int(f[4],16)==s['data'][index] and int(f[5])==int(index==255),'Row scalar write mismatch')
            s['count']+=1;values+=1;continue
        if kind in ('P','Q'):
            region,word=map(int,f[2:4]);s=slots.get(region)
            require(region in c['bindings'].values() and s is not None and s['state']=='writing' and word<64,'Unowned row packed write/ack')
            if kind=='P':
                require(word==s['packed'] and s['count']>=4*(word+1) and int(f[4],16)==sum(s['data'][4*word+j]<<(23*j) for j in range(4)),'Row packed word mismatch')
                s['packed']+=1;words+=1
            else:require(word==s['acks'] and word<s['packed'],'Row ack without write');s['acks']+=1;acks+=1
            continue
        if kind=='U':
            core=int(f[2]);region=c['bindings'].get(core);s=slots.get(region)
            require(s is not None and s['count']==256 and s['packed']==64 and s['acks']==64 and region not in c['commits'],'Row premature commit')
            c['commits'].add(region);continue
        if kind=='M':
            region,word=int(f[2]),int(f[3]);n=c['memory_reads'];expected_region=c['a'] if n%2==0 else c['b'];data=c['old_a'] if n%2==0 else c['old_b']
            require(c['kind']=='P' and n<128 and region==expected_region and word==n//2 and
                int(f[4],16)==sum(data[4*word+j]<<(23*j) for j in range(4)) and
                int(f[5])==(c['id'] if region==c['dest'] else c['bid']) and int(f[6])==(4*word if region==c['dest'] else 256),'Read-before-overwrite word/owner/order violated')
            c['memory_reads']+=1;readbacks+=1;continue
        if kind=='I':
            index=int(f[2]);require(c['kind']=='P' and index==c['inputs'] and index<256 and c['memory_reads']==2*(index//4+1) and
                int(f[3],16)==c['old_a'][index] and int(f[4],16)==c['old_b'][index],'Row ADD cache/input mismatch')
            c['inputs']+=1;continue
        if kind=='K':
            index=int(f[2]);require(c['kind']=='P' and index==c['outputs'] and index<c['inputs'] and
                list(map(int,f[3:6]))==[0,0,c['id']] and int(f[6],16)==c['expected'][c['dest']]['data'][index] and
                list(map(int,f[7:]))==[0,0,0,int(index==255)],'Row ADD arithmetic mismatch')
            c['outputs']+=1;continue
        if kind=='T':
            region,index=int(f[2]),int(f[3]);n=c['loads'];data=c['old_a'] if n<256 else c['old_b']
            require(c['kind']=='N' and data and n<(512 if c['op']==2 else 256) and region==(c['a'] if n<256 else c['b']) and
                index==n%256 and int(f[4],16)==data[index],'Row NTT DMA mismatch');c['loads']+=1;continue
        if kind=='N':
            index=int(f[2]);require(c['kind']=='N' and index==c['outputs'] and index<256 and
                c['loads']==(512 if c['op']==2 else 256) and int(f[3],16)==c['expected'][c['dest']]['data'][index] and int(f[4])==int(index==255),'Row NTT output mismatch')
            c['outputs']+=1;continue
        if kind in ('S','D'):
            if kind=='S':require(c['kind']=='S' and list(map(int,f[2:]))==[c['id'],0],'Row sampling status mismatch')
            else:
                require(f[2]==c['kind'] and list(map(int,f[3:]))==[0,c['id'],c['dest'],0] and c['outputs']==256,'Row child completion mismatch')
                if c['kind']=='P':require(c['inputs']==256 and c['memory_reads']==128,'Incomplete row update')
            require(set(c['expected'])==c['commits'],'Row child retired without durable commit')
            for region in c['bindings'].values():slots[region]['state']='complete'
            if row is not None:
                r=row
                if c['kind']=='P':r['acc_id']=c['id'];r['terms']+=1;r['phase']='free_scratch'
                elif c['op']==1:r['phase']='free_acc'
                elif r['column']==0:r['acc_id']=c['id'];r['terms']=1;r['column']=1;r['phase']='pwm'
                else:r['phase']='add'
            child=None;continue
        if kind=='A':require(row is not None and row['abort']>=0,'Unexpected child abort');partial=c;child=None;continue
        raise ValueError('Unknown row event:'+kind)
    require(footer==[samples,ntts,processes,good,bad,aborts,values,words,reads] and
        [samples,ntts,processes,good,bad,aborts]==[163,161,55,13,27,7] and runs==47 and completed=={(p,i) for p in range(3) for i in range(2)} and
        row is None and child is None and not slots and witness==[160,4] and rewrites==55,'Incomplete whole-row campaign')
    return (f'DILITHIUM STAGE5H ROW COMPARE PASS:13 complete rows,27 rejections,7 reset aborts;'
        f'163 sampled jobs,161 NTT commands,55 in-place ADDs;{values} scalar writes,{words} packed writes,{acks} acks;'
        f'{reads} exact92-bit public reads,{readbacks} read-before-overwrite words;levels2/3/5 and retained-source reuse\n')



def seed_input_artifact(token):
    return f'{token} 3\n'+''.join(f"{p} {int.from_bytes(hashlib.sha256(f'banked-row-level-{p}'.encode()).digest(),'little'):064x}\n" for p in range(3))


def verify_seed_rows(lines):
    """Validate seed ownership and the real absorption stream before row checks."""
    retained=None;param=0;pending=None;filtered=[];seeds=samples=errors=raw_bytes=formatted=0
    negative=[];levels=set()
    def require(ok,message):
        if not ok:raise ValueError('Seed row: '+message)
    for line in lines:
        f=line.split();kind=f[0]
        if kind=='SC':
            require(pending is None,'Overlapping source command')
            op,p,jid,nonce,row,col,region=map(int,f[1:8]);xi=int(f[8],16).to_bytes(32,'little')
            require(xi==(hashlib.sha256(f'banked-row-level-{p}'.encode()).digest() if p<3 else bytes(32)),'Wrong xi input')
            k,l=((4,4),(6,5),(8,7),(0,0))[p]
            code=0
            if op==0:retained=None;code=3 if p==3 else 0
            elif op==3:code=3
            elif retained is None:code=1
            elif p!=param:code=2
            elif (op==1 and (row>=k or col>=l)) or (op==2 and nonce>=k+l):code=3
            message=xi+bytes((k,l)) if op==0 else (
                (retained[:32]+bytes((col,row))) if op==1 and code==0 else
                (retained[32:96]+nonce.to_bytes(2,'little')) if op==2 and code==0 else b'')
            pending=dict(op=op,p=p,id=jid,region=region,code=code,message=message,
                         words=bytearray(),raw=bytearray(),request=False,ended=False,sample=False,status=False)
        elif kind=='SR':
            c=pending;require(c is not None and c['op']==0 and c['code']==0 and not c['request'],'Unowned/duplicate raw request')
            jid,core,mode,length,outlen=map(int,f[1:])
            require((jid,mode,length,outlen)==(c['id'],1,34,128) and core in (0,1),'Raw descriptor metadata')
            c['core']=core;c['request']=True
        elif kind in ('SI','SF'):
            c=pending;require(c is not None and c['code']==0,'Absorption without successful command')
            require((kind=='SI' and c['op']==0 and c['request']) or (kind=='SF' and c['op'] in (1,2) and c['sample']),'Wrong absorption route')
            word=int(f[1],16).to_bytes(8,'little');offset=len(c['words'])
            require(offset<len(c['message']),'Surplus absorption word')
            require(word==c['message'][offset:offset+8].ljust(8,b'\0'),'Incorrect seed/nonce/byte ordering')
            c['words'].extend(word)
        elif kind=='SO':
            c=pending;require(c is not None and c['op']==0 and c['request'] and not c['ended'],'Unowned seed output')
            require(list(map(int,f[1:4]))==[c['id'],c['core'],16],'Seed output identity/length')
            data=int(f[4],16).to_bytes(16,'little');offset=len(c['raw'])
            expected=hashlib.shake_256(c['message']).digest(128)
            require(offset<128 and data==expected[offset:offset+16],'Seed SHAKE mismatch')
            c['raw'].extend(data);raw_bytes+=16
        elif kind=='SE':
            c=pending;require(c is not None and c['request'] and not c['ended'] and len(c['raw'])==128,'Early/duplicate seed completion')
            require(list(map(int,f[1:]))==[c['id'],c['core']],'Seed completion owner')
            c['ended']=True
        elif kind=='SD':
            c=pending;require(c is not None,'Completion without source command')
            jid,code,valid,p=map(int,f[1:5])
            require((jid,code)==(c['id'],c['code']),'Source completion identity/code')
            if code==0:
                require(bytes(c['words'])==c['message'].ljust(8*((len(c['message'])+7)//8),b'\0'),'Incomplete absorption')
                if c['op']==0:
                    require(c['ended'] and len(c['raw'])==128,'Seed published before full hash retirement')
                    retained=bytes(c['raw']);param=c['p'];seeds+=1;levels.add(param)
                else:
                    require(c['sample'] and c['status'],'Sampling completion before memory publication')
                    samples+=1;formatted+=len(c['words'])//8
            else:
                require(not c['request'] and not c['sample'] and not c['words'] and not c['raw'],'Rejected source command had side effects')
                errors+=1;negative.append(jid)
                if c['op']==0:param=c['p']
            require((valid,p)==(int(retained is not None),param),'Retained seed validity/level')
            material=bytes(128) if retained is None else retained
            require([int(f[5],16),int(f[6],16),int(f[7],16)]==[int.from_bytes(material[:32],'little'),int.from_bytes(material[32:96],'little'),int.from_bytes(material[96:],'little')],'Retained rho/rho-prime/K mismatch')
            pending=None
        else:
            if kind=='J':
                c=pending;require(c is not None and c['op'] in (1,2) and c['code']==0 and not c['sample'],'Unowned sample descriptor')
                fixture=row_cases()[int(f[2])]
                require(int(f[5])==c['id'] and int(f[4])==c['region'] and fixture['message']==c['message'],'Seed/sample/region binding')
                c['sample']=True
            if kind=='S':
                c=pending;require(c is not None and c['sample'] and not c['status'] and list(map(int,f[2:]))==[c['id'],0],'Unowned/duplicate sampler retirement')
                c['status']=True
            if kind=='X':
                require(pending is None,'Source reset without explicit abort')
                retained=None;param=0
            filtered.append(line)
    require(pending is None and samples==163 and errors==7 and negative==[6100,6101,6102,6104,6105,6106,6107] and levels=={0,1,2},'Incomplete seed/source campaign')
    message=verify_rows(filtered)
    return (message+f'DILITHIUM STAGE5I SEED ROW COMPARE PASS:{seeds} seed expansions,{raw_bytes} exact SHAKE bytes;'
            f'{samples} RTL-formatted sampling jobs,{formatted} absorption words,7 rejected commands;retained rho/rho-prime/K match hashlib\n')


def compare(stage=2,unit='process'):
    if stage==5 and unit in ('row','seed_row'):
        lines=(HERE/f'stage5_{unit}_outputs.txt').read_text().splitlines()
        message=verify_seed_rows(lines) if unit=='seed_row' else verify_rows(lines)
        # Separate coefficient-domain schoolbook check of each reference row.
        table={(c['mode'],c['param'],c['row'],c['col']):c['values'] for c in row_cases()}
        for p in range(3):
            for row in range(2):
                total=[0]*256
                for j in range((4,5,7)[p]):
                    product=ntt_reference.schoolbook(arithmetic_result(1,table[0,p,row,j]),table[1,p,0,j])
                    total=[(x+y)%ntt_reference.Q for x,y in zip(total,product,strict=True)]
                if tuple(total)!=row_expected(p,row):raise ValueError('Whole-row schoolbook mismatch')
        accepted=[s.split() for s in lines if s.startswith('I ')]
        oracle=subprocess.run([str(HERE/'reference_build/process_reference.exe')],
            input=''.join(f'0 {int(f[3],16)} {int(f[4],16)}\n' for f in accepted),
            check=True,capture_output=True,text=True).stdout.splitlines()
        if len(oracle)!=len(accepted):raise ValueError('C row ADD count')
        golden={(int(f[1]),int(f[2])):list(map(int,r.split())) for f,r in zip(accepted,oracle,strict=True)}
        completed=0
        for line in lines:
            if not line.startswith('K '):continue
            f=line.split()
            if [int(f[3]),int(f[6],16),*map(int,f[7:10])]!=golden[int(f[1]),int(f[2])]:raise ValueError('C row ADD mismatch')
            completed+=1
        message+=f'ROW_SCHOOLBOOK_PASS:6 independent full reference rows;C_ROW_ADD_PASS:{len(accepted)} inputs,{completed} completed results\n'
        (HERE/f'stage5_{unit}_compare.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='bank_process':
        lines=(HERE/'stage5_process_banks_outputs.txt').read_text().splitlines()
        message=verify_process_banks(lines)
        accepted=[line.split() for line in lines if line.startswith('I ')]
        stimuli=''.join(f'{process_bank_program()[int(f[1])][1]} {int(f[3],16)} {int(f[4],16)}\n' for f in accepted)
        oracle=subprocess.run([str(HERE/'reference_build/process_reference.exe')],input=stimuli,check=True,capture_output=True,text=True).stdout.splitlines()
        if len(oracle)!=len(accepted):raise ValueError('C bank process count')
        expected={(int(f[1]),int(f[2])):list(map(int,result.split())) for f,result in zip(accepted,oracle,strict=True)}
        completed=0
        for line in lines:
            if not line.startswith('K '):continue
            f=line.split();actual=[int(f[3]),int(f[6],16),*map(int,f[7:10])]
            if actual!=expected[(int(f[1]),int(f[2]))]:raise ValueError('C bank process arithmetic mismatch')
            completed+=1
        c_message=f'C_BANK_PROCESS_PASS:{len(accepted)} accepted operands,{completed} exact completed arithmetic results\n'
        (HERE/'stage5_process_banks_c_reference.log').write_text(c_message)
        message+=c_message
        (HERE/'stage5_process_banks_compare.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='bank_ntt':
        message=verify_ntt((HERE/'stage5_ntt_banks_outputs.txt').read_text().splitlines(),banked=True)
        (HERE/'stage5_ntt_banks_compare.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='bank_store':
        message=verify_bank_store((HERE/'stage5_store_outputs.txt').read_text().splitlines())
        (HERE/'stage5_store_compare.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='bank_memory':
        message=verify_bank_memory((HERE/'stage5_banks_outputs.txt').read_text().splitlines())
        (HERE/'stage5_banks_compare.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='shared_hash':
        message=verify_shared_hash((HERE/'stage5_shared_outputs.txt').read_text().splitlines())
        (HERE/'stage5_shared_compare.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='hash_format':
        message=verify_hash_format((HERE/'stage5_hash_outputs.txt').read_text().splitlines())
        (HERE/'stage5_hash_compare.log').write_text(message);print(message,end='');return
    message={2:verify,3:verify_memory,4:verify_ntt,5:verify_process}[stage]((HERE/f'stage{stage}_outputs.txt').read_text().splitlines())
    (HERE/f'stage{stage}_compare.log').write_text(message);print(message,end='')


def selftest(stage=2,unit='process'):
    if stage==5 and unit=='seed_row':
        original=(HERE/'stage5_seed_row_outputs.txt').read_text().splitlines();verify_seed_rows(original);trials=[]
        for kind,column,base in [('SC',8,16),('SR',4,10),('SI',1,16),('SO',4,16),('SO',1,10),('SE',1,10),
                                  ('SF',1,16),('SD',2,10),('SD',5,16),('SD',6,16),('SD',7,16),('W',4,16),('R',4,16)]:
            index=next(i for i,s in enumerate(original) if s.startswith(kind+' '));changed=original.copy();f=changed[index].split()
            f[column]=format(int(f[column],base)^1,'x') if base==16 else str(int(f[column])^1)
            changed[index]=' '.join(f);trials.append((kind+str(column),changed))
        for kind in ('SC','SR','SI','SO','SE','SF','SD','J','U','DROW'):
            index=next(i for i,s in enumerate(original) if s.startswith(kind+' '));trials.append(('missing_'+kind,original[:index]+original[index+1:]))
        for label,lines in trials:
            try:verify_seed_rows(lines)
            except (ValueError,IndexError,KeyError,TypeError):continue
            raise ValueError('Seed-row checker accepted corruption:'+label)
        message=f'STAGE5I SEED ROW CHECKER PASS:{len(trials)}/{len(trials)} corruptions rejected\n'
        (HERE/'stage5_seed_row_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='row':
        original=(HERE/'stage5_row_outputs.txt').read_text().splitlines();verify_rows(original);trials=[]
        for kind,column,base,label in [('B',2,10,'row_parameter'),('B',9,10,'matrix_owner'),('B',11,10,'secret_owner'),
            ('DROW',5,10,'completed_term_count'),('C',10,10,'inplace_enable'),('V',7,10,'destination_domain'),
            ('W',4,16,'scalar_write'),('P',4,16,'packed_write'),('Q',3,10,'ack_index'),
            ('M',4,16,'cached_old_word'),('M',6,10,'overwrite_frontier'),('I',3,16,'old_accumulator'),
            ('K',6,16,'ADD_value'),('N',3,16,'NTT_value'),('R',4,16,'row_readback'),('L',1,10,'scratch_release')]:
            index=next(i for i,s in enumerate(original) if s.startswith(kind+' '));changed=original.copy();f=changed[index].split()
            value=int(f[column],base)^1;f[column]=format(value,'x') if base==16 else str(value);changed[index]=' '.join(f);trials.append((label,changed))
        for kind in ('O','C','M','P','Q','U','DROW','Z'):
            index=next(i for i,s in enumerate(original) if s.startswith(kind+' '));trials.append(('missing_'+kind,original[:index]+original[index+1:]))
        trials += [('stale_token',['H '+'0'*64]+original[1:]),('extra_footer',original+[original[-1]])]
        for label,lines in trials:
            try:verify_rows(lines)
            except (ValueError,IndexError,KeyError):continue
            raise ValueError('Row checker accepted corruption:'+label)
        message=f'STAGE5H ROW CHECKER PASS:{len(trials)}/{len(trials)} corruptions rejected\n'
        (HERE/'stage5_row_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='bank_process':
        original=(HERE/'stage5_process_banks_outputs.txt').read_text().splitlines()
        verify_process_banks(original);trials=[]
        for kind,column,base,label in [('I',3,16,'operand_A'),('I',4,16,'operand_B'),('K',6,16,'ADD_value'),
            ('W',4,16,'write_value'),('W',2,10,'packer_core'),('W',3,10,'write_index'),
            ('P',4,16,'packed_word'),('P',2,10,'packed_region'),('P',3,10,'packed_index'),
            ('Q',3,10,'ack_index'),('V',5,10,'allocation_mode'),('V',7,10,'allocation_domain'),
            ('D',4,10,'done_ID'),('R',4,16,'read_data'),('R',9,10,'small_flag'),('G',4,10,'atomic_witness'),('Y',4,10,'partial_publication')]:
            row=next(i for i,s in enumerate(original) if s.startswith(kind+' '))
            changed=original.copy();f=changed[row].split();value=int(f[column],base)^1
            f[column]=format(value,'x') if base==16 else str(value);changed[row]=' '.join(f);trials.append((label,changed))
        rounding=next(i for i,s in enumerate(original) if s.startswith('K ') and process_bank_program()[int(s.split()[1])][1]==2)
        for column,label in ((7,'P2R_high'),(8,'P2R_low'),(9,'P2R_encoding')):
            changed=original.copy();f=changed[rounding].split();f[column]=str(int(f[column])^1);changed[rounding]=' '.join(f);trials.append((label,changed))
        for kind in ('I','P','Q','U','D','R'):
            row=next(i for i,s in enumerate(original) if s.startswith(kind+' '))
            trials.append(('missing_'+kind,original[:row]+original[row+1:]))
        high_commit=next(i for i,s in enumerate(original) if s.startswith('U ') and s.split()[2]=='1' and process_bank_program()[int(s.split()[1])][0]=='P')
        trials += [('missing_high_commit',original[:high_commit]+original[high_commit+1:]),
                   ('stale_token',['H '+'0'*64]+original[1:]),('duplicate_footer',original+[original[-1]])]
        for label,lines in trials:
            try:verify_process_banks(lines)
            except (ValueError,IndexError,KeyError):continue
            raise ValueError('Bank process checker accepted corruption:'+label)
        message=f'STAGE5G BANK PROCESS CHECKER PASS:{len(trials)}/{len(trials)} corruptions rejected\n'
        (HERE/'stage5_process_banks_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='bank_ntt':
        original=(HERE/'stage5_ntt_banks_outputs.txt').read_text().splitlines()
        verify_ntt(original,banked=True);trials=[]
        for kind,column,base,label in [('K',3,16,'NTT_value'),('T',6,16,'DMA_value'),('T',4,10,'DMA_id'),
              ('R',3,16,'read_value'),('R',7,10,'domain'),('R',8,10,'small'),('O',4,10,'source_id'),
              ('V',2,10,'reservation'),('D',4,10,'done_id'),('P',5,16,'packed_word'),
              ('P',3,10,'packed_region'),('P',4,10,'packed_index'),('Q',4,10,'ack_index'),('G',4,10,'held_result_witness')]:
            row=next(i for i,s in enumerate(original) if s.startswith(kind+' '))
            changed=original.copy();fields=changed[row].split();value=int(fields[column],base)^1
            fields[column]=format(value,'x') if base==16 else str(value);changed[row]=' '.join(fields)
            trials.append((label,changed))
        for kind in ('K','Q','D'):
            row=next(i for i,s in enumerate(original) if s.startswith(kind+' '))
            trials.append(('missing_'+kind,original[:row]+original[row+1:]))
        trials += [('stale_token',['H '+'0'*64]+original[1:]),('duplicate_footer',original+[original[-1]])]
        for label,lines in trials:
            try:verify_ntt(lines,banked=True)
            except (ValueError,IndexError,KeyError):continue
            raise ValueError('Bank NTT checker accepted corruption:'+label)
        message=f'STAGE5F BANK NTT CHECKER PASS:{len(trials)}/{len(trials)} corruptions rejected\n'
        (HERE/'stage5_ntt_banks_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='bank_store':
        original=(HERE/'stage5_store_outputs.txt').read_text().splitlines();verify_bank_store(original);trials=[]
        for kind,column,base,label in [('K',4,16,'packed_data'),('K',2,10,'write_region'),('K',3,10,'write_word'),
                                     ('B',3,10,'ack_word'),('R',4,16,'read_data'),('R',5,10,'read_ID'),
                                     ('R',8,10,'domain'),('R',9,10,'bounded'),('S',3,10,'status'),('G',1,10,'fault_gate')]:
            index=next(k for k,s in enumerate(original) if s.startswith(kind+' '));lines=original.copy();f=lines[index].split()
            value=int(f[column],base)^1;f[column]=format(value,'x') if base==16 else str(value);lines[index]=' '.join(f);trials.append((label,lines))
        index=next(k for k,s in enumerate(original) if s.startswith('K '))
        trials += [('missing_write',original[:index]+original[index+1:]),('stale_token',['H '+'0'*64]+original[1:])]
        for label,lines in trials:
            try:verify_bank_store(lines)
            except (ValueError,KeyError,IndexError):continue
            raise ValueError('Bank-store checker accepted corruption:'+label)
        message='STAGE5 STORE CHECKER PASS:12/12 corruptions rejected\n'
        (HERE/'stage5_store_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='bank_memory':
        original=(HERE/'stage5_banks_outputs.txt').read_text().splitlines();verify_bank_memory(original)
        ri=next(i for i,s in enumerate(original) if s.startswith('R ') and s.split()[5]=='0')
        ji=next(i for i,s in enumerate(original) if s.startswith('J '));trials=[]
        for column,base,label in [(7,16,'read_word'),(6,10,'address'),(3,10,'bank'),(4,10,'port'),
                                  (5,10,'write_flag'),(1,10,'command_id')]:
            lines=original.copy();f=lines[ri].split();v=int(f[column],base)^1
            f[column]=format(v,'x') if base==16 else str(v);lines[ri]=' '.join(f);trials.append((label,lines))
        lines=original.copy();f=lines[ri].split();f[2]='0';lines[ri]=' '.join(f);trials.append(('response_latency',lines))
        trials += [('missing_read',original[:ri]+original[ri+1:]),('duplicate_request',original[:ji]+[original[ji]]+original[ji:]),
                   ('stale_token',['H '+'0'*64]+original[1:]),('missing_footer',original[:-1]),
                   ('missing_reset',[s for s in original if not s.startswith('X ')])]
        for label,lines in trials:
            try:verify_bank_memory(lines)
            except (ValueError,IndexError,KeyError):continue
            raise ValueError('Bank checker accepted corruption:'+label)
        message='STAGE5 BANKS CHECKER PASS:12/12 corruptions rejected\n'
        (HERE/'stage5_banks_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='shared_hash':
        original=(HERE/'stage5_shared_outputs.txt').read_text().splitlines();verify_shared_hash(original);trials=[]
        for kind,column,base,label in [('O',6,16,'raw_value'),('O',2,10,'raw_core'),('O',3,10,'raw_ID'),
                                     ('O',5,10,'valid_bytes'),('Z',5,16,'rho'),('Z',6,16,'rho_prime'),
                                     ('Z',7,16,'key'),('C',5,16,'coefficient'),('C',4,10,'coefficient_index'),
                                     ('Z',2,10,'seed_error')]:
            j=next(j for j,s in enumerate(original) if s.startswith(kind+' '));lines=original.copy();f=lines[j].split()
            v=int(f[column],base)^1;f[column]=format(v,'x') if base==16 else str(v);lines[j]=' '.join(f);trials.append((label,lines))
        j=next(j for j,s in enumerate(original) if s.startswith('D '))
        trials += [('missing_raw_completion',original[:j]+original[j+1:]),('stale_token',['H '+'0'*64]+original[1:])]
        for label,lines in trials:
            try:verify_shared_hash(lines)
            except (ValueError,IndexError):continue
            raise ValueError('Shared checker accepted corruption:'+label)
        message='STAGE5 SHARED HASH CHECKER PASS:12/12 corruptions rejected\n'
        (HERE/'stage5_shared_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='hash_format':
        original=(HERE/'stage5_hash_outputs.txt').read_text().splitlines();verify_hash_format(original)
        trials=[]
        for kind,column,label in [('D',2,'mode'),('D',3,'message_length'),('D',4,'output_length'),
                                  ('W',2,'word_index'),('W',3,'absorbed_byte'),('V',2,'output_index'),
                                  ('V',3,'output_bytes'),('V',5,'hash_byte'),('S',2,'ID'),('S',3,'error')]:
            row=next(i for i,s in enumerate(original) if s.startswith(kind+' '))
            lines=original.copy();f=lines[row].split();base=16 if label in ('absorbed_byte','hash_byte') else 10
            f[column]=format(int(f[column],base)^1,'x') if base==16 else str(int(f[column])^1)
            lines[row]=' '.join(f);trials.append((label,lines))
        trials += [('stale_token',['H '+'0'*64]+original[1:]),('missing_footer',original[:-1])]
        for label,lines in trials:
            try:verify_hash_format(lines)
            except (ValueError,IndexError):continue
            raise ValueError('Hash formatter checker accepted corruption:'+label)
        message='STAGE5 HASH FORMAT CHECKER PASS:12/12 corruptions rejected\n'
        (HERE/'stage5_hash_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==5:
        original=(HERE/'stage5_outputs.txt').read_text().splitlines();verify_process(original)
        pi=next(i for i,s in enumerate(original) if s.startswith('P '))
        ji=next(i for i,s in enumerate(original) if s.startswith('J '));trials=[]
        for label,col in [('error',2),('residue',3),('high',4),('signed_low',5),('packed_t0',6),
                          ('ID',7),('index',8),('last',9),('operation',10)]:
            lines=original.copy();f=lines[pi].split();f[col]=str(int(f[col])^1);lines[pi]=' '.join(f)
            trials.append((label,lines))
        trials += [('missing_output',original[:pi]+original[pi+1:]),
                   ('duplicate_input',original[:ji]+[original[ji]]+original[ji:]),
                   ('stale_token',['H '+'0'*64]+original[1:])]
        for label,lines in trials:
            try:verify_process(lines)
            except (ValueError,IndexError):continue
            raise ValueError('Process checker accepted corruption:'+label)
        message='STAGE5 PROCESS CHECKER PASS:12/12 corruptions rejected\n'
        (HERE/'stage5_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==4:
        original=(HERE/'stage4_outputs.txt').read_text().splitlines();verify_ntt(original)
        ri=next(i for i,s in enumerate(original) if s.startswith('R '))
        ki=next(i for i,s in enumerate(original) if s.startswith('K '))
        ti=next(i for i,s in enumerate(original) if s.startswith('T '))
        oi=next(i for i,s in enumerate(original) if s.startswith('O '))
        vi=next(i for i,s in enumerate(original) if s.startswith('V '))
        di=next(i for i,s in enumerate(original) if s.startswith('D '))
        trials=[]
        for label,row,column in [('output',ki,3),('DMA_value',ti,6),('DMA_id',ti,4),('read_value',ri,3),
                                 ('domain',ri,7),('source_id',oi,4),('reservation',vi,2),('done_id',di,4)]:
            lines=original.copy();f=lines[row].split();base=16 if label in ('output','DMA_value','read_value') else 10
            changed=int(f[column],base)^1;f[column]=format(changed,'x') if base==16 else str(changed)
            lines[row]=' '.join(f);trials.append((label,lines))
        trials += [('missing_output',original[:ki]+original[ki+1:]),('missing_commit',original[:di]+original[di+1:]),
                   ('stale_token',['H '+'0'*64]+original[1:]),('extra_read',original+[original[ri]])]
        for label,lines in trials:
            try:verify_ntt(lines)
            except (ValueError,IndexError,KeyError):continue
            raise ValueError('NTT checker accepted corruption:'+label)
        message='STAGE4 CHECKER SELFTEST PASS:12/12 corruptions rejected\n'
        (HERE/'stage4_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==3:
        original=(HERE/'stage3_outputs.txt').read_text().splitlines()
        verify_memory(original)
        ri=next(i for i,s in enumerate(original) if s.startswith('R '))
        trials=[]
        for label,column,value in [('value',4,'ffffff'),('slot',2,'4'),('index',3,'1'),
                                    ('job_id',5,'0'),('mode',6,'3'),('parameter',7,'3'),('domain',8,'1')]:
            lines=original.copy();f=lines[ri].split()
            if f[column]==value:value='0'
            f[column]=value;lines[ri]=' '.join(f);trials.append((label,lines))
        ji=next(i for i,s in enumerate(original) if s.startswith('J '))
        si=next(i for i,s in enumerate(original) if s.startswith('S '))
        trials += [('missing_read',original[:ri]+original[ri+1:]),
                   ('duplicate_job',original[:ji]+[original[ji]]+original[ji:]),
                   ('missing_commit',original[:si]+original[si+1:]),
                   ('stale_token',['H '+'0'*64]+original[1:]),
                   ('extra_read',original+[original[ri]])]
        for label,lines in trials:
            try:verify_memory(lines)
            except (ValueError,IndexError):continue
            raise ValueError('Memory checker accepted corruption:'+label)
        message='STAGE3 CHECKER SELFTEST PASS:12/12 corruptions rejected\n'
        (HERE/'stage3_checker_selftest.log').write_text(message);print(message,end='');return
    original=(HERE/'stage2_outputs.txt').read_text().splitlines()
    verify(original)
    ci=next(i for i,s in enumerate(original) if s.startswith('C '))
    ji=next(i for i,s in enumerate(original) if s.startswith('J '))
    si=next(i for i,s in enumerate(original) if s.startswith('S '))
    trials=[]
    for label,row,column,value in [
        ('value',ci,4,lambda v:f'{int(v,16)^1:06x}'),
        ('index',ci,3,lambda v:str(int(v)+1)),
        ('core',ci,2,lambda v:str(int(v)^1)),
        ('job_id',ji,3,lambda v:str(int(v)+1)),
        ('last',ci,5,lambda v:str(int(v)^1)),
        ('status',si,3,lambda v:str(int(v)+1)),
        ('case',ci,1,lambda v:'104'),
        ('footer',len(original)-1,1,lambda v:'103')]:
        lines=original.copy();f=lines[row].split();f[column]=value(f[column]);lines[row]=' '.join(f)
        trials.append((label,lines))
    trials += [('missing_coefficient',original[:ci]+original[ci+1:]),
               ('duplicate_descriptor',original[:ji]+[original[ji]]+original[ji:]),
               ('extra_coefficient',original+[original[ci]]),
               ('stale_capture',['H '+'0'*64]+original[1:])]
    for label,lines in trials:
        try:verify(lines)
        except ValueError:continue
        raise ValueError('Checker accepted corruption:'+label)
    message='STAGE2 CHECKER SELFTEST PASS:12/12 corruptions rejected\n'
    (HERE/'stage2_checker_selftest.log').write_text(message);print(message,end='')


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['prepare','check','compare','selftest'])
    p.add_argument('--stage',type=int,choices=[2,3,4,5],default=4)
    p.add_argument('--unit',choices=['process','hash_format','shared_hash','bank_memory','bank_store','bank_ntt','bank_process','row','seed_row'],default='process',
                   help='Select the Stage5 unit; full KeyGen is not implemented yet')
    try:
        args=p.parse_args();command=args.command
        if command=='check':
            check();print('STAGE2 VECTOR FRESHNESS PASS')
        elif command=='prepare':prepare()
        else:{'compare':compare,'selftest':selftest}[command](args.stage,args.unit)
    except (ValueError,OSError,AssertionError,subprocess.SubprocessError) as e:
        raise SystemExit('DILITHIUM REFERENCE FAIL: '+str(e))
