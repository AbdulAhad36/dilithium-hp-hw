# Dilithium cycles,throughput and implementation metrics

## Current Stage7C.6 routed production result

Both targeted changes are implemented:registered two-slot memory responses
remove the ready-feedback loop,and HintUnpkg fetches four indices in parallel.
Full compile,assembly,TimeQuest and the separate retained-hardware/four-corner
report pass. There are no combinational-loop warnings in the new full compile.
The same Cyclone V,6.757ns clock,hold rules and non-source QSF settings remain.

|Metric|Stage7B.9|Stage7C.5|Current7C.6|
|---|---:|---:|---:|
|Actual `[A]` placed ALMs|51162|34170|33824|
|Registers|47735|24376|25092|
|M10Ks|62|59|59|
|DSP blocks|27|8|8|
|Block-memory bits|416589|409381|409381|

Placed area falls346 ALMs from7C.5 and17338/51162=33.89% from7B.9. Response
buffering adds registers while total placed ALMs decrease;these are measured
fitter counts. No packing estimate is used as the headline area.

|Corner|Reported Fmax (MHz)|Setup slack (ns)|Setup endpoint TNS (ns)|Hold slack (ns)|Hold TNS (ns)|
|---|---:|---:|---:|---:|---:|
|Slow85C|39.43|-18.607|-207654.513|+0.307|0|
|Slow0C|39.37|-18.645|-200927.011|+0.301|0|
|Fast85C|91.67|-4.152|-21530.164|+0.139|0|
|Fast0C|100.63|-3.180|-8257.828|+0.127|0|

**The148MHz target still fails setup.** Worst hold remains positive;hold TNS
is zero. Worst setup slack improves,but aggregate setup TNS has not improved
at every corner. The new worst path is shared BitUnpkg `width_r[4]` through
service/Verify-input control into `state.NORM_RUN`:25.212ns data delay. The
former hint-byte path is no longer the worst path. Next optimize this measured
decoder/service-control path;do not change the clock or hide it with exceptions.

All210 official and88 protocol capture records after the token header are
exact7C.5,including every payload,attempt hash,verdict and cycle field. All30
main-UVM latency CSV rows also match across every column. There is no measured
cycle/throughput loss in these campaigns. Native RAM testing additionally
proves one request per port per clock during unstalled reads and writes.
Fitted Fmax is an estimate;no148MHz operating throughput or FPGA-board result
is claimed before timing closure. The compact cycle table below still applies.

Current main token:`695b8bbef6746043e78e107d11847ec819e5ba59d019f88721a8646beaf8f706`.
Evidence:`evidence/stage7c6_response_hint_qualified.zip` plus SHA256. This is a
qualified source/routed checkpoint,not user acceptance of the performance.


## Stage7C.5 routed production baseline

The actual production wrapper passes210 official commands,88 protocol commands
and the90-corruption checker. Its payloads and operation cycles match the frozen
7C.4 candidate. Main UVM passes30 completions/3 resets. Full compile,assembler,
TimeQuest and the separate retained-hardware/four-corner analysis all exit0.
**Setup still fails;the combinational-loop warning remains an open defect.**

|Resource|Previous7B.9|New7C.5|
|---|---:|---:|
|Actual `[A]` ALMs used in final placement|51162|34170|
|Registers|47735|24376|
|M10Ks|62|59|
|DSP blocks|27|8|
|Block-memory bits|416589|409381|

The placed-ALM reduction is16992/51162=33.21%. The headline uses actual final
placement,not the fitter's packing estimate. Device5CGXFC7C7F23C8,6.757ns clock,
seed,hold rules and all non-source QSF options remain exact to7B.9.

|Corner|Reported Fmax (MHz)|Setup slack (ns)|Setup endpoint TNS (ns)|Hold slack (ns)|Hold TNS (ns)|
|---|---:|---:|---:|---:|---:|
|Slow85C|32.21|-24.291|-205428.496|+0.286|0|
|Slow0C|31.89|-24.598|-198187.985|+0.258|0|
|Fast85C|69.39|-7.655|-26651.763|+0.130|0|
|Fast0C|77.48|-6.150|-12203.494|+0.099|0|

These timing figures are diagnostics from a design with a145-node post-fit
combinational loop (152 nodes at synthesis),not accepted operating clocks.
No throughput at148MHz or timing closure is claimed. The worst reported
setup path runs from Verify HintUnpkg `position_r[5]` through its dependent
byte selections and shared bank write route into bank1 RAM:data delay31.171ns.
The preserved reports are `output_full/dilithium_full.fit.rpt` and
`critical_full/{slow,fast}_{0,85}C_*`;the source baseline is frozen in
`evidence/stage7c5_production_loop_baseline.zip` plus SHA256.

The retained-hardware report confirms four controller FSMs (5/5/7/6 bits),
3200 Keccak state bits,all three64-bit sampler stages,four23-bit butterfly
registers,16 physical-port owner bits,32 sampler writer-ID bits,92 shared
Process coefficient bits,704 hint-suffix bits and the1024-bit secret-key header.
This does not substitute for the independent output/protocol checks.

Next7C.6 removes the memory ready-feedback loop and the measured dependent
hint-byte chain,then repeats source/output/UVM and physical gates. A temporary
two-slot response prototype sustains one request/port/clock when unstalled,
passes23397 checked requests and retains the same94208 RAM bits per bank.
Recovery from completely full buffering may add a stall bubble;measure actual
operation latencies and throughput after adoption. No prototype result is
retagged as production qualification.

## Stage7C compact reconstruction: correctness before final timing

### Qualified shared-main candidate

All210 official commands pass while interleaving the three operations through
ONE datapath,with no reset between completed commands. The byte total is
433600 published key bytes +310680 signature bytes =744280 bytes. Verify
separately matches9 valid/36 invalid verdicts,with35 exact equation digests;
10 structurally invalid inputs stop before that equation.

|Operation|Level|Cases|Minimum cycles|Mean cycles|Maximum cycles|
|---|---|---:|---:|---:|---:|
|KeyGen|2|25|8658|8722.84|8818|
|KeyGen|3|25|15082|15144.36|15227|
|KeyGen|5|25|24299|24438.88|24561|
|Sign|2|30|19095|69183.80|240176|
|Sign|3|30|28711|81791.80|266651|
|Sign|5|30|43126|131518.10|313294|
|Verify,all verdicts|2|15|1562|8940.80|12457|
|Verify,all verdicts|3|15|2094|12448.87|17718|
|Verify,all verdicts|5|15|2892|21451.07|27603|

Verify's early-invalid cases lower those means. The three accepted cases per
level average11042.67/16403.67/25405.67 cycles;equation-reaching cases average
10784.17/16205.82/26088.00. The functional bench uses a convenient ideal10ns
clock and public stream stalls. These are cycle measurements,not post-fit
throughput or Fmax. The unchanged implementation constraint remains6.757ns.
No new whole-main placed ALM/Fmax/slack result exists at this checkpoint.

Source token:`6270b2cad0147c256d8eb84798cef422b8d419201bbcab96243b0eaab78ffe61`.
Native capture:`stage7c4_main_outputs.txt`;classification:`stage7c4_main_metrics.log`.
Next:production source/UVM handoff and same-FPGA synthesis,then optimize the
measured bottlenecks. The paper's cycle/frequency/area targets remain open.

### Earlier compact operation checkpoints

Compact Sign now passes90 official signatures at source token
`b5c7cf95c4c0cce20bac03c4615e96c1116b023d4373ae18893c3b8bbedb3a22`.
The native ledger is `sim/dilithium/stage7c3_sign_cycles.csv`; every row
satisfies sum(phases)+1=total, including the command-accept clock.

|Level|Official cases|Suite minimum cycles|Suite mean cycles|Suite maximum cycles|Total attempts|Maximum attempts|
|---|---:|---:|---:|---:|---:|---:|
|2|30|19118|69203.37|240198|176|23|
|3|30|28738|81817.80|266678|128|16|
|5|30|43160|131553.10|313329|129|11|

These totals include the complete expanded-SK and message input streams,
one-time secret transforms, all actual rejection attempts and signature output
backpressure. They are measured vector-suite latencies, not a fitted clock
frequency or a claim of matching LightHD's counting boundaries. Matrix wait
averages12574.73/20819.60/43982.27 clocks per command and is the largest single
category at every level. The ledger also separates y preparation, MAC, inverse,
Decompose, challenge generation, response products/norms, hints and output.
Secret-transform preparation stays3032/4306/5822 clocks regardless of retries.
Current Sign still requires substantial cycle optimization after compact
Verify/main are working; no claim of beating the paper is made.

After paired-A/early-matrix scheduling,all75 official keypairs still match.
The measured cycle ranges at levels2/3/5 are8653..8818,15088..15222 and
24301..24561;averages8723.04,15144.16 and24438.12. These include the same
public-output stalls and complete key streaming. The previous averages were
10173.48,17364.56 and28462.76. Waiting for matrix data remains the largest
component:2675.72,5312.12 and10816.96 clocks on average. This is measured
controller/sampling wait,not NTT butterfly compute latency.

The ledger CSV gives seed,secret preparation,matrix wait,MAC,INTT,addition,
rounding,PK and SK phases. All75 rows satisfy sum(phases)+1=total;the extra
clock accepts the command. The current schedule still does not reach the
paper's KeyGen cycle counts. Final optimization must use the measured stream
and engine rates;the published LUT totals are not directly Cyclone V ALMs.

The following initial-schedule figures are historical:

All75 official KeyGen keypairs pass the initial compact-controller gate.
The first published case at each level completes in10261/17263/28474 clocks,
including host output backpressure and full PK/SK streaming. These totals
are not the paper's rounded4.2k/6.4k/10.6k counts;counting boundaries and
the measured sampler/hash waiting time must be recorded before comparison.
Across75 cases,the native trace observes315577 cycles with NTT active while
sampling remains active. Peak A-ring occupancy is2 of9 slots. This aggregate
overlap is not a separate count of secret-only Pre-NTT overlap.

No new whole-main actual placed ALM,Fmax,slack or throughput result exists
for the replacement. The production target and same FPGA remain6.757ns;
the historical7B.9 PPA below must not be attributed to compact KeyGen.
The shared Process standalone trial gave1561 placed ALMs,1038 registers,
zero DSP/RAM and worst Fmax102.52MHz;it still misses the target and predates
later pack-only transport additions. It is a diagnostic,not accepted full
accelerator PPA. Optimization follows complete KeyGen/Sign/Verify outputs.

## Stage7B.9: routed production baseline; setup target fails

The approved production wrapper keeps all three crypto operations and the
unchanged74 RTL. It exposes1027 command/data/status bits including clock;
1324 seed/debug/occupancy bits become internal. These are port counts,not
area savings. Main UVM now tests the actual production wrapper. Fresh full
compile runs with the same FPGA/6.757ns/hold constraints and original physical
options. Trial7B.8 was intentionally
aborted on the approved interface switch;its log is not a failed or successful
routed design. No aggressive-routability option was persisted from that trial.

Production-source main33 now passes30 checked completions/3 reset aborts with
zero UVM errors/fatals. Every completion timestamp and every latency/wait/
occupancy/engine-cycle CSV field equals7B.7. No operation-cycle penalty is
measured for the wrapper. Current functional121/170 and overall code
316722/397459=79.69%;same-token byte0 corruption earns zero credit. The full
compile now completes synthesis,placement,routing,assembly and timing analysis.
This is the first successfully routed whole-main baseline. It does not meet
the148MHz target;Stage7 performance closure remains open.

|Current production-top metric|Measured result|
|---|---:|
|ALMs used in final placement `[A]`|51,162 /56,480 (90.58%)|
|LABs used|5,306 /5,648|
|Registers|47,735|
|M10Ks / DSPs|62 /27|
|Block-memory bits|416,589|
|Clock constraint|6.757ns (about148MHz),unchanged|
|Worst reported Fmax|23.97MHz,slow0C|
|Worst setup slack|−34.965ns,slow0C|
|Worst hold slack|+0.099ns,fast0C|
|Worst setup endpoint TNS|−705,626.710ns,slow85C|
|Hold endpoint TNS|0ns at all four corners|

Area above is the actual final-placement count. Use that count consistently;
the headline logic-utilization estimate in fit.summary is a different metric.
Sources are output_full/dilithium_full.fit.rpt and .sta.summary,with detailed
paths and Fmax under critical_full/. Timing conditions are1100mV throughout.

|Corner|Fmax MHz|Setup ns|Hold ns|Setup endpoint TNS ns|
|---|---:|---:|---:|---:|
|Slow85C|24.50|−34.054|+0.284|−705626.710|
|Slow0C|23.97|−34.965|+0.220|−690297.804|
|Fast85C|55.71|−11.194|+0.128|−213406.907|
|Fast0C|61.98|−9.377|+0.099|−156168.980|

The worst path is Verify equation lane selection through Decompose/UseHint,
the shared request mux and Bitpkg into packer.bits_r. The slow0C path has23
logic levels and40.962ns data delay. No148MHz hardware throughput is claimed
from zero-delay source simulation. Reported Fmax is an estimate;the operating
constraint has not been lowered to it. Board I/O timing remains outside this
virtual-pin benchmark.

Retained-bit checks pass:main FSM8,KeyGen28,Sign16,Verify16,Keccak3200,sampler
secret stages64 each,writer metadata44/progress18,decoder hint payload672 and
both Sign scan indices5 each. The main/KeyGen queries are hierarchy-scoped to
exclude unrelated Keccak state arrays. This analysis-only correction changes
no RTL,physical recipe or source fingerprint. The fitter's1914.3ns cumulative
clk-to-clk hold-repair delay is a routing diagnostic,not hold slack.

Next Stage7C targets this measured Verify arithmetic/packing path. First review
lane selection and arithmetic widths with independent equivalence checks;
then evaluate register boundaries with explicit cycle/throughput measurements.
Do not relax the clock/hold constraints or remove validation to hide the miss.

Frozen evidence:[Stage7B.9 production baseline](evidence/stage7b9_production_top_baseline.zip)
plus SHA256. RESULTS.json and MANIFEST.json are inside the archive;no loose
checkpoint JSON is added. The earlier interrupted13/33 run is excluded from
the qualified captures. The successful restarted main/physical runs are the
ones recorded above. This result does not approve further-stage performance.

## Stage7B.8: aborted fitter-only trial

The exact7B.7 RTL was trialed with
FITTER_AGGRESSIVE_ROUTABILITY_OPTIMIZATION=ALWAYS. It was stopped before a
route result on the user's approved production-interface switch. QSF/SDC/RTL
were unchanged during the trial. Exit-1 records intentional interruption,
not a completed fit. No physical metric or recipe is accepted from it.

## Stage7B.7: source passes,routing still fails

The Verify decoder replaces eight variable-position byte writes with one
aligned64-bit word write. Header storage uses its proven0..7 word range.
No FSM state,port or cycle is added. Diagnostic383 scenarios match the prior
decoder's timing and qualified outputs;fresh independent checking,main33 UVM
and whole-main compile run concurrently. Fresh synthesis reduces the decoder
from4911 to1667 ALUTs,with1420->1449 local registers. Block memory and DSP
totals are unchanged. These are synthesis counts,not placed ALMs. Placement
passes at50059 ALMs/5341 LABs,but routing FAILS. Its failed-route report has
47530 registers,62 M10Ks and27 DSPs. No accepted routed PPA/timing exists.
Main33 UVM/negative pass;all30 timestamps and every latency CSV field equal
7B.6. Functional121/170;overall code315824/396429=79.67%.
The7B.6 failed-route counts below are historical,not this candidate's PPA.

Next7B.8 is a fitter-only aggressive-routability trial on this smaller netlist.
It changes no RTL,clock or hold constraint. Preserve7B.7 reports first;retain
the setting in QSF only if successful,and report its exact physical recipe.

## Stage7B.6: source passes,routing still fails

7B.5 also fails routing;its fitter-only option is not retained. No accepted
routed area/Fmax/setup/hold exists yet. Candidate7B.6 moves completed metadata
to64 x22-bit RAM and keeps mutable state in two active writer records. Public
ports and qualified response latency are unchanged. The isolated comparison
passes16647 writes/4418 reads across64 slots. Independent C/Python preparation
passes. Focused59 helper cases and118 checker corruptions pass freshly.
Synthesis confirms64 x22=1408 tag bits in M10K. In like-for-like synthesis
hierarchy rows,local store registers fall2543->560 and local ALUT3972->1919;
these are NOT placed ALM counts. Full33 main UVM now passes with zero errors;
the memory comparator matches2579302 writes/858082 reads. All30 completion
timestamps and every latency/wait/occupancy/engine-cycle CSV field exactly
match7B.4. No operation-cycle penalty is measured for this change. The
same-token corrupted-key gate rejects byte0 with0/170 functional credit.
Placement passes at51760 ALMs/5531 LABs,with47502 registers,62 M10Ks and27 DSPs.
Routing FAILS congestion. These are failed-route allocation counts,not accepted
routed PPA. No Fmax/setup/hold/TNS is accepted. The fitter reports1890.4ns
cumulative inserted delay for clk-to-clk hold repair;this is not a slack.
No clock or hold constraint is relaxed. Next7B.7 reduces decoder variable-write
cost with aligned hint-word writes and bounded header addressing,then checks
cycle-by-cycle behavior against the prior decoder and independent references.

## Stage7B.5 historical: route the placed design

7B.4 now passes placement at53190 ALMs/5624 LABs,but routing fails congestion.
This is NOT a completed fit. Its failed-route report has49485 registers,
61 M10Ks and27 DSPs;no routed Fmax/setup/hold/TNS is accepted. Source UVM,
scan/helper/checker gates pass. Frozen evidence is
evidence/stage7b4_serial_route_failure.zip +SHA256.

Try FITTER_AGGRESSIVE_ROUTABILITY_OPTIMIZATION=ALWAYS using the same mapped
netlist,with no RTL/QSF change during the trial. This follows the fitter's
congestion diagnostic. Keep the same device and6.757ns constraint. Do not
report a successful fit until routing succeeds;report timing afterward.

## Stage7B.4 in progress: shared-per-cycle descriptor scans

The explicit packing trial7B.3 also fails at5716 LABs/54612 partial ALMs and
is archived;its option is not retained. Candidate7B.4 changes only
sign_attempt_check and sign_response_products. They scan their captured
descriptor lists before taking ownership:31 steps+one final check and23
steps+one final check,respectively. This replaces their parallel mask logic
and adds56 cycles per ordinary signing attempt. Actual profile-dependent
latency and Fmax/throughput impact must be measured; this candidate makes
no zero-latency-cost claim. Arithmetic engines and subsequent sequencing are
exact to7B.2. The main clock remains6.757ns on the same Cyclone V.

New isolated scan tests pass256 scenarios (24 valid/232 rejected,including18
reset/recoveries). Full33 main UVM passes30 completions/3 resets,zero errors.
The59 helper cases and118 checker corruptions pass. Fit/PPA remains pending.

Measured Sign command-to-first-done cycles,including the fixed test profiles:

| Level | Case |7B.2 cycles|7B.4 cycles|Increase |
|---|---|---:|---:|---:|
|2|Deterministic|2141901|2143189|0.0601%|
|2|Supplied randomness|490223|490511|0.0587%|
|3|Deterministic|487802|487963|0.0330%|
|3|Supplied randomness|485279|485449|0.0350%|
|5|Deterministic|1013518|1013745|0.0224%|
|5|Supplied randomness|1256050|1256330|0.0223%|

The repeated level2 recovery matches2143189 cycles. First-case extra1288 is
exactly56*23 attempts. Deliberate periodic transport stalls can change phase,
so other differences need not equal56*attempts exactly. Verify latency stays
exact in all measured rows;two KeyGen rows improve by3/6 stall cycles from
phase shifts,not an arithmetic improvement. These are case latencies,not a
sustained throughput benchmark or proof of operation at the148MHz target.

## Stage7B.2 in progress

Full33 UVM now passes30 completions/3 aborts,zero errors. All30 completion
timestamps exactly match Stage7A. The59-case helper regression and118 checker
faults pass. The first fit of this RTL still fails:5716 LABs required/5648
available,partial allocation54612 ALMs. This is below the raw ALM capacity
but exceeds LAB packing capacity; no accepted placed PPA/timing exists.
Failed reports are frozen separately while a packing-only refit runs with
--pack_register=minimize_area. The RTL is unchanged for that trial.

Replace quadratic pairwise comparisons with decoded region masks and one
balanced seven-bit population count per helper. If N handles contain no
duplicates,their union has exactly N bits; any duplicate reduces that count.
Checking the union also detects cross-set aliases. Existing explicit region
equality/overlap and scalar bounds remain. All sequential code is unchanged.
45841 equivalence cases and counts from0 through64 pass.

The QSF switches HIGH PERFORMANCE EFFORT to AGGRESSIVE AREA and disables
physical register duplication to seek a fit on this same FPGA. The6.757ns
constraint stays fixed. Area-focused optimization can trade timing for size;
its actual Fmax/slack will be measured,not assumed. This is consistent with
[Altera's optimization-mode reference](https://docs.altera.com/r/docs/683296/25.3/quartus-prime-pro-edition-settings-file-reference-manual/optimization_mode).
Full-source UVM and synthesis/fit are running;no accepted PPA yet.

## Stage7B.1 guard rewrite: verified but still too large

The first area candidate passes the same33-scenario main UVM,30 completions
and3 resets,zero errors. All30 completion timestamps exactly equal Stage7A
under identical stimulus/seed/stalls. Current latency CSVs are intact.
The59-case Sign helper fault regression and118 checker corruptions pass.
Only seven RTL files change; all six helpers' sequential code is exact.

Quartus synthesis succeeds; fit still **fails**:6044 LABs required versus5648
available. Its partial allocation is57873 ALMs,6409 below Stage7A's64282,
but remains a failed-fit diagnostic, not valid placed PPA. No Fmax/slack is
claimed. Keep the same FPGA and6.757ns constraint. The next candidate targets
the remaining pairwise uniqueness logic with compact population counting.

## Stage7A whole-main baseline

All three operations are enabled on 5CGXFC7C7F23C8 at the unchanged 6.757ns
constraint. Synthesis passes; fitting **fails** (6674 LABs needed, 5648
available). The failed fit's 64282-ALM partial allocation is diagnostic only,
not a valid placed-area result. No full-main Fmax/setup/hold/TNS or real
operations-per-second value is available. The failed reports map 49148
registers,61 M10Ks and27 DSPs; these remain failed-build diagnostics.

The new main UVM passes 30 completions/3 reset aborts. Its initial coverage
is documented in COVERAGE.md. Latency CSVs were overwritten by a stopped
accidental rerun and are not evidence for this checkpoint. Stage7B targets
the excessive helper guard logic on the same FPGA before new PPA claims.

## Stage6 official full-operation work counts

Fresh actual-main qualification uses FULL_KEYGEN=1, ENABLE_SIGN=1 and
ENABLE_VERIFY=1 for all three suites, under the same source fingerprint.
75 KeyGen cases match 433600 published key bytes; 90 Sign cases match 310680
signature bytes; 45 Verify cases match 9 valid and 36 invalid verdicts.
No RTL, memory geometry, clock constraint or production software changes.

| Event | KeyGen75 | Sign90 | Verify45 |
|---|---:|---:|---:|
|Commands / completions|75 / 75|90 / 90|45 / 45|
|Reset/fault aborts|0|0|0|
|Host input64 words|Seed in command|87433|47596|
|Host encoded output words|54200 key words|38880 signature words|45 completion verdicts|
|Allocation/rewrite events|Not logged by this bench|75469|5199|
|Finish events|Not logged by this bench|75469|5199|
|Release events|See raw capture|58802|3995|
|Exact scalar writes|Encoded outputs checked|Encoded outputs checked|1328384|
|Packed read records|112000 field metadata records|Not logged by this bench|26880 exact W/h data records|

Verify's 5199 finishes comprise 5189 full 256-value commits and 10 empty
discard commits from structural-invalid signatures: 5189*256=1328384 exact
writes. All 2046 NTT commands retire: 397 FNTT + 35 challenge Pre-NTT + 1404
PWM + 210 inverse. All 1194 ADD/SUB commands retire. There are 115 raw hash
requests and retirements, 32467 raw input64 words and 425 tagged output128
beats. Its 26880 packed reads equal 210 rows * 128 W/h words per row.

Sign peak occupancy is 33/45/61 logical regions; Verify is 22/30/40 for
levels2/3/5. The shared pool remains four banks of 1024x92 bits, 64 polynomial
regions / 47104 payload bytes. Region counts are not M10Ks or ALMs.

These are workload/event totals under deliberate simulation backpressure.
No new operations-per-second, Fmax, slack or placed-area result is inferred
from them. Whole-main Quartus/PPA and controlled latency measurement follow
this functionality gate in Stage7. Prior standalone and subsystem timing
results retain their original scope. Exact commands, mode exclusions and
qualification evidence are in REFERENCE_VERIFICATION.md.

## Stage5V.4 main Verify work counts

Fresh primary capture/comparison passes118 scenarios:115 Verify commands,
one real KeyGen,one real Sign and one unsupported-op3 probe.104 complete
(23 valid Verify,60 invalid Verify,19 expected errors,two mixed operations);
14 reset/fault aborts each have a subsequent same-ID valid recovery. Official
pure Verify coverage is45/45 verdicts:9 valid,36 invalid. Ten invalid inputs
stop at structural decoding;the other26 reach the equation and fail its hash.

| Captured event | Count | Scope/definition |
|---|---:|---|
|Host input words|108425|Verify's three frames plus the mixed Sign frames|
|Allocation/rewrite events|10576|All three main operation kinds in this campaign|
|Finish events|10569|10551 full commits +18 failed-frame partial discards|
|Exact Verify scalar writes|2624604|10251 Verify full commits*256 +249 discarded partial values +99 values interrupted by reset|
|Mixed full commits|300|72 KeyGen +228 Sign;their final encoded outputs are compared,individual legacy writes are not logged here|
|Release events|7977|Whole campaign,including pre-existing/adopted contexts and work leases|
|Verify sampler jobs|2378|Challenge SampleInBall and matrix A jobs,including interrupted work|
|Verify NTT commands|3998|821 FNTT +73 challenge Pre-NTT +2698 PWM +406 inverse|
|Verify ADD/SUB commands|2290|Shared in-place process DMA|
|Exact packed W/h reads|51466|Four23-bit coefficients per92-bit read,including reset prefixes|
|Verify raw hash descriptors/retirements|252 /248|PK,tr/message mu,and packed-w1 hashes;four reset/fault requests do not retire|
|Verify raw input words/digest beats|78780 /926|64-bit absorption/tagged128-bit output,including discarded or interrupted work|
|UseHint/packer inputs/outputs|102929 /7137|Scalar corrected coefficients/64-bit packed words|
|Mixed encoded outputs|3872 key bytes +2420 signature bytes|One NIST-keygen-derived pair and one unchanged C-reference signature|

These counts include Verify preparation,unlike the earlier equation-only
table. They include explicit test stalls,errors and resets and are **not** a
hardware throughput/latency benchmark. No new synthesis or Fmax/ALM result is
claimed. Verify private peaks are22/30/40 regions;the whole mixed campaign's
per-level peaks are33/30/40 because the level2 KeyGen/Sign work uses more.
The pool remains64 regions/four banks. Independent C/Python agrees on60
distinct whole Verify inputs (9 valid,51 invalid);170/170 checker corruptions
are rejected. Fresh Sign45 compatibility passes:21 signatures/63204 bytes,
one actual KeyGen,14 expected errors,nine resets/faults;its private peaks are
33/45/61. Fresh KeyGen-only16 compatibility passes:8 complete keypairs,three
rejects,five resets. See universal REFERENCE_VERIFICATION.md for exact counts.
Evidence:evidence/stage5v4_full_verify.zip and SHA256. No clock constraint was
changed and no fresh fitted PPA result is introduced by this milestone.

## Stage5V.3 equation work counts

The fresh source/independent-comparison gate passed87 commands:77 completions (19 valid,
35 cryptographically invalid,23 expected protocol errors) and10 reset/fault
aborts. Normal cryptographic checks total54=35 original official inputs+
9 mutations+10 recovery checks. There are80 adoptions:6 normal pre-adoption
errors and one held-adoption reset take no context.

Counters start after real PK/SIG/body preparation publishes its transformed
context. Its setup sampling,hashing and transforms are excluded here;these
counts must not be presented as complete main-Verify operation costs.

| Observed event | Count | Definition |
|---|---:|---|
|Matrix sampler jobs|2473|Real SHAKE128 rho/column/row jobs,including interrupted/error work|
|NTT commands|3308|2880 pointwise multiplies +428 inverse transforms|
|In-place ADD/SUB commands|2446|Shared process DMA,not a separate arithmetic implementation|
|Allocation events|8226|5780 new allocations +2446 in-place rewrites|
|Full finishes|8221|Each commits256 checked coefficients|
|Scalar writes|2104627|8221*256+51 coefficients from interrupted partial work|
|Packed read responses|49903|44974 W/h reads +4929 foreign sentinel readbacks|
|UseHint/packer inputs|92177|Includes explicit zero-drain and reset prefixes|
|Packed output words|6433|64-bit words,including discarded error/reset work|
|Raw hash words/digest beats|8057 /205|Exact64-bit absorption/tagged128-bit outputs|
|Release events|7208|Includes adopted context and foreign leases;rewrites are not new leases|

Private peak reservations are22/30/40 at levels2/3/5,excluding the one foreign
sentinel. Conservative plans reserve space for23/31/41 handles,within the
unchanged64-region pool. No new polynomial RAM is added. Same71 old RTL files,
21 production C/H files and6.757ns SDC remain byte-identical;two new RTL modules
make73. These are functional work counts,not fitted PPA or end-to-end hardware
throughput. Main Verify/op2 and later full-system optimization remain pending.

All966 RTL UseHint unit cases pass;172/172 checker corruptions reject.
Fresh verify_math134-scenario compatibility passes with unchanged counts.
Independent C/Python44 inputs/519168 equation values agree. Immutable source/
capture evidence:evidence/stage5v3_verify_equation.zip and SHA256. No new fit
or clock-performance result is claimed by this functional milestone.

## Stage5V.2b Verify preparation work counts

Fresh source comparison:134 commands=122 completions (65 transformed contexts,
57 expected errors)+12 reset/fault aborts. There are112 actual upstream context
adoptions;21 normal pre-adoption errors and one held-adoption reset take none.
The65 successful contexts comprise35 original official inputs (9 valid and26
crypto-invalid but structurally acceptable),18 message-boundary cases and12
post-reset recovery requests. Per-level success counts are22/21/22.

| Checked event | Count | Meaning |
|---|---:|---|
|Host payload words|17648|Accepted third-frame words,including error/abort prefixes|
|Raw hash input words|18612|Exact formatted mu absorption,including required zero-drains|
|Tagged128-bit digest beats|437|Exact independent SHAKE256 outputs,including later-discarded jobs|
|NTT commands|848|780 normal FNTTs+68 challenge Pre-NTTs;includes aborted/error work|
|New region allocations|930|Sampled challenge and rotating NTT destinations;initial decoded context setup excluded|
|Successful finishes|925|256 checked coefficients per finished polynomial|
|Scalar coefficient writes|236834|925*256+34 partial coefficients later invalidated by reset|
|External packed readbacks|84099|1192 successful result polynomials*64 +122 sentinel polynomials*64 +3 held preflight read responses|
|Explicit releases|3157|Includes adopted/pre-existing context and sentinel leases,not only new allocations|

Five new allocations are interrupted before finish. Reset invalidates their
leases;all normal terminal paths explicitly retire context and foreign owners.
Private peak regions are14/19/25;successful results retain13/18/24 regions.
The same64-region/four-bank pool suffices;no coefficient RAM is added.

The57 errors=12 bad command/layout/identity/length+9 unready/missing/changed
upstream leases+18 payload framing+6 synthetic no-free-region reports+3 actual
NTT source-ID rejections+9 sampler/NTT/formatter completion metadata mismatches.
The no-free tests override the response seen by the control client;they do
not measure physically filling every pool region. Independent C/Python
agreement covers56 inputs/191232 challenge-and-NTT coefficients.

These are source-level work counts,not final Verify latency/throughput or a
new fitted implementation. Main Verify equation,challenge comparison and op2
remain next. Existing70 RTL,21 production C/H and6.757ns SDC are unchanged.

112/112 checker corruptions reject. The earlier5V.2a133-scenario capture and
independent comparison also pass under the final fingerprint,with its previous
360545 writes/61827 reads unchanged. The source fingerprint and immutable
evidence links are in REFERENCE_VERIFICATION.md. No historical capture is retagged.

## Stage5V.2a preparation work counts

Fresh source capture/independent comparison:133 requests=49 prepared contexts
+73 expected errors+11 reset/fault aborts.60646 accepted host words,360545
exact scalar coefficient writes,61827 exact packed reads,27921 raw absorption
words and453 raw128-bit digest beats. There are1457 allocations,1451 finishes
and1440 explicit releases;partial-discard finishes and reset-invalidated
lifetimes account for the differing totals. Every normal end returns all
context and sentinel regions;take transfers the context before its test owner
releases it. Reset recovery uses a fresh sentinel/request without stale credit.

The49 prepared contexts include35 structurally acceptable official Verify
inputs (9 cryptographically valid+26 invalid),3 maximum-fitting region bases
and11 recovery requests. The73 errors comprise6 bad command/length,3 prior
pending-read refusals,6 overflow/collision,15 PK transport,18 signature
transport,16 norm/hint errors (10 official+6 directed),and9 loader metadata
faults. These are preparation outcomes,not official cryptographic RTL verdicts.
87/87 capture corruptions reject. C/Python match45 distinct64-byte PK hashes.

Counts include prefixes later rolled back or reset;they are not full-operation
latency or throughput. This checkpoint runs source RTL at the existing test
clock/6.757ns constraint and performs no fresh fit. No new area,Fmax,slack,
post-netlist or full-UVM coverage claim is made.

Fresh compatibility preserves the prior counts:SK-load138 commands/449992
writes/105728 reads (95 checker faults rejected);full KeyGen8complete/3rejects/
5resets,5433 key words/656 tr bytes (37 checker faults rejected);main Sign45
commands,21 exact signatures/63204 bytes,1 mixed KeyGen,14 expected errors and
9resets/faults. Main Sign physical allocations/finishes/releases remain
11253/11251/8778,with peak regions33/45/61 by level. All source captures and
independent comparisons share the final5V.2a fingerprint in the reference doc.

## Stage5V.1 Verify decoding work counts

383 commands=374 normal completions+9 reset aborts.275 frames are structurally
accepted;99 errors=14 command/length+37 signature norm/hint+48 transport.
117458 input handshakes and705010 decoded coefficient handshakes are checked,
including tentative prefixes discarded on errors/resets.144 signatures pass
the structural decoder;this is not a cryptographic Verify-success count.

Origins:90 PK/signature frames from45 official Verify cases,90 official Sign
signatures,75 official KeyGen public keys,128 directed/framing/reset scenarios.
Python/C compare303 distinct frames/664576 decoded values;their count uses
unique complete-frame unpacking,whereas RTL counts include repeated recovery
jobs and exact early-stop prefixes. Full C Verify independently matches45/45
official verdicts:9valid/36invalid. Of the36 invalid official signatures,
10 fail structural/norm checks and26 require later cryptographic checking.

Testbench stall clocks are585 header,361250 coefficient and723487 input;
these deliberately throttled simulation counts are not sustainable-throughput
measurements. Source simulation time8153394864ps at a6757ps clock includes all
383 jobs,stalls,resets and completion holds. No PPA/Fmax/area claim is made.
All67 existing RTL files and the6.757ns SDC are unchanged;one decoder is added.
Main Verify/memory integration and performance measurement remain later work.

## Stage5N.4h.7 official main Sign work counts

90 complete official signatures=30 per level2/3/5,split15 deterministic and
15 randomized each.30x2420+30x3309+30x4627=310680 exact NIST bytes;
30x303+30x414+30x579=38880 accepted64-bit output words.87433 original SK/body
words are accepted.433 attempts include343 normal rejections;individual
requests take1..23 attempts. Messages1..8192 bytes and contexts0..255 are used.

Physical ledger:75469 allocations=58802 new+16667 rewrites,75469 successful
256-coefficient finishes,58802 releases. No expected errors/reset/discards
occur in this success corpus. Every new region lifetime ends at a release;
every main Sign completion waits for zero owned regions. Peak33/45/61 regions
means33x736=24288,45x736=33120,61x736=44896 payload bytes. Pool capacity remains
64x736=47104 bytes. No extra bank/RAM/engine is introduced.

These are work/serialization counts with deliberate testbench stalls,not a
sustainable-throughput benchmark. Observed simulator wall time47m54s is not
hardware latency. All67 RTL files and6.757ns SDC match the previous checkpoint;
no new synthesis/Fmax/area/slack result is claimed. See the universal reference
document for exact-byte/checker/compatibility gate results and provenance.

## Stage5N.4h.6 actual main Sign work counts

45 commands=21 complete Sign+1 mixed KeyGen+14 expected errors+9 reset/fault
aborts. There are36 normal completions. Sign successes comprise13 level2,
4 level3 and4 level5:13x2420+4x3309+4x4627=63204 exact signature bytes.
These are12 unique message/context/rnd fixtures plus nine recovery repeats.
The mixed level2 KeyGen emits1312+2560=3872 exact key bytes (484 words).

| Captured metric | Definition / result |
|---|---|
|Input words|13356 accepted64-bit SK/body beats,including error/abort prefixes |
|Signature words|9113 accepted output beats,including prefixes;7911 belong to the21 complete signatures |
|Attempt starts|76 actual mask-attempt launches across success,error and abort jobs;not76 completed signatures |
|Allocation events|11253=8901 new reservations+2352 in-place rewrites |
|Finish events|11251=11246 successful commits+5 error discards;2 open writes terminate at reset |
|Physical releases|8778;new lifetimes also end at5 failed finishes and118 reset-held regions,so8901=8778+5+118 |
|Peak occupied regions|33/45/61 at levels2/3/5;24288/33120/44896 payload bytes |
|Normal Sign boundary|Zero owned regions before main done;fresh key load for every request |

These are simulated work/serialization counts with deliberate host stalls,
resets and repeated fixtures. They are not a sustainable-throughput benchmark
or a new Fmax/area result. No new synthesis is run. The6.757ns constraint and
selected legacy Quartus top remain unchanged. Per-operation cycle/Fmax/area
optimization follows complete functionality;main Verify is still open.

Fresh encoded KeyGen and rounded/debug-read KeyGen compatibility gates pass;
REFERENCE_VERIFICATION.md records their counts and execution commands.

## Stage5N.4h.5 signature serialization counts

Seven complete signatures=2 level2 +2 level3 +3 level5:
2x2420 +2x3309 +3x4627 =25339 exact bytes. Each signature needs303/414/579
64-bit output handshakes,with final4/5/3 valid bytes. Z consumes4x72 /5x80 /
7x80 packer output words. Hints add omega+k=84/61/83 bytes after z.

The24-command gate also exercises9 expected errors and8 aborts. Across all
prefixes it records6810 exact output words,8880 packed92-bit responses,
21 takes,149 releases and11 real key preparations. These are work counts,
**not sustainable throughput or a new Fmax result**. The harness injects stalls
and repeats fixtures for recovery. Key preparation/retry work precedes packing.

The encoder itself allocates no region;it adopts8/11/15 accepted z+h regions
and releases them before held completion. Key+accepted payload remains20/28/38
regions,excluding the test sentinel. No new physical banks/signature RAM.
The6.757ns target is unchanged;there is no fresh synthesis/area/timing claim.
Full-system latency and throughput will be measured after main Sign is connected.

## Stage5N.4h.4 complete attempt-loop work counts

47 scenarios=19 accepted parent results+12 expected service failures+
5 nonce-exhaustion reports+11 reset/fault aborts. Thus36 normal completions
include17 expected nonzero status codes. Accepted runs are6/6/7 at levels
2/3/5 and repeat underlying fixtures for recovery;they are not19 complete
encoded signatures.14 actual key preparations supply the retained contexts.

| Child | Starts | Results |
|---|---|---|
|Mask|87|81=75 complete vectors+6 expected errors;6 interrupted |
|Matrix|75|75=72 successes+3 expected source-ID errors |
|Challenge|72|72 |
|Challenge transform|72|72 |
|Products|72|71;1 interrupted |
|Candidate checks|71|70=45 real rejects+22 accepts+3 expected errors;1 interrupted |
|Total|449|441;8 active children interrupted,plus3 held accepted-result resets |

Of22 child accepts,19 publish parent results and3 are deliberately reset
while held.45 real rejection/header takes advance the nonce;these are normal
algorithm behavior,not service errors. One final vector at level5 accepts
with nextnonce65536;level2/3 final-vector rejections stop there. Three initial
65536 requests launch no attempt. There is no wrapped nonce0 request.

| Actual observation | Count / arithmetic |
|---|---|
|Raw SHAKE requests|157=44 initial mu+41 initial private seed+72 challenge |
|Initial-hash exception|3 malformed-payload cases complete/discard mu but never derive the private seed |
|Raw absorption words|10276;81944 meaningful bytes,264 zero padding bytes |
|Digest bytes|8992=5440 initial headers+3552 challenge |
|Mask jobs / statuses|418/412;6 interrupted jobs |
|Mask input words|3762=418x9,each descriptor absorbs66 meaningful seed/nonce bytes |
|Exact y scalar writes|105667=412x256+6x32+3 pending writes after parent HALT |
|Physical allocations|13147=10057 new reservations+3090 rewrites |
|Physical commits|13140 successful;7 open allocations end in global reset |
|Physical releases|9972,including internal row-MAC scratch releases |
|Rejected header transfers|45;payload map is empty before every transfer |
|Accepted outbound takes|8;other accepted contexts are explicitly cleared |
|Pending-read barriers|19 |
|Packed92-bit reads|56256=6592 z+7424 hints+39936 key+2304 sentinel |

The19 accepted results contain103 z polynomials and116 hint polynomials:
(103+116)x64=14016 packed words=56064 checked coefficients. Every result
digest also matches. Other intermediate arithmetic writes are covered by
the preceding gates;this loop gate does not claim scalar comparison of all
NTT/matrix/product writes. Its new scalar comparison covers all observed y
writes,including interrupted prefixes. Allocation/commit/release records
are independently reconstructed across the whole path.

Peak simultaneous physical reservations including one test sentinel are
34/46/62 at levels2/3/5;excluding it,33/45/61 regions=24288/33120/44896
payload bytes. Earlier phase schedules and the four1024x92 banks are unchanged.
A is resampled per attempt;matrix caching is future measured optimization.
These are observed work/storage counts,not new Fmax,slack,area,signature
latency or sustained throughput.6.757ns SDC is unchanged;no new Quartus fit.

## Stage5N.4h.3 candidate-check work counts

Fresh59-command gate:18 accepted candidates,5 genuine algorithmic rejections,
21 expected hardware/service errors and15 reset/fault aborts. Thus44 normal
completions=18+5+21. The accepted runs repeat three distinct clean fixtures
across recovery tests;they are not18 independent complete signatures.
18 real key preparations and53 complete upstream preparations supply the
actual products. Two preflight checks per level reuse their intact context.

| Observed work | Count |
|---|---|
|Whole-products takes|53 |
|CNB requests/results|730/727;724 successful service results,3 real bad-ID rejects,3 interrupted |
|ADD requests/results|150/147;144 successful service results,3 real bad-ID rejects,3 interrupted |
|Mhint requests/results|141/135;132 successful service results,3 real bad-ID rejects,6 interrupted |
|Exact scalar writes|70944=36960 combined-low +33984 hints |
|Last-use row releases|393=131 low +131 high +131 ct0 |
|Whole-attempt clear/error/reject releases|643 |
|Next-owner/header transfers|5;2 accepted payload transfers +3 header-only rejections |
|External releases|93=26 accepted result regions +67 artificial capacity blockers |
|Held-read clear/take barriers|23=18 accepted +5 rejected outcomes |
|Exact packed92-bit reads|157888 |

Successful service result counts include later deliberately corrupted parent
observations and held-done resets;they are not accepted-candidate counts.
Write arithmetic:276 completed polynomial writes x256 +9 interrupted
prefixes x32=70944. The18 accepted candidates account for55296 writes;
the remaining15648 are checked rejection/error/reset work. No accepted
write after a parent fatal-HALT occurs in this gate.

Read arithmetic:20224 input z +22784 input r0 +22784 input w1 +22784 input
ct0 +6144 accepted z +6912 accepted hints +49152 key +2816 sentinel +4288
capacity blockers=157888. Whole accepted-result readback is13056 packed
words=52224 coefficients;all source/output metadata and key/sentinel values
are independently checked. The upstream input reads total88576 packed words.

This phase's key+attempt+hint peak excludes sentinel/blockers:29/41/55
regions at levels2/3/5. Accepted retained totals are20/28/38;rejected payloads
are fully freed,leaving12/17/23 key regions plus private scalar retry headers.
Earlier phase peaks are unchanged. Physical banks,engines and6.757ns SDC
are unchanged. These work/storage counts are not new fitted area,Fmax,
slack,signature latency or sustained-throughput measurements.

## Stage5N.4h.2 product/response work counts

Fresh63-command arithmetic gate:24 complete schedules,21 expected errors,
18 reset/fault aborts;45 normal completions.21 real key preparations and57
full mask/matrix/challenge/transform preparations supply the inputs. Two
preflight cases per level reuse their intact source contexts. Successful
executions reuse six distinct level/nonce fixtures,eight per level.

| Observed work | Count |
|---|---|
|Atomic mask/vector takes|57 |
|NTT-service commands|1246 =629 PWM +617 inverse |
|NTT-service results|1234 =1228 successful +6 real source-ID rejects;12 interrupted |
|In-place commands/results|440 /437;434 successes,3 source-ID rejects,3 interrupted |
|Actual scalar writes|425955 =158240 PWM +156512 inverse +111200 ADD/SUB +3 after parent HALT |
|PWM scratch releases|599 |
|Inverse scratch releases|431 |
|Final chat releases|27;includes3 held-done abort cases |
|Whole-context clear/error releases|789 |
|Outbound result/header transfers|3;70 result regions released by the next test owner |
|Separate capacity-blocker releases|61 |
|Pending-read clear/take barriers|24 |
|Packed92-bit reads|99584,all values/metadata checked |

Write arithmetic:1662 complete physical polynomial writes x256 =425472,
plus15 interrupted prefixes x32 =480,plus3 outstanding PWM values after
parent HALT. Only282624 writes belong to the24 completed arithmetic schedules;
the other143331 are checked expected-error/reset work. None is a signature
acceptance count.

Read arithmetic:8192 z +9216 corrected-low +11520 w1 +9216 ct0 +49920 key
+2880 sentinel +3904 blockers +2048 original-y +2304 original-low +384 chat
=99584. Of these,35840 packed words=143360 coefficients are whole result
vectors from24 completed schedules;w1 includes another2304 preflight reads.

Normal phase peaks reconstructed from N/X/F allocation intervals,including
one test sentinel,are31/43/57 regions at levels2/3/5. Excluding that sentinel
the phase uses30/42/56;retained result+key uses28/40/54. Artificial capacity
blockers are separate stress cases. Earlier matrix-generation peaks remain
unchanged. These are logical storage/work counts,not new fitted ALMs/M10Ks,
Fmax,slack or sustained throughput.6.757ns SDC is unchanged;no new synthesis.

## Stage5N.4h.1 ownership/reuse/FNTT(c) work counts

Fresh51-command gate:24 successes,12 expected errors,15 reset/fault aborts;
36 normal completions.18 real key preparations,24 mask vectors and51 full
matrix/challenge preparations produce the actual sources. Eight successful
executions per level reuse six level/nonce fixtures.

| Observed work | Count |
|---|---|
|Atomic matrix+challenge handoffs|42;no partial transfer |
|Dead-yhat releases|211,including3 interrupted release prefixes |
|Forward requests/results|39 /33;30 physical successes,3 source-ID rejects,6 partial resets |
|Actual chat scalar writes|7875 =30 x256 +6 x32 +3 outstanding values after parent HALT |
|Raw-c releases after valid chat|27;includes3 held-result reset cases |
|Normal clear/error releases|354 adopted/new regions |
|Outbound whole-context transfers|3;39 regions released by the next test owner |
|Capacity-blocker releases|66;separate from design-owned data |
|Pending-read clear/take barriers|24 |
|Packed92-bit reads|85760;every value and metadata tuple checked |

Read accounting:1536 chat +11520 w0 +11520 w1 +39936 prepared-key +12288
raw-y +2304 sentinel +4224 capacity blockers +2048 original yhat +384 raw c
=85760. Original yhat/c reads belong to preflight rejections whose previous
owners remain intact. Final successful chat readbacks check6144 coefficients
=24 x256. Error/reset work does not count as a successful signing attempt.

Retained key+y+w0+w1+chat uses25/35/47 regions at levels2/3/5. This phase's
temporary c/chat overlap uses26/36/48,excluding sentinel/blockers;earlier
matrix generation has a larger peak. No new banks/engines/payload RAM.
These are functional work/storage counts,not measured system throughput.
No new synthesis/Fmax/ALM/slack result;6.757ns SDC remains unchanged.

## Stage5N.4g functional work and storage

Fresh challenge capture:81 commands =24 successful executions +39 expected
errors +18 reset/fault aborts.63 normal completions;8 successes per level.
21 actual key preparations and27 actual mask/matrix vectors reuse three
published KeyGen SK inputs and six distinct level/nonce combinations.

| Observed work | Count |
|---|---|
|Pack commands/results|366 /360;6 interrupted;354 successes,3 value errors,3 frame errors |
|Accepted pack inputs|90895 scalar coefficients,including checked error-drain/reset prefixes |
|Packed outputs|6317 exact64-bit words |
|Formatter body|6162 accepted8-byte words;15 invalid-byte termination beats |
|Raw hash descriptors/results|75 /66;9 interrupted before complete raw retirement |
|Raw absorption|7962 words;includes exact zero-fill after abandoned body |
|Actual digest output|201 x16 =3216 bytes;includes discarded error hashes and reset prefixes |
|SampleInBall descriptors/statuses|39 /33;6 interrupted partial c jobs |
|c scalar writes|8640 =33 x256 +6 x32;includes bad-status and aborted work |
|Packed92-bit reads|171264;all source,result and blocker values checked |
|Normal c releases|30 =24 successful clear +6 bad-status cleanup |
|Separate capacity-blocker releases|69 |
|Pending-read clear barriers|24 |

Read accounting:1536 c +69888 prepared-key +21504 y +21504 yhat +24192 w0
+24192 w1 +4032 sentinel +4416 capacity-blocker words =171264. c readbacks
contain6144 coefficients =24 x256. Each successful retained c occupies one
736-byte region;existing sources retain28/39/53 regions,so steady sources+c
use29/40/54 regions at levels2/3/5,excluding the test sentinel.

These are functional work counts,not sustained throughput measurements.
No new synthesis/Fmax/area/slack result is claimed;6.757ns remains unchanged.
The new challenge helper and extended packer have not been fitted as a full
Sign path. Main Sign/retry scheduling and performance optimization remain open.

## Stage5N.4f functional work and storage accounting

The fresh matrix/decomposition comparison passes66 commands:24 complete
vectors,24 expected errors and18 reset/fault aborts. There are48 normal
completions.21 real key preparations and27 real mask generations reuse three
published SK inputs. All output expectations are local FIPS-derived values.

| Observed work | Count |
|---|---|
|Forward requests/results|303 /300;297 successful physical results,3 source-ID rejects,3 interrupted requests |
|A sample descriptors/statuses|1192 /1189;3 interrupted |
|A absorption|5960 words =5 per descriptor;40528 meaningful bytes =34 per descriptor |
|Row requests/results|210 /204;6 interrupted |
|Decomposition requests/results|198 /195;3 interrupted between low/high finish ACKs |
|Scalar writes|1060230,all compared |
|Packed92-bit reads|102336,all compared |
|Helper temporary releases|1257 |
|Helper clear/error releases|644 |
|Separate test-blocker releases|47 |

Scalar writes by owner phase:76128 forward +304480 A sampling +579776 row
arithmetic +99840 decomposition +6 outstanding row writes after injected
parent HALT. The last6 are checked abort work,not successful output. Physical
finish acknowledgments:297 forward +1189 A +2264 row +387 decomposition.
Reset between decomposition commits leaves a complete low and uncommitted
high;global reset discards both parent results without successful credit.

Read accounting:8192 yhat +9216 w0 +9216 w1 +53248 retained-key +16384
original-y +3072 sentinel +3008 capacity-blocker words =102336. The first
26624 words x4 coefficients =106496 final coefficients from24 complete
vectors. Source/blocker reads establish preservation through errors/clear.

Normal successful peak allocations,including one unrelated test sentinel,
are34/46/62 regions at levels2/3/5. Without that sentinel the schedule uses
33/45/61 regions at peak. Capacity tests deliberately fill extra regions;
their all-case peak is46/46/62 and is not the normal level2 schedule. The
workspace address budget is19/25/33,with full source+workspace plans35/47/63;
an address leased for future use need not be physically allocated yet.
Physical banks remain four1024 x92-bit arrays;these are logical lifetimes,
not new fitted area measurements.

This is a sequential functionality checkpoint. No fitted Fmax,ALMs/slack,
complete Sign latency or sustained full-operation throughput is measured.
The6.757ns constraint remains unchanged;PPA work is still deferred until
complete functionality/output verification. Whole-signature retry work and
the final memory schedule are unfinished.

## Stage5N.4e hash/mask functionality checkpoint

78 commands yield27 complete vectors,36 expected errors and15 reset/fault
aborts. The27 vectors contain9 x(4+5+7)=144 complete polynomials;144 x256=
36864 consumer-checked mask coefficients. Additional error/reset work is
checked without crediting successful output:total scalar writes49094=
191 x256 +198 partial values. Packed reads83136=9216 mask +69888 retained-key
+4032 sentinel words. Descriptor counts60 mu,51 seed,197 mask include reset
work;retirements57,48,191. There are169 normal mask releases.

The schedule intentionally runs mu,private seed and each mask sequentially,
waiting for physical engine retirement between descriptors. It establishes
correct bytes and ownership,not a throughput improvement. No fitted Fmax,
ALMs/slack or end-to-end Sign cycles are measured in this checkpoint. The
6.757ns integration constraint is unchanged;it is not a new achieved Fmax.
Prepared key payload plus one y vector uses16/22/30 existing regions at
levels2/3/5. Later full-operation scheduling/retry and PPA measurement remain.

## Stage5N.4d key preparation and storage reuse

165 commands =95 successful keys +62 expected errors +8 reset/fault aborts.
Accepted transform requests1816 =1200 Pre-NTT +616 ordinary forward.
Physical NTT retirements are1805 successes +6 real source-ID rejections;
five further requests are interrupted by reset/fault. Six physically complete
results have deliberately corrupted observed tags and are discarded by the
preparation owner;1799 transforms pass its result checks/source-release step.

Checked scalar writes1013992 =551881 decoded raw coefficients +462111
transform values.462111 =1805 x256 complete result values +31 partial
writeback values before reset. Public/privileged packed reads115776 =105728
prepared-key words +10048 sentinel words(157 non-reset cases x64). The
105728 key words x4 =422912 retained successful coefficients,including332800
from75 official KeyGen SKs.95 additional held consumer-read responses check
the clear barrier and are logged separately,not counted in115776.

96 context publications =95 normally completed prepared keys +one valid
held-done context reset before retirement;that aborted case is not credited
as a successful completion. Clear releases1652 retained polynomial regions;
normal source retirement releases1799;error cleanup releases318 more owned
raw/replacement/result allocations. The live allocation monitor observes
peak13/18/24 key regions at levels2/3/5,matching N+1;physical bank dimensions
are unchanged. Logical payload sizes are listed in MEMORY_MAP.md.

The first key witnesses all child backpressure channels;stall occurrence is
not required for every individual key. The full workload has1106 held-done
cycles,855 retained-READY probe cycles,85 load-command stalls,1187 NTT-command
stalls,4177 release stalls,196 load-done stalls,4741 NTT-done stalls and665
clear-barrier cycles. Outer ownership is witnessed for3170205 cycles. These
include artificial stalls,foreign sentinels,readback and cleanup:they are not
production preparation/full-Sign latency or throughput benchmarks.

All57 prior RTL files and6.757ns SDC are unchanged. The new control/header
client has no polynomial RAM or duplicate engine/bank tree. No new fitted
ALM,Fmax,setup/hold slack,netlist or full-system coverage result is claimed;
functional integration continues before PPA optimization.

## Stage5N.4c2 shared-service key ingestion

The production shared-service gate preserves the client workload:
138 commands =95 successes +38 expected errors +5 resets;449992 checked
scalar writes =422912 successful +16585 error prefixes +10495 reset prefixes.
105728 packed readbacks x4 =422912 successful coefficients,including332800
from75 official KeyGen secret-key inputs.

Additional work is133 independently checked sampled sentinel polynomials
(8512 packed reads),three17-byte raw hashes and three held public-read
responses.95 valid keys are then consumed by real read-only CNB operations.
The DMA schedule adds95 x(1 metadata check +64 arithmetic words)=6175
internal reads;these are not counted in the105728 public key-word readbacks.
Each of three levels exercises eight
six-cycle prior-owner holds. Acceptance/held-ownership/rollback counters are
verification witnesses,not production latency or throughput benchmarks.

No fitted ALM/Fmax/slack result is produced for this new production wiring.
The6.757ns constraint stays unchanged;PPA work remains deferred until the
complete functional integration is ready.

## Stage5N.4c1 key-loading measurements

138 commands =95 successful keys +38 expected errors +5 reset-aborted keys.
449992 exact scalar writes =422912 successful coefficients +16585 error
prefix coefficients +10495 reset-prefix coefficients. Successful readback is
105728 packed92-bit words x4 =422912 coefficients. This includes all75 official
KeyGen secret keys,which contribute332800 coefficients. The additional
boundary cases reuse existing known keys;they are not extra official cases.

The client serializes coefficients and waits for physical word ACKs before
polynomial finish. The focused harness adds deliberate allocation/write/finish/
release/read stalls,so its runtime is not a production signing throughput
benchmark. No previous RTL or6.757ns SDC changed;no new ALM,Fmax,slack or
full-operation cycle result is claimed. Optimization remains deferred.

## Stage5N.4b signing hash test measurements

167 commands =128 successes +34 expected errors +5 reset-aborted requests.
52618 accepted absorption words include verified aborted prefixes.
Finite SHAKE output7760 bytes =6464 success +1296 invalid-request drain
diagnostics.29 peer-core jobs add464 separate checked raw bytes,not included
in7760.6400 mask coefficients =25 complete polynomials;9 actual RTL digest
forwards form dependent commands. Python/C checks154 intended messages/
420639 bytes and26 masks(including one source for a reset-aborted request).

The formatter uses1024 prefix bits +128 merge bits plus control. It deliberately
does not push and pop its reservoir simultaneously;this is a functional
foundation,not a one-word-per-cycle claim or signing throughput result.
The existing16-bit service length caps a mu absorption at65535 total bytes;
tests exercise that boundary and reject overflow. No existing RTL,Fmax,area,
slack or clock-target change.6.757ns SDC remains unchanged. Whole Sign latency
and throughput remain unmeasured.

## Stage5N.4a decoder measurements

129 commands produce124 completions(92 success,32 expected errors) and5 reset
aborts. Exact emitted coefficient count436424 =409600 from successful keys +
16585 tentative error prefixes +10239 reset prefixes. The75 official keys
account for332800 successful coefficients. There are46970 accepted64-bit input
words and121 accepted headers across the directed campaign.
C checks128 full key fixtures/549888 coefficients;this includes complete source
keys for malformed-frame/abort cases,so it differs from emitted RTL prefixes.

Witness totals:872 held-header cycles,253519 held-coefficient cycles and682406
blocked-input cycles,plus774 deliberate done/reset hold checks. These measure
the directed stalled test,not a signing throughput benchmark. The decoder emits
at most one coefficient/cycle while reservoir data is available and accepts a
new64-bit word when fewer than one coefficient's bits remain. No simultaneous
input/output beat is claimed. Storage is1024 header bits +76 reservoir bits
plus control metadata,not a full encoded-key RAM. No new Fmax/area/slack or
operating-frequency claim;6.757ns SDC and existing production RTL are unchanged.

## Stage5N.3 memory-path measurements

| Focused campaign | Observed work |
|---|---|
| sign_dma |71 commands,65 completions,21 expected errors,6 resets;14284 exact scalar writes,3570 acknowledged packed writes |
| sign_service |33 commands,30 completions,9 expected errors,3 resets;192 sampled source words +768 exact result words |

The DMA count includes verified partial write prefixes later canceled by reset.
The service result count is768x4=3072 coefficients;source count is192x4=768.
These are directed campaigns with imposed stalls,not signing throughput figures.
sign_process can accept one x4 group/cycle unstalled,but this sequential DMA
uses the existing one23-bit coefficient/write beat and two word caches. It is
not a four-coefficient-per-cycle full-memory datapath. Decompose writes512
coefficients;Mhint writes256;CNB writes none. All read/commit/retirement overhead
must be included in future operation measurements.

No synthesis,Fmax,area or timing improvement is claimed. The6.757ns constraint
is unchanged. Full Sign/Verify latency and throughput are not measured yet.

## Stage5N.2 focused process counts

sign_process accepts up to one4-coefficient group/cycle with one elastic
register stage. This is an interface capability,not an integrated throughput
measurement. The directed test accepts7752 groups and returns7746 results;
six held groups abort on reset.45 returned groups are expected errors.
Thus7701 valid arithmetic groups cover30804 lanes;180 error lanes are checked
for zeroed payloads.117 full polynomial packets are included.
7509 simultaneous replacements,2865 input stalls and2903 output stalls are
deliberately exercised. Per-polynomial hint counts include256,so a9-bit count
is required. CNB failure is a sticky prefix OR,not a count.
No Quartus/PPA measurement or operating-frequency claim is made for the new
process. Existing6.757ns integration SDC remains unchanged.

## Stage5N.1 ownership relocation

All key-byte/hash/read totals below remain unchanged in the freshly rerun
full_keygen and nist_keygen gates. The local simulated campaign duration is
6676943064ps,identical to Stage5M. Local ownership witness:988082 owned cycles,
195 post-completion cleanup-owner cycles,52 unowned-idle cycles. NIST witness:
9142284 owned,2225 cleanup-owner,151 unowned-idle cycles. These count the whole
directed workload with imposed stalls;they are not per-key throughput figures.
No extra request/response pipeline or memory is added. No new area,Fmax or
slack measurement is claimed;6.757ns remains unchanged.

## Stage5M NIST functional counts

All75 cases succeed:25 at each level2/3/5. Successful key bytes total
25*(3872+5984+7488)=433600,or54200 accepted64-bit output words.
PK hash inputs:25*(164+244+324)=18300 words;tr:75*64=4800 bytes.
Encoding field reads:25*64*(16+23+31)=112000 metadata-checked words.
These counts include no aborted prefixes. Fork witnesses are3632 host-ahead
and17452 hash-ahead cycles. Output stalls are deliberate,so these are not
sustained-throughput results. All46 RTL files and the6.757ns constraint are
unchanged from Stage5L. No new Fmax,area,slack or full-top synthesis is claimed.

## Stage5L complete-key functional counts

No new clock,Fmax,placed-area or slack measurement is claimed. The fixed
6.757ns constraint remains unchanged;the Quartus top is still the historical
scalar helper. Full-key cycle totals include sampling,compute,word packing,
host/hash stalls and final cleanup;no throughput benchmark is inferred here.

Eight successful operations emit36704 valid key bytes =4588 output words.
The full capture contains5433 words =43464 bytes;the extra845 words =6760
bytes are reset-aborted prefixes. Do not count them as successful keys.
The successful set is six level2 keypairs,one level3 and one level5.

There are2058 actual PK absorption words =16464 bytes,including abort prefixes.
656 tr bytes =512 from successful operations +144 from partial/aborted ones.
11179 field read responses include metadata checks for aborted prefixes;
complete byte comparison validates the data encoded into keys.
Fork witnesses434 host-ahead cycles and1939 hash-ahead cycles demonstrate
both acknowledgement orders in this workload. They are not performance
targets and do not measure sustained key-generation throughput.

## Stage5K functional packing/rounding counts

No synthesis or new Fmax/ALM/slack measurement is performed. The6.757ns
constraint remains unchanged. Bitpkg's87-bit reservoir size is a logical RTL
width,not fitted area or a promised frequency.

Rounded KeyGen writes190224 values =172304 from the polynomial baseline
+70 complete rounded polynomials x256. There are35 rounded pairs:34 delivered
rows plus the completed first row subsequently reset while held.
Public readback12800 words =8448 baseline +68 retained rounded polynomials
x64 words. The additional68 correspond to34 successfully consumed rows.

Bitpkg checks2482 accepted64-bit words=19856 bytes,including valid prefixes
of failed/aborted packets. Successful packets alone contain16832 bytes.
The independent C comparison covers66 full valid fixture inputs,including
abort/recovery fixtures,total18496 bytes;these are different denominators.
Do not report this stimulus-dependent word count as sustained throughput or
whole-KeyGen key generation latency. Full-key serialization/hash work remains.

## Stage5J functional work and counting

Current result is functional polynomial computation,not a new timing/area run.
No change to the6.757ns constraint or new ALM/Fmax/slack claim is made.
The controller samples/transforms sequentially and waits for caller row reads.

Seven successful operations produce34 t rows (18 across the three ordinary
levels plus16 in four level2 recovery runs).8448 public words contain33792
coefficients:8704 t values plus25088 retained-secret/transform values.

The scalar-write count is172304:673 complete polynomials x256 values plus
8 secret-prefix values and8 accumulator-prefix values from reset tests.
This includes internal products/sums/transforms,not just the34 final rows.
Actual elapsed KeyGen latency includes caller stalls and all sampling/loading,
compute,output and cleanup phases. Byte encoding/hash work is still absent;
do not label this whole-KeyGen throughput or multiply core Fmax by row counts.

## Stage5I functional observations

Seed-driven row capture:190 source commands =20 successful seed expansions,
163 successful samples and7 rejected adapter commands. Each expansion consumes
five64-bit absorption words and produces eight128-bit output beats;all2560
bytes match. Sampling consumes1103 formatter words in this workload.
The row workload remains13 complete rows,27 rejects and7 reset aborts with
161 NTT commands and55 ADDs. Re-expansions include resets and deliberate
level switches in negative-fixture setup;this is not the final KeyGen schedule.

No new synthesis,ALM,Fmax,slack or throughput claim is made for this added
seed/control path. The historical scalar top and6.757ns constraint are unchanged.
Seed collection,formatting,sampling and compute remain sequentially scheduled;
whole-KeyGen latency cannot be inferred from standalone NTT cycle counts.
Correct full-operation outputs still precede PPA optimization.

## Stage5H row-scheduler observations

A successful l-column row issues l PWM commands,l-1 in-place ADDs and one inverse
NTT. Thus levels2/3/5 use4/5/7 PWM,3/4/6 ADD and one inverse respectively.
Secret transforms are retained across rows;the test uses both ordinary NTT and
eligible Pre-NTT. No new arithmetic pipelines or parallel cores are added.

Payload DMA reads128 words per PWM,128 per ADD and64 per inverse:256*l-64 word
reads per row. Payload writes64 words per result:128*l per row. These counts
exclude metadata validation reads and external observation. The scalar engine
still needs one23-bit coefficient per beat;this is not LightHD32-cycle loading.
One accumulator and one scratch region are reused;the coefficient result has
its own region. Each is64 words x92 bits. Total bank geometry stays46KiB.

The campaign checks13 full rows,27 rejections,7 resets;163 samples,161 NTT/Pre/
PWM/INTT commands,55 in-place ADDs,96264 scalar writes,24066 packed writes/acks,
12544 public word reads and6918 old-word cache reads.160 held-row and4 pending-
read refusal checks pass. These are source workload counts,not sustained
throughput,full-KeyGen latency or a new fitted Fmax/area/slack/RAM result.
Rows are fully staged and execute sequentially. Overlap/PPA work stays deferred.
## Stage5G banked process observations

23 sample jobs,15 NTT commands and71 process commands pass. Processing has34
successes,33 expected rejections and4 reset aborts. Actual accepted arithmetic
operands8978,completed outputs8976;the two extra inputs are canceled by reset.
Stored low/high/residue writes are separately checked,including partial aborted
work. Full campaign:22297 scalar writes,5574 packed writes/acknowledgements,
8512 exact92-bit read responses. These counts are workload evidence,not a
sustained throughput measurement or full-KeyGen latency.

The client reads A and B as two92-bit words for each binary four-coefficient
group:128 reads per ADD/SUB,64 per P2R. It feeds one coefficient into the existing
elastic arithmetic stage,waits for the residue/low write and,for P2R,the high
write,before advancing. Each unary result region uses64 packed writes. P2R uses
two regions/128 writes. Requests/responses,packing acknowledgement and exclusive
ownership add cycles;the one-coefficient-per-cycle unit rate is not the whole
DMA rate. Pipelining/overlap is deferred until full-operation correctness.

Witnesses:36 wait/source-release refusal checks,188 held-result release checks,
4 pending-read refusal checks and22 actual partial-P2R-publication snapshots.
Logical payload stays46KiB;two92-bit word caches and control add unsynthesized
logic. No new fit,Fmax,placed-area,slack or physical RAM count is available.

## Stage5F banked NTT observations

The real banked connection passes16 sample jobs/54 commands,with30 completed
arithmetic results,21 expected rejections and3 reset aborts. It checks9746 scalar
DMA values,7712 engine outputs and2944 exact92-bit word reads. Witnesses:
24 destination-wait cycles,206 held-completion cycles,295 public read-response
stall cycles,33 source leases,4 compute-refusal checks during a pending read
and120 blocked result-release checks while completion is held.

DMA reads one92-bit word and holds it through four scalar NTT input handshakes.
Thus a unary load needs64 word reads/256 scalar transfers;PWM needs128 reads/
512 transfers. Request/response control adds cycles. Result packing writes64
words for each successful operation and pauses the engine while a packed word
awaits acknowledgement. Sampling and compute are sequential. This reduces RAM
request count from the old scalar DMA but does not implement LightHD's32-cycle
wide NTT loading or establish maximum sustained/full-operation throughput.

No NTT arithmetic RTL,pipeline,core count or internal compute latency changes.
Memory payload remains46KiB. This new controller has no synthesis/fit result;
there is no current banked-system placed-ALM,Fmax,slack or physical RAM count.
The6.757ns benchmark remains unchanged;PPA optimization is deferred.

## Stage5E connected packed-bank storage observations

Source workload104 jobs produces88 complete polynomials and5632 exact92-bit
word readbacks. It observes8 occupied-region stall cycles,1070 held-read cycles
and50 simultaneous read-request/coefficient-write handshakes. Two held responses
are reset. Publication includes the final word acknowledgement and hash drain.

Each context packs four coefficients,then pauses until its word write is
acknowledged;the implementation allows one outstanding sampler write per bank.
This is a correctness baseline,not a maximum-throughput claim. Public checked
reads use one global outstanding response and wait through the synchronous RAM
and response-register stages. Memory capacity is unchanged at46KiB payload;
descriptor/packing/control registers add logic that has not been synthesized.
The scalar NTT wrapper and its measured cycles are unchanged. Full-system
Fmax/placed area/throughput remain unmeasured for this new path.

## Stage5D bank-memory foundation observations

Published/selected logical capacity:four1024x92-bit banks=376832 bits=47104
bytes=46KiB. This is16 times the old four-slot payload2944 bytes,not a physical
M10K count. Each bank has two ports and each92-bit word holds four coefficients.

The focused test observes1031 cycles with all eight requests accepted,4112
dual-read same-address pairs,73 serialized collisions,3075 request stalls,
3034 response stalls and14807 response replacements. Each unblocked port can
accept one word per cycle. These are source-test observations,not a clock/Fmax
or complete system throughput result. No synthesis/fit or RAM inference measured.

The current NTT wrapper remains one23-bit coefficient per beat;LightHD's32-cycle
input loading needs the corresponding wide engine input/controller integration.
The memory foundation alone does not change any measured NTT cycle count.

## Stage5C shared-service observations

The focused test sees67 cycles with both a raw and sampling owner,333 with
two raw owners,60 raw-output stalls,298 raw-completion stalls and44 held seed
result cycles. One simultaneous descriptor conflict confirms raw priority.
These count ownership/handshake conditions,not overlapping permutation clocks.
26 commands produce1699 checked SHAKE bytes and1792 sampled coefficients.
Finite raw transfers honor partial bytes at the136/168-byte rate boundaries.

No added hash cores;the128-byte expansion collector adds logical register state.
The current Stage4 top leaves RAW_SERVICE disabled. No fit/synthesis was run;
do not infer current placed ALMs,Fmax or throughput from old Stage2 reports.

## Stage5B message-builder observations

The formatter emits five64-bit words for seed/matrix messages,or nine for
secret messages,after descriptor acceptance. It can emit one word per cycle
when the hash service is ready. The final word has two valid bytes. Message
completion is separate from hash completion;no full-KeyGen latency is measured.

The focused165-command test observes111 descriptor,288 input,757 completion and
671 hash-output stall cycles;883 accepted words include7 reset-aborted-prefix
words. Python matches5888 SHAKE bytes. These workload witnesses are not FPGA
Fmax or system throughput. The main top is unchanged;no new synthesis/PPA.

## Stage5A process-unit observations

The isolated elastic unit observes10009 same-edge output/input replacements,
3505 blocked-input cycles and3511 held-output cycles in its10349-case workload.
It permits one coefficient per cycle when both ends are ready. These observations
do not establish FPGA Fmax or full-polynomial/Dilithium throughput. The unit is
now connected through Stage5G above;its banked PPA remains unmeasured.

The candidate four-slot KeyGen schedule in MEMORY_MAP.md requires16 forward
transforms at level2 if s1 is regenerated for each row,instead of4 with cached
transforms. This tradeoff is not adopted yet. Record its impact when deciding
the full-controller memory schedule;do not hide it in a compute-only comparison.

## Current boundary:Stage4 all three engines through memory

The top is now keccak_sampler_ntt. No Stage4 synthesis/fit has been run;there
is no current integrated placed-area,Fmax,slack or RAM-packing claim. Existing
output_files reports still describe the earlier Stage2 producer-only top.
The6.757ns benchmark constraint is unchanged. PPA optimization stays deferred.

Stage4 checks4096 sampled values,9745 DMA loads,7713 NTT outputs and11776
stored reads.30 complete result polynomials account for7680 NTT outputs;
33 additional outputs were accepted before a reset. The other abort targets
were during loading and computation.24 full-pool wait cycles,188 completion
stall cycles,699 read-response stall cycles and33 source-lock observations
are functional witnesses,not a throughput rate. All earlier Stage2/3 cycle
observations remain scoped to their own test workloads.

The initial DMA waits for each synchronous response/engine acceptance before
requesting the next coefficient. NTT compute/sampling are scheduled serially.
Its latency/throughput must not be equated with the standalone engine's no-gap
wrapper numbers or the internal four-butterfly issue rate. Wider/pipelined DMA,
more banks and overlap are later measured optimization options.

Relocated standalone NTT correctness was refreshed. Its original branch PPA
under quartus/ntt/results is historical;no fresh relocation fit was requested.

## Historical source boundary:Stage3 Keccak+sampler+memory

The Stage3 project selected keccak_sampler_memory with four logical
polynomial slots. Stage3 has source/Python functional results only;there is no
fresh Stage3 fit,Fmax,placed-area,slack or RAM-inference claim. Timing/resource
measurements below describe the prior Stage2 top and are historical.

The Stage3 workload checks23180 writes (22528 complete values+652 aborted-prefix
values),22528 readbacks,88 releases and99 rejected reads. It observes8 full-pool
blocked command cycles,1321 held-response cycles and170 concurrent read/write
cycles. These are functional witnesses,not throughput benchmarks. The configured
payload is23552 logical bits/2944 bytes;FPGA RAM packing is not measured yet.

## Historical measured boundary:Stage2 Keccak+sampler

The previous Stage2 project synthesized the real Keccak+sampler helper,
not a complete Dilithium accelerator. The project grows with the
controller,memory,NTT and process blocks. The user selected an initial148MHz
target:6.757ns,unchanged. The first combined fit is complete:129.18MHz worst Fmax and-0.984ns setup;
the requested148MHz timing target is NOT met.

Current main trial8:137.74MHz worst Fmax,-0.503ns setup,+0.157ns hold and11293
placed ALMs. Structural guards pass. On2026-10-20 the user stopped timing
optimization in favor of functionality-first integration. Fmax,area and
throughput optimization follow correct full-operation outputs;the timing miss
does not block Stage3 memory. The initial fit table below is historical.

Do not sum standalone module area or substitute the148MHz target for fitted
Fmax. All resource headlines use actual placed ALMs. Physical data I/O are
virtual/excluded from this internal benchmark;board timing is not closed.

## Functional-workload cycle observations

`sim/dilithium/stage2_jobs.csv` records104 jobs with case/ID/core/mode/param,
abort flag,and clock indices for command acceptance,first SHAKE beat accepted,
first sampler beat accepted,first/last coefficient,source stop and retirement.
The focused testbench has a6757ps rising-edge interval. Below are the22
successful jobs in each mode from this paired,stalled,boundary-length workload.

| Mode | Command acceptance → last coefficient | Command acceptance → first SHAKE beat accepted |
|---|---:|---:|
| Matrix A |750–1117 cycles|See stage2_jobs.csv|
| Secret |507–909 cycles|See stage2_jobs.csv|
| Mask |744–1185 cycles|See stage2_jobs.csv|
| Challenge |981–1921 cycles|See stage2_jobs.csv|

These ranges include deliberately varied input lengths/source gaps,peer work,
and output/status stalls. They are not isolated sampler compute latency or a
continuous-throughput benchmark. Negative timestamp fields mean the event was
not reached before an error/abort. Completion rates must later be measured
under a specified workload,with first-to-last intervals and pipeline overlap
boundaries. No full KeyGen/Sign/Verify latency is claimed.

Current functional observations:drops99,bridge cancellations140,blocked hash
cycles33316,dual-owned cycles37383,and upstream-retirement waits293. The queue
was full for34198 observed cycles,with128 simultaneous push/pop events. These prove
the exercised control paths;they are not coverage percentages or throughput.

## Initial synthesis record

Combined settings: Cyclone V5CGXFC7C7F23C8,Quartus25.1std,seed1,HIGH PERFORMANCE
EFFORT,physical register retiming OFF. Both engines' accepted RTL remains
unchanged. The new scalar SHAKE-mode decode replaced a port expression that
Quartus interpreted as an implicit net;that initial diagnostic run was stopped
and excluded. The current full fit uses the corrected source.

The combined TimeQuest helper preserves original sampler payload/register
guards with hierarchy-qualified names. Current structural guards pass,while timing misses the target as recorded below. Pipeline/area
optimization was attempted before memory. That ordering is now superseded by
the user's functionality-first decision;the benchmark constraint stays intact.

## First combined fit ? functional PASS,timing target OPEN

| Metric | Initial complete Stage2 fit |
|---|---:|
| Actual placed ALMs |11059|
| Registers |7396|
| Combinational ALUTs |16025|
| M10K / DSP |1 /0|
| Slow85 / Slow0 Fmax |129.18 /134.16MHz|
| Requested period |6.757ns (about148MHz),unchanged|
| Worst setup slack |?0.984ns|
| Worst hold slack |+0.166ns|
| Slow85 / Slow0 setup TNS |?1118.959 /?493.897ns|
| Hold TNS |0 at all four corners|
| Minimum pulse-width slack |+1.202ns minimum;positive at all four corners|
| Accepted sampler register guards |PASS,including original64-bit secret banks,140-bit commit payload and128 sign bits|

Quartus full compilation succeeds,but its timing-requirements warning is real.
The critical path is Keccak core1 absorb_block_full ? state_array registers,
with7.468ns data delay at the Slow85 corner;about78% of that path delay is
interconnect. See critical_paths/slow_85C_setup.rpt. It is not a sampler oracle
mismatch. The combined project has physical register retiming OFF,whereas the
standalone Keccak project enabled it. Retiming/placement/fanout are candidates
for a controlled review;their individual contribution is not yet measured.

This is an initial subsystem baseline,not an accepted148MHz implementation or
full-system PPA result. No target was relaxed. The earlier choice to close timing
before memory is superseded by the functionality-first decision above.
Initial immutable evidence:stage2_subsystem_initial.zip
and its SHA256 sidecar under evidence/.

### Timing trial1:settings only,no measured gain

Keep global retiming OFF,enable it only for hash hierarchy,and explicitly
disable it for sample hierarchy. Enable combinational physical synthesis,
register duplication and maximum router timing effort as in standalone Keccak.
No RTL,clock period or functional workload changes. The completed fit exactly
reproduces11059 placed ALMs,129.18MHz and-0.984ns setup. Original sampler
register guards PASS. Retiming runs but reports0ps estimated improvement;
this trial did not close timing.

### Timing trial2:lane-qualified Keccak absorb writes,rejected

Only src/keccak/keccak_core.sv changes:an absorbed64-bit word writes its
destination lane;the other lanes retain their state. Permutation and padding
still update the full state at the same edge. This removes absorb-dependent
control from a shared1600-bit write enable without adding a cycle. The initial
accepted Keccak revision remains preserved in the immutable import archive.

Focused104-job source/Python checking and12 checker fault gates PASS with23081
exact values. All104 workload cycle-witness rows match the initial snapshot
byte-for-byte. The full standalone Keccak regression passes904 UVM transactions
plus all dual suites,with zero UVM errors/fatals. After a declaration-only
Quartus syntax correction,the exact current source again passes the104-job
check;all6364 published NIST outputs match exactly. The fit worsens to11758
placed ALMs,7393 registers,16236 ALUTs,125.20MHz worst Fmax and-1.230ns setup;
hold+0.156ns. Slow0 Fmax127.80MHz. Setup TNS is-1010.976/-632.800ns at slow85/0;
all hold TNS remains0. Keccak3200-bit state and original sampler guards PASS.
The critical path moves to Keccak permutation data,with79% routing delay.
This implementation is rejected and restored to the original state-write form.

### Timing trial3:global routing for the original state enable,rejected

Restore original whole-state writes and name their existing combined enable
`state_array_enable = init_wr_en || state_array_wr_en`,with a keep attribute.
The QSF requests a dedicated global route for this1600-register data enable
inside each core. No generated clock or new cycle is introduced;the real clk
and6.757ns constraint are unchanged. Verify actual global routing in the fitter
report,all3200 state bits and the accepted sampler register guards.

Current-source104 jobs/23081 values and12 checker fault gates PASS;all104 cycle
rows match the initial snapshot exactly. Full904-transaction Keccak regression
plus dual suites PASS,zero UVM errors/fatals. Fitter confirms two dedicated
global control networks,each with1600 fanout. All6364 published NIST outputs
match that trial's source. Final fit:11256 placed ALMs,7402 registers,16081 ALUTs,
93.59/94.63MHz slow85/0 Fmax,setup-3.928ns,hold+0.155ns;slow85/0 setup TNS
-12479.887/-11921.846ns,all hold TNS0. Original Keccak/sampler guards PASS.
Dedicated routing increased control arrival delay;this trial is rejected.
Batch Keccak regressions now
omit recursive waveform recording;GUI waveform recording is unchanged.

The [Cyclone V handbook](https://cdrdv2-public.intel.com/666995/cv_5v2-683375-666995.pdf)
describes using global routing for high-fanout controls including clock enables.
This trial changes routing of a synchronous data enable,not the clock definition
or timing exceptions.

### Timing trial4:original RTL,local clock-enable mapping change

Restore the exact initial RTL(source vector token matches the initial snapshot).
Disable AUTO_CLOCK_ENABLE_RECOGNITION only on hash state_array registers;leave
sampler mapping unchanged. Analysis confirms3200 fewer clock-enable registers:
6153 initially versus2953 now. This selects feedback multiplexers for the two
Keccak states;it adds no clock,cycle or protocol change. Fresh104-job checking/
23081 values and12 checker fault gates PASS. Final fit:12366 placed ALMs,7395
registers,16558 ALUTs,130.92/130.79MHz slow85/0 Fmax;worst setup-0.889ns,
hold+0.146ns. Slow85/0 setup TNS-198.974/-152.546ns;hold TNS0 everywhere.
Original sampler and3200-bit Keccak state guards PASS. This is not timing
closure;its area increase is not accepted as a final design. Critical path is
offset_count through request/start/init decoding to Keccak state synchronous clear.

The [Quartus Standard mapping guide](https://docs.altera.com/r/docs/683283/18.1/design-compilation-user-guide-quartus-prime-standard-edition/controlling-clock-enable-signals-with-auto-clock-enable-replacement-and-direct_enable?contentId=lEZsrgY7vUwiSGtgN95~0Q)
documents this per-register option and its feedback-mux implementation.

### Timing trial5:predecoded launch-offset ready,still open

Retain trial4 mapping while registering the offset-count-zero decision one
cycle ahead. Reset/zero-offset launches set ready;loading a nonzero interval
clears ready;decrementing count1 sets ready for the following zero-count cycle.
The26-cycle launch gap is unchanged. A source invariant checks the flag against
the counter,and a fitted-register guard requires the new flag to survive mapping.
104 focused jobs/23081 exact values and12 checker fault gates PASS;all104 cycle
witness rows match the initial snapshot. Full Keccak904-transaction regression
plus all dual suites PASS,zero UVM errors/fatals. Core SHAKE RTL remains exactly
the initial source whose6364 published NIST outputs passed;only the wrapper's
countdown flag changed. Fit:12356 placed ALMs,7396 registers,16574 ALUTs,
129.27/131.32MHz slow85/0 Fmax,setup-0.979ns/hold+0.164ns. Slow85/0 setup
TNS-205.562/-114.946ns;hold TNS0. Original state/payload guards and the new
offset flag guard PASS. The worst path now crosses sampler generated/source_stop
through bridge discard/ready into Keccak squeeze/permutation counter control.

### Timing trial6:two-slot registered-credit bridge,still open

Keep trial5's local state mapping and offset flag. Replace the one-slot bridge
and combinational ready chain with a two-slot queue. Upstream room depends only
on registered occupancy;draining-context bypass depends only on registered
drain state. Immediate sampler source_stop still cancels that context's head
offer;status retirement checks both queue slots. Simultaneous push/pop remains
possible,without changing external ports or either engine's processing stages.

Fresh104-job source/Python PASS:88 complete,8 expected errors,8 reset aborts,
23089 checked values(22528 complete+561 aborted prefixes),24 mode/param/core
combinations;12 checker corruptions rejected. Four reset phases reach both
owned contexts;phase0 now requires a full two-slot queue. Full-queue cycles34198
and simultaneous push/pop128 are observed. Stops follow discarded release
handshakes;all public offers remain stable under stalls.

This deliberately stalled workload finishes at retirement clock48525 versus
48911 initially. Some individual latencies increase and others decrease due
to changed queueing/peer/stall phases;this is not a sustained-throughput claim.
Command-to-last-output ranges:A750-1117,secret507-909,mask744-1185,challenge
981-1921cycles. Clean trial6c fit:12542 placed ALMs,7581 registers,16711 ALUTs,
one M10K/1024 bits,zero DSP. Slow85/0 Fmax134.77/134.17MHz;worst setup-0.696ns,
hold+0.150ns. Slow85/0 setup TNS-105.438/-59.416ns;all hold TNS0,min pulse-width
slack+1.202ns. Original sampler/Keccak guards,offset flag and all256 queue
payload bits PASS. The remaining worst path is Keccak state-to-state permutation
logic,7.221ns data delay at slow0. Timing remains open.

The first trial6 mapping inferred block RAM for the two-entry payload. It was
interrupted;the first stop failed and a replacement briefly overlapped it.
Both task-owned process trees were then terminated and the generated db and
incremental_db directories cleared. Neither interrupted run is a PPA result.
The active trial6c is a clean full build with ramstyle="logic" on the payload;
synthesis confirms only1024 block RAM bits(the original sampler Ball memory).
The fitted helper must retain all256 bridge payload registers as well as the
original Keccak/sampler registers. No polynomial memory has been added.

### Timing trial7:predecoded absorb-ready,original compact mapping

Remove trial4's clock-enable suppression to restore the original smaller state
mapping. Add one absorb-ready flag per core,maintained from accepted message
words,rate-boundary events and final permutation rounds. An invariant requires
it to equal STATE_ABSORB && !absorb_block_full && !msg_received. The wide write
uses that flag with input valid;the permutation mux uses the current state
directly. No extra absorb/permutation cycle or interface change is introduced.

104 jobs/23089 exact values and12 checker faults PASS;all104 cycle rows match
trial6 byte-for-byte. The fitted helper requires both new flags to survive.
Full904-transaction Keccak regression plus dual suites PASS,zero UVM errors/
fatals. All6364 captured outputs match the published NIST vectors on both cores.
Fit:11204 placed ALMs,7570 registers,15995 ALUTs,1M10K/0DSP. Slow85/0 Fmax
124.72/128.50MHz;setup-1.261ns/hold+0.162ns. Slow85/0 setup TNS
-1618.286/-912.227ns;all hold TNS0. All register guards PASS. The worst path
starts in sampler active_r,through the command-ready mux,into Keccak state
initialization. The permutation-only path is also late(-0.891ns at slow85).

### Current functional implementation:trial8 ownership-qualified command ready

An unowned context is sampler-inactive:reset clears both,commands set both,and
ownership releases only with the external sampler-status handshake. Thus the
extra sampler_job_ready condition is redundant beside !owned. Remove that
combinational feedback from request_valid/job_ready,while checking both
sampler_active implies owned and accepted-command implies sampler_job_ready.
Atomic starts still use the same common handshake and core assignment.

104 jobs/23089 values and12 checker faults PASS;all104 cycle rows match trial7.
Keccak RTL is unchanged from the904-transaction/6364-NIST passing trial7.
Seed1 and an isolated seed2 fit use identical RTL,device,clock and settings.
Both compiles have finished. The main seed1 build reports11293 placed ALMs,
7557 registers,15970 ALUTs,one M10K/1024bits and zero DSP. Slow85/Slow0 Fmax
is138.06/137.74MHz;worst setup is-0.503ns and worst hold+0.157ns across four
corners at6.757ns. Setup TNS is-147.307/-47.642ns at the two slow corners;
hold TNS is zero at all four corners. Keccak/sampler register guards pass.
Evidence:quartus/dilithium/output_files/dilithium.fit.rpt,
dilithium.sta.rpt and stage2_timing8_guard.log. The isolated seed2 experiment
is not selected. Further PPA work is deferred;retain the verified functional
source for Stage3 integration.
