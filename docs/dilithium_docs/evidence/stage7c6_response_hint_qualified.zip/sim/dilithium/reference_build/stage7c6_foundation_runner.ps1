$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l sim/dilithium/stage7c6_foundation.log -do sim/dilithium/reference_build/stage7c6_foundation.do *> sim/dilithium/stage7c6_foundation_console.log
if ($LASTEXITCODE -ne 0) {throw 'Native foundation failed'}
foreach ($marker in @('BRAM_FIFO_PASS','LIGHTHD_DIRECT_MEMORY_PASS','LIGHTHD_NTT_DMA_CAPTURE_PASS','LIGHTHD_HINT_CAPTURE_PASS')) {
  if (-not (Select-String -LiteralPath sim/dilithium/stage7c6_foundation.log -Pattern $marker -Quiet)) {throw "Missing gate $marker"}
}
foreach ($gate in @('lighthd_dma_compare','lighthd_hint_compare','lighthd_hint_selftest')) {
  & 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py $gate *> "sim/dilithium/stage7c6_${gate}.log"
  if ($LASTEXITCODE -ne 0) {throw "Foundation comparison failed: $gate"}
}
'STAGE7C6_FOUNDATION_RUNNER_PASS'
