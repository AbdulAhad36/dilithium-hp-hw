# Read-only detailed analysis of the qualified C25R2 routed database.
project_open dilithium_full -revision dilithium_full
create_timing_netlist -model slow
read_sdc
set destination ../../sim/dilithium/reference_build/stage7c25r2_timing_audit
file mkdir $destination
foreach corner {{slow 85} {slow 0}} {
 lassign $corner model temperature
 set_operating_conditions -model $model -temperature $temperature -voltage 1100
 update_timing_netlist
 foreach {family pattern} {
  unpacker {*|lighthd_bitunpkg:unpacker|*}
  packer {*|lighthd_bitpkg:packer|*}
  process {*|lighthd_process:process_unit|*}
  regroup {*|lighthd_secret_regroup:*|*}
  hint {*|lighthd_hint_codec:*|*}
  keccak {*|keccak_core:*|*}
  sampler {*|sampler:sample|*}
  ntt {*|ntt_core:*|*}
  ntt_dma {*|lighthd_ntt_dma:polynomial|*}
  request_queue {*|bank_request_pipe:*|*}
  dma_control {*|lighthd_process_dma:process_path|completed_r*}
  main_control {lighthd_dilithium:core|state*}
  sign_control {*|lighthd_sign:sign_controller|state*}
  verify_control {*|lighthd_verify:verify_controller|state*}
  bank_control {*|lighthd_memory_port:*|*}
 } {
  set endpoints [get_registers -nowarn $pattern]
  if {[get_collection_size $endpoints]==0} {puts "C25_AUDIT_EMPTY:$family";continue}
  report_timing -setup -to $endpoints -npaths 1 -detail full_path -file $destination/${model}_${temperature}C_${family}.rpt
 }
}
delete_timing_netlist
project_close
puts C25R2_TIMING_AUDIT_COMPLETE
