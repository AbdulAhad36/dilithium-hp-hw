from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c25r1_source_hashes.json').read_text());new=json.loads((rb/'stage7c25r2_source_hashes.json').read_text())
assert len(new)==269 and set(old)==set(new)
for n,d in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
assert {n for n in old if old[n]!=new[n]}=={'src/controller/memory/bank_request_pipe.sv'}
assert 'genvar p,slot;' in (r/'src/controller/memory/bank_request_pipe.sv').read_text()
assert 'period 6.500' in (r/'quartus/dilithium/dilithium.sdc').read_text()
print('C25R2_SOURCE_AUDIT_PASS:269 frozen;only explicit generate/module-scope genvar syntax differs from archived R1;no logic/NIST math/settings changes;153.85MHz target')
