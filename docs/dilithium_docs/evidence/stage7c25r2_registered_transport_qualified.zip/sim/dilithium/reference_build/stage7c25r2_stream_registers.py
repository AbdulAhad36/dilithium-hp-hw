from pathlib import Path
import re,json
q=Path('quartus/dilithium/critical_full');names=(q/'mapped_register_names.rpt').read_text().splitlines();result={}
for key,expr,lo,hi in [('unpacker_words',r'\|lighthd_bitunpkg:unpacker\|words_r',192,192),
 ('unpacker_slots',r'\|lighthd_bitunpkg:unpacker\|(read_slot_r|write_slot_r)',4,4),
 ('unpacker_offset',r'\|lighthd_bitunpkg:unpacker\|bit_offset_r',4,6),
 ('hint_mask',r'\|lighthd_hint_codec:.*\|d_registered_hints',4,4),
 ('hint_coordinates',r'\|lighthd_hint_codec:.*\|d_registered_(row|word)',9,9),
 ('hint_pending',r'\|lighthd_hint_codec:.*\|d_output_pending_r',1,1),
 ('unpacker_window',r'\|lighthd_bitunpkg:unpacker\|bits_r',80,80),
 ('unpacker_window_valid',r'\|lighthd_bitunpkg:unpacker\|window_valid_r',1,1),
 ('bank_request_payload',r'\|bank_request_pipe:bank\[[0-3]\]\.request_pipe\|entries_r',1648,1648),
 ('bank_request_counts',r'\|bank_request_pipe:bank\[[0-3]\]\.request_pipe\|count_r',16,16),
 ('bank_request_pointers',r'\|bank_request_pipe:bank\[[0-3]\]\.request_pipe\|(read_r|write_r)',16,16),
 ('bank_request_order',r'\|bank_request_pipe:bank\[[0-3]\]\.request_pipe\|a_older_r',16,16),
 ('sampling_completion',r'\|lighthd_hash_sampler:hash_sampler\|completion_',18,21)]:
 hits=[n for n in names if re.search(expr,n)];assert lo<=len(hits)<=hi,(key,len(hits));result[key]=dict(bits=len(hits),names=hits)
predecoded=[n for n in names if re.search(r'\|lighthd_process_dma:process_path\|pack_raw_r',n)]
assert len(predecoded)==1,('registered pack selection',len(predecoded))
result['packer_raw_select']=dict(bits=1,names=predecoded)
assert not any(re.search(r'\|lighthd_bitpkg:packer\|gamma_r',n) for n in names),'Obsolete packer gamma snapshot remains'
assert 'WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS' in (q/'retained_registers.rpt').read_text()
Path('sim/dilithium/reference_build/stage7c25r2_stream_registers.json').write_text(json.dumps(result,indent=2)+'\n')
print('C25R2_STREAM_HARDWARE_GUARD_PASS:192word bits/ring state/registered hint mask and coordinates/pending bit/registered pack selection retained')
