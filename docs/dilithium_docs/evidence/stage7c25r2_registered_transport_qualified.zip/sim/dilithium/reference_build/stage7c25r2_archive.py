from pathlib import Path
import hashlib,json,zipfile,re
r=Path.cwd();h=r/'sim/dilithium';q=r/'quartus/dilithium';rb=h/'reference_build';ev=r/'docs/dilithium_docs/evidence'
target=ev/'stage7c25r2_registered_transport_qualified.zip';side=target.with_suffix('.sha256')
assert not target.exists() and not side.exists(),'Create-only archive already exists'
def read(p):
 b=p.read_bytes();return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8',errors='replace')
for leaf,marker in [('recovered_collection.log','STAGE7C25R2_RESULT_COLLECTION_PASS'),('native_runner.log','STAGE7C25R2_NATIVE_RUNNER_PASS'),('uvm_runner.log','STAGE7C25R2_UVM_RUNNER_PASS'),('scope_report_recovery.log','STAGE7C25R2_PHYSICAL_RECOVERY_PASS'),('cycle_audit.log','STAGE7C25R2_CYCLE_AUDIT_PASS')]:
 assert marker in read(h/('stage7c25r2_'+leaf)),leaf
for leaf,marker in [('lighthd_main_compare.log','LIGHTHD_MAIN_NIST_COMPARE_PASS:210'),('lighthd_main_protocol_compare.log','LIGHTHD_MAIN_PROTOCOL_COMPARE_PASS:88'),('lighthd_main_selftest.log','90/90 deliberate corruptions rejected')]:
 assert marker in read(h/('stage7c25r2_'+leaf)),leaf
foundation=read(h/'stage7c25r2_foundation.log')
assert '# ** Fatal:' not in foundation and '# ** Error:' not in foundation
for marker in ('LIGHTHD_UNPACK_PIPELINE_PASS:1241 packets/310504 coefficients/29 invalid/6 resets/6 occupied resets','LIGHTHD_BANK_PIPE_PASS:20732 accepted/20720 issued/20708 replies','LIGHTHD_HINT_PREFIX_PROOF_PASS:786432 combinations','LIGHTHD_PROCESS_DMA_PASS:cases64','LIGHTHD_DIRECT_MEMORY_PASS','LIGHTHD_MAIN_CAPTURE_PASS:9','LIGHTHD_PACK_STREAM_EQUIVALENCE_PASS:360 jobs/60 resets','LIGHTHD_OPERAND_QUEUE_MODEL_PASS:4127 pushes/4121 pops/658 full clocks/3874 renewals/3 occupied reset observations/phases11'):
 assert marker in foundation,marker
assert '65536 count/group/window/control combinations' in read(h/'stage7c25r2_counter_window_selftest.log')
assert 'C25R2_STREAM_HARDWARE_GUARD_PASS' in read(h/'stage7c25r2_stream_registers_console.log')
assert 'WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS' in read(q/'critical_full/retained_registers.rpt')
for n,d in json.loads((rb/'stage7c25r2_source_hashes.json').read_text()).items():
 assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
prior=sorted(ev.glob('*.sha256'))
for p in prior:
 d,n=p.read_text().split();assert hashlib.sha256((ev/n).read_bytes()).hexdigest()==d,p
paths=set()
for folder in ('src','tb/tb_dilithium','tb_uvm/tb_uvm_dilithium','tb_uvm/tb_uvm_ntt_LightHD','dilithium-sw-model/ref'):
    paths|={p.relative_to(r).as_posix() for p in (r/folder).rglob('*') if p.is_file() and p.suffix in ('.sv','.svh','.c','.h','.md')}
for folder in ('NIST/ML-DSA-keyGen-FIPS204','NIST/ML-DSA-sigGen-FIPS204','NIST/ML-DSA-sigVer-FIPS204'):
    paths|={p.relative_to(r).as_posix() for p in (r/folder).glob('*.json')}
for folder in ('FIPS204_NTT','FIPS204_SAMPLER'):
    paths|={p.relative_to(r).as_posix() for p in (r/folder).glob('*.py')}
paths|={p.relative_to(r).as_posix() for p in (r/'docs/dilithium_docs').glob('*.md')}
paths|={'AGENTS.md','README.md','sim/dilithium/.gitignore','sim/ntt/run_uvm.do','quartus/ntt/ntt.qsf','quartus/dilithium/dilithium.qsf'}
for leaf in ('README.md','dilithium_vectors.py','run.do','run_uvm.do','setup_cyclonev.tcl','report_uvm_coverage.tcl'):
    paths.add('sim/dilithium/'+leaf)
for p in h.glob('*'):
    if not p.is_file():continue
    current=p.name.startswith(('stage7c25r2','stage7_uvm')) and p.suffix in ('.txt','.csv','.rpt','.log','.ucdb')
    fixture=p.name.startswith(('stage2_','stage3_','stage4_','stage5_')) and p.suffix in ('.txt','.csv') and any(x in p.name for x in ('inputs','expected','samples','nist_sign_audit','nist_verify_audit'))
    if (current or fixture) and 'console' not in p.name and 'archive_create' not in p.name and 'archive_replay' not in p.name:paths.add(p.relative_to(r).as_posix())
for leaf in ('stage7c4_main_inputs.txt','stage7c4_main_outputs.txt','stage7c4_main_diagnostic_inputs.txt','stage7c4_main_diagnostic_outputs.txt','stage7c4_main_protocol_inputs.txt','stage7c4_main_protocol_outputs.txt','stage7c_ntt_inputs.txt','stage7c_ntt_expected.txt','stage7c1_ntt_dma_outputs.txt','stage7c4_hint_inputs.txt','stage7c4_hint_expected.txt','stage7c4_hint_outputs.txt'):
    paths.add('sim/dilithium/'+leaf)
for leaf in ('stage7c_sampler_inputs.txt','stage7c_sampler_expected.txt','stage7c1_sampler_writer_outputs.txt','stage7c_writer_mixed_inputs.txt','stage7c_writer_mixed_expected.txt','stage7c_writer_mixed_same_outputs.txt','stage7c_writer_mixed_different_outputs.txt','stage7c_chain_inputs.txt','stage7c_chain_expected.txt','stage7c1_hash_sampler_outputs.txt'):
    paths.add('sim/dilithium/'+leaf)
for pattern in ('c25*.py','c25*.ps1'):
    for p in (r/'tmp').glob(pattern):paths.add(p.relative_to(r).as_posix())

for p in rb.glob('stage7c25r2*'):
    if p.is_file():paths.add(p.relative_to(r).as_posix())
    elif p.is_dir():paths|={v.relative_to(r).as_posix() for v in p.rglob('*') if v.is_file() and v.suffix not in ('.exe','.o')}
for leaf in ('stage7c18r1_source_hashes.json','stage7c21_metrics.json','stage7c22_metrics.json','stage7c22_area_inventory.json','stage7c22_source_hashes.json','stage7c22_throughput.json'):paths.add('sim/dilithium/reference_build/'+leaf)
for leaf in ('dilithium_full.qpf','dilithium_full.qsf','dilithium.sdc','report_full.tcl','README.md','stage7c25r2_compile.log','stage7c25r2_report_full.log'):
    paths.add('quartus/dilithium/'+leaf)
paths|={p.relative_to(r).as_posix() for p in q.glob('stage7c25r2*.log') if p.is_file()}
for corner in ('slow_85C','slow_0C','fast_85C','fast_0C'):
    for kind in ('fmax','setup','hold'):paths.add(f'quartus/dilithium/critical_full/{corner}_{kind}.rpt')
for leaf in ('retained_registers.rpt','mapped_register_names.rpt'):paths.add('quartus/dilithium/critical_full/'+leaf)
for p in (q/'output_full').glob('*'):
    if p.suffix in ('.rpt','.summary'):paths.add(p.relative_to(r).as_posix())

# Earlier exhaustive proof is reused explicitly,never relabelled fresh.
paths.add('sim/dilithium/reference_build/stage7c20_baseline_c18r1/stage7c18r1_foundation.log')
for leaf in ('stage7c_sign_load_inputs.txt','stage7c_sign_load_expected.txt','stage7c3_sign_load_outputs.txt','stage7c4_verify_input_inputs.txt','stage7c4_verify_input_expected.txt','stage7c4_verify_input_outputs.txt'):
    paths.add('sim/dilithium/'+leaf)
# Private overridden-source probes are historical diagnostics,not current token captures.
for p in (r/'tmp').glob('*c25*.sv'):paths.add(p.relative_to(r).as_posix())
for p in (r/'tmp/stage7c25r2_bitpkg_map_baseline').glob('*.sv'):paths.add(p.relative_to(r).as_posix())
for p in (r/'tmp').glob('lighthd_bitpkg_c22_reference.sv'):paths.add(p.relative_to(r).as_posix())
for folder in ('stage7c25r2_bitpkg_map_baseline','stage7c25r2_bitpkg_map_candidate'):
    for p in (r/'tmp'/folder).rglob('*'):
        if p.is_file() and p.suffix in ('.qsf','.qpf','.rpt','.log','.summary','.sv','.txt'):paths.add(p.relative_to(r).as_posix())


paths|=set(json.loads((rb/'stage7c25r2_source_hashes.json').read_text()))
for leaf in ('stage7c25_source_hashes.json','stage7c25r1_source_hashes.json'):
    paths.add('sim/dilithium/reference_build/'+leaf)
for p in (r/'tmp/stage7c25_bank_syntax_probe').glob('*'):
    if p.is_file() and p.suffix in ('.sv','.qsf','.qpf','.log'):paths.add(p.relative_to(r).as_posix())
for p in (r/'tmp/stage7c25r2_launch_probe').glob('*'):
    if p.is_file() and p.suffix in ('.sv','.do','.py','.txt','.log'):paths.add(p.relative_to(r).as_posix())

metrics=json.loads((rb/'stage7c25r2_metrics.json').read_text())
throughput=json.loads((rb/'stage7c25r2_throughput.json').read_text())
uvm=read(h/'stage7c25r2_uvm.log')
def bins(label):
 m=re.search(re.escape(label)+r'.*?:\s*(\d+) / (\d+)',uvm);assert m,label
 return [int(m[1]),int(m[2])]
results=dict(stage='7C.25R2 timing-first registered transport',source_qualified=True,routed=True,performance_accepted=False,
 physical_completion=metrics['physical_flow'],clock_constraint_ns=6.500,target_frequency_mhz=1000/6.5,minimum_requested_frequency_mhz=150,
 synthesis_mode='HIGH PERFORMANCE EFFORT',area_reduction_deferred=True,reference_placed_ALMs=30577,
 timing_closed=all(c['setup_ns']>=0 and c['hold_ns']>=0 for c in metrics['corners']),
 minimum_frequency_met=min(c['fmax_mhz'] for c in metrics['corners'])>150,
 main_token=(h/'stage7c4_main_inputs.txt').read_text().split()[0],uvm_token=re.search(r'[0-9a-f]{64}',(h/'stage7_uvm_inputs.txt').read_text())[0],
 official_commands=210,official_bytes=744280,protocol_commands=88,checker_corruptions=90,UVM_checked=30,UVM_reset_aborts=3,
 functional_bins=bins('OVERALL FUNCTIONAL COVERAGE'),code_bins=bins('OVERALL DUT CODE COVERAGE'),
 new_source_count=269,source_delta_from_R1='Explicit generate and module-scope genvar only;no logic or checker math change',
 selected_as_working_timing_candidate=True,user_performance_acceptance=False,
 worst_path='slow0C NTT DMA op_r[0]->state.REPORT via command-mask/router/scheduler ready feedback;10logic/13.712ns',
 native_token_limitation='Legacy explicit source lists omit the new bank_request_pipe leaf;the external269-file manifest and recursive full-source UVM token cover it. Fix native dependency lists in next revision;current runs are fresh,not retagged.',
 transport='Independent two-entry A/B request FIFOs per physical bank;1696 logical bits;acceptance-ordered conflicting requests;physical RAM responses and burst retirement remain after physical issue',
 reset_semantics='Unissued requests discarded;committed RAM writes retained;all emitted reset-prefix bytes checked independently;prefix lengths measured',
 reused_Process_domain_proof=dict(stage='C18R1',unchanged_files=10,fresh_R2_execution=False),
 counter_model_combinations=65536,unpacker_semantic_packets=1241,bank_accepted=20732,bank_issued=20720,bank_replies=20708,
 hint_prefix_combinations=786432,cycle_deltas=json.loads((rb/'stage7c25r2_cycle_deltas.json').read_text()),
 metrics=metrics,throughput=throughput,prior_archives_verified=len(prior),
 prior_failures='Initial observer/launcher failure and R1 Quartus parser failure separately archived,never relabelled as qualified PPA',
 private_launch_probe='NOT promoted:registered35bit command passesmain9/protocol88 independent byte checks and all clock records exactR1;18 emptySHAKE128/256 outputs at offsets0/1/26/stalls/pending-reset pass. No PPA or main-coverage credit.',
 limitations='Not board measurements,security acceptance,Stage8,or a claim of unpublished LightHD RTL equivalence')
files={n:(r/n).read_bytes() for n in sorted(paths)}
files['RESULTS.json']=(json.dumps(results,indent=2)+'\n').encode()
manifest={n:hashlib.sha256(b).hexdigest() for n,b in files.items()}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 for n,d in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==d,n
digest=hashlib.sha256(target.read_bytes()).hexdigest()
with side.open('x') as f:f.write(digest+'  '+target.name+'\n')
print(f'C25R2_ARCHIVE_CREATE_VERIFY_PASS:{len(files)}members/{target.stat().st_size}bytes/{len(prior)}prior pairs;SHA256 '+digest)
