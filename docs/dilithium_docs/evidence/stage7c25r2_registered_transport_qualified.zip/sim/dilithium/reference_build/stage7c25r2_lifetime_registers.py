from pathlib import Path
import re,json
r=Path.cwd();q=r/'quartus/dilithium/critical_full'
names=(q/'mapped_register_names.rpt').read_text().splitlines()
process=[n for n in names if '|lighthd_process:process_unit|' in n]
assert 500<=len(process)<=624,len(process)
assert not any(re.search(r'\|(coefficient[01]_r|coarse_r|high[12]_r|low2_r|hint[012]_r|level[012]_r)',n) for n in process)
groups={}
for label,scope,pattern,wanted in [('Sign_rho','lighthd_sign:sign_controller',r'(rho_store_r|rho)',256),('Sign_tr_mu','lighthd_sign:sign_controller',r'(tr_mu_store_r|tr|mu_r)',512),('Sign_entropy_mask','lighthd_sign:sign_controller',r'(entropy_mask_store_r|mask_r|key|rnd_r)',512),('Verify_tr_mu_digest','lighthd_verify:verify_controller',r'(mu_r|digest_r)',512)]:
 found=[n for n in names if re.search(r'\|'+re.escape(scope)+r'\|'+pattern+r'\[',n)]
 assert len(found)==wanted,(label,len(found),wanted)
 groups[label]=found
for scope,pattern in [('lighthd_sign_input:key_input',r'header_r'),('lighthd_verify_input:inputs',r'tr_o')]:
 assert not any(re.search(r'\|'+re.escape(scope)+r'\|'+pattern+r'\[',n) for n in names),(scope,'duplicate snapshot storage remains')
owner=[n for n in names if re.search(r'^lighthd_dilithium:core\|owner_select_r\[',n)]
assert len(owner)==3,len(owner)
result=dict(Process_original_mapped_bits=len(process),shared_controller_bits={k:len(v) for k,v in groups.items()},owner_bits=3,process_names=process,groups=groups,owner_names=owner)
(r/'sim/dilithium/reference_build/stage7c25r2_lifetime_registers.json').write_text(json.dumps(result,indent=2)+'\n')
print('C25R2_LIFETIME_HARDWARE_GUARD_PASS:Sign256+512+512,Verify512,main owner3;no duplicate integrated header/TR snapshots;Process original bits',len(process))
