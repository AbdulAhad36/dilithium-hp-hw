"""Compare unchanged crypto/status semantics and measure intentional new latency."""
from pathlib import Path
from collections import defaultdict
from statistics import mean
import csv,json
h=Path('sim/dilithium');base=h/'reference_build/stage7c25r2_baseline_c22'
def jobs(path,count):
 lines=path.read_text().splitlines();assert lines[-1]=='F '+str(count)
 out=[];current=None
 for line in lines[1:-1]:
  x=line.split()
  if x[0]=='J':
   assert current is None;current=dict(identity=x,records=[])
  else:
   assert current is not None;current['records'].append(x)
   if x[0] in ('D','X'):out.append(current);current=None
 assert current is None and len(out)==count
 return out
report=[];groups=defaultdict(list);native=[];resets=[]
for leaf,count in (('stage7c4_main_outputs.txt',210),('stage7c4_main_protocol_outputs.txt',88)):
 old,new=jobs(base/leaf,count),jobs(h/leaf,count)
 for a,b in zip(old,new):
  assert a['identity']==b['identity'],(leaf,'command identity')
  identity=b['identity'];serial,op,p=int(identity[1]),int(identity[2]),int(identity[4])
  tail_a,tail_b=a['records'][-1],b['records'][-1]
  assert tail_a[0]==tail_b[0]
  if tail_a[0]=='D':
   assert a['records'][:-1]==b['records'][:-1],(leaf,serial,'changed crypto/payload records')
   assert tail_a[:-1]==tail_b[:-1],(leaf,serial,'status/attempt/rejection/nonce')
   before,after=int(tail_a[-1]),int(tail_b[-1]);delta=after-before
   native.append(dict(capture=leaf,case=serial,operation=op,param=p,before=before,after=after,delta=delta))
   groups[leaf,op,p].append(delta)
  else:
   assert tail_a==tail_b,(leaf,serial,'reset phase')
   # The authoritative Python checker verifies every emitted K/S byte and
   # every challenge/rejection independently. A fixed-phase reset may now
   # interrupt a different number of words:do not pretend lengths are equal.
   words_a=[x for x in a['records'] if x[0] in ('K','S')]
   words_b=[x for x in b['records'] if x[0] in ('K','S')]
   shared=min(len(words_a),len(words_b));assert words_a[:shared]==words_b[:shared]
   resets.append(dict(case=serial,phase=int(tail_b[1]),old_words=len(words_a),new_words=len(words_b),shared_words_exact=shared))
 report.append(leaf+':completed crypto/status/attempts exact C22;reset identities and common published prefixes exact;latencies and prefix lengths measured')
assert len(native)==286 and len(resets)==12
old=list(csv.DictReader((base/'stage7_uvm_checked.csv').open()));new=list(csv.DictReader((h/'stage7_uvm_checked.csv').open()))
assert len(old)==len(new)==30
for a,b in zip(old,new):assert all(a[k]==b[k] for k in a if k!='source_token'),(a,b)
old=list(csv.DictReader((base/'stage7_uvm_latency.csv').open()));new=list(csv.DictReader((h/'stage7_uvm_latency.csv').open()))
assert len(old)==len(new)==30;uvm=[]
for a,b in zip(old,new):
 assert all(a[k]==b[k] for k in ('case','op','param','id'))
 uvm.append(dict(case=int(a['case']),delta={k:int(b[k])-int(a[k]) for k in a if k not in ('case','op','param','id')}))
for (leaf,op,p),values in sorted(groups.items()):report.append(f'{leaf}:op{op}/level{(2,3,5)[p]} count{len(values)} delta clocks min{min(values)} mean{mean(values):.3f} max{max(values)}')
report.append('STAGE7C25R2_CYCLE_AUDIT_PASS:exact completed crypto/status;new operation clocks measured;12 reset prefix lengths measured,not assumed equal;no zero-cost pipeline claim')
(h/'reference_build/stage7c25r2_cycle_deltas.json').write_text(json.dumps(dict(native=native,UVM=uvm,reset_prefixes=resets),indent=2)+'\n')
(h/'stage7c25r2_cycle_audit.log').write_text('\n'.join(report)+'\n');print('\n'.join(report))
