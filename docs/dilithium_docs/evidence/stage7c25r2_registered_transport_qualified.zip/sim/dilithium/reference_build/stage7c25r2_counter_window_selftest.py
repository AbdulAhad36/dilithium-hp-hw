from pathlib import Path
from itertools import product

s=Path('src/controller/process/lighthd_bitunpkg.sv').read_text()
assert 'count_consume=!rst && state==FEED && enough && window_valid_r && output_ready_i;' in s
assert 'count_r[7]^count_r[6],~count_r[6],count_r[5:0]' in s
assert 'if(window_valid_r && enough && bad_value)begin done_code_o<=2;state<=REPORT;count_r<=0;end' in s
nchecks=0
for n,g,window,bad,ready,push,frame in product(range(256),(16,24,40,48,52,64,72,80),*[range(2)]*5):
    enough=n>=g
    pop=enough and window and not bad and ready
    consume=enough and window and ready
    expected=(n-(g if pop else 0)+(64 if push and not frame else 0))&255
    base=(n-g)&255 if consume else n
    got=((base&63)|((((base>>6)^1)&1)<<6)|((((base>>7)^(base>>6))&1)<<7)) if push and not frame else base
    if (push and frame) or (window and enough and bad):expected=got=0
    assert expected==got,(n,g,window,bad,ready,push,frame)
    nchecks+=1
print(f'C25R2_WINDOW_COUNTER_MODEL_PASS:{nchecks} count/group/window/control combinations;actual RTL semantic proof is the separate 1241-packet test;not NIST or coverage credit')
