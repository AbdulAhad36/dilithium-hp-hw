$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
foreach ($kind in @('native','uvm')) {
 if (-not (Select-String -LiteralPath ("sim/dilithium/stage7c25r2_"+$kind+"_runner.log") -SimpleMatch ("STAGE7C25R2_"+$kind.ToUpper()+"_RUNNER_PASS") -Quiet)) {throw "Missing $kind qualification"}
}
if (-not (Select-String -LiteralPath quartus/dilithium/stage7c25r2_compile.log -SimpleMatch 'Quartus Prime Full Compilation was successful' -Quiet)) {throw 'Missing actual full compile'}
if (-not (Select-String -LiteralPath sim/dilithium/stage7c25r2_scope_report_recovery.log -SimpleMatch 'STAGE7C25R2_PHYSICAL_RECOVERY_PASS' -Quiet)) {throw 'Scope-corrected read-only report did not pass'}
foreach ($reader in @('source_audit','proof_reuse','metrics','admission_registers','native_structure','shared_hint_registers','operand_registers','stream_registers','lifetime_registers','writer_registers','area_delta','throughput','cycle_audit')) {
 & 'C:/Python314/python.exe' ("sim/dilithium/reference_build/stage7c25r2_"+$reader+".py") *> ("sim/dilithium/stage7c25r2_"+$reader+"_console.log")
 if ($LASTEXITCODE -ne 0) {throw "C25R2 result reader failed:$reader"}
}
& 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py uvm_check *> sim/dilithium/stage7c25r2_final_uvm_check.log
if ($LASTEXITCODE -ne 0) {throw 'C25R2 UVM freshness failed'}
'STAGE7C25R2_RESULT_COLLECTION_PASS'
