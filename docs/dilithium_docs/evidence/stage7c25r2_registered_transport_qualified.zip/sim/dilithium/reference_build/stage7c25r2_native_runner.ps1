$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
foreach ($gate in @('lighthd_prepare','lighthd_hint_prepare','lighthd_sampler_prepare','lighthd_writer_mixed_prepare','lighthd_chain_prepare','lighthd_main_prepare','uvm_prepare','lighthd_sign_load_prepare','lighthd_verify_input_prepare')) {
  & 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py $gate *> "sim/dilithium/stage7c25r2_${gate}.log"
  if ($LASTEXITCODE -ne 0) {throw "Preparation failed: $gate"}
}
'STAGE7C25R2_PREPARE_PASS'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File sim/dilithium/reference_build/stage7c25r2_foundation_runner.ps1
if ($LASTEXITCODE -ne 0) {throw 'Foundation runner failed;no full build launched'}
$physicalJob=Start-Process -FilePath powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File','sim/dilithium/reference_build/stage7c25r2_quartus_runner.ps1') -WindowStyle Hidden -RedirectStandardOutput sim/dilithium/stage7c25r2_quartus_runner.log -RedirectStandardError sim/dilithium/stage7c25r2_quartus_runner_errors.log -PassThru
$uvmJob=Start-Process -FilePath powershell.exe -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File','sim/dilithium/reference_build/stage7c25r2_uvm_runner.ps1') -WindowStyle Hidden -RedirectStandardOutput sim/dilithium/stage7c25r2_uvm_runner.log -RedirectStandardError sim/dilithium/stage7c25r2_uvm_runner_errors.log -PassThru
@{uvm=$uvmJob.Id;quartus=$physicalJob.Id}|ConvertTo-Json|Set-Content sim/dilithium/reference_build/stage7c25r2_job_ids.json
'STAGE7C25R2_FOUNDATION_PASS_FULL_JOBS_STARTED'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File sim/dilithium/reference_build/stage7c25r2_production_runner.ps1
if ($LASTEXITCODE -ne 0) {throw 'Production runner failed'}
'STAGE7C25R2_NATIVE_RUNNER_PASS'
