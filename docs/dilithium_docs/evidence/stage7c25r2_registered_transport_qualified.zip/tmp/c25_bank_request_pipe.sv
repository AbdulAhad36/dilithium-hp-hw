// Physical-bank request pipeline. One two-entry queue of A/B request pairs,
// not a queue per client. Registered occupancy terminates ready propagation.
// Pairs issue in acceptance order;A precedes B on a write-address collision.
// Thus later requests cannot overtake an earlier conflicting request. The
// existing physical RAM remains solely responsible for collision prevention.
`default_nettype none
module bank_request_pipe (
 input wire logic clk,rst,
 input wire logic [1:0] input_valid_i,input_write_i,
 input wire logic [1:0][9:0] input_address_i,
 input wire logic [1:0][91:0] input_data_i,
 output logic [1:0] input_ready_o,
 output logic [1:0] output_valid_o,output_write_o,
 output logic [1:0][9:0] output_address_o,
 output logic [1:0][91:0] output_data_o,
 input wire logic [1:0] output_ready_i
);
 (* ramstyle="logic" *) logic [1:0][1:0][102:0] entries_r;
 logic [1:0][1:0] mask_r;
 logic [1:0] count_r,issued_r;
 logic read_r,write_r,push,pop;
 logic [1:0] fire,head_mask;
 assign input_ready_o={2{!rst && count_r<2}};
 assign push=|(input_valid_i & input_ready_o);
 assign head_mask=mask_r[read_r];
 assign output_valid_o={2{!rst && count_r!=0}} & head_mask & ~issued_r;
 assign fire=output_valid_o & output_ready_i;
 assign pop=count_r!=0 && ((issued_r|fire)&head_mask)==head_mask;
 for(genvar p=0;p<2;p++)begin:port_fields
  assign {output_write_o[p],output_address_o[p],output_data_o[p]}=entries_r[read_r][p];
 end
 always_ff @(posedge clk)if(push)begin
  entries_r[write_r][0]<={input_write_i[0],input_address_i[0],input_data_i[0]};
  entries_r[write_r][1]<={input_write_i[1],input_address_i[1],input_data_i[1]};
  mask_r[write_r]<=input_valid_i;
 end
 always_ff @(posedge clk or posedge rst)begin
  if(rst)begin count_r<=0;read_r<=0;write_r<=0;issued_r<=0;end
  else begin
   case({push,pop})
    2'b10:count_r<=count_r+1'b1;
    2'b01:count_r<=count_r-1'b1;
    default:begin end
   endcase
   if(push)write_r<=!write_r;
   if(pop)begin read_r<=!read_r;issued_r<=0;end
   else issued_r<=issued_r|fire;
  end
 end
 // synthesis translate_off
 always @(posedge clk)if(!rst)begin
  if(count_r>2 || (push && count_r==2))$fatal(1,"Physical request queue overflow");
  if(pop && count_r==0)$fatal(1,"Physical request queue underflow");
 end
 // synthesis translate_on
endmodule
`default_nettype wire
