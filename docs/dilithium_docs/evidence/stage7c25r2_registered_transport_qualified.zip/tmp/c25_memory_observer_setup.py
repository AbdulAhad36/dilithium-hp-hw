from pathlib import Path
import difflib,json,hashlib,zipfile
r=Path.cwd();archive=r/'docs/dilithium_docs/evidence/stage7c25_initial_memory_observer_failure.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==archive.with_suffix('.sha256').read_text().split()[0]
p=r/'tb/tb_dilithium/tb_lighthd_memory.sv';old=p.read_text();s=old
s=s.replace('  read_t expected[2][4][$];', '''  read_t expected[2][4][$];
  typedef struct packed {logic writing;logic [9:0] address;logic [91:0] data;} request_t;
  request_t physical_expected[2][4][$];
  logic [1:0][3:0] physical_fire,physical_write;
  logic [1:0][3:0][9:0] physical_address;
  logic [1:0][3:0][91:0] physical_data;
  int physical_requests=0,queued_conflicts=0;
  // Observe the RAM boundary after the new registered request queues.
  for(genvar bank_probe=0;bank_probe<4;bank_probe++)begin:physical_probe
    for(genvar port_probe=0;port_probe<2;port_probe++)begin:physical_port
      assign physical_fire[port_probe][bank_probe]=dut.banks.bank[bank_probe].queued_valid[port_probe] && dut.banks.bank[bank_probe].queued_ready[port_probe];
      assign physical_write[port_probe][bank_probe]=dut.banks.bank[bank_probe].queued_write[port_probe];
      assign physical_address[port_probe][bank_probe]=dut.banks.bank[bank_probe].queued_address[port_probe];
      assign physical_data[port_probe][bank_probe]=dut.banks.bank[bank_probe].queued_data[port_probe];
    end
  end''')
s=s.replace('int parallel_count;read_t next_read;', 'int parallel_count;read_t next_read;request_t next_request;')
s=s.replace('expected[p][b].delete();sent[p][b]=0;', 'expected[p][b].delete();physical_expected[p][b].delete();sent[p][b]=0;')
a=s.index('      // Capture read expectations before applying same-edge writes.');b=s.index('      if(parallel_count>max_parallel)',a)
s=s[:a]+'''      // Physical issue must match an earlier accepted request exactly.
      // Front acceptance is not RAM issue after adding the request pipeline.
      for(int p=0;p<2;p++)for(int b=0;b<4;b++)if(physical_fire[p][b])begin
        if(physical_expected[p][b].size()==0)$fatal(1,"RAM issued an unaccepted bank request");
        next_request=physical_expected[p][b].pop_front();
        if({physical_write[p][b],physical_address[p][b],physical_data[p][b]}!==
           {next_request.writing,next_request.address,next_request.data})$fatal(1,"Physical bank request reordered/corrupted");
        physical_requests++;
      end
      // Independent acceptance-order model:A precedes B on the same edge.
      // Conflicting writes may both enqueue;the backend must serialize them.
      for(int p=0;p<2;p++)for(int b=0;b<4;b++)
        if(dut.request_valid[p][b] && dut.request_ready[p][b])begin
          parallel_count++;requests++;
          next_request.writing=dut.request_write[p][b];next_request.address=dut.request_address[p][b];next_request.data=dut.request_data[p][b];
          physical_expected[p][b].push_back(next_request);
          if(physical_expected[p][b].size()>2)$fatal(1,"Bank request queue exceeded its bound");
          if(dut.request_write[p][b])begin
            if(dut.request_data[p][b]!==pattern(b,dut.request_address[p][b],epoch[p][b]))$fatal(1,"Bank write payload/order mismatch");
            model[b][dut.request_address[p][b]]=dut.request_data[p][b];initialized[b][dut.request_address[p][b]]=1;writes++;
          end else begin
            if(!initialized[b][dut.request_address[p][b]])$fatal(1,"Test read never initialized word");
            next_read.address=dut.request_address[p][b];next_read.data=model[b][next_read.address];expected[p][b].push_back(next_read);
          end
        end
      for(int b=0;b<4;b++)begin
        if(collision_o[b])collisions++;
        if(dut.request_valid[0][b] && dut.request_ready[0][b] && dut.request_valid[1][b] && dut.request_ready[1][b] &&
           dut.request_address[0][b]==dut.request_address[1][b] && (dut.request_write[0][b] || dut.request_write[1][b]))queued_conflicts++;
        if(physical_fire[0][b] && physical_fire[1][b] && physical_address[0][b]==physical_address[1][b] &&
           (physical_write[0][b] || physical_write[1][b]))$fatal(1,"Physical collision accepted");
      end
'''+s[b:]
s=s.replace('if(max_parallel!=8 || collisions==0 || stable_checks==0)', 'if(max_parallel!=8 || queued_conflicts==0 || stable_checks==0)')
s=s.replace('$display("LIGHTHD_DIRECT_MEMORY_PASS:commands%0d writes%0d reads%0d requests%0d max_parallel%0d collisions%0d stable_checks%0d;all3 fixed maps/reset recovery checked",\n      commands,writes,reads,requests,max_parallel,collisions,stable_checks);', '''for(int p=0;p<2;p++)for(int b=0;b<4;b++)if(physical_expected[p][b].size()!=0)$fatal(1,"Bank completed before physical requests drained");
    $display("LIGHTHD_DIRECT_MEMORY_PASS:commands%0d writes%0d reads%0d accepted_requests%0d physical_requests%0d max_parallel%0d queued_conflicts%0d physical_collisions%0d stable_checks%0d;all3 maps/reset and both boundaries checked",
      commands,writes,reads,requests,physical_requests,max_parallel,queued_conflicts,collisions,stable_checks);''')
assert 'Capture read expectations before applying same-edge writes' not in s
assert 'Physical collision accepted' in s and 'physical_expected' in s and 'queued_conflicts==0' in s
d=list(difflib.unified_diff(old.splitlines(True),s.splitlines(True)))
print(json.dumps('*** Begin Patch\n*** Update File: tb/tb_dilithium/tb_lighthd_memory.sv\n'+''.join('@@\n' if x.startswith('@@') else x for x in d[2:])+'*** End Patch'))
