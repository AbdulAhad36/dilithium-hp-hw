from pathlib import Path
import json,sys
r=Path.cwd()
names=['docs/dilithium_docs/'+n+'.md' for n in ('DILITHIUM_PLAN','THROUGHPUT','COVERAGE','MEMORY_MAP','PROCESS_BLOCKS','SPECIFICATION','REFERENCE_VERIFICATION')]
names+=['README.md','sim/dilithium/README.md','quartus/dilithium/README.md']
intro="""## C25R2 qualified timing candidate: 150+ MHz remains open

Area reduction is deferred. This timing candidate completes source and physical
qualification;it is **not** timing closure or user acceptance. The permanent
target is6.500ns/153.85MHz on the same Cyclone V,with hold constraints unchanged.

|Measured result|C22 reference|C25R2|
|---|---:|---:|
|Final placed ALMs [A]|30,577|31,720|
|Worst four-corner Fmax MHz|68.23|71.60|
|Clock constraint ns|6.757|6.500|
|Worst setup ns|-7.899|-7.466|
|Worst hold ns|+0.087|+0.113|
|Registers|20,389|22,241|
|M10Ks / hard DSPs|59 /8|59 /8|
|Block memory bits|409,446|409,446|

Fmax improves4.94%;placed area grows1,143ALMs/3.74%. Estimated operation
rates improve3.3–4.7% **after** measured pipeline clock penalties. These are
sequential estimates using actual worst-corner Fmax,not board measurements.
The constraint and synthesis mode also changed:HIGH PERFORMANCE EFFORT,
retiming/register duplication still off. Do not attribute all gains only to RTL.

Fresh full210official cases/744,280 published key-signature bytes/35 Verify
digests/9valid36invalid,protocol88/148,704 bytes,checker90,main UVM30 checked
completions/3 reset aborts and first-byte negative0 credit PASS. All269 frozen
source/config/ref hashes,286 completed native and30 UVM latency records and
12 reset-prefix records are audited. Functional116/170=68.24%;module code
135456/177545,package12/107,overall135468/177652=76.25%. Focused probes do
not inflate main UVM coverage.

The original full compile/fit/assembler/STA passes. Its subsequent read-only
retention checker initially missed generated bank instance prefixes. The
failed query is preserved;the scope-corrected checker uses the SAME thresholds
and passes all retained-hardware/four-corner gates. All1,696 request-queue bits,
80 unpacker window bits,original Process/buffer state and8 hard DSPs survive.
The original frozen report is unchanged;its permanent prefix correction is
part of the next source revision. No old physical report is used as current.

New worst path:NTT DMA op_r -> command mask -> memory arbitration/ready ->
DMA FSM,10 logic levels/13.712ns,slow0C. Cut this command-feedback path next.
A PRIVATE registered Keccak launch probe also passes main9/protocol88 with
every non-token/cycle record exact and18 empty SHAKE128/256 outputs at offsets
0/1/26,backpressure and pending-reset. It is not promoted and has no PPA or
main-coverage credit. Its input buffering hides the launch clock in those
tested ML-DSA operations.

Native freshness lists currently omit the new queue module leaf;the independent
269-file manifest and recursive full-source UVM fingerprint cover it. Add that
native dependency and update the legacy pre-window counter self-test on the
next source revision. NIST mathematics/comparison rules remain unchanged.
Keep immutable C22/C23/C24 and failed C25/R1/guard snapshots. No commit,branch
change,Stage8,unpublished-RTL equivalence or150MHz acceptance follows.

### Implemented timing cuts

"""
old,new=names[int(sys.argv[1])],None
p=r/old;s=p.read_text();a=s.index('## C25 active: timing and latency first')
b=s.index('Changes target the measured long paths rather than another area rewrite:',a)
tail=s[b+len('Changes target the measured long paths rather than another area rewrite:'):].lstrip('\n')
x=tail.index('The new preparation/transport stages can add clocks.')
y=tail.index('Focused proofs pass:',x)
tail=tail[:x]+"""Measured full-campaign mean added clocks versus C22:KeyGen24.76/53.20/51.72,
Sign753.50/935.43/1380.90,valid Verify165/255/320 at levels2/3/5. Report the
clock counts together with latency/rates at the measured71.60MHz. Reset prefix
lengths may differ;every emitted byte remains independently checked.

"""+tail[y:]
end=b+len('Changes target the measured long paths rather than another area rewrite:')
patch='*** Begin Patch\n*** Update File: '+p.as_posix()+'\n@@\n'+''.join('-'+l+'\n' for l in s[a:end].splitlines())+''.join('+'+l+'\n' for l in intro.rstrip().splitlines())
before=s[s.index('The new preparation/transport stages can add clocks.',end):s.index('Focused proofs pass:',end)]
after=tail[tail.index('Measured full-campaign mean added clocks'):tail.index('Focused proofs pass:')]
patch+='@@\n'+''.join('-'+l+'\n' for l in before.splitlines())+''.join('+'+l+'\n' for l in after.splitlines())+'*** End Patch'
print(json.dumps(patch))
