from pathlib import Path
import json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=(rb/'stage7c24_archive.py').read_text()
paths=old[old.index('paths=set()'):old.index('metrics=json.loads')]
paths=paths.replace('stage7c24','stage7c25r2').replace('c24','c25')
# Dependencies used by the R2 source audit, unchanged-domain proof and baseline readers.
paths+="""
paths|=set(json.loads((rb/'stage7c25r2_source_hashes.json').read_text()))
for leaf in ('stage7c25_source_hashes.json','stage7c25r1_source_hashes.json'):
    paths.add('sim/dilithium/reference_build/'+leaf)
for p in (r/'tmp/stage7c25_bank_syntax_probe').glob('*'):
    if p.is_file() and p.suffix in ('.sv','.qsf','.qpf','.log'):paths.add(p.relative_to(r).as_posix())
"""
# Old map-probe folders are optional diagnostics, not required for the qualified R2 archive.
paths=paths.replace("for leaf in ('c25_probe.do','c25_pack_proof.do','c25_pack_exhaustive.do'):paths.add('tmp/'+leaf)","")
header="""from pathlib import Path
import hashlib,json,zipfile,re
r=Path.cwd();h=r/'sim/dilithium';q=r/'quartus/dilithium';rb=h/'reference_build';ev=r/'docs/dilithium_docs/evidence'
target=ev/'stage7c25r2_registered_transport_qualified.zip';side=target.with_suffix('.sha256')
assert not target.exists() and not side.exists(),'Create-only archive already exists'
def read(p):
 b=p.read_bytes();return b.decode('utf-16' if b[:2] in (b'\\xff\\xfe',b'\\xfe\\xff') else 'utf-8',errors='replace')
for leaf,marker in [('collect_runner.log','STAGE7C25R2_RESULT_COLLECTION_PASS'),('native_runner.log','STAGE7C25R2_NATIVE_RUNNER_PASS'),('uvm_runner.log','STAGE7C25R2_UVM_RUNNER_PASS'),('quartus_runner.log','STAGE7C25R2_QUARTUS_RUNNER_PASS'),('cycle_audit.log','STAGE7C25R2_CYCLE_AUDIT_PASS')]:
 assert marker in read(h/('stage7c25r2_'+leaf)),leaf
for leaf,marker in [('lighthd_main_compare.log','LIGHTHD_MAIN_NIST_COMPARE_PASS:210'),('lighthd_main_protocol_compare.log','LIGHTHD_MAIN_PROTOCOL_COMPARE_PASS:88'),('lighthd_main_selftest.log','90/90 deliberate corruptions rejected')]:
 assert marker in read(h/('stage7c25r2_'+leaf)),leaf
foundation=read(h/'stage7c25r2_foundation.log')
assert '# ** Fatal:' not in foundation and '# ** Error:' not in foundation
for marker in ('LIGHTHD_UNPACK_PIPELINE_PASS:1241 packets/310504 coefficients/29 invalid/6 resets/6 occupied resets','LIGHTHD_BANK_PIPE_PASS:20732 accepted/20720 issued/20708 replies','LIGHTHD_HINT_PREFIX_PROOF_PASS:786432 combinations','LIGHTHD_PROCESS_DMA_PASS:cases64','LIGHTHD_DIRECT_MEMORY_PASS','LIGHTHD_MAIN_CAPTURE_PASS:9','LIGHTHD_PACK_STREAM_EQUIVALENCE_PASS:360 jobs/60 resets','LIGHTHD_OPERAND_QUEUE_MODEL_PASS:4127 pushes/4121 pops/658 full clocks/3874 renewals/3 occupied reset observations/phases11'):
 assert marker in foundation,marker
assert '65536 count/group/window/control combinations' in read(h/'stage7c25r2_counter_window_selftest.log')
assert 'C25R2_STREAM_HARDWARE_GUARD_PASS' in read(h/'stage7c25r2_stream_registers_console.log')
assert 'WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS' in read(q/'critical_full/retained_registers.rpt')
for n,d in json.loads((rb/'stage7c25r2_source_hashes.json').read_text()).items():
 assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
prior=sorted(ev.glob('*.sha256'))
for p in prior:
 d,n=p.read_text().split();assert hashlib.sha256((ev/n).read_bytes()).hexdigest()==d,p
"""
tail="""
metrics=json.loads((rb/'stage7c25r2_metrics.json').read_text())
throughput=json.loads((rb/'stage7c25r2_throughput.json').read_text())
uvm=read(h/'stage7c25r2_uvm.log')
def bins(label):
 m=re.search(re.escape(label)+r'.*?:\\s*(\\d+) / (\\d+)',uvm);assert m,label
 return [int(m[1]),int(m[2])]
results=dict(stage='7C.25R2 timing-first registered transport',source_qualified=True,routed=True,performance_accepted=False,
 physical_completion=metrics['physical_flow'],clock_constraint_ns=6.500,target_frequency_mhz=1000/6.5,minimum_requested_frequency_mhz=150,
 synthesis_mode='HIGH PERFORMANCE EFFORT',area_reduction_deferred=True,reference_placed_ALMs=30577,
 timing_closed=all(c['setup_ns']>=0 and c['hold_ns']>=0 for c in metrics['corners']),
 minimum_frequency_met=min(c['fmax_mhz'] for c in metrics['corners'])>150,
 main_token=(h/'stage7c4_main_inputs.txt').read_text().split()[0],uvm_token=re.search(r'[0-9a-f]{64}',(h/'stage7_uvm_inputs.txt').read_text())[0],
 official_commands=210,official_bytes=744280,protocol_commands=88,checker_corruptions=90,UVM_checked=30,UVM_reset_aborts=3,
 functional_bins=bins('OVERALL FUNCTIONAL COVERAGE'),code_bins=bins('OVERALL DUT CODE COVERAGE'),
 new_source_count=269,source_delta_from_R1='Explicit generate and module-scope genvar only;no logic or checker math change',
 transport='Independent two-entry A/B request FIFOs per physical bank;1696 logical bits;acceptance-ordered conflicting requests;physical RAM responses and burst retirement remain after physical issue',
 reset_semantics='Unissued requests discarded;committed RAM writes retained;all emitted reset-prefix bytes checked independently;prefix lengths measured',
 reused_Process_domain_proof=dict(stage='C18R1',unchanged_files=10,fresh_R2_execution=False),
 counter_model_combinations=65536,unpacker_semantic_packets=1241,bank_accepted=20732,bank_issued=20720,bank_replies=20708,
 hint_prefix_combinations=786432,cycle_deltas=json.loads((rb/'stage7c25r2_cycle_deltas.json').read_text()),
 metrics=metrics,throughput=throughput,prior_archives_verified=len(prior),
 prior_failures='Initial observer/launcher failure and R1 Quartus parser failure separately archived,never relabelled as qualified PPA',
 limitations='Not board measurements,security acceptance,Stage8,or a claim of unpublished LightHD RTL equivalence')
files={n:(r/n).read_bytes() for n in sorted(paths)}
files['RESULTS.json']=(json.dumps(results,indent=2)+'\\n').encode()
manifest={n:hashlib.sha256(b).hexdigest() for n,b in files.items()}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\\n').encode()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 for n,d in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==d,n
digest=hashlib.sha256(target.read_bytes()).hexdigest()
with side.open('x') as f:f.write(digest+'  '+target.name+'\\n')
print(f'C25R2_ARCHIVE_CREATE_VERIFY_PASS:{len(files)}members/{target.stat().st_size}bytes/{len(prior)}prior pairs;SHA256 '+digest)
"""
script=header+paths+tail
replay=(rb/'stage7c24_archive_replay.py').read_text().replace('stage7c24','stage7c25r2').replace('packing_path_qualified','registered_transport_qualified').replace('C24','C25R2')
replay=replay.replace("'lighthd_counter_selftest',",'')
replay=replay.replace("commands += [","commands += [['sim/dilithium/reference_build/stage7c25r2_counter_window_selftest.py']]\ncommands += [",1)
patch='*** Begin Patch\n'
for p,s in ((rb/'stage7c25r2_archive.py',script),(rb/'stage7c25r2_archive_replay.py',replay)):
 assert not p.exists(),p
 patch+='*** Add File: '+p.as_posix()+'\n'+''.join('+'+l+'\n' for l in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
