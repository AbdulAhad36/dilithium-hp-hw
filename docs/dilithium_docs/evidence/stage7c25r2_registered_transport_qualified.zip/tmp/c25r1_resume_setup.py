from pathlib import Path
import json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
foundation=(rb/'stage7c25r1_foundation_runner.ps1').read_text()
validation=foundation[foundation.index('if(Select-String'):foundation.index("'STAGE7C25R1_FOUNDATION_RUNNER_PASS'")]
validation=validation.replace("'lighthd_counter_selftest',",'')
native=(rb/'stage7c25r1_native_runner.ps1').read_text()
tail=native[native.index('$physicalJob='):]
body="""$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\\GitHub\\dilithium-hp-hw'
& 'C:/Python314/python.exe' sim/dilithium/reference_build/stage7c25r1_source_audit.py
if ($LASTEXITCODE -ne 0) {throw 'Frozen R1 audit failed'}
& 'C:/Python314/python.exe' sim/dilithium/reference_build/stage7c25r1_counter_window_selftest.py *> sim/dilithium/stage7c25r1_counter_window_selftest.log
if ($LASTEXITCODE -ne 0) {throw 'Window-qualified counter model failed'}
"""
body+=validation+"'STAGE7C25R1_FOUNDATION_RECOVERY_PASS:existing native foundation retained;window-qualified counter model replaces obsolete source-string assertion;NIST math unchanged'\n"+tail
p=rb/'stage7c25r1_resume_runner.ps1'
assert not p.exists()
print(json.dumps('*** Begin Patch\n*** Add File: '+p.as_posix()+'\n'+''.join('+'+line+'\n' for line in body.splitlines())+'*** End Patch'))
