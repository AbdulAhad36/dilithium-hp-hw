from pathlib import Path
import json,sys
r=Path.cwd();rb=r/'sim/dilithium/reference_build';u={}
s=(rb/'stage7c25_foundation_runner.ps1').read_text()
a=s.index('foreach ($marker in @(')
s="$ErrorActionPreference='Stop'\nSet-Location -LiteralPath 'D:\\GitHub\\dilithium-hp-hw'\n& C:/Python314/python.exe sim/dilithium/reference_build/stage7c25_source_audit.py\nif($LASTEXITCODE -ne 0){throw 'Frozen source changed'}\n"+s[a:]+"\n'STAGE7C25_FOUNDATION_RECOVERY_PASS:same completed native simulation;launcher count corrected;all semantic/pressure assertions retained;no RTL or bench change'\n"
u['sim/dilithium/reference_build/stage7c25_foundation_recovery.ps1']=s
s=(rb/'stage7c25_native_runner.ps1').read_text();a=s.index('& powershell.exe -NoProfile -ExecutionPolicy Bypass -File sim/dilithium/reference_build/stage7c25_foundation_runner.ps1')
s="$ErrorActionPreference='Stop'\nSet-Location -LiteralPath 'D:\\GitHub\\dilithium-hp-hw'\n"+s[a:]
s=s.replace('stage7c25_foundation_runner.ps1','stage7c25_foundation_recovery.ps1')
s=s.replace("'STAGE7C25_NATIVE_RUNNER_PASS'", "'STAGE7C25_NATIVE_RECOVERY_PASS'")
u['sim/dilithium/reference_build/stage7c25_native_recovery.ps1']=s
s=(rb/'stage7c25_collect_runner.ps1').read_text()
needle="  $marker='STAGE7C25_'+$kind.ToUpper()+'_RUNNER_PASS'"
s=s.replace(needle,"  $marker=if($kind -eq 'native'){'STAGE7C25_NATIVE_RECOVERY_PASS'}else{'STAGE7C25_'+$kind.ToUpper()+'_RUNNER_PASS'}\n  $log=if($kind -eq 'native'){'sim/dilithium/stage7c25_native_recovery.log'}else{\"sim/dilithium/stage7c25_${kind}_runner.log\"}")
s=s.replace('-LiteralPath "sim/dilithium/stage7c25_${kind}_runner.log"','-LiteralPath $log')
u['sim/dilithium/reference_build/stage7c25_recovered_collect.ps1']=s
p='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and n!=sys.argv[1]:continue
 assert not (r/n).exists()
 p+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(p+'*** End Patch'))
