from pathlib import Path
import json,sys
r=Path.cwd();u={}
s=(r/'tmp/c25_memory_probe.do').read_text().replace('work_c25_memory_probe','work_c25_memory_r1').replace('c25_memory_probe','c25_memory_r1')
s=s.replace('tmp/c25_bank_request_pipe.sv','tmp/c25_bank_request_pipe_r1.sv').replace('tmp/tb_c25_memory_main_probe.sv','tmp/tb_c25_memory_r1_main.sv')
u['tmp/c25_memory_r1.do']=s
u['tmp/tb_c25_memory_r1_main.sv']=(r/'tmp/tb_c25_memory_main_probe.sv').read_text().replace('stage7c25_memory_probe','stage7c25_memory_r1')
u['tmp/c25_memory_r1_compare.py']=(r/'tmp/c25_memory_probe_compare.py').read_text().replace('stage7c25_memory_probe','stage7c25_memory_r1')
p='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and n!=sys.argv[1]:continue
 assert not (r/n).exists()
 p+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(p+'*** End Patch'))
