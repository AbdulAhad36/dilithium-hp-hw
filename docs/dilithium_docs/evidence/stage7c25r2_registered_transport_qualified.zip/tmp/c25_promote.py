from pathlib import Path
import json,difflib,sys
r=Path.cwd();h=r/'sim/dilithium';u={}
def readlog(p):
 b=p.read_bytes();return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8',errors='replace')
for n,marker in (
 ('stage7c25_complete_compare.log','C25_COMPLETE_CONTROLLER_COMPARE_PASS'),
 ('stage7c25_unpack_proof.log','C25_UNPACK_PIPELINE_PASS:1241 packets/310504 coefficients/29 invalid/6 resets/6 occupied resets'),
 ('stage7c25_bank_pipe_both_phases.log','C25_BANK_PIPE_PASS:20732 accepted/20720 issued/20708 replies'),
 ('stage7c25_hint_prefix.log','C25_HINT_PREFIX_PROOF_PASS:786432 combinations')):
 assert marker in readlog(h/n),(n,marker)
for target,source in (
 ('src/controller/process/lighthd_bitunpkg.sv','tmp/c25_lighthd_bitunpkg.sv'),
 ('src/controller/process/lighthd_bitpkg.sv','tmp/c24_lighthd_bitpkg.sv'),
 ('src/controller/datapath/lighthd_process_dma.sv','tmp/c24_lighthd_process_dma.sv'),
 ('src/controller/memory/memory_banks.sv','tmp/c25_memory_banks.sv'),
 ('src/controller/memory/bank_request_pipe.sv','tmp/c25_bank_request_pipe_r1.sv'),
 ('src/controller/datapath/lighthd_hash_sampler.sv','tmp/c25_lighthd_hash_sampler.sv'),
 ('src/controller/process/lighthd_hint_codec.sv','tmp/c25_lighthd_hint_codec.sv'),
 ('tb/tb_dilithium/lighthd_hint_codec_c22_reference.sv','tmp/lighthd_hint_codec_c22_reference.sv')):
 u[target]=(r/source).read_text(encoding='utf-8')
u['tb/tb_dilithium/tb_lighthd_unpack_pipeline.sv']=(r/'tmp/tb_c25_unpack_pipeline.sv').read_text().replace('tb_c25_unpack_pipeline','tb_lighthd_unpack_pipeline').replace('C25_UNPACK_PIPELINE_PASS','LIGHTHD_UNPACK_PIPELINE_PASS')
u['tb/tb_dilithium/tb_lighthd_bank_pipe.sv']=(r/'tmp/tb_c25_bank_pipe.sv').read_text().replace('tb_c25_bank_pipe','tb_lighthd_bank_pipe').replace('C25_BANK_PIPE_PASS','LIGHTHD_BANK_PIPE_PASS')
u['tb/tb_dilithium/tb_lighthd_hint_prefix.sv']=(r/'tmp/tb_c25_hint_prefix.sv').read_text().replace('tb_c25_hint_prefix','tb_lighthd_hint_prefix').replace('C25_HINT_PREFIX_PROOF_PASS','LIGHTHD_HINT_PREFIX_PROOF_PASS')
n='sim/dilithium/dilithium_vectors.py';s=(r/n).read_text()
needle="'tb_lighthd_unpack_counter.sv','tb_lighthd_operand_queue.sv'):";assert s.count(needle)==1 or "'tb_lighthd_hint_prefix.sv'):" in s
u[n]=s.replace(needle,"'tb_lighthd_unpack_counter.sv','tb_lighthd_operand_queue.sv',\n                 'lighthd_bitunpkg_c22_reference.sv','tb_lighthd_decode_fields.sv',\n                 'lighthd_bitpkg_c22_reference.sv','tb_lighthd_pack_fields.sv','tb_lighthd_pack_stream.sv',\n                 'tb_lighthd_unpack_pipeline.sv','tb_lighthd_bank_pipe.sv',\n                 'lighthd_hint_codec_c22_reference.sv','tb_lighthd_hint_prefix.sv'):")
n='quartus/dilithium/dilithium_full.qsf';s=(r/n).read_text()
assert 'OPTIMIZATION_MODE "AGGRESSIVE AREA"' in s or 'OPTIMIZATION_MODE "HIGH PERFORMANCE EFFORT"' in s
s=s.replace('OPTIMIZATION_MODE "AGGRESSIVE AREA"','OPTIMIZATION_MODE "HIGH PERFORMANCE EFFORT"')
needle='set_global_assignment -name SYSTEMVERILOG_FILE ../../src/controller/memory/memory_banks.sv'
assert needle in s
if 'SYSTEMVERILOG_FILE ../../src/controller/memory/bank_request_pipe.sv' not in s:s=s.replace(needle,'set_global_assignment -name SYSTEMVERILOG_FILE ../../src/controller/memory/bank_request_pipe.sv\n'+needle)
u[n]=s
n='quartus/dilithium/dilithium.sdc';s=(r/n).read_text()
s=s.replace('# User-selected initial integration target:about148MHz. Do not relax silently.', '# User priority:150+MHz minimum. Target6.500ns=153.85MHz with timing margin.\n# Area reduction is deferred;retain existing device and hold constraints.')
assert '-period 6.757' in s or '-period 6.500' in s;s=s.replace('-period 6.757','-period 6.500');u[n]=s
n='quartus/dilithium/report_full.tcl';s=(r/n).read_text()
needle='  unpacker_word_store {\\|lighthd_bitunpkg:unpacker\\|words_r} 192'
assert needle in s
s=s.replace(needle,'''  bank_request_payload {\\|bank_request_pipe:request_pipe\\|entries_r} 1648
  bank_request_counts {\\|bank_request_pipe:request_pipe\\|count_r} 16
  bank_request_pointers {\\|bank_request_pipe:request_pipe\\|(read_r|write_r)} 16
  bank_request_order {\\|bank_request_pipe:request_pipe\\|a_older_r} 16
  unpacker_selected_window {\\|lighthd_bitunpkg:unpacker\\|bits_r} 80
  unpacker_window_valid {\\|lighthd_bitunpkg:unpacker\\|window_valid_r} 1
  sampling_completion {\\|lighthd_hash_sampler:hash_sampler\\|completion_} 18
'''+needle)
u[n]=s
p='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and n!=sys.argv[1]:continue
 path=r/n
 if path.exists():
  old=path.read_text(encoding='utf-8')
  if old==s:continue
  d=list(difflib.unified_diff(old.splitlines(True),s.splitlines(True)))
  p+='*** Update File: '+n+'\n'+''.join('@@\n' if x.startswith('@@') else x for x in d[2:])
 else:p+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(p+'*** End Patch'))
