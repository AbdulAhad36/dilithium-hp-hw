from pathlib import Path
import json,sys
r=Path.cwd();u={}
s=(r/'tmp/c23_lighthd_bitunpkg_shared.sv').read_text()
s=s.replace('// Valid-packet controls/cycles are preserved;the imminent invalid-field\n// rejection edge can have different input ready. Error/status stays exact.',
'''// A registered selected window splits alignment from field validation.
// Ring consumption still occurs only at accepted decoded output. Intake
// pauses while a window is captured,so framing cannot overtake validation.
// A packet may take additional clocks;no speculative decoded credit is given.''')
s=s.replace('  logic [79:0] bits_r;', '  logic [79:0] bits_r,selected_bits;\n  logic window_valid_r,window_capture;')
s=s.replace("    bits_r=80'(ordered_words>>bit_offset_r);", "    selected_bits=80'(ordered_words>>bit_offset_r);")
s=s.replace('  always_ff @(posedge clk)if(push && !bad_frame)', '''  assign window_capture=!rst && state==FEED && enough && !window_valid_r;
  // Payload need not reset:window_valid_r owns it and invalidates it on reset.
  always_ff @(posedge clk)if(window_capture)bits_r<=selected_bits;
  always_ff @(posedge clk)if(push && !bad_frame)''')
s=s.replace('state==FEED && enough && !bad_value;', 'state==FEED && enough && window_valid_r && !bad_value;')
s=s.replace('(!enough || output_ready_i) &&', '(!enough || (window_valid_r && output_ready_i)) &&')
s=s.replace('(enough && output_ready_i && count_r<=refill_limit_r)', '(enough && window_valid_r && output_ready_i && count_r<=refill_limit_r)')
s=s.replace('state==FEED && enough && output_ready_i;', 'state==FEED && enough && window_valid_r && output_ready_i;')
s=s.replace('      group_bits<=0;refill_limit_r<=0;', '      group_bits<=0;refill_limit_r<=0;window_valid_r<=0;')
s=s.replace('        op_r<=command_op_i;width_r<=width;', '        window_valid_r<=0;\n        op_r<=command_op_i;width_r<=width;')
s=s.replace('      FEED:begin\n', '      FEED:begin\n        if(window_capture)window_valid_r<=1;\n        if(pop)window_valid_r<=0;\n')
s=s.replace('if(enough && bad_value)begin', 'if(window_valid_r && enough && bad_value)begin')
s=s.replace('// Valid fields retain exact timing. On the single rejected-field edge the', '// Packet contents and error priority remain exact. On a rejected-field edge the')
assert 'bits_r=80\'' not in s and 'window_valid_r && enough && bad_value' in s
u['tmp/c25_lighthd_bitunpkg.sv']=s
s=(r/'tb/tb_dilithium/tb_lighthd_bitunpkg_ring.sv').read_text()
s=s.replace('module tb_lighthd_bitunpkg_ring;', 'module tb_c25_unpack_pipeline;')
a=s.index('  logic ref_command_ready');b=s.index('  int cycles=0',a)
s=s[:a]+'''  int captures=0,occupied_resets=0,held_windows=0;
  logic held_window=0;logic [79:0] held_bits;
  always @(posedge clk)begin
    if(rst)held_window=0;
    else begin
      if(held_window && dut.bits_r!==held_bits)$fatal(1,"Window payload changed while occupied");
      if(dut.window_capture)captures++;
      if(dut.window_valid_r && !dut.pop)held_windows++;
      if(dut.window_valid_r && dut.window_capture)$fatal(1,"Window overwrites live payload");
      held_window=dut.window_valid_r && !dut.pop && !done_valid_o;
      held_bits=dut.bits_r;
    end
  end
'''+s[b:]
s=s.replace('if(abort_run && got!=0)begin', 'if(abort_run && got!=0 && dut.window_valid_r && !output_ready_i)begin\n        occupied_resets++;')
a=s.index('    $display("LIGHTHD_BITUNPKG_RING_CYCLE_PASS:');b=s.index('    $finish;',a)
s=s[:a]+'''    if(captures==0 || occupied_resets!=6 || held_windows==0)$fatal(1,"Missing pipeline/reset pressure");
    $display("C25_UNPACK_PIPELINE_PASS:%0d packets/%0d coefficients/%0d invalid/%0d resets/%0d occupied resets/%0d held outputs/%0d captures/%0d held windows;independent serial-bit/integer oracle",packets,coefficients,errors,resets,occupied_resets,stalls,captures,held_windows);
'''+s[b:]
# Hold input payload and valid while stalled;random gaps apply only before a word.
s=s.replace('input_valid_i=cycles%7!=0;', 'if(!input_valid_i)input_valid_i=cycles%7!=0;')
s=s.replace('@(posedge clk);if(input_valid_i && input_ready_o)index++;\n        @(negedge clk);', '@(posedge clk);if(input_valid_i && input_ready_o)begin index++;@(negedge clk);input_valid_i=0;end\n        else @(negedge clk);')
assert 'reference_dut' not in s and 'reject_ready_deltas' not in s
u['tmp/tb_c25_unpack_pipeline.sv']=s
u['tmp/c25_unpack_proof.do']='''onerror {quit -code 1 -f}
vlib sim/dilithium/work_c25_unpack
vmap c25_unpack sim/dilithium/work_c25_unpack
vlog -sv -work c25_unpack tmp/c25_lighthd_bitunpkg.sv tmp/tb_c25_unpack_pipeline.sv tb/tb_dilithium/lighthd_bitunpkg_c22_reference.sv tb/tb_dilithium/tb_lighthd_decode_fields.sv
foreach top {tb_c25_unpack_pipeline tb_lighthd_decode_fields} {
 vsim c25_unpack.$top
 onfinish stop
 run -all
 quit -sim
}
quit -f
'''
patch='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and n!=sys.argv[1]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
