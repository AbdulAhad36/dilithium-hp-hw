from pathlib import Path
import json,sys
r=Path.cwd();s=(r/'src/controller/memory/memory_banks.sv').read_text()
s=s.replace('    poly_bram storage(','''    logic [1:0] queued_valid,queued_write,queued_ready;
    logic [1:0][9:0] queued_address;
    logic [1:0][91:0] queued_data;
    bank_request_pipe request_pipe(
      .clk(clk),.rst(rst),
      .input_valid_i({request_valid_i[1][b],request_valid_i[0][b]}),
      .input_write_i({request_write_i[1][b],request_write_i[0][b]}),
      .input_address_i({request_address_i[1][b],request_address_i[0][b]}),
      .input_data_i({request_data_i[1][b],request_data_i[0][b]}),
      .input_ready_o({request_ready_o[1][b],request_ready_o[0][b]}),
      .output_valid_o(queued_valid),.output_write_o(queued_write),
      .output_address_o(queued_address),.output_data_o(queued_data),.output_ready_i(queued_ready));
    poly_bram storage(''')
for p,letter in ((0,'a'),(1,'b')):
 for n in ('valid','write','address','data'):
  s=s.replace(f'.{letter}_{n}_i(request_{n}_i[{p}][b])',f'.{letter}_{n}_i(queued_{n}[{p}])')
 s=s.replace(f'.{letter}_ready_o(request_ready_o[{p}][b])',f'.{letter}_ready_o(queued_ready[{p}])')
s=s.replace('// bank0..3 correspond to the paper\'s BRAM1..4. No allocation policy here.',
 '// bank0..3 correspond to the paper\'s BRAM1..4. One registered pair queue\n// per physical bank breaks collision-ready feedback;payload RAM is unchanged.')
u={'tmp/c25_memory_banks.sv':s}
s=(r/'tmp/c25_probe.do').read_text().replace('work_c25_probe','work_c25_memory_probe').replace('c25_probe','c25_memory_probe')
s=s.replace('set fd [open quartus/', 'vlog -sv -work c25_memory_probe tmp/c25_bank_request_pipe.sv\nset fd [open quartus/')
s=s.replace('if {$stem eq "lighthd_bitunpkg"}', 'if {$stem eq "memory_banks"} {vlog -sv -work c25_memory_probe tmp/c25_memory_banks.sv} elseif {$stem eq "lighthd_bitunpkg"}')
s=s.replace('foreach top {tb_lighthd_process_dma tb_lighthd_controller_lifetimes}', 'foreach top {tb_lighthd_bram tb_lighthd_memory tb_lighthd_ntt_dma tb_lighthd_process_dma tb_lighthd_controller_lifetimes}')
s=s.replace('tmp/tb_c25_main_probe.sv','tmp/tb_c25_memory_main_probe.sv')
u['tmp/c25_memory_probe.do']=s
u['tmp/tb_c25_memory_main_probe.sv']=(r/'tmp/tb_c25_main_probe.sv').read_text().replace('stage7c25_probe','stage7c25_memory_probe')
u['tmp/c25_memory_probe_compare.py']=(r/'tmp/c25_probe_compare.py').read_text().replace('stage7c25_probe','stage7c25_memory_probe').replace('C25_PRIVATE_CONTROLLER_COMPARE_PASS','C25_MEMORY_CONTROLLER_COMPARE_PASS')
patch='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and n!=sys.argv[1]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
