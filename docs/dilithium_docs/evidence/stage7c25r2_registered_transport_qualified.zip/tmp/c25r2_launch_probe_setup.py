from pathlib import Path
import hashlib,json,sys
r=Path.cwd();d=r/'tmp/stage7c25r2_launch_probe';d.mkdir(exist_ok=True)
manifest=json.loads((r/'sim/dilithium/reference_build/stage7c25r2_source_hashes.json').read_text())
for n,h in manifest.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
s=(r/'src/keccak/keccak_dual_interleaved.sv').read_text()
s=s.replace('    logic [1:0] core_start;','''    logic [1:0] core_start;
    logic [1:0] launch_start_r,core_busy_internal;
    logic [0:0] launch_mode_r;
    logic [MSG_LEN_WIDTH-1:0] launch_message_r;
    logic [XOF_LEN_WIDTH-1:0] launch_output_r;
    // PRIVATE PROBE: front-end command capture before the wide core start.
    assign core_busy_o=core_busy_internal | launch_start_r;''')
s=s.replace("    assign busy_o = |core_busy_o;","""    assign busy_o = |core_busy_o;
    always_ff @(posedge clk or posedge rst) begin
        if(rst)launch_start_r<=0;
        else if(request_accept)launch_start_r<=2'b01<<dispatch_core;
        else launch_start_r<=0;
    end
    always_ff @(posedge clk) if(request_accept) begin
        launch_mode_r<=keccak_mode_i;
        launch_message_r<=message_len_i;
        launch_output_r<=output_len_i;
    end
    // synthesis translate_off
    always @(posedge clk) if(!rst && (|(core_start & core_busy_internal)))
        $fatal(1,\"Registered launch targets an already busy core\");
    // synthesis translate_on""")
s=s.replace("""        core_start = '0;
        if (request_accept)
            core_start[dispatch_core] = 1'b1;""","""        core_start = launch_start_r;""")
assert 'core_start = launch_start_r;' in s
s=s.replace('.keccak_mode_i  (keccak_mode_i)', '.keccak_mode_i  (launch_mode_r)')
s=s.replace('.message_len_i  (message_len_i)', '.message_len_i  (launch_message_r)')
s=s.replace('.output_len_i   (output_len_i)', '.output_len_i   (launch_output_r)')
s=s.replace('.busy_o         (core_busy_o[core])', '.busy_o         (core_busy_internal[core])')
bench=(r/'tb/tb_dilithium/tb_lighthd_main.sv').read_text().replace('module tb_lighthd_main;','module tb_lighthd_main_launch_probe;')
for leaf in ('stage7c4_main_outputs.txt','stage7c4_main_protocol_outputs.txt','stage7c4_main_diagnostic_outputs.txt'):
 bench=bench.replace('sim/dilithium/'+leaf,'tmp/stage7c25r2_launch_probe/'+leaf)
do="""onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vlib tmp/stage7c25r2_launch_probe/work
vmap launch_probe_work tmp/stage7c25r2_launch_probe/work
set fd [open quartus/dilithium/dilithium_full.qsf r]
set settings [read $fd];close $fd
foreach line [split $settings \"\\n\"] {
 if {[regexp {SYSTEMVERILOG_FILE\\s+(.+)$} [string trim $line] -> source]} {
  if {[file tail $source] eq \"keccak_dual_interleaved.sv\"} {
   vlog -sv -work launch_probe_work tmp/stage7c25r2_launch_probe/keccak_dual_interleaved.sv
  } else {vlog -sv -work launch_probe_work [file normalize [file join quartus/dilithium $source]]}
 }
}
vlog -sv -work launch_probe_work tmp/stage7c25r2_launch_probe/tb_main.sv
vsim -L cyclonev_ver launch_probe_work.tb_lighthd_main_launch_probe
onfinish stop
run -all
quit -sim
vsim -L cyclonev_ver -gDIAGNOSTIC=0 -gPROTOCOL=1 launch_probe_work.tb_lighthd_main_launch_probe
onfinish stop
run -all
quit -f
"""
compare="""from pathlib import Path
import hashlib,json,importlib.util
r=Path.cwd();d=r/'tmp/stage7c25r2_launch_probe'
manifest=json.loads((r/'sim/dilithium/reference_build/stage7c25r2_source_hashes.json').read_text())
for n,h in manifest.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
log=(d/'simulation.log').read_text(errors='replace')
assert '# ** Fatal:' not in log and '# ** Error:' not in log
assert 'LIGHTHD_MAIN_CAPTURE_PASS:9' in log and 'LIGHTHD_MAIN_CAPTURE_PASS:88' in log
spec=importlib.util.spec_from_file_location('launch_probe_reference',r/'sim/dilithium/dilithium_vectors.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.lighthd_main_compare(diagnostic=True,captured=(d/'stage7c4_main_diagnostic_outputs.txt').read_text())
m.lighthd_main_protocol_compare(captured=(d/'stage7c4_main_protocol_outputs.txt').read_text())
print('PRIVATE_REGISTERED_LAUNCH_PROBE_PASS:main9/protocol88;canonical269 source hashes exact;private override only,NOT current source/PPA/UVM coverage evidence')
"""
files=[(d/'keccak_dual_interleaved.sv',s),(d/'tb_main.sv',bench),(d/'run.do',do),(d/'compare.py',compare)]
p,s=files[int(sys.argv[1])-1];assert not p.exists()
print(json.dumps('*** Begin Patch\n*** Add File: '+p.as_posix()+'\n'+''.join('+'+line+'\n' for line in s.splitlines())+'*** End Patch'))
