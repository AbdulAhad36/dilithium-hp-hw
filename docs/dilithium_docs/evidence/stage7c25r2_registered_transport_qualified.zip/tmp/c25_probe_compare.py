from pathlib import Path
import importlib.util
r=Path.cwd();h=r/'sim/dilithium'
spec=importlib.util.spec_from_file_location('v',h/'dilithium_vectors.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
v.lighthd_main_compare(diagnostic=True,captured=(h/'stage7c25_probe_main_diagnostic_outputs.txt').read_text())
v.lighthd_main_protocol_compare(captured=(h/'stage7c25_probe_main_protocol_outputs.txt').read_text())
for leaf in ('diagnostic_outputs.txt','protocol_outputs.txt'):
 a=(h/('stage7c4_main_'+leaf)).read_text().splitlines();b=(h/('stage7c25_probe_main_'+leaf)).read_text().splitlines()
 def completed(lines):
  result={};key=None
  for line in lines:
   x=line.split()
   if x[0]=='J':key=tuple(x[1:])
   if x[0]=='D':result[key]=(tuple(x[1:-1]),int(x[-1]))
  return result
 before,after=completed(a),completed(b);assert before.keys()==after.keys()
 delta=[]
 for key in before:
  assert before[key][0]==after[key][0],(leaf,key,'status/attempts changed')
  delta.append(after[key][1]-before[key][1])
 print(leaf,'completed cycle deltas',min(delta),max(delta))
print('C25_PRIVATE_CONTROLLER_COMPARE_PASS:main9/protocol88 exact published bytes,digests,status and attempts;clock deltas measured;reset prefixes checked against published bytes,not forced to old lengths')
