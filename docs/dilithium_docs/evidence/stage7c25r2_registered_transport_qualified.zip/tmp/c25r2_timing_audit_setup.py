from pathlib import Path
import json
r=Path.cwd()
s=(r/'tmp/c25_timing_audit.tcl').read_text()
s=s.replace('# Read-only analysis of the immutable C24 routed database,not C25 PPA.','# Read-only detailed analysis of the qualified C25R2 routed database.')
s=s.replace('stage7c25_C24_timing_audit','stage7c25r2_timing_audit').replace('C25_C24_TIMING_AUDIT_COMPLETE','C25R2_TIMING_AUDIT_COMPLETE')
s=s.replace('  dma_control {','  ntt_dma {*|lighthd_ntt_dma:polynomial|*}\n  request_queue {*|bank_request_pipe:*|*}\n  dma_control {')
p=r/'sim/dilithium/reference_build/stage7c25r2_timing_audit.tcl';assert not p.exists()
print(json.dumps('*** Begin Patch\n*** Add File: '+p.as_posix()+'\n'+''.join('+'+x+'\n' for x in s.splitlines())+'*** End Patch'))
