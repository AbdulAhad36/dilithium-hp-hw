from pathlib import Path
import hashlib,json,zipfile
r=Path.cwd();rb=r/'sim/dilithium/reference_build';q=r/'quartus/dilithium';h=r/'sim/dilithium';ev=r/'docs/dilithium_docs/evidence'
source=json.loads((rb/'stage7c25r2_source_hashes.json').read_text())
for n,d in source.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
target=ev/'stage7c25r2_generated_scope_guard_failure.zip'
assert not target.exists() and not target.with_suffix('.sha256').exists()
paths=set(source)|{'sim/dilithium/reference_build/stage7c25r2_source_hashes.json','sim/dilithium/reference_build/stage7c25r2_stream_registers.py','AGENTS.md'}
for base,pattern in ((q,'stage7c25r2*'),(h,'stage7c25r2*')):
 paths|={p.relative_to(r).as_posix() for p in base.glob(pattern) if p.is_file() and p.suffix=='.log'}
for leaf in ('retained_registers.rpt','mapped_register_names.rpt'):paths.add('quartus/dilithium/critical_full/'+leaf)
files={n:(r/n).read_bytes() for n in paths}
files['RESULTS.json']=(json.dumps(dict(stage='C25R2 original generated-instance guard failure',full_compile_pass=True,physical_retention_qualified=False,
 reason='Original guard expects bank_request_pipe:request_pipe,actual instance is bank_request_pipe:bank[n].request_pipe. Actual names contain1648payload+16count+16pointer+16age bits;thresholds are not reduced.',
 source_count=269,source_unchanged=True,critical_corner_reports='Not included:still historical because original report stops before four-corner extraction'),indent=2)+'\n').encode()
manifest={n:hashlib.sha256(b).hexdigest() for n,b in files.items()};files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 for n,d in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==d
digest=hashlib.sha256(target.read_bytes()).hexdigest()
with target.with_suffix('.sha256').open('x') as f:f.write(digest+'  '+target.name+'\n')
report=(q/'report_full.tcl').read_text()
old=r'\|bank_request_pipe:request_pipe\|';new=r'\|bank_request_pipe:bank\[[0-3]\]\.request_pipe\|'
assert report.count(old)==4
fixed=report.replace(old,new)
assert fixed!=report and fixed.replace(new,old)==report
candidate=rb/'stage7c25r2_generated_scope_report.tcl';assert not candidate.exists()
patch='*** Begin Patch\n*** Add File: '+candidate.as_posix()+'\n'+''.join('+'+x+'\n' for x in fixed.splitlines())+'*** End Patch'
print(json.dumps(dict(patch=patch,archive=str(target),sha256=digest,members=len(files))))
