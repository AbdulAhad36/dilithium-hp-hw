from pathlib import Path
import hashlib,json,sys
r=Path.cwd();rb=r/'sim/dilithium/reference_build';u={}
names=('native_runner.ps1','quartus_runner.ps1','foundation_runner.ps1','production_runner.ps1','uvm_runner.ps1','collect_runner.ps1','foundation.do','production.do','metrics.py','admission_registers.py','native_structure.py','shared_hint_registers.py','operand_registers.py','stream_registers.py','lifetime_registers.py','writer_registers.py','area_delta.py','throughput.py','cycle_audit.py','proof_reuse.py')
for name in names:
 s=(rb/('stage7c25_'+name)).read_text(encoding='utf-8').replace('stage7c25','stage7c25r1').replace('STAGE7C25','STAGE7C25R1').replace('C25_','C25R1_')
 if name=='foundation_runner.ps1':
  needle="if ($LASTEXITCODE -ne 0) {throw 'Native foundation failed'}"
  assert needle in s;s=s.replace(needle,needle+'''\nif(Select-String -LiteralPath sim/dilithium/stage7c25r1_foundation.log -SimpleMatch -Pattern @('# ** Fatal:','# ** Error:') -Quiet){throw 'A foundation test reported a fatal/error;PASS markers do not override failures'}''')
 u['sim/dilithium/reference_build/stage7c25r1_'+name]=s
old=json.loads((rb/'stage7c25_source_hashes.json').read_text());new={n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in old}
assert len(new)==269 and {n for n in old if old[n]!=new[n]}=={'tb/tb_dilithium/tb_lighthd_memory.sv'}
u['sim/dilithium/reference_build/stage7c25r1_source_hashes.json']=json.dumps(new,indent=2)+'\n'
u['sim/dilithium/reference_build/stage7c25r1_source_audit.py']='''from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c25_source_hashes.json').read_text());new=json.loads((rb/'stage7c25r1_source_hashes.json').read_text())
for n,d in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
assert len(new)==269 and set(old)==set(new)
assert {n for n in old if old[n]!=new[n]}=={'tb/tb_dilithium/tb_lighthd_memory.sv'}
assert 'Physical collision accepted' in (r/'tb/tb_dilithium/tb_lighthd_memory.sv').read_text()
assert 'physical_expected' in (r/'tb/tb_dilithium/tb_lighthd_memory.sv').read_text()
assert 'period 6.500' in (r/'quartus/dilithium/dilithium.sdc').read_text()
print('C25R1_SOURCE_AUDIT_PASS:269 frozen;only canonical memory observer changed versus archived initial C25;all RTL/QSF/SDC/report/Python/UVM benches exact;physical collision assertion retained;153.85MHz performance target')
'''
p='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and Path(n).name not in sys.argv[1:]:continue
 assert not (r/n).exists(),n
 p+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(p+'*** End Patch'))
