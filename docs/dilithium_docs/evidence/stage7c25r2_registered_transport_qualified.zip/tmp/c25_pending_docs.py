from pathlib import Path
import json,difflib,sys
r=Path.cwd();leaf=sys.argv[1];p=r/leaf;s=p.read_text(encoding='utf-8');title,tail=s.split('\n\n',1)
note='''## C25 active: timing and latency first

The user has deferred further area reduction. Keep the footprint near the
current30.6K placed-ALM baseline;prioritize **150+MHz minimum,positive setup
slack,lower time per operation and exact NIST outputs**. The former under20K
objective is deferred,not achieved. The permanent full-project clock target
is now **6.500ns /153.85MHz**,with the same Cyclone V and hold constraints.
Quartus uses `HIGH PERFORMANCE EFFORT`;retiming and register duplication
remain explicitly off. The main UVM clock also uses6.500ns. Performance-mode
settings are documented in the [Standard Edition optimization guide](https://www.intel.com/programmable/technical-pdfs/683230.pdf).

**Current RTL is the C25 candidate,not yet qualified PPA.** C22/C23/C24 archives
remain immutable. Fresh prepare/foundation/full210official/protocol88/checker90/
main33UVM/negative and same-device placed/four-corner/retention gates must finish.
Do not edit269 frozen source/config/reference files or launch duplicate
project/library jobs. C25 has no measured placed area or Fmax yet. Existing
physical reports still describe C24 until the fresh full compile replaces them.

Changes target the measured long paths rather than another area rewrite:

- One80-bit registered unpacker window separates word alignment from validation.
- Two request slots per physical bank port register memory backpressure.
  A four-bit age relation per bank prevents younger conflicting requests from
  overtaking older requests while allowing unrelated A/B traffic to progress.
  The physical RAM and its collision guard are unchanged;both ports sustainII1.
- One21-bit sampling-completion record separates sampler arbitration/ID selection
  from the owning controller's state/error logic.
- Parallel narrow hint prefix counts replace serial carry propagation.
- The previously proved C23 field conversion and C24 packing/selection changes
  are included. Engine arithmetic and Process arithmetic are unchanged.

The new preparation/transport stages can add clocks. Always report measured
operation clocks AND time/rates using actual worst-corner Fmax. No zero-cost
or150MHz-complete claim follows from source simulation. Private completed
main9/protocol88 clock deltas are20..1082 /0..1089 versus C22,with all published
bytes,digests,statuses and attempt counts exact. Reset prefix lengths may vary;
every emitted prefix byte is still checked against published expected bytes.
The authoritative Python comparison mathematics was not relaxed.

Focused proofs pass:unpacker1241packets/310504coefficients/29invalid/6occupied
resets;field2390144vectors/9560960lane values;hint786432prefix combinations;
actualRAM request-pipe20732accepted/20720issued/20708replies/15741age checks/
10347full clocks/10825renewals/1281independent bypasses/3full resets/bothpointer
phases/12unissued requests discarded. Peak dual-portII1 is explicitly checked.
These focused probes are not merged into main functional/code coverage.

The initial coupled-port queue deadlocked KeyGen through head-of-line blocking.
It is rejected and preserved with its failure/debug logs;only the independently
queued revision passed promotion. A first complete-probe launcher used a wrong
bench filename;the corrected retry passes. Old unpacker cycle-equivalence
benches remain historical;new semantic tests check the intentionally changed
timing. Unchanged exhaustive Process arithmetic is reused from C18R1 through
10byte-identical source/reference files,not relabelled as a fresh execution.
No commit,branch change,Stage8 or user performance acceptance.

'''
if leaf.endswith('MEMORY_MAP.md'):
 note+='''### Registered request boundary (one of four banks)

```mermaid
flowchart LR
  A["A scheduler request\nwrite +10-bit address +92-bit data"] --> AQ["A queue:2 x103bits\nready from registered occupancy"]
  B["B scheduler request\nwrite +10-bit address +92-bit data"] --> BQ["B queue:2 x103bits\nready from registered occupancy"]
  AQ --> ORDER["4-bit older-slot relation\nonly conflicting younger requests wait"]
  BQ --> ORDER
  ORDER --> RAM["Existing dual-port RAM\n1024words x92bits\ncollision protection retained"]
  RAM --> RESP["Existing registered responses\nphysical completion before retirement"]
```

Four banks retain the same coefficient storage. The new transport is1,648
request-payload/metadata bits plus48 queue-control/age bits across the four
banks (1,696logical FF bits),not another polynomial RAM. Reset invalidates
queued requests and responses;already committed RAM writes remain. The
independent model rolls back unissued requests to the actual committed RAM
state on reset. No accepted request is reported completed before its physical
response. Full placed ALMs/registers must be measured after compilation.

'''
assert not tail.startswith('## C25 active')
tail=tail.replace('## Current working source: C22; C24 preserved as an area option','## Historical C22 selection before the C25 timing trial',1)
new=title+'\n\n'+note+tail;d=list(difflib.unified_diff(s.splitlines(True),new.splitlines(True)))
print(json.dumps('*** Begin Patch\n*** Update File: '+leaf+'\n'+''.join('@@\n' if x.startswith('@@') else x for x in d[2:])+'*** End Patch'))
