from pathlib import Path
import json
r=Path.cwd();s=(r/'tmp/tb_c25_memory_debug.sv').read_text();i=s.rindex('endmodule')
s=s[:i]+'''
 always @(posedge clk)if(!rst && cycles==20000)begin
  $display("C25_DEADLOCK:KG%s NTT%s Proc%s HashFault%b WriterFault%b active%h normal_count%0d",dut.core.keygen_controller.state.name(),dut.core.datapath.polynomial.state.name(),dut.core.datapath.process_path.state.name(),dut.core.datapath.hash_sampler.fault_o,dut.core.datapath.hash_sampler.writer.fault_o,dut.core.datapath.hash_sampler.writer.active_r,dut.core.datapath.hash_sampler.writer.normal_count_r);
  $display("NTT inputs%0d outputs%0d all_sources%b code%0d",dut.core.datapath.polynomial.inputs_r,dut.core.datapath.polynomial.outputs_r,dut.core.datapath.polynomial.all_sources,dut.core.datapath.polynomial.code_r);
 end
 for(genvar dbg=0;dbg<4;dbg++)begin
  always @(posedge clk)if(!rst && cycles==20000)begin
   $display("BANK%0d states %s/%s issued %0d/%0d retired %0d/%0d Q%0d mask%h issuedMask%h reqV%h reqR%h rspV%h rspR%h",dbg,
    dut.core.datapath.memory.storage.port_fsm[0].scheduler.state[dbg].name(),dut.core.datapath.memory.storage.port_fsm[1].scheduler.state[dbg].name(),
    dut.core.datapath.memory.storage.port_fsm[0].scheduler.issued_r[dbg],dut.core.datapath.memory.storage.port_fsm[1].scheduler.issued_r[dbg],
    dut.core.datapath.memory.storage.port_fsm[0].scheduler.retired_r[dbg],dut.core.datapath.memory.storage.port_fsm[1].scheduler.retired_r[dbg],
    dut.core.datapath.memory.storage.banks.bank[dbg].request_pipe.count_r,dut.core.datapath.memory.storage.banks.bank[dbg].request_pipe.head_mask,dut.core.datapath.memory.storage.banks.bank[dbg].request_pipe.issued_r,
    dut.core.datapath.memory.storage.banks.bank[dbg].queued_valid,dut.core.datapath.memory.storage.banks.bank[dbg].queued_ready,
    {dut.core.datapath.memory.storage.response_valid[1][dbg],dut.core.datapath.memory.storage.response_valid[0][dbg]},
    {dut.core.datapath.memory.storage.response_ready[1][dbg],dut.core.datapath.memory.storage.response_ready[0][dbg]});
  end
 end
 initial begin wait(cycles==20002);$display("C25_DIAGNOSTIC_CAPTURE_ONLY_NOT_PASS");$finish;end
'''+s[i:]
d=(r/'tmp/c25_memory_debug.do').read_text().replace('work_c25_memory_debug','work_c25_memory_debug_r1').replace('c25_memory_debug','c25_memory_debug_r1')
d=d.replace('tmp/tb_c25_memory_debug.sv','tmp/tb_c25_memory_debug_r1.sv')
u={'tmp/tb_c25_memory_debug_r1.sv':s,'tmp/c25_memory_debug_r1.do':d};p='*** Begin Patch\n'
for n,t in u.items():
 assert not (r/n).exists()
 p+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in t.splitlines())
print(json.dumps(p+'*** End Patch'))
