module launch_empty_case #(parameter integer OFFSET=0)(output logic finished=0);
 timeunit 1ns;timeprecision 1ps;
 logic clk=0,rst=1,request_valid=0,request_ready,request_core,mode=0;
 logic [1:0] core_busy,core_done;
 logic busy,output_valid,output_core,output_ready;
 logic [127:0] data;
 logic [4:0] bytes_out;
 logic [1:0] expected_valid;
 logic [127:0] expected[2];
 integer clocks=0,accepted=0,checked=0,held=0,consecutive=0,last_accept=-2;
 logic stalled=0;
 logic [127:0] held_data;
 logic held_core;
 always #5 clk=~clk;
 assign output_ready=!rst && clocks%5>=2;
 keccak_dual_interleaved #(.START_OFFSET_CYCLES(OFFSET)) dut(
  .clk(clk),.rst(rst),.request_valid_i(request_valid),.request_ready_o(request_ready),
  .request_core_o(request_core),.keccak_mode_i(mode),.message_len_i(16'd0),.output_len_i(16'd16),
  .input_data_i(64'd0),.input_valid_i(1'b0),.input_ready_o(),.input_core_o(),
  .stop_i(2'b0),.core_busy_o(core_busy),.core_done_o(core_done),.busy_o(busy),
  .output_data_o(data),.output_valid_o(output_valid),.output_bytes_o(bytes_out),
  .output_core_o(output_core),.output_ready_i(output_ready));
 always @(posedge clk)begin
  if(rst)begin expected_valid=0;accepted=0;checked=0;stalled=0;last_accept=-2;consecutive=0;held=0;clocks=0;end
  else begin
   clocks=clocks+1;
   if(stalled)begin
    if(!output_valid || data!==held_data || output_core!==held_core || bytes_out!==16)$fatal(1,"Empty hash stalled payload changed");
    held=held+1;
   end
   if(request_valid && request_ready)begin
    if(expected_valid[request_core])$fatal(1,"Empty hash reused owned core");
    expected_valid[request_core]=1;
    expected[request_core]=mode?128'h24eb3e74eb3f3b23138da80b2bddb946:128'h3e850576504560617d828fe8a42b9c7f;
    if(clocks==last_accept+1)consecutive=consecutive+1;
    last_accept=clocks;accepted=accepted+1;
   end
   if(output_valid && output_ready)begin
    if(!expected_valid[output_core] || bytes_out!==16 || data!==expected[output_core])$fatal(1,"Empty SHAKE Python-derived digest mismatch");
    expected_valid[output_core]=0;checked=checked+1;
   end
   stalled=output_valid && !output_ready;
   if(stalled)begin held_data=data;held_core=output_core;end
   if(clocks>5000)$fatal(1,"Empty hash watchdog");
  end
 end
 task automatic send_empty(input logic selected_mode);
  @(negedge clk);request_valid=1;mode=selected_mode;
  @(posedge clk);while(!request_ready)@(posedge clk);
  #1;
 endtask
 initial begin
  repeat(3)@(negedge clk);rst=0;
  // Reset after descriptor acceptance, before its registered core launch.
  send_empty(0);
  @(negedge clk);request_valid=0;rst=1;
  repeat(2)@(negedge clk);rst=0;
  repeat(3)@(negedge clk);
  if(busy || output_valid)$fatal(1,"Pending descriptor survived reset");
  send_empty(0);send_empty(1);send_empty(1);send_empty(0);send_empty(1);send_empty(0);
  @(negedge clk);request_valid=0;
  wait(checked==6);
  repeat(4)@(negedge clk);
  if(accepted!=6 || expected_valid!=0 || held==0)$fatal(1,"Missing empty-hash/stall checks");
  if(OFFSET<=1 && consecutive==0)$fatal(1,"No consecutive empty command accepts");
  $display("PRIVATE_EMPTY_LAUNCH_PASS:offset%0d accepted%0d checked%0d held%0d consecutive%0d reset-pending",OFFSET,accepted,checked,held,consecutive);
  finished=1;
 end
endmodule
module tb_launch_empty;
 wire [2:0] finished;
 launch_empty_case #(.OFFSET(0)) c0(finished[0]);
 launch_empty_case #(.OFFSET(1)) c1(finished[1]);
 launch_empty_case #(.OFFSET(26)) c26(finished[2]);
 initial begin wait(&finished);$display("PRIVATE_EMPTY_LAUNCH_ALL_PASS:18 empty SHAKE128/256 outputs;offset0/1/26;stalls;pending reset");$finish;end
endmodule
