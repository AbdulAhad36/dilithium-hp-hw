from pathlib import Path
import hashlib,json,importlib.util
r=Path.cwd();d=r/'tmp/stage7c25r2_launch_probe'
manifest=json.loads((r/'sim/dilithium/reference_build/stage7c25r2_source_hashes.json').read_text())
for n,h in manifest.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==h,n
log=(d/'simulation.log').read_text(errors='replace')
assert '# ** Fatal:' not in log and '# ** Error:' not in log
assert 'LIGHTHD_MAIN_CAPTURE_PASS:9' in log and 'LIGHTHD_MAIN_CAPTURE_PASS:88' in log
spec=importlib.util.spec_from_file_location('launch_probe_reference',r/'sim/dilithium/dilithium_vectors.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.lighthd_main_compare(diagnostic=True,captured=(d/'stage7c4_main_diagnostic_outputs.txt').read_text())
m.lighthd_main_protocol_compare(captured=(d/'stage7c4_main_protocol_outputs.txt').read_text())
print('PRIVATE_REGISTERED_LAUNCH_PROBE_PASS:main9/protocol88;canonical269 source hashes exact;private override only,NOT current source/PPA/UVM coverage evidence')
