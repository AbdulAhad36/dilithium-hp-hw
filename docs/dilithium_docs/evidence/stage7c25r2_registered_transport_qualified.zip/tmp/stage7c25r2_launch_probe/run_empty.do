onerror {quit -code 1 -f}
vmap launch_probe_work tmp/stage7c25r2_launch_probe/work
vlog -sv -work launch_probe_work tmp/stage7c25r2_launch_probe/tb_empty.sv
vsim launch_probe_work.tb_launch_empty
onfinish stop
run -all
quit -f
