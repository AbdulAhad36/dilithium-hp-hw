onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vlib tmp/stage7c25r2_launch_probe/work
vmap launch_probe_work tmp/stage7c25r2_launch_probe/work
set fd [open quartus/dilithium/dilithium_full.qsf r]
set settings [read $fd];close $fd
foreach line [split $settings "\n"] {
 if {[regexp {SYSTEMVERILOG_FILE\s+(.+)$} [string trim $line] -> source]} {
  if {[file tail $source] eq "keccak_dual_interleaved.sv"} {
   vlog -sv -work launch_probe_work tmp/stage7c25r2_launch_probe/keccak_dual_interleaved.sv
  } else {vlog -sv -work launch_probe_work [file normalize [file join quartus/dilithium $source]]}
 }
}
vlog -sv -work launch_probe_work tmp/stage7c25r2_launch_probe/tb_main.sv
vsim -L cyclonev_ver launch_probe_work.tb_lighthd_main_launch_probe
onfinish stop
run -all
quit -sim
vsim -L cyclonev_ver -gDIAGNOSTIC=0 -gPROTOCOL=1 launch_probe_work.tb_lighthd_main_launch_probe
onfinish stop
run -all
quit -f
