from pathlib import Path
import zipfile,json
r=Path.cwd();d=r/'tmp/stage7c25r2_launch_probe'
with zipfile.ZipFile(r/'docs/dilithium_docs/evidence/stage7c25r1_generate_syntax_failure.zip') as z:
 result={}
 for leaf in ('stage7c4_main_diagnostic_outputs.txt','stage7c4_main_protocol_outputs.txt'):
  old=z.read('sim/dilithium/'+leaf).decode().splitlines()[1:]
  new=(d/leaf).read_text().splitlines()[1:]
  result[leaf]=dict(all_non_token_records_equal=old==new,
                   old_completed=sum(x.startswith('D ') for x in old),
                   new_completed=sum(x.startswith('D ') for x in new))
  old_cycles=[int(x.split()[-1]) for x in old if x.startswith('D ')]
  new_cycles=[int(x.split()[-1]) for x in new if x.startswith('D ')]
  assert len(old_cycles)==len(new_cycles)
  result[leaf]['latency_deltas']=[b-a for a,b in zip(old_cycles,new_cycles)]
print(json.dumps(result,indent=2))
assert all(x['all_non_token_records_equal'] for x in result.values())
print('PRIVATE_LAUNCH_ALL_RECORDS_EXACT_R1_PASS:main9/protocol88 include all completed clock records and reset prefixes;R1/R2 differ only in generate syntax;NOT PPA/full-source qualification')
