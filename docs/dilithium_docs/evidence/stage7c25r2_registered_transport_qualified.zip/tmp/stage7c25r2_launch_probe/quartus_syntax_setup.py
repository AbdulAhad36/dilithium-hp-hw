from pathlib import Path
import json,re
r=Path.cwd();d=r/'tmp/stage7c25r2_launch_probe/quartus_syntax';d.mkdir(exist_ok=True)
lines=['set_global_assignment -name FAMILY "Cyclone V"',
       'set_global_assignment -name DEVICE 5CGXFC7C7F23C8',
       'set_global_assignment -name TOP_LEVEL_ENTITY keccak_dual_interleaved',
       'set_global_assignment -name PROJECT_OUTPUT_DIRECTORY output']
for line in (r/'quartus/dilithium/dilithium_full.qsf').read_text().splitlines():
 m=re.search(r'SYSTEMVERILOG_FILE\s+(.+)$',line)
 if not m:continue
 p=(r/'quartus/dilithium'/m[1]).resolve()
 if p.parent!=r/'src/keccak':continue
 if p.name=='keccak_dual_interleaved.sv':p=r/'tmp/stage7c25r2_launch_probe/keccak_dual_interleaved.sv'
 lines.append('set_global_assignment -name SYSTEMVERILOG_FILE "'+p.as_posix()+'"')
patch='*** Begin Patch\n'
for p,s in ((d/'launch.qpf','PROJECT_REVISION = "launch"\n'),(d/'launch.qsf','\n'.join(lines)+'\n')):
 assert not p.exists()
 patch+='*** Add File: '+p.as_posix()+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
