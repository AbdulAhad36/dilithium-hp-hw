from pathlib import Path
import json
r=Path.cwd();d=r/'tmp/stage7c25_bank_syntax_probe';d.mkdir(exist_ok=True)
s=(r/'src/controller/memory/bank_request_pipe.sv').read_text()
s=s.replace(' for(genvar p=0;p<2;p++)begin:port_fields',' generate\n for(genvar p=0;p<2;p++)begin:port_fields')
s=s.replace(' end\n always_comb begin',' end\n endgenerate\n always_comb begin',1)
files={'bank_request_pipe.sv':s,
'queue.qpf':'PROJECT_REVISION = "queue"\n',
'queue.qsf': 'set_global_assignment -name FAMILY "Cyclone V"\nset_global_assignment -name DEVICE 5CGXFC7C7F23C8\nset_global_assignment -name TOP_LEVEL_ENTITY bank_request_pipe\nset_global_assignment -name SYSTEMVERILOG_FILE bank_request_pipe.sv\nset_global_assignment -name PROJECT_OUTPUT_DIRECTORY output\n'}
patch='*** Begin Patch\n'
for n,b in files.items():
 p=d/n;assert not p.exists()
 patch+='*** Add File: '+p.as_posix()+'\n'+''.join('+'+l+'\n' for l in b.splitlines())
print(json.dumps(patch+'*** End Patch'))
