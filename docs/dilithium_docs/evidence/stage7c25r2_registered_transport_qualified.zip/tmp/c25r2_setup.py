from pathlib import Path
import hashlib,json,sys
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
ev=r/'docs/dilithium_docs/evidence'
archive=ev/'stage7c25r1_generate_syntax_failure.zip'
assert archive.exists() and archive.with_suffix('.sha256').exists(),'Archive failed revision first'
d,n=archive.with_suffix('.sha256').read_text().split();assert hashlib.sha256(archive.read_bytes()).hexdigest()==d
old=json.loads((rb/'stage7c25r1_source_hashes.json').read_text())
for n,d in old.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
name='src/controller/memory/bank_request_pipe.sv'
before=(r/name).read_text();after=(r/'tmp/stage7c25_bank_syntax_probe/bank_request_pipe.sv').read_text()
expect=before.replace(' for(genvar p=0;p<2;p++)begin:port_fields',' genvar p,slot;\n generate\n for(p=0;p<2;p=p+1)begin:port_fields').replace('  for(genvar slot=0;slot<2;slot++)begin:valid_slot','  for(slot=0;slot<2;slot=slot+1)begin:valid_slot').replace(' end\n always_comb begin',' end\n endgenerate\n always_comb begin',1)
assert after==expect
files={}
def replace(s):return s.replace('stage7c25r1','stage7c25r2').replace('STAGE7C25R1','STAGE7C25R2').replace('C25R1','C25R2')
for suffix in ('native_runner.ps1','quartus_runner.ps1','foundation_runner.ps1','production_runner.ps1','uvm_runner.ps1','collect_runner.ps1','foundation.do','production.do','metrics.py','admission_registers.py','native_structure.py','shared_hint_registers.py','operand_registers.py','stream_registers.py','lifetime_registers.py','writer_registers.py','area_delta.py','throughput.py','cycle_audit.py','proof_reuse.py','counter_window_selftest.py'):
 s=replace((rb/('stage7c25r1_'+suffix)).read_text())
 if suffix=='foundation_runner.ps1':
  s=s.replace("'lighthd_counter_selftest',",'')
  s=s.replace("foreach ($gate in", "& 'C:/Python314/python.exe' sim/dilithium/reference_build/stage7c25r2_counter_window_selftest.py *> sim/dilithium/stage7c25r2_counter_window_selftest.log\nif ($LASTEXITCODE -ne 0) {throw 'Window counter model failed'}\nforeach ($gate in",1)
 files[rb/('stage7c25r2_'+suffix)]=s
for p in (rb/'stage7c25r1_baseline_c22').iterdir():
 if p.is_file():files[rb/'stage7c25r2_baseline_c22'/p.name]=p.read_text()
source=dict(old);source[name]=hashlib.sha256(after.encode()).hexdigest()
files[rb/'stage7c25r2_source_hashes.json']=json.dumps(source,indent=2)+'\n'
audit="""from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c25r1_source_hashes.json').read_text());new=json.loads((rb/'stage7c25r2_source_hashes.json').read_text())
assert len(new)==269 and set(old)==set(new)
for n,d in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
assert {n for n in old if old[n]!=new[n]}=={'src/controller/memory/bank_request_pipe.sv'}
assert 'genvar p,slot;' in (r/'src/controller/memory/bank_request_pipe.sv').read_text()
assert 'period 6.500' in (r/'quartus/dilithium/dilithium.sdc').read_text()
print('C25R2_SOURCE_AUDIT_PASS:269 frozen;only explicit generate/module-scope genvar syntax differs from archived R1;no logic/NIST math/settings changes;153.85MHz target')
"""
files[rb/'stage7c25r2_source_audit.py']=audit
selected=int(sys.argv[1])
patch='*** Begin Patch\n'
if selected==0:patch+='*** Update File: '+(r/name).as_posix()+'\n@@\n'+''.join('-'+l+'\n' for l in before.splitlines())+''.join('+'+l+'\n' for l in after.splitlines())
for i,(p,s) in enumerate(files.items(),1):
 if selected!=i:continue
 assert not p.exists(),p
 patch+='*** Add File: '+p.as_posix()+'\n'+''.join('+'+l+'\n' for l in s.splitlines())
if selected==-1:print(len(files))
elif selected==-2:
 for p,s in files.items():
  if p.name=='stage7c25r2_source_hashes.json' or p.parent.name=='stage7c25r2_baseline_c22':
   assert not p.exists(),p
   p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
 print('C25R2_GENERATED_MANIFEST_AND_BASELINE_CACHE_CREATED')
else:print(json.dumps(patch+'*** End Patch'))
