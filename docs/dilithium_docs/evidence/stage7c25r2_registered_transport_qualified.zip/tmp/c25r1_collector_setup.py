from pathlib import Path
import json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
s=(rb/'stage7c25r1_collect_runner.ps1').read_text()
s=s.replace('foreach ($kind in',"""if (-not (Select-String -LiteralPath sim/dilithium/stage7c25r1_resume_runner.log -SimpleMatch 'STAGE7C25R1_NATIVE_RUNNER_PASS' -Quiet)) {throw 'Recovered native qualification incomplete'}
foreach ($kind in""")
s=s.replace("@('native','uvm','quartus')","@('uvm','quartus')")
s=s.replace('C18 qualification','C25R1 qualification').replace('C18 result','C25R1 result')
p=rb/'stage7c25r1_resume_collect_runner.ps1'
assert not p.exists()
print(json.dumps('*** Begin Patch\n*** Add File: '+p.as_posix()+'\n'+''.join('+'+l+'\n' for l in s.splitlines())+'*** End Patch'))
