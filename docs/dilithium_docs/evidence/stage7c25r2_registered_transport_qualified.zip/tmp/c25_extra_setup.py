from pathlib import Path
import json,sys
r=Path.cwd();u={}
s=(r/'src/controller/datapath/lighthd_hash_sampler.sv').read_text()
s=s.replace('  logic bad_job,bad_pending_r;', '  logic completion_valid_r,completion_core_r;\n  logic [15:0] completion_id_r;logic [2:0] completion_code_r;\n  logic completion_take;\n  logic bad_job,bad_pending_r;')
s=s.replace('!load_owned_r && !bad_pending_r', '!load_owned_r && !bad_pending_r && !completion_valid_r')
s=s.replace('!bad_job && !bad_pending_r', '!bad_job && !bad_pending_r && !completion_valid_r')
s=s.replace('assign done_valid_o=bad_pending_r || (!load_owned_r && writer_done_valid);','assign done_valid_o=bad_pending_r || completion_valid_r;')
s=s.replace('bad_id_r:writer_done_id;', 'bad_id_r:completion_id_r;').replace("1'b0:writer_done_core;", "1'b0:completion_core_r;").replace("3'd3:writer_done_code;", "3'd3:completion_code_r;")
s=s.replace('load_owned_r?manual_done_ready:done_ready_i && !bad_pending_r;', 'load_owned_r?manual_done_ready:!completion_valid_r && !bad_pending_r;')
a=s.index('  always_ff @(posedge clk or posedge rst)begin')
s=s[:a]+'''  // One registered completion record cuts sampler arbitration/ID selection
  // away from the owning controller's error/state transition path.
  assign completion_take=!load_owned_r && writer_done_valid && writer_done_ready;
  always_ff @(posedge clk or posedge rst)begin
    if(rst)completion_valid_r<=0;
    else if(completion_take)completion_valid_r<=1;
    else if(completion_valid_r && done_ready_i)completion_valid_r<=0;
  end
  always_ff @(posedge clk)if(completion_take)begin
    completion_core_r<=writer_done_core;completion_id_r<=writer_done_id;completion_code_r<=writer_done_code;
  end
'''+s[a:]
u['tmp/c25_lighthd_hash_sampler.sv']=s
s=(r/'src/controller/process/lighthd_hint_codec.sv').read_text()
s=s.replace('  logic e_first_write,e_second_write,e_push,e_bad_frame,e_overflow;', '  logic e_first_write,e_second_write,e_push,e_bad_frame,e_overflow;\n  logic [4:0][2:0] e_prefix;logic [3:0][6:0] e_target;')
s=s.replace('    e_new_total=e_total_r;e_first_index=e_total_r[6:3];e_second_index=e_first_index+1\'b1;', '''    // Narrow parallel prefix counts:one7-bit base addition per lane,not
    // four serial7-bit increments controlled by the incoming hint mask.
    e_prefix[0]=0;e_prefix[1]=3'(e_input_hints_i[0]);
    e_prefix[2]=3'(e_input_hints_i[0])+3'(e_input_hints_i[1]);
    e_prefix[3]=e_prefix[2]+3'(e_input_hints_i[2]);
    e_prefix[4]=e_prefix[2]+(3'(e_input_hints_i[2])+3'(e_input_hints_i[3]));
    for(int lane=0;lane<4;lane++)e_target[lane]=e_total_r+7'(e_prefix[lane]);
    e_new_total=e_total_r+7'(e_prefix[4]);e_first_index=e_total_r[6:3];e_second_index=e_first_index+1'b1;''')
s=s.replace('if(e_new_total<e_omega_r && !e_result_reject_o)', 'if(e_target[e_lane]<e_omega_r && !e_result_reject_o)')
s=s.replace('if(e_new_total[6:3]==e_first_index)', 'if(e_target[e_lane][6:3]==e_first_index)')
s=s.replace('8*e_new_total[2:0]+:8', '8*e_target[e_lane][2:0]+:8')
s=s.replace("      e_new_total=e_new_total+1'b1;\n",'')
u['tmp/c25_lighthd_hint_codec.sv']=s
u['tmp/lighthd_hint_codec_c22_reference.sv']=(r/'src/controller/process/lighthd_hint_codec.sv').read_text().replace('module lighthd_hint_codec(', 'module lighthd_hint_codec_c22_reference(')
s=(r/'tmp/c25_memory_r1.do').read_text().replace('work_c25_memory_r1','work_c25_complete_probe').replace('c25_memory_r1','c25_complete_probe')
needle='if {$stem eq "memory_banks"}'
s=s.replace(needle,'if {$stem eq "lighthd_hash_sampler" || $stem eq "lighthd_hint_codec"} {vlog -sv -work c25_complete_probe tmp/c25_${stem}.sv} elseif {$stem eq "memory_banks"}')
s=s.replace('tmp/tb_c25_memory_r1_main.sv','tmp/tb_c25_complete_main.sv')
s=s.replace('foreach top {tb_lighthd_bram', 'foreach top {tb_lighthd_hash_sampler tb_lighthd_hint_shared tb_lighthd_hintpkg tb_lighthd_hintunpkg tb_lighthd_bram')
u['tmp/c25_complete_probe.do']=s
u['tmp/tb_c25_complete_main.sv']=(r/'tmp/tb_c25_memory_r1_main.sv').read_text().replace('stage7c25_memory_r1','stage7c25_complete')
u['tmp/c25_complete_compare.py']=(r/'tmp/c25_memory_r1_compare.py').read_text().replace('stage7c25_memory_r1','stage7c25_complete').replace('C25_MEMORY_CONTROLLER_COMPARE_PASS','C25_COMPLETE_CONTROLLER_COMPARE_PASS')
p='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and n!=sys.argv[1]:continue
 assert not (r/n).exists()
 p+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(p+'*** End Patch'))
