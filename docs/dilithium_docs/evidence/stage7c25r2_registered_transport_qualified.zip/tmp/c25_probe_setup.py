from pathlib import Path
import json,sys
r=Path.cwd();u={}
s=(r/'tmp/c24_probe.do').read_text().replace('work_c24_probe','work_c25_probe').replace('c24_probe','c25_probe')
s=s.replace('if {$stem eq "lighthd_bitpkg" || $stem eq "lighthd_process_dma"} {vlog -sv -work c25_probe tmp/c24_${stem}.sv}',
 '''if {$stem eq "lighthd_bitunpkg"} {vlog -sv -work c25_probe tmp/c25_lighthd_bitunpkg.sv} elseif {$stem eq "lighthd_bitpkg" || $stem eq "lighthd_process_dma"} {vlog -sv -work c25_probe tmp/c24_${stem}.sv}''')
s=s.replace('tmp/tb_c24_main_probe.sv','tmp/tb_c25_main_probe.sv')
u['tmp/c25_probe.do']=s
u['tmp/tb_c25_main_probe.sv']=(r/'tmp/tb_c24_main_probe.sv').read_text().replace('stage7c24_probe','stage7c25_probe')
s=(r/'tmp/c24_probe_compare.py').read_text().replace('stage7c24_probe','stage7c25_probe')
a=s.index("for leaf in ('diagnostic_outputs.txt'")
s=s[:a]+'''for leaf in ('diagnostic_outputs.txt','protocol_outputs.txt'):
 a=(h/('stage7c4_main_'+leaf)).read_text().splitlines();b=(h/('stage7c25_probe_main_'+leaf)).read_text().splitlines()
 def completed(lines):
  result={};key=None
  for line in lines:
   x=line.split()
   if x[0]=='J':key=tuple(x[1:])
   if x[0]=='D':result[key]=(tuple(x[1:-1]),int(x[-1]))
  return result
 before,after=completed(a),completed(b);assert before.keys()==after.keys()
 delta=[]
 for key in before:
  assert before[key][0]==after[key][0],(leaf,key,'status/attempts changed')
  delta.append(after[key][1]-before[key][1])
 print(leaf,'completed cycle deltas',min(delta),max(delta))
print('C25_PRIVATE_CONTROLLER_COMPARE_PASS:main9/protocol88 exact published bytes,digests,status and attempts;clock deltas measured;reset prefixes checked against published bytes,not forced to old lengths')
'''
u['tmp/c25_probe_compare.py']=s
patch='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and n!=sys.argv[1]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
