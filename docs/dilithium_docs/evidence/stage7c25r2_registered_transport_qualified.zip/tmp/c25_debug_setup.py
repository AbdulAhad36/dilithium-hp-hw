from pathlib import Path
import json
r=Path.cwd();s=(r/'tmp/tb_c25_memory_main_probe.sv').read_text()
i=s.rindex('endmodule')
debug='''
  always @(posedge clk)if(!rst && dut.core.datapath.polynomial.stream_fault)begin
    $display("C25_STREAM_FAULT:clock%0d op%0d state%s inputs%0d outputs%0d all_sources%b load%b pwm%b result%b write_ready%h",cycles,
     dut.core.datapath.polynomial.op_r,dut.core.datapath.polynomial.state.name(),
     dut.core.datapath.polynomial.inputs_r,dut.core.datapath.polynomial.outputs_r,
     dut.core.datapath.polynomial.all_sources,dut.core.datapath.polynomial.load_ready,
     dut.core.datapath.polynomial.pwm_ready,dut.core.datapath.polynomial.result_valid,
     dut.core.datapath.polynomial.memory_write_ready_i);
    $fatal(1,"Diagnostic stops at first nonstallable NTT fault");
  end
  for(genvar bank_debug=0;bank_debug<4;bank_debug++)begin
    always @(posedge clk)if(!rst && dut.core.datapath.polynomial.stream_fault)
      $display("C25_BANK:%0d qcount%0d issued%h head%h valid%h ready%h responsevalid%h responseready%h",bank_debug,
       dut.core.datapath.memory.storage.banks.bank[bank_debug].request_pipe.count_r,
       dut.core.datapath.memory.storage.banks.bank[bank_debug].request_pipe.issued_r,
       dut.core.datapath.memory.storage.banks.bank[bank_debug].request_pipe.head_mask,
       dut.core.datapath.memory.storage.banks.bank[bank_debug].queued_valid,
       dut.core.datapath.memory.storage.banks.bank[bank_debug].queued_ready,
       {dut.core.datapath.memory.storage.response_valid[1][bank_debug],dut.core.datapath.memory.storage.response_valid[0][bank_debug]},
       {dut.core.datapath.memory.storage.response_ready[1][bank_debug],dut.core.datapath.memory.storage.response_ready[0][bank_debug]});
  end
'''
s=s[:i]+debug+s[i:]
d=(r/'tmp/c25_memory_probe.do').read_text().replace('work_c25_memory_probe','work_c25_memory_debug').replace('c25_memory_probe','c25_memory_debug')
d=d.replace('tmp/tb_c25_memory_main_probe.sv','tmp/tb_c25_memory_debug.sv')
a=d.index('foreach top {');b=d.index(' {\n',a);d=d[:a]+'foreach top {tb_lighthd_main}'+d[b:]
a=d.index('vsim -L cyclonev_ver -gDIAGNOSTIC=0');d=d[:a]+'quit -f\n'
u={'tmp/tb_c25_memory_debug.sv':s,'tmp/c25_memory_debug.do':d}
p='*** Begin Patch\n'
for n,t in u.items():
 assert not (r/n).exists()
 p+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in t.splitlines())
print(json.dumps(p+'*** End Patch'))
