# Evolving Dilithium synthesis project

## C25R2 qualified timing candidate: 150+ MHz remains open

Area reduction is deferred. This timing candidate completes source and physical
qualification;it is **not** timing closure or user acceptance. The permanent
target is6.500ns/153.85MHz on the same Cyclone V,with hold constraints unchanged.

|Measured result|C22 reference|C25R2|
|---|---:|---:|
|Final placed ALMs [A]|30,577|31,720|
|Worst four-corner Fmax MHz|68.23|71.60|
|Clock constraint ns|6.757|6.500|
|Worst setup ns|-7.899|-7.466|
|Worst hold ns|+0.087|+0.113|
|Registers|20,389|22,241|
|M10Ks / hard DSPs|59 /8|59 /8|
|Block memory bits|409,446|409,446|

Fmax improves4.94%;placed area grows1,143ALMs/3.74%. Estimated operation
rates improve3.3–4.7% **after** measured pipeline clock penalties. These are
sequential estimates using actual worst-corner Fmax,not board measurements.
The constraint and synthesis mode also changed:HIGH PERFORMANCE EFFORT,
retiming/register duplication still off. Do not attribute all gains only to RTL.

Fresh full210official cases/744,280 published key-signature bytes/35 Verify
digests/9valid36invalid,protocol88/148,704 bytes,checker90,main UVM30 checked
completions/3 reset aborts and first-byte negative0 credit PASS. All269 frozen
source/config/ref hashes,286 completed native and30 UVM latency records and
12 reset-prefix records are audited. Functional116/170=68.24%;module code
135456/177545,package12/107,overall135468/177652=76.25%. Focused probes do
not inflate main UVM coverage.

The original full compile/fit/assembler/STA passes. Its subsequent read-only
retention checker initially missed generated bank instance prefixes. The
failed query is preserved;the scope-corrected checker uses the SAME thresholds
and passes all retained-hardware/four-corner gates. All1,696 request-queue bits,
80 unpacker window bits,original Process/buffer state and8 hard DSPs survive.
The original frozen report is unchanged;its permanent prefix correction is
part of the next source revision. No old physical report is used as current.

New worst path:NTT DMA op_r -> command mask -> memory arbitration/ready ->
DMA FSM,10 logic levels/13.712ns,slow0C. Cut this command-feedback path next.
A PRIVATE registered Keccak launch probe also passes main9/protocol88 with
every non-token/cycle record exact and18 empty SHAKE128/256 outputs at offsets
0/1/26,backpressure and pending-reset. It is not promoted and has no PPA or
main-coverage credit. Its input buffering hides the launch clock in those
tested ML-DSA operations.

Native freshness lists currently omit the new queue module leaf;the independent
269-file manifest and recursive full-source UVM fingerprint cover it. Add that
native dependency and update the legacy pre-window counter self-test on the
next source revision. NIST mathematics/comparison rules remain unchanged.
Keep immutable C22/C23/C24 and failed C25/R1/guard snapshots. No commit,branch
change,Stage8,unpublished-RTL equivalence or150MHz acceptance follows.

### Implemented timing cuts

- One80-bit registered unpacker window separates word alignment from validation.
- Two request slots per physical bank port register memory backpressure.
  A four-bit age relation per bank prevents younger conflicting requests from
  overtaking older requests while allowing unrelated A/B traffic to progress.
  The physical RAM and its collision guard are unchanged;both ports sustainII1.
- One21-bit sampling-completion record separates sampler arbitration/ID selection
  from the owning controller's state/error logic.
- Parallel narrow hint prefix counts replace serial carry propagation.
- The previously proved C23 field conversion and C24 packing/selection changes
  are included. Engine arithmetic and Process arithmetic are unchanged.

Measured full-campaign mean added clocks versus C22:KeyGen24.76/53.20/51.72,
Sign753.50/935.43/1380.90,valid Verify165/255/320 at levels2/3/5. Report the
clock counts together with latency/rates at the measured71.60MHz. Reset prefix
lengths may differ;every emitted byte remains independently checked.

Focused proofs pass:unpacker1241packets/310504coefficients/29invalid/6occupied
resets;field2390144vectors/9560960lane values;hint786432prefix combinations;
actualRAM request-pipe20732accepted/20720issued/20708replies/15741age checks/
10347full clocks/10825renewals/1281independent bypasses/3full resets/bothpointer
phases/12unissued requests discarded. Peak dual-portII1 is explicitly checked.
These focused probes are not merged into main functional/code coverage.

The initial coupled-port queue deadlocked KeyGen through head-of-line blocking.
It is rejected and preserved with its failure/debug logs;only the independently
queued revision passed promotion. A first complete-probe launcher used a wrong
bench filename;the corrected retry passes. Old unpacker cycle-equivalence
benches remain historical;new semantic tests check the intentionally changed
timing. Unchanged exhaustive Process arithmetic is reused from C18R1 through
10byte-identical source/reference files,not relabelled as a fresh execution.
No commit,branch change,Stage8 or user performance acceptance.

## Historical C22 selection before the C25 timing trial

C24 passed fresh foundation/full210official/protocol88/checker90/main33UVM/
negative and same-device four-corner/retained-hardware gates. It saves454
placed ALMs but loses0.94% Fmax and estimated operation rates. **C22 remains
the working baseline to preserve the requested Fmax/throughput priority.**
All259 C22 source hashes and85 matching saved test/capture/report hashes
are restored exactly;their saved comparisons and UVM freshness checks pass.
Restoration replays immutable evidence;it is not a fresh native run or refit.

|Qualified evidence|Final placed ALMs|Worst Fmax MHz|Worst setup ns|Worst hold ns|
|---|---:|---:|---:|---:|
|C22 selected source|30,577|68.23|-7.899|+0.087|
|C24 saved area option|30,123|67.59|-8.039|+0.076|

C24 retained20,416registers/59M10Ks/8DSP/409,446memory bits. All286 completed
native latency records/30fullUVM latency rows and12reset-prefix records are
exact C22. Its fresh coverage is116/170functional,127897/169896module code,
12/107package code,127909/170003=75.24%overall code. Selected C22's saved
overall code coverage is127904/170039=75.22%;do not mix trial denominators.

**Current Quartus output_full/critical_full/database still contains the C24
fit.** It was preserved,not replaced by old reports. The next normal compile
will build restored C22;C22 PPA above comes from its immutable qualified archive.
The same Cyclone V/6.757ns/hold/public-stream constraints remain. Under20K/
148MHz,Stage8 and user performance acceptance remain open. Nothing is committed.

C24 create-only archive and fresh extraction replay pass:574members/
26,619,719bytes,79 prior archive pairs verified;SHA256 `601aa852c5ec95236df7f75828e337482f7e61734cc71b41397b397e2109cbd9`.
Archive:`docs/dilithium_docs/evidence/stage7c24_packing_path_qualified.zip`.
Restoration:`sim/dilithium/reference_build/stage7c24_c22_restoration.json`.
No C24 capture was retagged. All frozen manifests remain self-contained.

Next trial:combine saved C23 unpacker field conversion with C24 packing and
command-selection changes. C24's worst path is now unpacker.read_slot_r[1]
to state.REPORT,10logic levels/14.485ns;its old packing path is no longer worst.
This motivates a combined experiment,not an assumed gain. Repeat complete
source/cycle/placed-PPA qualification;separate-trial savings are not additive.
Preserve C20/C21/C22/C23/C24 and all earlier checkpoints.

## Historical C22 restoration before the C24 trial

C23 is a correct but rejected performance trial. **C22's exact259 source
hashes and85 matching saved fixture/capture/report hashes are restored.**
Saved C22 comparisons and UVM freshness checks pass. This is immutable-evidence
replay,not a fresh native simulation or synthesis run.

Selected C22 evidence: **30,577 final placed ALMs / 68.23MHz**,setup **-7.899ns**,
hold **+0.087ns**,20,389 registers/59 M10Ks/8 DSPs. C23 measured30,115ALMs /
62.42MHz:462 fewer ALMs but8.52% lower Fmax and estimated operation rates,
with no operation-cycle change. C21 remains the smaller saved checkpoint.
The same Cyclone V,6.757ns and hold constraints remain;under20K/148MHz is open.

**Current Quartus output_full/critical_full reports and database still belong
to the rejected C23 fit.** They were preserved,not replaced with old reports.
The selected C22 PPA comes from its immutable archive;the next normal compile
will build the restored C22 source. Do not label existing C23 reports as C22.

C23 archive and fresh extraction replay pass:591members/26,936,018bytes,
78 prior archive pairs verified;SHA256 `a077d7728946aa65860cecf86c2383959650c6d57ce8d262ce789115de7a7910`.
Archive:`docs/dilithium_docs/evidence/stage7c23_field_conversion_qualified.zip`.
Restoration manifest:`sim/dilithium/reference_build/stage7c23_c22_restoration.json`.
No archived C23 capture was retagged;its saved evidence remains self-contained.

Next target:the measured Process-to-BitPkg packing path (11logic levels,
15.758ns C23 data delay). Prove any proposed boundary/packing rewrite against
the exact C22 baseline,including framing,backpressure,reset and end-of-stream
flush,then measure full-operation cycles and actual placed PPA. The local
unpacker area saving is retained as a rejected trial,not silently promoted.
No commit,branch change,Stage8 or performance acceptance follows.

## C20 source-qualified and routed trial

All251 source hashes,changed-writer tests,210 official commands,88 protocol
commands,90 checker corruptions and main33 UVM/negative pass. Actual final
placement: **30,655 ALMs**, 21,695 registers,59 M10Ks and8 DSPs.
Worst Fmax **63.59MHz**, setup **-8.968ns**, hold **+0.121ns**.
Versus C18R1: -674 placed ALMs,+2.27% Fmax. Measured cycles and rate
changes are in THROUGHPUT.md. Keep the same Cyclone V,6.757ns/hold constraints,
public streams and all three operations. Under20K/148MHz remains open;this is
not user performance acceptance or a full unpublished-RTL replication claim.

## Historical C18R1 source and routed result

All 249 source hashes, foundation tests, 210 official commands, 88 protocol
commands, 90 checker corruptions and main33 UVM/negative pass. Final placement:
**31,329 ALMs**, 21,484 registers, 59 M10Ks and 8 DSPs.
Worst Fmax **62.18 MHz**, setup **-9.325 ns**, hold **+0.121 ns**.
Versus C17: -442 placed ALMs and +3.31% Fmax; actual operation rates
and cycle deltas are recorded in THROUGHPUT.md. The same Cyclone V, 6.757 ns
clock and hold constraints remain. Under20K/148MHz targets remain open;
this result is not user performance acceptance or a literal unpublished-RTL
replication claim. No shared controller-context RAM was introduced.

## Active production project (C14 shared Process hint resource)

SameCycloneV/6.757ns/hold constraints;all three public operations enabled.
Full compile/ASM/STA and strict retained-hardware/four-corner checks pass.
Final placed[A]ALMs31882,registers22120,M10Ks59,DSPs8,blockbits409446. Do not
use29239 summary logic-utilization as placed area. WorstFmax56.72MHz,
setup-10.875ns/hold+0.104ns;holdTNS0. Area-3.55% versus C12,cycles unchanged,
estimated rates-1.15%. Neither under20K nor148MHz is met or accepted.
One codec retains640index+64count bits;no private Sign/Verify hint instances.
All earlier admission/retirement and native-DSP/selector guards pass. Logs:
stage7c14_compile.log,stage7c14_report_full.log. Preserve/replay C14 before
connecting the next memory-data candidate;no constraint relaxation.

## Previous production project (C12 architecture trial)

`dilithium_full.qpf` compiles all three public operations. Fused native-DSP
RTL is included;device,6.757ns SDC,hold rules and physical settings stay exact
C11R1. Full compile/ASM/STA completes after an automatic routing retry.
Strict retained-hardware/four-corner reporting also passes. Actual final
placed [A] ALMs33056,registers22797,M10Ks59,DSPs8;worst57.38MHz,
setup-10.671ns/hold+0.090ns. This is essentially unchanged area and0.33% lower
Fmax than C11R1;performance remains unaccepted. The summary's30365 ALM
logic-utilization estimate is not the placed count. Logs:stage7c12_compile.log,
stage7c12_report_full.log. The mapped DSP table proves4 dedicated pre-adders
and4 output-adder chains;all8DSPs and required registers survive placement.
No native job remains. Next target:memory/router-to-Process path and selection
overhead;the below20000 and148MHz goals remain open.

## Previous production project (C11R1)

`dilithium_full.qpf` remains the whole three-operation production project.
QSF/6.757ns SDC/device/hold rules are exact C10. Fresh full compile/ASM/STA
and retained-hardware/four-corner gates pass:33066 actual placed ALMs,
23054 registers,59M10Ks,4DSP. Worst Fmax57.57MHz/setup−10.612ns/hold+0.095ns.
Under20000 and148MHz remain open. Compile log:stage7c11r1_compile.log;
strict report:stage7c11r1_report_full.log. Detailed results are in the
universal THROUGHPUT.md and C11 evidence archive.

## Previous production project (Stage7C.10)

C10 source/full compile/ASM/STA and retained/four-corner gates pass. Actual
placed34660 ALMs,25339 registers,59M10Ks,8DSP;worst Fmax56.65MHz/setup-10.894ns/
hold+0.122ns. All20 new control bits retained. No native build remains active.
Same device,6.757ns clock,hold rules and physical options are retained;
the148MHz target still fails setup. Next target is RAM-to-Process timing.

### Frozen Stage7C.9 R1 result

R1 source/full compile/retained-register/four-corner gates complete. Actual
placed34535 ALMs,25404 registers,59M10Ks/8DSP;worst Fmax53.85MHz/setup-11.812ns/
hold+0.121ns. This regresses versus C8's55.53MHz and is not performance-accepted.
The148MHz constraint remains unchanged and fails setup. Next target is NTT
completion readiness. The C7 physical figures below are historical.

Open `dilithium_full.qpf` in Quartus and use **Processing > Start Compilation**.
The top remains `dilithium_fpga`;its core is now `lighthd_dilithium`. The QSF
lists55 production sources for one shared engine set and the fixed-bank
controller. Original engine RTL and historical controllers remain preserved
in the checkout;the former allocator/helper hierarchy is not an active
production synthesis dependency.

Device5CGXFC7C7F23C8,clock6.757ns,hold rules,virtual pins,seed and all non-source
physical settings are unchanged from7B.9. No SDC edit is required. Current
full compilation passes with34302 actual placed `[A]` ALMs,25337 registers,
59 M10Ks and8 DSPs. The response loop is gone. Worst reported Fmax51.78MHz/
setup-12.556ns/hold+0.103ns:the148MHz target still fails setup. THROUGHPUT.md
records all corners and remaining work. Old51162-ALM/23.97MHz reports belong
to the earlier source. Keep reporting actual fitted area and worst corners.
The preserved `dilithium.qpf` remains the older subsystem project.


## Stage7B.9 production top

Open **dilithium_full.qpf** in the Quartus GUI, then choose
**Processing > Start Compilation**. It selects `dilithium_fpga`,whose unchanged
`dilithium` core has FULL_KEYGEN=1,ENABLE_SIGN=1 and ENABLE_VERIFY=1 hardwired.
Seed/debug exports stay internal;all normal command/data/status pins remain.
The design uses the same Cyclone V
5CGXFC7C7F23C8 and unchanged 6.757ns clock target. Reports go to output_full/.
The former dilithium.qpf and output_files/ retain the earlier subsystem scope.
Do not quote their results as whole-main PPA.

After a successful full compile, run `quartus_sta -t report_full.tcl` here.
It checks retained controller/Keccak/sampler registers and reports setup,
hold and Fmax at all four supported timing corners under critical_full/.
Headline area must come from **ALMs used in final placement** in the fitted
report, not the synthesis/packing estimate. Virtual data pins and false-path
I/O constraints make this an internal benchmark, not board I/O closure.
No manual SDC change is required. See universal THROUGHPUT.md for measured
results. Current7B.9 full compile routes at51,162 actual placed ALMs,62 M10Ks,
27 DSPs. Fmax23.97MHz/setup−34.965ns/hold+0.099ns:the unchanged target fails
setup. Compiler exit0 does not mean timing closure. The production boundary has1026
virtual nonclock bits plus the real clock. These are port counts,not ALMs.

## Earlier subsystem project

Open `dilithium.qpf` in Quartus GUI and choose **Processing > Start Compilation**.
The current top is `keccak_sampler_ntt` (Stage4). The project will grow to the full
controller/memory/process/NTT system as those parts are implemented.

Initial target chosen by the user:about148MHz,permanent6.757ns SDC for this
baseline. No manual SDC edit is needed. Seed1,HIGH PERFORMANCE EFFORT,
Cyclone V5CGXFC7C7F23C8.294 non-clock bits are virtual.
Virtual data I/O timing is excluded;this is an internal timing benchmark.

Stage4 all-engine source/Python checks pass,but its synthesis/fit has not been run.
Existing output_files reports are the earlier Stage2 producer-only build and
must not be reported as current Stage4 PPA. report_paths.tcl refuses an old
database lacking memory metadata or the NTT datapath. Full-system optimization
remains deferred;the project is prepared for GUI compilation when needed.

The first fit missed timing at129.18MHz/-0.984ns setup. On2026-10-20 the user
superseded timing-first work:integrate for functionality and full-operation
outputs,then optimize Fmax/area/throughput. Timing closure does not block memory.
Historical Stage2 trial8:global retiming OFF,Keccak hierarchy ON,
sampler hierarchy OFF,physical combinational synthesis/duplication ON,and
maximum router timing effort. Ordinary clock-enable mapping is restored;
each Keccak core predecodes absorb-ready without adding a processing cycle.
The lane-write and forced-global-enable trials were rejected and removed.
Keccak's launch-offset-zero flag is registered without changing launch gaps.
The helper has a two-slot register queue with registered-credit upstream ready.
Command ready relies on ownership,with sampler-readiness equivalence asserted
in source simulation. The main project uses seed1;its completed fit has11293
placed ALMs,137.74MHz worst Fmax,-0.503ns setup and+0.157ns hold. Structural
guards pass;timing remains open. The isolated seed2 compile also finished;
it is not selected. No build remains active and no further timing experiment
is planned before functional integration. This is not a timing-closed baseline.

Read **[A] ALMs used in final placement** for area,all-corner TimeQuest setup/
hold/TNS and both slow-corner Fmax summaries. A positive source-test result does
not establish FPGA Fmax. Run `quartus_sta -t report_paths.tcl` from this folder
to check the accepted sampler's payload/register guards inside the combined top.

Current measurements and limitations belong in the universal
docs/dilithium_docs/THROUGHPUT.md. Standalone module reports remain standalone;
they do not define system area or timing.
