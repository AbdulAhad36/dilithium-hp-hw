# Focused integration regression;full Dilithium UVM comes later.
# Questa GUI,from sim/: do dilithium/run.do
# Default Stage4;set DILITHIUM_STAGE 2 or3 to rerun earlier connection gates.
if {![info exists DILITHIUM_STAGE]} {set DILITHIUM_STAGE 4}
if {![info exists DILITHIUM_TEST]} {set DILITHIUM_TEST process}
if {$DILITHIUM_TEST ni {process hash_format shared_hash bank_memory bank_store bank_ntt}} {error "DILITHIUM_TEST must be process,hash_format,shared_hash,bank_memory,bank_store or bank_ntt"}
if {$DILITHIUM_STAGE ni {2 3 4 5}} {error "DILITHIUM_STAGE must be2,3,4 or5 (process unit gate)"}
if {[batch_mode]} {onerror {quit -code 1 -f}} else {onerror {abort}}
set launch [file normalize [pwd]]
if {[file exists [file join $launch stage2_inputs.txt]]} {
    set here $launch
} elseif {[file exists [file join $launch dilithium run.do]]} {
    set here [file join $launch dilithium]
} else {
    set here [file join $launch sim dilithium]
}
set repo [file normalize [file join $here .. ..]]
if {[catch {exec python [file join $here dilithium_vectors.py] check} freshness]} {error $freshness}
echo $freshness
set workdir [file join $here work]
if {![file exists $workdir]} {vlib $workdir}
vmap dilithium_work $workdir
set rtl [file join $repo src]
vlog -sv -work dilithium_work [file join $rtl keccak keccak_pkg.sv]
foreach n {keccak_param_unit keccak_absorb_unit theta_step rho_step pi_step chi_step iota_step keccak_step_unit keccak_output_unit keccak_core keccak_dual_interleaved} {
    vlog -sv -work dilithium_work [file join $rtl keccak ${n}.sv]
}
vlog -sv -work dilithium_work [file join $rtl sampler sampler_pkg.sv]
foreach n {sampler_secret_lane sampler_mask_unpack sampler_input_prepare sampler_ball sampler_compact sampler} {
    vlog -sv -work dilithium_work [file join $rtl sampler ${n}.sv]
}
vlog -sv -work dilithium_work [file join $rtl ntt ntt_pkg.sv]
foreach n {mod_mul butterfly_unit twiddle_rom ntt_core ntt_engine} {
    vlog -sv -work dilithium_work [file join $rtl ntt ${n}.sv]
}
vlog -sv -work dilithium_work [file join $rtl controller keccak_sampler.sv] [file join $rtl controller memory.sv] [file join $rtl controller keccak_sampler_memory.sv] [file join $rtl controller keccak_sampler_ntt.sv]
vlog -sv -work dilithium_work [file join $rtl controller process poly_process.sv]
vlog -sv -work dilithium_work [file join $rtl controller keygen_hash_message.sv]
vlog -sv -work dilithium_work [file join $rtl controller keygen_seed_collect.sv]
vlog -sv -work dilithium_work [file join $rtl controller poly_bram.sv] [file join $rtl controller memory_banks.sv]
vlog -sv -work dilithium_work [file join $rtl controller bank_poly_store.sv] [file join $rtl controller keccak_sampler_banks.sv]
vlog -sv -work dilithium_work [file join $rtl controller keccak_sampler_ntt_banks.sv]
if {$DILITHIUM_STAGE == 5} {
    if {$DILITHIUM_TEST eq "bank_ntt"} {set top tb_keccak_sampler_ntt_banks} elseif {$DILITHIUM_TEST eq "bank_store"} {set top tb_keccak_sampler_banks} elseif {$DILITHIUM_TEST eq "bank_memory"} {set top tb_memory_banks} elseif {$DILITHIUM_TEST eq "shared_hash"} {set top tb_shared_hash} elseif {$DILITHIUM_TEST eq "hash_format"} {set top tb_keygen_hash_message} else {set top tb_poly_process}
    if {$DILITHIUM_TEST eq "bank_store"} {vlog -sv -work dilithium_work [file join $repo tb tb_dilithium bank_store_protocol_test.sv]}
    vlog -sv -work dilithium_work [file join $repo tb tb_dilithium ${top}.sv]
} elseif {$DILITHIUM_STAGE == 4} {
    set top tb_keccak_sampler_ntt
    vlog -sv -work dilithium_work [file join $repo tb tb_dilithium ${top}.sv]
} elseif {$DILITHIUM_STAGE == 3} {
    set top tb_keccak_sampler_memory
    vlog -sv -work dilithium_work [file join $repo tb tb_dilithium memory_protocol_test.sv] [file join $repo tb tb_dilithium ${top}.sv]
} else {
    set top tb_keccak_sampler
    vlog -sv -work dilithium_work [file join $repo tb tb_dilithium ${top}.sv]
}
vsim -voptargs=+acc -wlf [file join $here stage${DILITHIUM_STAGE}.wlf] dilithium_work.$top +STAGE2_DIR=$here
onfinish stop
if {![batch_mode]} {
    view transcript;view wave
    add wave /$top/clk /$top/rst
    if {$DILITHIUM_STAGE == 5} {
      if {$DILITHIUM_TEST eq "bank_ntt"} {
        add wave -divider {Banked sampling and NTT ownership}
        add wave /$top/job_* /$top/status_* /$top/op_* /$top/dut/state /$top/dut/source_leases
        add wave -divider {Packed DMA and committed result}
        add wave /$top/dut/load_word_r /$top/dut/lane_r /$top/dut/s_* /$top/dut/m_*
        add wave /$top/dut/store/word_* /$top/dut/store/acknowledged_r /$top/read_* /$top/response_*
      } elseif {$DILITHIUM_TEST eq "bank_store"} {
        add wave -divider {Bank region descriptor and publication}
        add wave /$top/job_* /$top/status_* /$top/reserved_o /$top/complete_o /$top/fault_o
        add wave -divider {Coefficient packing and word acknowledgement}
        add wave /$top/dut/coeff_* /$top/dut/store/word_* /$top/dut/store/acknowledged_r
        add wave -divider {Protected bank read and release}
        add wave /$top/read_* /$top/response_* /$top/release_*
      } elseif {$DILITHIUM_TEST eq "bank_memory"} {
        add wave -divider {Four banks,ports A/B}
        add wave /$top/request_* /$top/response_* /$top/collision_o /$top/phase
      } elseif {$DILITHIUM_TEST eq "shared_hash"} {
        add wave -divider {Seed submission and retained material}
        add wave /$top/start_* /$top/result_* /$top/collector/count_r
        add wave -divider {Shared raw hash and sampling ownership}
        add wave /$top/raw_* /$top/job_* /$top/output_* /$top/status_*
        add wave /$top/dut/owned_r /$top/dut/raw_r /$top/dut/hash_busy
      } elseif {$DILITHIUM_TEST eq "hash_format"} {
        add wave -divider {KeyGen message construction}
        add wave /$top/command_* /$top/request_* /$top/input_* /$top/done_* /$top/dut/state
        add wave -divider {Shared SHAKE test service}
        add wave /$top/hash_* /$top/words /$top/beats
      } else {
        add wave -divider {Process input and output}
        add wave /$top/input_* /$top/output_*
      }
    } else {
    add wave -divider {Descriptor and absorption}
    add wave /$top/job_* /$top/input_*
    add wave -divider {Coefficient and completion}
    add wave /$top/status_*
    if {$DILITHIUM_STAGE >= 3} {
        add wave -divider {Slot ownership and readback}
        add wave /$top/reserved_o /$top/complete_o /$top/fault_o
        add wave /$top/read_* /$top/response_* /$top/release_*
        add wave /$top/dut/coeff_* /$top/dut/store/count_r /$top/dut/store/state_r
        if {$DILITHIUM_STAGE == 4} {
            add wave -divider {NTT command and DMA}
            add wave /$top/op_* /$top/dut/state /$top/dut/load_index_r /$top/dut/result_count_r
            add wave /$top/dut/ntt_* /$top/dut/s_* /$top/dut/m_*
        }
    } else {
        add wave /$top/output_*
        add wave -divider {Bridge,drain and ownership}
        add wave /$top/dut/owned_r /$top/dut/drain_r /$top/dut/stop_r
        add wave /$top/dut/bridge_valid_r /$top/dut/hash_valid /$top/dut/hash_ready
    }
    }
    log /$top/*
}
run -all
if {[examine -radix unsigned /$top/test_passed] != 1} {
    error "Stage$DILITHIUM_STAGE test did not reach its explicit completion gate"
}
if {![batch_mode]} {wave zoom full}
echo "Run python sim/dilithium/dilithium_vectors.py compare --stage $DILITHIUM_STAGE --unit $DILITHIUM_TEST from repository root for the independent verdict."
