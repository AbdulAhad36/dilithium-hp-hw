# Dilithium cycles,throughput and implementation metrics

## Stage5N.4h.6 actual main Sign work counts

45 commands=21 complete Sign+1 mixed KeyGen+14 expected errors+9 reset/fault
aborts. There are36 normal completions. Sign successes comprise13 level2,
4 level3 and4 level5:13x2420+4x3309+4x4627=63204 exact signature bytes.
These are12 unique message/context/rnd fixtures plus nine recovery repeats.
The mixed level2 KeyGen emits1312+2560=3872 exact key bytes (484 words).

| Captured metric | Definition / result |
|---|---|
|Input words|13356 accepted64-bit SK/body beats,including error/abort prefixes |
|Signature words|9113 accepted output beats,including prefixes;7911 belong to the21 complete signatures |
|Attempt starts|76 actual mask-attempt launches across success,error and abort jobs;not76 completed signatures |
|Allocation events|11253=8901 new reservations+2352 in-place rewrites |
|Finish events|11251=11246 successful commits+5 error discards;2 open writes terminate at reset |
|Physical releases|8778;new lifetimes also end at5 failed finishes and118 reset-held regions,so8901=8778+5+118 |
|Peak occupied regions|33/45/61 at levels2/3/5;24288/33120/44896 payload bytes |
|Normal Sign boundary|Zero owned regions before main done;fresh key load for every request |

These are simulated work/serialization counts with deliberate host stalls,
resets and repeated fixtures. They are not a sustainable-throughput benchmark
or a new Fmax/area result. No new synthesis is run. The6.757ns constraint and
selected legacy Quartus top remain unchanged. Per-operation cycle/Fmax/area
optimization follows complete functionality;main Verify is still open.

Fresh encoded KeyGen and rounded/debug-read KeyGen compatibility gates pass;
REFERENCE_VERIFICATION.md records their counts and execution commands.

## Stage5N.4h.5 signature serialization counts

Seven complete signatures=2 level2 +2 level3 +3 level5:
2x2420 +2x3309 +3x4627 =25339 exact bytes. Each signature needs303/414/579
64-bit output handshakes,with final4/5/3 valid bytes. Z consumes4x72 /5x80 /
7x80 packer output words. Hints add omega+k=84/61/83 bytes after z.

The24-command gate also exercises9 expected errors and8 aborts. Across all
prefixes it records6810 exact output words,8880 packed92-bit responses,
21 takes,149 releases and11 real key preparations. These are work counts,
**not sustainable throughput or a new Fmax result**. The harness injects stalls
and repeats fixtures for recovery. Key preparation/retry work precedes packing.

The encoder itself allocates no region;it adopts8/11/15 accepted z+h regions
and releases them before held completion. Key+accepted payload remains20/28/38
regions,excluding the test sentinel. No new physical banks/signature RAM.
The6.757ns target is unchanged;there is no fresh synthesis/area/timing claim.
Full-system latency and throughput will be measured after main Sign is connected.

## Stage5N.4h.4 complete attempt-loop work counts

47 scenarios=19 accepted parent results+12 expected service failures+
5 nonce-exhaustion reports+11 reset/fault aborts. Thus36 normal completions
include17 expected nonzero status codes. Accepted runs are6/6/7 at levels
2/3/5 and repeat underlying fixtures for recovery;they are not19 complete
encoded signatures.14 actual key preparations supply the retained contexts.

| Child | Starts | Results |
|---|---|---|
|Mask|87|81=75 complete vectors+6 expected errors;6 interrupted |
|Matrix|75|75=72 successes+3 expected source-ID errors |
|Challenge|72|72 |
|Challenge transform|72|72 |
|Products|72|71;1 interrupted |
|Candidate checks|71|70=45 real rejects+22 accepts+3 expected errors;1 interrupted |
|Total|449|441;8 active children interrupted,plus3 held accepted-result resets |

Of22 child accepts,19 publish parent results and3 are deliberately reset
while held.45 real rejection/header takes advance the nonce;these are normal
algorithm behavior,not service errors. One final vector at level5 accepts
with nextnonce65536;level2/3 final-vector rejections stop there. Three initial
65536 requests launch no attempt. There is no wrapped nonce0 request.

| Actual observation | Count / arithmetic |
|---|---|
|Raw SHAKE requests|157=44 initial mu+41 initial private seed+72 challenge |
|Initial-hash exception|3 malformed-payload cases complete/discard mu but never derive the private seed |
|Raw absorption words|10276;81944 meaningful bytes,264 zero padding bytes |
|Digest bytes|8992=5440 initial headers+3552 challenge |
|Mask jobs / statuses|418/412;6 interrupted jobs |
|Mask input words|3762=418x9,each descriptor absorbs66 meaningful seed/nonce bytes |
|Exact y scalar writes|105667=412x256+6x32+3 pending writes after parent HALT |
|Physical allocations|13147=10057 new reservations+3090 rewrites |
|Physical commits|13140 successful;7 open allocations end in global reset |
|Physical releases|9972,including internal row-MAC scratch releases |
|Rejected header transfers|45;payload map is empty before every transfer |
|Accepted outbound takes|8;other accepted contexts are explicitly cleared |
|Pending-read barriers|19 |
|Packed92-bit reads|56256=6592 z+7424 hints+39936 key+2304 sentinel |

The19 accepted results contain103 z polynomials and116 hint polynomials:
(103+116)x64=14016 packed words=56064 checked coefficients. Every result
digest also matches. Other intermediate arithmetic writes are covered by
the preceding gates;this loop gate does not claim scalar comparison of all
NTT/matrix/product writes. Its new scalar comparison covers all observed y
writes,including interrupted prefixes. Allocation/commit/release records
are independently reconstructed across the whole path.

Peak simultaneous physical reservations including one test sentinel are
34/46/62 at levels2/3/5;excluding it,33/45/61 regions=24288/33120/44896
payload bytes. Earlier phase schedules and the four1024x92 banks are unchanged.
A is resampled per attempt;matrix caching is future measured optimization.
These are observed work/storage counts,not new Fmax,slack,area,signature
latency or sustained throughput.6.757ns SDC is unchanged;no new Quartus fit.

## Stage5N.4h.3 candidate-check work counts

Fresh59-command gate:18 accepted candidates,5 genuine algorithmic rejections,
21 expected hardware/service errors and15 reset/fault aborts. Thus44 normal
completions=18+5+21. The accepted runs repeat three distinct clean fixtures
across recovery tests;they are not18 independent complete signatures.
18 real key preparations and53 complete upstream preparations supply the
actual products. Two preflight checks per level reuse their intact context.

| Observed work | Count |
|---|---|
|Whole-products takes|53 |
|CNB requests/results|730/727;724 successful service results,3 real bad-ID rejects,3 interrupted |
|ADD requests/results|150/147;144 successful service results,3 real bad-ID rejects,3 interrupted |
|Mhint requests/results|141/135;132 successful service results,3 real bad-ID rejects,6 interrupted |
|Exact scalar writes|70944=36960 combined-low +33984 hints |
|Last-use row releases|393=131 low +131 high +131 ct0 |
|Whole-attempt clear/error/reject releases|643 |
|Next-owner/header transfers|5;2 accepted payload transfers +3 header-only rejections |
|External releases|93=26 accepted result regions +67 artificial capacity blockers |
|Held-read clear/take barriers|23=18 accepted +5 rejected outcomes |
|Exact packed92-bit reads|157888 |

Successful service result counts include later deliberately corrupted parent
observations and held-done resets;they are not accepted-candidate counts.
Write arithmetic:276 completed polynomial writes x256 +9 interrupted
prefixes x32=70944. The18 accepted candidates account for55296 writes;
the remaining15648 are checked rejection/error/reset work. No accepted
write after a parent fatal-HALT occurs in this gate.

Read arithmetic:20224 input z +22784 input r0 +22784 input w1 +22784 input
ct0 +6144 accepted z +6912 accepted hints +49152 key +2816 sentinel +4288
capacity blockers=157888. Whole accepted-result readback is13056 packed
words=52224 coefficients;all source/output metadata and key/sentinel values
are independently checked. The upstream input reads total88576 packed words.

This phase's key+attempt+hint peak excludes sentinel/blockers:29/41/55
regions at levels2/3/5. Accepted retained totals are20/28/38;rejected payloads
are fully freed,leaving12/17/23 key regions plus private scalar retry headers.
Earlier phase peaks are unchanged. Physical banks,engines and6.757ns SDC
are unchanged. These work/storage counts are not new fitted area,Fmax,
slack,signature latency or sustained-throughput measurements.

## Stage5N.4h.2 product/response work counts

Fresh63-command arithmetic gate:24 complete schedules,21 expected errors,
18 reset/fault aborts;45 normal completions.21 real key preparations and57
full mask/matrix/challenge/transform preparations supply the inputs. Two
preflight cases per level reuse their intact source contexts. Successful
executions reuse six distinct level/nonce fixtures,eight per level.

| Observed work | Count |
|---|---|
|Atomic mask/vector takes|57 |
|NTT-service commands|1246 =629 PWM +617 inverse |
|NTT-service results|1234 =1228 successful +6 real source-ID rejects;12 interrupted |
|In-place commands/results|440 /437;434 successes,3 source-ID rejects,3 interrupted |
|Actual scalar writes|425955 =158240 PWM +156512 inverse +111200 ADD/SUB +3 after parent HALT |
|PWM scratch releases|599 |
|Inverse scratch releases|431 |
|Final chat releases|27;includes3 held-done abort cases |
|Whole-context clear/error releases|789 |
|Outbound result/header transfers|3;70 result regions released by the next test owner |
|Separate capacity-blocker releases|61 |
|Pending-read clear/take barriers|24 |
|Packed92-bit reads|99584,all values/metadata checked |

Write arithmetic:1662 complete physical polynomial writes x256 =425472,
plus15 interrupted prefixes x32 =480,plus3 outstanding PWM values after
parent HALT. Only282624 writes belong to the24 completed arithmetic schedules;
the other143331 are checked expected-error/reset work. None is a signature
acceptance count.

Read arithmetic:8192 z +9216 corrected-low +11520 w1 +9216 ct0 +49920 key
+2880 sentinel +3904 blockers +2048 original-y +2304 original-low +384 chat
=99584. Of these,35840 packed words=143360 coefficients are whole result
vectors from24 completed schedules;w1 includes another2304 preflight reads.

Normal phase peaks reconstructed from N/X/F allocation intervals,including
one test sentinel,are31/43/57 regions at levels2/3/5. Excluding that sentinel
the phase uses30/42/56;retained result+key uses28/40/54. Artificial capacity
blockers are separate stress cases. Earlier matrix-generation peaks remain
unchanged. These are logical storage/work counts,not new fitted ALMs/M10Ks,
Fmax,slack or sustained throughput.6.757ns SDC is unchanged;no new synthesis.

## Stage5N.4h.1 ownership/reuse/FNTT(c) work counts

Fresh51-command gate:24 successes,12 expected errors,15 reset/fault aborts;
36 normal completions.18 real key preparations,24 mask vectors and51 full
matrix/challenge preparations produce the actual sources. Eight successful
executions per level reuse six level/nonce fixtures.

| Observed work | Count |
|---|---|
|Atomic matrix+challenge handoffs|42;no partial transfer |
|Dead-yhat releases|211,including3 interrupted release prefixes |
|Forward requests/results|39 /33;30 physical successes,3 source-ID rejects,6 partial resets |
|Actual chat scalar writes|7875 =30 x256 +6 x32 +3 outstanding values after parent HALT |
|Raw-c releases after valid chat|27;includes3 held-result reset cases |
|Normal clear/error releases|354 adopted/new regions |
|Outbound whole-context transfers|3;39 regions released by the next test owner |
|Capacity-blocker releases|66;separate from design-owned data |
|Pending-read clear/take barriers|24 |
|Packed92-bit reads|85760;every value and metadata tuple checked |

Read accounting:1536 chat +11520 w0 +11520 w1 +39936 prepared-key +12288
raw-y +2304 sentinel +4224 capacity blockers +2048 original yhat +384 raw c
=85760. Original yhat/c reads belong to preflight rejections whose previous
owners remain intact. Final successful chat readbacks check6144 coefficients
=24 x256. Error/reset work does not count as a successful signing attempt.

Retained key+y+w0+w1+chat uses25/35/47 regions at levels2/3/5. This phase's
temporary c/chat overlap uses26/36/48,excluding sentinel/blockers;earlier
matrix generation has a larger peak. No new banks/engines/payload RAM.
These are functional work/storage counts,not measured system throughput.
No new synthesis/Fmax/ALM/slack result;6.757ns SDC remains unchanged.

## Stage5N.4g functional work and storage

Fresh challenge capture:81 commands =24 successful executions +39 expected
errors +18 reset/fault aborts.63 normal completions;8 successes per level.
21 actual key preparations and27 actual mask/matrix vectors reuse three
published KeyGen SK inputs and six distinct level/nonce combinations.

| Observed work | Count |
|---|---|
|Pack commands/results|366 /360;6 interrupted;354 successes,3 value errors,3 frame errors |
|Accepted pack inputs|90895 scalar coefficients,including checked error-drain/reset prefixes |
|Packed outputs|6317 exact64-bit words |
|Formatter body|6162 accepted8-byte words;15 invalid-byte termination beats |
|Raw hash descriptors/results|75 /66;9 interrupted before complete raw retirement |
|Raw absorption|7962 words;includes exact zero-fill after abandoned body |
|Actual digest output|201 x16 =3216 bytes;includes discarded error hashes and reset prefixes |
|SampleInBall descriptors/statuses|39 /33;6 interrupted partial c jobs |
|c scalar writes|8640 =33 x256 +6 x32;includes bad-status and aborted work |
|Packed92-bit reads|171264;all source,result and blocker values checked |
|Normal c releases|30 =24 successful clear +6 bad-status cleanup |
|Separate capacity-blocker releases|69 |
|Pending-read clear barriers|24 |

Read accounting:1536 c +69888 prepared-key +21504 y +21504 yhat +24192 w0
+24192 w1 +4032 sentinel +4416 capacity-blocker words =171264. c readbacks
contain6144 coefficients =24 x256. Each successful retained c occupies one
736-byte region;existing sources retain28/39/53 regions,so steady sources+c
use29/40/54 regions at levels2/3/5,excluding the test sentinel.

These are functional work counts,not sustained throughput measurements.
No new synthesis/Fmax/area/slack result is claimed;6.757ns remains unchanged.
The new challenge helper and extended packer have not been fitted as a full
Sign path. Main Sign/retry scheduling and performance optimization remain open.

## Stage5N.4f functional work and storage accounting

The fresh matrix/decomposition comparison passes66 commands:24 complete
vectors,24 expected errors and18 reset/fault aborts. There are48 normal
completions.21 real key preparations and27 real mask generations reuse three
published SK inputs. All output expectations are local FIPS-derived values.

| Observed work | Count |
|---|---|
|Forward requests/results|303 /300;297 successful physical results,3 source-ID rejects,3 interrupted requests |
|A sample descriptors/statuses|1192 /1189;3 interrupted |
|A absorption|5960 words =5 per descriptor;40528 meaningful bytes =34 per descriptor |
|Row requests/results|210 /204;6 interrupted |
|Decomposition requests/results|198 /195;3 interrupted between low/high finish ACKs |
|Scalar writes|1060230,all compared |
|Packed92-bit reads|102336,all compared |
|Helper temporary releases|1257 |
|Helper clear/error releases|644 |
|Separate test-blocker releases|47 |

Scalar writes by owner phase:76128 forward +304480 A sampling +579776 row
arithmetic +99840 decomposition +6 outstanding row writes after injected
parent HALT. The last6 are checked abort work,not successful output. Physical
finish acknowledgments:297 forward +1189 A +2264 row +387 decomposition.
Reset between decomposition commits leaves a complete low and uncommitted
high;global reset discards both parent results without successful credit.

Read accounting:8192 yhat +9216 w0 +9216 w1 +53248 retained-key +16384
original-y +3072 sentinel +3008 capacity-blocker words =102336. The first
26624 words x4 coefficients =106496 final coefficients from24 complete
vectors. Source/blocker reads establish preservation through errors/clear.

Normal successful peak allocations,including one unrelated test sentinel,
are34/46/62 regions at levels2/3/5. Without that sentinel the schedule uses
33/45/61 regions at peak. Capacity tests deliberately fill extra regions;
their all-case peak is46/46/62 and is not the normal level2 schedule. The
workspace address budget is19/25/33,with full source+workspace plans35/47/63;
an address leased for future use need not be physically allocated yet.
Physical banks remain four1024 x92-bit arrays;these are logical lifetimes,
not new fitted area measurements.

This is a sequential functionality checkpoint. No fitted Fmax,ALMs/slack,
complete Sign latency or sustained full-operation throughput is measured.
The6.757ns constraint remains unchanged;PPA work is still deferred until
complete functionality/output verification. Whole-signature retry work and
the final memory schedule are unfinished.

## Stage5N.4e hash/mask functionality checkpoint

78 commands yield27 complete vectors,36 expected errors and15 reset/fault
aborts. The27 vectors contain9 x(4+5+7)=144 complete polynomials;144 x256=
36864 consumer-checked mask coefficients. Additional error/reset work is
checked without crediting successful output:total scalar writes49094=
191 x256 +198 partial values. Packed reads83136=9216 mask +69888 retained-key
+4032 sentinel words. Descriptor counts60 mu,51 seed,197 mask include reset
work;retirements57,48,191. There are169 normal mask releases.

The schedule intentionally runs mu,private seed and each mask sequentially,
waiting for physical engine retirement between descriptors. It establishes
correct bytes and ownership,not a throughput improvement. No fitted Fmax,
ALMs/slack or end-to-end Sign cycles are measured in this checkpoint. The
6.757ns integration constraint is unchanged;it is not a new achieved Fmax.
Prepared key payload plus one y vector uses16/22/30 existing regions at
levels2/3/5. Later full-operation scheduling/retry and PPA measurement remain.

## Stage5N.4d key preparation and storage reuse

165 commands =95 successful keys +62 expected errors +8 reset/fault aborts.
Accepted transform requests1816 =1200 Pre-NTT +616 ordinary forward.
Physical NTT retirements are1805 successes +6 real source-ID rejections;
five further requests are interrupted by reset/fault. Six physically complete
results have deliberately corrupted observed tags and are discarded by the
preparation owner;1799 transforms pass its result checks/source-release step.

Checked scalar writes1013992 =551881 decoded raw coefficients +462111
transform values.462111 =1805 x256 complete result values +31 partial
writeback values before reset. Public/privileged packed reads115776 =105728
prepared-key words +10048 sentinel words(157 non-reset cases x64). The
105728 key words x4 =422912 retained successful coefficients,including332800
from75 official KeyGen SKs.95 additional held consumer-read responses check
the clear barrier and are logged separately,not counted in115776.

96 context publications =95 normally completed prepared keys +one valid
held-done context reset before retirement;that aborted case is not credited
as a successful completion. Clear releases1652 retained polynomial regions;
normal source retirement releases1799;error cleanup releases318 more owned
raw/replacement/result allocations. The live allocation monitor observes
peak13/18/24 key regions at levels2/3/5,matching N+1;physical bank dimensions
are unchanged. Logical payload sizes are listed in MEMORY_MAP.md.

The first key witnesses all child backpressure channels;stall occurrence is
not required for every individual key. The full workload has1106 held-done
cycles,855 retained-READY probe cycles,85 load-command stalls,1187 NTT-command
stalls,4177 release stalls,196 load-done stalls,4741 NTT-done stalls and665
clear-barrier cycles. Outer ownership is witnessed for3170205 cycles. These
include artificial stalls,foreign sentinels,readback and cleanup:they are not
production preparation/full-Sign latency or throughput benchmarks.

All57 prior RTL files and6.757ns SDC are unchanged. The new control/header
client has no polynomial RAM or duplicate engine/bank tree. No new fitted
ALM,Fmax,setup/hold slack,netlist or full-system coverage result is claimed;
functional integration continues before PPA optimization.

## Stage5N.4c2 shared-service key ingestion

The production shared-service gate preserves the client workload:
138 commands =95 successes +38 expected errors +5 resets;449992 checked
scalar writes =422912 successful +16585 error prefixes +10495 reset prefixes.
105728 packed readbacks x4 =422912 successful coefficients,including332800
from75 official KeyGen secret-key inputs.

Additional work is133 independently checked sampled sentinel polynomials
(8512 packed reads),three17-byte raw hashes and three held public-read
responses.95 valid keys are then consumed by real read-only CNB operations.
The DMA schedule adds95 x(1 metadata check +64 arithmetic words)=6175
internal reads;these are not counted in the105728 public key-word readbacks.
Each of three levels exercises eight
six-cycle prior-owner holds. Acceptance/held-ownership/rollback counters are
verification witnesses,not production latency or throughput benchmarks.

No fitted ALM/Fmax/slack result is produced for this new production wiring.
The6.757ns constraint stays unchanged;PPA work remains deferred until the
complete functional integration is ready.

## Stage5N.4c1 key-loading measurements

138 commands =95 successful keys +38 expected errors +5 reset-aborted keys.
449992 exact scalar writes =422912 successful coefficients +16585 error
prefix coefficients +10495 reset-prefix coefficients. Successful readback is
105728 packed92-bit words x4 =422912 coefficients. This includes all75 official
KeyGen secret keys,which contribute332800 coefficients. The additional
boundary cases reuse existing known keys;they are not extra official cases.

The client serializes coefficients and waits for physical word ACKs before
polynomial finish. The focused harness adds deliberate allocation/write/finish/
release/read stalls,so its runtime is not a production signing throughput
benchmark. No previous RTL or6.757ns SDC changed;no new ALM,Fmax,slack or
full-operation cycle result is claimed. Optimization remains deferred.

## Stage5N.4b signing hash test measurements

167 commands =128 successes +34 expected errors +5 reset-aborted requests.
52618 accepted absorption words include verified aborted prefixes.
Finite SHAKE output7760 bytes =6464 success +1296 invalid-request drain
diagnostics.29 peer-core jobs add464 separate checked raw bytes,not included
in7760.6400 mask coefficients =25 complete polynomials;9 actual RTL digest
forwards form dependent commands. Python/C checks154 intended messages/
420639 bytes and26 masks(including one source for a reset-aborted request).

The formatter uses1024 prefix bits +128 merge bits plus control. It deliberately
does not push and pop its reservoir simultaneously;this is a functional
foundation,not a one-word-per-cycle claim or signing throughput result.
The existing16-bit service length caps a mu absorption at65535 total bytes;
tests exercise that boundary and reject overflow. No existing RTL,Fmax,area,
slack or clock-target change.6.757ns SDC remains unchanged. Whole Sign latency
and throughput remain unmeasured.

## Stage5N.4a decoder measurements

129 commands produce124 completions(92 success,32 expected errors) and5 reset
aborts. Exact emitted coefficient count436424 =409600 from successful keys +
16585 tentative error prefixes +10239 reset prefixes. The75 official keys
account for332800 successful coefficients. There are46970 accepted64-bit input
words and121 accepted headers across the directed campaign.
C checks128 full key fixtures/549888 coefficients;this includes complete source
keys for malformed-frame/abort cases,so it differs from emitted RTL prefixes.

Witness totals:872 held-header cycles,253519 held-coefficient cycles and682406
blocked-input cycles,plus774 deliberate done/reset hold checks. These measure
the directed stalled test,not a signing throughput benchmark. The decoder emits
at most one coefficient/cycle while reservoir data is available and accepts a
new64-bit word when fewer than one coefficient's bits remain. No simultaneous
input/output beat is claimed. Storage is1024 header bits +76 reservoir bits
plus control metadata,not a full encoded-key RAM. No new Fmax/area/slack or
operating-frequency claim;6.757ns SDC and existing production RTL are unchanged.

## Stage5N.3 memory-path measurements

| Focused campaign | Observed work |
|---|---|
| sign_dma |71 commands,65 completions,21 expected errors,6 resets;14284 exact scalar writes,3570 acknowledged packed writes |
| sign_service |33 commands,30 completions,9 expected errors,3 resets;192 sampled source words +768 exact result words |

The DMA count includes verified partial write prefixes later canceled by reset.
The service result count is768x4=3072 coefficients;source count is192x4=768.
These are directed campaigns with imposed stalls,not signing throughput figures.
sign_process can accept one x4 group/cycle unstalled,but this sequential DMA
uses the existing one23-bit coefficient/write beat and two word caches. It is
not a four-coefficient-per-cycle full-memory datapath. Decompose writes512
coefficients;Mhint writes256;CNB writes none. All read/commit/retirement overhead
must be included in future operation measurements.

No synthesis,Fmax,area or timing improvement is claimed. The6.757ns constraint
is unchanged. Full Sign/Verify latency and throughput are not measured yet.

## Stage5N.2 focused process counts

sign_process accepts up to one4-coefficient group/cycle with one elastic
register stage. This is an interface capability,not an integrated throughput
measurement. The directed test accepts7752 groups and returns7746 results;
six held groups abort on reset.45 returned groups are expected errors.
Thus7701 valid arithmetic groups cover30804 lanes;180 error lanes are checked
for zeroed payloads.117 full polynomial packets are included.
7509 simultaneous replacements,2865 input stalls and2903 output stalls are
deliberately exercised. Per-polynomial hint counts include256,so a9-bit count
is required. CNB failure is a sticky prefix OR,not a count.
No Quartus/PPA measurement or operating-frequency claim is made for the new
process. Existing6.757ns integration SDC remains unchanged.

## Stage5N.1 ownership relocation

All key-byte/hash/read totals below remain unchanged in the freshly rerun
full_keygen and nist_keygen gates. The local simulated campaign duration is
6676943064ps,identical to Stage5M. Local ownership witness:988082 owned cycles,
195 post-completion cleanup-owner cycles,52 unowned-idle cycles. NIST witness:
9142284 owned,2225 cleanup-owner,151 unowned-idle cycles. These count the whole
directed workload with imposed stalls;they are not per-key throughput figures.
No extra request/response pipeline or memory is added. No new area,Fmax or
slack measurement is claimed;6.757ns remains unchanged.

## Stage5M NIST functional counts

All75 cases succeed:25 at each level2/3/5. Successful key bytes total
25*(3872+5984+7488)=433600,or54200 accepted64-bit output words.
PK hash inputs:25*(164+244+324)=18300 words;tr:75*64=4800 bytes.
Encoding field reads:25*64*(16+23+31)=112000 metadata-checked words.
These counts include no aborted prefixes. Fork witnesses are3632 host-ahead
and17452 hash-ahead cycles. Output stalls are deliberate,so these are not
sustained-throughput results. All46 RTL files and the6.757ns constraint are
unchanged from Stage5L. No new Fmax,area,slack or full-top synthesis is claimed.

## Stage5L complete-key functional counts

No new clock,Fmax,placed-area or slack measurement is claimed. The fixed
6.757ns constraint remains unchanged;the Quartus top is still the historical
scalar helper. Full-key cycle totals include sampling,compute,word packing,
host/hash stalls and final cleanup;no throughput benchmark is inferred here.

Eight successful operations emit36704 valid key bytes =4588 output words.
The full capture contains5433 words =43464 bytes;the extra845 words =6760
bytes are reset-aborted prefixes. Do not count them as successful keys.
The successful set is six level2 keypairs,one level3 and one level5.

There are2058 actual PK absorption words =16464 bytes,including abort prefixes.
656 tr bytes =512 from successful operations +144 from partial/aborted ones.
11179 field read responses include metadata checks for aborted prefixes;
complete byte comparison validates the data encoded into keys.
Fork witnesses434 host-ahead cycles and1939 hash-ahead cycles demonstrate
both acknowledgement orders in this workload. They are not performance
targets and do not measure sustained key-generation throughput.

## Stage5K functional packing/rounding counts

No synthesis or new Fmax/ALM/slack measurement is performed. The6.757ns
constraint remains unchanged. Bitpkg's87-bit reservoir size is a logical RTL
width,not fitted area or a promised frequency.

Rounded KeyGen writes190224 values =172304 from the polynomial baseline
+70 complete rounded polynomials x256. There are35 rounded pairs:34 delivered
rows plus the completed first row subsequently reset while held.
Public readback12800 words =8448 baseline +68 retained rounded polynomials
x64 words. The additional68 correspond to34 successfully consumed rows.

Bitpkg checks2482 accepted64-bit words=19856 bytes,including valid prefixes
of failed/aborted packets. Successful packets alone contain16832 bytes.
The independent C comparison covers66 full valid fixture inputs,including
abort/recovery fixtures,total18496 bytes;these are different denominators.
Do not report this stimulus-dependent word count as sustained throughput or
whole-KeyGen key generation latency. Full-key serialization/hash work remains.

## Stage5J functional work and counting

Current result is functional polynomial computation,not a new timing/area run.
No change to the6.757ns constraint or new ALM/Fmax/slack claim is made.
The controller samples/transforms sequentially and waits for caller row reads.

Seven successful operations produce34 t rows (18 across the three ordinary
levels plus16 in four level2 recovery runs).8448 public words contain33792
coefficients:8704 t values plus25088 retained-secret/transform values.

The scalar-write count is172304:673 complete polynomials x256 values plus
8 secret-prefix values and8 accumulator-prefix values from reset tests.
This includes internal products/sums/transforms,not just the34 final rows.
Actual elapsed KeyGen latency includes caller stalls and all sampling/loading,
compute,output and cleanup phases. Byte encoding/hash work is still absent;
do not label this whole-KeyGen throughput or multiply core Fmax by row counts.

## Stage5I functional observations

Seed-driven row capture:190 source commands =20 successful seed expansions,
163 successful samples and7 rejected adapter commands. Each expansion consumes
five64-bit absorption words and produces eight128-bit output beats;all2560
bytes match. Sampling consumes1103 formatter words in this workload.
The row workload remains13 complete rows,27 rejects and7 reset aborts with
161 NTT commands and55 ADDs. Re-expansions include resets and deliberate
level switches in negative-fixture setup;this is not the final KeyGen schedule.

No new synthesis,ALM,Fmax,slack or throughput claim is made for this added
seed/control path. The historical scalar top and6.757ns constraint are unchanged.
Seed collection,formatting,sampling and compute remain sequentially scheduled;
whole-KeyGen latency cannot be inferred from standalone NTT cycle counts.
Correct full-operation outputs still precede PPA optimization.

## Stage5H row-scheduler observations

A successful l-column row issues l PWM commands,l-1 in-place ADDs and one inverse
NTT. Thus levels2/3/5 use4/5/7 PWM,3/4/6 ADD and one inverse respectively.
Secret transforms are retained across rows;the test uses both ordinary NTT and
eligible Pre-NTT. No new arithmetic pipelines or parallel cores are added.

Payload DMA reads128 words per PWM,128 per ADD and64 per inverse:256*l-64 word
reads per row. Payload writes64 words per result:128*l per row. These counts
exclude metadata validation reads and external observation. The scalar engine
still needs one23-bit coefficient per beat;this is not LightHD32-cycle loading.
One accumulator and one scratch region are reused;the coefficient result has
its own region. Each is64 words x92 bits. Total bank geometry stays46KiB.

The campaign checks13 full rows,27 rejections,7 resets;163 samples,161 NTT/Pre/
PWM/INTT commands,55 in-place ADDs,96264 scalar writes,24066 packed writes/acks,
12544 public word reads and6918 old-word cache reads.160 held-row and4 pending-
read refusal checks pass. These are source workload counts,not sustained
throughput,full-KeyGen latency or a new fitted Fmax/area/slack/RAM result.
Rows are fully staged and execute sequentially. Overlap/PPA work stays deferred.
## Stage5G banked process observations

23 sample jobs,15 NTT commands and71 process commands pass. Processing has34
successes,33 expected rejections and4 reset aborts. Actual accepted arithmetic
operands8978,completed outputs8976;the two extra inputs are canceled by reset.
Stored low/high/residue writes are separately checked,including partial aborted
work. Full campaign:22297 scalar writes,5574 packed writes/acknowledgements,
8512 exact92-bit read responses. These counts are workload evidence,not a
sustained throughput measurement or full-KeyGen latency.

The client reads A and B as two92-bit words for each binary four-coefficient
group:128 reads per ADD/SUB,64 per P2R. It feeds one coefficient into the existing
elastic arithmetic stage,waits for the residue/low write and,for P2R,the high
write,before advancing. Each unary result region uses64 packed writes. P2R uses
two regions/128 writes. Requests/responses,packing acknowledgement and exclusive
ownership add cycles;the one-coefficient-per-cycle unit rate is not the whole
DMA rate. Pipelining/overlap is deferred until full-operation correctness.

Witnesses:36 wait/source-release refusal checks,188 held-result release checks,
4 pending-read refusal checks and22 actual partial-P2R-publication snapshots.
Logical payload stays46KiB;two92-bit word caches and control add unsynthesized
logic. No new fit,Fmax,placed-area,slack or physical RAM count is available.

## Stage5F banked NTT observations

The real banked connection passes16 sample jobs/54 commands,with30 completed
arithmetic results,21 expected rejections and3 reset aborts. It checks9746 scalar
DMA values,7712 engine outputs and2944 exact92-bit word reads. Witnesses:
24 destination-wait cycles,206 held-completion cycles,295 public read-response
stall cycles,33 source leases,4 compute-refusal checks during a pending read
and120 blocked result-release checks while completion is held.

DMA reads one92-bit word and holds it through four scalar NTT input handshakes.
Thus a unary load needs64 word reads/256 scalar transfers;PWM needs128 reads/
512 transfers. Request/response control adds cycles. Result packing writes64
words for each successful operation and pauses the engine while a packed word
awaits acknowledgement. Sampling and compute are sequential. This reduces RAM
request count from the old scalar DMA but does not implement LightHD's32-cycle
wide NTT loading or establish maximum sustained/full-operation throughput.

No NTT arithmetic RTL,pipeline,core count or internal compute latency changes.
Memory payload remains46KiB. This new controller has no synthesis/fit result;
there is no current banked-system placed-ALM,Fmax,slack or physical RAM count.
The6.757ns benchmark remains unchanged;PPA optimization is deferred.

## Stage5E connected packed-bank storage observations

Source workload104 jobs produces88 complete polynomials and5632 exact92-bit
word readbacks. It observes8 occupied-region stall cycles,1070 held-read cycles
and50 simultaneous read-request/coefficient-write handshakes. Two held responses
are reset. Publication includes the final word acknowledgement and hash drain.

Each context packs four coefficients,then pauses until its word write is
acknowledged;the implementation allows one outstanding sampler write per bank.
This is a correctness baseline,not a maximum-throughput claim. Public checked
reads use one global outstanding response and wait through the synchronous RAM
and response-register stages. Memory capacity is unchanged at46KiB payload;
descriptor/packing/control registers add logic that has not been synthesized.
The scalar NTT wrapper and its measured cycles are unchanged. Full-system
Fmax/placed area/throughput remain unmeasured for this new path.

## Stage5D bank-memory foundation observations

Published/selected logical capacity:four1024x92-bit banks=376832 bits=47104
bytes=46KiB. This is16 times the old four-slot payload2944 bytes,not a physical
M10K count. Each bank has two ports and each92-bit word holds four coefficients.

The focused test observes1031 cycles with all eight requests accepted,4112
dual-read same-address pairs,73 serialized collisions,3075 request stalls,
3034 response stalls and14807 response replacements. Each unblocked port can
accept one word per cycle. These are source-test observations,not a clock/Fmax
or complete system throughput result. No synthesis/fit or RAM inference measured.

The current NTT wrapper remains one23-bit coefficient per beat;LightHD's32-cycle
input loading needs the corresponding wide engine input/controller integration.
The memory foundation alone does not change any measured NTT cycle count.

## Stage5C shared-service observations

The focused test sees67 cycles with both a raw and sampling owner,333 with
two raw owners,60 raw-output stalls,298 raw-completion stalls and44 held seed
result cycles. One simultaneous descriptor conflict confirms raw priority.
These count ownership/handshake conditions,not overlapping permutation clocks.
26 commands produce1699 checked SHAKE bytes and1792 sampled coefficients.
Finite raw transfers honor partial bytes at the136/168-byte rate boundaries.

No added hash cores;the128-byte expansion collector adds logical register state.
The current Stage4 top leaves RAW_SERVICE disabled. No fit/synthesis was run;
do not infer current placed ALMs,Fmax or throughput from old Stage2 reports.

## Stage5B message-builder observations

The formatter emits five64-bit words for seed/matrix messages,or nine for
secret messages,after descriptor acceptance. It can emit one word per cycle
when the hash service is ready. The final word has two valid bytes. Message
completion is separate from hash completion;no full-KeyGen latency is measured.

The focused165-command test observes111 descriptor,288 input,757 completion and
671 hash-output stall cycles;883 accepted words include7 reset-aborted-prefix
words. Python matches5888 SHAKE bytes. These workload witnesses are not FPGA
Fmax or system throughput. The main top is unchanged;no new synthesis/PPA.

## Stage5A process-unit observations

The isolated elastic unit observes10009 same-edge output/input replacements,
3505 blocked-input cycles and3511 held-output cycles in its10349-case workload.
It permits one coefficient per cycle when both ends are ready. These observations
do not establish FPGA Fmax or full-polynomial/Dilithium throughput. The unit is
now connected through Stage5G above;its banked PPA remains unmeasured.

The candidate four-slot KeyGen schedule in MEMORY_MAP.md requires16 forward
transforms at level2 if s1 is regenerated for each row,instead of4 with cached
transforms. This tradeoff is not adopted yet. Record its impact when deciding
the full-controller memory schedule;do not hide it in a compute-only comparison.

## Current boundary:Stage4 all three engines through memory

The top is now keccak_sampler_ntt. No Stage4 synthesis/fit has been run;there
is no current integrated placed-area,Fmax,slack or RAM-packing claim. Existing
output_files reports still describe the earlier Stage2 producer-only top.
The6.757ns benchmark constraint is unchanged. PPA optimization stays deferred.

Stage4 checks4096 sampled values,9745 DMA loads,7713 NTT outputs and11776
stored reads.30 complete result polynomials account for7680 NTT outputs;
33 additional outputs were accepted before a reset. The other abort targets
were during loading and computation.24 full-pool wait cycles,188 completion
stall cycles,699 read-response stall cycles and33 source-lock observations
are functional witnesses,not a throughput rate. All earlier Stage2/3 cycle
observations remain scoped to their own test workloads.

The initial DMA waits for each synchronous response/engine acceptance before
requesting the next coefficient. NTT compute/sampling are scheduled serially.
Its latency/throughput must not be equated with the standalone engine's no-gap
wrapper numbers or the internal four-butterfly issue rate. Wider/pipelined DMA,
more banks and overlap are later measured optimization options.

Relocated standalone NTT correctness was refreshed. Its original branch PPA
under quartus/ntt/results is historical;no fresh relocation fit was requested.

## Historical source boundary:Stage3 Keccak+sampler+memory

The Stage3 project selected keccak_sampler_memory with four logical
polynomial slots. Stage3 has source/Python functional results only;there is no
fresh Stage3 fit,Fmax,placed-area,slack or RAM-inference claim. Timing/resource
measurements below describe the prior Stage2 top and are historical.

The Stage3 workload checks23180 writes (22528 complete values+652 aborted-prefix
values),22528 readbacks,88 releases and99 rejected reads. It observes8 full-pool
blocked command cycles,1321 held-response cycles and170 concurrent read/write
cycles. These are functional witnesses,not throughput benchmarks. The configured
payload is23552 logical bits/2944 bytes;FPGA RAM packing is not measured yet.

## Historical measured boundary:Stage2 Keccak+sampler

The previous Stage2 project synthesized the real Keccak+sampler helper,
not a complete Dilithium accelerator. The project grows with the
controller,memory,NTT and process blocks. The user selected an initial148MHz
target:6.757ns,unchanged. The first combined fit is complete:129.18MHz worst Fmax and-0.984ns setup;
the requested148MHz timing target is NOT met.

Current main trial8:137.74MHz worst Fmax,-0.503ns setup,+0.157ns hold and11293
placed ALMs. Structural guards pass. On2026-10-20 the user stopped timing
optimization in favor of functionality-first integration. Fmax,area and
throughput optimization follow correct full-operation outputs;the timing miss
does not block Stage3 memory. The initial fit table below is historical.

Do not sum standalone module area or substitute the148MHz target for fitted
Fmax. All resource headlines use actual placed ALMs. Physical data I/O are
virtual/excluded from this internal benchmark;board timing is not closed.

## Functional-workload cycle observations

`sim/dilithium/stage2_jobs.csv` records104 jobs with case/ID/core/mode/param,
abort flag,and clock indices for command acceptance,first SHAKE beat accepted,
first sampler beat accepted,first/last coefficient,source stop and retirement.
The focused testbench has a6757ps rising-edge interval. Below are the22
successful jobs in each mode from this paired,stalled,boundary-length workload.

| Mode | Command acceptance → last coefficient | Command acceptance → first SHAKE beat accepted |
|---|---:|---:|
| Matrix A |750–1117 cycles|See stage2_jobs.csv|
| Secret |507–909 cycles|See stage2_jobs.csv|
| Mask |744–1185 cycles|See stage2_jobs.csv|
| Challenge |981–1921 cycles|See stage2_jobs.csv|

These ranges include deliberately varied input lengths/source gaps,peer work,
and output/status stalls. They are not isolated sampler compute latency or a
continuous-throughput benchmark. Negative timestamp fields mean the event was
not reached before an error/abort. Completion rates must later be measured
under a specified workload,with first-to-last intervals and pipeline overlap
boundaries. No full KeyGen/Sign/Verify latency is claimed.

Current functional observations:drops99,bridge cancellations140,blocked hash
cycles33316,dual-owned cycles37383,and upstream-retirement waits293. The queue
was full for34198 observed cycles,with128 simultaneous push/pop events. These prove
the exercised control paths;they are not coverage percentages or throughput.

## Initial synthesis record

Combined settings: Cyclone V5CGXFC7C7F23C8,Quartus25.1std,seed1,HIGH PERFORMANCE
EFFORT,physical register retiming OFF. Both engines' accepted RTL remains
unchanged. The new scalar SHAKE-mode decode replaced a port expression that
Quartus interpreted as an implicit net;that initial diagnostic run was stopped
and excluded. The current full fit uses the corrected source.

The combined TimeQuest helper preserves original sampler payload/register
guards with hierarchy-qualified names. Current structural guards pass,while timing misses the target as recorded below. Pipeline/area
optimization was attempted before memory. That ordering is now superseded by
the user's functionality-first decision;the benchmark constraint stays intact.

## First combined fit ? functional PASS,timing target OPEN

| Metric | Initial complete Stage2 fit |
|---|---:|
| Actual placed ALMs |11059|
| Registers |7396|
| Combinational ALUTs |16025|
| M10K / DSP |1 /0|
| Slow85 / Slow0 Fmax |129.18 /134.16MHz|
| Requested period |6.757ns (about148MHz),unchanged|
| Worst setup slack |?0.984ns|
| Worst hold slack |+0.166ns|
| Slow85 / Slow0 setup TNS |?1118.959 /?493.897ns|
| Hold TNS |0 at all four corners|
| Minimum pulse-width slack |+1.202ns minimum;positive at all four corners|
| Accepted sampler register guards |PASS,including original64-bit secret banks,140-bit commit payload and128 sign bits|

Quartus full compilation succeeds,but its timing-requirements warning is real.
The critical path is Keccak core1 absorb_block_full ? state_array registers,
with7.468ns data delay at the Slow85 corner;about78% of that path delay is
interconnect. See critical_paths/slow_85C_setup.rpt. It is not a sampler oracle
mismatch. The combined project has physical register retiming OFF,whereas the
standalone Keccak project enabled it. Retiming/placement/fanout are candidates
for a controlled review;their individual contribution is not yet measured.

This is an initial subsystem baseline,not an accepted148MHz implementation or
full-system PPA result. No target was relaxed. The earlier choice to close timing
before memory is superseded by the functionality-first decision above.
Initial immutable evidence:stage2_subsystem_initial.zip
and its SHA256 sidecar under evidence/.

### Timing trial1:settings only,no measured gain

Keep global retiming OFF,enable it only for hash hierarchy,and explicitly
disable it for sample hierarchy. Enable combinational physical synthesis,
register duplication and maximum router timing effort as in standalone Keccak.
No RTL,clock period or functional workload changes. The completed fit exactly
reproduces11059 placed ALMs,129.18MHz and-0.984ns setup. Original sampler
register guards PASS. Retiming runs but reports0ps estimated improvement;
this trial did not close timing.

### Timing trial2:lane-qualified Keccak absorb writes,rejected

Only src/keccak/keccak_core.sv changes:an absorbed64-bit word writes its
destination lane;the other lanes retain their state. Permutation and padding
still update the full state at the same edge. This removes absorb-dependent
control from a shared1600-bit write enable without adding a cycle. The initial
accepted Keccak revision remains preserved in the immutable import archive.

Focused104-job source/Python checking and12 checker fault gates PASS with23081
exact values. All104 workload cycle-witness rows match the initial snapshot
byte-for-byte. The full standalone Keccak regression passes904 UVM transactions
plus all dual suites,with zero UVM errors/fatals. After a declaration-only
Quartus syntax correction,the exact current source again passes the104-job
check;all6364 published NIST outputs match exactly. The fit worsens to11758
placed ALMs,7393 registers,16236 ALUTs,125.20MHz worst Fmax and-1.230ns setup;
hold+0.156ns. Slow0 Fmax127.80MHz. Setup TNS is-1010.976/-632.800ns at slow85/0;
all hold TNS remains0. Keccak3200-bit state and original sampler guards PASS.
The critical path moves to Keccak permutation data,with79% routing delay.
This implementation is rejected and restored to the original state-write form.

### Timing trial3:global routing for the original state enable,rejected

Restore original whole-state writes and name their existing combined enable
`state_array_enable = init_wr_en || state_array_wr_en`,with a keep attribute.
The QSF requests a dedicated global route for this1600-register data enable
inside each core. No generated clock or new cycle is introduced;the real clk
and6.757ns constraint are unchanged. Verify actual global routing in the fitter
report,all3200 state bits and the accepted sampler register guards.

Current-source104 jobs/23081 values and12 checker fault gates PASS;all104 cycle
rows match the initial snapshot exactly. Full904-transaction Keccak regression
plus dual suites PASS,zero UVM errors/fatals. Fitter confirms two dedicated
global control networks,each with1600 fanout. All6364 published NIST outputs
match that trial's source. Final fit:11256 placed ALMs,7402 registers,16081 ALUTs,
93.59/94.63MHz slow85/0 Fmax,setup-3.928ns,hold+0.155ns;slow85/0 setup TNS
-12479.887/-11921.846ns,all hold TNS0. Original Keccak/sampler guards PASS.
Dedicated routing increased control arrival delay;this trial is rejected.
Batch Keccak regressions now
omit recursive waveform recording;GUI waveform recording is unchanged.

The [Cyclone V handbook](https://cdrdv2-public.intel.com/666995/cv_5v2-683375-666995.pdf)
describes using global routing for high-fanout controls including clock enables.
This trial changes routing of a synchronous data enable,not the clock definition
or timing exceptions.

### Timing trial4:original RTL,local clock-enable mapping change

Restore the exact initial RTL(source vector token matches the initial snapshot).
Disable AUTO_CLOCK_ENABLE_RECOGNITION only on hash state_array registers;leave
sampler mapping unchanged. Analysis confirms3200 fewer clock-enable registers:
6153 initially versus2953 now. This selects feedback multiplexers for the two
Keccak states;it adds no clock,cycle or protocol change. Fresh104-job checking/
23081 values and12 checker fault gates PASS. Final fit:12366 placed ALMs,7395
registers,16558 ALUTs,130.92/130.79MHz slow85/0 Fmax;worst setup-0.889ns,
hold+0.146ns. Slow85/0 setup TNS-198.974/-152.546ns;hold TNS0 everywhere.
Original sampler and3200-bit Keccak state guards PASS. This is not timing
closure;its area increase is not accepted as a final design. Critical path is
offset_count through request/start/init decoding to Keccak state synchronous clear.

The [Quartus Standard mapping guide](https://docs.altera.com/r/docs/683283/18.1/design-compilation-user-guide-quartus-prime-standard-edition/controlling-clock-enable-signals-with-auto-clock-enable-replacement-and-direct_enable?contentId=lEZsrgY7vUwiSGtgN95~0Q)
documents this per-register option and its feedback-mux implementation.

### Timing trial5:predecoded launch-offset ready,still open

Retain trial4 mapping while registering the offset-count-zero decision one
cycle ahead. Reset/zero-offset launches set ready;loading a nonzero interval
clears ready;decrementing count1 sets ready for the following zero-count cycle.
The26-cycle launch gap is unchanged. A source invariant checks the flag against
the counter,and a fitted-register guard requires the new flag to survive mapping.
104 focused jobs/23081 exact values and12 checker fault gates PASS;all104 cycle
witness rows match the initial snapshot. Full Keccak904-transaction regression
plus all dual suites PASS,zero UVM errors/fatals. Core SHAKE RTL remains exactly
the initial source whose6364 published NIST outputs passed;only the wrapper's
countdown flag changed. Fit:12356 placed ALMs,7396 registers,16574 ALUTs,
129.27/131.32MHz slow85/0 Fmax,setup-0.979ns/hold+0.164ns. Slow85/0 setup
TNS-205.562/-114.946ns;hold TNS0. Original state/payload guards and the new
offset flag guard PASS. The worst path now crosses sampler generated/source_stop
through bridge discard/ready into Keccak squeeze/permutation counter control.

### Timing trial6:two-slot registered-credit bridge,still open

Keep trial5's local state mapping and offset flag. Replace the one-slot bridge
and combinational ready chain with a two-slot queue. Upstream room depends only
on registered occupancy;draining-context bypass depends only on registered
drain state. Immediate sampler source_stop still cancels that context's head
offer;status retirement checks both queue slots. Simultaneous push/pop remains
possible,without changing external ports or either engine's processing stages.

Fresh104-job source/Python PASS:88 complete,8 expected errors,8 reset aborts,
23089 checked values(22528 complete+561 aborted prefixes),24 mode/param/core
combinations;12 checker corruptions rejected. Four reset phases reach both
owned contexts;phase0 now requires a full two-slot queue. Full-queue cycles34198
and simultaneous push/pop128 are observed. Stops follow discarded release
handshakes;all public offers remain stable under stalls.

This deliberately stalled workload finishes at retirement clock48525 versus
48911 initially. Some individual latencies increase and others decrease due
to changed queueing/peer/stall phases;this is not a sustained-throughput claim.
Command-to-last-output ranges:A750-1117,secret507-909,mask744-1185,challenge
981-1921cycles. Clean trial6c fit:12542 placed ALMs,7581 registers,16711 ALUTs,
one M10K/1024 bits,zero DSP. Slow85/0 Fmax134.77/134.17MHz;worst setup-0.696ns,
hold+0.150ns. Slow85/0 setup TNS-105.438/-59.416ns;all hold TNS0,min pulse-width
slack+1.202ns. Original sampler/Keccak guards,offset flag and all256 queue
payload bits PASS. The remaining worst path is Keccak state-to-state permutation
logic,7.221ns data delay at slow0. Timing remains open.

The first trial6 mapping inferred block RAM for the two-entry payload. It was
interrupted;the first stop failed and a replacement briefly overlapped it.
Both task-owned process trees were then terminated and the generated db and
incremental_db directories cleared. Neither interrupted run is a PPA result.
The active trial6c is a clean full build with ramstyle="logic" on the payload;
synthesis confirms only1024 block RAM bits(the original sampler Ball memory).
The fitted helper must retain all256 bridge payload registers as well as the
original Keccak/sampler registers. No polynomial memory has been added.

### Timing trial7:predecoded absorb-ready,original compact mapping

Remove trial4's clock-enable suppression to restore the original smaller state
mapping. Add one absorb-ready flag per core,maintained from accepted message
words,rate-boundary events and final permutation rounds. An invariant requires
it to equal STATE_ABSORB && !absorb_block_full && !msg_received. The wide write
uses that flag with input valid;the permutation mux uses the current state
directly. No extra absorb/permutation cycle or interface change is introduced.

104 jobs/23089 exact values and12 checker faults PASS;all104 cycle rows match
trial6 byte-for-byte. The fitted helper requires both new flags to survive.
Full904-transaction Keccak regression plus dual suites PASS,zero UVM errors/
fatals. All6364 captured outputs match the published NIST vectors on both cores.
Fit:11204 placed ALMs,7570 registers,15995 ALUTs,1M10K/0DSP. Slow85/0 Fmax
124.72/128.50MHz;setup-1.261ns/hold+0.162ns. Slow85/0 setup TNS
-1618.286/-912.227ns;all hold TNS0. All register guards PASS. The worst path
starts in sampler active_r,through the command-ready mux,into Keccak state
initialization. The permutation-only path is also late(-0.891ns at slow85).

### Current functional implementation:trial8 ownership-qualified command ready

An unowned context is sampler-inactive:reset clears both,commands set both,and
ownership releases only with the external sampler-status handshake. Thus the
extra sampler_job_ready condition is redundant beside !owned. Remove that
combinational feedback from request_valid/job_ready,while checking both
sampler_active implies owned and accepted-command implies sampler_job_ready.
Atomic starts still use the same common handshake and core assignment.

104 jobs/23089 values and12 checker faults PASS;all104 cycle rows match trial7.
Keccak RTL is unchanged from the904-transaction/6364-NIST passing trial7.
Seed1 and an isolated seed2 fit use identical RTL,device,clock and settings.
Both compiles have finished. The main seed1 build reports11293 placed ALMs,
7557 registers,15970 ALUTs,one M10K/1024bits and zero DSP. Slow85/Slow0 Fmax
is138.06/137.74MHz;worst setup is-0.503ns and worst hold+0.157ns across four
corners at6.757ns. Setup TNS is-147.307/-47.642ns at the two slow corners;
hold TNS is zero at all four corners. Keccak/sampler register guards pass.
Evidence:quartus/dilithium/output_files/dilithium.fit.rpt,
dilithium.sta.rpt and stage2_timing8_guard.log. The isolated seed2 experiment
is not selected. Further PPA work is deferred;retain the verified functional
source for Stage3 integration.
