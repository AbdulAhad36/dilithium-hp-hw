$ErrorActionPreference='Stop'
foreach($kind in @('baseline','direct')){
 Set-Location -LiteralPath "D:/GitHub/dilithium-hp-hw/tmp/stage7c15_router_map_$kind"
 & 'F:/altera/quartus/bin64/quartus_map.exe' probe -c probe --read_settings_files=on --write_settings_files=off *> map.log
 if($LASTEXITCODE -ne 0){throw "Router prototype synthesis failed:$kind"}
 "DIRECT_MEMORY_MAP_PASS:$kind"
}
