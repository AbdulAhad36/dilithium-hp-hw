$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
foreach ($jobId in @(18508,15404,22536)) {Wait-Process -Id $jobId -ErrorAction SilentlyContinue}
foreach ($kind in @('native','uvm','quartus')) {
  $marker='STAGE7C15_'+$kind.ToUpper()+'_RUNNER_PASS'
  if (-not (Select-String -LiteralPath "sim/dilithium/stage7c15_${kind}_runner.log" -Pattern $marker -Quiet)) {throw "C15 qualification incomplete: $kind"}
}
foreach ($reader in @('source_audit','metrics','admission_registers','native_structure','shared_hint_registers','area_delta','throughput','cycle_audit')) {
  & 'C:/Python314/python.exe' "sim/dilithium/reference_build/stage7c15_${reader}.py" *> "sim/dilithium/stage7c15_${reader}_console.log"
  if ($LASTEXITCODE -ne 0) {throw "C15 result reader failed: $reader"}
}
& 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py uvm_check *> sim/dilithium/stage7c15_final_uvm_check.log
if ($LASTEXITCODE -ne 0) {throw 'C15 final UVM source freshness failed'}
'STAGE7C15_RESULT_COLLECTION_PASS'
