onerror {quit -code 1 -f}
vlib sim/dilithium/work_memory_direct_probe
vmap memory_direct_probe sim/dilithium/work_memory_direct_probe
vlog -sv -work memory_direct_probe tmp/stage7c15_memory_direct_probe.sv tb/tb_dilithium/lighthd_memory_router_c12_reference.sv tmp/tb_stage7c15_memory_direct_probe.sv
vsim memory_direct_probe.tb_memory_direct_probe
onfinish stop
run -all
quit -f
