from pathlib import Path
import re,json
p=Path('quartus/dilithium/critical_full/mapped_register_names.rpt')
names=p.read_text().splitlines();result={}
for label,pattern,minimum in [('ntt_read_release',r'\|lighthd_ntt_dma:polynomial\|read_release_r',1),('ntt_final_ready',r'\|lighthd_ntt_dma:polynomial\|finish_ready_r',1),('deferred_retirement',r'\|lighthd_memory_router:router\|retire_pending_r',8),('admit_mask',r'\|lighthd_memory_port:.*\|admit_mask_r',8),('admit_mask_error',r'\|lighthd_memory_port:.*\|mask_bad_r',2)]:
 matches=[n for n in names if re.search(pattern,n)]
 result[label]=dict(count=len(matches),minimum=minimum,names=matches)
 assert len(matches)>=minimum,(label,len(matches),matches)
Path('sim/dilithium/reference_build/stage7c15_admission_registers.json').write_text(json.dumps(result,indent=2)+'\n')
print('C15_ADMISSION_REGISTER_GUARD_PASS:'+','.join(f'{k}={v["count"]}'for k,v in result.items()))
