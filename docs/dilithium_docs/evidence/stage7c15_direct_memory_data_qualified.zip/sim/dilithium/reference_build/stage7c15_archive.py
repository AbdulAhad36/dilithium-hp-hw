from pathlib import Path
import hashlib,json,zipfile

r=Path.cwd();h=r/'sim/dilithium';q=r/'quartus/dilithium';rb=h/'reference_build';ev=r/'docs/dilithium_docs/evidence'
target=ev/'stage7c15_direct_memory_data_qualified.zip';side=target.with_suffix('.sha256')
assert not target.exists() and not side.exists(),'Create-only archive already exists'

def read(p):
    b=p.read_bytes();return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8',errors='replace')

for leaf,marker in [('native_runner.log','STAGE7C15_NATIVE_RUNNER_PASS'),('uvm_runner.log','STAGE7C15_UVM_RUNNER_PASS'),('quartus_runner.log','STAGE7C15_QUARTUS_RUNNER_PASS'),('cycle_audit.log','STAGE7C15_CYCLE_AUDIT_PASS')]:
    assert marker in read(h/('stage7c15_'+leaf)),leaf
foundation=read(h/'stage7c15_foundation.log')
for marker in ('LIGHTHD_PROCESS_DMA_PASS:cases64','SHARED_HINT_MODE_SWITCH_PASS:60','LIGHTHD_PROCESS_PHASE_PORT_PASS:2097152'):
    assert marker in foundation,marker
assert 'LIGHTHD_MEMORY_DIRECT_DATA_PASS:400000' in foundation
assert 'WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS' in read(q/'critical_full/retained_registers.rpt')
for name,digest in json.loads((rb/'stage7c15_source_hashes.json').read_text()).items():
    assert hashlib.sha256((r/name).read_bytes()).hexdigest()==digest,name

prior=sorted(ev.glob('*.sha256'))
for p in prior:
    digest,leaf=p.read_text().split();assert hashlib.sha256((ev/leaf).read_bytes()).hexdigest()==digest,p
    print('PRIOR_ARCHIVE_SHA_PASS:'+p.stem,flush=True)

paths=set()
for folder in ('src','tb/tb_dilithium','tb_uvm/tb_uvm_dilithium','tb_uvm/tb_uvm_ntt_LightHD','dilithium-sw-model/ref'):
    paths|={p.relative_to(r).as_posix() for p in (r/folder).rglob('*') if p.is_file() and p.suffix in ('.sv','.svh','.c','.h','.md')}
for folder in ('NIST/ML-DSA-keyGen-FIPS204','NIST/ML-DSA-sigGen-FIPS204','NIST/ML-DSA-sigVer-FIPS204'):
    paths|={p.relative_to(r).as_posix() for p in (r/folder).glob('*.json')}
for folder in ('FIPS204_NTT','FIPS204_SAMPLER'):
    paths|={p.relative_to(r).as_posix() for p in (r/folder).glob('*.py')}
paths|={p.relative_to(r).as_posix() for p in (r/'docs/dilithium_docs').glob('*.md')}
paths|={'AGENTS.md','README.md','sim/dilithium/.gitignore','sim/ntt/run_uvm.do','quartus/ntt/ntt.qsf','quartus/dilithium/dilithium.qsf'}
for leaf in ('README.md','dilithium_vectors.py','run.do','run_uvm.do','setup_cyclonev.tcl','report_uvm_coverage.tcl'):
    paths.add('sim/dilithium/'+leaf)
for p in h.glob('*'):
    if not p.is_file():continue
    current=p.name.startswith(('stage7c15','stage7_uvm')) and p.suffix in ('.txt','.csv','.rpt','.log','.ucdb')
    fixture=p.name.startswith(('stage2_','stage3_','stage4_','stage5_')) and p.suffix in ('.txt','.csv') and any(x in p.name for x in ('inputs','expected','samples','nist_sign_audit','nist_verify_audit'))
    if (current or fixture) and 'console' not in p.name and 'archive_create' not in p.name and 'archive_replay' not in p.name:paths.add(p.relative_to(r).as_posix())
for leaf in ('stage7c4_main_inputs.txt','stage7c4_main_outputs.txt','stage7c4_main_diagnostic_inputs.txt','stage7c4_main_diagnostic_outputs.txt','stage7c4_main_protocol_inputs.txt','stage7c4_main_protocol_outputs.txt','stage7c_ntt_inputs.txt','stage7c_ntt_expected.txt','stage7c1_ntt_dma_outputs.txt','stage7c4_hint_inputs.txt','stage7c4_hint_expected.txt','stage7c4_hint_outputs.txt'):
    paths.add('sim/dilithium/'+leaf)
for p in rb.glob('stage7c15*'):
    if p.is_file():paths.add(p.relative_to(r).as_posix())
    elif p.is_dir():paths|={v.relative_to(r).as_posix() for v in p.rglob('*') if v.is_file() and v.suffix not in ('.exe','.o')}
for leaf in ('stage7c14_metrics.json','stage7c14_area_inventory.json'):paths.add('sim/dilithium/reference_build/'+leaf)
for leaf in ('dilithium_full.qpf','dilithium_full.qsf','dilithium.sdc','report_full.tcl','README.md','stage7c15_compile.log','stage7c15_report_full.log'):
    paths.add('quartus/dilithium/'+leaf)
for corner in ('slow_85C','slow_0C','fast_85C','fast_0C'):
    for kind in ('fmax','setup','hold'):paths.add(f'quartus/dilithium/critical_full/{corner}_{kind}.rpt')
for leaf in ('retained_registers.rpt','mapped_register_names.rpt'):paths.add('quartus/dilithium/critical_full/'+leaf)
for p in (q/'output_full').glob('*'):
    if p.suffix in ('.rpt','.summary'):paths.add(p.relative_to(r).as_posix())

metrics=json.loads((rb/'stage7c15_metrics.json').read_text())
throughput=json.loads((rb/'stage7c15_throughput.json').read_text())
results=dict(stage='7C.15 direct memory data',source_qualified=True,routed=True,performance_accepted=False,
    placed_ALM_target_strictly_below=20000,target_met=metrics['area']['placed_ALMs']<20000,
    clock_constraint_ns=6.757,timing_closed=all(c['setup_ns']>=0 and c['hold_ns']>=0 for c in metrics['corners']),
    main_token='bac16c4aa3e10fbe65abba63247f2664604037a91d3c4561ccf367680ff93a93',
    uvm_token='47ee25992994c3376fb5c183c942033ef720d84aac29dcf7c6f98c7590ce6b4f',
    full_official_commands=210,official_output_bytes=744280,protocol_commands=88,protocol_checked_bytes=148704,
    checker_corruptions_rejected=90,main_uvm_checked=30,main_uvm_reset_aborts=3,functional_bins=[116,170],
    module_code_bins=[125267,167297],executable_package_code_bins=[12,107],code_bins=[125279,167404],
    cycles='EXACT C14:all full/protocol/UVM timing records',shared_codec_commands=60,shared_codec_observations=33125,
    process_port_comparisons=2097152,hard_DSPs=8,hard_preadder_count=4,hard_chainadder_count=4,
    metrics=metrics,throughput=throughput,prior_archives_verified=len(prior),
    rejected_architecture='No new shared64x64 controller context RAM/formatter',
    remaining_work='Published controller/memory reconstruction and under20000 ALM/148MHz targets remain open;C16 Process range/registered-operand candidate is outside this snapshot')
files={n:(r/n).read_bytes() for n in sorted(paths)}
files['RESULTS.json']=(json.dumps(results,indent=2)+'\n').encode()
manifest={n:hashlib.sha256(b).hexdigest() for n,b in files.items()}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for n,d in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==d,n
digest=hashlib.sha256(target.read_bytes()).hexdigest()
with side.open('x') as f:f.write(digest+'  '+target.name+'\n')
print(f'C15_ARCHIVE_CREATE_VERIFY_PASS:{len(files)}members/{target.stat().st_size}bytes/{len(prior)}prior pairs;SHA256 '+digest)
