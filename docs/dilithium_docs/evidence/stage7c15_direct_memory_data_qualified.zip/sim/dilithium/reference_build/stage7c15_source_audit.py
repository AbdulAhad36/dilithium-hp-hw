from pathlib import Path
import hashlib,json

r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c14_source_hashes.json').read_text())
frozen=json.loads((rb/'stage7c15_source_hashes.json').read_text())
assert old.keys()==frozen.keys()
for n,digest in frozen.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==digest,n
changed=[n for n in old if old[n]!=frozen[n]]
assert set(changed)=={'src/controller/memory/lighthd_memory_router.sv','tb/tb_dilithium/tb_lighthd_memory_switch.sv'},changed
result={'frozen_files':len(frozen),'unchanged_vs_C14':len(frozen)-len(changed),'changed':changed,
        'device_clock_QSF_arithmetic_reference_sources':'exact C14'}
(rb/'stage7c15_source_audit.json').write_text(json.dumps(result,indent=2)+'\n')
print('C15_SOURCE_AUDIT_PASS:'+str(len(frozen))+' frozen files unchanged;only router and its bench differ from C14')
