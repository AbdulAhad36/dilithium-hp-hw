onerror {quit -code 1 -f}
vlib sim/dilithium/work_fixed_ports_probe
vmap fixed_ports_probe sim/dilithium/work_fixed_ports_probe
vlog -sv -work fixed_ports_probe tmp/stage7c14_port_decode_probe.sv
vsim fixed_ports_probe.tb_process_fixed_ports
onfinish stop
run -all
quit -f
