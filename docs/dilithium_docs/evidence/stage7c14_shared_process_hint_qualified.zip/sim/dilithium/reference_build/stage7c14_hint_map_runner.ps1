$ErrorActionPreference='Stop'
foreach($kind in @('baseline','shared')){
 Set-Location -LiteralPath "D:/GitHub/dilithium-hp-hw/tmp/stage7c14_hint_map_$kind"
 & 'F:/altera/quartus/bin64/quartus_map.exe' probe -c probe --read_settings_files=on --write_settings_files=off *> map.log
 if($LASTEXITCODE -ne 0){throw "Hint prototype synthesis failed:$kind"}
 "HINT_PROTOTYPE_MAP_PASS:$kind"
}
