$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
# Wait only for the existing physical runner;never launch a duplicate build.
Wait-Process -Id 24088 -ErrorAction SilentlyContinue
if (-not (Select-String -LiteralPath sim/dilithium/stage7c14_quartus_runner.log -Pattern 'STAGE7C14_QUARTUS_RUNNER_PASS' -Quiet)) {
  throw 'C14 physical runner did not pass;do not report old PPA as current'
}
foreach ($reader in @('metrics','admission_registers','native_structure','shared_hint_registers','area_delta','throughput','cycle_audit')) {
  & 'C:/Python314/python.exe' "sim/dilithium/reference_build/stage7c14_${reader}.py" *> "sim/dilithium/stage7c14_${reader}_console.log"
  if ($LASTEXITCODE -ne 0) {throw "C14 result reader failed: $reader"}
}
foreach ($gate in @('lighthd_main_compare','lighthd_main_protocol_compare','uvm_check')) {
  & 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py $gate *> "sim/dilithium/stage7c14_final_${gate}.log"
  if ($LASTEXITCODE -ne 0) {throw "C14 final source freshness failed: $gate"}
}
'STAGE7C14_RESULT_COLLECTION_PASS'
