onerror {quit -code 1 -f}
vlib sim/dilithium/work_hint_switch_probe
vmap hint_switch_probe sim/dilithium/work_hint_switch_probe
vlog -sv -work hint_switch_probe src/controller/process/lighthd_hintpkg.sv src/controller/process/lighthd_hintunpkg.sv tmp/stage7c14_shared_hint_core_only.sv tmp/tb_stage7c14_shared_hint_switch.sv
vsim hint_switch_probe.tb_shared_hint_switch
onfinish stop
run -all
quit -f
