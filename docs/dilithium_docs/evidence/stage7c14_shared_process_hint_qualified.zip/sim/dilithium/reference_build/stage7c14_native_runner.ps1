$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
foreach ($gate in @('lighthd_prepare','lighthd_hint_prepare','lighthd_main_prepare','uvm_prepare')) {
  & 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py $gate *> "sim/dilithium/stage7c14_${gate}.log"
  if ($LASTEXITCODE -ne 0) {throw "Preparation failed: $gate"}
}
'STAGE7C14_PREPARE_PASS'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File sim/dilithium/reference_build/stage7c14_foundation_runner.ps1
if ($LASTEXITCODE -ne 0) {throw 'Foundation runner failed'}
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File sim/dilithium/reference_build/stage7c14_production_runner.ps1
if ($LASTEXITCODE -ne 0) {throw 'Production runner failed'}
'STAGE7C14_NATIVE_RUNNER_PASS'
