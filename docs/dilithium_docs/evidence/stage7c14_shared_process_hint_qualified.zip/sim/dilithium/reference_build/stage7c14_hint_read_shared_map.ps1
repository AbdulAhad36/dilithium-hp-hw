$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:/GitHub/dilithium-hp-hw/tmp/stage7c14_hint_map_shared'
& 'F:/altera/quartus/bin64/quartus_map.exe' probe -c probe --read_settings_files=on --write_settings_files=off *> map_read_shared.log
if($LASTEXITCODE -ne 0){throw 'Read-shared hint prototype synthesis failed'}
'HINT_READ_SHARED_PROTOTYPE_MAP_PASS'
