onerror {quit -code 1 -f}
vlib sim/dilithium/work_shared_hint_probe
vmap shared_hint_probe sim/dilithium/work_shared_hint_probe
vlog -sv -work shared_hint_probe tmp/stage7c14_shared_hint_probe.sv
quit -f
