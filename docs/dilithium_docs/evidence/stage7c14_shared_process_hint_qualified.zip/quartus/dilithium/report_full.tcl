# Whole-main baseline only. Run after compiling dilithium_full.qpf.
project_open dilithium_full -revision dilithium_full
if {[get_global_assignment -name TOP_LEVEL_ENTITY] ne "dilithium_fpga"} {error "Wrong production synthesis top"}
create_timing_netlist -model slow
read_sdc
file mkdir critical_full
set guard [open critical_full/retained_registers.rpt w]
# Read mapped register names once. Exact scope expressions prevent child
# FSMs/Keccak state arrays from inflating the four controller checks.
set mapped_registers {}
foreach_in_collection reg [get_registers *] {
  set name [get_node_info -name $reg]
  if {![string match {*~DUPLICATE*} $name]} {lappend mapped_registers $name}
}
set mapped_registers [lsort -unique $mapped_registers]
set names_file [open critical_full/mapped_register_names.rpt w]
foreach name $mapped_registers {puts $names_file $name}
close $names_file
foreach {label expression minimum} {
  main_state {^lighthd_dilithium:core\|state[.\[]} 1
  keygen_controller {\|lighthd_keygen:keygen_controller\|state[.\[]} 1
  sign_controller {\|lighthd_sign:sign_controller\|state[.\[]} 1
  verify_controller {\|lighthd_verify:verify_controller\|state[.\[]} 1
  dual_keccak_state {\|keccak_core:.*u_core\|state_array} 3200
  sampler_extract_secret {\|sampler:sample\|extract_secret_r} 64
  sampler_decode_secret {\|sampler:sample\|decode_secret_r} 64
  sampler_packed_secret {\|sampler:sample\|packed_secret_r} 64
  butterfly0 {\|lighthd_butterfly_fused:g_bf\[0\]\.u_bf\|keep_a_reg} 23
  butterfly1 {\|lighthd_butterfly_fused:g_bf\[1\]\.u_bf\|keep_a_reg} 23
  butterfly2 {\|lighthd_butterfly_fused:g_bf\[2\]\.u_bf\|keep_a_reg} 23
  butterfly3 {\|lighthd_butterfly_fused:g_bf\[3\]\.u_bf\|keep_a_reg} 23
  physical_port_owners {\|lighthd_memory_router:router\|owner_r} 16
  sampler_writer_context_ids {\|lighthd_sampler_writer:writer\|id_r} 32
  decoded_packet_payload {\|lighthd_load_decode:decoder\|packet[01]_r} 184
  decoded_packet_progress {\|lighthd_load_decode:decoder\|decoded_r} 7
  shared_process_coefficients {\|lighthd_process:.*\|coefficient0_r} 92
  shared_hint_indices {\|lighthd_hint_codec:.*\|indices_r} 640
  shared_hint_counts {\|lighthd_hint_codec:.*\|counts_r} 64
  secret_key_header {\|lighthd_sign_input:.*\|header_r} 1024
} {
  set names {}
  foreach name $mapped_registers {
    if {[regexp $expression $name]} {lappend names $name}
  }
  set count [llength $names]
  puts $guard "$label:$count original mapped register bits; minimum:$minimum"
  if {$count<$minimum} {close $guard;error "Missing retained registers for $label; inspect actual mapped names/features"}
}
puts $guard {WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS}
close $guard
foreach corner {{slow 85} {slow 0} {fast 85} {fast 0}} {
  lassign $corner model temperature
  set_operating_conditions -model $model -temperature $temperature -voltage 1100
  update_timing_netlist
  set prefix critical_full/${model}_${temperature}C
  report_timing -setup -npaths 5 -detail full_path -file ${prefix}_setup.rpt
  report_timing -hold -npaths 5 -detail full_path -file ${prefix}_hold.rpt
  report_clock_fmax_summary -file ${prefix}_fmax.rpt
}
delete_timing_netlist
project_close
