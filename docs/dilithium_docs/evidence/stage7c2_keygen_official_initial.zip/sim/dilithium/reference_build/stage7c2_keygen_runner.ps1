Set-Location -LiteralPath 'D:/GitHub/dilithium-hp-hw'
'START full75 compact KeyGen' | Set-Content sim/dilithium/stage7c2_keygen_status.log
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l sim/dilithium/stage7c2_keygen_full.log -do sim/dilithium/reference_build/stage7c2_keygen_full.do *> sim/dilithium/stage7c2_keygen_full_console.log
$nativeCode=$LASTEXITCODE
"SIM_EXIT=$nativeCode" | Add-Content sim/dilithium/stage7c2_keygen_status.log
if($nativeCode -ne 0){exit $nativeCode}
& python sim/dilithium/dilithium_vectors.py lighthd_keygen_compare *> sim/dilithium/stage7c2_keygen_compare.log
$compareCode=$LASTEXITCODE
"COMPARE_EXIT=$compareCode" | Add-Content sim/dilithium/stage7c2_keygen_status.log
if($compareCode -ne 0){exit $compareCode}
'COMPLETE full75 compact KeyGen capture+published comparison' | Add-Content sim/dilithium/stage7c2_keygen_status.log
