`timescale 1ns/1ps
module tb_lighthd_keygen;
  import lighthd_pkg::*;
  parameter bit DIAGNOSTIC=0;
  logic clk=0;always #5 clk=~clk;
  logic rst=1,start_valid_i=0,start_ready_o;
  logic [1:0] start_param_i=0;logic [15:0] start_id_i=0;
  logic [255:0] start_seed_i=0;
  request_t service_o;response_t service_i;
  logic key_valid_o,key_ready_i,key_type_o,key_last_o;
  logic [63:0] key_data_o;logic [3:0] key_bytes_o;
  logic [9:0] key_index_o;logic [15:0] key_id_o;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o;
  logic [15:0] done_id_o;logic fault_o,datapath_fault;
  lighthd_keygen controller(.*);
  lighthd_datapath datapath(.clk(clk),.rst(rst),.service_i(service_o),.service_o(service_i),.fault_o(datapath_fault));
  int cycles=0,current=-1,completed=0,key_words=0,overlap_cycles=0,max_ring=0;
  int input_file,output_file,n,serials[75],levels[75],ids[75];
  logic [255:0] seeds[75];string token;
  logic held=0;logic [95:0] held_word;
  assign key_ready_i=!rst && cycles%13>3;
  always @(negedge clk)cycles++;
  always @(posedge clk)if(rst)held=0;else begin
    int occupancy;occupancy=$countones(controller.a_reserved_r);
    if(occupancy>max_ring)max_ring=occupancy;
    if(datapath.polynomial.core_busy && |service_i.sample.active)overlap_cycles++;
    if(DIAGNOSTIC && service_o.sample.valid && service_i.sample.ready)$display("KG_SAMPLE_LAUNCH:id%0d state%0d kind%0d idx%0d batch%0d",service_o.sample.id,controller.state,controller.current.kind,controller.current.index,controller.batch_size_r);
    if(DIAGNOSTIC && service_i.sample.done_valid && service_o.sample.done_ready)$display("KG_SAMPLE_DONE:id%0d code%0d expected%0d/%0d done%0b state%0d",service_i.sample.done_id,service_i.sample.done_code,controller.descriptor_id(controller.descriptor_r[0],controller.id_r,controller.l_r),controller.descriptor_id(controller.descriptor_r[1],controller.id_r,controller.l_r),controller.batch_done_r,controller.state);
    if(DIAGNOSTIC && service_i.raw.output_valid && service_o.raw.output_ready)$display("KG_RAW:id%0d want%0d count%0d state%0d",service_i.raw.output_id,service_o.raw.id,controller.raw_count_r,controller.state);
    if(held)begin
      if(!key_valid_o || {key_data_o,key_bytes_o,key_type_o,key_last_o,key_index_o,key_id_o}!==held_word)
        $fatal(1,"Compact KeyGen key stream changed under backpressure");
    end
    held=key_valid_o && !key_ready_i;
    held_word={key_data_o,key_bytes_o,key_type_o,key_last_o,key_index_o,key_id_o};
    if(key_valid_o && key_ready_i)begin
      if(key_id_o!=start_id_i || key_bytes_o!=8)$fatal(1,"Compact key identity/byte count");
      $fdisplay(output_file,"K %0d %0d %016h %0d %0d",key_type_o,key_index_o,key_data_o,key_bytes_o,key_last_o);key_words++;
    end
    if(fault_o || datapath_fault)$fatal(1,"Compact KeyGen child fault case%0d state%0d producer%0d ntt%0d process%0d sample%0d",
      current,controller.state,controller.producer,service_i.ntt.done_code,service_i.process.done_code,service_i.sample.done_code);
  end
  initial begin
    int watchdog,start_cycle;
    input_file=$fopen("sim/dilithium/stage7c_keygen_inputs.txt","r");
    output_file=$fopen(DIAGNOSTIC?"sim/dilithium/stage7c2_keygen_diagnostic_outputs.txt":"sim/dilithium/stage7c2_keygen_outputs.txt","w");
    if(!input_file || !output_file || $fscanf(input_file,"%s %d",token,n)!=2 || n!=75)$fatal(1,"Prepare compact KeyGen fixtures");
    for(int i=0;i<n;i++)if($fscanf(input_file,"%d %d %d %h",serials[i],levels[i],ids[i],seeds[i])!=4)$fatal(1,"Compact KeyGen seed records");
    $fclose(input_file);$fdisplay(output_file,"%s %0d",token,DIAGNOSTIC?3:75);
    repeat(3)@(negedge clk);rst=0;
    for(int i=0;i<n;i++)begin
      if(DIAGNOSTIC && i!=0 && i!=25 && i!=50)continue;
      @(negedge clk);current=i;start_param_i=2'(levels[i]);start_id_i=16'(ids[i]);start_seed_i=seeds[i];
      start_valid_i=1;
      #1;if(!start_ready_o)$fatal(1,"Compact KeyGen not ready");
      $fdisplay(output_file,"J %0d %0d %0d",i,start_param_i,start_id_i);start_cycle=cycles;
      @(negedge clk);start_valid_i=0;watchdog=0;
      while(!done_valid_o)begin
        @(negedge clk);
        if(watchdog++>100000)$fatal(1,"Compact KeyGen timeout case%0d state%0d producer%0d s1next%0d transform%0d row%0d col%0d Aready%h reserved%h s2%h",
          i,controller.state,controller.producer,controller.s1_next_r,controller.transform_r,controller.row_r,
          controller.column_r,controller.a_ready_r,controller.a_reserved_r,controller.s2_ready_r);
      end
      if(done_code_o!=0 || done_id_o!=start_id_i)$fatal(1,"Compact KeyGen completion identity/code code%0d state%0d producer%0d fault%0d sampleFault%0d nttstate%0d nttcode%0d inputs%0d outputs%0d procCode%0d",
        done_code_o,controller.state,controller.producer,fault_o,service_i.sample.fault,datapath.polynomial.state,
        service_i.ntt.done_code,datapath.polynomial.inputs_r,datapath.polynomial.outputs_r,service_i.process.done_code);
      $fdisplay(output_file,"D %0d %0d",done_code_o,cycles-start_cycle);
      $display("COMPACT_KEYGEN_CASE_PASS:case%0d level%0d cycles%0d",i,levels[i],cycles-start_cycle);
      repeat(3)begin @(negedge clk);if(!done_valid_o || done_code_o!=0)$fatal(1,"Compact completion unstable");end
      done_ready_i=1;@(negedge clk);done_ready_i=0;completed++;
    end
    if(overlap_cycles==0 || max_ring>9)$fatal(1,"Compact schedule overlap/ring gate");
    $fdisplay(output_file,"F %0d",completed);$fclose(output_file);
    $display("LIGHTHD_KEYGEN_CAPTURE_PASS:%0d keypairs/%0d words/overlap_cycles%0d/peak_A_ring%0d;independent NIST comparison required",completed,key_words,overlap_cycles,max_ring);
    $finish;
  end
  initial begin #100000000;$fatal(1,"Compact KeyGen global watchdog");end
endmodule
