# Dilithium specification

## Status and supported scope

Stage1 imported and revalidated the accepted Keccak package on branch
`integration`. The sampler is already present. No connected Keccak/sampler
datapath, NTT import, controller or polynomial memory is implemented yet.
The full-operation algorithm scope is awaiting the user's decision between
final ML-DSA variants and legacy Dilithium variants. This does not block
standalone Keccak relocation.

See [DILITHIUM_PLAN.md](DILITHIUM_PLAN.md) for the common roadmap. All integration
milestones update this universal documentation set.

## Imported source provenance

| Component | Source | Destination | Changes |
|---|---|---|---|
| Sampler | sampler_v1 accepted Stage4.9r; Stage5 commit e1b9c84 | src/sampler, existing tb_uvm/sim/quartus/sampler assets | None during Keccak import |
| Keccak | keccak_v2 at fe54a782e3df9ed684dc960b0067b39ce323289d | src/keccak; tb_uvm/tb_uvm_keccak_v2 | RTL/UVM byte-identical to source snapshot |
| Keccak simulation | Same commit, sim/ | sim/keccak/ | Launcher discovery, root/RTL/project paths and Python defaults relocated; main run sets local working directory |
| Keccak synthesis | Same commit, quartus/dual_interleaved/ | quartus/keccak/ | QSF source paths only; original settings/SDC preserved |
| Keccak vectors/docs | Same commit, NIST/ and docs/keccak_docs/ | Same paths | Original published vector files and historical module documentation preserved |
| NTT | Planned ntt_v2 accepted snapshot, not imported | src/ntt and corresponding standalone assets | Pending its integration stage |

Imports used create-only writes and included no historical experiment trees,
generated synthesis databases or shared-template overwrite. Standalone test
tops named `tb_top` stay in separate simulator work libraries; the eventual
full-design testbench must not compile all standalone tops into one library.

## Current engine contracts

| Interface | Existing behavior | Integration obligation |
|---|---|---|
| Keccak request | ready/valid; actual assigned core on request_core_o; 1-bit SHAKE128/256 mode; 16-bit message/XOF byte lengths | Capture the actual core on acceptance and reserve its descriptor/destination |
| Keccak absorption | Shared64-bit ready/valid stream; message length controls final valid bytes | Feed exactly the specified message in little-endian byte order; retain descriptor while feeding |
| Keccak output | Shared128-bit ready/valid,5-bit valid-byte count and1-bit core tag | Preserve data/bytes/tag while stalled and bind each core to the correct sampler job |
| Keccak continuous mode | output_len_i=0; stop_i sampled in SQUEEZE | Manage stop, outstanding output and busy/done before reuse; do not treat a rate-block boundary as stream end |
| Sampler job | ready/valid; core1 bit,ID16 bits,mode2 bits,param2 bits | Establish matching context before accepting that Keccak stream |
| Sampler input |128-bit ready/valid,1..16 contiguous low valid bytes,core tag,last | Pass actual valid bytes; continuous SHAKE input_last stays0; bounded end needs explicit controller accounting |
| Sampler output |23-bit canonical residue,core/ID/index/last; one accepted coefficient per clock | Route by job to the correct destination; output alone does not identify memory ownership lifetime |
| Sampler completion | source_stop_o per context and checked status; success after256 outputs | Stop/dispose upstream surplus,handle error/abort and invalidate partial destinations |

The sampler's internal64-bit chunk issue remains unchanged. No native128
sampling or integrated throughput claim follows from this connection plan.
Matrix A uses SHAKE128; secret/mask/challenge expansion uses SHAKE256. Their
seed/nonce/message constructions must match the chosen algorithm/version.
Derive the Keccak mode explicitly from the sampling operation:the sampler's
2-bit mode encoding must not be truncated and wired to the1-bit SHAKE selector.

## Stop/drain and context reuse: required design work

Source inspection found that Keccak stop can suppress a core's output-valid,
while the wrapper retains a selected output under backpressure. Therefore the
future adapter must not simply wire sampler source_stop directly to Keccak stop
and assume all outstanding offers disappear safely.

Define and test a drain/discard sequence that releases any held wrapper output,
preserves the peer job,stops the completed stream,and waits for core completion.
Do not reuse a context until both sampler ownership and Keccak/adapter tokens
from the old job are retired. Exact buffer sizing and state transitions will
be designed and independently tested in Stage2;no adapter implementation or
proof of this sequence is claimed here.

## Clock/reset and pending major decisions

Keccak uses an active-high asynchronous control reset; sampler reset is
active-high synchronous. Start with a common clock and coordinated top-level
reset,then test release/cancellation semantics explicitly. FPGA reset input
conditioning belongs to the top-level design when specified.

Standalone Keccak constraint:6.757 ns. Standalone sampler constraint:6.500 ns.
Neither sets the future full-design clock automatically. Confirm the initial
integrated clock target,full-operation algorithm scope,and polynomial memory
capacity/banking with the user before committing to those architecture choices.

Keccak message/XOF length fields are16 bits. The current fixed-length command
therefore represents at most65535 input bytes;continuous XOF uses output_len=0.
Do not advertise unrestricted full-operation message lengths without specifying
and testing the hashing interface. Supporting longer streamed messages would
require a deliberate interface/controller decision;hashing separate chunks as
independent SHAKE requests would not implement one continued hash operation.

## Stage1 relocation verification — 2026-10-19

| Check | Observed result |
|---|---|
| Source identity | All12 RTL and13 UVM files byte-identical to the selected Keccak commit |
| Existing sampler | No source/UVM/Quartus changes during this import |
| Full Keccak source regression | COMPLETE_KECCAK_SUITE_PASS:904 two-core UVM transactions plus all dual-interleaved regressions |
| Source/NIST UVM errors and fatals | Zero in both runs |
| Published NIST suite |3182 cases from six short/long/variable-output files;both standalone cores captured |
| Separate Python byte comparison |6364/6364 outputs match published expected values;3182/3182 per core |
| Standalone Quartus compile | Full compilation successful with original RTL/settings and relocated source paths |
| RTL package/module names | No collisions with the current sampler source set |

The NIST flow compares published bytes directly;it does not generate expected
SHAKE outputs from the DUT or reuse the SV golden model. Capture completion
alone is not the verdict. The full wrapper regressions check dispatch/routing/
interleaving separately from the published-vector standalone-core capture.

### Fresh standalone Keccak implementation

| Metric | Measured value |
|---|---:|
| Device | Cyclone V 5CGXFC7C7F23C8 |
| Tool | Quartus25.1std Lite |
| Actual placed ALMs |8058|
| Registers |3501|
| Combinational ALUTs |11860|
| M10K / DSP |0 /0|
| Clock period |6.757ns|
| Slow85 / Slow0 Fmax |149.63 /152.88MHz|
| Worst setup / hold |+0.074 /+0.166ns|
| Setup/hold TNS |0 at all four corners|
| Minimum pulse-width slack |Positive at all four corners;minimum+2.442ns|

Area uses the report row **[A] ALMs used in final placement**. Historical7581
figures in imported module docs refer to the needed estimate in this reproduced
fit. The current area record is8058 placed ALMs. RTL/UVM and synthesis settings
are unchanged;do not interpret this reporting correction as added integration
logic or a source redesign. Data pins remain virtual with the inherited I/O
exceptions;these results establish standalone internal timing only.

### Reproduce and inspect

From repository root:`python sim/keccak/nist_shake.py prepare`.
From sim/ in fresh Questa sessions,run `do keccak/run.do` for the full source
regression and `do keccak/run_nist.do` for the NIST capture. Then run
`python sim/keccak/nist_shake.py compare` from repository root.
Open `quartus/keccak/keccak_dual_interleaved.qpf` and start full compilation in
Quartus GUI. Scripts and README files contain the relocated paths.

Live reports:sim/keccak/import_uvm.log,import_nist.log,import_nist_compare.log;
quartus/keccak/import_compile.log and output_files/*.fit.rpt/*.sta.rpt/*.sta.summary.
Frozen milestone evidence:evidence/keccak_import.zip with SHA256 sidecar;
the archive includes the source/destination hash manifest and selected reports.

No relocated post-synthesis/post-fit simulation or connected-system result is
claimed. Standalone netlist launchers are imported for later use with fresh
exports. The next work is Stage2 adapter design and seeded polynomial checking.
