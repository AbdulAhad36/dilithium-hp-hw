# Dilithium integration

This is the universal documentation set for the `integration` branch. Add each
integration milestone to these documents as the complete design grows.

| Document | Purpose |
|---|---|
| [DILITHIUM_PLAN.md](DILITHIUM_PLAN.md) | Agreed layout,stages,decision gates and next work |
| [SPECIFICATION.md](SPECIFICATION.md) | Imported source provenance,current interfaces and relocation results |

Architecture,process-flow,memory,throughput,reference-verification,pin and full
verification/coverage documents will be created here when their implementation
work begins. Do not create a separate documentation suite for each module pair.

Current runnable projects are standalone:

- Keccak: [simulation](../../sim/keccak/README.md),
  [Quartus](../../quartus/keccak/README.md).
- Sampler: [simulation](../../sim/sampler/README.md),
  [Quartus](../../quartus/sampler/README.md).

There is no connected Dilithium RTL/testbench/synthesis project yet. Initial
integration will connect real Keccak output to the sampler with explicit
job/context ownership,backpressure and stop/drain handling. NTT and polynomial
memory follow the shared roadmap. Standalone metrics are not system metrics.
