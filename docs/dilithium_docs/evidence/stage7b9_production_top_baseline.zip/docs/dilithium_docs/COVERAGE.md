# Dilithium UVM coverage

## Active Stage7B.9 production scope

The same main33 scenarios now run through the real dilithium_fpga wrapper.
The driver uses only production pins;legacy debug request stimulus is removed.
Pool occupancy,owners and legacy full-key-mode guard flags are internal
read-only probes. The9 groups/22 coverpoints/8 crosses/170 defined bins are
unchanged;there were no separate debug-request bins to remove or manufacture.
Legacy raw-core debug tests remain in the focused benches. DUT code coverage
includes /tb_top/dut and its wrapped core,plus the service package once.
The optional old-memory reference remains outside that DUT hierarchy.
Fresh main33 passes30 checked completions/3 reset aborts with zero UVM errors
or fatals. Functional121/170=71.18%;modules316708/397445,package14/14,overall
316722/397459=79.69%. The same-token corrupted-key run rejects byte0 with
zero checked outcomes and0/170 functional credit. All30 completion timestamps
and every latency CSV field match7B.7. The external memory comparator matches
9318041 cycles,2579302 writes and858082 reads. These are current production-top
source results;physical routing now passes,but the148MHz setup target fails.
Retained-register checks pass;timing/area are recorded in THROUGHPUT.md.
Earlier results below retain
their raw-core interface scope. The extra wrapper code counters change the
code denominator;they do not add functional tests or bins.

## Stage7B.7 source results

The aligned decoder candidate passes the existing383 focused scenarios,
705010 independent decoded-value checks and37 checker corruptions. Its
old/new decoder comparator matches1206629 cycles,including348 headers and
374 completions. These are focused preservation checks,not main-UVM coverage
credit. Main33 passes30 completions/3 reset aborts,zero errors/fatals.
Functional121/170=71.18%;modules315810/396415;package14/14;overall315824/396429
=79.67%. The current-token corrupted-key gate rejects byte0 with zero checked
outcomes/0of170 bins. Every completed-case timing/latency CSV field equals7B.6.
Routing fails;no accepted physical PPA. A fitter-only trial will reuse the
exact qualified RTL. The earlier results below remain historical.

## Stage7B.6 source results and verification scope

All33 main-UVM scenarios pass:30 checked completions,three reset aborts,
zero errors/fatals. Functional121/170=71.18%;DUT modules315685/396290,
shared package14/14,overall315699/396304=79.66%. The external memory comparator
matches over9318041 active cycles,2579302 scalar writes and858082 packed
reads. These are trace comparisons,not a formal equivalence proof.
All30 completion timestamps and every latency/wait/occupancy/engine-cycle
CSV field equal7B.4. The current-token corrupted-key gate rejects byte0
with zero checked outcomes and0/170 functional credit. Positive files retain
their separate prefix. Full physical fit remains pending.

The memory metadata candidate adds a verification-only copy of the prior
memory controller and an external pin comparator. Enable it with
`set DILITHIUM_MEMORY_EQUIVALENCE 1` before the usual main UVM launcher.
Ready,status,occupancy,fault and response-valid must match every checked
cycle;data,metadata and error must match whenever a response is valid.
The reference is outside /tb_top/dut and is not part of DUT coverage.

The focused memory unit passes all64 slots,16647 scalar writes and4418 reads,
including two interleaved writers,read/rewrite admission,untouched-word
watermarks,cancel,reset and fault behavior. These counts are unit evidence,
not extra main-UVM bins. The focused59 helper cases and118 checker corruptions
also pass freshly. Their results are not merged into the main-UVM coverage.
The7B.4 results below remain historical for the prior implementation.

## Latest Stage7B.4 source results

All33 scenarios pass:30 checked completions,3 reset aborts and zero UVM
errors/fatals. Functional121/170=71.18%;DUT modules315612/396220,shared
package14/14,overall315626/396234=79.66%. The model/stimulus remain the same;
implementation code-bin changes are not extra functional verification.
Separate focused tests pass256 scan scenarios and59 whole helper cases;
118 checker corruptions reject. Their results are not merged into this UVM
coverage. Physical fit and timing are still pending.

## Active Stage7B.2 reporting scope

The launcher now instruments dilithium_service_pkg.sv as well as DUT modules.
report_uvm_coverage.tcl prints module counters and explicitly requested
service-package DU counters separately,then sums them once for overall DUT
code coverage. This includes the new executable handle_mask/handle_count
functions; UVM/reference code and type-only packages remain excluded.
The separate package report is stage7_uvm_package_code.rpt. The full33-case
campaign passes30 checked completions/3 resets,zero errors. Functional bins
stay121/170=71.18%. DUT modules reach315817/397721; executable package14/14;
overall315831/397735=79.41%. Earlier module-only results below retain their
different scope; no percentage is presented as verification closure.

The same-token corrupted-key run also executes14/14 package code items,yet
fails the first byte comparison and earns0/170 functional bins. This is a
concrete example of why executed code alone does not prove a correct result.

## Stage7A foundation and counting rules

Stage7B.1 reruns all33 scenarios with30 checked completions/3 resets and zero
errors. Its functional result stays121/170=71.18%; raw enabled DUT module
code is316363/399028=79.28%. The changed instrumentation scope and denominator
are not a verification gain. See the package-function limitation below.
Its separate59-case helper gate and118/118 checker faults pass; those are not
merged into main coverage. All30 completion timestamps match Stage7A exactly.

Completed first campaign: **30 checked completions and 3 reset aborts**, with
zero UVM errors/fatals. Functional coverage is **121/170 = 71.18%**. Raw DUT
code coverage is **314371/393251 = 79.94%**:

| Enabled kind | Hit / defined |
|---|---:|
|Statements|6759 / 7671|
|Branches|4581 / 5564|
|Conditions|994 / 2117|
|Expressions|1949 / 2946|
|Toggles|300088 / 374953|

No FSM counters were inferred in this run. Evidence is the completed
stage7a_uvm_diagnostic.log and copied stage7a_positive UCDB/code/functional
reports. All 33 scenarios ran; IterationLimit=200 is a delta-cycle limit.
The 30 checked outcomes include four keypairs (21216 bytes), seven signatures
(23132 bytes), thirteen Verify verdicts (4 valid/9 invalid), and six expected
command errors. The three reset aborts each have a checked recovery.
An accidental second positive invocation was stopped and overwrote the CSVs;
this checkpoint therefore makes no CSV latency claim. Regenerate those with
the next complete campaign. Its reports are not added to the completed run.

The actual full-operation main is instantiated in
`tb_uvm/tb_uvm_dilithium/tb_top.sv`: FULL_KEYGEN=1, ENABLE_SIGN=1,
ENABLE_VERIFY=1. This is a UVM agent with a sequencer, driver and independent
pin monitor, an output scoreboard, and a separate coverage subscriber.
The earlier focused integration benches do not supply these coverage numbers.

```mermaid
flowchart LR
  N["Pinned NIST files"] --> P["Python uvm_prepare"]
  P --> I["Input file"]
  P --> E["Expected file"]
  I --> S["UVM sequence + driver"]
  S --> D["Actual dilithium RTL"]
  D --> M["Pin monitor"]
  M --> B["Scoreboard: bytes + status + cleanup"]
  E --> B
  B --> C["Qualified functional coverage"]
  B --> W["Checked witness + latency CSV"]
  D --> Q["Questa code instrumentation"]
```

The input and expected files are separate. The driver reads original inputs;
the scoreboard alone reads the consolidated published expected outputs.
`dilithium_scoreboard::write` checks every accepted input byte and output
byte, IDs, word indices, valid-byte count, last flags, result codes/verdicts
and retry-counter consistency. Normal Verify equation cases require all
three frames; structural-invalid cases may stop after the checked signature
prefix. Results are held until the monitor observes retirement with an empty
memory pool. Only then does the scoreboard publish a coverage-qualified event.

Transport-tail observations accumulate privately during work. They are sampled
only after the corresponding operation has passed its result and retirement
checks. Expected command errors credit outcome coverage, not successful-operation
groups. A reset abort earns no success bins; reset/recovery coverage waits for
the subsequent independently checked successful command. No input stimulus
alone credits successful functionality.

| Group | What is observed and checked before sampling |
|---|---|
|operation_cg|Actual operation and parameter after checked completion/cleanup; all nine combinations|
|command_cg|Accepted ID, context and message sizes matching the original input fixture|
|outcome_cg|Checked successful, invalid-signature or expected-error outcome|
|transport_cg|Actual input blocking, output stalls and held completion observed at the pins|
|tail_cg|Actual accepted word sizes and checked input/output bytes; unused output tails must be zero|
|retry_cg|Published signature match and attempts/rejections/nonce consistency|
|sequence_cg|Ordered pairs of independently checked retired commands|
|memory_cg|Observed peak reserved regions, with all regions empty at retirement|
|reset_cg|Observed active-command reset followed by a checked recovery|

The initial model has **9 groups, 22 coverpoints, 8 crosses and 170 defined
bins**. Legal unhit cases remain visible. Fixed eight-byte encoded key words
and the absence of an encoded Verify output have explicit structural exclusions.
Unsupported prehash/external-mu/internal-message APIs are separately audited;
they are not claimed as covered functionality.

The monitor also checks single services ownership, refusal while busy/held
done, stable stalled inputs/outputs, unknown control and payload values,
no exposed debug traffic in full-key mode, unexpected faults and watchdogs.
These assertions are checks, not additional automatically covered bins.

## Running and viewing results

```powershell
# Repository root; regenerate after changing source/testbench/launcher.
python sim/dilithium/dilithium_vectors.py uvm_prepare
```

```tcl
# Questa GUI Transcript, cwd sim/
do dilithium/run_uvm.do
```

The GUI opens the Wave, Covergroups and code-analysis panes. At completion,
the same Questa Transcript prints raw functional hits/defined bins, a DUT
code summary and the overall raw DUT code total. Files under sim/dilithium/:
stage7_uvm.ucdb, stage7_uvm.wlf, stage7_uvm_functional.rpt,
stage7_uvm_code.rpt, stage7_uvm_checked.csv and stage7_uvm_latency.csv.
The CSV witness identifies each checked case and source fingerprint.

RTL modules compile with statement, branch, condition, expression, toggle
and FSM instrumentation. Report only counters enabled and present in the
actual DUT hierarchy; package/type files and the UVM environment are not added
to the DUT total. Overall code coverage is summed hits / summed enabled bins,
not a mean of percentages. Toggle bins may dominate. FSM state/transition
coverage exists only where Questa actually infers an FSM.

Stage7B.1 introduced executable checked_handle_set code in the service package.
That launcher excluded packages from instrumentation, so its raw DUT
module percentage did not include that function. The separate equivalence
gate verifies its behavior but is not merged into UVM coverage. Do not claim
an executable-RTL coverage improvement merely because code moved out of the
instrumented modules. Stage7B.2 resolves that reporting gap by instrumenting
the replacement handle_mask/handle_count functions and explicitly adding
their package counters once, as described above.

The separate instrumented equivalence run does report the package explicitly
using vcover report -package=dilithium_service_pkg: 9/9 statements, 4/4 branches
and 3/3 focused condition items. These are unit-only results over45841 cases,
not extra main-UVM credits and not a substitute for broader system stimulus.

The negative gate sets DILITHIUM_INJECT_BAD_KEY=1 before the same launcher.
It changes the first observed key byte before the scoreboard, requiring a
specific byte-mismatch failure, zero checked completions and 0/170 functional
bins. A compile/startup failure does not qualify as a successful negative gate.

## Remaining campaign work

This is the first whole-main UVM checkpoint, not verification closure. Expand
input framing errors, child error/publication faults, reset phases during
sampling/NTT/packing/held outputs, all ordered operation pairs, ID wrap/reuse,
message/context/tail boundaries, long retry/rejection paths and varied stalls.
Add checked internal ownership, bank hazards and detailed service/NTT phase
observations as these tests are brought into the main UVM. Keep the broader
feature list in INTEGRATION_VERIFICATION_TESTPLAN.md. Classify code misses
from the actual report before proposing RTL changes or exclusions. Do not
invent unreachable bins or suppress hits to meet a requested percentage.
