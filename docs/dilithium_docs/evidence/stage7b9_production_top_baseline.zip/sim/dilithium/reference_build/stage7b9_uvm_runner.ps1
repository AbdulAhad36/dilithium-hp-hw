$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
$progressFile = 'sim/dilithium/stage7b9_uvm_runner.log'
'START main UVM with memory equivalence' | Set-Content -LiteralPath $progressFile
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l sim/dilithium/stage7b9_main_uvm.log -do 'set DILITHIUM_MEMORY_EQUIVALENCE 1; do sim/dilithium/run_uvm.do; quit -f' *> sim/dilithium/stage7b9_main_uvm_console.log
if ($LASTEXITCODE -ne 0) { 'FAIL positive main UVM' | Add-Content -LiteralPath $progressFile; exit 1 }
'PASS positive main UVM; START same-token corrupted-key gate' | Add-Content -LiteralPath $progressFile
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l sim/dilithium/stage7b9_negative.log -do 'set DILITHIUM_MEMORY_EQUIVALENCE 1; set DILITHIUM_INJECT_BAD_KEY 1; do sim/dilithium/run_uvm.do; quit -f' *> sim/dilithium/stage7b9_negative_console.log
$negativeExit = $LASTEXITCODE
"NEGATIVE_EXIT:$negativeExit; inspect specific mismatch and zero-credit evidence" | Add-Content -LiteralPath $progressFile
if ($negativeExit -ne 1) { exit 1 }
'RUNNER_COMPLETE; negative evidence requires audit' | Add-Content -LiteralPath $progressFile
