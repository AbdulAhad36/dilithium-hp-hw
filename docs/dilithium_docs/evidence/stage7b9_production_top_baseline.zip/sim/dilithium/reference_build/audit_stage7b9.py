"""Audit completed production-top captures; never converts a partial run to PASS."""
import csv
import io
import json
import re
from pathlib import Path
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[3]
SIM = ROOT / 'sim/dilithium'
TOKEN = '1011eeaaaa7947e5ef646419987d3dcbd3c0ec62f2c96fd5ef7a97cd931489e6'


def require(condition, message):
    if not condition:
        raise SystemExit('STAGE7B9_AUDIT_INCOMPLETE_OR_FAIL: ' + message)


def rows(data):
    return list(csv.DictReader(io.StringIO(data)))


positive = (SIM / 'stage7b9_main_uvm.log').read_text(errors='replace')
negative_path = SIM / 'stage7b9_negative.log'
require(negative_path.exists(), 'negative capture not completed')
negative = negative_path.read_text(errors='replace')
require('STAGE7A_UVM_PASS' in positive and '30 checked completions/3 reset aborts' in positive,
        'main 33-case PASS marker missing')
require(re.search(r'UVM_ERROR\s*:\s*0', positive) and
        re.search(r'UVM_FATAL\s*:\s*0', positive), 'main UVM severity counts')
require('MEMORY_METADATA_TRACE_MATCH:cycles9318041' in positive,
        'full memory trace comparator did not complete')
require('byte mismatch index0; coverage credit withheld' in negative,
        'negative did not reject the intended corrupted key byte')
require(re.search(r'OVERALL FUNCTIONAL COVERAGE .*: 0 / 170 =', negative),
        'negative earned coverage or coverage report missing')
require(rows((SIM / 'stage7_uvm_negative_checked.csv').read_text()) == [],
        'negative has checked outcomes')
checked = rows((SIM / 'stage7_uvm_checked.csv').read_text())
require(len(checked) == 30 and all(row['source_token'] == TOKEN for row in checked),
        '30 current-token checked completions required')

latency = rows((SIM / 'stage7_uvm_latency.csv').read_text())
with ZipFile(ROOT / 'docs/dilithium_docs/evidence/stage7b7_aligned_decoder_route_failure.zip') as baseline:
    prior_latency = rows(baseline.read('sim/dilithium/stage7_uvm_latency.csv').decode())
    prior_log = baseline.read('sim/dilithium/stage7b7_main_uvm.log').decode()
require(len(latency) == 30 and latency == prior_latency,
        'latency/wait/occupancy/engine CSV fields differ from Stage7B.7')
timestamp_pattern = r'@ (\d+):.*\[CHECKED\] case(\d+) '
require(len(re.findall(timestamp_pattern, positive)) == 30 and
        re.findall(timestamp_pattern, positive) == re.findall(timestamp_pattern, prior_log),
        'completion timestamps differ from Stage7B.7')

coverage = {}
for name, pattern in {
    'functional': r'OVERALL FUNCTIONAL COVERAGE .*: (\d+) / (\d+) =',
    'module_code': r'DUT MODULE CODE COVERAGE .*: (\d+) / (\d+) =',
    'package_code': r'SHARED DUT PACKAGE CODE COVERAGE: (\d+) / (\d+) =',
    'overall_code': r'OVERALL DUT CODE COVERAGE .*: (\d+) / (\d+) =',
}.items():
    match = re.search(pattern, positive)
    require(match is not None, name + ' coverage report missing')
    coverage[name] = [int(value) for value in match.groups()]
require(coverage['functional'] == [121, 170], 'functional bin credit changed')
require(coverage['overall_code'] == [sum(pair) for pair in
        zip(coverage['module_code'], coverage['package_code'])], 'code count arithmetic')
print('STAGE7B9_SOURCE_QUALIFICATION_PASS: 33 scenarios;30 checked completions/3 resets;'
      'same-token byte0 negative/zero credit;all30 timestamps and all latency CSV fields exact7B.7')
print(json.dumps(coverage, sort_keys=True))
print('Physical acceptance is separate: inspect the fresh completed Quartus flow and four corners.')
