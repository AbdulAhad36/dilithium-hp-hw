$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw\quartus\dilithium'
$progressFile = 'D:\GitHub\dilithium-hp-hw\sim\dilithium\stage7b9_quartus_runner.log'
'START complete compile with unchanged FPGA/constraints' | Set-Content -LiteralPath $progressFile
& 'F:/altera/quartus/bin64/quartus_sh.exe' --flow compile dilithium_full -c dilithium_full *> ../../sim/dilithium/stage7b9_compile.log
$compileExit = $LASTEXITCODE
"QUARTUS_FLOW_EXIT:$compileExit" | Add-Content -LiteralPath $progressFile
if ($compileExit -ne 0) { exit $compileExit }
& 'F:/altera/quartus/bin64/quartus_sta.exe' -t report_full.tcl *> ../../sim/dilithium/stage7b9_retention_timing.log
if ($LASTEXITCODE -ne 0) { 'FAIL retained-register/multicorner report' | Add-Content -LiteralPath $progressFile; exit 1 }
'QUARTUS_RUNNER_PASS' | Add-Content -LiteralPath $progressFile
