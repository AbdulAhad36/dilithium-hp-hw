$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
'START independent C/Python preparation for production-source fixtures' | Set-Content -LiteralPath sim/dilithium/stage7b9_reference_runner.log
python sim/dilithium/dilithium_vectors.py prepare *> sim/dilithium/stage7b9_prepare.log
if ($LASTEXITCODE -ne 0) { 'FAIL preparation' | Add-Content -LiteralPath sim/dilithium/stage7b9_reference_runner.log; exit 1 }
'REFERENCE_PREPARE_PASS' | Add-Content -LiteralPath sim/dilithium/stage7b9_reference_runner.log
