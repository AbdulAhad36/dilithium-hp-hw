"""Create-only evidence collector, invoked only after the physical run ends.

RESULTS is supplied on stdin after manual review. The script refuses a live
or stale fit report, verifies every prior archive, and includes no old captures.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import subprocess
import sys

root = Path(__file__).resolve().parents[3]
evidence = root / 'docs/dilithium_docs/evidence'
results = json.load(sys.stdin)
assert results['stage'] == '7B.9'
assert results['source']['completions'] == 30
assert results['source']['reset_aborts'] == 3
assert results['source']['errors'] == 0
fit = root / 'quartus/dilithium/output_full/dilithium_full.fit.rpt'
assert fit.stat().st_mtime > (root / 'sim/dilithium/stage7b9_source_audit.log').stat().st_mtime
progress = (root / 'sim/dilithium/stage7b9_quartus_runner.log').read_text(encoding='utf-8-sig')
assert 'QUARTUS_FLOW_EXIT:' in progress
if results['quartus']['routing'] == 'PASS':
    assert 'QUARTUS_RUNNER_PASS' in progress
else:
    assert results['quartus']['accepted_routed_PPA'] is False
for command in [
    [sys.executable, 'sim/dilithium/reference_build/audit_stage7b9.py'],
    [sys.executable, 'sim/dilithium/dilithium_vectors.py', 'uvm_check'],
    [sys.executable, 'sim/dilithium/dilithium_vectors.py', 'check'],
]:
    subprocess.run(command, cwd=root, check=True)

prior = []
for sidecar in sorted(evidence.glob('*.sha256')):
    target = sidecar.with_suffix('') if sidecar.stem.endswith('.zip') else sidecar.with_suffix('.zip')
    assert hashlib.sha256(target.read_bytes()).hexdigest() == sidecar.read_text(encoding='utf-8-sig').split()[0]
    prior.append(target.name)
assert len(prior) == 48
results['prior_archive_pairs_verified'] = len(prior)

paths = {root / '.gitignore', root / 'AGENTS.md', root / 'README.md'}
for directory, patterns in {
    'src': ['**/*.sv'],
    'tb/tb_dilithium': ['*.sv', '*.c', '*.h'],
    'tb_uvm/tb_uvm_dilithium': ['*.sv', '*.svh'],
    'dilithium-sw-model/ref': ['*.c', '*.h'],
    'docs/dilithium_docs': ['*.md'],
    'quartus/dilithium': ['*.qsf', '*.qpf', '*.sdc', 'report_full.tcl', 'README.md'],
    'quartus/dilithium/output_full': ['*.rpt', '*.summary'],
    'sim/dilithium': ['README.md', 'dilithium_vectors.py', 'run.do', 'run_uvm.do',
                      'report_uvm_coverage.tcl', 'stage7b9*.log', 'stage7_uvm*.csv',
                      'stage7_uvm*.txt', 'stage7_uvm*.rpt', 'stage7_uvm*.ucdb'],
    'sim/dilithium/reference_build': ['stage7b9*.ps1', 'audit_stage7b9.py', 'archive_stage7b9.py'],
    'FIPS204_NTT': ['ntt_vectors.py'],
    'FIPS204_SAMPLER': ['sampler_vectors.py'],
}.items():
    for pattern in patterns:
        paths.update((root / directory).glob(pattern))
for operation in ['keyGen', 'sigGen', 'sigVer']:
    paths.update((root / f'NIST/ML-DSA-{operation}-FIPS204').glob('*.json'))
if results['quartus']['routing'] == 'PASS':
    paths.update((root / 'quartus/dilithium/critical_full').glob('*.rpt'))
paths = sorted(path for path in paths if path.is_file())
assert len([path for path in paths if path.is_relative_to(root / 'src')]) == 75
for path in paths:
    if path.is_relative_to(root / 'quartus/dilithium/output_full'):
        assert path.stat().st_mtime > (root / 'sim/dilithium/stage7b9_source_audit.log').stat().st_mtime
blobs = {path.relative_to(root).as_posix(): path.read_bytes() for path in paths}
blobs['RESULTS.json'] = (json.dumps(results, indent=2) + '\n').encode()
manifest = {name: hashlib.sha256(data).hexdigest() for name, data in sorted(blobs.items())}
blobs['MANIFEST.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
suffix = 'baseline' if results['quartus']['routing'] == 'PASS' else 'route_failure'
target = evidence / f'stage7b9_production_top_{suffix}.zip'
sidecar = target.with_suffix('.sha256')
assert not target.exists() and not sidecar.exists()
with ZipFile(target, 'x', compression=ZIP_DEFLATED, compresslevel=9) as archive:
    for name, data in sorted(blobs.items()):
        archive.writestr(name, data)
with ZipFile(target) as archive:
    assert archive.testzip() is None
    for name, digest in manifest.items():
        assert hashlib.sha256(archive.read(name)).hexdigest() == digest
digest = hashlib.sha256(target.read_bytes()).hexdigest()
with sidecar.open('x', encoding='ascii') as handle:
    handle.write(f'{digest}  {target.name}\n')
print(f'CREATE_ONLY_STAGE7B9_ARCHIVE_PASS:{target.name};SHA256:{digest};'
      f'members:{len(blobs)};bytes:{target.stat().st_size};prior_pairs:{len(prior)}')
