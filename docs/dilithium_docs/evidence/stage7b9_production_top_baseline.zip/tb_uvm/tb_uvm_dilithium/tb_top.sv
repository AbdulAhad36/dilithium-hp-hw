`timescale 1ps/1ps
module tb_top #(parameter bit MEMORY_EQUIVALENCE=0);
  generate if(MEMORY_EQUIVALENCE)begin:g_memory_equivalence
    memory_metadata_equivalence memory_check (
      .clk(dut.core.services.datapath.subsystem.store.clk),
      .rst(dut.core.services.datapath.subsystem.store.rst),
      .alloc_valid_i(dut.core.services.datapath.subsystem.store.alloc_valid_i),
      .alloc_core_i(dut.core.services.datapath.subsystem.store.alloc_core_i),
      .alloc_bank_i(dut.core.services.datapath.subsystem.store.alloc_bank_i),
      .alloc_mode_i(dut.core.services.datapath.subsystem.store.alloc_mode_i),
      .alloc_param_i(dut.core.services.datapath.subsystem.store.alloc_param_i),
      .alloc_region_i(dut.core.services.datapath.subsystem.store.alloc_region_i),
      .alloc_id_i(dut.core.services.datapath.subsystem.store.alloc_id_i),
      .alloc_compute_i(dut.core.services.datapath.subsystem.store.alloc_compute_i),
      .alloc_ntt_domain_i(dut.core.services.datapath.subsystem.store.alloc_ntt_domain_i),
      .alloc_rewrite_i(dut.core.services.datapath.subsystem.store.alloc_rewrite_i),
      .dut_alloc_ready_o(dut.core.services.datapath.subsystem.store.alloc_ready_o),
      .write_valid_i(dut.core.services.datapath.subsystem.store.write_valid_i),
      .write_core_i(dut.core.services.datapath.subsystem.store.write_core_i),
      .write_last_i(dut.core.services.datapath.subsystem.store.write_last_i),
      .write_id_i(dut.core.services.datapath.subsystem.store.write_id_i),
      .write_index_i(dut.core.services.datapath.subsystem.store.write_index_i),
      .write_data_i(dut.core.services.datapath.subsystem.store.write_data_i),
      .dut_write_ready_o(dut.core.services.datapath.subsystem.store.write_ready_o),
      .finish_valid_i(dut.core.services.datapath.subsystem.store.finish_valid_i),
      .finish_core_i(dut.core.services.datapath.subsystem.store.finish_core_i),
      .finish_id_i(dut.core.services.datapath.subsystem.store.finish_id_i),
      .finish_code_i(dut.core.services.datapath.subsystem.store.finish_code_i),
      .dut_finish_ready_o(dut.core.services.datapath.subsystem.store.finish_ready_o),
      .read_valid_i(dut.core.services.datapath.subsystem.store.read_valid_i),
      .read_bank_i(dut.core.services.datapath.subsystem.store.read_bank_i),
      .read_region_i(dut.core.services.datapath.subsystem.store.read_region_i),
      .read_word_i(dut.core.services.datapath.subsystem.store.read_word_i),
      .dut_read_ready_o(dut.core.services.datapath.subsystem.store.read_ready_o),
      .dut_response_valid_o(dut.core.services.datapath.subsystem.store.response_valid_o),
      .dut_response_error_o(dut.core.services.datapath.subsystem.store.response_error_o),
      .dut_response_bank_o(dut.core.services.datapath.subsystem.store.response_bank_o),
      .dut_response_mode_o(dut.core.services.datapath.subsystem.store.response_mode_o),
      .dut_response_param_o(dut.core.services.datapath.subsystem.store.response_param_o),
      .dut_response_region_o(dut.core.services.datapath.subsystem.store.response_region_o),
      .dut_response_word_o(dut.core.services.datapath.subsystem.store.response_word_o),
      .dut_response_data_o(dut.core.services.datapath.subsystem.store.response_data_o),
      .dut_response_id_o(dut.core.services.datapath.subsystem.store.response_id_o),
      .dut_response_ntt_domain_o(dut.core.services.datapath.subsystem.store.response_ntt_domain_o),
      .dut_response_small_o(dut.core.services.datapath.subsystem.store.response_small_o),
      .response_ready_i(dut.core.services.datapath.subsystem.store.response_ready_i),
      .release_valid_i(dut.core.services.datapath.subsystem.store.release_valid_i),
      .release_bank_i(dut.core.services.datapath.subsystem.store.release_bank_i),
      .release_region_i(dut.core.services.datapath.subsystem.store.release_region_i),
      .dut_release_ready_o(dut.core.services.datapath.subsystem.store.release_ready_o),
      .dut_reserved_o(dut.core.services.datapath.subsystem.store.reserved_o),
      .dut_complete_o(dut.core.services.datapath.subsystem.store.complete_o),
      .dut_fault_o(dut.core.services.datapath.subsystem.store.fault_o)
    );
  end endgenerate

  import uvm_pkg::*;import dilithium_uvm_pkg::*;
  logic clk=0;
  always begin #3378 clk=1;#3379 clk=0;end
  dilithium_if vif(clk);
  dilithium_fpga dut (
    .key_valid_o(vif.key_valid_o),
    .key_ready_i(vif.key_ready_i),
    .key_data_o(vif.key_data_o),
    .key_bytes_o(vif.key_bytes_o),
    .key_type_o(vif.key_type_o),
    .key_last_o(vif.key_last_o),
    .key_index_o(vif.key_index_o),
    .key_id_o(vif.key_id_o),
    .clk(clk),
    .rst(vif.rst),
    .start_valid_i(vif.start_valid_i),
    .start_ready_o(vif.start_ready_o),
    .busy_o(vif.busy_o),
    .start_op_i(vif.start_op_i),
    .start_param_i(vif.start_param_i),
    .start_id_i(vif.start_id_i),
    .start_seed_i(vif.start_seed_i),
    .start_message_len_i(vif.start_message_len_i),
    .start_context_len_i(vif.start_context_len_i),
    .start_rnd_i(vif.start_rnd_i),
    .sign_input_valid_i(vif.sign_input_valid_i),
    .sign_input_ready_o(vif.sign_input_ready_o),
    .sign_input_data_i(vif.sign_input_data_i),
    .sign_input_bytes_i(vif.sign_input_bytes_i),
    .sign_input_index_i(vif.sign_input_index_i),
    .sign_input_last_i(vif.sign_input_last_i),
    .start_signature_len_i(vif.start_signature_len_i),
    .verify_input_valid_i(vif.verify_input_valid_i),
    .verify_input_ready_o(vif.verify_input_ready_o),
    .verify_input_data_i(vif.verify_input_data_i),
    .verify_input_bytes_i(vif.verify_input_bytes_i),
    .verify_input_index_i(vif.verify_input_index_i),
    .verify_input_last_i(vif.verify_input_last_i),
    .verify_accept_o(vif.verify_accept_o),
    .signature_valid_o(vif.signature_valid_o),
    .signature_ready_i(vif.signature_ready_i),
    .signature_data_o(vif.signature_data_o),
    .signature_bytes_o(vif.signature_bytes_o),
    .signature_index_o(vif.signature_index_o),
    .signature_last_o(vif.signature_last_o),
    .signature_id_o(vif.signature_id_o),
    .done_stage_o(vif.done_stage_o),
    .done_detail_o(vif.done_detail_o),
    .sign_attempts_o(vif.sign_attempts_o),
    .sign_rejections_o(vif.sign_rejections_o),
    .sign_next_nonce_o(vif.sign_next_nonce_o),
    .done_valid_o(vif.done_valid_o),
    .done_ready_i(vif.done_ready_i),
    .done_code_o(vif.done_code_o),
    .done_id_o(vif.done_id_o),
    .fault_o(vif.fault_o)
  );
  // Observation probes are internal;they are not production FPGA ports.
  assign vif.reserved_o=dut.core.reserved_o;
  assign vif.complete_o=dut.core.complete_o;
  assign vif.legacy_row_valid=dut.core.row_result_valid_o;
  assign vif.legacy_read_ready=dut.core.read_ready_o;
  assign vif.legacy_response_valid=dut.core.response_valid_o;
  assign vif.main_state=dut.core.state;
  assign vif.owners={dut.core.verify_owner,dut.core.sign_owner,dut.core.keygen_owner};
  assign vif.hash_active=dut.core.shared_response.active;
  assign vif.ntt_busy=dut.core.shared_response.op_busy;
  assign vif.process_busy=dut.core.shared_response.process_busy;
  initial begin uvm_config_db#(virtual dilithium_if)::set(null,"*","vif",vif);run_test();end
  initial begin #(64'd4000000000000);$fatal(1,"Dilithium UVM global watchdog");end
endmodule

