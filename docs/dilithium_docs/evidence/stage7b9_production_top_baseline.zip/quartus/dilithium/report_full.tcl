# Whole-main baseline only. Run after compiling dilithium_full.qpf.
project_open dilithium_full -revision dilithium_full
if {[get_global_assignment -name TOP_LEVEL_ENTITY] ne "dilithium_fpga"} {error "Wrong production synthesis top"}
create_timing_netlist -model slow
read_sdc
file mkdir critical_full
set guard [open critical_full/retained_registers.rpt w]
foreach {label pattern minimum} {
  main_state *state* 1
  keygen_controller *core|state* 1
  sign_controller *g_sign*signer|state* 1
  verify_controller *g_verify*verifier|state* 1
  keccak_state *hash|*u_core|state_array* 3200
  sampler_extract_secret *sample|extract_secret_r* 64
  sampler_decode_secret *sample|decode_secret_r* 64
  sampler_packed_secret *sample|packed_secret_r* 64
  sign_products_scan_index *products|layout_index_r* 5
  sign_attempt_scan_index *bounds|layout_index_r* 5
  active_writer_metadata *store|writer_meta_r* 44
  active_writer_progress *store|writer_count_r* 18
  verify_hint_payload *verify_loader|decoder|hints_r* 672
} {
  set names {}
  foreach_in_collection reg [get_registers $pattern] {
    set name [get_node_info -name $reg]
    # Scope these two FSM guards exactly: *state* also finds Keccak state_array.
    if {$label eq "main_state" && ![regexp {^dilithium:core\|state[.\[]} $name]} {continue}
    if {$label eq "keygen_controller" && ![regexp {^dilithium:core\|keygen:core\|state[.\[]} $name]} {continue}
    # Count the original84-byte payload,not the four new padding bytes.
    if {$label eq "verify_hint_payload"} {
      if {![regexp {hints_r\[([0-9]+)\]} $name -> bit_index] || $bit_index>=672} {continue}
    }
    if {![string match {*~DUPLICATE*} $name]} {lappend names $name}
  }
  set count [llength [lsort -unique $names]]
  puts $guard "$label:$count original mapped register bits; minimum:$minimum"
  if {$count<$minimum} {close $guard;error "Missing retained registers for $label"}
}
puts $guard {WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS}
close $guard
foreach corner {{slow 85} {slow 0} {fast 85} {fast 0}} {
  lassign $corner model temperature
  set_operating_conditions -model $model -temperature $temperature -voltage 1100
  update_timing_netlist
  set prefix critical_full/${model}_${temperature}C
  report_timing -setup -npaths 5 -detail full_path -file ${prefix}_setup.rpt
  report_timing -hold -npaths 5 -detail full_path -file ${prefix}_hold.rpt
  report_clock_fmax_summary -file ${prefix}_fmax.rpt
}
delete_timing_netlist
project_close
