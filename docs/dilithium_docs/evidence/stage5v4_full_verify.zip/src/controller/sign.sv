// Full pure-ML-DSA Sign client. Input frames:expanded SK,then ctx||M.
// Each frame restarts its word index at0. No encoded-key/message/signature RAM.
// One exclusive services lease includes all child handoffs and final cleanup.
`default_nettype none
module sign (
  input wire logic clk,rst,start_valid_i,output logic start_ready_o,busy_o,fault_o,
  input wire logic [1:0] start_param_i,input wire logic [15:0] start_id_i,start_message_len_i,
  input wire logic [8:0] start_context_len_i,input wire logic [255:0] start_rnd_i,
  input wire logic input_valid_i,output logic input_ready_o,
  input wire logic [63:0] input_data_i,input wire logic [3:0] input_bytes_i,
  input wire logic [15:0] input_index_i,input wire logic input_last_i,
  output logic signature_valid_o,input wire logic signature_ready_i,
  output logic [63:0] signature_data_o,output logic [3:0] signature_bytes_o,
  output logic [9:0] signature_index_o,output logic signature_last_o,
  output logic [15:0] signature_id_o,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic [2:0] done_code_o,done_stage_o,done_detail_o,output logic [15:0] done_id_o,
  output logic [16:0] attempts_o,rejections_o,next_nonce_o,
  output dilithium_service_pkg::request_t service_o,
  input wire dilithium_service_pkg::response_t service_i
);
  import dilithium_service_pkg::*;
  typedef enum logic [4:0] {IDLE,KEY_START,KEY_WAIT,KEY_RETIRE,ATTEMPT_START,
    ATTEMPT_WAIT,ATTEMPT_RETIRE,ENCODE_START,ENCODE_WAIT,ENCODE_RETIRE,
    DROP_ATTEMPT,WAIT_ATTEMPT,DROP_KEY,WAIT_KEY,REPORT,HALT} state_e;
  state_e state;
  logic [1:0] param_r,kparam;
  logic [15:0] id_r,message_r,kid,kdone_id,adone_id,edone_id;
  logic [8:0] context_r;logic [255:0] rnd_r,rho,key;logic [511:0] tr;
  logic kr,kbusy,kactive,kfault,kinput_ready,kdone,kvalid,kclear,kclear_ready;
  logic ar,abusy,afault,ainput_ready,adone,avalid,aclear,aclear_ready,atake,atake_ready;
  logic er,ebusy,efault,edone;
  logic [2:0] kcode,kdetail,acode,astage,adetail,ecode;
  logic [63:0] kregions,aregions;
  logic [22:0][5:0] handles;
  logic [6:0][5:0] z;logic [7:0][5:0] hints;
  logic [511:0] digest;logic [6:0] digest_bytes;
  logic [16:0] attempts,rejections,next_nonce;
  request_t key_request,attempt_request,encode_request;
  logic [17:0] message_total;
  assign message_total=18'd66+18'(start_context_len_i)+18'(start_message_len_i);
  assign start_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault && service_i.reserved==0 &&
    kr && ar && er && !kbusy && !abusy && !ebusy;
  assign busy_o=state!=IDLE;
  assign input_ready_o=!rst && !fault_o && ((state==KEY_WAIT && kinput_ready) || (state==ATTEMPT_WAIT && ainput_ready));
  assign done_valid_o=!rst && state==REPORT && !fault_o;assign done_id_o=id_r;
  assign kclear=state==DROP_KEY && kvalid && !fault_o;
  assign aclear=state==DROP_ATTEMPT && avalid && !fault_o;
  sign_key_prepare keys(
    .clk(clk),.rst(rst),.command_valid_i(state==KEY_START && !fault_o),.command_ready_o(kr),
    .busy_o(kbusy),.service_active_o(kactive),.fault_o(kfault),.command_param_i(param_r),.command_id_i(id_r),
    .command_base_i(6'd0),.command_work_i(6'd31),
    .input_valid_i(state==KEY_WAIT && input_valid_i && !fault_o),.input_ready_o(kinput_ready),
    .input_data_i(input_data_i),.input_bytes_i(input_index_i[15:10]!=0?4'd0:input_bytes_i),
    .input_index_i(input_index_i[9:0]),.input_last_i(input_last_i),
    .done_valid_o(kdone),.done_ready_i(state==KEY_WAIT && !fault_o),.done_code_o(kcode),.done_detail_o(kdetail),.done_id_o(kdone_id),
    .context_valid_o(kvalid),.context_param_o(kparam),.context_id_o(kid),.context_regions_o(kregions),
    .context_handles_o(handles),.context_rho_o(rho),.context_key_o(key),.context_tr_o(tr),
    .clear_valid_i(kclear),.clear_ready_o(kclear_ready),.service_o(key_request),.service_i(service_i));
  sign_attempt_loop attempt(
    .clk(clk),.rst(rst),.command_valid_i(state==ATTEMPT_START && !fault_o),.command_ready_o(ar),.busy_o(abusy),.fault_o(afault),
    .context_valid_i(kvalid),.context_param_i(kparam),.context_id_i(kid),.context_regions_i(kregions),.context_handles_i(handles),
    .context_rho_i(rho),.context_key_i(key),.context_tr_i(tr),.command_id_i(id_r),.command_message_len_i(message_r),
    .command_nonce_i(17'd0),.command_context_len_i(context_r),.command_base_i(6'd32),.command_rnd_i(rnd_r),
    .payload_valid_i(state==ATTEMPT_WAIT && input_valid_i && !fault_o),.payload_ready_o(ainput_ready),
    .payload_data_i(input_data_i),.payload_bytes_i(input_bytes_i),.payload_index_i(input_index_i),.payload_last_i(input_last_i),
    .done_valid_o(adone),.done_ready_i(state==ATTEMPT_WAIT && !fault_o),.done_code_o(acode),.done_stage_o(astage),.done_detail_o(adetail),
    .done_id_o(adone_id),.attempts_o(attempts),.rejections_o(rejections),.next_nonce_o(next_nonce),
    .result_valid_o(avalid),.result_regions_o(aregions),.result_z_o(z),.result_hint_o(hints),.result_ctilde_o(digest),.result_bytes_o(digest_bytes),
    .clear_valid_i(aclear),.clear_ready_o(aclear_ready),.take_valid_i(atake),.take_ready_o(atake_ready),
    .service_o(attempt_request),.service_i(service_i));
  sign_signature_encode encoder(
    .clk(clk),.rst(rst),.command_valid_i(state==ENCODE_START && !fault_o),.command_ready_o(er),.busy_o(ebusy),.fault_o(efault),
    .param_i(param_r),.command_id_i(id_r),.source_valid_i(avalid),.source_id_i(id_r),.source_regions_i(aregions),
    .source_z_i(z),.source_hint_i(hints),.source_ctilde_i(digest),.source_bytes_i(digest_bytes),
    .source_take_valid_o(atake),.source_take_ready_i(atake_ready),
    .output_valid_o(signature_valid_o),.output_ready_i(signature_ready_i),.output_data_o(signature_data_o),
    .output_bytes_o(signature_bytes_o),.output_index_o(signature_index_o),.output_last_o(signature_last_o),.output_id_o(signature_id_o),
    .done_valid_o(edone),.done_ready_i(state==ENCODE_WAIT && !fault_o),.done_code_o(ecode),.done_id_o(edone_id),
    .service_o(encode_request),.service_i(service_i));
  always_comb begin
    service_o='0;
    case(state)
      KEY_START,KEY_WAIT,KEY_RETIRE,DROP_KEY,WAIT_KEY:service_o=key_request;
      ATTEMPT_START,ATTEMPT_WAIT,ATTEMPT_RETIRE,DROP_ATTEMPT,WAIT_ATTEMPT:service_o=attempt_request;
      ENCODE_START,ENCODE_WAIT,ENCODE_RETIRE:service_o=encode_request;
      default:service_o='0;
    endcase
    if(fault_o)service_o='0;
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;id_r<=0;message_r<=0;context_r<=0;rnd_r<=0;
      done_code_o<=0;done_stage_o<=0;done_detail_o<=0;fault_o<=0;
      attempts_o<=0;rejections_o<=0;next_nonce_o<=0;
    end else if(state!=IDLE && (service_i.fault || kfault || afault || efault))begin fault_o<=1;state<=HALT;
    end else begin
      if(state==ATTEMPT_WAIT)begin attempts_o<=attempts;rejections_o<=rejections;next_nonce_o<=next_nonce;end
      case(state)
        IDLE:if(start_valid_i && start_ready_o)begin
          param_r<=start_param_i;id_r<=start_id_i;message_r<=start_message_len_i;context_r<=start_context_len_i;rnd_r<=start_rnd_i;
          done_code_o<=0;done_stage_o<=0;done_detail_o<=0;attempts_o<=0;rejections_o<=0;next_nonce_o<=0;
          if(start_param_i==3 || start_context_len_i>255 || message_total>65535)begin done_code_o<=1;state<=REPORT;end
          else state<=KEY_START;
        end
        KEY_START:if(kr)state<=KEY_WAIT;
        KEY_WAIT:if(kdone)begin
          if(kdone_id!=id_r || (kcode==0 && (!kvalid || kid!=id_r || kparam!=param_r)))begin done_code_o<=6;done_stage_o<=1;end
          else if(kcode!=0)begin done_code_o<=3;done_stage_o<=1;done_detail_o<=kcode;end
          state<=KEY_RETIRE;
        end
        KEY_RETIRE:if(!kdone && (kvalid || !kbusy))state<=done_code_o==0?ATTEMPT_START:DROP_ATTEMPT;
        ATTEMPT_START:if(ar)state<=ATTEMPT_WAIT;
        ATTEMPT_WAIT:if(adone)begin
          if(adone_id!=id_r || (acode==0 && !avalid))begin done_code_o<=6;done_stage_o<=2;end
          else if(acode!=0)begin done_code_o<=4;done_stage_o<=2;done_detail_o<=acode;end
          state<=ATTEMPT_RETIRE;
        end
        ATTEMPT_RETIRE:if(!adone && (avalid || !abusy))state<=done_code_o==0?ENCODE_START:DROP_ATTEMPT;
        ENCODE_START:if(er)state<=ENCODE_WAIT;
        ENCODE_WAIT:if(edone)begin
          if(edone_id!=id_r)begin done_code_o<=6;done_stage_o<=3;end
          else if(ecode!=0)begin done_code_o<=5;done_stage_o<=3;done_detail_o<=ecode;end
          state<=ENCODE_RETIRE;
        end
        ENCODE_RETIRE:if(!ebusy)state<=DROP_ATTEMPT;
        DROP_ATTEMPT:if(aclear && aclear_ready)state<=WAIT_ATTEMPT;else if(!abusy)state<=DROP_KEY;
        WAIT_ATTEMPT:if(!abusy)state<=DROP_KEY;
        DROP_KEY:if(kclear && kclear_ready)state<=WAIT_KEY;else if(!kbusy)state<=REPORT;
        WAIT_KEY:if(!kbusy)state<=REPORT;
        REPORT:if(done_ready_i)begin rnd_r<=0;state<=IDLE;end
        HALT:state<=HALT;
        default:begin fault_o<=1;state<=HALT;end
      endcase
    end
  end
endmodule
`default_nettype wire
