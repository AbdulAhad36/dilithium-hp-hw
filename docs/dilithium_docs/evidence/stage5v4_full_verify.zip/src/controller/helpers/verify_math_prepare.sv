// Adopt the decoded Verify context,hash pure-message mu,SampleInBall(ctilde),
// and transform t1<<13,z,c with the ONE existing services tree. A free region
// rotates through the source slots;hints stay in coefficient form. No data RAM.
`default_nettype none
module verify_math_prepare (
  input wire logic clk,rst,command_valid_i,output logic command_ready_o,busy_o,fault_o,
  input wire logic [15:0] command_id_i,command_message_len_i,input wire logic [8:0] command_context_len_i,
  input wire logic context_valid_i,input wire logic [1:0] context_param_i,input wire logic [15:0] context_id_i,
  input wire logic [63:0] context_regions_i,input wire logic [7:0][5:0] context_t1_i,context_hints_i,
  input wire logic [6:0][5:0] context_z_i,input wire logic [255:0] context_rho_i,
  input wire logic [511:0] context_tr_i,context_ctilde_i,
  output logic context_take_valid_o,input wire logic context_take_ready_i,
  input wire logic payload_valid_i,output logic payload_ready_o,input wire logic [63:0] payload_data_i,
  input wire logic [3:0] payload_bytes_i,input wire logic [15:0] payload_index_i,input wire logic payload_last_i,
  output logic done_valid_o,input wire logic done_ready_i,output logic [2:0] done_code_o,done_detail_o,
  output logic [15:0] done_id_o,output logic result_valid_o,output logic [1:0] result_param_o,
  output logic [15:0] result_id_o,output logic [63:0] result_regions_o,
  output logic [7:0][5:0] result_t1hat_o,result_hints_o,output logic [6:0][5:0] result_zhat_o,
  output logic [5:0] result_chat_o,output logic [255:0] result_rho_o,
  output logic [511:0] result_mu_o,result_ctilde_o,
  input wire logic clear_valid_i,output logic clear_ready_o,input wire logic take_valid_i,output logic take_ready_o,
  output dilithium_service_pkg::request_t service_o,input wire dilithium_service_pkg::response_t service_i
);
  typedef enum logic [4:0] {IDLE,CHECK,TAKE,MU_START,MU_WAIT,FIND_C,C_START,C_INPUT,C_WAIT,C_RETIRE,
    FIND_WORK,OP_START,OP_WAIT,OP_RETIRE,FREE_SOURCE,REPORT,READY,CLEAN,HALT} state_e;
  state_e state;
  logic [1:0] param_r;logic [15:0] id_r,mlen_r;logic [8:0] ctx_r;
  logic [3:0] k_r,l_r,ordinal_r;logic [5:0] scan_r,c_r,chat_r,work_r,source;
  logic [7:0][5:0] t1_r,hints_r;logic [6:0][5:0] z_r;
  logic [255:0] rho_r;logic [511:0] tr_r,ctilde_r,mu_r;
  logic [63:0] original_r,owned_r,command_mask;logic layout_bad,source_changed,quiescent,clearing_r;
  logic [3:0] command_k,command_l;logic [17:0] command_length;
  logic [2:0] code_r,detail_r;logic [6:0] count_r,ctbytes;
  logic started_r,retired_r,core_r,sample_core_r;logic [3:0] sample_word_r;
  logic fr,fb,fq,fqr,fs,fm,fi,fir,fl,fd,fack,fpr;logic [1:0] fp;
  logic [15:0] fid,flen,fout,findex,fdid;logic [63:0] fdata;logic [3:0] fbytes;logic [2:0] fcode;
  logic out_fire,done_fire,raw_bad;
  always_comb begin
    command_k=context_param_i==0?4'd4:context_param_i==1?4'd6:4'd8;
    command_l=context_param_i==0?4'd4:context_param_i==1?4'd5:4'd7;
    command_length=18'd66+18'(command_context_len_i)+18'(command_message_len_i);
    command_mask=0;layout_bad=0;
    for(int j=0;j<8;j++)if(j<int'(command_k))begin
      if(command_mask[context_t1_i[j]])layout_bad=1;command_mask[context_t1_i[j]]=1;
      if(command_mask[context_hints_i[j]])layout_bad=1;command_mask[context_hints_i[j]]=1;
    end
    for(int j=0;j<7;j++)if(j<int'(command_l))begin
      if(command_mask[context_z_i[j]])layout_bad=1;command_mask[context_z_i[j]]=1;
    end
    layout_bad|=command_mask!=context_regions_i || (context_param_i==0 && context_ctilde_i[511:256]!=0) ||
      (context_param_i==1 && context_ctilde_i[511:384]!=0);
  end
  assign source_changed=!context_valid_i || context_id_i!=id_r || context_param_i!=param_r || context_regions_i!=original_r ||
    context_t1_i!=t1_r || context_z_i!=z_r || context_hints_i!=hints_r || context_rho_i!=rho_r || context_tr_i!=tr_r || context_ctilde_i!=ctilde_r;
  assign quiescent=service_i.active==0 && !service_i.op_busy && !service_i.process_busy && !service_i.sign.busy &&
    !service_i.load.busy && !service_i.row_busy && !service_i.response_valid && service_i.read_ready &&
    service_i.pack.command_ready && !service_i.pack.done_valid && !service_i.pack.output_valid;
  assign command_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault;
  assign busy_o=state!=IDLE;assign done_valid_o=!rst && state==REPORT && !fault_o;
  assign done_code_o=code_r;assign done_detail_o=detail_r;assign done_id_o=id_r;
  assign context_take_valid_o=state==TAKE && quiescent && !source_changed && !fault_o;
  assign result_valid_o=!rst && !fault_o && ((state==REPORT && code_r==0) || state==READY);
  assign result_param_o=result_valid_o?param_r:2'd0;assign result_id_o=result_valid_o?id_r:16'd0;
  assign result_regions_o=result_valid_o?owned_r:64'd0;assign result_t1hat_o=result_valid_o?t1_r:'0;
  assign result_zhat_o=result_valid_o?z_r:'0;assign result_hints_o=result_valid_o?hints_r:'0;
  assign result_chat_o=result_valid_o?chat_r:6'd0;assign result_rho_o=result_valid_o?rho_r:256'd0;
  assign result_mu_o=result_valid_o?mu_r:512'd0;assign result_ctilde_o=result_valid_o?ctilde_r:512'd0;
  assign clear_ready_o=!rst && state==READY && quiescent && !fault_o && !service_i.fault;
  assign take_ready_o=clear_ready_o && !clear_valid_i;
  assign ctbytes=param_r==0?7'd32:param_r==1?7'd48:7'd64;
  assign source=ordinal_r<k_r?t1_r[ordinal_r]:ordinal_r<k_r+l_r?z_r[ordinal_r-k_r]:c_r;
  sign_hash_message formatter(.clk(clk),.rst(rst),.command_valid_i(state==MU_START && !fault_o),.command_ready_o(fr),.busy_o(fb),
    .command_op_i(2'd0),.command_param_i(param_r),.command_id_i(id_r),.command_message_len_i(mlen_r),.command_nonce_i(16'd0),
    .command_context_len_i(ctx_r),.command_tr_i(tr_r),.command_mu_i(512'd0),.command_mask_seed_i(512'd0),.command_key_i(256'd0),.command_rnd_i(256'd0),
    .payload_valid_i(payload_valid_i && state==MU_WAIT && !fault_o),.payload_ready_o(fpr),.payload_data_i(payload_data_i),
    .payload_bytes_i(payload_bytes_i),.payload_index_i(payload_index_i),.payload_last_i(payload_last_i),
    .request_valid_o(fq),.request_ready_i(fqr),.request_sampling_o(fs),.request_mode_o(fm),.request_param_o(fp),.request_id_o(fid),
    .request_message_len_o(flen),.request_output_len_o(fout),.input_valid_o(fi),.input_ready_i(fir),.input_data_o(fdata),
    .input_bytes_o(fbytes),.input_index_o(findex),.input_last_o(fl),.done_valid_o(fd),.done_ready_i(fack),.done_code_o(fcode),.done_id_o(fdid));
  assign fqr=state==MU_WAIT && service_i.raw_ready && !fault_o;
  assign payload_ready_o=state==MU_WAIT && fpr && !fault_o;
  assign fir=state==MU_WAIT && service_i.raw_input_ready && !fault_o;
  assign fack=state==MU_WAIT && fd && retired_r && service_i.active==0 && !fault_o;
  assign out_fire=service_i.raw_output_valid && service_o.raw_output_ready;
  assign done_fire=service_i.raw_done_valid && service_o.raw_done_ready;
  always_comb begin
    raw_bad=out_fire && (service_i.raw_output_core!=core_r || service_i.raw_output_id!=id_r || service_i.raw_output_bytes!=16 || count_r>48 || retired_r);
    if(done_fire)raw_bad|=service_i.raw_done_core!=core_r || service_i.raw_done_id!=id_r || count_r+(out_fire?7'd16:7'd0)!=64 || retired_r;
    service_o='0;
    service_o.raw_valid=state==MU_WAIT && fq && !fault_o;service_o.raw_mode=fm;service_o.raw_id=fid;
    service_o.raw_message_len=flen;service_o.raw_output_len=fout;service_o.raw_input_data=fdata;
    service_o.raw_input_valid=state==MU_WAIT && fi && !fault_o;
    service_o.raw_output_ready=state==MU_WAIT && started_r && !retired_r && !fault_o;
    service_o.raw_done_ready=service_o.raw_output_ready;
    service_o.job_valid=state==C_START && !fault_o;service_o.job_mode=3;service_o.job_param=param_r;
    service_o.job_id=id_r;service_o.message_len={9'd0,ctbytes};{service_o.job_bank,service_o.job_region}=c_r;
    service_o.input_valid=state==C_INPUT && !fault_o;service_o.input_data=ctilde_r[64*sample_word_r+:64];
    service_o.status_ready=state==C_WAIT && !fault_o;
    service_o.op_valid=state==OP_START && !fault_o;service_o.op=ordinal_r==k_r+l_r?2'd3:2'd0;
    service_o.op_a_region=source;service_o.op_a_id=id_r;service_o.op_dest_region=work_r;service_o.op_id=id_r;
    service_o.op_done_ready=state==OP_WAIT && !fault_o;
    service_o.release_valid=!fault_o && (state==FREE_SOURCE || (state==CLEAN && owned_r[scan_r]));
    {service_o.release_bank,service_o.release_region}=state==FREE_SOURCE?source:scan_r;
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;id_r<=0;mlen_r<=0;ctx_r<=0;k_r<=0;l_r<=0;ordinal_r<=0;scan_r<=0;c_r<=0;chat_r<=0;work_r<=0;
      t1_r<=0;z_r<=0;hints_r<=0;rho_r<=0;tr_r<=0;ctilde_r<=0;mu_r<=0;original_r<=0;owned_r<=0;
      code_r<=0;detail_r<=0;count_r<=0;clearing_r<=0;started_r<=0;retired_r<=0;core_r<=0;sample_core_r<=0;sample_word_r<=0;fault_o<=0;
    end else if((service_i.fault && state!=IDLE) || raw_bad)begin fault_o<=1;state<=HALT;end
    else case(state)
      IDLE:if(command_valid_i && command_ready_o)begin
        param_r<=context_param_i;id_r<=command_id_i;mlen_r<=command_message_len_i;ctx_r<=command_context_len_i;k_r<=command_k;l_r<=command_l;
        t1_r<=context_t1_i;z_r<=context_z_i;hints_r<=context_hints_i;rho_r<=context_rho_i;tr_r<=context_tr_i;ctilde_r<=context_ctilde_i;
        original_r<=context_regions_i;owned_r<=0;code_r<=0;detail_r<=0;scan_r<=0;ordinal_r<=0;mu_r<=0;clearing_r<=0;
        if(!context_valid_i || context_param_i==3 || context_id_i!=command_id_i || layout_bad || command_context_len_i>255 || command_length>65535)begin code_r<=1;state<=REPORT;end
        else state<=CHECK;
      end
      CHECK:if(!quiescent || source_changed || (service_i.reserved & original_r)!=original_r || (service_i.complete & original_r)!=original_r)begin code_r<=2;state<=REPORT;end
        else state<=TAKE;
      TAKE:if(source_changed)begin code_r<=2;state<=REPORT;end
        else if(context_take_valid_o && context_take_ready_i)begin owned_r<=original_r;state<=MU_START;end
      MU_START:if(fr)begin started_r<=0;retired_r<=0;count_r<=0;mu_r<=0;state<=MU_WAIT;end
      MU_WAIT:begin
        if(fq && fqr)begin started_r<=1;core_r<=service_i.raw_core;end
        if(out_fire)begin mu_r[8*count_r+:128]<=service_i.raw_output_data;count_r<=count_r+16;end
        if(done_fire)retired_r<=1;
        if(fack)begin
          if(fcode!=0 || fdid!=id_r)begin code_r<=fdid!=id_r?3'd6:3'd3;detail_r<=fcode;scan_r<=0;state<=CLEAN;end
          else begin scan_r<=0;state<=FIND_C;end
        end
      end
      FIND_C:if(!service_i.reserved[scan_r])begin c_r<=scan_r;state<=C_START;end
        else if(scan_r==63)begin code_r<=4;scan_r<=0;state<=CLEAN;end else scan_r<=scan_r+1'b1;
      C_START:if(service_i.job_ready)begin sample_core_r<=service_i.job_core;sample_word_r<=0;state<=C_INPUT;end
      C_INPUT:if(service_i.input_ready)begin
        if(sample_word_r==4'(ctbytes>>3)-1'b1)state<=C_WAIT;else sample_word_r<=sample_word_r+1'b1;
      end
      C_WAIT:if(service_i.status_valid)begin
        if(service_i.status_id!=id_r || service_i.status_core!=sample_core_r)code_r<=6;
        else if(service_i.status_code!=0)begin code_r<=5;detail_r<=service_i.status_code;end
        state<=C_RETIRE;
      end
      C_RETIRE:if(service_i.active==0)begin
        if(service_i.reserved[c_r])owned_r[c_r]<=1;
        if(service_i.reserved[c_r] && !service_i.complete[c_r])begin fault_o<=1;state<=HALT;end
        else if(code_r!=0 || !service_i.reserved[c_r])begin if(code_r==0)code_r<=6;scan_r<=0;state<=CLEAN;end
        else begin scan_r<=0;state<=FIND_WORK;end
      end
      FIND_WORK:if(!service_i.reserved[scan_r])begin work_r<=scan_r;state<=OP_START;end
        else if(scan_r==63)begin code_r<=4;scan_r<=0;state<=CLEAN;end else scan_r<=scan_r+1'b1;
      OP_START:if(service_i.op_ready)state<=OP_WAIT;
      OP_WAIT:if(service_i.op_done_valid)begin
        if(service_i.op_done_id!=id_r || service_i.op_done_region!=work_r)code_r<=6;
        else if(service_i.op_done_code!=0)begin code_r<=5;detail_r<=service_i.op_done_code;end
        state<=OP_RETIRE;
      end
      OP_RETIRE:if(!service_i.op_busy)begin
        if(service_i.reserved[work_r])owned_r[work_r]<=1;
        if(service_i.reserved[work_r] && !service_i.complete[work_r])begin fault_o<=1;state<=HALT;end
        else if(code_r!=0 || !service_i.reserved[work_r])begin if(code_r==0)code_r<=6;scan_r<=0;state<=CLEAN;end
        else state<=FREE_SOURCE;
      end
      FREE_SOURCE:if(service_i.release_ready)begin
        owned_r[source]<=0;work_r<=source;
        if(ordinal_r<k_r)t1_r[ordinal_r]<=work_r;
        else if(ordinal_r<k_r+l_r)z_r[ordinal_r-k_r]<=work_r;
        else chat_r<=work_r;
        if(ordinal_r==k_r+l_r)state<=REPORT;
        else begin ordinal_r<=ordinal_r+1'b1;state<=OP_START;end
      end
      REPORT:if(done_ready_i)state<=code_r==0?READY:IDLE;
      READY:if(clear_valid_i && clear_ready_o)begin clearing_r<=1;scan_r<=0;state<=CLEAN;end
        else if(take_valid_i && take_ready_o)begin owned_r<=0;mu_r<=0;rho_r<=0;ctilde_r<=0;state<=IDLE;end
      CLEAN:if(!owned_r[scan_r] || service_i.release_ready)begin
        owned_r[scan_r]<=0;
        if(scan_r==63)begin mu_r<=0;rho_r<=0;ctilde_r<=0;state<=clearing_r?IDLE:REPORT;end else scan_r<=scan_r+1'b1;
      end
      HALT:state<=HALT;
      default:begin fault_o<=1;state<=HALT;end
    endcase
  end
endmodule
`default_nettype wire
