"""Stage2: real SHAKE -> sampling vectors, capture and independent comparison.

These are locally generated subsystem vectors, not full-operation NIST vectors.
One script is extended as the Dilithium subsystem grows.
"""
import argparse
import hashlib
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
REF = ROOT / 'FIPS204_SAMPLER/sampler_vectors.py'
spec = importlib.util.spec_from_file_location('sampler_reference', REF)
reference = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reference)


def cases():
    result = []
    def add(mode, param, label, length=None, abort=False, job_id=None):
        i = len(result)
        length = (34 if mode == 0 else 66 if mode in (1, 2) else 32) if length is None else length
        message = hashlib.shake_256(label.encode()).digest(length)
        # Raw absorbed messages exercise the engine connection; full seed/nonce
        # formatting is a later controller/version contract.
        if param == 3:
            values, code = [], 3
        else:
            stream = (hashlib.shake_128 if mode == 0 else hashlib.shake_256)(message).digest(4096)
            values, _ = reference.sample(mode, param, stream)
            assert len(values) == 256
            code = 0
        result.append(dict(i=i, id=1000+i if job_id is None else job_id,
                           mode=mode, param=param, message=message,
                           abort=abort, code=code, values=values))
    # Twelve pairs establish both contexts in every mode/parameter combination.
    for mode in range(4):
        for param in range(3):
            for slot in range(2):
                add(mode, param, f'base-{mode}-{param}-{slot}')
    # All sixteen ordered mode pairs, including independent live peer modes.
    for first in range(4):
        for second in range(4):
            param = (first+second) % 3
            add(first, param, f'mixed-{first}-{second}-a')
            add(second, param, f'mixed-{first}-{second}-b')
    # Empty/partial/multi-rate absorption; unused high input bytes are poisoned.
    lengths = [0, 1, 7, 8, 9, 33, 34, 65, 66, 135, 136, 137,
               167, 168, 169, 271, 272, 273, 335, 336, 337, 15, 16, 17]
    for i, length in enumerate(lengths):
        add(i % 4, (i//4) % 3, f'length-{i}', length)
    assert len(result) == 80
    for mode in range(4):
        for slot in range(2):
            add(mode, 3, f'invalid-{mode}-{slot}')
    for phase in range(4):
        for slot in range(2):
            add((phase+slot) % 4, phase % 3, f'abort-{phase}-{slot}', abort=True,
                job_id=2000+phase*2+slot)
        for slot in range(2):
            add((phase+slot) % 4, phase % 3, f'recover-{phase}-{slot}',
                job_id=2000+phase*2+slot)
    assert len(result) == 104
    return result


def artifacts():
    rows = cases()
    stimuli, golden = [], []
    for c in rows:
        stimuli.append(f"{c['i']} {c['id']} {c['mode']} {c['param']} {int(c['abort'])} {len(c['message'])} {c['message'].hex() or '-'}")
        golden.append(f"{c['i']} {c['code']} {int(c['abort'])} {len(c['values'])} " +
                      ' '.join(f'{v:06x}' for v in c['values']))
    body = '\n'.join(stimuli)+'\n'
    expected = '\n'.join(golden)+'\n'
    sources = [Path(__file__).resolve(), REF, ROOT/'sim/dilithium/run.do']
    sources += sorted((ROOT/'src/keccak').glob('*.sv'))
    sources += sorted((ROOT/'src/sampler').glob('*.sv'))
    sources += sorted((ROOT/'src/controller').glob('*.sv'))
    sources += sorted((ROOT/'tb/tb_dilithium').glob('*.sv'))
    h = hashlib.sha256((body+expected).encode())
    for p in sources:
        h.update(p.relative_to(ROOT).as_posix().encode()); h.update(p.read_bytes())
    token = h.hexdigest()
    header = f'{token} {len(rows)}\n'
    return rows, token, header+body, header+expected


def prepare():
    rows, token, stimuli, golden = artifacts()
    (HERE/'stage2_inputs.txt').write_text(stimuli, encoding='ascii')
    (HERE/'stage2_expected.txt').write_text(golden, encoding='ascii')
    print(f'PREPARE PASS: {len(rows)} jobs;88 successful,8 invalid-parameter errors,8 reset aborts;token {token}')


def check():
    rows, token, stimuli, golden = artifacts()
    if (HERE/'stage2_inputs.txt').read_text() != stimuli or (HERE/'stage2_expected.txt').read_text() != golden:
        raise ValueError('Stale source/reference/vector files: rerun prepare and capture')
    return rows, token


def verify(lines):
    rows, token = check()
    if not lines or lines[0] != 'H '+token:
        raise ValueError('Capture token differs;rerun simulation after prepare')
    opened, counts, finished = {}, {}, {}
    total_values = 0
    footer = None
    for line in lines[1:]:
        f = line.split()
        if f[0] == 'F':
            if footer is not None: raise ValueError('Duplicate footer')
            footer = list(map(int, f[1:]));continue
        i, core = map(int, f[1:3])
        if not 0 <= i < len(rows) or core not in (0, 1): raise ValueError('Unknown job/core')
        c = rows[i]
        if f[0] == 'J':
            if i in opened or int(f[3]) != c['id']: raise ValueError('Repeated/wrong descriptor')
            opened[i] = core;counts[i] = 0;continue
        if opened.get(i) != core or i in finished: raise ValueError('Unowned/retired output')
        if f[0] == 'C':
            index, value, last = int(f[3]), int(f[4],16), int(f[5])
            if index != counts[i] or index >= len(c['values']) or value != c['values'][index] or last != int(index==255):
                raise ValueError(f'Coefficient mismatch:case{i},index{index},observed{value}')
            counts[i] += 1;total_values += 1
        elif f[0] == 'S':
            if c['abort'] or int(f[3]) != c['code'] or counts[i] != len(c['values']):
                raise ValueError(f'Wrong status/count for case{i}')
            finished[i] = 'S'
        elif f[0] == 'A':
            if not c['abort'] or int(f[3]) != counts[i]: raise ValueError('Unexpected abort/count')
            finished[i] = 'A'
        else:raise ValueError('Unknown capture record')
    if len(opened) != 104 or len(finished) != 104 or footer != [104,88,8,8,total_values]:
        raise ValueError('Missing/extra jobs or incorrect footer')
    combinations = {(opened[c['i']],c['mode'],c['param']) for c in rows if not c['abort'] and c['code']==0}
    if len(combinations) != 24:raise ValueError('Missing mode/parameter/context combination')
    message = (f'DILITHIUM STAGE2 COMPARE PASS:104 jobs,88 complete,8 expected errors,8 reset aborts;'
               f'{total_values} exact coefficients (22528 complete-polynomial values plus checked aborted prefixes);'
               '24 mode/parameter/context combinations\n')
    return message


def compare():
    message=verify((HERE/'stage2_outputs.txt').read_text().splitlines())
    (HERE/'stage2_compare.log').write_text(message);print(message,end='')


def selftest():
    original=(HERE/'stage2_outputs.txt').read_text().splitlines()
    verify(original)
    ci=next(i for i,s in enumerate(original) if s.startswith('C '))
    ji=next(i for i,s in enumerate(original) if s.startswith('J '))
    si=next(i for i,s in enumerate(original) if s.startswith('S '))
    trials=[]
    for label,row,column,value in [
        ('value',ci,4,lambda v:f'{int(v,16)^1:06x}'),
        ('index',ci,3,lambda v:str(int(v)+1)),
        ('core',ci,2,lambda v:str(int(v)^1)),
        ('job_id',ji,3,lambda v:str(int(v)+1)),
        ('last',ci,5,lambda v:str(int(v)^1)),
        ('status',si,3,lambda v:str(int(v)+1)),
        ('case',ci,1,lambda v:'104'),
        ('footer',len(original)-1,1,lambda v:'103')]:
        lines=original.copy();f=lines[row].split();f[column]=value(f[column]);lines[row]=' '.join(f)
        trials.append((label,lines))
    trials += [('missing_coefficient',original[:ci]+original[ci+1:]),
               ('duplicate_descriptor',original[:ji]+[original[ji]]+original[ji:]),
               ('extra_coefficient',original+[original[ci]]),
               ('stale_capture',['H '+'0'*64]+original[1:])]
    for label,lines in trials:
        try:verify(lines)
        except ValueError:continue
        raise ValueError('Checker accepted corruption:'+label)
    message='STAGE2 CHECKER SELFTEST PASS:12/12 corruptions rejected\n'
    (HERE/'stage2_checker_selftest.log').write_text(message);print(message,end='')


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['prepare','check','compare','selftest'])
    try:
        command=p.parse_args().command
        if command=='check':
            check();print('STAGE2 VECTOR FRESHNESS PASS')
        else:{'prepare':prepare,'compare':compare,'selftest':selftest}[command]()
    except (ValueError,OSError,AssertionError) as e:
        raise SystemExit('STAGE2 FAIL: '+str(e))
