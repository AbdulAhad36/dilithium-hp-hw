# Stage2 focused integration regression;full Dilithium UVM comes later.
# Questa GUI,from sim/: do dilithium/run.do
if {[batch_mode]} {onerror {quit -code 1 -f}} else {onerror {abort}}
set launch [file normalize [pwd]]
if {[file exists [file join $launch stage2_inputs.txt]]} {
    set here $launch
} elseif {[file exists [file join $launch dilithium run.do]]} {
    set here [file join $launch dilithium]
} else {
    set here [file join $launch sim dilithium]
}
set repo [file normalize [file join $here .. ..]]
if {[catch {exec python [file join $here dilithium_vectors.py] check} freshness]} {error $freshness}
echo $freshness
set workdir [file join $here work]
if {![file exists $workdir]} {vlib $workdir}
vmap dilithium_work $workdir
set rtl [file join $repo src]
vlog -sv -work dilithium_work [file join $rtl keccak keccak_pkg.sv]
foreach n {keccak_param_unit keccak_absorb_unit theta_step rho_step pi_step chi_step iota_step keccak_step_unit keccak_output_unit keccak_core keccak_dual_interleaved} {
    vlog -sv -work dilithium_work [file join $rtl keccak ${n}.sv]
}
vlog -sv -work dilithium_work [file join $rtl sampler sampler_pkg.sv]
foreach n {sampler_secret_lane sampler_mask_unpack sampler_input_prepare sampler_ball sampler_compact sampler} {
    vlog -sv -work dilithium_work [file join $rtl sampler ${n}.sv]
}
vlog -sv -work dilithium_work [file join $rtl controller keccak_sampler.sv] [file join $repo tb tb_dilithium tb_keccak_sampler.sv]
vsim -voptargs=+acc -wlf [file join $here stage2.wlf] dilithium_work.tb_keccak_sampler +STAGE2_DIR=$here
onfinish stop
if {![batch_mode]} {
    view transcript;view wave
    add wave /tb_keccak_sampler/clk /tb_keccak_sampler/rst
    add wave -divider {Descriptor and absorption}
    add wave /tb_keccak_sampler/job_* /tb_keccak_sampler/input_*
    add wave -divider {Coefficient and completion}
    add wave /tb_keccak_sampler/output_* /tb_keccak_sampler/status_*
    add wave -divider {Bridge,drain and ownership}
    add wave /tb_keccak_sampler/dut/owned_r /tb_keccak_sampler/dut/drain_r /tb_keccak_sampler/dut/stop_r
    add wave /tb_keccak_sampler/dut/bridge_valid_r /tb_keccak_sampler/dut/hash_valid /tb_keccak_sampler/dut/hash_ready
    log /tb_keccak_sampler/* /tb_keccak_sampler/dut/bridge_valid_r
}
run -all
if {[examine -radix unsigned /tb_keccak_sampler/test_passed] != 1} {
    error "Stage2 test did not reach its explicit completion gate"
}
if {![batch_mode]} {wave zoom full}
echo {Run python sim/dilithium/dilithium_vectors.py compare from repository root for the independent verdict.}
