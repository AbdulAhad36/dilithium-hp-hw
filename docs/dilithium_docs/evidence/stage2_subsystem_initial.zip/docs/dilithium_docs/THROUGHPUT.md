# Dilithium cycles,throughput and implementation metrics

## Current boundary:Stage2 Keccak+sampler

The project at `quartus/dilithium/dilithium.qpf` currently synthesizes the real
Keccak+sampler helper,not a complete Dilithium accelerator. It will grow with the
controller,memory,NTT and process blocks. The user selected an initial148MHz
target:6.757ns,unchanged. The first combined fit is complete:129.18MHz worst Fmax and-0.984ns setup;
the requested148MHz timing target is NOT met.

Do not sum standalone module area or substitute the148MHz target for fitted
Fmax. All resource headlines use actual placed ALMs. Physical data I/O are
virtual/excluded from this internal benchmark;board timing is not closed.

## Functional-workload cycle observations

`sim/dilithium/stage2_jobs.csv` records104 jobs with case/ID/core/mode/param,
abort flag,and clock indices for command acceptance,first SHAKE beat accepted,
first sampler beat accepted,first/last coefficient,source stop and retirement.
The focused testbench has a6757ps rising-edge interval. Below are the22
successful jobs in each mode from this paired,stalled,boundary-length workload.

| Mode | Command acceptance → last coefficient | Command acceptance → first SHAKE beat accepted |
|---|---:|---:|
| Matrix A |749–1111 cycles|27–314 cycles|
| Secret |508–867 cycles|35–302 cycles|
| Mask |748–1143 cycles|31–296 cycles|
| Challenge |1027–1921 cycles|39–565 cycles|

These ranges include deliberately varied input lengths/source gaps,peer work,
and output/status stalls. They are not isolated sampler compute latency or a
continuous-throughput benchmark. Negative timestamp fields mean the event was
not reached before an error/abort. Completion rates must later be measured
under a specified workload,with first-to-last intervals and pipeline overlap
boundaries. No full KeyGen/Sign/Verify latency is claimed.

Current functional observations:drops99,bridge cancellations59,blocked hash
cycles33662,dual-owned cycles37980,and upstream-retirement waits287. These prove
the exercised control paths;they are not coverage percentages or throughput.

## Initial synthesis record

Combined settings: Cyclone V5CGXFC7C7F23C8,Quartus25.1std,seed1,HIGH PERFORMANCE
EFFORT,physical register retiming OFF. Both engines' accepted RTL remains
unchanged. The new scalar SHAKE-mode decode replaced a port expression that
Quartus interpreted as an implicit net;that initial diagnostic run was stopped
and excluded. The current full fit uses the corrected source.

The combined TimeQuest helper preserves original sampler payload/register
guards with hierarchy-qualified names. Current structural guards pass,while timing misses the target as recorded below. Pipeline/area
optimization belongs to the later measured-improvement stage;do not hide a
miss by lowering this user-selected target.

## First combined fit ? functional PASS,timing target OPEN

| Metric | Current Stage2 result |
|---|---:|
| Actual placed ALMs |11059|
| Registers |7396|
| Combinational ALUTs |16025|
| M10K / DSP |1 /0|
| Slow85 / Slow0 Fmax |129.18 /134.16MHz|
| Requested period |6.757ns (about148MHz),unchanged|
| Worst setup slack |?0.984ns|
| Worst hold slack |+0.166ns|
| Slow85 / Slow0 setup TNS |?1118.959 /?493.897ns|
| Hold TNS |0 at all four corners|
| Minimum pulse-width slack |+1.202ns minimum;positive at all four corners|
| Accepted sampler register guards |PASS,including original64-bit secret banks,140-bit commit payload and128 sign bits|

Quartus full compilation succeeds,but its timing-requirements warning is real.
The critical path is Keccak core1 absorb_block_full ? state_array registers,
with7.468ns data delay at the Slow85 corner;about78% of that path delay is
interconnect. See critical_paths/slow_85C_setup.rpt. It is not a sampler oracle
mismatch. The combined project has physical register retiming OFF,whereas the
standalone Keccak project enabled it. Retiming/placement/fanout are candidates
for a controlled review;their individual contribution is not yet measured.

This is an initial subsystem baseline,not an accepted148MHz implementation or
full-system PPA result. No target was relaxed. The user has been asked whether
to close timing before memory or keep the original functionality-first order.
No new trial is selected and no memory architecture is fixed until that choice.
