# Dilithium architecture

## Current implemented boundary:Stage2

```text
Job descriptor + complete absorption message
             |                     64-bit ready/valid
             v                            |
  controller/keccak_sampler.sv            v
     ownership/atomic start --> dual Keccak cores
             |                            |
             |               shared128-bit data/bytes/core
             |                            v
             |                    one-beat bridge
             |                            |
             +-- matching context --> sampler
                                          |
                         tagged23-bit coefficients + status
                                          |
                              external sink (testbench)
```

This helper will be controlled by the future `src/controller/dilithium.sv`.
No main algorithm controller,polynomial memory,NTT connection or complete
KeyGen/Sign/Verify implementation is present yet. Standalone engine RTL remains
unchanged. The user selected an initial combined target of about148MHz;the
Quartus project uses6.757ns and is not silently relaxed to close timing.

## Command and context ownership

`job_valid_i && job_ready_o` atomically starts Keccak and sampler for the core
actually assigned by Keccak. The descriptor contains job ID,sampling mode,
parameter encoding,and the absorption-message byte count. The source supplies
those message bytes on the shared64-bit ready/valid port. Seed/nonce assembly
is external at this stage;the adapter does not implement full algorithm encoding.

Mode0 explicitly selects SHAKE128;all other sampling modes select SHAKE256.
The decode uses a dedicated scalar wire. Quartus treated the original
package-qualified constant in a port expression as an implicit net despite
Questa accepting it. That build was stopped and excluded;the current adapter
uses explicit net declarations and `default_nettype none`.

Two ownership bits keep a descriptor live until the external status handshake.
An idle Keccak core cannot be reused while its old sampler job/status still owns
it. The inherited Keccak dispatch preference can cause head-of-line command
waiting when its chosen idle core is still owned;this baseline favors simple
ownership over new dispatch scheduling. Performance optimization follows later.

## Bridge and backpressure

One shared registered beat stores128 data bits,a5-bit byte count,a core tag and
valid. Required data is forwarded in order;the existing sampler handles its
64-bit chunks internally. A beat can be replaced when consumed or canceled.
No deep FIFO or polynomial memory was added. Readiness propagates conservatively
when the register is full;the peer stream may wait behind a blocked shared beat.

Sampler `source_stop` explicitly cancels surplus unaccepted sampler-input offers.
Such offers belong to the old job and must not enter its replacement. This is a
documented internal cancellation boundary;ordinary public coefficient/status
offers remain stable under backpressure until accepted or reset.

## Drain,stop and completion

The adapter never wires sampler stop directly to Keccak stop:

1. The sampler requests stop after successful generation or an error.
2. The adapter marks that context draining and cancels its surplus bridge beat.
3. It accepts/discards a further offered SHAKE beat for that context. This
   handshake releases the shared Keccak output lock,even under downstream stalls.
4. It registers Keccak stop AFTER that handshake and holds stop through any
   intervening permutation until the core returns idle.
5. It exposes the sampler's status only when that core is idle and no bridge
   token from the job remains. Status acceptance releases ownership.

The peer context is retained throughout. The selected sampler status may wait
for its hash core,so another status can experience head-of-line waiting. Arbitrary
permanent sink stalls or missing declared message bytes cannot guarantee progress.
The producer must send the declared message;coordinated reset cancels a job that
cannot finish absorption. This stage has no independent per-job cancel command.

Continuous SHAKE uses `output_len_i=0`;sampler input_last is0. Bounded-XOF
exhaustion/refill is outside this stage's interface and is not simulated by
calling a rate-block boundary the end of a polynomial.

## Reset and validation hooks

One shared clock is used. Hold active-high reset through rising edges so both
the asynchronous Keccak controls and synchronous sampler controls reset.
Ownership,bridge valid and stop/drain state cancel together. The focused test
then reuses job IDs with different messages to expose stale-state leakage.

Source assertions reject unowned hash/bridge tokens,premature reuse and invalid
hash byte counts. The testbench additionally checks stable coefficient/status/
Keccak offers and proves every stop rise follows a discarded release handshake.
The combined TimeQuest helper checks the original accepted sampler payload and
reservation register counts with hierarchy-qualified patterns. These checks
complement tests;they are not formal proof or full security signoff.
