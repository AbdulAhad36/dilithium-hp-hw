# Dilithium design and integration plan

## 1. Purpose and current status

**Integration means the Dilithium project.** This is the shared roadmap for
connecting our accepted Keccak, sampler and NTT, building the controller and
memory, adding the remaining processing blocks, and verifying the complete
accelerator. Do not create a second plan for the same work under another name.

The working branch is `integration`, created from `sampler_v1` at `e1b9c84`.
The sampler is already present. Its accepted Stage4.9r implementation has
3537 actual placed ALMs, 164.74 MHz worst Fmax, +0.430 ns setup and +0.141 ns
hold at a 6.500 ns constraint. Stage5 source, post-synthesis and post-fit checks
passed. These are **standalone sampler results**, not integrated design metrics.

Keccak is imported from `keccak_v2` at `fe54a78` and its standalone relocation
checks pass. NTT remains on `ntt_v2` until its integration stage. Full Dilithium
RTL,memory,controller,integrated verification and system synthesis are not
implemented yet. See SPECIFICATION.md for exact snapshot provenance.

The user has approved this structure and incremental import approach and has
authorized starting Stage1. Ask before major architecture decisions,report what
was done and verified at each stage,and always state the next step. Do not
commit or push subsequent work without an explicit request.

## 2. Agreed folder structure

```text
src/
  keccak/                         # Keccak RTL, imported when needed
  ntt/                            # NTT/INTT/PWM/Pre-NTT RTL
  sampler/                        # Accepted sampler RTL
  controller/
    process/                      # Decompose, hints, Power2Round, etc.
    memory.sv                     # Polynomial memory subsystem
    dilithium.sv                  # Main controller/top-level RTL
    ...                           # Scheduling, routing and interface helpers

tb_uvm/
  tb_uvm_reusable/                 # Shared reusable verification components
  <individual module UVM folders>/
  tb_uvm_dilithium/                # Full Dilithium UVM, when that stage begins

tb/
  tb_dilithium/                    # Focused integration testbenches as needed

sim/
  keccak/                         # Individual Keccak simulation
  ntt/                            # Individual NTT simulation
  sampler/                        # Individual sampler simulation
  dilithium/                      # Evolving full-design simulation project

quartus/
  keccak/                         # Individual Keccak synthesis project
  ntt/                            # Individual NTT synthesis project
  sampler/                        # Individual sampler synthesis project
  dilithium/                      # Evolving full-design synthesis project

docs/
  keccak_docs/                     # Imported module documentation/evidence
  ntt_docs/                        # Imported module documentation/evidence
  sampler_docs/                    # Existing module documentation/evidence
  dilithium_docs/                  # Universal full-design documentation
    DILITHIUM_PLAN.md
    ...
```

Use the spelling `controller` consistently. `dilithium.sv` is the main
controller/top; helper modules can live beside it. Processing arithmetic belongs
under `src/controller/process/`; memory implementation helpers can live under
`src/controller/` if `memory.sv` needs them. Additional files must have a clear
purpose rather than forcing an entire subsystem into one large file.

Testbench source belongs in `tb/` or `tb_uvm/`, RTL in `src/`, launchers and
generated simulation output in `sim/`, and synthesis projects in `quartus/`.
Create folders and runnable scripts when used; do not create empty test launchers.

## 3. Import an individual module as a complete package

Bring modules in as integration reaches them. Each import includes:

1. The selected accepted RTL and required ROM/table/initialization files.
2. Its existing UVM testbench and independent reference/checking assets.
3. Its standalone simulation launchers and required vector/reference files.
4. Its standalone Quartus project, constraints and synthesis helper scripts.
5. Its module documentation and relevant accepted evidence.

Keep standalone module verification and synthesis runnable on this branch.
Retain each module's existing UVM folder name unless an actual naming conflict
requires a documented change. Map imported RTL to `src/keccak/` and `src/ntt/`,
and update file lists, relative paths, include paths, ROM paths and project
assignments. Check for package/module/library collisions before compiling all
three together. Re-run the relevant standalone checks after relocation.

Record branch, commit, original paths, destination paths, changes and verification
in the shared Dilithium specification. Preserve frozen imported evidence exactly;
its historical paths and standalone metrics describe the original build. New
verification records must identify the relocated build separately.

Do not merge whole branches or import historical experiment trees and obsolete
generated databases merely to obtain a module. Preserve the accepted branches.
The evolving `sim/dilithium/` and `quartus/dilithium/` projects must use the current
combined source set as each part is added.

## 4. One documentation set for all integration milestones

All integration work updates **the same documents in `docs/dilithium_docs/`**.
A Keccak-to-sampler milestone and a later memory-to-NTT milestone are sections
of these documents, not separate documentation suites. Individual imported
module documentation remains under its own module folder for standalone use.

| Document | Contents and when to create/update it |
|---|---|
| DILITHIUM_PLAN.md | This roadmap, agreed structure, stages, current status and next work |
| README.md | Navigation, actual simulation/synthesis commands and current supported scope |
| SPECIFICATION.md | Supported algorithm/version/parameters, exact imported snapshots, ports, reset/clock and command contracts |
| ARCHITECTURE.md | Datapath, controller, adapters, routing and memory connections |
| PROCESS_FLOW.md | Step-by-step data movement, scheduling and eventual KeyGen/Sign/Verify sequences |
| MEMORY_MAP.md | Polynomial layout, banks/ports, allocation, addresses, lifetimes, ownership and arbitration |
| INTEGRATION_VERIFICATION_TESTPLAN.md | Full-design requirements, independent checking, tests and later detailed UVM/coverage plan |
| THROUGHPUT.md | Measurement boundaries, cycles, stalls, loading/compute/output time, system throughput, placed ALMs, Fmax and slack |
| COVERAGE.md | Functional/code coverage, bin-hit justification, observed gaps and implementation-verification scope |
| PIN_CONFIG.md | Full-design top-level virtual pins, widths and meaning; physical assignments only when actually selected |
| REFERENCE_VERIFICATION.md | Reference provenance, vectors, file formats, preparation/capture/comparison commands and measured results |

Create each document when its work becomes concrete and maintain it throughout
the project. Do not fill documents with invented results or runnable placeholders.
Separate proposed targets, standalone historical metrics and measured system data.
Store only useful milestone evidence; avoid a new JSON/archive for every small trial.

## 5. Initial architecture and interface decisions

The starting datapath is:

```text
Commands / seeds / messages
             |
    dilithium.sv controller
      | scheduling / memory ownership / error handling
      v
 Keccak -> Sampler -> Polynomial memory <-> NTT/INTT/PWM/Pre-NTT
                            ^
                            |
                  controller/process blocks
```

This is a starting structure; finalize the detailed contracts before wiring it.

- Keep Keccak's shared 64-bit input and tagged 128-bit output interfaces.
  The current sampler accepts 128-bit beats and processes ordered 64-bit chunks
  internally. This does not become native128 sampling merely through connection.
- Associate the sampler job with Keccak's actual accepted core assignment.
  Maintain the complete job ID, sampling mode, parameters, seed/nonce and
  destination. A core/context number alone is not a permanent polynomial ID.
- Define continuous SHAKE operation, sampler completion/stop requests,
  already-offered output handling and safe context reuse. Finite-source handling
  must not repeat SHAKE prefixes, insert zero padding or silently truncate data.
- Resolve reset conventions at the top level. Preserve each module's defined
  reset behavior and verify cancellation, draining and subsequent fresh work.
- Keep canonical 23-bit residues at the current sampler/NTT boundary. Check
  transform ordering, modular representation and scaling explicitly when
  comparing software; do not equate an intermediate Montgomery representation
  with canonical coefficients without the required conversion.
- Matrix A sampling already produces transform-domain values. Route them to
  operand storage/PWM, not through an unnecessary forward NTT. Ordinary secrets
  can use forward NTT or the existing eligible Pre-NTT operation. Assign one
  owner for Pre-NTT so its first stage is never applied twice.
- Use one shared clock initially, with an operating target selected from the
  imported modules' constraints and actual integrated timing. Standalone sampler
  Fmax is not an integrated Fmax guarantee.

### Memory decisions to settle before implementation

The sampler can interleave two jobs; the current NTT wrapper handles one complete
operation at a time and transfers one 23-bit coefficient per beat. Use memory
to separate polynomial ownership and production/consumption schedules.

Define 256-coefficient polynomial storage, coefficient addresses, domain metadata,
slot allocation and states such as free/writing/complete/in-use. Set the actual
bank/slot count from the first workload and expected live ranges. Do not invent
a large all-parameter memory allocation before deriving capacity and port demand.

Mark a sampled polynomial usable only after successful completion. Invalidate
partial results on errors/abort. Track both PWM operands, writeback ownership,
simultaneous read/write hazards and reset/reuse. Preserve input polynomials still
needed by later operations. Add ping-pong storage or more ports when measurements
justify them. Wider NTT ports and deeper queues are later measured changes.

## 6. Execution stages and completion gates

Announce the stage before starting it. Work in bounded steps and update these
universal docs after each meaningful milestone. A passing subset must not be
reported as complete Dilithium or complete verification.

| Stage | Work | Evidence required before moving on |
|---|---|---|
| 1 — Contracts and imports | Inspect accepted snapshots, import Keccak with its standalone assets, define commands/reset/tags and initial memory contracts | Relocated standalone checks pass; interface and source provenance documented |
| 2 — Keccak + sampler | Feed real SHAKE outputs into all four sampling modes; handle two contexts, stop/drain, valid bytes and backpressure | Seeded polynomial outputs match independent expectations; ordering, context reuse, reset and errors checked |
| 3 — Memory | Implement memory.sv, allocation, write/read paths, completion validity and arbitration | Exact polynomial readback; no mixing, overwrite, stale reuse or premature reads under stalls/abort |
| 4 — NTT integration | Import accepted NTT with all standalone assets; connect load/command/result paths through memory | Sampled/transformed outputs and polynomial operations match software with explicit domain/scaling conventions |
| 5 — Controller and remaining processes | Build dilithium.sv scheduling and required process blocks; begin with sequential operation schedules | Each added process and full supported flow produces independently checked outputs; rejection/retry and error handling exercised |
| 6 — Full-operation reference/NIST flow | Complete the supported KeyGen/Sign/Verify interfaces and file-based capture/comparison | Exact official-vector comparisons for the declared algorithm/parameter/mode; limitations and unsupported cases explicit |
| 7 — Full UVM and synthesis optimization | Build comprehensive Dilithium UVM/coverage, synthesize the whole design and improve timing/area/throughput | Correctness retained; detailed functional/code coverage and honest gaps; fresh measured PPA and positive timing at the agreed operating clock |
| 8 — Implementation and FPGA verification | Verify distinct whole-design synthesis/fit netlists, then board interfaces and hardware testing | Implementation checks and timing reports; FPGA results only after actual execution |

The remaining processing work includes polynomial add/subtract, matrix-vector
accumulation, rounding/Power2Round, decomposition, norm checks, hint creation/use,
packing/unpacking, signing rejection/retry control, and seed/nonce/message/key
handling. Define and verify the exact required subset as each algorithm flow is
implemented. Three connected engines alone do not implement all these functions.

### Testing during integration

Focused, efficient non-UVM integration testbenches are explicitly allowed.
Use them to supply real jobs, exercise boundary conditions, dump outputs and
compare with independent models. They must be self-checking and reproducible.
They do not replace the imported standalone UVM suites or justify later full
UVM coverage claims. Keep focused testbench source under `tb/tb_dilithium/`.

After one connection produces the required outputs, add the next block and
repeat independent checking. Start with serial schedules to make faults easy
to locate. During the later optimization stage, overlap sampling, arithmetic
and memory traffic only with ownership/dependency checks and measured benefit.

The full-fledged Dilithium UVM campaign and primary PPA optimization follow
correct end-to-end outputs and the full-operation reference/vector milestone.
Earlier compile/synthesis checks may establish feasibility, RAM inference and
resource limits; they do not imply that full verification or optimization is done.

### Full-operation vector flow

Use the same explainable pattern as Keccak: input vectors -> RTL execution ->
captured outputs -> a separately executed Python comparison command -> explicit
PASS/FAIL with case counts and mismatch details. Keep the reference independent.

At that stage obtain official NIST/ACVP full-operation vectors and record exact
source/version/provenance. Define whether the implementation targets final
FIPS 204 ML-DSA or a legacy Dilithium variant, including parameter names,
message/context formatting and supported operation interfaces. Never silently
mix incompatible vectors or assume legacy reference code is a full FIPS oracle.
Control the specified seed/randomness inputs for exact randomized-operation
comparisons; verification vectors require correct accept/reject outcomes too.

Do not claim official standalone sampler or NTT vectors. Their existing
FIPS-derived/reference checks remain useful component evidence. Full-operation
vector equality is not itself NIST validation or certification.

### Later full UVM, synthesis and optimization

Define the complete feature/test/coverage plan, then exercise modes/parameters,
command sequences, queues, memory hazards, concurrent jobs, stalls, invalid
requests, reset/abort/recovery and signing retries. Credit successful functional
observations only after independent checking. Report raw and averaged coverage
metrics clearly; do not fabricate bins or suppress hits to impose a percentage.

Measure full command-to-completion latency and sustained completion interval,
SHAKE/sampler waiting, memory occupancy/conflicts, NTT load/compute/output and
controller overhead. Report actual placed ALMs, registers, RAM/DSP, worst Fmax,
constraint and worst-corner setup/hold/TNS. Standalone virtual-pin closure is
not board I/O closure. Preserve correctness while improving measured bottlenecks.

The full design will have three main `.do` launchers when implemented: source
UVM with GUI/waves/functional and code coverage, post-synthesis, and post-fit.
Focused early tests can use selectable modes or supporting Tcl/scripts in the
same `sim/dilithium/` project. Use supported vendor functional netlists and
TimeQuest timing evidence; do not promise unsupported Cyclone V SDF simulation.

## 7. Next action and status tracking

**Current milestone:Stage2 functional PASS;148MHz timing target OPEN.**
The real Keccak+sampler helper is implemented under src/controller and exercised
by the focused testbench under tb/tb_dilithium.104 jobs pass:88 complete,
8 expected parameter errors,8 reset aborts,and23081 exact coefficient checks.
All24 mode/parameter/context combinations are observed;12 checker corruptions
are rejected. The user chose about148MHz as the initial combined synthesis
target:6.757ns. The first combined fit has11059 placed ALMs,129.18MHz Fmax,-0.984ns setup
and+0.166ns hold at that unchanged target;the148MHz goal is not met.
Original sampler structural guards pass. Evidence:evidence/stage2_subsystem.zip.
No polynomial memory,NTT connection,main algorithm controller or full-operation
NIST/UVM completion is claimed. See ARCHITECTURE.md,PROCESS_FLOW.md,
REFERENCE_VERIFICATION.md and THROUGHPUT.md.

**Prior milestone:Stage1 Keccak import and standalone revalidation PASS.**
Keccak RTL/UVM/vector/module-doc assets are imported,with original RTL/UVM
bytes preserved. Path adapters pass the904-transaction source suite plus dual
regressions,and all6364 captured outputs match3182 published NIST cases on
both cores. Fresh standalone Quartus:8058 actual placed ALMs,149.63MHz Fmax,
setup+0.074ns/hold+0.166ns at6.757ns. All four corners have zero setup/hold TNS.
These are standalone metrics from the prior import milestone.
Evidence:evidence/keccak_import.zip+SHA256.

Current source snapshot:keccak_v2 at fe54a782e3df9ed684dc960b0067b39ce323289d.
See SPECIFICATION.md for source provenance,path mapping and initial contracts.
Next:await the user's priority choice after the measured timing miss:continue
functional integration/memory as planned,or close timing before Stage3. Propose
memory capacity/banking/ownership for approval before implementing it. The user selected LightHD's full CRYSTALS-Dilithium
scope:KeyGen,Sign and Verify at all three security levels2/3/5;bring up level2
first. Audit exact algorithm/encoding compatibility before choosing the full
NIST/reference vector suite. The paper's level names and draft-standard citation
must not be treated as proof of final FIPS204 byte compatibility. See the
algorithm-scope decision in SPECIFICATION.md. The initial clock is now6.757ns;
memory architecture and later major changes require user agreement.

| Milestone | Revision and workload | Result | Limitation / next action |
|---|---|---|---|
| Stage1 Keccak package relocation | keccak_v2 fe54a782e3df9ed684dc960b0067b39ce323289d;904 source UVM transactions plus dual suites;3182 NIST cases per core;full standalone Quartus compile | PASS;RTL/UVM unchanged;6364 exact NIST matches;positive multicorner timing | No new netlist simulation or connected datapath. Next:Stage2 adapter and user-confirmed major decisions |
| Stage2 real Keccak-sampler source connection |104 generated subsystem jobs;88 complete,8 expected errors,8 aborts;23081 exact values;12 checker faults | Source/Python PASS;four reset phases,stop/drain,backpressure and same-ID recovery exercised | Fit11059 placed ALMs/129.18MHz/?0.984ns setup at6.757ns;structural guards PASS;timing target open,priority decision pending |

Maintain a concise milestone table here with the stage, source revision,
workload, explicit check result, measured limitations and next action. Keep the
same specification, process, memory, throughput and verification documents as
the system grows; do not start a parallel suite for each pair of modules.
