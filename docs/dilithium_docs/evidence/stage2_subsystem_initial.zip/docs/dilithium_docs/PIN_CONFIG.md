# Dilithium current interface and virtual pins

Current synthesis top:`keccak_sampler`,the Stage2 subsystem helper. The future
`dilithium.sv` top will extend this table when main-controller interfaces exist.
All181 non-clock bits are assigned virtual pins;clk is the one physical clock
input with fitter-selected placement. No board/package assignment is selected.

| Port | Direction | Bits | Meaning |
|---|---|---:|---|
| clk | Input |1|Shared clock,target6.757ns/about148MHz |
| rst | Input |1|Active-high coordinated reset;hold through rising edges;abort both contexts |
| job_valid_i / job_ready_o | Input/output |1 each|Descriptor ready/valid transfer |
| job_core_o | Output |1|Actual assigned Keccak/sampler context on command acceptance |
| job_id_i | Input |16|Polynomial/job ID |
| message_len_i | Input |16|Complete absorption-message byte length,0..65535 |
| job_mode_i | Input |2|0=A,1=secret,2=mask,3=challenge |
| job_param_i | Input |2|0/1/2 select level2/3/5 parameters;3 yields parameter error |
| input_data_i | Input |64|Message bytes,earliest in low byte;declared length controls final partial word |
| input_valid_i / input_ready_o | Input/output |1 each|Message ready/valid transfer |
| output_data_o | Output |23|Canonical coefficient0..8380416 |
| output_core_o | Output |1|Result context |
| output_id_o | Output |16|Result job ID |
| output_index_o | Output |8|Ordered coefficient index0..255 |
| output_last_o | Output |1|Index255 |
| output_valid_o / output_ready_i | Output/input |1 each|Coefficient ready/valid transfer |
| status_valid_o / status_ready_i | Output/input |1 each|Completion/error ready/valid;source drained before external offer |
| status_core_o | Output |1|Completed context |
| status_id_o | Output |16|Completed job ID |
| status_code_o | Output |3|Existing sampler status encoding;current tests exercise OK0 and parameter error3 |
| active_o | Output |2|Context ownership until external status acceptance |

Hold producer payloads stable while valid and not ready. Public output/status
offers remain stable until accepted or reset. input_data_i belongs to the
currently accepted Keccak message;new absorption messages are serialized by its
ingress protocol. Reset discards old jobs;it does not securely erase all data.
Independent per-job cancellation,finite-XOF length controls and memory APIs
are not exposed by this helper.
