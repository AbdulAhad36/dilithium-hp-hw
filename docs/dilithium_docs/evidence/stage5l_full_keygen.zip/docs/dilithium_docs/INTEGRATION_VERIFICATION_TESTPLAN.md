# Dilithium verification test plan

## Stage5L complete key serialization and PK hashing

| Requirement | Checked behavior |
|---|---|
| Complete keys |8 successful keypairs equal unchanged C KeyGen bytes;all levels2/3/5 |
| Independent hash |All2058 accepted PK absorption words and656 tr bytes compare independently;includes abort prefixes |
| Tagged output |5433 exact64-bit words;per-key index,ID,type,last,length and PK-before-SK order |
| Read ownership |11179 field-read metadata records follow t1,s1,s2,t0 order with exact region/owner/level/domain |
| Shared resources |Real raw service and existing banks/Bitpkg;no testbench-generated hashes/coefficients |
| Fork |Independent hash/host backpressure;stable held words,no duplicate delivery;both acknowledgement orders |
| Reset |Hash-first stalled PK header,partial PK,tr first beat,partial SK secret field,held overall completion |
| Recovery |Same-ID different-xi recovery;three ordinary operations restart without reset;ID65500 internal wrap |
| Lifetime |Retained sources cannot release before overall done handshake;zero reservations before next start |
| Rejects |Invalid level and unimplemented Sign/Verify:no keys,hash requests or field reads |
| Checker |35 corruptions rejected,including duplicate delivery,missing hash done,wrong SK bytes and early release |
| Remaining gates |Official NIST full-KeyGen vectors,Sign/Verify controllers,full-system UVM and PPA |

This focused source test is selector full_keygen in the existing launcher.
Earlier15 tests remain separate regression gates. Complete byte agreement
with a local software reference is distinct from published-vector conformance
and from exhaustive functional/code coverage.

## Stage5K rounded KeyGen and polynomial packing

| Requirement | Evidence |
|---|---|
| P2R connection |34 delivered rows at all levels;both rounded arrays committed before row publication |
| Rounded retention |t1/t0 survive later rows and are read before overall completion;cleanup/reuse/reset checked |
| Arithmetic/metadata |190224 scalar values,12800 exact92-bit reads,rounded pair IDs/regions and domain metadata |
| Rounded checker |36 corruptions rejected,including both array values/IDs and missing high commit |
| Bitpkg formats |t1,t0,secret eta2/eta4;all three levels,six data patterns per format/level |
| External reference |66 valid fixture packets/18496 bytes equal unchanged C polynomial packers |
| Malformed packets |31 expected errors;invalid command/level,value,index,last;final status invalidates prefix |
| Stalls/reset |Held outputs/completions;six aborts and same-ID different-data recovery;18292 accepted inputs,2482 exact words |
| Bitpkg checker |15 corruptions rejected |
| Remaining scope |Bank read/packer connection,complete key field order,public-key hash,encoded key outputs and official whole-operation tests |

No new full-system coverage percentage or PPA result follows from these directed
gates. Existing thirteen selectors remain regression baselines;the two new
selectors are rounded_keygen and bitpkg in the same run.do/Python script.

## Stage5J autonomous KeyGen polynomial phase

| Requirement | Checked workload |
|---|---|
| Autonomous control |Bench drives start/read controls only;all seed,nonce,transform,matrix,row and ADD commands originate in RTL |
| Full parameter coverage |All s1/s2 nonces and all matrix positions for levels2/3/5;canonical23-bit residues |
| Arithmetic/output |34 complete t=A*s1+s2 rows;172304 scalar writes;8448 exact92-bit public reads |
| Independent model |hashlib plus sampler/direct NTT references;alternate coefficient-domain schoolbook row0 at every level |
| Retention/reuse |Raw s1/s2 and transformed s1 read back before overall completion;transform cache reused across rows |
| Boundaries |Invalid level,unsupported Sign/Verify with no child side effects;ID65500 wrap |
| Reset |Partial seed,first secret prefix,held first output row,partial accumulator rewrite;different-xi same-ID recovery |
| Ownership |Held row/final completion;136 pending-read handoff checks;no region released while final row response is held |
| Cleanup |Exact release order,zero remaining reservations,normal operations restarted without reset |
| Checker integrity |29 deliberate corruptions rejected |
| Limits |Polynomial phase only;no encoded key bytes/official full-operation vectors/full-system UVM or PPA |

The existing twelve focused gates remain independent regressions after source
relocation and Power2Round extraction. Their coverage/metrics are not combined
into a claimed full-Dilithium verification percentage.

## Stage5I seed-to-row connection

| Requirement | Evidence / limit |
|---|---|
| Seed expansion |20 actual expansions at all3 levels;2560 bytes equal hashlib SHAKE256(xi||k||l) |
| Retained material |Exact rho,rho-prime,K and level/valid checked at every source completion |
| Real messages |163 sampling jobs;1103 accepted absorption words checked byte-for-byte including zeroed unused high bytes |
| Memory/row outputs |Existing row checker validates every scalar/packed write,ack,publication,NTT/ADD result and12544 exact92-bit reads |
| Reject before side effects |7 expected adapter errors;no raw request,bank allocation or sample descriptor on rejection |
| Completion ownership |Tagged raw output/done,matching sample ID/core,full hash retirement and bank commit before source done |
| Held result |4-cycle held completion on all190 source commands;seed fields stable and command-ready low |
| Reset/reuse |7 row-phase resets with seed/bank invalidation and successful re-expansion/recovery |
| Independent checks |6 schoolbook reference rows,C ADD results;23 checker corruptions rejected |
| Not yet covered here |All s2 nonces,all matrix rows,seed-phase reset sweep on this wrapper,autonomous KeyGen,key bytes,full-system UVM/PPA |

Use existing testbench parameter SEED_SOURCE=1 through selector5/seed_row;
SEED_SOURCE=0 preserves selector5/row. The eleven earlier focused gates remain
separate regressions. Do not report their counts as one full-operation suite
or interpret these directed tests as a functional/code coverage percentage.

## Stage5H reusable row scheduling

| Requirement | Checked behavior |
|---|---|
| Full row mathematics |4/5/7-column rows at all levels;two distinct matrix rows per level;direct-transform and coefficient-domain schoolbook agreement |
| Real producers |163 actual SHAKE/sampler jobs;FIPS-format A/secret messages;ordinary NTT and eligible Pre-NTT secret transforms |
| Row schedule |First PWM -> accumulator;later PWM -> scratch;in-place ADD -> same accumulator;scratch release;final inverse -> coefficient output;accumulator release |
| Retained operands |Transformed secrets reused between rows without retransform;complete raw/transform/matrix readbacks prove preservation |
| Rewrite safety |6918 old-word cache reads match old accumulator/product,updated owner and untouched write frontier;96264 scalar writes/24066 packed writes/acks checked |
| Descriptor rejection |Invalid level/row,workspace alias/busy,stale A/S,wrong parameter,untransformed secret,missing matrix;no child arithmetic |
| Exclusive ownership |External jobs/compute/reads/releases blocked during row;held completion protects result/sources;pending public read blocks row acceptance |
| Reset |Validation,PWM execution,first accumulator result,partial rewrite,scratch release,inverse execution,held row completion;IDs reused with different matrix row |
| Campaign |13 successes,27 rejections,7 aborts;12544 exact92-bit public reads;160 held-row refusal checks and4 pending-read checks |
| Checker integrity |26 deliberate corruptions rejected,including missing column work,commit/ack,wrong cached old value/frontier and row output |

This gate uses selector5/row and the existing script/launcher. It verifies the
tested staged-row product u=A*s1,not s2 addition,KeyGen byte encoding,NIST whole-
operation conformance,full-system UVM coverage or PPA. In-place ADD is tested;
in-place SUB is exposed by the generic DMA but is outside this row workload.

## Stage5G banked process/NTT chains

| Requirement | Checked behavior |
|---|---|
| Shared ownership |PROCESS_SERVICE=1;one store/four banks;sampling,NTT and process sequential;pending public reads block process commands |
| Arithmetic domains |ADD/SUB accept matching domains/parameters;P2R coefficient domain only;missing/stale A/B and invalid opcode reject |
| Destinations |Aliasing A/B or P2R high/low rejects;busy explicit destinations wait;unrelated release unblocks them |
| Real chains |23 real sample jobs;15 real NTT commands;PWM -> ADD/SUB -> INTT -> ADD -> P2R,then stored low -> NTT |
| Canonical low/high |Signed low converted modulo q for storage;high zero-extended10-bit;all signed low/high/encoded t0 arithmetic outputs match Python/C |
| Physical storage |22297 scalar writes,5574 packed writes/acks;correct ID,region,core,lane/index/value;8512 exact92-bit readbacks |
| Atomic pair |Two P2R commits;22 actual snapshots prove no partial public visibility;held completion protects both destinations |
| Reset |Before DMA,partial arithmetic writeback,between low/high writes,and between low/high commit;old descriptors invalid;ID reuse with different inputs |
| Campaign |71 process commands:34 successes,33 expected rejections,4 reset aborts;8978 input beats/8976 completed results |
| Checker fault gate |29 corruptions rejected,including false partial visibility,missing high commit,wrong signed low/encoded t0 and physical memory corruption |

The full262-action program must retire without missing actions. Python models
ownership/packing/acknowledgements and arithmetic independently;the C reference
cross-checks actual captured process operands/outputs. These are focused source
tests,not a full-system coverage percentage,formal proof,whole-operation KAT or
PPA result. Next:row multiply/accumulate scheduling and first full KeyGen control.

## Stage5F banked sampling/NTT/result gate

| Requirement | Checked behavior |
|---|---|
| Real connected outputs |16 actual Keccak/sampler jobs;all4 NTT operations,all3 parameters;direct NTT/inverse and schoolbook references |
| Source eligibility |Missing/stale A and B;matrix already transformed;PWM parameter/domain checks;Pre checks actual[-4,4] bounds |
| Destination safety |Both A/B alias cases rejected;occupied distinct destination waits;unrelated release unblocks it |
| Source leases |Protected from acceptance through completion retirement,including waiting for destination;source data preserved |
| Packed DMA |64 words/unary,128/PWM;four low-first scalar lanes/word;exact ID/index/value order;A==B and same/different banks |
| Physical writeback |2952 packed writes and2951 acknowledgements checked by Python;publication requires64 acknowledged words |
| Read/result ownership |Held external read prevents compute acceptance;held result prevents destination release;metadata/domain/small flags checked |
| Reset/recovery |Load,core execution and partial packed writeback aborted;no stale region publication;IDs reused with different inputs |
| Exact campaign |54 commands:30 results,21 expected rejections,3 aborts;2944 exact92-bit readbacks=11776 coefficients |
| Checker integrity |19 deliberate corruptions rejected,including missing packed ack,wrong lane data/region/index/domain/bounds,missing publication and stale token |

This gate uses the single launcher/script with selector5/bank_ntt. It establishes
the tested banked connection,not a full KeyGen result,formal proof,full-system UVM
coverage or new PPA measurement. Banked process reads/writeback and row scheduling
are the next integration requirements.

## Stage5E connected packed-bank sampling

| Requirement | Checked behavior |
|---|---|
| Atomic reservation |Actual core/ID bound to caller's bank/region;occupied destination cannot accept replacement |
| Context isolation |Interleaved coefficient streams use separate92-bit packers;same/different destination banks |
| Physical word correctness |23-bit low-first lanes;all5792 bank writes independently compared before readback |
| Durable publication |64 write acknowledgements and256 coefficients plus matching external success;held success does not publish |
| Word reads |5632 completed92-bit words;ID/mode/parameter/domain/bounded metadata checked;invalid/partial/reset regions reject reads |
| Release/reuse |Matching pending read blocks release;same-index fresh jobs update all data/metadata;all64 regions fill |
| Error/reset |8 expected parameter errors free reservations;8 partial jobs aborted;held successful/error read responses reset |
| Internal protocol faults |Wrong index,last,value,ID/core;premature/wrong-ID status;extra coefficient all halt publication until reset |
| Checker fault gate |12 corruptions rejected,including missing physical write and altered bounded/domain bits |

104 jobs,88 completed polynomials,22528 complete coefficient readbacks. Tests
use actual Keccak/sampler and independent Python expectations. Stage5F above adds
NTT source locks/compute writeback. Packed narrow fields and full-phase scheduling
remain future connected requirements. No new coverage percentage is reported.

## Stage5D bank-memory foundation gate

| Requirement | Implemented check |
|---|---|
| Published geometry |Four independent1024x92-bit logical banks;two ports each |
| Full address/lane capacity |Initialize all4096 words;read all through both ports;compare full92 bits |
| Dual-port hazards |Same-address read/read accepted together;read/write and write/write serialize with A priority |
| Independence |Simultaneous access to all eight ports and independent per-port stalls |
| Elastic responses |Replace consumed response without bubble;hold read data/address/type under stall |
| Reset |Eight held write acknowledgements canceled;eight blocked offers unaccepted;payload retention and canceled-write absence checked |
| Independent reference |Python word dictionary and per-port response queues;exact accepted request/response ledger |
| Checker fault gate |12 corruptions rejected:payload,address,bank,port,type,ID,latency,missing/duplicate records,token/footer/reset |

Measured:14872 accepted,14864 responses,9509 exact reads,5355 write acks,8
reset-aborted acks. This is storage-primitive verification,not full algorithm
coverage or completed four-bank migration. Region ownership/locks,packing,
DMA/process routing and safe phase reuse still need their own connected tests.

## Stage5C shared raw-SHAKE and seed gate

| Requirement | Implemented check |
|---|---|
| One real shared engine |RAW_SERVICE=1 in existing keccak_sampler;no extra Keccak instance |
| Correct client selection |Raw/raw and raw/sampling jobs;captured per-core type/ID;simultaneous requests give raw priority |
| Finite raw hash math |Both SHAKE modes;empty/partial/multi-rate input;partial output and rate-boundary beats;1699 exact bytes |
| Complete seed ownership |rho32/rho-prime64/K32 captured from128 output bytes;wait raw completion;hold result/ID/parameter |
| Actual seed-to-polynomial connection |RTL-collected seeds feed formatter/sampler;7 polynomials/1792 exact coefficients across all parameters |
| Parameter error |Seed parameter3 returns zero fields/error without issuing hash |
| Backpressure |Raw payload,raw done and seed result remain stable;held completion survives peer finishing |
| Reset/recovery |Partial seed absorption,partial output,held complete result;coordinated reset and same-ID fresh seeds |
| Independent checking |Same Python script;hashlib plus independent sampler;12 corruptions rejected |

Workload26 commands,18 raw requests,7 seed results(including1 expected error),
7 complete polynomials,3 reset aborts. Main Stage3/4 tie raw service off and
retain their earlier gates. No full-operation output or new coverage/PPA claim.

## Stage5B final-standard KeyGen message gate

Target final FIPS204 bytes,with level2/3/5 labels for44/65/87. Use the existing
Python script and DILITHIUM_STAGE5,DILITHIUM_TEST hash_format. This is a focused
message-construction/hash test;main controller,seed-result storage and complete
key outputs are not established by it.

| Requirement | Implemented check |
|---|---|
| Parameter-bound seed expansion | SHAKE256(seed32+K+L),128 bytes;three seed patterns per set,three reset recoveries |
| Matrix byte order and bounds | All102 legal row/column positions;SHAKE128(rho+column+row),32 exact test output bytes |
| Secret nonce and bounds | All34 legal KeyGen nonces;SHAKE256(rho-prime64+nonce_le16),32 exact test output bytes |
| Command snapshot | Mutate seed,ID,opcode,parameter and coordinate inputs immediately after acceptance |
| Illegal requests |14 error completions;no hash request/input issued |
| Backpressure | Descriptor,64-bit message,completion and128-bit hash output held stable |
| Reset/recovery | Held descriptor,partial input and held completion aborted;coordinated Keccak reset;reuse IDs with changed seeds |
| Independent oracle | Python hashlib plus explicit normative byte concatenation;no RTL/reference sharing |
| Checker credibility |12 injected capture corruptions rejected |

Measured:165 commands,162 completions,3 aborts,883 absorption words and5888 exact
SHAKE bytes PASS. No new functional/code coverage percentage is claimed.

## Stage5A process-unit gate

tb_poly_process.sv checks the shared one-stage coefficient arithmetic unit.
It does not instantiate a full KeyGen/controller. Expected math is generated
by the existing singular Python script and cross-checked with the unchanged C
rounding reference plus ordinary modular arithmetic in process_reference.c.

| Requirement | Check |
|---|---|
| Canonical add/sub |Directed q/zero/half-range boundaries and512 deterministic random pairs for both operations|
| Power2Round ties/width |9208 canonical cases spanning every high-part region with low offsets0,1,4094..4098,8190,8191 where valid|
| Signed/packed low |Exact signed14-bit low and13-bit 4096-low;reconstruction and strict tie interval|
| Relevant operands |ADD/SUB require both canonical;rounding ignores an intentionally noncanonical unused B|
| Framing/errors |13 invalid opcode,noncanonical operand or last/index errors;zero arithmetic results,metadata retained|
| Stalls/pipeline |10009 simultaneous output/input transfers,3505 blocked-input and3511 held-output observations|
| Reset and ID reuse |Three operation-specific pending outputs aborted;one reset also cancels an unaccepted blocked input;fresh recovery reuses IDs|
| Checker integrity |12 corruptions of arithmetic/signedness/packing/opcode/tag/framing/sequence rejected|

PASS:10349 accepted,10346 compared outputs (including13 expected errors),
3 reset aborts. C separately checks all8380417 canonical Power2Round values
against reconstruction/range constraints. This exhaustive reference check
does not mean exhaustive RTL simulation or full functional/code coverage.
Memory routing,packing,stateful polynomial sequencing and KeyGen remain untested
until implemented after the required architecture decisions.

## Current Stage4 focused tests

tb_keccak_sampler_ntt.sv connects all three real engines through memory. It uses
generated independent expectations and writes a trace consumed by the separate
Python checker. Standalone NTT UVM is retained and revalidated independently.

| Requirement | Observed check |
|---|---|
| Four arithmetic operations |NTT,INTT,PWM,Pre;canonical values and exact root/order/scaling|
| All parameter levels |Three Matrix A/secret chains with parameter encodings0/1/2|
| Matrix A bypass |Already-transformed A enters PWM;attempted forward NTT(A) is rejected|
| Independent product |INTT(PWM(A_hat,NTT(s))) equals schoolbook(inverse(A_hat),s)|
| Pre eligibility |Bounded secret and challenge accepted;unbounded mask rejected|
| Round trips |Secret,mask and challenge recovered exactly after NTT/INTT|
| Operand preservation/alias |A and s remain exact after use;PWM may read the same NTT slot twice|
| DMA order/tags |9745 accepted values checked against the exact source ID,slot,index and value|
| Result publication |256 results plus engine done precede commit and completion reply|
| Full-pool handling |24 reservation-wait cycles;release unrelated Pre result to allow PWM destination|
| Source locks |33 successful reservations checked;source complete bits clear while IN_USE|
| Rejection containment |17 stale/free/domain/Pre/parameter errors;zero engine launches,loads or outputs for them|
| Stalls |188 held completion cycles and699 held read-response cycles;payload/metadata stable|
| Reset/recovery |Load17 values,coreRUN after256 loads,and writeback after32 outputs;reset clears all roles and six old-slot reads fail|
| Checker integrity |12 corruptions of DMA/output/read/tag/domain/reservation/completion records rejected|

Source/Python PASS:16 sampled jobs,4096 sampled values;50 compute commands,
30 complete,17 rejected,3 reset aborts;7713 output values (7680 complete+33
aborted prefix) and11776 exact stored reads. Stage2 andStage3 regressions remain
separate and pass their existing gates. This is not full-operation verification,
integration functional/code coverage or formal proof. Compute/sampling overlap,
multi-consumer schedules and general process-block arbitration are not tested.

Relocated NTT standalone UVM:748 jobs,191488 values,32 group type mean90.4731%;
raw DUT code12990/14093=92.17%. Python18 cases/4608 values PASS. These figures
belong solely to standalone NTT,not the connected subsystem.

## Preserved Stage3 focused tests

tb_keccak_sampler_memory.sv uses the real producer and memory. The separate
memory_protocol_test.sv companion injects faults into a three-slot configuration.
Stage2 remains a selectable regression in the same launcher.

| Requirement | Observed check |
|---|---|
| Atomic allocation and both contexts |104 accepted jobs;slot/core/ID binding checked;full pool refuses new commands|
| Stored contents and metadata |88 x256=22528 readbacks match independent values,IDs,mode,param,domain and index|
| Commit only on success |Reads rejected during writes and after coefficient255 while status is held|
| Concurrent traffic |170 read-request/write-accept overlaps on different slots;exact readback|
| Stable stalled response |1321 held-response cycles;payload and all metadata immutable|
| Release arbitration |Outstanding response blocks release;same-slot read wins simultaneous release|
| Invalidation/reuse |8 parameter errors,8 reset aborts,99 rejected reads;88 releases;ID reuse with new messages|
| Read pipeline/reset |Back-to-back response replacement;reset cancels stalled valid and error responses|
| Protocol containment |8 injected faults cannot publish COMPLETE;sticky fault detected|
| Configuration bounds |Three-slot companion rejects encoded slot3|
| Independent checker integrity |12/12 corrupted Stage3 captures rejected|

Source and Python gates pass:104 jobs,88 complete,8 expected errors,8 aborts,
23180 exact writes and22528 exact reads. Stage2 also freshly passes104 jobs,
23089 values and12 checker faults. This is focused verification,not comprehensive
coverage,formal proof or a full-operation Dilithium output claim.

## Preserved Stage2 focused tests

The user authorized efficient non-UVM tests during integration. The current
testbench is `tb/tb_dilithium/tb_keccak_sampler.sv`. Accepted individual UVM
environments remain intact. Full-design UVM and detailed covergroups/crosses
will be developed after complete operation outputs and reference/vector gates.

| Requirement | Current stimulus | Check/evidence |
|---|---|---|
| Both contexts/all sampling parameters |24 baseline jobs:4 modes*3 parameters*2 contexts | Python confirms all24 mode/parameter/actual-core combinations |
| Independent simultaneous operations |32 jobs covering16 ordered mode pairs | Exact per-job polynomial and tags;overlap witness |
| Empty,partial and multi-rate absorption |24 jobs with lengths0,1,7,8,9,15,16,17,33,34,65,66,135,136,137,167,168,169,271,272,273,335,336,337 | Hashlib+scalar expected values;unused high input bytes poisoned |
| Parameter error with live SHAKE source |8 jobs:param3 in4 modes on2 contexts | Parameter-error status,no coefficients,safe upstream drain |
| Output/status backpressure |Periodic stalls,forced stalls for reset targets | Held public value/core/ID/index/last and status stable |
| Shared Keccak lock and cancellation |Observed blocked hash offer,bridge cancellation and stop/drain | Hash offer stable;each stop rise must follow a discarded accepted beat |
| Reset and same-ID reuse |8 aborted jobs at4 observed phases,then8 recovery jobs | Accepted old prefixes exact;no old status/data crosses reset/reuse |
| Completion and source retirement |Every job | Status cannot retire a busy hash core or matching bridge token |
| Registered-credit queue |Two slots,forced full-queue reset,observed concurrent push/pop | Occupancy bounds,ordered values,tags retained,both slots drained before status |
| Ownership |Every accepted command/hash/bridge/output/status transfer | No unowned token or premature context reuse |
| Comparison integrity |12 deliberately corrupted captures | All rejected without changing DUT output or expected models |

Observed source gate:104 jobs,88 complete,8 expected errors,8 aborts,23089 exact
coefficient comparisons. Four reset targets are explicitly reached with both
ownership bits asserted. Raw witnesses:drops99,bridge cancellations140,blocked
hash cycles33316,dual-owned cycles37383,upstream-retirement wait cycles293,
full-queue cycles34198,simultaneous push/pop128.
These event counts describe this workload;they are not throughput rates.

## Remaining verification work

- Future NTT writeback/consumer leases,multi-consumer slot lifetimes and broader memory arbitration.
- Full-operation polynomial lifetimes,matrix-vector accumulation and remaining arithmetic/processes.
- Controller seed/nonce formation,parameter schedules,encoding and signing retries.
- Broader reset points,malformed/incomplete traffic,finite-source semantics and
  independent cancel/timeout features if they are added to the interface.
- Comprehensive UVM functional/code coverage and justified reachable gaps.
- Distinct integrated implementation netlists,physical I/O/FPGA and security review.

Do not interpret104 passing jobs or24 observed combinations as full verification
or a measured overall functional-coverage percentage. The imported components'
standalone coverage figures must not be summed into integrated coverage.
