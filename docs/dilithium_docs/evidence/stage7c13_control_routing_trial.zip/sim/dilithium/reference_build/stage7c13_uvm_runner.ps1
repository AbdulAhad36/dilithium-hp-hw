$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l sim/dilithium/stage7c13_uvm.log -do 'do sim/dilithium/run_uvm.do; quit -f' *> sim/dilithium/stage7c13_uvm_console.log
if ($LASTEXITCODE -ne 0) {throw 'Main UVM run failed'}
if (-not (Select-String -LiteralPath sim/dilithium/stage7c13_uvm.log -Pattern 'STAGE7C5_UVM_PASS' -Quiet)) {throw 'Missing main UVM PASS'}
& 'C:/questasim64_2024.1/win64/vsim.exe' -c -l sim/dilithium/stage7c13_uvm_negative.log -do 'set DILITHIUM_INJECT_BAD_KEY 1; do sim/dilithium/run_uvm.do; quit -f' *> sim/dilithium/stage7c13_uvm_negative_console.log
# Expected UVM fatal: proof is the specific byte mismatch with no credited outcomes.
if (-not (Select-String -LiteralPath sim/dilithium/stage7c13_uvm_negative.log -Pattern 'byte mismatch index0; coverage credit withheld' -Quiet)) {throw 'Negative gate did not reject first byte'}
if ((Get-Content -LiteralPath sim/dilithium/stage7_uvm_negative_checked.csv).Count -ne 1) {throw 'Negative gate incorrectly credited outcomes'}
'STAGE7C13_UVM_RUNNER_PASS'
