from pathlib import Path
from collections import defaultdict
from statistics import mean
import json
h=Path('sim/dilithium');m=json.loads((h/'reference_build/stage7c13_metrics.json').read_text())
f=min(c['fmax_mhz'] for c in m['corners']);groups=defaultdict(list);valid=defaultdict(list)
lines=(h/'stage7c4_main_outputs.txt').read_text().splitlines();assert lines[-1]=='F 210'
for line in lines[1:]:
    x=line.split()
    if x[0]=='J':op,p=int(x[2]),int(x[4])
    if x[0]=='D':
        groups[op,p].append(int(x[-1]))
        if op==2 and int(x[4])==1:valid[p].append(int(x[-1]))
assert [sum(len(v) for k,v in groups.items() if k[0]==op) for op in range(3)]==[75,90,45]
assert sum(map(len,valid.values()))==9
rows=[]
for op in range(3):
    for p,level in enumerate((2,3,5)):
        cycles=mean(valid[p] if op==2 else groups[op,p])
        rows.append(dict(operation=('KeyGen','Sign mean','Verify valid')[op],level=level,cycles=cycles,latency_us=cycles/f,operations_per_second=f*1e6/cycles))
result=dict(worst_fmax_mhz=f,reported_period_ns=1000/f,cycle_change_vs_C12=0,operation_rate_gain_vs_C12_pct=100*(f/57.38-1),rows=rows)
(h/'reference_build/stage7c13_throughput.json').write_text(json.dumps(result,indent=2)+'\n')
print('|Operation|Level|Mean cycles|Estimated latency us|Estimated operations/s|')
print('|---|---:|---:|---:|---:|')
for r in rows:print(f'|{r["operation"]}|{r["level"]}|{r["cycles"]:.2f}|{r["latency_us"]:.1f}|{r["operations_per_second"]:.1f}|')
print('C13_THROUGHPUT_CALC_PASS:latency-based sequential estimates at reported Fmax,not board measurements or initiation interval;gain_vs_C12_pct='+str(result['operation_rate_gain_vs_C12_pct']))
