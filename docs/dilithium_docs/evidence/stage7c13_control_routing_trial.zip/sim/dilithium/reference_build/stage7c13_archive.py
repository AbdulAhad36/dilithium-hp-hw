from pathlib import Path
import hashlib,json,zipfile
r=Path.cwd();h=r/'sim/dilithium';q=r/'quartus/dilithium';rb=h/'reference_build';ev=r/'docs/dilithium_docs/evidence'
target=ev/'stage7c13_control_routing_trial.zip';side=target.with_suffix('.sha256')
assert not target.exists() and not side.exists(),'Create-only archive already exists'
def read(p):
 b=p.read_bytes();return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8',errors='replace')
for leaf,marker in [('native_runner.log','STAGE7C13_NATIVE_RUNNER_PASS'),('uvm_runner.log','STAGE7C13_UVM_RUNNER_PASS'),('quartus_runner.log','STAGE7C13_QUARTUS_RUNNER_PASS'),('cycle_audit.log','STAGE7C13_CYCLE_AUDIT_PASS')]:
 assert marker in read(h/('stage7c13_'+leaf)),leaf
assert 'LIGHTHD_MEMORY_SWITCH_EQUIVALENCE_PASS:400000' in read(h/'stage7c13_switch.log')
assert 'LIGHTHD_PROCESS_DMA_PASS:cases64' in read(h/'stage7c13_foundation.log')
for name,digest in json.loads((rb/'stage7c13_source_hashes.json').read_text()).items():
 assert hashlib.sha256((r/name).read_bytes()).hexdigest()==digest,name
prior=sorted(ev.glob('*.sha256'))
for p in prior:
 words=p.read_text().split();assert hashlib.sha256((ev/words[1]).read_bytes()).hexdigest()==words[0],p
 print('PRIOR_ARCHIVE_SHA_PASS:'+p.stem,flush=True)
paths=set()
for folder in ('src','tb/tb_dilithium','tb_uvm/tb_uvm_dilithium','tb_uvm/tb_uvm_ntt_LightHD','dilithium-sw-model/ref'):
 paths|={p.relative_to(r).as_posix() for p in (r/folder).rglob('*') if p.is_file() and p.suffix in ('.sv','.svh','.c','.h','.md')}
for folder in ('NIST/ML-DSA-keyGen-FIPS204','NIST/ML-DSA-sigGen-FIPS204','NIST/ML-DSA-sigVer-FIPS204'):
 paths|={p.relative_to(r).as_posix() for p in (r/folder).glob('*.json')}
for folder in ('FIPS204_NTT','FIPS204_SAMPLER'):
 paths|={p.relative_to(r).as_posix() for p in (r/folder).glob('*.py')}
paths|={p.relative_to(r).as_posix() for p in (r/'docs/dilithium_docs').glob('*.md')}
paths|={'AGENTS.md','README.md','sim/dilithium/.gitignore','sim/ntt/run_uvm.do','quartus/ntt/ntt.qsf','quartus/dilithium/dilithium.qsf'}
for leaf in ('README.md','dilithium_vectors.py','run.do','run_uvm.do','setup_cyclonev.tcl','report_uvm_coverage.tcl'):
 paths.add('sim/dilithium/'+leaf)
for p in h.glob('*'):
 if not p.is_file():continue
 if (p.name.startswith(('stage7c13','stage7_uvm')) and p.suffix in ('.txt','.csv','.rpt','.log','.ucdb')) or (p.name.startswith(('stage2_','stage3_','stage4_','stage5_')) and p.suffix in ('.txt','.csv') and any(x in p.name for x in ('inputs','expected','samples','nist_sign_audit','nist_verify_audit'))):
  if 'console' not in p.name:paths.add(p.relative_to(r).as_posix())
for leaf in ('stage7c4_main_inputs.txt','stage7c4_main_outputs.txt','stage7c4_main_diagnostic_inputs.txt','stage7c4_main_diagnostic_outputs.txt','stage7c4_main_protocol_inputs.txt','stage7c4_main_protocol_outputs.txt','stage7c_ntt_inputs.txt','stage7c_ntt_expected.txt','stage7c1_ntt_dma_outputs.txt','stage7c4_hint_inputs.txt','stage7c4_hint_expected.txt','stage7c4_hint_outputs.txt'):
 paths.add('sim/dilithium/'+leaf)
for p in rb.glob('stage7c13*'):
 if p.is_file():paths.add(p.relative_to(r).as_posix())
 elif p.is_dir():paths|={v.relative_to(r).as_posix() for v in p.rglob('*') if v.is_file() and v.suffix not in ('.exe','.o')}
for leaf in ('stage7c12_metrics.json','stage7c12_area_inventory.json'):paths.add('sim/dilithium/reference_build/'+leaf)
for leaf in ('dilithium_full.qpf','dilithium_full.qsf','dilithium.sdc','report_full.tcl','README.md','stage7c13_compile.log','stage7c13_report_full.log'):paths.add('quartus/dilithium/'+leaf)
for prefix in ('slow_85C','slow_0C','fast_85C','fast_0C'):
 for suffix in ('fmax','setup','hold'):paths.add(f'quartus/dilithium/critical_full/{prefix}_{suffix}.rpt')
for leaf in ('retained_registers.rpt','mapped_register_names.rpt'):paths.add('quartus/dilithium/critical_full/'+leaf)
for p in (q/'output_full').glob('*'):
 if p.suffix in ('.rpt','.summary'):paths.add(p.relative_to(r).as_posix())

metrics=json.loads((rb/'stage7c13_metrics.json').read_text());throughput=json.loads((rb/'stage7c13_throughput.json').read_text())
results=dict(stage='7C.13 rejected performance trial',source_qualified=True,routed=True,performance_accepted=False,placed_ALM_target_strictly_below=20000,target_met=metrics['area']['placed_ALMs']<20000,clock_constraint_ns=6.757,timing_closed=all(c['setup_ns']>=0 and c['hold_ns']>=0 for c in metrics['corners']),main_token='30110e3247aad307821dadb67c2cbb0f8c5a118c80afa01e5e3bcfee82dc56e0',uvm_token='a08e0681a3f98dbf1d2786a7e5e65c4cabcc7b986e6976dc4175754285974aeb',full_official_commands=210,official_output_bytes=744280,protocol_commands=88,protocol_checked_bytes=148704,checker_corruptions_rejected=90,main_uvm_checked=30,main_uvm_reset_aborts=3,functional_bins=[116,170],code_bins=[117406,162681],cycles='EXACT C12:all full/protocol/UVM timing records',switch_equivalence_pin_state_checks=400000,switch_reset_epochs=49,hard_DSPs=8,hard_preadder_count=4,hard_chainadder_count=4,metrics=metrics,throughput=throughput,prior_archives_verified=len(prior),rejected_architecture='No new shared64x64 controller context RAM/formatter',trial_rejected=True,remaining_work='Restore C12 router/Process adapter;direct phase control and shared hint buffer prototype next')
files={n:(r/n).read_bytes() for n in sorted(paths)}
files['RESULTS.json']=(json.dumps(results,indent=2)+'\n').encode()
manifest={n:hashlib.sha256(b).hexdigest() for n,b in files.items()}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
 for n,b in sorted(files.items()):z.writestr(n,b)
with zipfile.ZipFile(target) as z:
 assert z.testzip() is None
 for n,d in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==d,n
digest=hashlib.sha256(target.read_bytes()).hexdigest()
with side.open('x') as f:f.write(digest+'  '+target.name+'\n')
print(f'C12_ARCHIVE_CREATE_VERIFY_PASS:{len(files)}members/{target.stat().st_size}bytes/{len(prior)}prior pairs;SHA256 '+digest)
