onerror {quit -code 1 -f}
vlib sim/dilithium/work_lighthd_switch_c13
vmap lighthd_switch_c13 sim/dilithium/work_lighthd_switch_c13
vlog -sv -work lighthd_switch_c13 src/controller/memory/lighthd_memory_router.sv tb/tb_dilithium/lighthd_memory_router_c12_reference.sv tb/tb_dilithium/tb_lighthd_memory_switch.sv
vsim lighthd_switch_c13.tb_lighthd_memory_switch
onfinish stop
run -all
quit -f
