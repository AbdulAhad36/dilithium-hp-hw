// Three clients (NTT,sampling,Process/controller) share eight physical lanes.
// Sixteen ownership and eight deferred-completion bits;no polynomial tags.
// Commands reserve a selected set atomically per A/B port;other banks keep
// running independently. Owners retire on the real memory-done handshake.
`default_nettype none
module lighthd_memory_router (
  input wire logic clk,rst,output logic idle_o,
  input wire logic [2:0][1:0] client_command_valid_i,
  output logic [2:0][1:0] client_command_ready_o,
  input wire logic [2:0][1:0][3:0] client_command_mask_i,client_command_write_i,
  input wire logic [2:0][1:0][3:0][9:0] client_command_base_i,
  input wire logic [2:0][1:0][3:0][10:0] client_command_words_i,
  input wire logic [2:0][1:0][3:0][1:0] client_command_mode_i,
  input wire logic [2:0][1:0][3:0] client_write_valid_i,
  output logic [2:0][1:0][3:0] client_write_ready_o,
  input wire logic [2:0][1:0][3:0][91:0] client_write_data_i,
  input wire logic [2:0][1:0][3:0][9:0] client_write_address_i,
  output logic [2:0][1:0][3:0] client_read_valid_o,
  input wire logic [2:0][1:0][3:0] client_read_ready_i,
  output logic [2:0][1:0][3:0][91:0] client_read_data_o,
  output logic [2:0][1:0][3:0][9:0] client_read_address_o,
  output logic [2:0][1:0][3:0] client_read_last_o,client_done_valid_o,client_done_error_o,
  input wire logic [2:0][1:0][3:0] client_done_ready_i,
  output logic [1:0] memory_command_valid_o,input wire logic [1:0] memory_command_ready_i,
  output logic [1:0][3:0] memory_command_mask_o,memory_command_write_o,
  output logic [1:0][3:0][9:0] memory_command_base_o,
  output logic [1:0][3:0][10:0] memory_command_words_o,
  output logic [1:0][3:0][1:0] memory_command_mode_o,
  output logic [1:0][3:0] memory_write_valid_o,input wire logic [1:0][3:0] memory_write_ready_i,
  output logic [1:0][3:0][91:0] memory_write_data_o,
  output logic [1:0][3:0][9:0] memory_write_address_o,
  input wire logic [1:0][3:0] memory_read_valid_i,
  output logic [1:0][3:0] memory_read_ready_o,
  input wire logic [1:0][3:0][91:0] memory_read_data_i,
  input wire logic [1:0][3:0][9:0] memory_read_address_i,
  input wire logic [1:0][3:0] memory_read_last_i,memory_done_valid_i,memory_done_error_i,
  output logic [1:0][3:0] memory_done_ready_o
);
  logic [1:0][3:0][1:0] owner_r;
  // A client can consume its completion while a same-lane renewal waits for
  // arbitration. Retain the physical REPORT/owner until that renewal wins.
  logic [1:0][3:0] retire_pending_r;
  logic [1:0][1:0] turn_r,selected;
  logic [1:0][2:0] eligible,grant;
  logic [1:0][3:0] owner_done_ready;
  logic [1:0][3:0] effective_mask;
  assign idle_o=&owner_r;
  always_comb begin
    client_command_ready_o=0;client_write_ready_o=0;client_read_valid_o=0;
    client_read_data_o=0;client_read_address_o=0;client_read_last_o=0;
    client_done_valid_o=0;client_done_error_o=0;
    memory_command_valid_o=0;memory_command_mask_o=0;memory_command_write_o=0;
    memory_command_base_o=0;memory_command_words_o=0;memory_command_mode_o=0;
    memory_write_valid_o=0;memory_write_data_o=0;memory_write_address_o=0;memory_read_ready_o=0;memory_done_ready_o=0;
    selected='1;effective_mask=0;eligible=0;grant=0;owner_done_ready=0;
    for(int p=0;p<2;p++)begin
      // Decode three fixed engine requests BEFORE selecting any descriptor.
      // No rotating array index or repeated wide priority mux on bank data.
      for(int c=0;c<3;c++)begin
        logic available;logic [3:0] mask;
        mask=client_command_mask_i[c][p]==0?4'b1:client_command_mask_i[c][p];
        available=!rst;
        for(int b=0;b<4;b++)if(mask[b] && owner_r[p][b]!=3 &&
          !(owner_r[p][b]==c && memory_done_valid_i[p][b] &&
            (client_done_ready_i[c][p][b] || retire_pending_r[p][b])))available=0;
        eligible[p][c]=client_command_valid_i[c][p] && available;
      end
      // Preserve C12 admission order while eliminating the indexed crossbar.
      // This local switch correction is not a completed controller rewrite.
      case(turn_r[p])
        0:begin
          grant[p][0]=eligible[p][0];
          grant[p][1]=eligible[p][1] && !eligible[p][0];
          grant[p][2]=eligible[p][2] && !(eligible[p][0] || eligible[p][1]);
        end
        1:begin
          grant[p][1]=eligible[p][1];
          grant[p][2]=eligible[p][2] && !eligible[p][1];
          grant[p][0]=eligible[p][0] && !(eligible[p][1] || eligible[p][2]);
        end
        default:begin
          grant[p][2]=eligible[p][2];
          grant[p][0]=eligible[p][0] && !eligible[p][2];
          grant[p][1]=eligible[p][1] && !(eligible[p][2] || eligible[p][0]);
        end
      endcase
      memory_command_valid_o[p]=|grant[p];
      for(int c=0;c<3;c++)begin
        if(grant[p][c])selected[p]=2'(c);
        client_command_ready_o[c][p]=grant[p][c] && memory_command_ready_i[p];
        effective_mask[p]|={4{grant[p][c]}} &
          (client_command_mask_i[c][p]==0?4'b1:client_command_mask_i[c][p]);
        memory_command_mask_o[p]|={4{grant[p][c]}} & client_command_mask_i[c][p];
        memory_command_write_o[p]|={4{grant[p][c]}} & client_command_write_i[c][p];
        memory_command_base_o[p]|={40{grant[p][c]}} & client_command_base_i[c][p];
        memory_command_words_o[p]|={44{grant[p][c]}} & client_command_words_i[c][p];
        memory_command_mode_o[p]|={8{grant[p][c]}} & client_command_mode_i[c][p];
        for(int b=0;b<4;b++)begin
          logic owns,renewal_wait;
          owns=!rst && owner_r[p][b]==2'(c);
          renewal_wait=client_command_valid_i[c][p] &&
            (client_command_mask_i[c][p][b] || (client_command_mask_i[c][p]==0 && b==0)) && !grant[p][c];
          memory_write_valid_o[p][b]|=owns && client_write_valid_i[c][p][b];
          memory_write_data_o[p][b]|={92{owns}} & client_write_data_i[c][p][b];
          memory_write_address_o[p][b]|={10{owns}} & client_write_address_i[c][p][b];
          memory_read_ready_o[p][b]|=owns && client_read_ready_i[c][p][b];
          owner_done_ready[p][b]|=owns && client_done_ready_i[c][p][b];
          memory_done_ready_o[p][b]|=owns && !renewal_wait &&
            (client_done_ready_i[c][p][b] || retire_pending_r[p][b]);
          client_write_ready_o[c][p][b]=owns && memory_write_ready_i[p][b];
          client_read_valid_o[c][p][b]=owns && memory_read_valid_i[p][b];
          client_read_data_o[c][p][b]={92{owns}} & memory_read_data_i[p][b];
          client_read_address_o[c][p][b]={10{owns}} & memory_read_address_i[p][b];
          client_read_last_o[c][p][b]=owns && memory_read_last_i[p][b];
          client_done_valid_o[c][p][b]=owns && memory_done_valid_i[p][b] && !retire_pending_r[p][b];
          client_done_error_o[c][p][b]=owns && memory_done_error_i[p][b];
        end
      end
    end
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin owner_r<='1;turn_r<=0;retire_pending_r<=0;end
    else for(int p=0;p<2;p++)begin
      for(int b=0;b<4;b++)begin
        if(owner_r[p][b]!=3 && memory_done_valid_i[p][b] &&
          owner_done_ready[p][b] && !memory_done_ready_o[p][b])retire_pending_r[p][b]<=1;
        if(memory_done_valid_i[p][b] && memory_done_ready_o[p][b])begin
          owner_r[p][b]<=3;retire_pending_r[p][b]<=0;
        end
        if(memory_command_valid_o[p] && memory_command_ready_i[p] && effective_mask[p][b])begin
          owner_r[p][b]<=selected[p];retire_pending_r[p][b]<=0;
        end
      end
      if(memory_command_valid_o[p] && memory_command_ready_i[p])turn_r[p]<=selected[p]==2?2'd0:selected[p]+1'b1;
    end
  end
`ifndef SYNTHESIS
  always @(posedge clk)if(!rst)for(int p=0;p<2;p++)for(int b=0;b<4;b++)
    if(retire_pending_r[p][b] && (owner_r[p][b]==3 || !memory_done_valid_i[p][b]))
      $fatal(1,"Deferred bank retirement lost its physical REPORT/owner");
`endif
endmodule
`default_nettype wire
