# Evolving Dilithium synthesis project

## Active production project (C12 architecture trial)

`dilithium_full.qpf` compiles all three public operations. Fused native-DSP
RTL is included;device,6.757ns SDC,hold rules and physical settings stay exact
C11R1. Full compile/ASM/STA completes after an automatic routing retry.
Strict retained-hardware/four-corner reporting also passes. Actual final
placed [A] ALMs33056,registers22797,M10Ks59,DSPs8;worst57.38MHz,
setup-10.671ns/hold+0.090ns. This is essentially unchanged area and0.33% lower
Fmax than C11R1;performance remains unaccepted. The summary's30365 ALM
logic-utilization estimate is not the placed count. Logs:stage7c12_compile.log,
stage7c12_report_full.log. The mapped DSP table proves4 dedicated pre-adders
and4 output-adder chains;all8DSPs and required registers survive placement.
No native job remains. Next target:memory/router-to-Process path and selection
overhead;the below20000 and148MHz goals remain open.

## Previous production project (C11R1)

`dilithium_full.qpf` remains the whole three-operation production project.
QSF/6.757ns SDC/device/hold rules are exact C10. Fresh full compile/ASM/STA
and retained-hardware/four-corner gates pass:33066 actual placed ALMs,
23054 registers,59M10Ks,4DSP. Worst Fmax57.57MHz/setup−10.612ns/hold+0.095ns.
Under20000 and148MHz remain open. Compile log:stage7c11r1_compile.log;
strict report:stage7c11r1_report_full.log. Detailed results are in the
universal THROUGHPUT.md and C11 evidence archive.

## Previous production project (Stage7C.10)

C10 source/full compile/ASM/STA and retained/four-corner gates pass. Actual
placed34660 ALMs,25339 registers,59M10Ks,8DSP;worst Fmax56.65MHz/setup-10.894ns/
hold+0.122ns. All20 new control bits retained. No native build remains active.
Same device,6.757ns clock,hold rules and physical options are retained;
the148MHz target still fails setup. Next target is RAM-to-Process timing.

### Frozen Stage7C.9 R1 result

R1 source/full compile/retained-register/four-corner gates complete. Actual
placed34535 ALMs,25404 registers,59M10Ks/8DSP;worst Fmax53.85MHz/setup-11.812ns/
hold+0.121ns. This regresses versus C8's55.53MHz and is not performance-accepted.
The148MHz constraint remains unchanged and fails setup. Next target is NTT
completion readiness. The C7 physical figures below are historical.

Open `dilithium_full.qpf` in Quartus and use **Processing > Start Compilation**.
The top remains `dilithium_fpga`;its core is now `lighthd_dilithium`. The QSF
lists55 production sources for one shared engine set and the fixed-bank
controller. Original engine RTL and historical controllers remain preserved
in the checkout;the former allocator/helper hierarchy is not an active
production synthesis dependency.

Device5CGXFC7C7F23C8,clock6.757ns,hold rules,virtual pins,seed and all non-source
physical settings are unchanged from7B.9. No SDC edit is required. Current
full compilation passes with34302 actual placed `[A]` ALMs,25337 registers,
59 M10Ks and8 DSPs. The response loop is gone. Worst reported Fmax51.78MHz/
setup-12.556ns/hold+0.103ns:the148MHz target still fails setup. THROUGHPUT.md
records all corners and remaining work. Old51162-ALM/23.97MHz reports belong
to the earlier source. Keep reporting actual fitted area and worst corners.
The preserved `dilithium.qpf` remains the older subsystem project.


## Stage7B.9 production top

Open **dilithium_full.qpf** in the Quartus GUI, then choose
**Processing > Start Compilation**. It selects `dilithium_fpga`,whose unchanged
`dilithium` core has FULL_KEYGEN=1,ENABLE_SIGN=1 and ENABLE_VERIFY=1 hardwired.
Seed/debug exports stay internal;all normal command/data/status pins remain.
The design uses the same Cyclone V
5CGXFC7C7F23C8 and unchanged 6.757ns clock target. Reports go to output_full/.
The former dilithium.qpf and output_files/ retain the earlier subsystem scope.
Do not quote their results as whole-main PPA.

After a successful full compile, run `quartus_sta -t report_full.tcl` here.
It checks retained controller/Keccak/sampler registers and reports setup,
hold and Fmax at all four supported timing corners under critical_full/.
Headline area must come from **ALMs used in final placement** in the fitted
report, not the synthesis/packing estimate. Virtual data pins and false-path
I/O constraints make this an internal benchmark, not board I/O closure.
No manual SDC change is required. See universal THROUGHPUT.md for measured
results. Current7B.9 full compile routes at51,162 actual placed ALMs,62 M10Ks,
27 DSPs. Fmax23.97MHz/setup−34.965ns/hold+0.099ns:the unchanged target fails
setup. Compiler exit0 does not mean timing closure. The production boundary has1026
virtual nonclock bits plus the real clock. These are port counts,not ALMs.

## Earlier subsystem project

Open `dilithium.qpf` in Quartus GUI and choose **Processing > Start Compilation**.
The current top is `keccak_sampler_ntt` (Stage4). The project will grow to the full
controller/memory/process/NTT system as those parts are implemented.

Initial target chosen by the user:about148MHz,permanent6.757ns SDC for this
baseline. No manual SDC edit is needed. Seed1,HIGH PERFORMANCE EFFORT,
Cyclone V5CGXFC7C7F23C8.294 non-clock bits are virtual.
Virtual data I/O timing is excluded;this is an internal timing benchmark.

Stage4 all-engine source/Python checks pass,but its synthesis/fit has not been run.
Existing output_files reports are the earlier Stage2 producer-only build and
must not be reported as current Stage4 PPA. report_paths.tcl refuses an old
database lacking memory metadata or the NTT datapath. Full-system optimization
remains deferred;the project is prepared for GUI compilation when needed.

The first fit missed timing at129.18MHz/-0.984ns setup. On2026-10-20 the user
superseded timing-first work:integrate for functionality and full-operation
outputs,then optimize Fmax/area/throughput. Timing closure does not block memory.
Historical Stage2 trial8:global retiming OFF,Keccak hierarchy ON,
sampler hierarchy OFF,physical combinational synthesis/duplication ON,and
maximum router timing effort. Ordinary clock-enable mapping is restored;
each Keccak core predecodes absorb-ready without adding a processing cycle.
The lane-write and forced-global-enable trials were rejected and removed.
Keccak's launch-offset-zero flag is registered without changing launch gaps.
The helper has a two-slot register queue with registered-credit upstream ready.
Command ready relies on ownership,with sampler-readiness equivalence asserted
in source simulation. The main project uses seed1;its completed fit has11293
placed ALMs,137.74MHz worst Fmax,-0.503ns setup and+0.157ns hold. Structural
guards pass;timing remains open. The isolated seed2 compile also finished;
it is not selected. No build remains active and no further timing experiment
is planned before functional integration. This is not a timing-closed baseline.

Read **[A] ALMs used in final placement** for area,all-corner TimeQuest setup/
hold/TNS and both slow-corner Fmax summaries. A positive source-test result does
not establish FPGA Fmax. Run `quartus_sta -t report_paths.tcl` from this folder
to check the accepted sampler's payload/register guards inside the combined top.

Current measurements and limitations belong in the universal
docs/dilithium_docs/THROUGHPUT.md. Standalone module reports remain standalone;
they do not define system area or timing.
