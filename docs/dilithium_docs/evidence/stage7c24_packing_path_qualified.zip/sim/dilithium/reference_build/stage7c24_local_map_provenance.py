"""Record the immutable sources of the prepromotion local map comparison."""
from pathlib import Path
import hashlib,json,zipfile
r=Path.cwd();rb=r/'sim/dilithium/reference_build';ev=r/'docs/dilithium_docs/evidence'
zpath=ev/'stage7c22_ready_isolation_qualified.zip'
sha=hashlib.sha256(zpath.read_bytes()).hexdigest();assert sha==zpath.with_suffix('.sha256').read_text().split()[0]
with zipfile.ZipFile(zpath) as z:baseline=z.read('src/controller/process/lighthd_bitpkg.sv')
candidate=(r/'tmp/c24_lighthd_bitpkg.sv').read_bytes()
assert candidate==(r/'src/controller/process/lighthd_bitpkg.sv').read_bytes()
result=dict(scope='prepromotion standalone Analysis & Synthesis,not placed ALMs or PPA',
 baseline_C22_archive_sha256=sha,baseline_packer_sha256=hashlib.sha256(baseline).hexdigest(),
 candidate_packer_sha256=hashlib.sha256(candidate).hexdigest(),baseline_ALUTs=1050,candidate_ALUTs=974,
 baseline_registers=197,candidate_registers=195,
 baseline_qsf='tmp/stage7c24_bitpkg_map_baseline/probe.qsf',candidate_qsf='tmp/stage7c24_bitpkg_map_candidate/probe.qsf',
 note='Baseline map ran before production promotion,when all259 C22 hashes were exact. Its QSF uses original production paths;do not rerun it against later source and call that the old baseline.')
p=rb/'stage7c24_local_map_sources.json';assert not p.exists()
with p.open('x',encoding='utf-8') as f:json.dump(result,f,indent=2);f.write('\n')
print('C24_LOCAL_MAP_PROVENANCE_PASS:immutable C22 baseline/shared candidate hashes recorded;local map is not placed area')
