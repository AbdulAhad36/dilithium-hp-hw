from pathlib import Path
import re,json
q=Path('quartus/dilithium/critical_full');h=Path('sim/dilithium/reference_build')
names=(q/'mapped_register_names.rpt').read_text().splitlines();result={}
for label,expr,lo,hi in [('raw_operands',r'\|lighthd_process_dma:process_path\|operand_[ab]_store_r',368,368),
                       ('word_tags',r'\|lighthd_process_dma:process_path\|operand_tag_store_r',12,12),
                       ('occupancy',r'\|lighthd_process_dma:process_path\|operand_count_r',2,2),
                       ('pointers',r'\|lighthd_process_dma:process_path\|operand_(read|write)_r',2,2)]:
    hits=[n for n in names if re.search(expr,n)];assert lo<=len(hits)<=hi,(label,len(hits))
    result[label]=dict(bits=len(hits),names=hits)
assert 'WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS' in (q/'retained_registers.rpt').read_text()
(h/'stage7c24_operand_registers.json').write_text(json.dumps(result,indent=2)+'\n')
print('C24_PROCESS_OPERAND_HW_GUARD_PASS:368 raw payload/12 tag/2 occupancy/2 pointer bits;two entries physically retained')
