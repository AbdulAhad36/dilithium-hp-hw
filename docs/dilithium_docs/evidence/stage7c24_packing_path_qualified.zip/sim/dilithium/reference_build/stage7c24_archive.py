from pathlib import Path
import hashlib,json,zipfile,re

r=Path.cwd();h=r/'sim/dilithium';q=r/'quartus/dilithium';rb=h/'reference_build';ev=r/'docs/dilithium_docs/evidence'
target=ev/'stage7c24_packing_path_qualified.zip';side=target.with_suffix('.sha256')
assert not target.exists() and not side.exists(),'Create-only archive already exists'

def read(p):
    b=p.read_bytes();return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8',errors='replace')

for leaf,marker in [('collect_runner.log','STAGE7C24_RESULT_COLLECTION_PASS'),('native_runner.log','STAGE7C24_NATIVE_RUNNER_PASS'),('uvm_runner.log','STAGE7C24_UVM_RUNNER_PASS'),('quartus_runner.log','STAGE7C24_QUARTUS_RUNNER_PASS'),('cycle_audit.log','STAGE7C24_CYCLE_AUDIT_PASS')]:
    assert marker in read(h/('stage7c24_'+leaf)),leaf
foundation=read(h/'stage7c24_foundation.log')
for marker in ('LIGHTHD_PROCESS_DMA_PASS:cases64','SHARED_HINT_MODE_SWITCH_PASS:60','LIGHTHD_PROCESS_PHASE_PORT_PASS:2097152'):
    assert marker in foundation,marker
assert 'LIGHTHD_MEMORY_DIRECT_DATA_PASS:400000' in foundation
assert 'LIGHTHD_PROCESS_RANGE_EXHAUSTIVE_PASS:norm134217728' in foundation
assert 'LIGHTHD_PROCESS_OPERAND_STAGE_PASS:' in foundation
assert 'LIGHTHD_PACK_FIELD_PROOF_PASS:exhaustive1/31461480 vectors/125845920 lane checks/2401227 valid-lane encodings/4200 isolated-boundary vectors' in foundation
assert 'LIGHTHD_PACK_STREAM_EQUIVALENCE_PASS:360 jobs/60 resets/240 malformed/7040 words/1490 stalled/6139 pop-push renewals/16701 clocks' in foundation
assert 'LIGHTHD_UNPACK_COUNTER_CYCLE_PASS:174350' in foundation
assert 'LIGHTHD_OPERAND_QUEUE_MODEL_PASS:4131 pushes/4125 pops/663 full clocks/3878 renewals/3 occupied reset observations/phases11' in foundation
assert 'LIGHTHD_COUNTER_PRIORITY_MODEL_PASS:32768' in read(h/'stage7c24_lighthd_counter_selftest.log')
assert 'C24_UNIT_DOMAIN_PROOF_REUSE_PASS' in read(h/'stage7c24_proof_reuse_console.log')
assert 'LIGHTHD_WRITER_QUEUE_STRESS_PASS:17batches/2178writes/34completions/4occupied-reset recoveries/8rejects' in foundation
assert 'LIGHTHD_SAMPLER_WRITER_CAPTURE_PASS:112' in foundation
assert 'LIGHTHD_HASH_SAMPLER_CAPTURE_PASS:104' in foundation
assert 'LIGHTHD_VERIFY_DIGEST_LIFETIME_PASS:' in foundation
assert 'LIGHTHD_UNPACK_READY_ISOLATION_PASS:' in foundation
assert '174350' in foundation
assert 'C24_STREAM_HARDWARE_GUARD_PASS' in read(h/'stage7c24_stream_registers_console.log')
assert 'WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS' in read(q/'critical_full/retained_registers.rpt')
for name,digest in json.loads((rb/'stage7c24_source_hashes.json').read_text()).items():
    assert hashlib.sha256((r/name).read_bytes()).hexdigest()==digest,name

prior=sorted(ev.glob('*.sha256'))
for p in prior:
    digest,leaf=p.read_text().split();assert hashlib.sha256((ev/leaf).read_bytes()).hexdigest()==digest,p
    print('PRIOR_ARCHIVE_SHA_PASS:'+p.stem,flush=True)

paths=set()
for folder in ('src','tb/tb_dilithium','tb_uvm/tb_uvm_dilithium','tb_uvm/tb_uvm_ntt_LightHD','dilithium-sw-model/ref'):
    paths|={p.relative_to(r).as_posix() for p in (r/folder).rglob('*') if p.is_file() and p.suffix in ('.sv','.svh','.c','.h','.md')}
for folder in ('NIST/ML-DSA-keyGen-FIPS204','NIST/ML-DSA-sigGen-FIPS204','NIST/ML-DSA-sigVer-FIPS204'):
    paths|={p.relative_to(r).as_posix() for p in (r/folder).glob('*.json')}
for folder in ('FIPS204_NTT','FIPS204_SAMPLER'):
    paths|={p.relative_to(r).as_posix() for p in (r/folder).glob('*.py')}
paths|={p.relative_to(r).as_posix() for p in (r/'docs/dilithium_docs').glob('*.md')}
paths|={'AGENTS.md','README.md','sim/dilithium/.gitignore','sim/ntt/run_uvm.do','quartus/ntt/ntt.qsf','quartus/dilithium/dilithium.qsf'}
for leaf in ('README.md','dilithium_vectors.py','run.do','run_uvm.do','setup_cyclonev.tcl','report_uvm_coverage.tcl'):
    paths.add('sim/dilithium/'+leaf)
for p in h.glob('*'):
    if not p.is_file():continue
    current=p.name.startswith(('stage7c24','stage7_uvm')) and p.suffix in ('.txt','.csv','.rpt','.log','.ucdb')
    fixture=p.name.startswith(('stage2_','stage3_','stage4_','stage5_')) and p.suffix in ('.txt','.csv') and any(x in p.name for x in ('inputs','expected','samples','nist_sign_audit','nist_verify_audit'))
    if (current or fixture) and 'console' not in p.name and 'archive_create' not in p.name and 'archive_replay' not in p.name:paths.add(p.relative_to(r).as_posix())
for leaf in ('stage7c4_main_inputs.txt','stage7c4_main_outputs.txt','stage7c4_main_diagnostic_inputs.txt','stage7c4_main_diagnostic_outputs.txt','stage7c4_main_protocol_inputs.txt','stage7c4_main_protocol_outputs.txt','stage7c_ntt_inputs.txt','stage7c_ntt_expected.txt','stage7c1_ntt_dma_outputs.txt','stage7c4_hint_inputs.txt','stage7c4_hint_expected.txt','stage7c4_hint_outputs.txt'):
    paths.add('sim/dilithium/'+leaf)
for leaf in ('stage7c_sampler_inputs.txt','stage7c_sampler_expected.txt','stage7c1_sampler_writer_outputs.txt','stage7c_writer_mixed_inputs.txt','stage7c_writer_mixed_expected.txt','stage7c_writer_mixed_same_outputs.txt','stage7c_writer_mixed_different_outputs.txt','stage7c_chain_inputs.txt','stage7c_chain_expected.txt','stage7c1_hash_sampler_outputs.txt'):
    paths.add('sim/dilithium/'+leaf)
for pattern in ('c24*.py','c24*.ps1'):
    for p in (r/'tmp').glob(pattern):paths.add(p.relative_to(r).as_posix())
for leaf in ('c24_probe.do','c24_pack_proof.do','c24_pack_exhaustive.do'):paths.add('tmp/'+leaf)
for p in rb.glob('stage7c24*'):
    if p.is_file():paths.add(p.relative_to(r).as_posix())
    elif p.is_dir():paths|={v.relative_to(r).as_posix() for v in p.rglob('*') if v.is_file() and v.suffix not in ('.exe','.o')}
for leaf in ('stage7c18r1_source_hashes.json','stage7c21_metrics.json','stage7c22_metrics.json','stage7c22_area_inventory.json','stage7c22_source_hashes.json','stage7c22_throughput.json'):paths.add('sim/dilithium/reference_build/'+leaf)
for leaf in ('dilithium_full.qpf','dilithium_full.qsf','dilithium.sdc','report_full.tcl','README.md','stage7c24_compile.log','stage7c24_report_full.log'):
    paths.add('quartus/dilithium/'+leaf)
for corner in ('slow_85C','slow_0C','fast_85C','fast_0C'):
    for kind in ('fmax','setup','hold'):paths.add(f'quartus/dilithium/critical_full/{corner}_{kind}.rpt')
for leaf in ('retained_registers.rpt','mapped_register_names.rpt'):paths.add('quartus/dilithium/critical_full/'+leaf)
for p in (q/'output_full').glob('*'):
    if p.suffix in ('.rpt','.summary'):paths.add(p.relative_to(r).as_posix())

# Earlier exhaustive proof is reused explicitly,never relabelled fresh.
paths.add('sim/dilithium/reference_build/stage7c20_baseline_c18r1/stage7c18r1_foundation.log')
for leaf in ('stage7c_sign_load_inputs.txt','stage7c_sign_load_expected.txt','stage7c3_sign_load_outputs.txt','stage7c4_verify_input_inputs.txt','stage7c4_verify_input_expected.txt','stage7c4_verify_input_outputs.txt'):
    paths.add('sim/dilithium/'+leaf)
# Private overridden-source probes are historical diagnostics,not current token captures.
for p in (r/'tmp').glob('*c24*.sv'):paths.add(p.relative_to(r).as_posix())
for p in (r/'tmp/stage7c24_bitpkg_map_baseline').glob('*.sv'):paths.add(p.relative_to(r).as_posix())
for p in (r/'tmp').glob('lighthd_bitpkg_c22_reference.sv'):paths.add(p.relative_to(r).as_posix())
for folder in ('stage7c24_bitpkg_map_baseline','stage7c24_bitpkg_map_candidate'):
    for p in (r/'tmp'/folder).rglob('*'):
        if p.is_file() and p.suffix in ('.qsf','.qpf','.rpt','.log','.summary','.sv','.txt'):paths.add(p.relative_to(r).as_posix())

metrics=json.loads((rb/'stage7c24_metrics.json').read_text())
throughput=json.loads((rb/'stage7c24_throughput.json').read_text())
uvm=read(h/'stage7c24_uvm.log')
def bins(label):
 m=re.search(re.escape(label)+r'.*?:\s*(\d+) / (\d+)',uvm);assert m,label
 return [int(m[1]),int(m[2])]
results=dict(stage='7C.24 centered packing and registered raw/high selection',source_qualified=True,routed=True,performance_accepted=False,
 physical_completion=metrics['physical_flow'],
 selected_as_working_baseline=False,qualified_area_option=True,selected_baseline_after_archive='C22',
 selection_reason='C24 saves454 actual placed ALMs but loses0.938percent Fmax/rates versus C22,with exact operation cycles. Preserve C24 as an area tradeoff and restore faster C22 after immutable archive/replay;do not retag captures.',
 worst_path='slow0C unpacker.read_slot_r[1]->unpacker.state.REPORT;10logic/14.485ns data delay',
 placed_ALM_target_strictly_below=20000,target_met=metrics['area']['placed_ALMs']<20000,
 clock_constraint_ns=6.757,timing_closed=all(c['setup_ns']>=0 and c['hold_ns']>=0 for c in metrics['corners']),
 main_token=(h/'stage7c4_main_inputs.txt').read_text().split()[0],uvm_token=re.search(r'[0-9a-f]{64}',(h/'stage7_uvm_inputs.txt').read_text())[0],
 full_official_commands=210,official_output_bytes=744280,protocol_commands=88,protocol_checked_bytes=148704,
 checker_corruptions_rejected=90,main_uvm_checked=30,main_uvm_reset_aborts=3,
 functional_bins=bins('OVERALL FUNCTIONAL COVERAGE'),module_code_bins=bins('DUT MODULE CODE COVERAGE'),
 executable_package_code_bins=bins('SHARED DUT PACKAGE CODE COVERAGE'),code_bins=bins('OVERALL DUT CODE COVERAGE'),
 writer_full_polynomials=336,writer_actual_RAM_words=17472,writer_stress_batches=17,writer_stress_writes=2178,
 writer_stress_completions=34,writer_occupied_reset_recoveries=4,writer_rejects=8,writer_checked_reset_prefix_writes=2,
 writer_consecutive_write_witness=128,chain_commands=104,chain_full_polynomials=88,chain_raw_hash_bytes=192,
 reused_Process_domain_proof=dict(stage='C18R1',unchanged_source_files=10,accepted=29339358,checked=29339355,
  reset_discards=3,fresh_C24_execution=False),
 controller_lifetime_guards=json.loads((rb/'stage7c24_lifetime_registers.json').read_text()),
 controller_cycle_checks=dict(diagnostic_clocks=195757,protocol_clocks=972701,owner_model_combinations=65536),
 counter_model_combinations=32768,unpacker_exact_RTL_cycles=174350,
 field_vectors=31461480,field_lane_results=125845920,field_valid_lane_encodings=2401227,isolated_boundary_vectors=4200,
 packing_stream=dict(jobs=360,occupied_resets=60,malformed=240,words=7040,stalls=1490,pop_push=6139,clocks=16701,all_pins_state_reservoir_exact_C22=True),
 operand_queue_test=dict(admissions=4131,deliveries=4125,full_clocks=663,renewals=3878,full_resets=3,reset_read_phases=[0,1]),
 operand_queue_physical_guards=json.loads((rb/'stage7c24_operand_registers.json').read_text()),
 writer_physical_guards=json.loads((rb/'stage7c24_writer_registers.json').read_text()),
 metrics=metrics,throughput=throughput,prior_archives_verified=len(prior),
 private_probes='ActualRTL complete23-bit operand field batches and isolated boundaries/stream pins/state all PASS;actualRAM DMA64/main9/protocol88 controls,requests,digests,bytes and clocks exact C22;standalone map1050->974ALUT/197->195regs is not placed area',
 memory_contract='C22 RAM/collision/384bit operand queue/214bit writer/ring/framing/counter unchanged;packing arithmetic and one preserved raw/high command-selection register;no new operation stage/storage RAM',
 rejected_architecture='No shared64x64 controller context RAM/formatter',
 remaining_work='Under20000 actual placed ALMs/148MHz remain unaccepted targets;use new final critical paths and disjoint area scopes')

files={n:(r/n).read_bytes() for n in sorted(paths)}
files['RESULTS.json']=(json.dumps(results,indent=2)+'\n').encode()
manifest={n:hashlib.sha256(b).hexdigest() for n,b in files.items()}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None
    for n,d in manifest.items():assert hashlib.sha256(z.read(n)).hexdigest()==d,n
digest=hashlib.sha256(target.read_bytes()).hexdigest()
with side.open('x') as f:f.write(digest+'  '+target.name+'\n')
print(f'C24_ARCHIVE_CREATE_VERIFY_PASS:{len(files)}members/{target.stat().st_size}bytes/{len(prior)}prior pairs;SHA256 '+digest)
