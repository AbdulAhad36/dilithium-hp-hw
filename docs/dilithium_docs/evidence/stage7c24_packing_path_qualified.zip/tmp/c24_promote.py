from pathlib import Path
import json,difflib,sys
r=Path.cwd();h=r/'sim/dilithium'
def readlog(p):
 b=p.read_bytes();return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8',errors='replace')
assert 'C24_PRIVATE_CONTROLLER_COMPARE_PASS' in readlog(h/'stage7c24_private_compare.log')
assert 'C24_PACK_FIELD_PROOF_PASS:exhaustive1/31461480 vectors/125845920 lane checks/' in readlog(h/'stage7c24_pack_exhaustive.log')
assert 'C24_PACK_STREAM_EQUIVALENCE_PASS:360 jobs/60 resets/240 malformed/' in readlog(h/'stage7c24_pack_proof.log')
u={
'src/controller/process/lighthd_bitpkg.sv':(r/'tmp/c24_lighthd_bitpkg.sv').read_text(),
'src/controller/datapath/lighthd_process_dma.sv':(r/'tmp/c24_lighthd_process_dma.sv').read_text(),
'tb/tb_dilithium/lighthd_bitpkg_c22_reference.sv':(r/'tmp/lighthd_bitpkg_c22_reference.sv').read_text(),
'tb/tb_dilithium/tb_lighthd_pack_fields.sv':(r/'tmp/tb_c24_pack_fields.sv').read_text().replace('tb_c24_pack_fields','tb_lighthd_pack_fields').replace('C24_PACK_','LIGHTHD_PACK_'),
'tb/tb_dilithium/tb_lighthd_pack_stream.sv':(r/'tmp/tb_c24_pack_stream.sv').read_text().replace('tb_c24_pack_stream','tb_lighthd_pack_stream').replace('C24_PACK_','LIGHTHD_PACK_')}
n='sim/dilithium/dilithium_vectors.py';s=(r/n).read_text()
needle="'tb_lighthd_unpack_counter.sv','tb_lighthd_operand_queue.sv'):"
assert s.count(needle)==1
u[n]=s.replace(needle,"'tb_lighthd_unpack_counter.sv','tb_lighthd_operand_queue.sv',\n                 'lighthd_bitpkg_c22_reference.sv','tb_lighthd_pack_fields.sv','tb_lighthd_pack_stream.sv'):")
patch='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and n!=sys.argv[1]:continue
 p=r/n
 if p.exists():
  d=list(difflib.unified_diff(p.read_text().splitlines(True),s.splitlines(True)))
  patch+='*** Update File: '+n+'\n'+''.join('@@\n' if x.startswith('@@') else x for x in d[2:])
 else:patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
