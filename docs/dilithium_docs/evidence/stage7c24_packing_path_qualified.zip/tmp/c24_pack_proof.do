onerror {quit -code 1 -f}
vlib sim/dilithium/work_c24_pack_proof
vmap c24_pack_proof sim/dilithium/work_c24_pack_proof
vlog -sv -work c24_pack_proof tmp/c24_lighthd_bitpkg.sv tmp/lighthd_bitpkg_c22_reference.sv tmp/tb_c24_pack_fields.sv tmp/tb_c24_pack_stream.sv
foreach top {tb_c24_pack_fields tb_c24_pack_stream} {
 vsim c24_pack_proof.$top
 onfinish stop
 run -all
 quit -sim
}
quit -f
