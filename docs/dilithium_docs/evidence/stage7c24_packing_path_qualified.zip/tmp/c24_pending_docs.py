from pathlib import Path
import difflib,json,sys
r=Path.cwd();leaf=sys.argv[1];p=r/leaf;s=p.read_text(encoding='utf-8');title,tail=s.split('\n\n',1)
note='''## C24 packing-path trial under qualification

Current production sources are the C24 candidate;**C22 remains the last
selected qualified baseline (30,577 placed ALMs /68.23MHz).** No C24 placed
area,Fmax,coverage or throughput result is claimed yet. Fresh source
qualification and the same Cyclone V/6.757ns/hold physical build must finish
before this trial can be selected. All262 frozen source/config/reference
hashes are protected while jobs run;do not start duplicate project/library jobs.

Two RTL changes:BitPkg shares one20-bit centered encoding subtraction per
lane and uses fixed validity bounds;ProcessDMA registers its raw-versus-high
selection when admitting the command. The reservoir,ordering,streaming
interface,error priority and pipeline depth stay unchanged. Invalid internal
field encodings may differ only for operands that are rejected;their rejection
and complete visible transport behavior remain exact. BitUnpkg is exact C22.
No new RAM,engine arithmetic,clock/hold constraint or public port change.

Private actualRTL proof passes31,461,480 vectors/125,845,920 lane checks,
2,401,227 valid-lane encodings and4,200 isolated boundary vectors over all
five formats/three levels. Four adjacent values per batch collectively cover
the23-bit operand domain. This is a field proof,not main functional coverage.
Unforced streaming360jobs/60occupied resets/240malformed/7,040words/1,490stalls/
6,139simultaneous pop-push cycles matches C22 pins,reservoir and state on all
16,701clocks. ActualRAM DMA64cases/11,008coefficients/464packedwords and
main9/protocol88 independent published-byte/digest/status/cycle comparisons pass.

Standalone map:1,050 ->974 combinational ALUTs,197 ->195registers.
These are not placed ALMs or full-device timing. Fresh full210/protocol88/
checker90/main33UVM/negative/foundation and physical-retention gates follow.
Unchanged exhaustive Process arithmetic is explicitly reused from C18R1 via
10byte-identical files,not rerun or relabelled as fresh C24 evidence.
Preserve C20/C21/C22/C23 and all immutable archives. Under20K/148MHz remain
open;no commit,branch change,Stage8 or user performance acceptance.

'''
assert not tail.startswith('## C24 packing-path trial')
tail=tail.replace('## Current working source: C22 restored','## Historical C22 restoration before the C24 trial',1)
new=title+'\n\n'+note+tail
d=list(difflib.unified_diff(s.splitlines(True),new.splitlines(True)))
print(json.dumps('*** Begin Patch\n*** Update File: '+leaf+'\n'+''.join('@@\n' if x.startswith('@@') else x for x in d[2:])+'*** End Patch'))
