from pathlib import Path
import importlib.util
r=Path.cwd();h=r/'sim/dilithium'
spec=importlib.util.spec_from_file_location('v',h/'dilithium_vectors.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
v.lighthd_main_compare(diagnostic=True,captured=(h/'stage7c24_probe_main_diagnostic_outputs.txt').read_text())
v.lighthd_main_protocol_compare(captured=(h/'stage7c24_probe_main_protocol_outputs.txt').read_text())
for leaf in ('diagnostic_outputs.txt','protocol_outputs.txt'):
 a=(h/('stage7c4_main_'+leaf)).read_text().splitlines();b=(h/('stage7c24_probe_main_'+leaf)).read_text().splitlines()
 assert a==b,leaf
print('C24_PRIVATE_CONTROLLER_COMPARE_PASS:main9/protocol88 payloads/status/attempts/digests/all clocks exact C22;saved C22 fixture token,not a new production token')
