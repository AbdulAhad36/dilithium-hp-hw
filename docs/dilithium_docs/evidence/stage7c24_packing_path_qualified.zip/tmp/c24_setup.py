from pathlib import Path
import json,sys
r=Path.cwd();u={}
s=(r/'src/controller/process/lighthd_bitpkg.sv').read_text()
start=s.index('  function automatic logic [12:0] encode_t0')
end=s.index('  assign command_ready_o',start)
fn='''  // Valid centered coefficients lie near zero or q;bit22 selects the
  // negative interval. One shared20-bit subtraction supplies all low-field
  // encodings. Invalid operands still take the unchanged rejection path.
  function automatic logic [19:0] encode_centered(input logic [22:0] value,
    input logic [2:0] op,input logic [4:0] width,input logic [2:0] eta);
    logic [19:0] bias;
    case(op)
      1:bias=value[22]?20'd4097:20'd4096;
      2:bias=20'(eta)+20'(value[22]);
      default:bias=width==18?(value[22]?20'h1e001:20'd131072):
        (value[22]?20'h7e001:20'd524288);
    endcase
    return bias-value[19:0];
  endfunction
'''
s=s[:start]+fn+s[end:]
s=s.replace('  logic [23:0] gamma_r;\n','')
start=s.index('        1:begin\n');end=s.index('        default:bad_value=1;',start)
s=s[:start]+'''        1,2,4:begin
          if(op_r==1)bad_value|=input_data_i[i]>4096 && input_data_i[i]<23'd8376322;
          else if(op_r==2)bad_value|=eta_r==4?
            (input_data_i[i]>4 && input_data_i[i]<23'd8380413):
            (input_data_i[i]>2 && input_data_i[i]<23'd8380415);
          else bad_value|=width_r==18?
            (input_data_i[i]>131072 && input_data_i[i]<23'd8249346):
            (input_data_i[i]>524288 && input_data_i[i]<23'd7856130);
          encoded[i]=24'(encode_centered(input_data_i[i],op_r,width_r,eta_r));
        end
        3:begin encoded[i]={1'b0,input_data_i[i]};bad_value|=input_data_i[i]>(width_r==6?43:15);end
'''+s[end:]
s=s.replace('gamma_r==131072?', 'width_r==6?',1).replace('gamma_r==131072?', 'width_r==18?')
s=s.replace('      gamma_r<=0;ended_r<=0;', '      ended_r<=0;')
s=s.replace("        gamma_r<=command_param_i==0?24'd131072:24'd524288;\n",'')
assert 'gamma_r' not in s and 'encode_t0' not in s
u['tmp/c24_lighthd_bitpkg.sv']=s
s=(r/'src/controller/datapath/lighthd_process_dma.sv').read_text()
s=s.replace('  logic [2:0] pack_op_r;','  logic [2:0] pack_op_r;\n  (* preserve *) logic pack_raw_r;')
s=s.replace('pack_data[lane]=op_r==PROC_PACK?', 'pack_data[lane]=pack_raw_r?')
s=s.replace('pack_op_r<=0;hint_enable_r<=0;', 'pack_op_r<=0;pack_raw_r<=0;hint_enable_r<=0;')
s=s.replace('          op_r<=command_op_i;level_r<=command_param_i;', '          pack_raw_r<=command_op_i==PROC_PACK;\n          op_r<=command_op_i;level_r<=command_param_i;')
assert 'pack_raw_r<=command_op_i==PROC_PACK' in s
u['tmp/c24_lighthd_process_dma.sv']=s
u['tmp/lighthd_bitpkg_c22_reference.sv']=(r/'src/controller/process/lighthd_bitpkg.sv').read_text().replace('module lighthd_bitpkg (','module lighthd_bitpkg_c22_reference (')
base=(r/'tmp/stage7c19_formatter_map_baseline/probe.qsf').read_text().split('set_global_assignment -name TOP_LEVEL_ENTITY')[0]
import re
sources=[(r/'quartus/dilithium'/m).resolve() for m in re.findall(r'SYSTEMVERILOG_FILE\s+(.+)',(r/'quartus/dilithium/dilithium_full.qsf').read_text())]
for variant in ('baseline','candidate'):
 folder='tmp/stage7c24_bitpkg_map_'+variant
 qsf=base+'set_global_assignment -name TOP_LEVEL_ENTITY lighthd_bitpkg\n'
 for source in sources:
  path=r/'tmp/c24_lighthd_bitpkg.sv' if variant=='candidate' and source.stem=='lighthd_bitpkg' else source
  qsf+='set_global_assignment -name SYSTEMVERILOG_FILE "'+path.as_posix()+'"\n'
 u[folder+'/probe.qsf']=qsf;u[folder+'/probe.qpf']='PROJECT_REVISION = "probe"\n'
patch='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and n!=sys.argv[1]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
