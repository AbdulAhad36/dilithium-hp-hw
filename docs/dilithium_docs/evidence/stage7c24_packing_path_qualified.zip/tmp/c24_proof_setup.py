from pathlib import Path
import json,sys
r=Path.cwd();u={}
inputs='clk rst command_valid_i command_op_i command_param_i command_id_i input_valid_i input_data_i input_index_i input_last_i output_ready_i done_ready_i'.split()
outputs={'command_ready_o':'','input_ready_o':'','output_valid_o':'','output_data_o':'[63:0]','output_bytes_o':'[3:0]','output_index_o':'[6:0]','output_last_o':'','output_id_o':'[15:0]','done_valid_o':'','done_code_o':'[2:0]','done_id_o':'[15:0]'}
common='''  logic clk=0,rst=1,command_valid_i=0,input_valid_i=0,input_last_i=0,output_ready_i=0,done_ready_i=0;
  logic [2:0] command_op_i=0;logic [1:0] command_param_i=0;logic [15:0] command_id_i=0;
  logic [3:0][22:0] input_data_i='0;logic [5:0] input_index_i=0;
'''
for n,w in outputs.items():common+=f'  logic {w} {n},ref_{n};\n'
common+='  lighthd_bitpkg dut(.*);\n  lighthd_bitpkg_c22_reference old(\n'+',\n'.join('    .'+n+'('+n+')' for n in inputs)+',\n'+',\n'.join('    .'+n+'(ref_'+n+')' for n in outputs)+'\n  );\n'
field='''`timescale 1ns/1ps
module tb_c24_pack_fields #(parameter bit EXHAUSTIVE=0);
'''+common+'''  int op_cfg,width_cfg,eta_cfg,gamma_cfg;
  longint vectors=0,lanes=0,accepted_lanes=0,isolated=0;
  function automatic bit invalid(input int value);
    int signed_value;
    if(value>=8380417)return 1;
    signed_value=value<=4190208?value:value-8380417;
    case(op_cfg)
      0:return value>1023;
      1:return signed_value< -4095 || signed_value>4096;
      2:return signed_value< -eta_cfg || signed_value>eta_cfg;
      3:return value>(width_cfg==6?43:15);
      default:return signed_value<= -gamma_cfg || signed_value>gamma_cfg;
    endcase
  endfunction
  task automatic check;
    bit bad;int value,signed_value,code;logic [79:0] gold;logic [23:0] mask;
    #1;bad=0;gold=0;mask=(24'd1<<width_cfg)-1;
    for(int lane=0;lane<4;lane++)begin
      value=int'(input_data_i[lane]);bad|=invalid(value);lanes++;
      if(!invalid(value))begin
        signed_value=value<=4190208?value:value-8380417;
        code=op_cfg==1?4096-signed_value:op_cfg==2?eta_cfg-signed_value:op_cfg==4?gamma_cfg-signed_value:value;
        if((dut.encoded[lane]&mask)!==24'(code) || (old.encoded[lane]&mask)!==24'(code))
          $fatal(1,"C24 field op%0d width%0d lane%0d value%0d expected%0d",op_cfg,width_cfg,lane,value,code);
        for(int b=0;b<width_cfg;b++)gold[lane*width_cfg+b]=1'(code>>b);
        accepted_lanes++;
      end
    end
    if(dut.bad_value!==bad || old.bad_value!==bad)$fatal(1,"C24 validity op%0d width%0d data%h",op_cfg,width_cfg,input_data_i);
    if(!bad && (dut.group_bits!==gold || old.group_bits!==gold))$fatal(1,"C24 ordered packed group");
    vectors++;
  endtask
  initial begin
    force dut.op_r=op_cfg;force old.op_r=op_cfg;
    force dut.width_r=width_cfg;force old.width_r=width_cfg;
    force dut.eta_r=eta_cfg;force old.eta_r=eta_cfg;force old.gamma_r=gamma_cfg;
    for(int op=0;op<5;op++)for(int level=0;level<3;level++)begin
      op_cfg=op;eta_cfg=level==1?4:2;gamma_cfg=level==0?131072:524288;
      width_cfg=op==0?10:op==1?13:op==2?(level==1?4:3):op==3?(level==0?6:4):(level==0?18:20);
      for(int base=0;base<(EXHAUSTIVE?8388608:8192);base+=4)begin
        for(int lane=0;lane<4;lane++)input_data_i[lane]=23'(base+lane);
        check();
      end
      for(int lane=0;lane<4;lane++)for(int boundary=0;boundary<10;boundary++)for(int delta=-3;delta<=3;delta++)begin
        int value;
        value=boundary==0?0:boundary==1?1023:boundary==2?4096:boundary==3?eta_cfg:
          boundary==4?gamma_cfg:boundary==5?8380417-gamma_cfg:boundary==6?8380417-eta_cfg:
          boundary==7?8376322:boundary==8?8380417:8388607;
        value=(value+delta)&8388607;input_data_i='0;input_data_i[lane]=23'(value);check();isolated++;
      end
      $display("C24_PACK_FIELDS_PROGRESS:op%0d level%0d vectors%0d",op,level,vectors);
    end
    $display("C24_PACK_FIELD_PROOF_PASS:exhaustive%0d/%0d vectors/%0d lane checks/%0d valid-lane encodings/%0d isolated-boundary vectors;field-only,no transport/UVM credit",EXHAUSTIVE,vectors,lanes,accepted_lanes,isolated);
    $finish;
  end
endmodule
'''
u['tmp/tb_c24_pack_fields.sv']=field
stream='''`timescale 1ns/1ps
module tb_c24_pack_stream;
'''+common+'''  always #5 clk=~clk;
  int clocks=0,jobs=0,outputs=0,stalls=0,renewals=0,resets=0,errors=0;
  logic [31:0] rng=32'hc244b17;
  always @(posedge clk)begin
    clocks++;
    if(clocks>500000)$fatal(1,"C24 stream watchdog");
    if({command_ready_o,input_ready_o,output_valid_o,output_bytes_o,output_index_o,output_last_o,output_id_o,done_valid_o,done_code_o,done_id_o}!==
       {ref_command_ready_o,ref_input_ready_o,ref_output_valid_o,ref_output_bytes_o,ref_output_index_o,ref_output_last_o,ref_output_id_o,ref_done_valid_o,ref_done_code_o,ref_done_id_o})
      $fatal(1,"C24 stream pins clock%0d",clocks);
    if(output_valid_o && output_data_o!==ref_output_data_o)$fatal(1,"C24 stream payload");
    if(dut.bits_r!==old.bits_r || dut.count_r!==old.count_r || dut.group_r!==old.group_r || dut.state!==old.state)
      $fatal(1,"C24 reservoir/state clock%0d",clocks);
    if(!rst)begin
      if(output_valid_o && output_ready_i)outputs++;
      if(output_valid_o && !output_ready_i)stalls++;
      if(dut.pop && dut.push)renewals++;
    end
  end
  function automatic int canonical(input int signed_value);
    return signed_value<0?signed_value+8380417:signed_value;
  endfunction
  task automatic sample(input int op,level,index,trial);
    int eta,gamma,span,value;
    eta=level==1?4:2;gamma=level==0?131072:524288;
    for(int lane=0;lane<4;lane++)begin
      value=(index*7919+trial*73+lane*37317);
      case(op)
        0:input_data_i[lane]=23'(value%1024);
        1:input_data_i[lane]=23'(canonical(value%8192-4095));
        2:input_data_i[lane]=23'(canonical(value%(2*eta+1)-eta));
        3:input_data_i[lane]=23'(value%(level==0?44:16));
        default:input_data_i[lane]=23'(canonical(value%(2*gamma)-gamma+1));
      endcase
    end
  endtask
  task automatic run_job(input int op,level,kind,trial);
    int index;bit active,finished,aborted;int start_clock;
    @(negedge clk);command_op_i=3'(op);command_param_i=2'(level);command_id_i=16'(trial);
    command_valid_i=1;output_ready_i=0;done_ready_i=0;input_valid_i=0;
    do @(posedge clk);while(!command_ready_o);
    @(negedge clk);command_valid_i=0;index=0;active=0;finished=0;aborted=0;start_clock=clocks;
    while(!finished)begin
      rng={rng[30:0],rng[31]^rng[21]^rng[1]^rng[0]};
      output_ready_i=kind==5?(clocks-start_clock>30):(|rng[2:0]);
      done_ready_i=clocks-start_clock>12 && (|rng[4:3]);
      if(!active && index<64 && (|rng[7:5]))begin
        sample(op,level,index,trial);input_index_i=6'(index);input_last_i=index==63;
        if(kind==1 && index==17)input_data_i[trial%4]=23'h7fffff;
        if(kind==2 && index==31)input_index_i=6'd30;
        if(kind==3 && index==15)input_last_i=1;
        if(kind==4 && index==63)input_last_i=0;
        input_valid_i=1;active=1;
      end
      @(posedge clk);
      if(input_valid_i && input_ready_o)begin index++;active=0;end
      if(done_valid_o && done_ready_i)begin
        if(kind==0 && done_code_o!=0)$fatal(1,"C24 valid stream rejected");
        if(kind>=1 && kind<=4 && done_code_o!=(kind==1?2:3))$fatal(1,"C24 malformed stream accepted/code");
        if(kind>=1 && kind<=4)errors++;
        finished=1;
      end
      @(negedge clk);
      if(!active)input_valid_i=0;
      if(kind==5 && dut.count_r!=0 && clocks-start_clock>=6)begin
        rst=1;input_valid_i=0;command_valid_i=0;output_ready_i=0;done_ready_i=0;
        repeat(2)@(negedge clk);rst=0;resets++;aborted=1;finished=1;
      end
    end
    input_valid_i=0;done_ready_i=0;jobs++;
  endtask
  initial begin
    repeat(3)@(negedge clk);rst=0;
    for(int trial=0;trial<4;trial++)for(int op=0;op<5;op++)for(int level=0;level<3;level++)
      for(int kind=0;kind<6;kind++)run_job(op,level,kind,trial*90+op*18+level*6+kind);
    if(jobs!=360 || resets!=60 || errors!=240 || outputs==0 || stalls==0 || renewals==0)$fatal(1,"C24 missing stream scenario");
    $display("C24_PACK_STREAM_EQUIVALENCE_PASS:%0d jobs/%0d resets/%0d malformed/%0d words/%0d stalled/%0d pop-push renewals/%0d clocks;all pins/reservoir/state exact C22",jobs,resets,errors,outputs,stalls,renewals,clocks);
    $finish;
  end
endmodule
'''
u['tmp/tb_c24_pack_stream.sv']=stream
u['tmp/c24_pack_proof.do']='''onerror {quit -code 1 -f}
vlib sim/dilithium/work_c24_pack_proof
vmap c24_pack_proof sim/dilithium/work_c24_pack_proof
vlog -sv -work c24_pack_proof tmp/c24_lighthd_bitpkg.sv tmp/lighthd_bitpkg_c22_reference.sv tmp/tb_c24_pack_fields.sv tmp/tb_c24_pack_stream.sv
foreach top {tb_c24_pack_fields tb_c24_pack_stream} {
 vsim c24_pack_proof.$top
 onfinish stop
 run -all
 quit -sim
}
quit -f
'''
u['tmp/c24_pack_exhaustive.do']='''onerror {quit -code 1 -f}
vmap c24_pack_proof sim/dilithium/work_c24_pack_proof
vsim -gEXHAUSTIVE=1 c24_pack_proof.tb_c24_pack_fields
onfinish stop
run -all
quit -f
'''
u['tmp/c24_map_runner.ps1']='''$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\\GitHub\\dilithium-hp-hw'
foreach($variant in @('baseline','candidate')){
 $folder="tmp/stage7c24_bitpkg_map_${variant}"
 Push-Location -LiteralPath $folder
 & F:/altera/quartus/bin64/quartus_map.exe probe -c probe --read_settings_files=on --write_settings_files=off *> map_console.log
 $code=$LASTEXITCODE;Pop-Location
 if($code -ne 0){throw "C24 map failed $variant"}
 "C24_MAP_PASS $variant"
}
'''
patch='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and n!=sys.argv[1]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
