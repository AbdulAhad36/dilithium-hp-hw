onerror {quit -code 1 -f}
set here [file normalize sim/dilithium]
source sim/dilithium/setup_cyclonev.tcl
vlib sim/dilithium/work_c24_probe
vmap c24_probe sim/dilithium/work_c24_probe
set fd [open quartus/dilithium/dilithium_full.qsf r]
set settings [read $fd];close $fd
foreach line [split $settings "\n"] {
  if {[regexp {SYSTEMVERILOG_FILE\s+(.+)$} [string trim $line] -> source]} {
    set stem [file rootname [file tail $source]]
    if {$stem eq "lighthd_bitpkg" || $stem eq "lighthd_process_dma"} {vlog -sv -work c24_probe tmp/c24_${stem}.sv} else {
      vlog -sv -work c24_probe [file normalize [file join quartus/dilithium $source]]
    }
  }
}
vlog -sv -work c24_probe tb/tb_dilithium/lighthd_bitunpkg_c21_reference.sv tb/tb_dilithium/tb_lighthd_unpack_counter.sv tb/tb_dilithium/tb_lighthd_operand_queue.sv tb/tb_dilithium/lighthd_sign_input_c20_reference.sv tb/tb_dilithium/lighthd_sign_c20_reference.sv tb/tb_dilithium/lighthd_verify_input_c20_reference.sv tb/tb_dilithium/lighthd_verify_c20_reference.sv tb/tb_dilithium/tb_lighthd_controller_lifetimes.sv tb/tb_dilithium/tb_lighthd_sign_input.sv tb/tb_dilithium/lighthd_service_fixture.sv tb/tb_dilithium/tb_lighthd_verify_input.sv tb/tb_dilithium/tb_lighthd_sampler_writer.sv tb/tb_dilithium/tb_lighthd_sampler_writer_mixed.sv tb/tb_dilithium/tb_lighthd_sampler_writer_queue.sv tb/tb_dilithium/tb_lighthd_hash_sampler.sv tb/tb_dilithium/lighthd_process_c17_reference.sv tb/tb_dilithium/lighthd_verify_c17_reference.sv tb/tb_dilithium/tb_lighthd_process_payload.sv tb/tb_dilithium/tb_lighthd_verify_lifetime.sv tb/tb_dilithium/lighthd_process_c16_reference.sv tb/tb_dilithium/lighthd_bitunpkg_c16_reference.sv tb/tb_dilithium/lighthd_hint_decode_stage_reference.sv tb/tb_dilithium/tb_lighthd_process_alu.sv tb/tb_dilithium/tb_lighthd_bitunpkg_ring.sv tb/tb_dilithium/lighthd_cnb_c15_reference.sv tb/tb_dilithium/lighthd_mhint_c15_reference.sv tb/tb_dilithium/tb_lighthd_process_ranges.sv tb/tb_dilithium/tb_lighthd_process.sv tb/tb_dilithium/lighthd_memory_router_c12_reference.sv tb/tb_dilithium/tb_lighthd_memory_switch.sv tb/tb_dilithium/lighthd_hint_compat.sv tb/tb_dilithium/lighthd_hintpkg_c13_reference.sv tb/tb_dilithium/lighthd_hintunpkg_c13_reference.sv tb/tb_dilithium/lighthd_process_dma_c12_reference.sv tb/tb_dilithium/tb_lighthd_process_ports.sv tb/tb_dilithium/tb_lighthd_hint_shared.sv tb/tb_dilithium/tb_lighthd_hintpkg.sv tb/tb_dilithium/lighthd_bank_fixture.sv tb/tb_dilithium/tb_lighthd_process_dma.sv tmp/tb_c24_main_probe.sv tb/tb_dilithium/tb_lighthd_bram.sv tb/tb_dilithium/tb_lighthd_memory.sv tb/tb_dilithium/tb_lighthd_ntt_dma.sv tb/tb_dilithium/tb_lighthd_hintunpkg.sv
foreach top {tb_lighthd_process_dma tb_lighthd_controller_lifetimes} {
  if {$top eq "tb_lighthd_process_payload"} {vsim -L cyclonev_ver -gEXHAUSTIVE=1 c24_probe.$top} elseif {$top eq "tb_lighthd_process" || $top eq "tb_lighthd_process_alu"} {vsim -L cyclonev_ver -gEXHAUSTIVE=0 c24_probe.$top} else {vsim -L cyclonev_ver c24_probe.$top}
  onfinish stop
  run -all
  quit -sim
}
vsim -L cyclonev_ver -gDIAGNOSTIC=0 -gPROTOCOL=1 c24_probe.tb_lighthd_controller_lifetimes
onfinish stop
run -all
quit -f
