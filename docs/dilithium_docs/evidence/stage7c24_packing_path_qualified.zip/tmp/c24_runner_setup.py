from pathlib import Path
import hashlib,json,sys
r=Path.cwd();rb=r/'sim/dilithium/reference_build';u={}
names=('native_runner.ps1','quartus_runner.ps1','foundation_runner.ps1','production_runner.ps1','uvm_runner.ps1','collect_runner.ps1','foundation.do','production.do','metrics.py','admission_registers.py','native_structure.py','shared_hint_registers.py','operand_registers.py','stream_registers.py','lifetime_registers.py','writer_registers.py','area_delta.py','throughput.py','cycle_audit.py','proof_reuse.py')
for name in names:
 # C22 packer/unpacker baseline;do not inherit rejected C23 unpacker logic.
 s=(rb/('stage7c22_'+name)).read_text(encoding='utf-8').replace('stage7c22','stage7c24').replace('STAGE7C22','STAGE7C24').replace('C22_','C24_')
 if name=='foundation.do':
  s=s.replace('vlog -sv -work lighthd_foundation_work tb/tb_dilithium/lighthd_bitunpkg_c21_reference.sv','vlog -sv -work lighthd_foundation_work tb/tb_dilithium/lighthd_bitpkg_c22_reference.sv tb/tb_dilithium/tb_lighthd_pack_fields.sv tb/tb_dilithium/tb_lighthd_pack_stream.sv tb/tb_dilithium/lighthd_bitunpkg_c21_reference.sv')
  s=s.replace('foreach top {tb_lighthd_unpack_counter','foreach top {tb_lighthd_pack_fields tb_lighthd_pack_stream tb_lighthd_unpack_counter')
  s=s.replace('if {$top eq "tb_lighthd_process_payload"}', 'if {$top eq "tb_lighthd_process_payload" || $top eq "tb_lighthd_pack_fields"}')
 if name=='foundation_runner.ps1':
  s=s.replace("@('LIGHTHD_UNPACK_COUNTER_CYCLE_PASS", "@('LIGHTHD_PACK_FIELD_PROOF_PASS:exhaustive1/31461480 vectors/125845920 lane checks/2401227 valid-lane encodings/4200 isolated-boundary vectors','LIGHTHD_PACK_STREAM_EQUIVALENCE_PASS:360 jobs/60 resets/240 malformed/7040 words/1490 stalled/6139 pop-push renewals/16701 clocks','LIGHTHD_UNPACK_COUNTER_CYCLE_PASS",1)
 if name in ('area_delta.py','throughput.py'):
  s=s.replace('stage7c21_area_inventory.json','stage7c22_area_inventory.json').replace('stage7c21_throughput.json','stage7c22_throughput.json').replace('C21','C22').replace('63.37','68.23')
 if name=='cycle_audit.py':s=s.replace('stage7c24_baseline_c21','stage7c24_baseline_c22').replace('C21','C22')
 if name=='proof_reuse.py':s=s.replace('fresh C22 execution','fresh C24 execution')
 if name=='stream_registers.py':
  needle="assert 'WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS'"
  a=s.index(needle)
  s=s[:a]+'''predecoded=[n for n in names if re.search(r'\\|lighthd_process_dma:process_path\\|pack_raw_r',n)]
assert len(predecoded)==1,('registered pack selection',len(predecoded))
result['packer_raw_select']=dict(bits=1,names=predecoded)
assert not any(re.search(r'\\|lighthd_bitpkg:packer\\|gamma_r',n) for n in names),'Obsolete packer gamma snapshot remains'
'''+s[a:]
  s=s.replace('registered hint mask and coordinates/pending bit retained','registered hint mask and coordinates/pending bit/registered pack selection retained')
 # Start the full build only after the fresh connected foundation passes.
 if name=='native_runner.ps1':
  lines=s.splitlines(True);physical=next(x for x in lines if x.startswith('$physicalJob='));lines.remove(physical)
  index=next(i for i,x in enumerate(lines) if x.startswith('$uvmJob='));lines.insert(index,physical);s=''.join(lines)
 u['sim/dilithium/reference_build/stage7c24_'+name]=s
paths=set(json.loads((rb/'stage7c22_source_hashes.json').read_text()))
paths|={'tb/tb_dilithium/'+n+'.sv' for n in ('lighthd_bitpkg_c22_reference','tb_lighthd_pack_fields','tb_lighthd_pack_stream')}
assert len(paths)==262
u['sim/dilithium/reference_build/stage7c24_source_hashes.json']=json.dumps({n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in sorted(paths)},indent=2)+'\n'
u['sim/dilithium/reference_build/stage7c24_source_audit.py']='''from pathlib import Path
import hashlib,json
r=Path.cwd();rb=r/'sim/dilithium/reference_build'
old=json.loads((rb/'stage7c22_source_hashes.json').read_text());new=json.loads((rb/'stage7c24_source_hashes.json').read_text())
for n,d in new.items():assert hashlib.sha256((r/n).read_bytes()).hexdigest()==d,n
assert len(new)==262 and len(set(new)-set(old))==3
assert {n for n in old if old[n]!=new[n]}=={'src/controller/process/lighthd_bitpkg.sv','src/controller/datapath/lighthd_process_dma.sv','sim/dilithium/dilithium_vectors.py'}
print('C24_SOURCE_AUDIT_PASS:262 frozen/two packing-control RTL changes/3 new reference-test files;unpacker,engine and Process arithmetic,RAM rules,QSF,SDC/report exact C22')
'''
patch='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and Path(n).name not in sys.argv[1:]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
