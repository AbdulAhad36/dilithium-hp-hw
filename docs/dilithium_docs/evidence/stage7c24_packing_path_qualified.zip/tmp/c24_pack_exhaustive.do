onerror {quit -code 1 -f}
vmap c24_pack_proof sim/dilithium/work_c24_pack_proof
vsim -gEXHAUSTIVE=1 c24_pack_proof.tb_c24_pack_fields
onfinish stop
run -all
quit -f
