from pathlib import Path
import json,sys
r=Path.cwd();rb=r/'sim/dilithium/reference_build';u={}
s=(rb/'stage7c23_archive.py').read_text().replace('stage7c23','stage7c24').replace('STAGE7C23','STAGE7C24').replace('C23','C24')
s=s.replace('stage7c24_field_conversion_qualified.zip','stage7c24_packing_path_qualified.zip')
s=s.replace("assert 'LIGHTHD_DECODE_FIELD_EXHAUSTIVE_PASS:2390144 vectors/9560960 lane results' in foundation", "assert 'LIGHTHD_PACK_FIELD_PROOF_PASS:exhaustive1/31461480 vectors/125845920 lane checks/2401227 valid-lane encodings/4200 isolated-boundary vectors' in foundation\nassert 'LIGHTHD_PACK_STREAM_EQUIVALENCE_PASS:360 jobs/60 resets/240 malformed/7040 words/1490 stalled/6139 pop-push renewals/16701 clocks' in foundation")
s=s.replace("assert 'C24_SUPPLEMENTAL_VALIDITY_PROOF_PASS' in read(h/'stage7c24_validity_check_console.log')\n",'')
s=s.replace("for p in (r/'tmp').glob('c23*.py')", "for p in (r/'tmp').glob('c24*.py')")
a=s.index("for leaf in ('c23_probe.do'");b=s.index('for p in rb.glob',a)
s=s[:a]+"for leaf in ('c24_probe.do','c24_pack_proof.do','c24_pack_exhaustive.do'):paths.add('tmp/'+leaf)\n"+s[b:]
s=s.replace("for p in (r/'tmp').glob('*c23*.sv')", "for p in (r/'tmp').glob('*c24*.sv')")
s=s.replace('tmp/stage7c24_map_baseline','tmp/stage7c24_bitpkg_map_baseline')
s=s.replace('lighthd_bitunpkg_c22_reference.sv','lighthd_bitpkg_c22_reference.sv')
s=s.replace("('stage7c24_bitunpkg_map_baseline','stage7c24_bitunpkg_map_candidate','stage7c24_bitunpkg_map_shared','stage7c24_separate_calls')", "('stage7c24_bitpkg_map_baseline','stage7c24_bitpkg_map_candidate')")
s=s.replace("stage='7C.23 shared power-of-two packed-field conversion'", "stage='7C.24 centered packing and registered raw/high selection'")
a=s.index(' performance_trial_rejected=');b=s.index(' placed_ALM_target_',a)
s=s[:a]+" selection_pending_until_actual_result_review=True,\n"+s[b:]
s=s.replace('field_vectors=2390144,field_lane_results=9560960,', 'field_vectors=31461480,field_lane_results=125845920,field_valid_lane_encodings=2401227,isolated_boundary_vectors=4200,\n packing_stream=dict(jobs=360,occupied_resets=60,malformed=240,words=7040,stalls=1490,pop_push=6139,clocks=16701,all_pins_state_reservoir_exact_C22=True),')
a=s.index(' supplemental_field_only_validity=');b=s.index(' operand_queue_test=',a);s=s[:a]+s[b:]
a=s.index(" private_probes=");b=s.index(" rejected_architecture=",a)
s=s[:a]+''' private_probes='ActualRTL complete23-bit operand field batches and isolated boundaries/stream pins/state all PASS;actualRAM DMA64/main9/protocol88 controls,requests,digests,bytes and clocks exact C22;standalone map1050->974ALUT/197->195regs is not placed area',
 memory_contract='C22 RAM/collision/384bit operand queue/214bit writer/ring/framing/counter unchanged;packing arithmetic and one preserved raw/high command-selection register;no new operation stage/storage RAM',
'''+s[b:]
s=s.replace("for leaf,marker in [('native_runner.log'", "for leaf,marker in [('collect_runner.log','STAGE7C24_RESULT_COLLECTION_PASS'),('native_runner.log'")
assert 'c23' not in s and 'C23' not in s
u['sim/dilithium/reference_build/stage7c24_archive.py']=s
s=(rb/'stage7c23_archive_replay.py').read_text().replace('stage7c23','stage7c24').replace('C23','C24')
s=s.replace('stage7c24_field_conversion_qualified.zip','stage7c24_packing_path_qualified.zip').replace("'source_audit','validity_check','proof_reuse'", "'source_audit','proof_reuse'")
u['sim/dilithium/reference_build/stage7c24_archive_replay.py']=s
patch='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and n!=sys.argv[1]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
