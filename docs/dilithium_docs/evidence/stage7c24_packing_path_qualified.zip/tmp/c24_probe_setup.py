from pathlib import Path
import json,sys
r=Path.cwd();u={}
s=(r/'sim/dilithium/reference_build/stage7c22_foundation.do').read_text().replace('work_lighthd_foundation','work_c24_probe').replace('lighthd_foundation_work','c24_probe')
s=s.replace('    vlog -sv -work c24_probe [file normalize [file join quartus/dilithium $source]]','''    set stem [file rootname [file tail $source]]
    if {$stem eq "lighthd_bitpkg" || $stem eq "lighthd_process_dma"} {vlog -sv -work c24_probe tmp/c24_${stem}.sv} else {
      vlog -sv -work c24_probe [file normalize [file join quartus/dilithium $source]]
    }''')
a=s.index('foreach top {');b=s.index(' {\n',a)
s=s[:a]+'foreach top {tb_lighthd_process_dma tb_lighthd_controller_lifetimes}'+s[b:]
a=s.index('foreach different {');b=s.index('vsim -L cyclonev_ver -gDIAGNOSTIC=0',a);s=s[:a]+s[b:]
main=(r/'tb/tb_dilithium/tb_lighthd_main.sv').read_text()
for leaf in ('outputs.txt','diagnostic_outputs.txt','protocol_outputs.txt'):main=main.replace('stage7c4_main_'+leaf,'stage7c24_probe_main_'+leaf)
u['tmp/tb_c24_main_probe.sv']=main
s=s.replace('tb/tb_dilithium/tb_lighthd_main.sv','tmp/tb_c24_main_probe.sv');u['tmp/c24_probe.do']=s
u['tmp/c24_probe_compare.py']='''from pathlib import Path
import importlib.util
r=Path.cwd();h=r/'sim/dilithium'
spec=importlib.util.spec_from_file_location('v',h/'dilithium_vectors.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
v.lighthd_main_compare(diagnostic=True,captured=(h/'stage7c24_probe_main_diagnostic_outputs.txt').read_text())
v.lighthd_main_protocol_compare(captured=(h/'stage7c24_probe_main_protocol_outputs.txt').read_text())
for leaf in ('diagnostic_outputs.txt','protocol_outputs.txt'):
 a=(h/('stage7c4_main_'+leaf)).read_text().splitlines();b=(h/('stage7c24_probe_main_'+leaf)).read_text().splitlines()
 assert a==b,leaf
print('C24_PRIVATE_CONTROLLER_COMPARE_PASS:main9/protocol88 payloads/status/attempts/digests/all clocks exact C22;saved C22 fixture token,not a new production token')
'''
patch='*** Begin Patch\n'
for n,s in u.items():
 if len(sys.argv)>1 and n!=sys.argv[1]:continue
 assert not (r/n).exists(),n
 patch+='*** Add File: '+n+'\n'+''.join('+'+x+'\n' for x in s.splitlines())
print(json.dumps(patch+'*** End Patch'))
