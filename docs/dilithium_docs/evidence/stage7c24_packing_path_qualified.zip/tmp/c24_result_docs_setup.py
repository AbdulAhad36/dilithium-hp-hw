from pathlib import Path
import json
r=Path.cwd();s=(r/'tmp/c23_result_docs.py').read_text()
s=s.replace('stage7c23','stage7c24').replace('C23','C24').replace('All261','All262').replace('main261','main262')
s=s.replace("assert 'C24_SUPPLEMENTAL_VALIDITY_PROOF_PASS' in readlog(h/'stage7c24_validity_check_console.log')\n",'')
a=s.index("status=f'''");b=s.index('All262 source hashes',a)
s=s[:a]+"status=f'''## C24 source-qualified and routed packing-path trial\n\n"+s[b:]
a=s.index("common='''");b=s.index("corner_table=",a)
s=s[:a]+'''common='''+repr('''Only two production RTL files change versus C22. BitPkg shares one20-bit
centered-field subtraction per lane and constant validity bounds;ProcessDMA
records raw-versus-high selection in one preserved command register. No new
operation stage,RAM,public port or engine/Process arithmetic is introduced.
BitUnpkg,QSF/SDC/report and all remaining RTL are exact C22. The384-bit raw
operand queue/writer214/Process611/native DSP8 and prior retention guards pass;
the registered pack selector is retained and the old packer gamma snapshot is absent.

Fresh actualRTL field checks:31,461,480 vectors/125,845,920 lane checks,
2,401,227 valid-lane encodings and4,200 isolated boundaries. Adjacent four-lane
batches collectively cover every23-bit value at five formats/three levels,
against C22 actual logic and an independent signed-integer oracle. This forces
field configuration only;it is not transport or main-UVM coverage.
Fresh unforced transport checks360jobs/60occupied resets/240malformed cases,
7,040words/1,490stalls/6,139pop-push renewals on16,701clocks,with C22 pins,
reservoir and state exact. Standalone map1050->974ALUTs/197->195registers is
not a placed-area result. The actual whole-device results are reported above.

''')+'\n'+s[b:]
a=s.index("proof='''");b=s.index('worst=min',a)
s=s[:a]+"proof='''Focused field and transport probes are not merged into main coverage.\nThe first-corrupt-key-byte negative test rejects with zero checked outcomes\nand zero coverage credit. Unchanged full Process arithmetic is explicitly\nreused from C18R1 via10 byte-identical files,not rerun or retagged as fresh.\nThe C24 packing field and transport proofs are fresh executions.\n\n'''\n"+s[b:]
a=s.index('The next timing target is the Process-to-BitPkg');b=s.index('Another{max(',a)
s=s[:a]+s[b:]
s=s.replace('stage7c24_field_conversion_qualified.zip','stage7c24_packing_path_qualified.zip')
s=s.replace("if tail.startswith('## C24'):\n  z=re.search(r'\\n## C22 ',tail);assert z,leaf;tail=tail[z.start()+1:]", "if tail.startswith('## C24'):\n  z=re.search(r'\\n## Historical C22 restoration',tail);assert z,leaf\n  if leaf=='PROCESS_BLOCKS.md':\n   extra+=tail[tail.index('### Why the C24 centered encoding is exact'):z.start()]+'\\n'\n  tail=tail[z.start()+1:]")
assert 'validity_check_console' not in s and 'C23' not in s
print(json.dumps('*** Begin Patch\n*** Add File: tmp/c24_result_docs.py\n'+''.join('+'+x+'\n' for x in s.splitlines())+'*** End Patch'))
