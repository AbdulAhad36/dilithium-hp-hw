from pathlib import Path
import json,re,sys,difflib
r=Path.cwd();h=r/'sim/dilithium';rb=h/'reference_build'
def readlog(path):
 b=path.read_bytes();return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8',errors='replace')
assert 'STAGE7C24_RESULT_COLLECTION_PASS' in (h/'stage7c24_collect_runner.log').read_text()
m=json.loads((rb/'stage7c24_metrics.json').read_text());old=json.loads((rb/'stage7c22_metrics.json').read_text());a=m['area']
f=min(c['fmax_mhz'] for c in m['corners']);setup=min(c['setup_ns'] for c in m['corners']);hold=min(c['hold_ns'] for c in m['corners'])
delta=a['placed_ALMs']-old['area']['placed_ALMs'];gain=100*(f/68.23-1)
cycles=json.loads((rb/'stage7c24_cycle_deltas.json').read_text());assert len(cycles['native'])==286 and len(cycles['UVM'])==30
native=[x['delta'] for x in cycles['native']];uvm=[n for x in cycles['UVM'] for n in x['delta'].values()]
cycle_note='All286 completed official/protocol latencies and30 main-UVM latency rows exactly match C22;the12 reset-prefix records also match. No operation cycles were added.' if all(n==0 for n in native+uvm) else f'Completed native latency deltas range{min(native):+}..{max(native):+} clocks;main-UVM field deltas range{min(uvm):+}..{max(uvm):+}. Detailed operation means and differences are recorded in the cycle audit.'
u=(h/'stage7c24_uvm.log').read_text(encoding='utf-8',errors='replace');bins={}
for key,label in [('functional','OVERALL FUNCTIONAL COVERAGE'),('module','DUT MODULE CODE COVERAGE'),('package','SHARED DUT PACKAGE CODE COVERAGE'),('overall','OVERALL DUT CODE COVERAGE')]:
 z=re.search(re.escape(label)+r'.*?:\s*(\d+) / (\d+)',u);assert z,label;bins[key]=tuple(map(int,z.groups()))
token=(h/'stage7c4_main_inputs.txt').read_text().split()[0];uvmtoken=re.search(r'[0-9a-f]{64}',(h/'stage7_uvm_inputs.txt').read_text())[0]
status=f'''## C24 source-qualified and routed packing-path trial

**C24 is retained as a qualified area option;C22 remains the working
baseline because Fmax and throughput must stay up.** C24 saves454 placed
ALMs but loses0.94% estimated operation rates. After create-only C24 archive
and fresh extraction replay,restore the exact C22 sources and saved fixtures.
This is not target or user performance acceptance.

All262 source hashes,fresh foundation/field/stream tests,210 official commands,
88 protocol commands,90 checker corruptions and main33UVM/negative pass.
Actual final placement: **{a['placed_ALMs']:,} ALMs**,{a['registers']:,} registers,
{a['M10Ks']} M10Ks and{a['DSPs']} DSPs. Worst Fmax **{f:.2f}MHz**,setup **{setup:+.3f}ns**,
hold **{hold:+.3f}ns**. Versus C22:{delta:+,} placed ALMs,{gain:+.2f}% Fmax.
The same Cyclone V,6.757ns and hold constraints remain. Under20K/148MHz and
user performance acceptance remain open;C20/C21/C22 are preserved. Whole-fit
counts are actual final placed ALMs. Full corner/rate tables are in THROUGHPUT.md.

{cycle_note}

Physical completion: {m['physical_flow']}.

'''
common='Only two production RTL files change versus C22. BitPkg shares one20-bit\ncentered-field subtraction per lane and constant validity bounds;ProcessDMA\nrecords raw-versus-high selection in one preserved command register. No new\noperation stage,RAM,public port or engine/Process arithmetic is introduced.\nBitUnpkg,QSF/SDC/report and all remaining RTL are exact C22. The384-bit raw\noperand queue/writer214/Process611/native DSP8 and prior retention guards pass;\nthe registered pack selector is retained and the old packer gamma snapshot is absent.\n\nFresh actualRTL field checks:31,461,480 vectors/125,845,920 lane checks,\n2,401,227 valid-lane encodings and4,200 isolated boundaries. Adjacent four-lane\nbatches collectively cover every23-bit value at five formats/three levels,\nagainst C22 actual logic and an independent signed-integer oracle. This forces\nfield configuration only;it is not transport or main-UVM coverage.\nFresh unforced transport checks360jobs/60occupied resets/240malformed cases,\n7,040words/1,490stalls/6,139pop-push renewals on16,701clocks,with C22 pins,\nreservoir and state exact. Standalone map1050->974ALUTs/197->195registers is\nnot a placed-area result. The actual whole-device results are reported above.\n\n'
corner_table='|Corner|Fmax MHz|Setup ns|Setup TNS ns|Hold ns|Hold TNS ns|\n|---|---:|---:|---:|---:|---:|\n'
for c in m['corners']:corner_table+=f"|{c['corner']}|{c['fmax_mhz']:.2f}|{c['setup_ns']:+.3f}|{c['setup_tns_ns']:.3f}|{c['hold_ns']:+.3f}|{c['hold_tns_ns']:.3f}|\n"
t=json.loads((rb/'stage7c24_throughput.json').read_text());rates='|Operation|Level|Mean cycles|Cycle delta vs C22|Estimated latency us|Estimated operations/s|Rate delta vs C22|\n|---|---:|---:|---:|---:|---:|---:|\n'
for row in t['rows']:rates+=f"|{row['operation']}|{row['level']}|{row['cycles']:.2f}|{row['cycle_delta_vs_C22']:+.2f}|{row['latency_us']:.1f}|{row['operations_per_second']:.1f}|{row['rate_gain_vs_C22_pct']:+.2f}%|\n"
cov='|Main coverage|Hit / defined|Percent|\n|---|---:|---:|\n'
for key,label in [('functional','Functional'),('module','RTL module raw code'),('package','Executable shared package raw code'),('overall','Overall DUT raw code')]:
 hit,total=bins[key];cov+=f'|{label}|{hit} / {total}|{100*hit/total:.2f}%|\n'
proof='''Focused field and transport probes are not merged into main coverage.
The first-corrupt-key-byte negative test rejects with zero checked outcomes
and zero coverage credit. Unchanged full Process arithmetic is explicitly
reused from C18R1 via10 byte-identical files,not rerun or retagged as fresh.
The C24 packing field and transport proofs are fresh executions.

'''
worst=min(m['corners'],key=lambda c:c['setup_ns']);text=(r/f"quartus/dilithium/critical_full/{worst['corner']}_setup.rpt").read_text(errors='replace')
path=None
for line in text.splitlines():
 c=[x.strip() for x in line.split(';')[1:-1]]
 if len(c)==8 and re.fullmatch(r'-?\d+\.\d+',c[0]):path=c;break
assert path
levels=re.search(r'; Number of Logic Levels\s*;\s*;\s*(\d+)',text);assert levels
short=lambda node:'|'.join(node.split('|')[-2:])
nextnote=f'''Fresh worst setup path ({worst['corner']}):`{short(path[1])}` to
`{short(path[2])}`,{levels[1]} logic levels/{path[-1]}ns data delay. Use this
path and disjoint placed-area scopes to choose the next Stage7C trial.
Another{max(0,a['placed_ALMs']-19999)} actual placed ALMs must be removed to reach19999.
The packing change is no longer the worst measured path. Next evaluate the
saved C23 field-conversion change together with this packing change:their
separate routed trials exposed different critical paths. A combined trial
must repeat source/cycle/physical gates;separate savings are not additive PPA.
No target acceptance,Stage8,commit,branch change or complete unpublished-RTL
replica claim follows from these gates.

Create-only evidence:`evidence/stage7c24_packing_path_qualified.zip` and
its SHA256 sidecar. Fresh extraction replay is required before handoff;it
checks saved evidence without fixture regeneration or native reruns.

'''
extras={'DILITHIUM_PLAN.md':common+nextnote,'THROUGHPUT.md':common+corner_table+'\n'+rates+'\nRates use measured cycles and actual worst Fmax;sequential estimates,not board measurements or command initiation interval.\n\n','MEMORY_MAP.md':common,'PROCESS_BLOCKS.md':common,'COVERAGE.md':cov+'\n'+proof,'REFERENCE_VERIFICATION.md':common+f'Main token `{token}`.\n\nUVM token `{uvmtoken}`.\n\n'+proof,'SPECIFICATION.md':common}
patch='*** Begin Patch\n'
for leaf,extra in extras.items():
 if len(sys.argv)>1 and leaf not in sys.argv[1:]:continue
 p=r/'docs/dilithium_docs'/leaf;s=p.read_text(encoding='utf-8');title,tail=s.split('\n\n',1)
 if tail.startswith('## C24'):
  z=re.search(r'\n## Historical C22 restoration',tail);assert z,leaf
  if leaf=='PROCESS_BLOCKS.md':
   extra+=tail[tail.index('### Why the C24 centered encoding is exact'):z.start()]+'\n'
  tail=tail[z.start()+1:]
 new=title+'\n\n'+status+extra+tail
 d=list(difflib.unified_diff(s.splitlines(True),new.splitlines(True)))
 patch+='*** Update File: '+p.relative_to(r).as_posix()+'\n'+''.join('@@\n' if x.startswith('@@') else x for x in d[2:])
print(json.dumps(patch+'*** End Patch'))
