$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
foreach($variant in @('baseline','candidate')){
 $folder="tmp/stage7c24_bitpkg_map_${variant}"
 Push-Location -LiteralPath $folder
 & F:/altera/quartus/bin64/quartus_map.exe probe -c probe --read_settings_files=on --write_settings_files=off *> map_console.log
 $code=$LASTEXITCODE;Pop-Location
 if($code -ne 0){throw "C24 map failed $variant"}
 "C24_MAP_PASS $variant"
}
