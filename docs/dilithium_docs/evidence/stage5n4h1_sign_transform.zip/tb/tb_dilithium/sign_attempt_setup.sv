`timescale 1ps/1ps
// Reusable focused-test fixture;real key/mask/matrix clients,ONE services.
module sign_attempt_setup(input logic clk,rst,
  input wire dilithium_service_pkg::request_t request_i,
  output dilithium_service_pkg::response_t response_o);
  import dilithium_service_pkg::*;
  logic command_valid_i=0,command_ready_o,busy_o,fault_o;logic [15:0] command_id_i=0;
  logic context_valid_i;logic [1:0] context_param_i;logic [15:0] context_id_i;
  logic [63:0] context_regions_i;logic [255:0] context_rho_i,key;logic [511:0] tr;
  logic mask_valid_i;logic [15:0] mask_id_i;logic [63:0] mask_regions_i;logic [6:0][5:0] mask_handles_i;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o,done_detail_o;logic [15:0] done_id_o;
  logic result_valid_o;logic [63:0] result_regions_o;logic [6:0][5:0] result_yhat_o;
  logic [7:0][5:0] result_low_o,result_high_o;logic clear_valid_i=0,clear_ready_o;
  request_t service_o,key_request,mask_request,consumer='0,wire_request;response_t service_i,actual;
  logic matrix_take_valid=0,matrix_take_ready;
  sign_matrix_prepare matrix(.take_valid_i(matrix_take_valid),.take_ready_o(matrix_take_ready),.*);
  dilithium_services services(.clk(clk),.rst(rst),.request_i(wire_request),.response_o(actual));
  logic kv=0,kr,kbusy,kactive,kfault,ki=0,kir,klast=0,kdone,kdr=0,kclear=0,kcr;
  logic [1:0] kp=0;logic [63:0] kd=0;logic [9:0] kindex=0;
  logic [2:0] kcode,kdetail;logic [15:0] kid;logic [22:0][5:0] kh;
  sign_key_prepare prep(.clk(clk),.rst(rst),.command_valid_i(kv),.command_ready_o(kr),.busy_o(kbusy),
    .service_active_o(kactive),.fault_o(kfault),.command_param_i(kp),.command_id_i(16'(100+kp)),
    .command_base_i(6'd0),.command_work_i(6'd31),.input_valid_i(ki),.input_ready_o(kir),.input_data_i(kd),
    .input_bytes_i(4'd8),.input_index_i(kindex),.input_last_i(klast),.done_valid_o(kdone),.done_ready_i(kdr),
    .done_code_o(kcode),.done_detail_o(kdetail),.done_id_o(kid),.context_valid_o(context_valid_i),
    .context_param_o(context_param_i),.context_id_o(context_id_i),.context_regions_o(context_regions_i),
    .context_handles_o(kh),.context_rho_o(context_rho_i),.context_key_o(key),.context_tr_o(tr),
    .clear_valid_i(kclear),.clear_ready_o(kcr),.service_o(key_request),.service_i(actual));
  logic mv=0,mr,mbusy,mfault,mpv=0,mpr,mplast=0,mdone,mdr=0,mclear=0,mcr;
  logic [63:0] mpdata=0;logic [15:0] mpindex=0;logic [3:0] mpbytes=8;
  logic [255:0] rnd=0;logic [15:0] mask_nonce=0,mid;logic [2:0] mcode;
  logic [511:0] mu,seed;
  assign mask_id_i=16'(1000+kp);
  sign_mask_prepare front(.clk(clk),.rst(rst),.command_valid_i(mv),.command_ready_o(mr),.busy_o(mbusy),.fault_o(mfault),
    .context_valid_i(context_valid_i),.context_param_i(context_param_i),.context_id_i(context_id_i),
    .context_regions_i(context_regions_i),.context_key_i(key),.context_tr_i(tr),.command_id_i(mask_id_i),
    .command_message_len_i(16'd169),.command_nonce_i(mask_nonce),.command_context_len_i(9'd7),.command_base_i(6'd32),
    .command_rnd_i(rnd),.payload_valid_i(mpv),.payload_ready_o(mpr),.payload_data_i(mpdata),.payload_bytes_i(mpbytes),
    .payload_index_i(mpindex),.payload_last_i(mplast),.done_valid_o(mdone),.done_ready_i(mdr),.done_code_o(mcode),.done_id_o(mid),
    .result_valid_o(mask_valid_i),.result_mu_o(mu),.result_seed_o(seed),.result_regions_o(mask_regions_i),.result_handles_o(mask_handles_i),
    .clear_valid_i(mclear),.clear_ready_o(mcr),.service_o(mask_request),.service_i(actual));

  int p=0,nonce=0,sklen=0,case_no=-1,fd=0,keys=0,masks=0,matrices=0;
  bit preparing_mask=0,preparing_matrix=0,manual=0;
  always_comb begin
    wire_request=kactive?key_request:(preparing_mask?mask_request:(preparing_matrix?service_o:(manual?consumer:request_i)));
    service_i=actual;response_o=actual;
  end
  task automatic reset_controls();
    kv=0;ki=0;kdr=0;kclear=0;mv=0;mpv=0;mdr=0;mclear=0;
    command_valid_i=0;done_ready_i=0;clear_valid_i=0;matrix_take_valid=0;consumer='0;
    preparing_mask=0;preparing_matrix=0;manual=0;
  endtask
  task automatic seed_region(input int region);
    manual=1;consumer='0;consumer.job_valid=1;{consumer.job_bank,consumer.job_region}=6'(region);
    consumer.job_mode=2;consumer.job_param=0;consumer.job_id=60000;consumer.status_ready=1;
    do @(posedge clk);while(!actual.job_ready);@(negedge clk);#1;consumer.job_valid=0;
    while(actual.active!=0)begin @(negedge clk);#1;end consumer='0;
    if(!actual.complete[region])$fatal(1,"Matrix blocker seed failed");manual=0;
  endtask
  task automatic prepare_key(input string hexbytes);
    int parsed;byte unsigned value;kp=2'(p);kv=1;do @(posedge clk);while(!kr);@(negedge clk);#1;kv=0;
    for(int w=0;w<sklen/8;w++)begin
      kd=0;for(int b=0;b<8;b++)begin parsed=$sscanf(hexbytes.substr(2*(8*w+b),2*(8*w+b)+1),"%h",value);if(parsed!=1)$fatal(1,"Matrix SK byte");kd[8*b+:8]=value;end
      kindex=10'(w);klast=w==sklen/8-1;ki=1;do @(posedge clk);while(!kir);@(negedge clk);#1;ki=0;
    end
    while(!kdone)begin @(negedge clk);#1;end if(kcode || !context_valid_i)$fatal(1,"Matrix key prepare failed");
    $fdisplay(fd,"K %0d %0d %016h %064h",case_no,p,context_regions_i,context_rho_i);keys++;
    kdr=1;@(posedge clk);@(negedge clk);#1;kdr=0;seed_region(50);
  endtask
  task automatic prepare_mask(input string bodyhex);
    int parsed;byte unsigned value;preparing_mask=1;mask_nonce=16'(nonce);mv=1;
    do @(posedge clk);while(!mr);@(negedge clk);#1;mv=0;
    for(int w=0;w<22;w++)begin
      mpdata=0;for(int b=0;b<8;b++)begin parsed=$sscanf(bodyhex.substr(2*(8*w+b),2*(8*w+b)+1),"%h",value);if(parsed!=1)$fatal(1,"Matrix body byte");mpdata[8*b+:8]=value;end
      mpindex=16'(w);mplast=w==21;mpv=1;do @(posedge clk);while(!mpr);@(negedge clk);#1;mpv=0;
    end
    while(!mdone)begin @(negedge clk);#1;end if(mcode || !mask_valid_i)$fatal(1,"Matrix mask prepare failed");
    $fdisplay(fd,"M %0d %0d %016h %011h %0128h %0128h",case_no,nonce,mask_regions_i,mask_handles_i,mu,seed);masks++;
    mdr=1;@(posedge clk);@(negedge clk);#1;mdr=0;preparing_mask=0;
  endtask

  task automatic prepare_all(input int level,initial_nonce,input string skhex,bodyhex,input logic [255:0] random_value);
    p=level;nonce=initial_nonce;sklen=skhex.len()/2;rnd=random_value;
    if(!context_valid_i)prepare_key(skhex);
    if(result_valid_o && mask_nonce!=nonce)begin
      preparing_matrix=1;clear_valid_i=1;do @(posedge clk);while(!clear_ready_o);@(negedge clk);#1;clear_valid_i=0;
      while(busy_o)begin @(negedge clk);#1;end preparing_matrix=0;
    end
    if(mask_valid_i && mask_nonce!=nonce)begin
      preparing_mask=1;mclear=1;do @(posedge clk);while(!mcr);@(negedge clk);#1;mclear=0;
      while(mbusy)begin @(negedge clk);#1;end preparing_mask=0;
    end
    if(!mask_valid_i)prepare_mask(bodyhex);
    if(!result_valid_o)begin
      preparing_matrix=1;command_id_i=16'(10000+p);command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;
      while(!done_valid_o)begin @(negedge clk);#1;end
      if(done_code_o || !result_valid_o)$fatal(1,"Challenge source matrix preparation failed");
      $fdisplay(fd,"U %0d %0d %016h %011h %012h %012h",case_no,done_id_o,result_regions_o,result_yhat_o,result_low_o,result_high_o);matrices++;
      done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;preparing_matrix=0;
    end
  endtask
endmodule

