# Whole-main baseline only. Run after compiling dilithium_full.qpf.
project_open dilithium_full -revision dilithium_full
if {[get_global_assignment -name TOP_LEVEL_ENTITY] ne "dilithium"} {error "Wrong synthesis top"}
create_timing_netlist -model slow
read_sdc
file mkdir critical_full
set guard [open critical_full/retained_registers.rpt w]
foreach {label pattern minimum} {
  main_state *state* 1
  keygen_controller *core|state* 1
  sign_controller *g_sign*signer|state* 1
  verify_controller *g_verify*verifier|state* 1
  keccak_state *hash|*u_core|state_array* 3200
  sampler_extract_secret *sample|extract_secret_r* 64
  sampler_decode_secret *sample|decode_secret_r* 64
  sampler_packed_secret *sample|packed_secret_r* 64
} {
  set names {}
  foreach_in_collection reg [get_registers $pattern] {
    set name [get_node_info -name $reg]
    if {![string match {*~DUPLICATE*} $name]} {lappend names $name}
  }
  set count [llength [lsort -unique $names]]
  puts $guard "$label:$count original mapped register bits; minimum:$minimum"
  if {$count<$minimum} {close $guard;error "Missing retained registers for $label"}
}
puts $guard {WHOLE_MAIN_RETAINED_REGISTER_GUARD_PASS}
close $guard
foreach corner {{slow 85} {slow 0} {fast 85} {fast 0}} {
  lassign $corner model temperature
  set_operating_conditions -model $model -temperature $temperature -voltage 1100
  update_timing_netlist
  set prefix critical_full/${model}_${temperature}C
  report_timing -setup -npaths 5 -detail full_path -file ${prefix}_setup.rpt
  report_timing -hold -npaths 5 -detail full_path -file ${prefix}_hold.rpt
  report_clock_fmax_summary -file ${prefix}_fmax.rpt
}
delete_timing_netlist
project_close
