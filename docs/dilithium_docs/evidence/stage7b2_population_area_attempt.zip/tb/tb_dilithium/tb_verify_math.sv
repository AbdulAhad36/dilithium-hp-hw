`timescale 1ps/1ps
// Real first-two-frame owner -> atomic adoption -> math owner -> ONE services.
module tb_verify_math;
  import dilithium_service_pkg::*;
  logic clk=0,rst=1;always begin #3378 clk=1;#3379 clk=0;end
  logic command_valid_i=0,command_ready_o,busy_o,fault_o;logic [15:0] command_id_i=0,command_message_len_i=0;logic [8:0] command_context_len_i=0;
  logic context_valid_i,context_take_valid_o,context_take_ready_i;logic [1:0] context_param_i;logic [15:0] context_id_i;
  logic [63:0] context_regions_i;logic [7:0][5:0] context_t1_i,context_hints_i;logic [6:0][5:0] context_z_i;
  logic [255:0] context_rho_i;logic [511:0] context_tr_i,context_ctilde_i;
  logic payload_valid_i=0,payload_ready_o,payload_last_i=0;logic [63:0] payload_data_i=0;logic [3:0] payload_bytes_i=0;logic [15:0] payload_index_i=0;
  logic done_valid_o,done_ready_i=0;logic [2:0] done_code_o,done_detail_o;logic [15:0] done_id_o;
  logic result_valid_o;logic [1:0] result_param_o;logic [15:0] result_id_o;logic [63:0] result_regions_o;
  logic [7:0][5:0] result_t1hat_o,result_hints_o;logic [6:0][5:0] result_zhat_o;logic [5:0] result_chat_o;
  logic [255:0] result_rho_o;logic [511:0] result_mu_o,result_ctilde_o;
  logic clear_valid_i=0,clear_ready_o,take_valid_i=0,take_ready_o;
  request_t service_o,prep_request,external_request,actual;response_t service_i,response;
  int owner=0,cycles=0,elapsed=0,case_no=-1,p,jid,base,scenario,abort_phase,adopt,ctxlen,mlen,expected_code,expected_detail,sentinel;
  int fd,count,commands=0,adoptions=0,dones=0,aborts=0,inputs=0,allocs=0,writes=0,finishes=0,releases=0,reads=0,raws=0,outs=0,ops=0;
  int raw_index=0,sample_index=0;bit monitor=0,test_passed=0,change_source=0,inject_raw=0;
  logic pv=0,pr,pbusy,pfault,pi=0,pir,plast=0,pdone,pdr=0,pclear=0,pcr,ptake,ptr,pcvalid;
  logic [1:0] pp=0,pcp;logic [15:0] pid=0,pslen=0,pindex=0,pcid;logic [5:0] pbase=0;logic [63:0] pdata=0,pregions;
  logic [3:0] pbytes=8;logic [2:0] pcode,pdetail;logic [15:0] pdid;
  logic [7:0][5:0] pt1,phints;logic [6:0][5:0] pz;logic [255:0] prho;logic [511:0] ptrhash,pctilde;
  verify_math_prepare dut(.*);
  verify_input_prepare prep(.clk(clk),.rst(rst),.command_valid_i(pv),.command_ready_o(pr),.busy_o(pbusy),.fault_o(pfault),
    .command_param_i(pp),.command_id_i(pid),.command_signature_len_i(pslen),.command_base_i(pbase),
    .input_valid_i(pi),.input_ready_o(pir),.input_data_i(pdata),.input_bytes_i(pbytes),.input_index_i(pindex),.input_last_i(plast),
    .done_valid_o(pdone),.done_ready_i(pdr),.done_code_o(pcode),.done_detail_o(pdetail),.done_id_o(pdid),
    .context_valid_o(pcvalid),.context_param_o(pcp),.context_id_o(pcid),.context_regions_o(pregions),.context_t1_o(pt1),.context_hints_o(phints),.context_z_o(pz),
    .context_rho_o(prho),.context_tr_o(ptrhash),.context_ctilde_o(pctilde),.clear_valid_i(pclear),.clear_ready_o(pcr),.take_valid_i(ptake),.take_ready_o(ptr),
    .service_o(prep_request),.service_i(response));
  dilithium_services physical(.clk(clk),.rst(rst),.request_i(actual),.response_o(response));
  always_comb begin
    context_valid_i=pcvalid;context_param_i=pcp;context_id_i=pcid;context_regions_i=pregions;
    context_t1_i=pt1;context_z_i=pz;context_hints_i=phints;context_rho_i=prho;context_tr_i=ptrhash;context_ctilde_i=pctilde;
    if(scenario==3)context_t1_i[1]=pt1[0];
    if(scenario==4 || change_source)context_id_i=pcid^16'd1;
    context_take_ready_i=ptr && abort_phase!=1;ptake=context_take_valid_o && abort_phase!=1;
    actual=owner==2?service_o:owner==1?prep_request:external_request;service_i=response;
    if(owner==2)begin
      actual.raw_input_valid=service_o.raw_input_valid && cycles%11>3;service_i.raw_input_ready=response.raw_input_ready && cycles%11>3;
      actual.raw_output_ready=service_o.raw_output_ready && cycles%17>5 && abort_phase!=3;
      service_i.raw_output_valid=response.raw_output_valid && cycles%17>5 && abort_phase!=3;
      actual.input_valid=service_o.input_valid && cycles%7>2;service_i.input_ready=response.input_ready && cycles%7>2;
      actual.status_ready=service_o.status_ready && cycles%7>2;service_i.status_valid=response.status_valid && cycles%7>2;
      actual.op_valid=service_o.op_valid && cycles%5>1;service_i.op_ready=response.op_ready && cycles%5>1;
      actual.op_done_ready=service_o.op_done_ready && cycles%7>1;service_i.op_done_valid=response.op_done_valid && cycles%7>1;
      if(scenario==5 && dut.state==1)service_i.complete=0;
      if(scenario==13)service_i.status_id=16'hf00d;
      if(scenario==14)service_i.op_done_id=16'hf00d;
      if(scenario==16 && dut.ordinal_r==0)actual.op_a_id=service_o.op_a_id^16'd1;
      if(scenario==17 && dut.state==5 || scenario==18 && dut.state==10)service_i.reserved='1;
      if(inject_raw)service_i.raw_output_id=16'hf00d;
    end
  end
  logic held_payload=0,held_done=0,held_raw=0;logic [84:0] payload_snapshot;logic [21:0] done_snapshot;logic [149:0] raw_snapshot;
  always @(posedge clk)begin
    cycles++;
    if(rst)begin held_payload=0;held_done=0;held_raw=0;end
    else if(monitor)begin
      elapsed++;if(elapsed>300000)$fatal(1,"Verify math watchdog case%0d state%0d",case_no,dut.state);
      if(fault_o && abort_phase!=11 && abort_phase!=12)$fatal(1,"Unexpected math fault case%0d state%0d",case_no,dut.state);
      if(held_payload && !done_valid_o && !fault_o && (!payload_valid_i || payload_snapshot!=={payload_index_i,payload_bytes_i,payload_last_i,payload_data_i}))$fatal(1,"Held Verify message changed");
      held_payload=payload_valid_i && !payload_ready_o;payload_snapshot={payload_index_i,payload_bytes_i,payload_last_i,payload_data_i};
      if(held_done && (!done_valid_o || done_snapshot!=={done_id_o,done_code_o,done_detail_o}))$fatal(1,"Held math completion changed");
      held_done=done_valid_o && !done_ready_i;done_snapshot={done_id_o,done_code_o,done_detail_o};
      if(held_raw && (!response.raw_output_valid || raw_snapshot!=={response.raw_output_core,response.raw_output_id,response.raw_output_bytes,response.raw_output_data}))$fatal(1,"Held physical hash changed");
      held_raw=response.raw_output_valid && !actual.raw_output_ready;raw_snapshot={response.raw_output_core,response.raw_output_id,response.raw_output_bytes,response.raw_output_data};
      if(command_valid_i && command_ready_o)begin $fdisplay(fd,"C %0d %0d %0d %0d",case_no,command_id_i,command_context_len_i,command_message_len_i);commands++;end
      if(context_take_valid_o && context_take_ready_i)begin $fdisplay(fd,"T %0d %016h",case_no,pregions);adoptions++;end
      if(payload_valid_i && payload_ready_o)begin $fdisplay(fd,"I %0d %0d %0d %0d %016h",case_no,payload_index_i,payload_bytes_i,payload_last_i,payload_data_i);inputs++;end
      if(owner==2 && actual.raw_valid && response.raw_ready)begin $fdisplay(fd,"Q %0d %0d %0d %0d %0d %0d",case_no,response.raw_core,actual.raw_id,actual.raw_mode,actual.raw_message_len,actual.raw_output_len);raw_index=0;end
      if(owner==2 && actual.raw_input_valid && response.raw_input_ready)begin $fdisplay(fd,"B %0d %0d %016h",case_no,raw_index,actual.raw_input_data);raw_index++;raws++;end
      if(owner==2 && actual.raw_output_ready && response.raw_output_valid)begin $fdisplay(fd,"O %0d %0d %0d %0d %032h",case_no,service_i.raw_output_core,service_i.raw_output_id,service_i.raw_output_bytes,service_i.raw_output_data);outs++;end
      if(owner==2 && actual.raw_done_ready && response.raw_done_valid)$fdisplay(fd,"G %0d %0d %0d",case_no,service_i.raw_done_core,service_i.raw_done_id);
      if(dut.fd && dut.fack)$fdisplay(fd,"X %0d %0d %0d",case_no,dut.fdid,dut.fcode);
      if(owner==2 && actual.job_valid && response.job_ready)begin $fdisplay(fd,"J %0d %0d %0d %0d %0d %0d %0d",case_no,response.job_core,actual.job_id,actual.job_param,{actual.job_bank,actual.job_region},actual.job_mode,actual.message_len);sample_index=0;end
      if(owner==2 && actual.input_valid && response.input_ready)begin $fdisplay(fd,"S %0d %0d %016h",case_no,sample_index,actual.input_data);sample_index++;end
      if(owner==2 && actual.status_ready && response.status_valid)$fdisplay(fd,"H %0d %0d %0d %0d",case_no,service_i.status_core,service_i.status_id,service_i.status_code);
      if(owner==2 && actual.op_valid && response.op_ready)begin $fdisplay(fd,"N %0d %0d %0d %0d %0d %0d %0d",case_no,dut.ordinal_r,actual.op,actual.op_a_region,actual.op_a_id,actual.op_dest_region,actual.op_id);ops++;end
      if(owner==2 && actual.op_done_ready && response.op_done_valid)$fdisplay(fd,"V %0d %0d %0d %0d",case_no,service_i.op_done_id,service_i.op_done_code,service_i.op_done_region);
      if(physical.datapath.subsystem.store.alloc_fire)begin $fdisplay(fd,"A %0d %0d %0d %0d %0d %0d %0d %0d",case_no,physical.datapath.subsystem.store.alloc_region,physical.datapath.subsystem.store.alloc_id_i,physical.datapath.subsystem.store.alloc_mode_i,physical.datapath.subsystem.store.alloc_param_i,physical.datapath.subsystem.store.alloc_ntt_domain_i,physical.datapath.subsystem.store.alloc_rewrite_i,physical.datapath.subsystem.store.alloc_compute_i);allocs++;end
      if(physical.datapath.subsystem.store.write_fire)begin $fdisplay(fd,"W %0d %0d %0d %06h %0d",case_no,physical.datapath.subsystem.store.write_region,physical.datapath.subsystem.store.write_index_i,physical.datapath.subsystem.store.write_data_i,physical.datapath.subsystem.store.write_last_i);writes++;end
      if(physical.datapath.subsystem.store.finish_fire)begin $fdisplay(fd,"M %0d %0d %0d %0d",case_no,physical.datapath.subsystem.store.finish_region,physical.datapath.subsystem.store.finish_code_i,physical.datapath.subsystem.store.count_r[physical.datapath.subsystem.store.finish_region]);finishes++;end
      if(physical.datapath.subsystem.store.release_fire)begin $fdisplay(fd,"F %0d %0d",case_no,physical.datapath.subsystem.store.release_region);releases++;end
    end
  end
  task automatic reset_all();
    release dut.formatter.done_id_o;release physical.datapath.subsystem.store.fault_o;
    rst=1;monitor=0;owner=0;external_request='0;pv=0;pi=0;pdr=0;pclear=0;command_valid_i=0;payload_valid_i=0;done_ready_i=0;clear_valid_i=0;take_valid_i=0;change_source=0;inject_raw=0;
    repeat(3)@(posedge clk);@(negedge clk);#1;rst=0;@(negedge clk);#1;
    if(busy_o || pbusy || fault_o || pfault || response.reserved || response.active || !command_ready_o)$fatal(1,"Verify math reset");
  endtask
  task automatic send_prep(input string data);
    int n,parsed;byte unsigned b;n=data.len()/2;
    for(int w=0;w<(n+7)/8;w++)begin pdata='1;pbytes=4'(n-8*w>=8?8:n-8*w);pindex=16'(w);plast=8*(w+1)>=n;
      for(int j=0;j<int'(pbytes);j++)begin parsed=$sscanf(data.substr(2*(8*w+j),2*(8*w+j)+1),"%h",b);pdata[8*j+:8]=b;end
      pi=1;do @(posedge clk);while(!pir);@(negedge clk);#1;pi=0;
    end
  endtask
  task automatic setup(input string pk,input string sig,input string seed);
    int parsed;byte unsigned b;owner=0;external_request='0;external_request.job_valid=1;external_request.job_mode=2;external_request.job_id=62000;
    {external_request.job_bank,external_request.job_region}=6'(sentinel);external_request.message_len=66;
    do @(posedge clk);while(!response.job_ready);@(negedge clk);#1;external_request.job_valid=0;
    for(int w=0;w<9;w++)begin external_request.input_data=0;
      for(int j=0;j<8;j++)if(8*w+j<66)begin parsed=$sscanf(seed.substr(2*(8*w+j),2*(8*w+j)+1),"%h",b);external_request.input_data[8*j+:8]=b;end
      external_request.input_valid=1;do @(posedge clk);while(!response.input_ready);@(negedge clk);#1;external_request.input_valid=0;
    end
    while(!response.status_valid)begin @(negedge clk);#1;end
    if(response.status_code!=0)$fatal(1,"Math sentinel");external_request.status_ready=1;@(posedge clk);@(negedge clk);#1;external_request='0;
    while(response.active)begin @(negedge clk);#1;end
    owner=1;pp=2'(p);pid=16'(jid);pslen=16'(sig.len()/2);pbase=6'(base);pv=1;
    do @(posedge clk);while(!pr);@(negedge clk);#1;pv=0;send_prep(pk);send_prep(sig);
    while(!pdone)begin @(negedge clk);#1;end
    if(pcode!=0 || !pcvalid)$fatal(1,"Math source preparation");pdr=1;@(posedge clk);@(negedge clk);#1;pdr=0;
  endtask
  task automatic send_payload(input string data);
    int n,size,parsed;byte unsigned b;n=data=="-"?0:data.len()/2;
    for(int w=0;w<(n+7)/8;w++)begin
      if(rst || done_valid_o || fault_o)return;
      if(w%7==2)begin @(negedge clk);#1;if(rst || done_valid_o || fault_o)return;end
      payload_data_i='1;size=n-8*w>=8?8:n-8*w;
      for(int j=0;j<size;j++)begin parsed=$sscanf(data.substr(2*(8*w+j),2*(8*w+j)+1),"%h",b);payload_data_i[8*j+:8]=b;end
      payload_bytes_i=4'(size);payload_index_i=16'(w);payload_last_i=8*(w+1)>=n;
      if(scenario==7 && w==0)payload_index_i=1024;
      if(scenario==8 && w==0)payload_bytes_i=0;
      if(scenario==9 && w==0)payload_last_i=1;
      if(scenario==10 && payload_last_i)payload_last_i=0;
      payload_valid_i=1;do @(posedge clk);while(!payload_ready_o && !done_valid_o && !fault_o && !rst);
      @(negedge clk);#1;payload_valid_i=0;
    end
  endtask
  task automatic read_word(input int region,input int w,input bit held);
    owner=0;external_request='0;external_request.read_valid=1;{external_request.read_bank,external_request.read_region}=6'(region);external_request.read_word=6'(w);
    do @(posedge clk);while(!response.read_ready);@(negedge clk);#1;external_request.read_valid=0;
    while(!response.response_valid)begin @(negedge clk);#1;end
    if(held)begin clear_valid_i=1;take_valid_i=1;repeat(7)begin @(posedge clk);if(clear_ready_o || take_ready_o)$fatal(1,"Math pending read handoff");end
      @(negedge clk);#1;clear_valid_i=0;take_valid_i=0;$fdisplay(fd,"HOLD %0d %0d %0d",case_no,region,w);end
    $fdisplay(fd,"R %0d %0d %0d %0d %0d %0d %0d %0d %0d %023h",case_no,{response.response_bank,response.response_region},response.response_word,response.response_id,response.response_mode,response.response_param,response.response_ntt_domain,response.response_small,response.response_error,response.response_data);reads++;
    external_request.response_ready=1;@(posedge clk);@(negedge clk);#1;external_request='0;
  endtask
  task automatic release_region(input int r);
    owner=0;external_request='0;external_request.release_valid=1;{external_request.release_bank,external_request.release_region}=6'(r);
    do @(posedge clk);while(!response.release_ready);@(negedge clk);#1;external_request='0;
  endtask
  initial begin
    int f,k,l;bit hit;string directory,token,seed,pk,sig,body;logic [63:0] mask;
    if(!$value$plusargs("STAGE2_DIR=%s",directory))directory=".";
    f=$fopen({directory,"/stage5_verify_math_inputs.txt"},"r");if(!f || $fscanf(f,"%s %d %s",token,count,seed)!=3)$fatal(1,"Prepare Verify math inputs");
    fd=$fopen({directory,"/stage5_verify_math_outputs.txt"},"w");$fdisplay(fd,"V %s",token);reset_all();
    for(int c=0;c<count;c++)begin
      if($fscanf(f,"%d %d %d %d %d %d %d %d %d %d %d %s %s %s",case_no,p,jid,base,scenario,abort_phase,adopt,ctxlen,mlen,expected_code,expected_detail,pk,sig,body)!=14 || case_no!=c)$fatal(1,"Math fixture");
      k=p==0?4:p==1?6:8;l=p==0?4:p==1?5:7;sentinel=base+2*k+l<=63?63:0;setup(pk,sig,seed);
      elapsed=0;monitor=1;raw_index=0;sample_index=0;change_source=0;inject_raw=0;
      $fdisplay(fd,"INIT %0d %0d %0d %0d %0d %016h",case_no,p,jid,base,sentinel,pregions);
      if(scenario==6)begin owner=0;external_request.read_valid=1;{external_request.read_bank,external_request.read_region}=6'(sentinel);external_request.read_word=0;
        do @(posedge clk);while(!response.read_ready);@(negedge clk);#1;external_request.read_valid=0;while(!response.response_valid)begin @(negedge clk);#1;end end
      owner=2;command_id_i=16'(jid);command_context_len_i=9'(ctxlen);command_message_len_i=16'(mlen);command_valid_i=1;
      do @(posedge clk);while(!command_ready_o);@(negedge clk);#1;command_valid_i=0;command_id_i=~16'(jid);command_context_len_i=511;command_message_len_i=65535;
      fork begin send_payload(body);end join_none
      hit=0;
      if(abort_phase)begin
        while(!hit)begin @(negedge clk);#1;
          case(abort_phase)
            1:hit=dut.state==2 && context_take_valid_o;
            2:hit=raw_index==3;
            3:hit=response.raw_output_valid && !actual.raw_output_ready;
            4:hit=dut.state==7 && sample_index==1;
            5:hit=dut.state==8 && physical.datapath.subsystem.store.write_fire && physical.datapath.subsystem.store.write_index_i==17;
            6:hit=dut.state==12 && physical.datapath.subsystem.load_word_r==10;
            7:hit=dut.state==12 && physical.datapath.subsystem.store.write_fire && physical.datapath.subsystem.store.write_index_i==17;
            8:hit=done_valid_o;
            9:if(done_valid_o)begin done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;owner=0;external_request.read_valid=1;
              {external_request.read_bank,external_request.read_region}=result_chat_o;external_request.read_word=0;
              do @(posedge clk);while(!response.read_ready);@(negedge clk);#1;external_request.read_valid=0;while(!response.response_valid)begin @(negedge clk);#1;end
              clear_valid_i=1;take_valid_i=1;repeat(5)begin @(posedge clk);if(clear_ready_o || take_ready_o)$fatal(1,"Math reset pending read");end @(negedge clk);#1;hit=1;end
            10:if(done_valid_o)begin done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;clear_valid_i=1;
              do @(posedge clk);while(!clear_ready_o);@(negedge clk);#1;clear_valid_i=0;
              while(!physical.datapath.subsystem.store.release_fire)begin @(negedge clk);#1;end @(posedge clk);@(negedge clk);#1;hit=1;end
            11:if(response.raw_output_valid)begin inject_raw=1;repeat(3)@(negedge clk);#1;hit=fault_o;end
            12:if(dut.state==12 && physical.datapath.subsystem.store.write_fire)begin force physical.datapath.subsystem.store.fault_o=1'b1;repeat(3)@(negedge clk);#1;hit=fault_o;end
          endcase
          if(done_valid_o && abort_phase<8)$fatal(1,"Missed math reset");
        end
        if(abort_phase==3)repeat(8)@(negedge clk);#1;
        $fdisplay(fd,"Z %0d %0d %0d %0d %016h %016h",case_no,abort_phase,dut.state,fault_o,response.reserved,response.complete);aborts++;reset_all();wait fork;continue;
      end
      while(!done_valid_o)begin @(negedge clk);#1;
        if(scenario==20 && dut.state==2)change_source=1;
        if(scenario==19 && dut.fd)force dut.formatter.done_id_o=16'hf00d;
      end
      repeat(7)@(negedge clk);#1;wait fork;release dut.formatter.done_id_o;
      if(done_code_o!=expected_code || done_detail_o!=expected_detail || done_id_o!=jid)$fatal(1,"Math status case%0d got%0d/%0d expected%0d/%0d",case_no,done_code_o,done_detail_o,expected_code,expected_detail);
      $fdisplay(fd,"D %0d %0d %0d %0d %016h %016h %0d",case_no,done_id_o,done_code_o,done_detail_o,response.reserved,response.complete,response.active);dones++;
      mask=result_regions_o;
      if(done_code_o==0)begin
        if(!result_valid_o || pcvalid || pbusy)$fatal(1,"Math atomic context adoption");
        $fdisplay(fd,"Y %0d %0d %0d %016h %064h %0128h %0128h",case_no,result_param_o,result_id_o,result_regions_o,result_rho_o,result_mu_o,result_ctilde_o);
        for(int j=0;j<k;j++)begin $fdisplay(fd,"K %0d 0 %0d %0d",case_no,j,result_t1hat_o[j]);$fdisplay(fd,"K %0d 2 %0d %0d",case_no,j,result_hints_o[j]);end
        for(int j=0;j<l;j++)$fdisplay(fd,"K %0d 1 %0d %0d",case_no,j,result_zhat_o[j]);$fdisplay(fd,"K %0d 3 0 %0d",case_no,result_chat_o);
      end else if(result_valid_o)$fatal(1,"Math error context");
      done_ready_i=1;@(posedge clk);@(negedge clk);#1;done_ready_i=0;
      if(expected_code==0)begin
        for(int r=0;r<64;r++)if(mask[r])for(int w=0;w<64;w++)read_word(r,w,r==int'(result_chat_o) && w==0);
        owner=2;
        if(adopt)begin take_valid_i=1;do @(posedge clk);while(!take_ready_o);$fdisplay(fd,"TAKE %0d %016h",case_no,mask);@(negedge clk);#1;take_valid_i=0;
          for(int r=0;r<64;r++)if(mask[r])release_region(r);
        end else begin clear_valid_i=1;take_valid_i=1;do @(posedge clk);while(!clear_ready_o);if(take_ready_o)$fatal(1,"Math clear priority");$fdisplay(fd,"CLEAR %0d %016h",case_no,mask);
          @(negedge clk);#1;clear_valid_i=0;take_valid_i=0;while(busy_o)begin @(negedge clk);#1;end end
      end
      if(scenario==6)begin owner=0;$fdisplay(fd,"R %0d %0d 0 %0d %0d %0d %0d %0d %0d %023h",case_no,sentinel,response.response_id,response.response_mode,response.response_param,response.response_ntt_domain,response.response_small,response.response_error,response.response_data);reads++;
        external_request.response_ready=1;@(posedge clk);@(negedge clk);#1;external_request='0;end
      if(pcvalid)begin owner=1;pclear=1;do @(posedge clk);while(!pcr);$fdisplay(fd,"PREP_CLEAR %0d %016h",case_no,pregions);
        @(negedge clk);#1;pclear=0;while(pbusy)begin @(negedge clk);#1;end end
      for(int w=0;w<64;w++)read_word(sentinel,w,0);$fdisplay(fd,"EXTERNAL_RELEASE %0d %0d",case_no,sentinel);release_region(sentinel);
      if(response.reserved || response.active || pbusy || busy_o)$fatal(1,"Math final ownership");
      $fdisplay(fd,"ENDCASE %0d 0",case_no);monitor=0;
    end
    $fdisplay(fd,"END %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d %0d",commands,adoptions,dones,aborts,inputs,allocs,writes,finishes,releases,reads,raws,outs,ops,count);
    $fclose(f);$fclose(fd);$display("STAGE5V2B_VERIFY_MATH_CAPTURE_PASS:%0d commands/%0d writes/%0d reads/%0d NTTs",commands,writes,reads,ops);test_passed=1;$finish;
  end
  initial begin #(64'd600000000000);$fatal(1,"Verify math global watchdog case%0d",case_no);end
endmodule
