`timescale 1ps/1ps
module tb_top;
  import uvm_pkg::*;import dilithium_uvm_pkg::*;
  logic clk=0;
  always begin #3378 clk=1;#3379 clk=0;end
  dilithium_if vif(clk);
  dilithium #(.FULL_KEYGEN(1),.ENABLE_SIGN(1),.ENABLE_VERIFY(1)) dut(
    .clk(clk),.rst(vif.rst),.key_valid_o(vif.key_valid_o),
    .key_ready_i(vif.key_ready_i),
    .key_data_o(vif.key_data_o),
    .key_bytes_o(vif.key_bytes_o),
    .key_type_o(vif.key_type_o),
    .key_last_o(vif.key_last_o),
    .key_index_o(vif.key_index_o),
    .key_id_o(vif.key_id_o),
    .start_valid_i(vif.start_valid_i),
    .start_ready_o(vif.start_ready_o),
    .busy_o(vif.busy_o),
    .start_op_i(vif.start_op_i),
    .start_param_i(vif.start_param_i),
    .start_id_i(vif.start_id_i),
    .start_seed_i(vif.start_seed_i),
    .start_message_len_i(vif.start_message_len_i),
    .start_context_len_i(vif.start_context_len_i),
    .start_rnd_i(vif.start_rnd_i),
    .sign_input_valid_i(vif.sign_input_valid_i),
    .sign_input_ready_o(vif.sign_input_ready_o),
    .sign_input_data_i(vif.sign_input_data_i),
    .sign_input_bytes_i(vif.sign_input_bytes_i),
    .sign_input_index_i(vif.sign_input_index_i),
    .sign_input_last_i(vif.sign_input_last_i),
    .start_signature_len_i(vif.start_signature_len_i),
    .verify_input_valid_i(vif.verify_input_valid_i),
    .verify_input_ready_o(vif.verify_input_ready_o),
    .verify_input_data_i(vif.verify_input_data_i),
    .verify_input_bytes_i(vif.verify_input_bytes_i),
    .verify_input_index_i(vif.verify_input_index_i),
    .verify_input_last_i(vif.verify_input_last_i),
    .verify_accept_o(vif.verify_accept_o),
    .signature_valid_o(vif.signature_valid_o),
    .signature_ready_i(vif.signature_ready_i),
    .signature_data_o(vif.signature_data_o),
    .signature_bytes_o(vif.signature_bytes_o),
    .signature_index_o(vif.signature_index_o),
    .signature_last_o(vif.signature_last_o),
    .signature_id_o(vif.signature_id_o),
    .done_stage_o(vif.done_stage_o),
    .done_detail_o(vif.done_detail_o),
    .sign_attempts_o(vif.sign_attempts_o),
    .sign_rejections_o(vif.sign_rejections_o),
    .sign_next_nonce_o(vif.sign_next_nonce_o),
    .row_result_valid_o(vif.row_result_valid_o),
    .row_result_ready_i(vif.row_result_ready_i),
    .row_result_index_o(vif.row_result_index_o),
    .row_result_region_o(vif.row_result_region_o),
    .row_result_id_o(vif.row_result_id_o),
    .done_valid_o(vif.done_valid_o),
    .done_ready_i(vif.done_ready_i),
    .done_code_o(vif.done_code_o),
    .done_id_o(vif.done_id_o),
    .seed_valid_o(vif.seed_valid_o),
    .rho_o(vif.rho_o),
    .key_o(vif.key_o),
    .rhoprime_o(vif.rhoprime_o),
    .read_valid_i(vif.read_valid_i),
    .read_bank_i(vif.read_bank_i),
    .read_region_i(vif.read_region_i),
    .read_word_i(vif.read_word_i),
    .read_ready_o(vif.read_ready_o),
    .response_valid_o(vif.response_valid_o),
    .response_error_o(vif.response_error_o),
    .response_bank_o(vif.response_bank_o),
    .response_mode_o(vif.response_mode_o),
    .response_param_o(vif.response_param_o),
    .response_region_o(vif.response_region_o),
    .response_word_o(vif.response_word_o),
    .response_data_o(vif.response_data_o),
    .response_id_o(vif.response_id_o),
    .response_ntt_domain_o(vif.response_ntt_domain_o),
    .response_small_o(vif.response_small_o),
    .response_ready_i(vif.response_ready_i),
    .reserved_o(vif.reserved_o),
    .complete_o(vif.complete_o),
    .fault_o(vif.fault_o)
  );
  assign vif.main_state=dut.state;
  assign vif.owners={dut.verify_owner,dut.sign_owner,dut.keygen_owner};
  assign vif.hash_active=dut.shared_response.active;
  assign vif.ntt_busy=dut.shared_response.op_busy;
  assign vif.process_busy=dut.shared_response.process_busy;
  initial begin uvm_config_db#(virtual dilithium_if)::set(null,"*","vif",vif);run_test();end
  initial begin #(64'd4000000000000);$fatal(1,"Dilithium UVM global watchdog");end
endmodule

