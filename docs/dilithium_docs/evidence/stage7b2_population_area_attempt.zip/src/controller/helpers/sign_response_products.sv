// Adopt raw-y/retry headers and transformed challenge context. Use the shared
// PWM/INTT and in-place ADD/SUB clients. No polynomial payload storage.
`default_nettype none
module sign_response_products (
  input wire logic clk,rst,command_valid_i,output logic command_ready_o,busy_o,fault_o,
  input wire logic [15:0] command_id_i,
  input wire logic key_valid_i,input wire logic [1:0] param_i,
  input wire logic [15:0] key_id_i,input wire logic [63:0] key_regions_i,
  input wire logic [22:0][5:0] key_handles_i,
  input wire logic mask_valid_i,input wire logic [15:0] mask_id_i,mask_nonce_i,
  input wire logic [63:0] mask_regions_i,input wire logic [6:0][5:0] mask_handles_i,
  input wire logic [511:0] mask_mu_i,mask_seed_i,
  input wire logic vector_valid_i,input wire logic [15:0] vector_id_i,vector_matrix_id_i,
  input wire logic [63:0] vector_regions_i,input wire logic [7:0][5:0] vector_low_i,vector_high_i,
  input wire logic [5:0] vector_chat_i,input wire logic [511:0] vector_ctilde_i,
  input wire logic [6:0] vector_bytes_i,
  output logic mask_take_valid_o,vector_take_valid_o,
  input wire logic mask_take_ready_i,vector_take_ready_i,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic [2:0] done_code_o,done_detail_o,output logic [15:0] done_id_o,
  output logic result_valid_o,output logic [63:0] result_regions_o,
  output logic [6:0][5:0] result_z_o,output logic [7:0][5:0] result_low_o,result_high_o,result_ct0_o,
  output logic [15:0] result_high_id_o,output logic [511:0] result_mu_o,result_seed_o,result_ctilde_o,
  output logic [6:0] result_bytes_o,output logic [16:0] result_next_nonce_o,
  input wire logic clear_valid_i,output logic clear_ready_o,
  input wire logic take_valid_i,output logic take_ready_o,
  output dilithium_service_pkg::request_t service_o,
  input dilithium_service_pkg::response_t service_i
);
  typedef enum logic [4:0] {IDLE,CHECK,PLAN,TAKE,PWM_START,PWM_WAIT,PWM_RETIRE,
    INV_START,INV_WAIT,INV_RETIRE,PROCESS_START,PROCESS_WAIT,PROCESS_RETIRE,
    FREE_PWM,FREE_INV,ADVANCE,DROP_CHAT,REPORT,READY,CLEAN,HALT} state_e;
  state_e state;
  logic [1:0] param_r,group_r;logic [3:0] rows_r,columns_r,ordinal_r;
  logic [15:0] id_r,key_id_r,mask_id_r,vector_id_r,matrix_id_r,nonce_r;
  logic [63:0] key_r,mask_r,vector_r,plan_r,owned_r;
  logic [22:0][5:0] keys_r;logic [6:0][5:0] z_r;
  logic [7:0][5:0] low_r,high_r,ct0_r;
  logic [5:0] chat_r,pwm_r,inv_r,scan_r,count_r;
  logic [511:0] mu_r,seed_r,ctilde_r;logic [6:0] bytes_r;
  logic [2:0] code_r,detail_r;logic adopted_r,clearing_r;
  logic [3:0] rows,columns;logic [63:0] input_key,input_mask,input_vector;logic bad,quiescent,changed;
  logic [4:0] key_index;logic [5:0] inverse_dest;
  logic [31:0][5:0] key_list,mask_list,vector_list;
  logic [31:0] key_active,mask_active,vector_active;
  assign key_index=group_r==0?5'(ordinal_r):(group_r==1?5'(columns_r)+5'(ordinal_r):5'(columns_r)+5'(rows_r)+5'(ordinal_r));
  assign inverse_dest=group_r==2?ct0_r[ordinal_r]:inv_r;
  always_comb begin
    rows=param_i==0?4'd4:(param_i==1?4'd6:4'd8);columns=param_i==0?4'd4:(param_i==1?4'd5:4'd7);
    key_list='0;mask_list='0;vector_list='0;key_active=0;mask_active=0;vector_active=0;
    for(int j=0;j<23;j++)if(j<int'(columns+2*rows))begin
      key_list[j]=key_handles_i[j];key_active[j]=1;
    end
    for(int j=0;j<7;j++)if(j<int'(columns))begin
      mask_list[j]=mask_handles_i[j];mask_active[j]=1;
    end
    for(int j=0;j<8;j++)if(j<int'(rows))begin
      vector_list[j]=vector_low_i[j];vector_active[j]=1;
      vector_list[8+j]=vector_high_i[j];vector_active[8+j]=1;
    end
    vector_list[16]=vector_chat_i;vector_active[16]=1;
    input_key=dilithium_service_pkg::handle_mask(key_list,key_active);
    input_mask=dilithium_service_pkg::handle_mask(mask_list,mask_active);
    input_vector=dilithium_service_pkg::handle_mask(vector_list,vector_active);
    bad=dilithium_service_pkg::handle_count(input_key|input_mask|input_vector)!=7'(2*columns+4*rows+1);
    bad|=input_key!=key_regions_i || input_mask!=mask_regions_i || input_vector!=vector_regions_i ||
      (input_key & input_mask)!=0 || (input_key & input_vector)!=0 || (input_mask & input_vector)!=0 ||
      ({1'b0,mask_nonce_i}+17'(columns)>17'd65536) ||
      vector_bytes_i!=(param_i==0?7'd32:(param_i==1?7'd48:7'd64)) ||
      (param_i==0 && vector_ctilde_i[511:256]!=0) || (param_i==1 && vector_ctilde_i[511:384]!=0);
  end
  assign quiescent=service_i.active==0 && !service_i.op_busy && !service_i.process_busy &&
    !service_i.sign.busy && !service_i.load.busy && !service_i.row_busy && service_i.pack.command_ready &&
    !service_i.pack.output_valid && !service_i.pack.done_valid && !service_i.response_valid && service_i.read_ready;
  assign changed=!mask_valid_i || !vector_valid_i || mask_id_i!=mask_id_r || mask_nonce_i!=nonce_r ||
    mask_regions_i!=mask_r || mask_handles_i!=z_r || mask_mu_i!=mu_r || mask_seed_i!=seed_r ||
    vector_id_i!=vector_id_r || vector_matrix_id_i!=matrix_id_r || vector_regions_i!=vector_r ||
    vector_low_i!=low_r || vector_high_i!=high_r || vector_chat_i!=chat_r || vector_ctilde_i!=ctilde_r || vector_bytes_i!=bytes_r;
  assign command_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault;
  assign busy_o=state!=IDLE;assign done_valid_o=!rst && state==REPORT && !fault_o;
  assign done_code_o=code_r;assign done_detail_o=detail_r;assign done_id_o=id_r;
  assign result_valid_o=!rst && !fault_o && ((state==REPORT && code_r==0) || state==READY);
  assign result_regions_o=result_valid_o?owned_r:64'd0;assign result_z_o=result_valid_o?z_r:'0;
  assign result_low_o=result_valid_o?low_r:'0;assign result_high_o=result_valid_o?high_r:'0;assign result_ct0_o=result_valid_o?ct0_r:'0;
  assign result_high_id_o=result_valid_o?matrix_id_r:16'd0;
  assign result_mu_o=result_valid_o?mu_r:512'd0;assign result_seed_o=result_valid_o?seed_r:512'd0;
  assign result_ctilde_o=result_valid_o?ctilde_r:512'd0;assign result_bytes_o=result_valid_o?bytes_r:7'd0;
  assign result_next_nonce_o=result_valid_o?{1'b0,nonce_r}+17'(columns_r):17'd0;
  assign clear_ready_o=!rst && state==READY && quiescent && !fault_o && !service_i.fault;
  assign take_ready_o=clear_ready_o && !clear_valid_i;
  assign mask_take_valid_o=state==TAKE && quiescent && vector_take_ready_i && !changed && !fault_o && !service_i.fault;
  assign vector_take_valid_o=state==TAKE && quiescent && mask_take_ready_i && !changed && !fault_o && !service_i.fault;
  always_comb begin
    service_o='0;
    service_o.op_valid=!fault_o && (state==PWM_START || state==INV_START);
    service_o.op=state==PWM_START?2'd2:2'd1;
    service_o.op_a_region=state==PWM_START?chat_r:pwm_r;
    service_o.op_a_id=state==PWM_START?vector_id_r:id_r;
    service_o.op_b_region=keys_r[key_index];service_o.op_b_id=key_id_r;
    service_o.op_dest_region=state==PWM_START?pwm_r:inverse_dest;service_o.op_id=id_r;
    service_o.op_done_ready=!fault_o && (state==PWM_WAIT || state==INV_WAIT);
    service_o.process_valid=state==PROCESS_START && !fault_o;service_o.process_op=group_r==0?2'd0:2'd1;
    service_o.process_inplace=1;service_o.process_a=group_r==0?z_r[ordinal_r]:low_r[ordinal_r];
    service_o.process_b=inv_r;service_o.process_dest=service_o.process_a;
    service_o.process_a_id=group_r==0?mask_id_r:matrix_id_r;service_o.process_b_id=id_r;service_o.process_id=id_r;
    service_o.process_done_ready=state==PROCESS_WAIT && !fault_o;
    service_o.release_valid=!fault_o && (state==FREE_PWM || state==FREE_INV || state==DROP_CHAT || (state==CLEAN && owned_r[scan_r]));
    {service_o.release_bank,service_o.release_region}=state==FREE_PWM?pwm_r:(state==FREE_INV?inv_r:(state==DROP_CHAT?chat_r:scan_r));
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;group_r<=0;rows_r<=0;columns_r<=0;ordinal_r<=0;
      id_r<=0;key_id_r<=0;mask_id_r<=0;vector_id_r<=0;matrix_id_r<=0;nonce_r<=0;
      key_r<=0;mask_r<=0;vector_r<=0;plan_r<=0;owned_r<=0;keys_r<=0;z_r<=0;low_r<=0;high_r<=0;ct0_r<=0;
      chat_r<=0;pwm_r<=0;inv_r<=0;scan_r<=0;count_r<=0;mu_r<=0;seed_r<=0;ctilde_r<=0;bytes_r<=0;
      code_r<=0;detail_r<=0;adopted_r<=0;clearing_r<=0;fault_o<=0;
    end else if(state!=IDLE && (service_i.fault || ((state!=REPORT || code_r==0) &&
      (!key_valid_i || param_i!=param_r || key_id_i!=key_id_r || key_regions_i!=key_r || key_handles_i!=keys_r))))begin
      fault_o<=1;state<=HALT;
    end else case(state)
      IDLE:if(command_valid_i && command_ready_o)begin
        param_r<=param_i;rows_r<=rows;columns_r<=columns;id_r<=command_id_i;key_id_r<=key_id_i;keys_r<=key_handles_i;key_r<=key_regions_i;
        mask_id_r<=mask_id_i;nonce_r<=mask_nonce_i;mask_r<=mask_regions_i;z_r<=mask_handles_i;mu_r<=mask_mu_i;seed_r<=mask_seed_i;
        vector_id_r<=vector_id_i;matrix_id_r<=vector_matrix_id_i;vector_r<=vector_regions_i;low_r<=vector_low_i;high_r<=vector_high_i;
        chat_r<=vector_chat_i;ctilde_r<=vector_ctilde_i;bytes_r<=vector_bytes_i;
        group_r<=0;ordinal_r<=0;plan_r<=0;owned_r<=0;ct0_r<=0;pwm_r<=0;inv_r<=0;scan_r<=0;count_r<=0;
        code_r<=0;detail_r<=0;adopted_r<=0;clearing_r<=0;
        if(!key_valid_i || !mask_valid_i || !vector_valid_i || param_i==3 || bad)begin code_r<=1;state<=REPORT;end else state<=CHECK;
      end
      CHECK:if(changed || (service_i.reserved & (key_r|mask_r|vector_r))!=(key_r|mask_r|vector_r) ||
        (service_i.complete & (key_r|mask_r|vector_r))!=(key_r|mask_r|vector_r))begin code_r<=1;state<=REPORT;end
        else if(quiescent)state<=PLAN;
      PLAN:if(changed)begin code_r<=1;state<=REPORT;end else begin
        if(!service_i.reserved[scan_r] && count_r<6'(rows_r)+2)begin
          plan_r[scan_r]<=1;count_r<=count_r+1'b1;
          if(count_r<6'(rows_r))ct0_r[count_r]<=scan_r;
          else if(count_r==6'(rows_r))pwm_r<=scan_r;else inv_r<=scan_r;
        end
        if(scan_r==63)begin
          if(count_r==6'(rows_r)+2 || (count_r==6'(rows_r)+1 && !service_i.reserved[scan_r]))state<=TAKE;
          else begin code_r<=2;state<=REPORT;end
        end else scan_r<=scan_r+1'b1;
      end
      TAKE:if(changed)begin code_r<=1;state<=REPORT;end
        else if(mask_take_valid_o && mask_take_ready_i && vector_take_valid_o && vector_take_ready_i)begin
          owned_r<=mask_r|vector_r;adopted_r<=1;state<=PWM_START;
        end
      PWM_START:if(service_i.op_ready)state<=PWM_WAIT;
      PWM_WAIT:if(service_i.op_done_valid)begin
        if(service_i.op_done_code!=0)begin code_r<=3;detail_r<=service_i.op_done_code;end
        else if(service_i.op_done_id!=id_r || service_i.op_done_region!=pwm_r)code_r<=5;
        state<=PWM_RETIRE;
      end
      PWM_RETIRE:if(!service_i.op_busy)begin
        owned_r<=owned_r|(service_i.reserved & plan_r);
        if((service_i.reserved & owned_r)!=owned_r || (service_i.complete & (owned_r|(service_i.reserved & plan_r)))!=(owned_r|(service_i.reserved & plan_r)))begin fault_o<=1;state<=HALT;end
        else if(code_r!=0 || !service_i.reserved[pwm_r])begin if(code_r==0)code_r<=5;scan_r<=0;state<=CLEAN;end
        else state<=INV_START;
      end
      INV_START:if(service_i.op_ready)state<=INV_WAIT;
      INV_WAIT:if(service_i.op_done_valid)begin
        if(service_i.op_done_code!=0)begin code_r<=3;detail_r<=service_i.op_done_code;end
        else if(service_i.op_done_id!=id_r || service_i.op_done_region!=inverse_dest)code_r<=5;
        state<=INV_RETIRE;
      end
      INV_RETIRE:if(!service_i.op_busy)begin
        owned_r<=owned_r|(service_i.reserved & plan_r);
        if((service_i.reserved & owned_r)!=owned_r || (service_i.complete & (owned_r|(service_i.reserved & plan_r)))!=(owned_r|(service_i.reserved & plan_r)))begin fault_o<=1;state<=HALT;end
        else if(code_r!=0 || !service_i.reserved[inverse_dest])begin if(code_r==0)code_r<=5;scan_r<=0;state<=CLEAN;end
        else state<=group_r==2?FREE_PWM:PROCESS_START;
      end
      PROCESS_START:if(service_i.process_ready)state<=PROCESS_WAIT;
      PROCESS_WAIT:if(service_i.process_done_valid)begin
        if(service_i.process_done_code!=0)begin code_r<=4;detail_r<=service_i.process_done_code;end
        else if(service_i.process_done_id!=id_r || service_i.process_done_dest!=(group_r==0?z_r[ordinal_r]:low_r[ordinal_r]))code_r<=5;
        state<=PROCESS_RETIRE;
      end
      PROCESS_RETIRE:if(!service_i.process_busy)begin
        if((service_i.reserved & owned_r)!=owned_r || (service_i.complete & owned_r)!=owned_r)begin fault_o<=1;state<=HALT;end
        else if(code_r!=0)begin scan_r<=0;state<=CLEAN;end else state<=FREE_PWM;
      end
      FREE_PWM:if(service_i.release_ready)begin owned_r[pwm_r]<=0;state<=group_r==2?ADVANCE:FREE_INV;end
      FREE_INV:if(service_i.release_ready)begin owned_r[inv_r]<=0;state<=ADVANCE;end
      ADVANCE:if(ordinal_r==(group_r==0?columns_r:rows_r)-1'b1)begin
        ordinal_r<=0;if(group_r==2)state<=DROP_CHAT;else begin group_r<=group_r+1'b1;state<=PWM_START;end
      end else begin ordinal_r<=ordinal_r+1'b1;state<=PWM_START;end
      DROP_CHAT:if(service_i.release_ready)begin owned_r[chat_r]<=0;state<=REPORT;end
      REPORT:if(done_ready_i)state<=code_r==0?READY:IDLE;
      READY:if(clear_valid_i && clear_ready_o)begin clearing_r<=1;scan_r<=0;state<=CLEAN;end
        else if(take_valid_i && take_ready_o)begin owned_r<=0;adopted_r<=0;mu_r<=0;seed_r<=0;ctilde_r<=0;state<=IDLE;end
      CLEAN:if(!owned_r[scan_r] || service_i.release_ready)begin
        owned_r[scan_r]<=0;
        if(scan_r==63)begin mu_r<=0;seed_r<=0;ctilde_r<=0;adopted_r<=0;state<=clearing_r?IDLE:REPORT;end else scan_r<=scan_r+1'b1;
      end
      HALT:state<=HALT;
      default:begin fault_o<=1;state<=HALT;end
    endcase
  end
endmodule
`default_nettype wire
