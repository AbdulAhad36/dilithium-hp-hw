// Whole-attempt CNB/MakeHint control; all coefficients stay in shared banks.
// code=0,reject=1 is normal signing rejection, never a hardware error.
// A rejected result keeps only mu/private seed/next nonce for the retry owner.
`default_nettype none
module sign_attempt_check (
  input wire logic clk,rst,command_valid_i,output logic command_ready_o,busy_o,fault_o,
  input wire logic [15:0] command_id_i,
  input wire logic key_valid_i,input wire logic [1:0] param_i,
  input wire logic [15:0] key_id_i,input wire logic [63:0] key_regions_i,
  input wire logic [22:0][5:0] key_handles_i,
  input wire logic vector_valid_i,input wire logic [15:0] vector_id_i,vector_high_id_i,
  input wire logic [63:0] vector_regions_i,input wire logic [6:0][5:0] vector_z_i,
  input wire logic [7:0][5:0] vector_low_i,vector_high_i,vector_ct0_i,
  input wire logic [511:0] vector_mu_i,vector_seed_i,vector_ctilde_i,
  input wire logic [6:0] vector_bytes_i,input wire logic [16:0] vector_next_nonce_i,
  output logic vector_take_valid_o,input wire logic vector_take_ready_i,
  output logic done_valid_o,input wire logic done_ready_i,
  output logic [2:0] done_code_o,done_detail_o,done_reason_o,
  output logic done_reject_o,output logic [11:0] done_weight_o,output logic [15:0] done_id_o,
  output logic result_valid_o,result_reject_o,output logic [63:0] result_regions_o,
  output logic [6:0][5:0] result_z_o,output logic [7:0][5:0] result_hint_o,
  output logic [15:0] result_z_id_o,
  output logic [511:0] result_mu_o,result_seed_o,result_ctilde_o,
  output logic [6:0] result_bytes_o,output logic [16:0] result_next_nonce_o,
  input wire logic clear_valid_i,output logic clear_ready_o,
  input wire logic take_valid_i,output logic take_ready_o,
  output dilithium_service_pkg::request_t service_o,
  input dilithium_service_pkg::response_t service_i
);
  typedef enum logic [4:0] {IDLE,CHECK,PLAN,TAKE,NORM_START,NORM_WAIT,NORM_RETIRE,
    ADD_START,ADD_WAIT,ADD_RETIRE,HINT_START,HINT_WAIT,HINT_RETIRE,
    FREE_LOW,FREE_HIGH,FREE_CT0,ADVANCE,REPORT,READY,CLEAN,HALT} state_e;
  state_e state;
  logic [1:0] param_r,group_r;logic [3:0] rows_r,columns_r,ordinal_r;
  logic [15:0] id_r,key_id_r,vector_id_r,high_id_r;
  logic [63:0] key_r,vector_r,owned_r;logic [22:0][5:0] keys_r;
  logic [6:0][5:0] z_r;logic [7:0][5:0] low_r,high_r,ct0_r,hint_r;
  logic [5:0] spare_r,scan_r;logic [511:0] mu_r,seed_r,ctilde_r;
  logic [6:0] bytes_r;logic [16:0] nonce_r;logic [11:0] weight_r;
  logic [2:0] code_r,detail_r,reason_r;logic reject_r,clearing_r;
  logic [3:0] rows,columns;logic [63:0] input_key,input_vector;logic bad,changed,quiescent;
  logic [11:0] omega,weight_sum;logic [5:0] norm_source;
  logic [31:0][5:0] key_list,vector_list;
  logic [31:0] key_active,vector_active;
  assign omega=param_r==0?12'd80:(param_r==1?12'd55:12'd75);
  assign weight_sum=weight_r+{3'd0,service_i.sign.done_weight};
  assign norm_source=group_r==0?z_r[ordinal_r]:(group_r==1?low_r[ordinal_r]:ct0_r[ordinal_r]);
  always_comb begin
    rows=param_i==0?4'd4:(param_i==1?4'd6:4'd8);columns=param_i==0?4'd4:(param_i==1?4'd5:4'd7);
    key_list='0;vector_list='0;key_active=0;vector_active=0;
    for(int j=0;j<23;j++)if(j<int'(columns+2*rows))begin
      key_list[j]=key_handles_i[j];key_active[j]=1;
    end
    for(int j=0;j<7;j++)if(j<int'(columns))begin
      vector_list[j]=vector_z_i[j];vector_active[j]=1;
    end
    for(int j=0;j<8;j++)if(j<int'(rows))begin
      vector_list[7+j]=vector_low_i[j];vector_active[7+j]=1;
      vector_list[15+j]=vector_high_i[j];vector_active[15+j]=1;
      vector_list[23+j]=vector_ct0_i[j];vector_active[23+j]=1;
    end
    input_key=dilithium_service_pkg::handle_mask(key_list,key_active);
    input_vector=dilithium_service_pkg::handle_mask(vector_list,vector_active);
    bad=dilithium_service_pkg::handle_count(input_key|input_vector)!=7'(2*columns+5*rows);
    bad|=input_key!=key_regions_i || input_vector!=vector_regions_i || (input_key & input_vector)!=0 ||
      vector_next_nonce_i>17'd65536 || vector_next_nonce_i<17'(columns) ||
      vector_bytes_i!=(param_i==0?7'd32:(param_i==1?7'd48:7'd64)) ||
      (param_i==0 && vector_ctilde_i[511:256]!=0) || (param_i==1 && vector_ctilde_i[511:384]!=0);
  end
  assign changed=!vector_valid_i || vector_id_i!=vector_id_r || vector_high_id_i!=high_id_r ||
    vector_regions_i!=vector_r || vector_z_i!=z_r || vector_low_i!=low_r || vector_high_i!=high_r || vector_ct0_i!=ct0_r ||
    vector_mu_i!=mu_r || vector_seed_i!=seed_r || vector_ctilde_i!=ctilde_r || vector_bytes_i!=bytes_r || vector_next_nonce_i!=nonce_r;
  assign quiescent=service_i.active==0 && !service_i.op_busy && !service_i.process_busy && !service_i.sign.busy &&
    !service_i.load.busy && !service_i.row_busy && service_i.pack.command_ready && !service_i.pack.output_valid &&
    !service_i.pack.done_valid && !service_i.response_valid && service_i.read_ready;
  assign command_ready_o=!rst && state==IDLE && !fault_o && !service_i.fault;
  assign busy_o=state!=IDLE;assign done_valid_o=!rst && state==REPORT && !fault_o;
  assign done_code_o=code_r;assign done_detail_o=detail_r;assign done_id_o=id_r;
  assign done_reject_o=code_r==0 && reject_r;assign done_reason_o=reason_r;assign done_weight_o=weight_r;
  assign result_valid_o=!rst && !fault_o && ((state==REPORT && code_r==0) || state==READY);
  assign result_reject_o=result_valid_o && reject_r;
  assign result_regions_o=result_valid_o && !reject_r?owned_r:64'd0;
  assign result_z_o=result_valid_o && !reject_r?z_r:'0;assign result_hint_o=result_valid_o && !reject_r?hint_r:'0;
  assign result_z_id_o=result_valid_o && !reject_r?vector_id_r:16'd0;
  assign result_mu_o=result_valid_o?mu_r:512'd0;assign result_seed_o=result_valid_o?seed_r:512'd0;
  assign result_ctilde_o=result_valid_o && !reject_r?ctilde_r:512'd0;
  assign result_bytes_o=result_valid_o && !reject_r?bytes_r:7'd0;assign result_next_nonce_o=result_valid_o?nonce_r:17'd0;
  assign clear_ready_o=!rst && state==READY && quiescent && !fault_o && !service_i.fault;
  assign take_ready_o=clear_ready_o && !clear_valid_i;
  assign vector_take_valid_o=state==TAKE && quiescent && !changed && !fault_o && !service_i.fault;
  always_comb begin
    service_o='0;
    service_o.sign.valid=!fault_o && (state==NORM_START || state==HINT_START);
    service_o.sign.op=state==NORM_START?2'd1:2'd2;service_o.sign.param=param_r;service_o.sign.kind=group_r;
    service_o.sign.a=state==NORM_START?norm_source:low_r[ordinal_r];service_o.sign.b=high_r[ordinal_r];
    service_o.sign.dest=spare_r;service_o.sign.high=0;
    service_o.sign.a_id=state==NORM_START?vector_id_r:id_r;service_o.sign.b_id=high_id_r;service_o.sign.id=id_r;
    service_o.sign.done_ready=!fault_o && (state==NORM_WAIT || state==HINT_WAIT);
    service_o.process_valid=!fault_o && state==ADD_START;service_o.process_op=0;service_o.process_inplace=1;
    service_o.process_a=low_r[ordinal_r];service_o.process_b=ct0_r[ordinal_r];service_o.process_dest=low_r[ordinal_r];
    service_o.process_a_id=vector_id_r;service_o.process_b_id=vector_id_r;service_o.process_id=id_r;
    service_o.process_done_ready=!fault_o && state==ADD_WAIT;
    service_o.release_valid=!fault_o && (state==FREE_LOW || state==FREE_HIGH || state==FREE_CT0 || (state==CLEAN && owned_r[scan_r]));
    {service_o.release_bank,service_o.release_region}=state==FREE_LOW?low_r[ordinal_r]:(state==FREE_HIGH?high_r[ordinal_r]:(state==FREE_CT0?ct0_r[ordinal_r]:scan_r));
  end
  always_ff @(posedge clk or posedge rst)begin
    if(rst)begin
      state<=IDLE;param_r<=0;group_r<=0;rows_r<=0;columns_r<=0;ordinal_r<=0;id_r<=0;key_id_r<=0;vector_id_r<=0;high_id_r<=0;
      key_r<=0;vector_r<=0;owned_r<=0;keys_r<=0;z_r<=0;low_r<=0;high_r<=0;ct0_r<=0;hint_r<=0;spare_r<=0;scan_r<=0;
      mu_r<=0;seed_r<=0;ctilde_r<=0;bytes_r<=0;nonce_r<=0;weight_r<=0;code_r<=0;detail_r<=0;reason_r<=0;reject_r<=0;clearing_r<=0;fault_o<=0;
    end else if(state!=IDLE && (service_i.fault || ((state!=REPORT || code_r==0) &&
      (!key_valid_i || param_i!=param_r || key_id_i!=key_id_r || key_regions_i!=key_r || key_handles_i!=keys_r))))begin
      fault_o<=1;state<=HALT;
    end else case(state)
      IDLE:if(command_valid_i && command_ready_o)begin
        param_r<=param_i;rows_r<=rows;columns_r<=columns;id_r<=command_id_i;key_id_r<=key_id_i;key_r<=key_regions_i;keys_r<=key_handles_i;
        vector_id_r<=vector_id_i;high_id_r<=vector_high_id_i;vector_r<=vector_regions_i;z_r<=vector_z_i;low_r<=vector_low_i;high_r<=vector_high_i;ct0_r<=vector_ct0_i;
        mu_r<=vector_mu_i;seed_r<=vector_seed_i;ctilde_r<=vector_ctilde_i;bytes_r<=vector_bytes_i;nonce_r<=vector_next_nonce_i;
        group_r<=0;ordinal_r<=0;owned_r<=0;hint_r<=0;scan_r<=0;weight_r<=0;reject_r<=0;reason_r<=0;code_r<=0;detail_r<=0;clearing_r<=0;
        if(!key_valid_i || !vector_valid_i || param_i==3 || bad)begin code_r<=1;state<=REPORT;end else state<=CHECK;
      end
      CHECK:if(changed || (service_i.reserved & (key_r|vector_r))!=(key_r|vector_r) ||
        (service_i.complete & (key_r|vector_r))!=(key_r|vector_r))begin code_r<=1;state<=REPORT;end else if(quiescent)state<=PLAN;
      PLAN:if(changed)begin code_r<=1;state<=REPORT;end
        else if(!service_i.reserved[scan_r])begin spare_r<=scan_r;state<=TAKE;end
        else if(scan_r==63)begin code_r<=2;state<=REPORT;end else scan_r<=scan_r+1'b1;
      TAKE:if(changed)begin code_r<=1;state<=REPORT;end
        else if(vector_take_valid_o && vector_take_ready_i)begin owned_r<=vector_r;state<=NORM_START;end
      NORM_START:if(service_i.sign.ready)state<=NORM_WAIT;
      NORM_WAIT:if(service_i.sign.done_valid)begin
        if(service_i.sign.done_code!=0)begin code_r<=3;detail_r<=service_i.sign.done_code;end
        else if(service_i.sign.done_id!=id_r || service_i.sign.done_dest!=spare_r || service_i.sign.done_high!=0 || service_i.sign.done_weight!=0)code_r<=5;
        else if(service_i.sign.done_reject)begin reject_r<=1;reason_r<=3'(group_r)+1'b1;end
        state<=NORM_RETIRE;
      end
      NORM_RETIRE:if(!service_i.sign.busy)begin
        if((service_i.reserved & owned_r)!=owned_r || (service_i.complete & owned_r)!=owned_r)begin fault_o<=1;state<=HALT;end
        else if(code_r!=0 || reject_r)begin scan_r<=0;state<=CLEAN;end
        else if(ordinal_r==(group_r==0?columns_r:rows_r)-1'b1)begin
          ordinal_r<=0;if(group_r==2)state<=ADD_START;else begin group_r<=group_r+1'b1;state<=NORM_START;end
        end else begin ordinal_r<=ordinal_r+1'b1;state<=NORM_START;end
      end
      ADD_START:if(service_i.process_ready)state<=ADD_WAIT;
      ADD_WAIT:if(service_i.process_done_valid)begin
        if(service_i.process_done_code!=0)begin code_r<=4;detail_r<=service_i.process_done_code;end
        else if(service_i.process_done_id!=id_r || service_i.process_done_dest!=low_r[ordinal_r])code_r<=5;
        state<=ADD_RETIRE;
      end
      ADD_RETIRE:if(!service_i.process_busy)begin
        if((service_i.reserved & owned_r)!=owned_r || (service_i.complete & owned_r)!=owned_r)begin fault_o<=1;state<=HALT;end
        else if(code_r!=0)begin scan_r<=0;state<=CLEAN;end else state<=HINT_START;
      end
      HINT_START:if(service_i.sign.ready)state<=HINT_WAIT;
      HINT_WAIT:if(service_i.sign.done_valid)begin
        if(service_i.sign.done_code!=0)begin code_r<=3;detail_r<=service_i.sign.done_code;end
        else if(service_i.sign.done_id!=id_r || service_i.sign.done_dest!=spare_r || service_i.sign.done_high!=0 || service_i.sign.done_reject || service_i.sign.done_weight>256)code_r<=5;
        else begin weight_r<=weight_sum;if(weight_sum>omega)begin reject_r<=1;reason_r<=4;end end
        state<=HINT_RETIRE;
      end
      HINT_RETIRE:if(!service_i.sign.busy)begin
        owned_r<=owned_r|(service_i.reserved & (64'd1<<spare_r));
        if((service_i.reserved & owned_r)!=owned_r || (service_i.complete & (owned_r|(service_i.reserved & (64'd1<<spare_r))))!=(owned_r|(service_i.reserved & (64'd1<<spare_r))))begin fault_o<=1;state<=HALT;end
        else if(code_r!=0 || reject_r || !service_i.reserved[spare_r])begin if(code_r==0 && !reject_r)code_r<=5;scan_r<=0;state<=CLEAN;end
        else begin hint_r[ordinal_r]<=spare_r;state<=FREE_LOW;end
      end
      FREE_LOW:if(service_i.release_ready)begin owned_r[low_r[ordinal_r]]<=0;state<=FREE_HIGH;end
      FREE_HIGH:if(service_i.release_ready)begin owned_r[high_r[ordinal_r]]<=0;state<=FREE_CT0;end
      FREE_CT0:if(service_i.release_ready)begin owned_r[ct0_r[ordinal_r]]<=0;state<=ADVANCE;end
      ADVANCE:if(ordinal_r==rows_r-1'b1)state<=REPORT;
        else begin spare_r<=low_r[ordinal_r];ordinal_r<=ordinal_r+1'b1;state<=ADD_START;end
      REPORT:if(done_ready_i)state<=code_r==0?READY:IDLE;
      READY:if(clear_valid_i && clear_ready_o)begin clearing_r<=1;scan_r<=0;state<=CLEAN;end
        else if(take_valid_i && take_ready_o)begin owned_r<=0;mu_r<=0;seed_r<=0;ctilde_r<=0;state<=IDLE;end
      CLEAN:if(!owned_r[scan_r] || service_i.release_ready)begin
        owned_r[scan_r]<=0;
        if(scan_r==63)begin
          if(code_r!=0 || clearing_r)begin mu_r<=0;seed_r<=0;ctilde_r<=0;end
          state<=clearing_r?IDLE:REPORT;
        end else scan_r<=scan_r+1'b1;
      end
      HALT:state<=HALT;
      default:begin fault_o<=1;state<=HALT;end
    endcase
  end
endmodule
`default_nettype wire
