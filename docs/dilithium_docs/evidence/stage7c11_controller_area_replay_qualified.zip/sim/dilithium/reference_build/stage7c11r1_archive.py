from pathlib import Path
import hashlib,json,zipfile
r=Path.cwd();ev=r/'docs/dilithium_docs/evidence';h=r/'sim/dilithium';q=r/'quartus/dilithium'
target=ev/'stage7c11_controller_area_qualified.zip';side=target.with_suffix('.sha256')
assert not target.exists() and not side.exists(),'Create-only archive exists'
def read(p):
    b=p.read_bytes();return b.decode('utf-16' if b[:2] in (b'\xff\xfe',b'\xfe\xff') else 'utf-8',errors='replace')
for leaf,marker in [('native_runner.log','STAGE7C11R1_NATIVE_RUNNER_PASS'),('uvm_runner.log','STAGE7C11R1_UVM_RUNNER_PASS'),('formatter_runner.log','STAGE7C11R1_FORMATTER_BOTH_MODES_PASS'),('quartus_runner.log','STAGE7C11R1_QUARTUS_RUNNER_PASS'),('cycle_audit.log','STAGE7C11R1_CYCLE_AUDIT_PASS')]:
    assert marker in read(h/('stage7c11r1_'+leaf)),leaf
for name,digest in json.loads((h/'reference_build/stage7c11r1_source_hashes.json').read_text()).items():
    assert hashlib.sha256((r/name).read_bytes()).hexdigest()==digest,name
prior=sorted(ev.glob('*.sha256'))
for p in prior:
    words=p.read_text().split();assert hashlib.sha256((ev/words[1]).read_bytes()).hexdigest()==words[0],p
paths=set()
for folder in ('src','tb/tb_dilithium','tb_uvm/tb_uvm_dilithium','dilithium-sw-model/ref'):
    paths|={p.relative_to(r).as_posix() for p in (r/folder).rglob('*') if p.is_file() and p.suffix in ('.sv','.svh','.c','.h')}
for folder in ('NIST/ML-DSA-keyGen-FIPS204','NIST/ML-DSA-sigGen-FIPS204','NIST/ML-DSA-sigVer-FIPS204'):
    paths|={p.relative_to(r).as_posix() for p in (r/folder).glob('*.json')}
for folder in ('FIPS204_NTT','FIPS204_SAMPLER'):
    paths|={p.relative_to(r).as_posix() for p in (r/folder).glob('*.py')}
paths|={p.relative_to(r).as_posix() for p in (r/'docs/dilithium_docs').glob('*.md')}
paths|={'AGENTS.md','README.md','sim/dilithium/.gitignore'}
for leaf in ('README.md','dilithium_vectors.py','run.do','run_uvm.do','report_uvm_coverage.tcl'):
    paths.add('sim/dilithium/'+leaf)
for p in h.glob('*'):
    if not p.is_file():continue
    if (p.name.startswith(('stage7c11r1','stage7_uvm')) and p.suffix in ('.txt','.csv','.rpt','.log','.ucdb')) or (p.name.startswith(('stage2_','stage3_','stage4_','stage5_')) and p.suffix=='.txt' and ('inputs' in p.name or 'expected' in p.name or 'samples' in p.name)):
        if 'console' not in p.name:paths.add(p.relative_to(r).as_posix())
for leaf in ('stage5_sign_hash_outputs.txt','stage5_sign_hash_c_reference.log','stage7c4_main_inputs.txt','stage7c4_main_outputs.txt','stage7c4_main_diagnostic_inputs.txt','stage7c4_main_diagnostic_outputs.txt','stage7c4_main_protocol_inputs.txt','stage7c4_main_protocol_outputs.txt','stage7c_ntt_inputs.txt','stage7c_ntt_expected.txt','stage7c1_ntt_dma_outputs.txt','stage7c4_hint_inputs.txt','stage7c4_hint_expected.txt','stage7c4_hint_outputs.txt'):
    paths.add('sim/dilithium/'+leaf)
for p in (h/'reference_build').glob('stage7c11r1*'):
    if p.is_file():paths.add(p.relative_to(r).as_posix())
for leaf in ('stage7c11_area_inventory.json',):paths.add('sim/dilithium/reference_build/'+leaf)
for p in (h/'reference_build/stage7c11_baseline_c10').glob('*'):paths.add(p.relative_to(r).as_posix())
for leaf in ('dilithium_full.qpf','dilithium_full.qsf','dilithium.sdc','report_full.tcl','README.md','stage7c11r1_compile.log','stage7c11r1_report_full.log'):
    paths.add('quartus/dilithium/'+leaf)
for p in (q/'critical_full').rglob('*'):
    if p.is_file():paths.add(p.relative_to(r).as_posix())
for p in (q/'output_full').glob('*'):
    if p.suffix in ('.rpt','.summary'):paths.add(p.relative_to(r).as_posix())
for leaf in ('stage7c11_initial_elaboration_failure.zip','stage7c11_initial_elaboration_failure.sha256'):
    paths.add('docs/dilithium_docs/evidence/'+leaf)
metrics=json.loads((h/'reference_build/stage7c11r1_metrics.json').read_text())
throughput=json.loads((h/'reference_build/stage7c11r1_throughput.json').read_text())
results=dict(stage='7C.11 R1',source_qualified=True,routed=True,performance_accepted=False,
    strict_placed_ALM_target=20000,target_met=metrics['area']['placed_ALMs']<20000,
    remaining_ALMs_to_19999=metrics['area']['placed_ALMs']-19999,clock_constraint_ns=6.757,timing_closed=False,
    main_token='5489e895aebef98b85c4063585ea37913a427ecbc4616105bf2afeb3d73df879',uvm_token='0459fca4ea835c9c95a1652d3c1736f43ec1a1a00e425856534b0b57268212aa',
    full_official_commands=210,official_output_bytes=744280,protocol_commands=88,protocol_checked_bytes=148704,checker_corruptions_rejected=90,
    main_uvm_checked=30,main_uvm_reset_aborts=3,functional_bins=[116,170],code_bins=[115562,160047],cycles='EXACT C10:all full/protocol/UVM timing records',
    formatter_commands_per_mode=167,metrics=metrics,throughput=throughput,prior_archives_verified=len(prior),next_architecture='shared context RAM and one formatter;user decision pending')
files={n:(r/n).read_bytes() for n in sorted(paths)}
files['RESULTS.json']=(json.dumps(results,indent=2)+'\n').encode()
manifest={n:hashlib.sha256(b).hexdigest() for n,b in files.items()}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in manifest.items())
digest=hashlib.sha256(target.read_bytes()).hexdigest()
with side.open('x') as f:f.write(digest+'  '+target.name+'\n')
print(f'C11R1_ARCHIVE_CREATE_VERIFY_PASS:{len(files)}members/{target.stat().st_size}bytes/{len(prior)}prior pairs;SHA256 '+digest)
