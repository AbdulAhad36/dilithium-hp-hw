onerror {quit -code 1 -f}
vmap dilithium_work sim/dilithium/work
vsim -gSTABLE_PREFIX_INPUTS=1 dilithium_work.tb_sign_hash_message +STAGE2_DIR=D:/GitHub/dilithium-hp-hw/sim/dilithium
onfinish stop
run -all
# Completion is checked from the bench's explicit capture marker by the
# runner. Optimized batch mode may remove the test_passed variable.
quit -f
