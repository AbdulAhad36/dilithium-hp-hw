set DILITHIUM_STAGE 5
set DILITHIUM_TEST sign_hash
do sim/dilithium/run.do
quit -f
