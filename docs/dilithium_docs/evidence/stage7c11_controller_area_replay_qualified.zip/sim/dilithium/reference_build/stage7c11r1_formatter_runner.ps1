$ErrorActionPreference='Stop'
Set-Location -LiteralPath 'D:\GitHub\dilithium-hp-hw'
& 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py prepare --stage 5 --unit sign_hash *> sim/dilithium/stage7c11r1_legacy_prepare.log
if ($LASTEXITCODE -ne 0) {throw 'Legacy reference preparation failed'}
foreach ($mode in @('default','stable')) {
  & 'C:/questasim64_2024.1/win64/vsim.exe' -c -l "sim/dilithium/stage7c11r1_formatter_${mode}.log" -do "sim/dilithium/reference_build/stage7c11r1_formatter_${mode}.do" *> "sim/dilithium/stage7c11r1_formatter_${mode}_console.log"
  if ($LASTEXITCODE -ne 0) {throw "Formatter native failed: $mode"}
  if (-not (Select-String -LiteralPath "sim/dilithium/stage7c11r1_formatter_${mode}.log" -Pattern 'STAGE5N4B_SIGN_HASH_CAPTURE_PASS' -Quiet)) {throw "Formatter missing completion: $mode"}
  Copy-Item -LiteralPath sim/dilithium/stage5_sign_hash_outputs.txt -Destination "sim/dilithium/reference_build/stage7c11r1_formatter_${mode}_outputs.txt"
  & 'C:/Python314/python.exe' sim/dilithium/dilithium_vectors.py compare --stage 5 --unit sign_hash *> "sim/dilithium/stage7c11r1_formatter_${mode}_compare.log"
  if ($LASTEXITCODE -ne 0) {throw "Formatter independent compare failed: $mode"}
}
'STAGE7C11R1_FORMATTER_BOTH_MODES_PASS'
