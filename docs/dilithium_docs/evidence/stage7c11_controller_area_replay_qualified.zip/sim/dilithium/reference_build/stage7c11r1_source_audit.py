from pathlib import Path
import hashlib,json,zipfile
r=Path.cwd();h=r/'sim/dilithium'
expected={'src/controller/datapath/lighthd_process_dma.sv','src/controller/lighthd_keygen.sv','src/controller/lighthd_sign.sv','src/controller/lighthd_verify.sv','src/controller/process/lighthd_bitpkg.sv','src/controller/process/sign_hash_message.sv'}
changed=[];same=[]
with zipfile.ZipFile(r/'docs/dilithium_docs/evidence/stage7c10_ntt_completion_qualified.zip') as z:
    for n in z.namelist():
        if n.startswith('src/') and n.endswith('.sv'):
            (same if z.read(n)==(r/n).read_bytes() else changed).append(n)
    for n in ('quartus/dilithium/dilithium_full.qsf','quartus/dilithium/dilithium.sdc'):
        assert z.read(n)==(r/n).read_bytes(),n
assert set(changed)==expected and len(same)==92,(changed,len(same))
with zipfile.ZipFile(r/'docs/dilithium_docs/evidence/stage7c11_initial_elaboration_failure.zip') as z:
    initial_changes=[n for n in z.namelist() if n.startswith('src/') and n.endswith('.sv') and z.read(n)!=(r/n).read_bytes()]
assert initial_changes==['src/controller/lighthd_keygen.sv'],initial_changes
paths=sorted((r/'src').rglob('*.sv'))+sorted((r/'tb/tb_dilithium').glob('*'))+sorted((r/'tb_uvm/tb_uvm_dilithium').glob('*.sv'))
paths += [h/'dilithium_vectors.py',h/'run.do',h/'run_uvm.do',h/'report_uvm_coverage.tcl',r/'quartus/dilithium/dilithium_full.qsf',r/'quartus/dilithium/dilithium.sdc']
paths += sorted((r/'dilithium-sw-model/ref').glob('*.c'))+sorted((r/'dilithium-sw-model/ref').glob('*.h'))
fingerprint={p.relative_to(r).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths if p.is_file()}
(h/'reference_build/stage7c11r1_source_hashes.json').write_text(json.dumps(fingerprint,indent=2)+'\n')
print('C11R1_SOURCE_AUDIT_PASS:6 changed RTL/92 exact C10;QSF/SDC exact;only KeyGen RTL differs from initial;'+str(len(fingerprint))+' current source fingerprints')
