onerror {quit -code 1 -f}
vlib sim/dilithium/work_lighthd_foundation
vmap lighthd_foundation_work sim/dilithium/work_lighthd_foundation
set fd [open quartus/dilithium/dilithium_full.qsf r]
set settings [read $fd];close $fd
foreach line [split $settings "\n"] {
  if {[regexp {SYSTEMVERILOG_FILE\s+(.+)$} [string trim $line] -> source]} {
    vlog -sv -work lighthd_foundation_work [file normalize [file join quartus/dilithium $source]]
  }
}
vlog -sv -work lighthd_foundation_work tb/tb_dilithium/tb_lighthd_area_arithmetic.sv tb/tb_dilithium/tb_lighthd_bitpkg.sv tb/tb_dilithium/tb_lighthd_process_dma.sv tb/tb_dilithium/lighthd_bank_fixture.sv tb/tb_dilithium/tb_lighthd_bram.sv tb/tb_dilithium/tb_lighthd_memory.sv tb/tb_dilithium/tb_lighthd_ntt_dma.sv tb/tb_dilithium/tb_lighthd_hintunpkg.sv
foreach top {tb_lighthd_area_arithmetic tb_lighthd_bitpkg tb_lighthd_process_dma} {
  vsim lighthd_foundation_work.$top
  onfinish stop
  run -all
  quit -sim
}
quit -f
