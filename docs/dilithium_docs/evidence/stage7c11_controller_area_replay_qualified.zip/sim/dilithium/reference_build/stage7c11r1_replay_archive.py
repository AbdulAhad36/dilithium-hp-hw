from pathlib import Path
import hashlib,json,zipfile
r=Path.cwd();ev=r/'docs/dilithium_docs/evidence'
old=ev/'stage7c11_controller_area_qualified.zip';target=ev/'stage7c11_controller_area_replay_qualified.zip';side=target.with_suffix('.sha256')
assert not target.exists() and not side.exists(),'Create-only replay archive exists'
prior=sorted(ev.glob('*.sha256'))
for p in prior:
    words=p.read_text().split();assert hashlib.sha256((ev/words[1]).read_bytes()).hexdigest()==words[0],p
with zipfile.ZipFile(old) as z:
    manifest=json.loads(z.read('MANIFEST.json'));assert all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in manifest.items())
    files={n:z.read(n) for n in manifest};result=json.loads(files.pop('RESULTS.json'))
for leaf in ('stage5_nist_sign_audit.csv','stage5_nist_verify_audit.csv'):
    name='sim/dilithium/'+leaf;files[name]=(r/name).read_bytes()
for p in (r/'docs/dilithium_docs').glob('*.md'):files[p.relative_to(r).as_posix()]=p.read_bytes()
files['AGENTS.md']=(r/'AGENTS.md').read_bytes()
for leaf in ('stage7c11r1_archive_check.py','stage7c11r1_replay_archive.py'):
    n='sim/dilithium/reference_build/'+leaf;files[n]=(r/n).read_bytes()
for name,digest in json.loads(files['sim/dilithium/reference_build/stage7c11r1_source_hashes.json']).items():assert hashlib.sha256(files[name]).hexdigest()==digest,name
result.update(prior_archives_verified=len(prior),packaging_revision=2,
    previous_archive=old.name,previous_archive_sha256=hashlib.sha256(old.read_bytes()).hexdigest(),
    packaging_change='Two NIST corpus audit CSV dependencies and replay script added;source/fixtures/captures/PPA unchanged. Legacy replay rebuilds archived C reference tools with GCC,without prepare or fixture regeneration.')
files['RESULTS.json']=(json.dumps(result,indent=2)+'\n').encode()
manifest={n:hashlib.sha256(b).hexdigest() for n,b in files.items()}
files['MANIFEST.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as z:
    for n,b in sorted(files.items()):z.writestr(n,b)
with zipfile.ZipFile(target) as z:assert z.testzip() is None and all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in manifest.items())
digest=hashlib.sha256(target.read_bytes()).hexdigest()
with side.open('x') as f:f.write(digest+'  '+target.name+'\n')
print(f'C11R1_REPLAY_ARCHIVE_CREATE_PASS:{len(files)}members/{target.stat().st_size}bytes/{len(prior)}prior pairs;SHA256 '+digest)
