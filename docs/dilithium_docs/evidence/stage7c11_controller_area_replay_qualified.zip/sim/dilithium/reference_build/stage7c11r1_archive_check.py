from pathlib import Path
import hashlib,json,os,runpy,subprocess,sys,zipfile
r=Path.cwd();archive=r/'docs/dilithium_docs/evidence/stage7c11_controller_area_replay_qualified.zip'
out=r/'tmp/stage7c11r1_archive_check_final';out.mkdir()
with zipfile.ZipFile(archive) as z:
    manifest=json.loads(z.read('MANIFEST.json'))
    assert z.testzip() is None and all(hashlib.sha256(z.read(n)).hexdigest()==v for n,v in manifest.items())
    for n in z.namelist():assert (out/n).resolve().is_relative_to(out.resolve()),n
    z.extractall(out)
os.chdir(out)
fingerprint=json.loads(Path('sim/dilithium/reference_build/stage7c11r1_source_hashes.json').read_text())
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==v for n,v in fingerprint.items())
print('ARCHIVE_MANIFEST_SOURCE_HASHES_PASS',len(manifest),len(fingerprint),flush=True)
fixture_hashes={n:d for n,d in manifest.items() if n.startswith('sim/dilithium/') and n.endswith(('.txt','.csv'))}
def run(args):
    result=subprocess.run([sys.executable,*args],capture_output=True,text=True)
    print(result.stdout,end='',flush=True)
    assert result.returncode==0,(args,result.stderr)
for command in ('uvm_check','lighthd_check','lighthd_dma_compare','lighthd_hint_compare','lighthd_hint_selftest','lighthd_main_diagnostic_compare','lighthd_main_compare','lighthd_main_protocol_compare','lighthd_main_selftest'):
    run(['sim/dilithium/dilithium_vectors.py',command])
# Generic legacy check() also recomputes its unrelated KeyGen/Sign/Verify
# reference expectations. Compile those archived C sources ONLY;never call
# prepare or rewrite any fixture/capture token. A C compiler is required.
reference=runpy.run_path('sim/dilithium/dilithium_vectors.py',run_name='archive_reference_build')
for build in ('build_full_keygen_c','build_full_sign_c','check_verify_c'):reference[build]()
capture=Path('sim/dilithium/stage5_sign_hash_outputs.txt');original=capture.read_bytes()
try:
    for mode in ('default','stable'):
        capture.write_bytes(Path(f'sim/dilithium/reference_build/stage7c11r1_formatter_{mode}_outputs.txt').read_bytes())
        run(['sim/dilithium/dilithium_vectors.py','compare','--stage','5','--unit','sign_hash'])
finally:capture.write_bytes(original)
assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==v for n,v in fixture_hashes.items()),'Fixture/capture mutation during replay'
for name in ('cycle_audit','metrics','admission_registers','area_delta','throughput'):
    run([f'sim/dilithium/reference_build/stage7c11r1_{name}.py'])
print('C11R1_FRESH_EXTRACTION_PASS:no prepare or fixture regeneration;archived C reference tools rebuilt;both formatters/full/protocol/checkers/cycles/source hashes/report-derived PPA/retained bits/throughput',flush=True)
