# Dilithium simulation

Stage5C shared raw-SHAKE/seed test uses the same launcher and Python script:

```tcl
# Questa Transcript,from sim/;run Python prepare from repository root first
set DILITHIUM_STAGE 5
set DILITHIUM_TEST shared_hash
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit shared_hash
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit shared_hash
```

26 commands,1699 exact SHAKE bytes and1792 exact sampled coefficients PASS.
The sampled seeds come from the real RTL collector. Includes1 parameter error,
3 resets,raw/raw and raw/sampling ownership,stalls and12 checker corruptions.
Capture:stage5_shared_outputs.txt. Main connected top remains Stage4;no complete
KeyGen or synthesis claim. Shared docs give the protocol and result arithmetic.

Current `run.do` exercises Stage4's real Keccak→sampler→memory→NTT path using a focused
non-UVM testbench under `tb/tb_dilithium/`. Main Dilithium UVM and implementation
launchers will replace/extend this evolving project at their actual stages.

Stage5A also adds an isolated process gate:in Questa use
`set DILITHIUM_STAGE 5` and `set DILITHIUM_TEST process` before this launcher;then Python compare/selftest
with `--stage 5`. It checks ADD/SUB/Power2Round:10349 accepted,10346 exact outputs,
3 reset aborts,13 expected errors. It does not run full KeyGen. Preparation
now needs GCC for the unchanged C rounding reference;it is available as
C:/MinGW/bin/gcc.exe in this workspace. Return to selector4 for the connected test.

Stage5B tests final FIPS204 seed/nonce formatting using level2/3/5 labels for
ML-DSA-44/65/87. Prepare as below,then in the Questa Transcript (from sim/):

```tcl
set DILITHIUM_STAGE 5
set DILITHIUM_TEST hash_format
do dilithium/run.do
```

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 5 --unit hash_format
python sim/dilithium/dilithium_vectors.py selftest --stage 5 --unit hash_format
```

165 commands/162 message completions/14 expected errors/3 reset aborts PASS;
883 absorption words and5888 SHAKE bytes match. Captures:stage5_hash_outputs.txt;
inputs:stage5_hash_inputs.txt. This gate uses one existing Keccak instance in
a focused harness;the formatter is not connected to the main top yet. Sampling
messages are hashed for32 bytes here,not sampled into polynomials. Full commands,
file formats and limits:docs/dilithium_docs/REFERENCE_VERIFICATION.md.

Repository-root terminal:

```powershell
python sim/dilithium/dilithium_vectors.py prepare
```

Questa GUI Transcript,working directory `sim/`:

```tcl
do dilithium/run.do
```

Repository-root terminal after capture:

```powershell
python sim/dilithium/dilithium_vectors.py compare --stage 4
python sim/dilithium/dilithium_vectors.py selftest --stage 4
```

16 sampling jobs and50 compute commands:30 completed,17 rejected,3 reset-aborted.
Require `DILITHIUM_STAGE4_CAPTURE_PASS` and independent
`DILITHIUM STAGE4 COMPARE PASS`;4096 sampled values,9745 DMA operands,7713 NTT
outputs and11776 stored readbacks match. All12 checker corruptions are rejected.
GUI waves include commands,DMA progress,NTT streams and memory lifecycle.
No complete Dilithium UVM/coverage/PPA claim.

To rerun the preserved Stage2 test in Questa:

```tcl
set DILITHIUM_STAGE 2
do dilithium/run.do
```

Then use Python compare/selftest with `--stage 2`. Set `DILITHIUM_STAGE 3`
for the preserved sampling-memory test (104 jobs/22528 readbacks),and use
`--stage 3` for its Python verdict. Set `DILITHIUM_STAGE 4` to return to the
current all-engine test. All stages use the same sampling input/expected files
and the same Python script. Stage4 adds stage4_expected.txt with26 independently
calculated arithmetic expectations. Stage-specific captures are named
stage2_outputs.txt,stage3_outputs.txt andstage4_outputs.txt. Python defaults to4.

Golden vectors bind to the source/test/launcher/reference hash;rerun prepare and
capture after changing them. Current workload cycle witnesses are in
stage2_jobs.csv. Universal docs:docs/dilithium_docs/REFERENCE_VERIFICATION.md,
ARCHITECTURE.md and THROUGHPUT.md. Standalone module projects remain separate.
