"""Real SHAKE -> sampling -> memory -> NTT: independent file comparison.

These are locally generated subsystem vectors, not full-operation NIST vectors.
One script is extended as the Dilithium subsystem grows.
"""
import argparse
import hashlib
import importlib.util
import random
import shutil
import subprocess
from functools import lru_cache
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
REF = ROOT / 'FIPS204_SAMPLER/sampler_vectors.py'
spec = importlib.util.spec_from_file_location('sampler_reference', REF)
reference = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reference)
NTT_REF = ROOT / 'FIPS204_NTT/ntt_vectors.py'
ntt_spec = importlib.util.spec_from_file_location('ntt_reference', NTT_REF)
ntt_reference = importlib.util.module_from_spec(ntt_spec)
ntt_spec.loader.exec_module(ntt_reference)


def cases():
    result = []
    def add(mode, param, label, length=None, abort=False, job_id=None):
        i = len(result)
        length = (34 if mode == 0 else 66 if mode in (1, 2) else 32) if length is None else length
        message = hashlib.shake_256(label.encode()).digest(length)
        # Raw absorbed messages exercise the engine connection; full seed/nonce
        # formatting is a later controller/version contract.
        if param == 3:
            values, code = [], 3
        else:
            stream = (hashlib.shake_128 if mode == 0 else hashlib.shake_256)(message).digest(4096)
            values, _ = reference.sample(mode, param, stream)
            assert len(values) == 256
            code = 0
        result.append(dict(i=i, id=1000+i if job_id is None else job_id,
                           mode=mode, param=param, message=message,
                           abort=abort, code=code, values=values))
    # Twelve pairs establish both contexts in every mode/parameter combination.
    for mode in range(4):
        for param in range(3):
            for slot in range(2):
                add(mode, param, f'base-{mode}-{param}-{slot}')
    # All sixteen ordered mode pairs, including independent live peer modes.
    for first in range(4):
        for second in range(4):
            param = (first+second) % 3
            add(first, param, f'mixed-{first}-{second}-a')
            add(second, param, f'mixed-{first}-{second}-b')
    # Empty/partial/multi-rate absorption; unused high input bytes are poisoned.
    lengths = [0, 1, 7, 8, 9, 33, 34, 65, 66, 135, 136, 137,
               167, 168, 169, 271, 272, 273, 335, 336, 337, 15, 16, 17]
    for i, length in enumerate(lengths):
        add(i % 4, (i//4) % 3, f'length-{i}', length)
    assert len(result) == 80
    for mode in range(4):
        for slot in range(2):
            add(mode, 3, f'invalid-{mode}-{slot}')
    for phase in range(4):
        for slot in range(2):
            add((phase+slot) % 4, phase % 3, f'abort-{phase}-{slot}', abort=True,
                job_id=2000+phase*2+slot)
        for slot in range(2):
            add((phase+slot) % 4, phase % 3, f'recover-{phase}-{slot}',
                job_id=2000+phase*2+slot)
    assert len(result) == 104
    return result


@lru_cache(maxsize=1)
def arithmetic_vectors():
    rows=cases(); result=[]
    ntt_reference.check_reference()
    for p in range(3):
        a=rows[2*p]['values'];s=rows[6+2*p]['values']
        ia=ntt_reference.direct_inverse(a);ns=ntt_reference.direct_forward(s)
        pwm=ntt_reference.pointwise(a,ns)
        product=ntt_reference.schoolbook(ia,s)
        assert ntt_reference.direct_inverse(pwm)==product
        for poly in (ia,ns,s,ns,ntt_reference.pointwise(ns,ns),pwm,product):
            result.append(poly)
    for i in (12,18):
        result += [ntt_reference.direct_forward(rows[i]['values']), rows[i]['values']]
    result.append(ntt_reference.direct_forward(rows[7]['values']))
    assert len(result)==26
    return result


@lru_cache(maxsize=1)
def process_cases():
    result=[]
    def add(op,a,b=0,abort=False,job_id=None,bad_last=False):
        i=len(result);index=i%256;last=int(index==255)^int(bad_last)
        error=int(op==3 or a>=8_380_417 or (op<2 and b>=8_380_417) or bad_last)
        residue=high=low=packed=0
        if not error:
            if op==0:residue=(a+b)%8_380_417
            elif op==1:residue=(a-b)%8_380_417
            else:
                high,low=divmod(a,8192)
                if low>4096:high+=1;low-=8192
                packed=4096-low
        result.append([i,op,a,b,9000+i//2 if job_id is None else job_id,index,last,
                       int(abort),error,residue,high,low,packed])
    for op,a,b,recover_op,recover_a,recover_b in [
        (0,0,8_380_416,0,8_380_416,8_380_416),
        (1,0,8_380_416,2,4096,8_388_607),
        (2,4097,0,2,8_380_416,0)]:
        add(op,a,b,True);add(recover_op,recover_a,recover_b)
    for high in range(1024):
        for offset in (0,1,4094,4095,4096,4097,4098,8190,8191):
            a=high*8192+offset
            if a<8_380_417:add(2,a,8_388_607) # unused B must not affect rounding
    boundaries=sorted({0,1,4096,4097,4_190_208,8_380_415,8_380_416})
    for op in (0,1):
        for a in boundaries:
            for b in boundaries:add(op,a,b)
    rng=random.Random(0x5A2026)
    for _ in range(512):
        a=rng.randrange(8_380_417);b=rng.randrange(8_380_417)
        add(0,a,b);add(1,a,b)
    for op in range(3):
        add(op,8_380_417);add(op,8_388_607)
        add(op,1,8_380_417,bad_last=(op==2));add(op,1,bad_last=True)
    add(3,0)
    assert len(result)<16000 and sum(r[7] for r in result)==3
    return result


def check_process_c():
    gcc=shutil.which('gcc')
    if not gcc:raise ValueError('GCC is needed by prepare for the independent process reference')
    build=HERE/'reference_build';build.mkdir(exist_ok=True)
    exe=build/'process_reference.exe'
    subprocess.run([gcc,'-std=c99','-O2','-DDILITHIUM_MODE=2','-I',str(ROOT/'dilithium-sw-model/ref'),
                    str(ROOT/'tb/tb_dilithium/process_reference.c'),str(ROOT/'dilithium-sw-model/ref/rounding.c'),
                    '-o',str(exe)],check=True,capture_output=True,text=True)
    report=subprocess.run([str(exe),'--selftest'],check=True,capture_output=True,text=True).stdout
    if not report.startswith('C_PROCESS_REFERENCE_PASS:8380417 '):raise ValueError('C reference selftest marker missing')
    rows=process_cases()
    values=subprocess.run([str(exe)],input=''.join(f'{r[1]} {r[2]} {r[3]}\n' for r in rows),
                          check=True,capture_output=True,text=True).stdout.splitlines()
    if len(values)!=len(rows):raise ValueError('C process oracle count')
    for r,line in zip(rows,values,strict=True):
        observed=list(map(int,line.split()))
        if r[6]!=int(r[5]==255):observed=[1,0,0,0,0] # framing is checked by the transport
        if observed!=r[8:13]:raise ValueError('Python/C process mismatch at case'+str(r[0]))
    report+=f'PYTHON_C_PROCESS_PASS:{len(rows)} arithmetic/framing cases\n'
    (HERE/'stage5_c_reference.log').write_text(report);print(report,end='')


def artifacts():
    rows = cases()
    stimuli, golden = [], []
    for c in rows:
        stimuli.append(f"{c['i']} {c['id']} {c['mode']} {c['param']} {int(c['abort'])} {len(c['message'])} {c['message'].hex() or '-'}")
        golden.append(f"{c['i']} {c['code']} {int(c['abort'])} {len(c['values'])} " +
                      ' '.join(f'{v:06x}' for v in c['values']))
    body = '\n'.join(stimuli)+'\n'
    expected = '\n'.join(golden)+'\n'
    math_body='\n'.join(str(i)+' '+' '.join(f'{v:06x}' for v in poly)
                        for i,poly in enumerate(arithmetic_vectors()))+'\n'
    process_body='\n'.join(' '.join(map(str,r)) for r in process_cases())+'\n'
    sources = [Path(__file__).resolve(), REF, NTT_REF, ROOT/'sim/dilithium/run.do']
    sources += [ROOT/'tb/tb_dilithium/process_reference.c']
    sources += [ROOT/'dilithium-sw-model/ref'/n for n in ('rounding.c','rounding.h','params.h','config.h')]
    sources += sorted((ROOT/'src/keccak').glob('*.sv'))
    sources += sorted((ROOT/'src/sampler').glob('*.sv'))
    sources += sorted((ROOT/'src/controller').rglob('*.sv'))
    sources += sorted((ROOT/'src/ntt').glob('*.sv'))
    sources += sorted((ROOT/'tb/tb_dilithium').glob('*.sv'))
    h = hashlib.sha256((body+expected+math_body+process_body).encode())
    for p in sources:
        h.update(p.relative_to(ROOT).as_posix().encode()); h.update(p.read_bytes())
    token = h.hexdigest()
    header = f'{token} {len(rows)}\n'
    return rows, token, header+body, header+expected, f'{token} 26\n'+math_body, f'{token} {len(process_cases())}\n'+process_body


@lru_cache(maxsize=1)
def hash_format_cases():
    """Final FIPS 204 KeyGen messages; level labels remain 2/3/5.

    Locally generated component vectors, not published NIST full-operation KATs.
    """
    result=[]
    def add(op,p,seed,row=0,column=0,nonce=0,abort=0,job_id=None):
        i=len(result);k,l=[(4,4),(6,5),(8,7),(0,0)][p]
        error=int(p==3 or op==3 or (op==1 and (row>=k or column>=l)) or
                  (op==2 and nonce>=k+l))
        message=b''
        if not error:
            if op==0:message=seed[:32]+bytes([k,l])
            elif op==1:message=seed[:32]+bytes([column,row])
            else:message=seed[:64]+nonce.to_bytes(2,'little')
        mode=int(op!=1);outlen=128 if op==0 else 0
        # Bound the test service to32 output bytes for sample-message checks.
        # The RTL descriptor remains continuous (outlen0); this test does not sample.
        digest=((hashlib.shake_256 if mode else hashlib.shake_128)(message).digest(
            128 if op==0 else 32)) if not error else b''
        result.append(dict(i=i,op=op,p=p,seed=seed.ljust(64,b'\xa5'),row=row,column=column,
                           nonce=nonce,abort=abort,id=12000+i if job_id is None else job_id,
                           error=error,message=message,mode=mode,outlen=outlen,digest=digest))
    for phase in (1,2,3):
        seed=hashlib.shake_256(f'abort{phase}'.encode()).digest(32)
        add(0,phase-1,seed,abort=phase,job_id=11999+phase)
        add(0,phase-1,bytes(x^255 for x in seed),job_id=11999+phase)
    for p,(k,l) in enumerate(((4,4),(6,5),(8,7))):
        for seed in (bytes(32),bytes([255])*32,bytes(range(32))):add(0,p,seed)
        expanded=hashlib.shake_256(bytes(range(32))+bytes([k,l])).digest(128)
        for row in range(k):
            for column in range(l):add(1,p,expanded[:32],row=row,column=column)
        for nonce in range(k+l):add(2,p,expanded[32:96],nonce=nonce)
        add(1,p,expanded[:32],row=k)
        add(1,p,expanded[:32],column=l)
        add(2,p,expanded[32:96],nonce=k+l)
    for op in range(3):add(op,3,bytes(64))
    add(3,0,bytes(64));add(2,0,bytes(64),nonce=65535)
    return result


def hash_format_artifact(token):
    rows=hash_format_cases()
    body='\n'.join(f"{r['i']} {r['op']} {r['p']} {r['id']} {r['row']} {r['column']} "
                   f"{r['nonce']} {r['abort']} {r['error']} "
                   f"{int.from_bytes(r['seed'],'little'):0128x} "
                   f"{int.from_bytes(r['message'],'little'):0132x}" for r in rows)+'\n'
    return f'{token} {len(rows)}\n'+body


@lru_cache(maxsize=1)
def shared_hash_cases():
    rows=[];expanded={}
    def add(kind,p=0,mode=1,abort=0,seed=b'',message=b'',outlen=128,nonce=0,row=0,column=0,job_id=None):
        i=len(rows);error=int(kind==1 and p==3)
        if kind==1:
            message=b'' if error else seed+bytes([(4,6,8)[p],(4,5,7)[p]])
        if kind==2:
            material=expanded[p]
            message=(material[:32]+bytes([column,row])) if mode==0 else material[32:96]+nonce.to_bytes(2,'little')
            outlen=0
        digest=b'' if error or kind==2 else (hashlib.shake_256 if mode else hashlib.shake_128)(message).digest(outlen)
        values=[]
        if kind==2:
            values,_=reference.sample(mode,p,(hashlib.shake_128 if mode==0 else hashlib.shake_256)(message).digest(4096))
        rows.append(dict(i=i,kind=kind,p=p,mode=mode,abort=abort,seed=seed.ljust(32,b'\0'),message=message,
                         outlen=outlen,nonce=nonce,row=row,column=column,id=13000+i if job_id is None else job_id,
                         error=error,digest=digest,values=values))
    for phase in (1,2,3):
        add(1,abort=phase,seed=hashlib.shake_256(f'shared-abort-{phase}'.encode()).digest(32),job_id=12990+phase)
        add(1,seed=hashlib.shake_256(f'shared-recover-{phase}'.encode()).digest(32),job_id=12990+phase)
    for p,(k,l) in enumerate(((4,4),(6,5),(8,7))):
        seed=hashlib.shake_256(f'shared-main-{p}'.encode()).digest(32)
        expanded[p]=hashlib.shake_256(seed+bytes([k,l])).digest(128)
        add(1,p,seed=seed)
        add(2,p,mode=0,row=k-1,column=l-1)
        add(2,p,mode=1,nonce=k+l-1)
    add(1,3,seed=bytes(32))
    for i,(length,outlen) in enumerate(((0,1),(1,15),(7,16),(8,17),(136,137),(169,169),(273,272),(34,32))):
        add(0,mode=i%2,message=hashlib.shake_256(f'raw-{i}'.encode()).digest(length),outlen=outlen)
    add(0,message=bytes(range(17)),outlen=128)
    add(2,1,mode=0,row=5,column=4)
    return rows


def shared_hash_artifact(token):
    rows=shared_hash_cases()
    body='\n'.join(f"{r['i']} {r['kind']} {r['p']} {r['id']} {r['mode']} {r['abort']} "
                   f"{len(r['message'])} {r['outlen']} {r['nonce']} {r['row']} {r['column']} "
                   f"{int.from_bytes(r['seed'],'little'):064x} "
                   f"{int.from_bytes(r['message'],'little'):0800x}" for r in rows)+'\n'
    return f'{token} {len(rows)}\n'+body


def prepare():
    check_process_c()
    rows, token, stimuli, golden, arithmetic, process = artifacts()
    (HERE/'stage2_inputs.txt').write_text(stimuli, encoding='ascii')
    (HERE/'stage2_expected.txt').write_text(golden, encoding='ascii')
    (HERE/'stage4_expected.txt').write_text(arithmetic, encoding='ascii')
    (HERE/'stage5_process_inputs.txt').write_text(process, encoding='ascii')
    (HERE/'stage5_hash_inputs.txt').write_text(hash_format_artifact(token),encoding='ascii')
    (HERE/'stage5_shared_inputs.txt').write_text(shared_hash_artifact(token),encoding='ascii')
    print(f'PREPARE PASS:{len(rows)} sampling cases plus26 arithmetic expectations;token {token}')


def check():
    rows, token, stimuli, golden, arithmetic, process = artifacts()
    if ((HERE/'stage2_inputs.txt').read_text() != stimuli or
        (HERE/'stage2_expected.txt').read_text() != golden or
        (HERE/'stage4_expected.txt').read_text() != arithmetic or
        (HERE/'stage5_process_inputs.txt').read_text() != process or
        (HERE/'stage5_hash_inputs.txt').read_text() != hash_format_artifact(token) or
        (HERE/'stage5_shared_inputs.txt').read_text() != shared_hash_artifact(token)):
        raise ValueError('Stale source/reference/vector files: rerun prepare and capture')
    return rows, token


def verify(lines):
    rows, token = check()
    if not lines or lines[0] != 'H '+token:
        raise ValueError('Capture token differs;rerun simulation after prepare')
    opened, counts, finished = {}, {}, {}
    total_values = 0
    footer = None
    for line in lines[1:]:
        f = line.split()
        if f[0] == 'F':
            if footer is not None: raise ValueError('Duplicate footer')
            footer = list(map(int, f[1:]));continue
        i, core = map(int, f[1:3])
        if not 0 <= i < len(rows) or core not in (0, 1): raise ValueError('Unknown job/core')
        c = rows[i]
        if f[0] == 'J':
            if i in opened or int(f[3]) != c['id']: raise ValueError('Repeated/wrong descriptor')
            opened[i] = core;counts[i] = 0;continue
        if opened.get(i) != core or i in finished: raise ValueError('Unowned/retired output')
        if f[0] == 'C':
            index, value, last = int(f[3]), int(f[4],16), int(f[5])
            if index != counts[i] or index >= len(c['values']) or value != c['values'][index] or last != int(index==255):
                raise ValueError(f'Coefficient mismatch:case{i},index{index},observed{value}')
            counts[i] += 1;total_values += 1
        elif f[0] == 'S':
            if c['abort'] or int(f[3]) != c['code'] or counts[i] != len(c['values']):
                raise ValueError(f'Wrong status/count for case{i}')
            finished[i] = 'S'
        elif f[0] == 'A':
            if not c['abort'] or int(f[3]) != counts[i]: raise ValueError('Unexpected abort/count')
            finished[i] = 'A'
        else:raise ValueError('Unknown capture record')
    if len(opened) != 104 or len(finished) != 104 or footer != [104,88,8,8,total_values]:
        raise ValueError('Missing/extra jobs or incorrect footer')
    combinations = {(opened[c['i']],c['mode'],c['param']) for c in rows if not c['abort'] and c['code']==0}
    if len(combinations) != 24:raise ValueError('Missing mode/parameter/context combination')
    message = (f'DILITHIUM STAGE2 COMPARE PASS:104 jobs,88 complete,8 expected errors,8 reset aborts;'
               f'{total_values} exact coefficients (22528 complete-polynomial values plus checked aborted prefixes);'
               '24 mode/parameter/context combinations\n')
    return message


def verify_memory(lines):
    rows, token = check()
    if not lines or lines[0] != 'H '+token:
        raise ValueError('Memory capture token differs')
    opened, counts, finished, read_counts = {}, {}, {}, {}
    slots, live = {}, {}
    writes = reads = invalid = releases = resets = 0
    footer = None
    for line in lines[1:]:
        if footer is not None: raise ValueError('Record after memory footer')
        f = line.split()
        kind = f[0]
        if kind == 'F':
            footer = list(map(int, f[1:])); continue
        if kind == 'X':
            if live: raise ValueError('Reset omitted live-job abort records')
            slots.clear(); resets += 1; continue
        if kind in ('E', 'L'):
            slot = int(f[1])
            if not 0 <= slot < 4: raise ValueError('Bad memory slot')
            if kind == 'E':
                if slot in slots and slots[slot][1]: raise ValueError('Readable slot reported error')
                if not 0 <= int(f[2]) < 256: raise ValueError('Bad invalid-read index')
                invalid += 1
            else:
                if slot not in slots or not slots[slot][1]: raise ValueError('Release of incomplete slot')
                if read_counts.get(slots[slot][0], 0) != 256: raise ValueError('Released before full readback')
                del slots[slot]; releases += 1
            continue
        if kind not in ('J', 'W', 'S', 'A', 'R'): raise ValueError('Unknown memory record')
        i = int(f[1])
        if not 0 <= i < len(rows): raise ValueError('Bad memory case')
        c = rows[i]
        if kind == 'J':
            core, slot, job_id = map(int, f[2:])
            if core not in (0, 1) or core in live or not 0 <= slot < 4 or slot in slots:
                raise ValueError('Memory allocation reused live owner')
            if i in opened or job_id != c['id']: raise ValueError('Repeated/wrong memory descriptor')
            opened[i] = (core, slot); counts[i] = read_counts[i] = 0
            slots[slot] = (i, False); live[core] = i
        elif kind == 'R':
            slot, index = map(int, f[2:4])
            if slots.get(slot) != (i, True) or opened.get(i, (None,None))[1] != slot:
                raise ValueError('Read before commit, after release/reset, or from wrong slot')
            if index != read_counts.get(i) or index >= 256: raise ValueError('Read order/count mismatch')
            if (int(f[4],16) != c['values'][index] or
                list(map(int,f[5:])) != [c['id'],c['mode'],c['param'],int(c['mode']==0)]):
                raise ValueError('Memory data or metadata mismatch')
            reads += 1; read_counts[i] += 1
        else:
            core = int(f[2])
            if live.get(core) != i: raise ValueError('Write/status without live owner')
            slot = opened[i][1]
            if kind == 'W':
                index = int(f[3])
                if index != counts[i] or index >= len(c['values']): raise ValueError('Write index mismatch')
                if int(f[4],16) != c['values'][index] or int(f[5]) != int(index==255):
                    raise ValueError('Write data/last mismatch')
                counts[i] += 1; writes += 1
            else:
                if kind == 'S':
                    if c['abort'] or int(f[3]) != c['code'] or counts[i] != len(c['values']):
                        raise ValueError('Incorrect memory completion')
                    if c['code']==0: slots[slot] = (i,True)
                    else: del slots[slot]
                elif not c['abort'] or int(f[3]) != counts[i]:
                    raise ValueError('Incorrect memory abort')
                finished[i] = kind; del live[core]
    successful = [c['i'] for c in rows if not c['abort'] and c['code']==0]
    combinations = {(opened[i][0],rows[i]['mode'],rows[i]['param']) for i in successful}
    if (len(opened)!=104 or len(finished)!=104 or live or slots or
        footer != [104,88,8,8,writes,reads] or reads!=22528 or releases!=88 or
        invalid<90 or resets!=5 or len(combinations)!=24 or any(read_counts[i]!=256 for i in successful)):
        raise ValueError('Incomplete memory lifecycle/readback gate')
    return (f'DILITHIUM STAGE3 COMPARE PASS:104 jobs,88 complete,8 expected errors,8 reset aborts;'
            f'{writes} exact writes,22528 exact readbacks;88 releases,{invalid} invalid reads,5 resets\n')


@lru_cache(maxsize=128)
def arithmetic_result(operation, a, b=()):
    if operation in (0,3): return tuple(ntt_reference.direct_forward(list(a)))
    if operation==1:return tuple(ntt_reference.direct_inverse(list(a)))
    return tuple(ntt_reference.pointwise(list(a),list(b)))


def verify_ntt(lines):
    rows, token=check()
    if not lines or lines[0]!='H '+token:raise ValueError('NTT capture token differs')
    slots={};jobs={};live={};operations={};pending=None;footer=None
    samples=successes=rejections=aborts=writes=results=reads=resets=loads=releases=invalid=0
    op_kinds=set();rejection_kinds=set();sample_modes=set()
    def eligibility(o):
        a=slots.get(o['a']);b=slots.get(o['b']);op=o['op']
        if (a is None or a['state']!='complete' or a['id']!=o['aid'] or
            (op==2 and (b is None or b['state']!='complete' or b['id']!=o['bid']))):return 1
        if ((op in (0,3) and a['domain']) or (op in (1,2) and not a['domain']) or
            (op==3 and any(4<v<ntt_reference.Q-4 for v in a['values'])) or
            (op==2 and (not b['domain'] or b['param']!=a['param']))):return 2
        return 0
    for line in lines[1:]:
        if footer is not None:raise ValueError('Records after NTT footer')
        f=line.split();kind=f[0]
        if kind=='F':footer=list(map(int,f[1:]));continue
        if kind=='X':
            if live or pending is not None:raise ValueError('Reset lacks abort/retirement records')
            slots.clear();resets+=1;continue
        if kind=='J':
            j,c,core,s,jobid=map(int,f[1:])
            if (j!=samples or not 0<=c<len(rows) or rows[c]['code']!=0 or core not in (0,1) or
                core in live or not 0<=s<4 or s in slots or pending is not None):
                raise ValueError('Bad sampled allocation')
            jobs[j]=dict(case=c,core=core,slot=s,count=0,done=False);live[core]=j
            r=rows[c];slots[s]=dict(id=jobid,mode=r['mode'],param=r['param'],domain=int(r['mode']==0),
                                  values=r['values'],state='writing',reads=0)
            sample_modes.add(r['mode']);samples+=1;continue
        if kind in ('W','S'):
            j=int(f[1]);job=jobs.get(j)
            if job is None or live.get(job['core'])!=j or job['done']:raise ValueError('Sample without owner')
            s=slots[job['slot']]
            if kind=='W':
                index=int(f[2])
                if index!=job['count'] or index>=256 or int(f[3],16)!=s['values'][index] or int(f[4])!=int(index==255):
                    raise ValueError('Sample write mismatch')
                job['count']+=1;writes+=1
            else:
                if job['count']!=256 or list(map(int,f[2:]))!=[s['id'],0]:raise ValueError('Premature/wrong sample status')
                s['state']='complete';job['done']=True;del live[job['core']]
            continue
        if kind=='O':
            run,op,a,aid,b,bid,resultid=map(int,f[1:])
            if run!=len(operations) or op not in range(4) or a not in range(4) or b not in range(4) or pending is not None or live:
                raise ValueError('Overlapping/invalid compute command')
            operations[run]=dict(op=op,a=a,aid=aid,b=b,bid=bid,id=resultid,code=None,count=0,loads=0,done=False)
            pending=run;continue
        if kind in ('V','T','K','D','B'):
            run=int(f[1]);o=operations.get(run)
            if o is None or pending!=run or o['done']:raise ValueError('NTT event without live operation')
            if kind=='V':
                code,dest=map(int,f[2:])
                if o['code'] is not None or code!=eligibility(o):raise ValueError('Wrong reservation/domain decision')
                o['code']=code;o['dest']=dest
                if code==0:
                    if dest not in range(4) or dest in slots:raise ValueError('Overwritten live polynomial')
                    a=slots[o['a']];b=slots.get(o['b'])
                    o['a_values']=tuple(a['values']);o['b_values']=tuple(b['values']) if o['op']==2 else ()
                    o['expected']=arithmetic_result(o['op'],o['a_values'],o['b_values'])
                    a['state']='in_use'
                    if o['op']==2:b['state']='in_use'
                    slots[dest]=dict(id=o['id'],mode=a['mode'],param=a['param'],domain=int(o['op']!=1),
                                     values=o['expected'],state='writing',reads=0)
                elif dest!=0:raise ValueError('Rejected reservation returned destination')
            elif kind=='T':
                index,s,jobid,coefficient=map(int,f[2:6]);value=int(f[6],16)
                source=o['a'] if index<256 else o['b'];srcid=o['aid'] if index<256 else o['bid']
                expected=o.get('a_values',()) if index<256 else o.get('b_values',())
                if (o['code']!=0 or index!=o['loads'] or not expected or index>=len(o['a_values'])+len(o['b_values']) or
                    s!=source or jobid!=srcid or coefficient!=index%256 or value!=expected[index%256]):
                    raise ValueError('DMA operand/value/tag/order mismatch')
                o['loads']+=1;loads+=1
            elif kind=='K':
                index=int(f[2])
                if (o['code']!=0 or o['loads']!=(512 if o['op']==2 else 256) or index!=o['count'] or index>=256 or
                    int(f[3],16)!=o['expected'][index] or int(f[4])!=int(index==255)):
                    raise ValueError('NTT output/last mismatch')
                o['count']+=1;results+=1
            elif kind=='D':
                code,dest,resultid=map(int,f[2:])
                if code!=o['code'] or dest!=o['dest'] or resultid!=o['id']:raise ValueError('Wrong compute retirement')
                if code==0:
                    if o['count']!=256 or o['loads']!=(512 if o['op']==2 else 256):raise ValueError('Premature compute commit')
                    slots[dest]['state']='complete';slots[o['a']]['state']='complete'
                    if o['op']==2:slots[o['b']]['state']='complete'
                    successes+=1;op_kinds.add(o['op'])
                else:
                    if o['count'] or o['loads']:raise ValueError('Rejected compute changed arithmetic')
                    rejections+=1;rejection_kinds.add(code)
                o['done']=True;pending=None
            else:
                if o['code']!=0 or int(f[2])!=o['count']:raise ValueError('Bad compute abort')
                o['done']=True;pending=None;aborts+=1
            continue
        if kind in ('R','E','L'):
            s=int(f[1]);v=slots.get(s)
            if not 0<=s<4:raise ValueError('Bad read/release slot')
            if kind=='E':
                if v is not None and v['state']=='complete':raise ValueError('Readable slot rejected')
                if not 0<=int(f[2])<256:raise ValueError('Bad rejected read index')
                invalid+=1
            elif kind=='L':
                if v is None or v['state']!='complete' or v['reads']!=256:raise ValueError('Release of locked/incomplete/unread slot')
                del slots[s];releases+=1
            else:
                index=int(f[2])
                if (v is None or v['state']!='complete' or index!=v['reads'] or index>=256 or
                    int(f[3],16)!=v['values'][index] or
                    list(map(int,f[4:]))!=[v['id'],v['mode'],v['param'],v['domain']]):
                    raise ValueError('Stored NTT value/domain/metadata mismatch')
                v['reads']+=1;reads+=1
            continue
        raise ValueError('Unknown Stage4 capture record')
    if (footer!=[16,50,30,17,3,4096,results,11776] or samples!=16 or len(operations)!=50 or
        (successes,rejections,aborts,writes,reads,resets,loads,releases)!=(30,17,3,4096,11776,4,9745,43) or
        slots or live or pending is not None or any(not j['done'] for j in jobs.values()) or
        any(not o['done'] for o in operations.values()) or op_kinds!={0,1,2,3} or
        rejection_kinds!={1,2} or sample_modes!={0,1,2,3} or invalid!=6):
        raise ValueError(f'Incomplete Stage4 gate:{samples,len(operations),successes,rejections,aborts,writes,results,reads,resets,loads,releases}')
    return (f'DILITHIUM STAGE4 COMPARE PASS:16 sampled jobs,50 commands,30 arithmetic results,17 rejected,3 reset aborts;'
            f'4096 sampled coefficients,{loads} DMA operands,{results} NTT outputs,11776 exact stored readbacks\n')


def verify_process(lines):
    _,token=check();rows=process_cases()
    if not lines or lines[0]!='H '+token:raise ValueError('Process capture token differs')
    opened=set();finished=set();queue=[];footer=None;resets=complete=aborts=errors=0
    for line in lines[1:]:
        if footer is not None:raise ValueError('Record after process footer')
        f=line.split();kind=f[0]
        if kind=='F':footer=list(map(int,f[1:]));continue
        if kind=='X':
            if queue:raise ValueError('Reset omitted accepted abort')
            resets+=1;continue
        if kind not in ('J','P','A'):raise ValueError('Unknown process record')
        i=int(f[1])
        if not 0<=i<len(rows):raise ValueError('Unknown process case')
        r=rows[i]
        if kind=='J':
            if i!=len(opened) or i in opened or queue:raise ValueError('Process input sequence/elastic ownership')
            opened.add(i);queue.append(i)
        else:
            if not queue or queue.pop(0)!=i or i in finished:raise ValueError('Output/abort without matching input')
            if kind=='A':
                if not r[7]:raise ValueError('Unexpected process abort')
                aborts+=1
            else:
                if r[7] or list(map(int,f[2:]))!=r[8:13]+[r[4],r[5],r[6],r[1]]:
                    raise ValueError('Process arithmetic/rounding/framing/tag mismatch')
                complete+=1;errors+=r[8]
            finished.add(i)
    if (len(opened)!=len(rows) or len(finished)!=len(rows) or queue or resets!=4 or aborts!=3 or
        complete!=len(rows)-3 or errors!=13 or footer!=[len(rows),complete,3,13]):
        raise ValueError('Incomplete process gate')
    return (f'DILITHIUM STAGE5 PROCESS COMPARE PASS:{len(rows)} accepted,{complete} exact outputs,'
            '3 reset aborts,13 expected errors;all canonical high-part rounding boundaries exercised\n')


def verify_hash_format(lines):
    _,token=check();rows=hash_format_cases()
    if not lines or lines[0]!='H '+token:raise ValueError('Hash-format capture token')
    opened=set();finished=set();state=None;totals=[0]*6;footer=None;resets=0;cores=set()
    for line in lines[1:]:
        if footer is not None:raise ValueError('Record after hash-format footer')
        f=line.split();kind=f[0]
        if kind=='X':
            if state is not None:raise ValueError('Reset without formatter abort')
            resets+=1;continue
        if kind=='F':footer=list(map(int,f[1:]));continue
        i=int(f[1])
        if not 0<=i<len(rows):raise ValueError('Unknown formatter case')
        r=rows[i]
        if kind=='J':
            if state is not None or i!=len(opened):raise ValueError('Formatter ownership/sequence')
            opened.add(i);state=dict(i=i,d=0,w=0,v=0,s=0);totals[0]+=1;continue
        if state is None or state['i']!=i:raise ValueError('Unowned formatter event')
        if kind=='D':
            if r['error'] or state['d'] or list(map(int,f[2:]))!=[r['mode'],len(r['message']),r['outlen']]:
                raise ValueError('SHAKE descriptor mismatch')
            state['d']=1
        elif kind=='W':
            n=state['w'];word=r['message'][8*n:8*n+8].ljust(8,b'\0')
            if not state['d'] or int(f[2])!=n or n*8>=len(r['message']) or int(f[3],16)!=int.from_bytes(word,'little'):
                raise ValueError('Seed/nonce absorption message mismatch')
            state['w']+=1;totals[4]+=1
        elif kind=='V':
            n=state['v'];core=int(f[4]);offset=16*n
            if (not state['d'] or state['w']!=(len(r['message'])+7)//8 or int(f[2])!=n or
                int(f[3])!=16 or core not in (0,1) or offset>=len(r['digest']) or
                int(f[5],16)!=int.from_bytes(r['digest'][offset:offset+16],'little')):
                raise ValueError('SHAKE output mismatch')
            if n and core!=state['core']:raise ValueError('Hash core changed within job')
            state['core']=core;cores.add(core);state['v']+=1;totals[5]+=1
        elif kind=='S':
            if state['s'] or list(map(int,f[2:]))!=[r['id'],r['error']]:raise ValueError('Formatter completion mismatch')
            if state['w']!=(len(r['message'])+7)//8:raise ValueError('Completion before full message')
            state['s']=1;totals[1]+=1;totals[2]+=r['error']
        elif kind=='A':
            if not r['abort'] or int(f[2])!=r['abort'] or state['s'] or state['v']:
                raise ValueError('Unexpected formatter abort')
            if (state['d'],state['w'])!=[(0,0),(1,2),(1,5)][r['abort']-1]:raise ValueError('Wrong reset phase')
            totals[3]+=1;finished.add(i);state=None
        elif kind=='E':
            if r['abort'] or not state['s'] or state['d']!=int(not r['error']) or state['v']!=len(r['digest'])//16:
                raise ValueError('Incomplete formatter/hash result')
            finished.add(i);state=None
        else:raise ValueError('Unknown formatter record')
    if (state is not None or len(opened)!=len(rows) or len(finished)!=len(rows) or resets!=4 or
        cores!={0,1} or totals!=footer or totals[3]!=3):raise ValueError('Incomplete formatter gate')
    return (f'DILITHIUM STAGE5 HASH FORMAT COMPARE PASS:{totals[0]} accepted,'
            f'{totals[1]} completions,{totals[2]} expected errors,3 reset aborts;'
            f'{totals[4]} absorption words,{16*totals[5]} exact SHAKE bytes;'
            'all102 matrix entries and34 secret nonces across levels2/3/5\n')


def verify_shared_hash(lines):
    _,token=check();rows=shared_hash_cases()
    if not lines or lines[0]!='H '+token:raise ValueError('Shared hash capture token')
    jobs={};owners={};finished=set();resets=0;footer=None;totals=[0]*7
    for line in lines[1:]:
        if footer is not None:raise ValueError('Record after shared footer')
        f=line.split();kind=f[0]
        if kind=='X':
            if owners or any(i not in finished for i in jobs):raise ValueError('Reset omitted live owner/abort')
            resets+=1;continue
        if kind=='F':footer=list(map(int,f[1:]));continue
        i=int(f[1])
        if not 0<=i<len(rows):raise ValueError('Unknown shared case')
        r=rows[i]
        if kind=='J':
            if i in jobs:raise ValueError('Duplicate shared command')
            jobs[i]=dict(desc=False,w=0,n=0,c=0,d=False);totals[0]+=1;continue
        if i not in jobs or i in finished:raise ValueError('Unowned/retired shared event')
        s=jobs[i]
        if kind in ('R','S'):
            core=int(f[2])
            if core not in (0,1) or core in owners or s['desc'] or r['error']:
                raise ValueError('Descriptor overwrote owner')
            expected=([r['id'],r['mode'],r['p'],len(r['message'])] if kind=='S' else
                      [r['id'],r['mode'],len(r['message']),r['outlen']])
            if list(map(int,f[3:]))!=expected or (kind=='S')!=(r['kind']==2):raise ValueError('Shared descriptor mismatch')
            s['desc']=True;s['core']=core;owners[core]=i;totals[2 if kind=='S' else 1]+=1
        elif kind in ('W','P'):
            n=s['w'];word=r['message'][8*n:8*n+8].ljust(8,b'\0')
            if (not s['desc'] or (kind=='P')!=(r['kind']==2) or int(f[2])!=n or
                n*8>=len(r['message']) or int(f[3],16)!=int.from_bytes(word,'little')):
                raise ValueError('Shared absorption mismatch')
            s['w']+=1
        elif kind=='O':
            core,job_id,offset,n=map(int,f[2:6]);rate=136 if r['mode'] else 168
            expected_n=min(16,len(r['digest'])-s['n'],rate-s['n']%rate)
            expected=r['digest'][s['n']:s['n']+n]
            if (r['kind']==2 or owners.get(core)!=i or job_id!=r['id'] or offset!=s['n'] or
                n!=expected_n or n<=0 or s['w']!=(len(r['message'])+7)//8 or
                int(f[6],16)&((1<<(8*n))-1)!=int.from_bytes(expected,'little')):
                raise ValueError(f'Shared raw bytes/tag mismatch:case{i},offset{offset}')
            s['n']+=n;totals[5]+=n
        elif kind=='D':
            core,job_id=map(int,f[2:])
            if owners.get(core)!=i or job_id!=r['id'] or s['d'] or s['n']!=len(r['digest']):
                raise ValueError('Premature/wrong raw completion')
            s['d']=True;del owners[core]
            if r['kind']==0:finished.add(i)
        elif kind=='Z':
            error,job_id,p=map(int,f[2:5]);material=bytes(128) if r['error'] else r['digest']
            expected=[int.from_bytes(material[:32],'little'),int.from_bytes(material[32:96],'little'),
                      int.from_bytes(material[96:128],'little')]
            if (r['kind']!=1 or r['abort'] or [error,job_id,p]!=[r['error'],r['id'],r['p']] or
                list(int(v,16) for v in f[5:])!=expected or s['desc']!=bool(not error) or
                (not error and not s['d'])):raise ValueError('Seed material/metadata mismatch')
            totals[3]+=1;finished.add(i)
        elif kind=='C':
            core,job_id,index=map(int,f[2:5])
            if (r['kind']!=2 or owners.get(core)!=i or job_id!=r['id'] or index!=s['c'] or index>=256 or
                int(f[5],16)!=r['values'][index] or int(f[6])!=int(index==255) or
                s['w']!=(len(r['message'])+7)//8):raise ValueError('Derived-seed sampler mismatch')
            s['c']+=1;totals[6]+=1
        elif kind=='T':
            core,code=map(int,f[2:])
            if owners.get(core)!=i or r['kind']!=2 or code!=0 or s['c']!=256:raise ValueError('Sampling completion mismatch')
            del owners[core];finished.add(i)
        elif kind=='A':
            if not r['abort'] or int(f[2])!=r['abort']:raise ValueError('Unexpected shared abort')
            if (s['w'],s['n'],s['d'])!=[(2,0,False),(5,16,False),(5,128,True)][r['abort']-1]:
                raise ValueError('Shared reset phase mismatch')
            if owners.get(s.get('core'))==i:del owners[s['core']]
            totals[4]+=1;finished.add(i)
        else:raise ValueError('Unknown shared event')
    if (len(jobs)!=len(rows) or len(finished)!=len(rows) or owners or resets!=4 or totals!=footer or
        totals!=[26,18,7,7,3,1699,1792]):raise ValueError('Incomplete shared hash gate')
    return ('DILITHIUM STAGE5 SHARED HASH COMPARE PASS:26 commands,18 raw hashes,7 sampled polynomials,'
            '7 seed results(including1 expected parameter error),3 reset aborts;1699 exact SHAKE bytes,'
            '1792 exact coefficients from RTL-collected seeds;both raw and sampled ownership checked\n')


def compare(stage=2,unit='process'):
    if stage==5 and unit=='shared_hash':
        message=verify_shared_hash((HERE/'stage5_shared_outputs.txt').read_text().splitlines())
        (HERE/'stage5_shared_compare.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='hash_format':
        message=verify_hash_format((HERE/'stage5_hash_outputs.txt').read_text().splitlines())
        (HERE/'stage5_hash_compare.log').write_text(message);print(message,end='');return
    message={2:verify,3:verify_memory,4:verify_ntt,5:verify_process}[stage]((HERE/f'stage{stage}_outputs.txt').read_text().splitlines())
    (HERE/f'stage{stage}_compare.log').write_text(message);print(message,end='')


def selftest(stage=2,unit='process'):
    if stage==5 and unit=='shared_hash':
        original=(HERE/'stage5_shared_outputs.txt').read_text().splitlines();verify_shared_hash(original);trials=[]
        for kind,column,base,label in [('O',6,16,'raw_value'),('O',2,10,'raw_core'),('O',3,10,'raw_ID'),
                                     ('O',5,10,'valid_bytes'),('Z',5,16,'rho'),('Z',6,16,'rho_prime'),
                                     ('Z',7,16,'key'),('C',5,16,'coefficient'),('C',4,10,'coefficient_index'),
                                     ('Z',2,10,'seed_error')]:
            j=next(j for j,s in enumerate(original) if s.startswith(kind+' '));lines=original.copy();f=lines[j].split()
            v=int(f[column],base)^1;f[column]=format(v,'x') if base==16 else str(v);lines[j]=' '.join(f);trials.append((label,lines))
        j=next(j for j,s in enumerate(original) if s.startswith('D '))
        trials += [('missing_raw_completion',original[:j]+original[j+1:]),('stale_token',['H '+'0'*64]+original[1:])]
        for label,lines in trials:
            try:verify_shared_hash(lines)
            except (ValueError,IndexError):continue
            raise ValueError('Shared checker accepted corruption:'+label)
        message='STAGE5 SHARED HASH CHECKER PASS:12/12 corruptions rejected\n'
        (HERE/'stage5_shared_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==5 and unit=='hash_format':
        original=(HERE/'stage5_hash_outputs.txt').read_text().splitlines();verify_hash_format(original)
        trials=[]
        for kind,column,label in [('D',2,'mode'),('D',3,'message_length'),('D',4,'output_length'),
                                  ('W',2,'word_index'),('W',3,'absorbed_byte'),('V',2,'output_index'),
                                  ('V',3,'output_bytes'),('V',5,'hash_byte'),('S',2,'ID'),('S',3,'error')]:
            row=next(i for i,s in enumerate(original) if s.startswith(kind+' '))
            lines=original.copy();f=lines[row].split();base=16 if label in ('absorbed_byte','hash_byte') else 10
            f[column]=format(int(f[column],base)^1,'x') if base==16 else str(int(f[column])^1)
            lines[row]=' '.join(f);trials.append((label,lines))
        trials += [('stale_token',['H '+'0'*64]+original[1:]),('missing_footer',original[:-1])]
        for label,lines in trials:
            try:verify_hash_format(lines)
            except (ValueError,IndexError):continue
            raise ValueError('Hash formatter checker accepted corruption:'+label)
        message='STAGE5 HASH FORMAT CHECKER PASS:12/12 corruptions rejected\n'
        (HERE/'stage5_hash_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==5:
        original=(HERE/'stage5_outputs.txt').read_text().splitlines();verify_process(original)
        pi=next(i for i,s in enumerate(original) if s.startswith('P '))
        ji=next(i for i,s in enumerate(original) if s.startswith('J '));trials=[]
        for label,col in [('error',2),('residue',3),('high',4),('signed_low',5),('packed_t0',6),
                          ('ID',7),('index',8),('last',9),('operation',10)]:
            lines=original.copy();f=lines[pi].split();f[col]=str(int(f[col])^1);lines[pi]=' '.join(f)
            trials.append((label,lines))
        trials += [('missing_output',original[:pi]+original[pi+1:]),
                   ('duplicate_input',original[:ji]+[original[ji]]+original[ji:]),
                   ('stale_token',['H '+'0'*64]+original[1:])]
        for label,lines in trials:
            try:verify_process(lines)
            except (ValueError,IndexError):continue
            raise ValueError('Process checker accepted corruption:'+label)
        message='STAGE5 PROCESS CHECKER PASS:12/12 corruptions rejected\n'
        (HERE/'stage5_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==4:
        original=(HERE/'stage4_outputs.txt').read_text().splitlines();verify_ntt(original)
        ri=next(i for i,s in enumerate(original) if s.startswith('R '))
        ki=next(i for i,s in enumerate(original) if s.startswith('K '))
        ti=next(i for i,s in enumerate(original) if s.startswith('T '))
        oi=next(i for i,s in enumerate(original) if s.startswith('O '))
        vi=next(i for i,s in enumerate(original) if s.startswith('V '))
        di=next(i for i,s in enumerate(original) if s.startswith('D '))
        trials=[]
        for label,row,column in [('output',ki,3),('DMA_value',ti,6),('DMA_id',ti,4),('read_value',ri,3),
                                 ('domain',ri,7),('source_id',oi,4),('reservation',vi,2),('done_id',di,4)]:
            lines=original.copy();f=lines[row].split();base=16 if label in ('output','DMA_value','read_value') else 10
            changed=int(f[column],base)^1;f[column]=format(changed,'x') if base==16 else str(changed)
            lines[row]=' '.join(f);trials.append((label,lines))
        trials += [('missing_output',original[:ki]+original[ki+1:]),('missing_commit',original[:di]+original[di+1:]),
                   ('stale_token',['H '+'0'*64]+original[1:]),('extra_read',original+[original[ri]])]
        for label,lines in trials:
            try:verify_ntt(lines)
            except (ValueError,IndexError,KeyError):continue
            raise ValueError('NTT checker accepted corruption:'+label)
        message='STAGE4 CHECKER SELFTEST PASS:12/12 corruptions rejected\n'
        (HERE/'stage4_checker_selftest.log').write_text(message);print(message,end='');return
    if stage==3:
        original=(HERE/'stage3_outputs.txt').read_text().splitlines()
        verify_memory(original)
        ri=next(i for i,s in enumerate(original) if s.startswith('R '))
        trials=[]
        for label,column,value in [('value',4,'ffffff'),('slot',2,'4'),('index',3,'1'),
                                    ('job_id',5,'0'),('mode',6,'3'),('parameter',7,'3'),('domain',8,'1')]:
            lines=original.copy();f=lines[ri].split()
            if f[column]==value:value='0'
            f[column]=value;lines[ri]=' '.join(f);trials.append((label,lines))
        ji=next(i for i,s in enumerate(original) if s.startswith('J '))
        si=next(i for i,s in enumerate(original) if s.startswith('S '))
        trials += [('missing_read',original[:ri]+original[ri+1:]),
                   ('duplicate_job',original[:ji]+[original[ji]]+original[ji:]),
                   ('missing_commit',original[:si]+original[si+1:]),
                   ('stale_token',['H '+'0'*64]+original[1:]),
                   ('extra_read',original+[original[ri]])]
        for label,lines in trials:
            try:verify_memory(lines)
            except (ValueError,IndexError):continue
            raise ValueError('Memory checker accepted corruption:'+label)
        message='STAGE3 CHECKER SELFTEST PASS:12/12 corruptions rejected\n'
        (HERE/'stage3_checker_selftest.log').write_text(message);print(message,end='');return
    original=(HERE/'stage2_outputs.txt').read_text().splitlines()
    verify(original)
    ci=next(i for i,s in enumerate(original) if s.startswith('C '))
    ji=next(i for i,s in enumerate(original) if s.startswith('J '))
    si=next(i for i,s in enumerate(original) if s.startswith('S '))
    trials=[]
    for label,row,column,value in [
        ('value',ci,4,lambda v:f'{int(v,16)^1:06x}'),
        ('index',ci,3,lambda v:str(int(v)+1)),
        ('core',ci,2,lambda v:str(int(v)^1)),
        ('job_id',ji,3,lambda v:str(int(v)+1)),
        ('last',ci,5,lambda v:str(int(v)^1)),
        ('status',si,3,lambda v:str(int(v)+1)),
        ('case',ci,1,lambda v:'104'),
        ('footer',len(original)-1,1,lambda v:'103')]:
        lines=original.copy();f=lines[row].split();f[column]=value(f[column]);lines[row]=' '.join(f)
        trials.append((label,lines))
    trials += [('missing_coefficient',original[:ci]+original[ci+1:]),
               ('duplicate_descriptor',original[:ji]+[original[ji]]+original[ji:]),
               ('extra_coefficient',original+[original[ci]]),
               ('stale_capture',['H '+'0'*64]+original[1:])]
    for label,lines in trials:
        try:verify(lines)
        except ValueError:continue
        raise ValueError('Checker accepted corruption:'+label)
    message='STAGE2 CHECKER SELFTEST PASS:12/12 corruptions rejected\n'
    (HERE/'stage2_checker_selftest.log').write_text(message);print(message,end='')


if __name__ == '__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('command',choices=['prepare','check','compare','selftest'])
    p.add_argument('--stage',type=int,choices=[2,3,4,5],default=4)
    p.add_argument('--unit',choices=['process','hash_format','shared_hash'],default='process',
                   help='Select the Stage5 unit; full KeyGen is not implemented yet')
    try:
        args=p.parse_args();command=args.command
        if command=='check':
            check();print('STAGE2 VECTOR FRESHNESS PASS')
        elif command=='prepare':prepare()
        else:{'compare':compare,'selftest':selftest}[command](args.stage,args.unit)
    except (ValueError,OSError,AssertionError,subprocess.SubprocessError) as e:
        raise SystemExit('DILITHIUM REFERENCE FAIL: '+str(e))
