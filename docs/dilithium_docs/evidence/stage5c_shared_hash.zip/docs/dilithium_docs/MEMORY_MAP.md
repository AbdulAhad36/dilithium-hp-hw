# Dilithium polynomial memory

## Implemented memory block diagram — four-slot configuration

The diagram below describes `src/controller/memory.sv` inside
`keccak_sampler_ntt`. It shows logical storage and interfaces. Physical M10K
packing for this subsystem has not been measured. Four slots are four regions
of **one declared1024 x23-bit array**,not four independently accessible RAMs.

```mermaid
flowchart TB
  C["Controller commands<br/>allocate / finish / release / execute"]
  S["Sampler<br/>data23 + index8 + core1 + ID16 + last"]
  N["NTT result stream<br/>data23 + index8 + last"]
  R["Read owner mux outside memory.sv<br/>public inspection OR NTT DMA<br/>slot2 + index8"]
  subgraph MEM["memory.sv — shared polynomial pool"]
    META["Slot metadata:4 entries x36 bits<br/>ownership / state / count / domain / bounded flag"]
    CTRL["Allocation / validation / source locks<br/>compute reservation and commit"]
    WA["One write-port selector<br/>NTT result priority,otherwise sampler<br/>23-bit word;flat10-bit address"]
    subgraph PAY["payload_r:1024 words x23 bits =23552 bits =2944 bytes"]
      P0["Slot0:256 x23<br/>word addresses0..255<br/>736 bytes"]
      P1["Slot1:256 x23<br/>word addresses256..511<br/>736 bytes"]
      P2["Slot2:256 x23<br/>word addresses512..767<br/>736 bytes"]
      P3["Slot3:256 x23<br/>word addresses768..1023<br/>736 bytes"]
    end
    RD["One synchronous read port<br/>flat address=slot*256+index"]
    RESP["Elastic response register<br/>data23 + metadata32 + valid1 =56 bits"]
    EX["Compute state9 bits<br/>held reservation reply6 bits<br/>sticky fault1 bit"]
  end
  O["Read response owner mux outside memory.sv<br/>public output OR23-bit NTT input"]
  C --> CTRL
  CTRL <--> META
  CTRL --- EX
  S --> WA
  N --> WA
  META -. "write permission and destination" .-> WA
  WA --> PAY
  R --> RD
  PAY --> RD
  RD --> RESP
  META -. "snapshot ID,domain and parameter" .-> RESP
  RESP --> O
```

Arrows into the pool use one selected write address;the four slot boxes are
not parallel write ports. A read accepts at most one request per cycle,and its
response is available after the clock edge. A blocked response prevents another
read unless it is consumed on that edge. The legal source/destination states
prevent reading a partially written slot. Engine-private FIFOs are separate.

### Storage and bus dimensions

| Storage/interface | Width | Depth / count | Contents and role |
|---|---:|---:|---|
| Shared coefficient payload |23 bits|1024 words|Four256-coefficient polynomials |
| Per-slot metadata |36 bits|4 entries|Fields below;not included in2944 payload bytes |
| Read response |56 bits total|1 entry|23 data +32 metadata/error +1 valid |
| Compute ownership state |9 bits|1 operation|active1,opcode2,A-slot2,B-slot2,destination2 |
| Compute reservation reply |6 bits|1 entry|valid1,code3,slot2 |
| Protocol fault |1 bit|1|Sticky until coordinated reset |
| Read/write coefficient index |8 bits|Each transaction|Index0..255 within slot |
| Slot selector |2 bits|Each transaction|Slot0..3;not a job ID |
| Flattened word address |10 bits|Each payload access|slot*256+index;no byte-address bus |

Metadata per slot:state2,mode2,parameter2,core1,poison1,ID16,count9,
compute-destination1,NTT-domain1,small-coefficient1 =36 bits. Four entries use
144 logical bits. Response metadata/error32 =slot2+index8+ID16+mode2+parameter2+
domain1+error1. The dimensions count declared logical fields,not fitted area.
For another SLOTS value,slot/address widths and metadata total change.

### What enters and leaves

1. **Sampler allocation:**reserve FREE slot;capture core/ID/mode/parameter.
   The output slot number tells the controller where the polynomial will live.
2. **Sampler writes:**tagged23-bit coefficients enter in order0..255. Their
   tags select the reserved slot. Memory checks canonical value,index and last.
3. **Sampling publication:**matching successful retirement plus256 prior writes
   changes WRITING to COMPLETE. Receiving coefficient255 alone is insufficient.
4. **NTT operation:**validate and lock one/two COMPLETE source slots as IN_USE;
   reserve a distinct FREE destination as WRITING. DMA reads source coefficients
   through the one response path and passes them to NTT. PWM loads A then B.
5. **Writeback:**256 tagged-by-reservation NTT results use the write selector.
   Engine completion commits the destination and unlocks the source slots.
6. **Inspection/release:**read COMPLETE slots via the public response;release
   only after consumers finish and no same-slot response remains pending.

Sampling and NTT are scheduled sequentially in the current top. The memory
write selector defines result priority,but does not itself implement concurrent
system scheduling. Allocation/execute replies and coefficient read responses
are separate handshakes. Faults invalidate affected work and require reset.

### Other storage boundaries

| Location | Logical storage | Relationship to the shared pool |
|---|---|---|
| Keccak |Two1600-bit permutation states plus input/output/control registers|Produces tagged128-bit hash beats;not polynomial slots |
| Keccak-to-sampler bridge |Two128-bit payload entries plus byte-count/core/pointers|Temporary hash beats,not persistent polynomials |
| Sampler |Per-context parsing/collection state;Ball512 x2-bit memory|Private implementation;see sampler SPECIFICATION.md |
| NTT coefficient FIFOs |32 x92,32 x92,16 x92 bits|Private working words,each packs four23-bit coefficients |
| NTT second PWM operand |64 x92 bits|Private256-coefficient operand copy |
| Seed collection |128-byte expansion result:rho32,rho-prime64,K32|Implemented in keygen_seed_collect;separate from polynomial pool;focused shared-service gate PASS |
| Encoded keys/signatures/message buffers |Not implemented or sized yet|Require an explicit storage/interface decision |

Do not sum these logical capacities into a physical M10K claim or assume they
replace encoded-key storage. Reset of the pool clears ownership and response
validity,not the payload;it prevents stale publication and is not secure erasure.

## Next KeyGen storage decision — proposal, not implemented

**Recommendation:**instantiate the configurable pool with **10 slots** for the
first full KeyGen controller,cache all transformed s1 polynomials,and add
separate addressed byte buffers for encoded public/secret keys. This proposal
needs user approval;the current tested top remains at four slots.

| Proposed storage | Logical capacity | Reason |
|---|---:|---|
| Polynomial pool |10 x256 x23 =58880 bits =7360 bytes|Largest l=7 cached transforms plus3 temporary slots |
| Public-key buffer |2592 x8 bits =2592 bytes|Largest level5 encoded public key;hash it to form tr |
| Secret-key buffer |4896 x8 bits =4896 bytes|Retain encoded secrets/t0 while tr is produced;deliver only after completion |
| Expansion collector |128 bytes|rho32,rho-prime64,K32;not polynomial slots |

This is14976 logical data bytes in total,excluding metadata/control and other
engines' private storage. Physical RAM block use is not measured. Compared to
the current four-slot payload,the ten-slot pool adds4416 logical bytes.
No signature/message buffer is included;Sign/Verify schedules may require
additional capacity and a separate decision.

| KeyGen phase | Largest live polynomial set |
|---|---|
| Build s1 cache |Already cached transforms + current sampled s1 + new transform;at most l+1 |
| Multiply a later matrix column |l cached transforms + accumulator + current A_hat + product =l+3 |
| Accumulate |l cached transforms + old accumulator + product + new accumulator =l+3 |
| Inverse row |l cached transforms + transform accumulator + INTT output =l+2 |
| Add s2 |l cached transforms + INTT output + s2 + resulting t =l+3 |
| Round/pack row |l cached transforms + t;stream both t1/t0 into key buffers before releasing t |

Pack each sampled s1 into its secret-key buffer position before releasing its
coefficient slot;keep only its transform in the cache. Pack s2 likewise before
releasing its temporary slot. Matrix entries are generated on demand and freed
after PWM. Source/result slots stay distinct. Modular ADD and round/pack routing
are still unimplemented;this table sizes their required lifetime rather than
claiming a completed schedule.

Cached s1 needs l forward transforms:4/5/7 for levels2/3/5. Regenerating it for
every row requires k*l=16/30/56. This recommendation saves12/25/49 forward
transforms and the corresponding repeated sampling;PWM/INTT counts are unchanged.
These are algorithmic counts,not measured cycle reductions.

Proposed byte offsets are public key rho[0..31],then t1 row i at32+320*i;
secret key rho[0..31],K[32..63],tr[64..127],then s1 at128,s2 at128+l*eta_bytes,
and t0 at128+(l+k)*eta_bytes. eta_bytes is96 or128 by parameter. Fill tr after
hashing the complete public key. Keep key-valid false until all fields are
written and checked;reset cancels pending keys. External command/key-transfer
ports will be specified before implementation;these offsets are internal.

Alternative:keep four slots and the same encoded-key buffers,but regenerate
s1 for each row as below. This saves coefficient capacity at a higher compute
cost. Neither alternative is adopted by merely documenting it.

## Earlier four-slot KeyGen live-range proposal - not implemented

Level2 needs k=l=4. Four slots are sufficient for a sequential mathematical
row schedule if secrets are regenerated when needed and results are delivered
to a separately defined key-output destination. This differs from caching all
four s1 polynomials and their transforms. No expanded memory allocation or
key-output protocol is approved by this proposal.

| Step in row i,column j | Live polynomial roles at peak | Action releasing capacity |
|---|---|---|
| Sample A_hat[i,j] and s1[j];transform s1[j] |Accumulator,A_hat,s1,s1_hat:4 |Release coefficient s1 after transform;regenerate it for later rows/key encoding|
| PWM(A_hat,s1_hat) |Accumulator,A_hat,s1_hat,product:4 |Release A_hat and s1_hat after PWM|
| Add product into NTT-domain accumulator |Old accumulator,product,new accumulator:3 |Release old accumulator/product;first column can keep product directly|
| Finish row |Accumulator,INTT result:2 |Release transform accumulator|
| Add sampled s2[i] |INTT result,s2,t:3 |Release INTT result and s2|
| Power2Round/pack |t plus external key-output storage |Release t only after both t1/t0 are delivered safely|

For this regeneration schedule,level2 uses16 forward transforms,16 PWM,12
transform-domain additions,4 inverse transforms and4 coefficient-domain error
additions. Cached s1_hat would require only4 forward transforms;the extra12
transforms are an explicit tradeoff,not an unnoticed throughput result.
These are logical operation counts,not measured hardware cycle counts.

Key output is a separate unresolved lifetime:pk needs rho and all t1 rows;
sk needs rho,K,tr,s1,s2,t0. tr depends on the complete encoded pk. t0 rows must
survive until written in the chosen output/key-storage protocol. A four-slot
coefficient pool does not itself store all encoded keys. Options to review are
addressed key-byte output or explicit byte storage;neither is implemented yet.

Raw SHAKE now has an optional finite-output route in keccak_sampler and a tested
seed collector. Raw jobs reserve a core but do not allocate polynomial slots.
Sampling jobs still publish through the memory status contract. The current
Stage4 top explicitly disables the optional raw route until the main-controller
connection is added. No second dual-core engine is instantiated by this service.
Final FIPS204 bytes are now selected with level2/3/5 names. The memory/key-output
architecture decisions above are still open;the isolated message formatter does
not adopt this regeneration schedule or expand the pool.

## Stage4 extension:NTT ownership and writeback

The approved four-slot capacity is unchanged. memory.sv now adds a sequential
compute reservation,source locks and a distinct result writer,used by
keccak_sampler_ntt.sv. The preserved Stage3 wrapper explicitly disables these
ports;its regression still checks the earlier sampling-only contract below.

Slot states are now FREE,WRITING,COMPLETE and IN_USE. Compute reservation
validates source state,expected IDs,domain,parameter agreement and bounded
Pre eligibility before changing ownership. Invalid commands return code1 or2
without allocation/engine activity. Valid commands wait for a free destination
and for an old read response to drain. The helper protects source release
immediately on command acceptance,including the destination-capacity wait.
Unrelated completed slots can still be released to supply capacity.
At reservation,sources transition COMPLETE -> IN_USE;
the destination transitions FREE -> WRITING. PWM may read one source twice.

Locked slots cannot be released/reallocated. The internal DMA may read IN_USE
slots;the public read path waits during compute. The helper accepts compute
commands only after active sampling contexts retire,and pauses new sampling
until completion is accepted. Consequently the first schedule is sequential.
The RAM's result write has priority over a sampler write;if a future scheduler
permits overlap,it must verify that arbitration and revise this contract.

After256 correct result writes and engine done,destination becomes COMPLETE
and sources return COMPLETE. Reset invalidates all roles and pending replies.
An internal write/ordering fault prevents valid publication and requires reset.
No partially written result is readable as a completed polynomial.

Domain is now an explicit metadata bit,independent of original sampling mode.
For example INTT(A) retains mode=A but has coefficient-domain output. Compute
results inherit source A's mode/parameter and receive the new result job ID.
NTT/Pre/PWM output is transform-domain;INTT output is coefficient-domain.
The per-slot bounded flag is accumulated from actual values,including writeback.

Source interfaces,run commands and measured Stage4 gates are in the shared
SPECIFICATION.md,REFERENCE_VERIFICATION.md and INTEGRATION_VERIFICATION_TESTPLAN.md.
There is no new fitted PPA/physical RAM-packing result for this extension.

## Preserved Stage3 sampling contract

The user approved the simple four-slot pool on2026-10-20. It is implemented in
src/controller/memory.sv and connected through keccak_sampler_memory.sv.
Functionality-first integration continues;PPA optimization is deferred until
correct full-operation outputs. No Stage3 synthesis/PPA result is claimed.

The implementation uses a configurable shared pool of four polynomial slots, simple
arbitration and sequential NTT scheduling. This is an initial integration
configuration, not the final capacity for full KeyGen/Sign/Verify.

| Item | Implemented contract |
|---|---|
| Polynomial |256 coefficients,23 bits each|
| Initial capacity |4 slots;4 x256 x23=23552 coefficient bits=2944 bytes|
| Slot address |2-bit slot number plus8-bit coefficient index|
| Allocation |Reserve a free slot before accepting a sampling job|
| Ownership |Record actual assigned core,job ID,mode and domain for that reservation|
| Sampling states |FREE,WRITING,COMPLETE;only FREE slots may be allocated;Stage4 adds IN_USE for compute sources|
| Writes |Accept only the owning job's next coefficient;check index,last and count|
| Completion |Exactly256 accepted coefficients plus successful matching status|
| Reads |Only COMPLETE slots return valid payload;other requests return an error response;ready/valid holds stalled responses|
| Release |Explicit controller release after all scheduled consumers finish|
| Errors/reset |Invalidate affected partial slots;reset clears metadata rather than bulk RAM contents|
| Arbitration |Shared sampler write stream plus independent synchronous read port;read wins a simultaneous same-slot release;pending responses block release|

Three slots allow two retained PWM operands and a separate result destination.
A fourth provides another reservation for the producer. This does not promise
unrestricted simultaneous dual-job sampling and NTT operation. If all slots
are reserved, stall new commands. First schedules will be serial;derive larger
capacity and ports from actual algorithm live ranges before supporting overlap.

The arithmetic above counts coefficient storage only. Metadata, handshake
registers and physical FPGA RAM packing add resources;no M10K/area result is
claimed before implementation and measurement. These are logical slots, not
a promise of four physical RAM blocks or a particular banking layout.

## Domain and interface obligations

The sampler emits tagged23-bit coefficients with8-bit index and last flag.
Retirement status follows SHAKE drain;receiving the last coefficient alone
must not publish a polynomial as valid. Job IDs can be reused after retirement;
slot ownership and lifecycle must prevent old contents from being mistaken
for a new polynomial.

Matrix A values are already in the transform domain. Secret/mask/challenge
polynomials begin in the coefficient domain. Preserve this distinction in
metadata;NTT representation/scaling metadata will be finalized in Stage4.

Successful status and slot commit are the same external handshake. Status
stall keeps the slot WRITING even after coefficient255. Ordinary sampler errors
free the reservation. An owned malformed write is consumed but poisons the slot;
wrong-owner traffic and premature success also raise sticky fault_o. A poisoned
slot cannot become COMPLETE. fault_o is an internal protocol failure,requires
coordinated reset,and must be handled by the future controller;it is distinct
from an expected sampler parameter-error status. Read errors are ordinary
responses and do not set fault_o. Error-response data is unspecified;ignore it.

Reads are synchronous with one response register,which can be replaced on the
same edge the previous response is accepted. Metadata is captured with each
read,so stalls cannot change its ID,domain or parameter. Reset clears metadata
and pending responses,not payload RAM;this provides validity isolation,not
secure erasure. Do not interpret two-bit slot addresses as permanent job IDs.

Read-only inspection of ntt_v2:src/ntt_LightHD/ntt_engine.sv confirms one23-bit
coefficient per accepted beat. NTT/INTT load256 values;PWM loads256 A followed
by256 B;results stream256 values with backpressure. Do not import that package
or implement its controller until Stage4. Memory has no dependency on its
internal bank organization.

## Stage3 verification gate

- Feed independently checked SHAKE-sampler jobs into allocated slots;read back
  and compare all256 coefficients,IDs,indices and domains.
- Interleave both contexts with different jobs and hold input/read/status
  handshakes;verify no mixing,overwrite or changing stalled response.
- Reject reads before successful retirement,including after coefficient255.
- Exercise pool exhaustion,explicit release and reuse with different contents.
- Inject expected parameter errors and reset during partial writes/read stalls;
  prove no partial or stale polynomial becomes readable afterward.
- Preserve the existing Stage2 checker and standalone module tests.

## Measured Stage3 source results

104 jobs:88 complete,8 expected errors,8 reset aborts.23180 input coefficients
match independently computed expectations:22528 complete values plus652 aborted
prefix values. All88 successful slots are read back exactly once:22528 values,
including ID,index,mode,parameter and domain.88 explicit releases and99 invalid
reads pass. Full-pool blocking is witnessed for8 cycles,read-response stalls
for1321 cycles and concurrent read/write for170 cycles in this workload.

The companion memory_protocol_test uses SLOTS=3 to check non-power-of-two bounds.
It rejects8 fault kinds:wrong index,wrong last,noncanonical value,wrong write ID,
premature success,simultaneous early write/success,extra257th coefficient,and
wrong finish ID. It also checks consecutive read-response replacement,
simultaneous same-slot read/release priority and reset of a stalled valid read.
The integrated test resets partial writes and a pending error response,checks
post-reset invalid reads,and reuses IDs with different messages.

The separate Python lifecycle checker confirms ownership,commit/release/reset,
all stored outputs and exact totals.12/12 deliberately corrupted captures are
rejected. The preserved Stage2 regression also passes104 jobs/23089 values and
12 checker faults. See REFERENCE_VERIFICATION.md for commands and evidence.
