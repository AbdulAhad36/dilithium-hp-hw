# Sampler Quartus baseline

## Current retained Stage4.9r

3537 actual placed ALMs,3931 registers,4256 ALUTs,one M10K/1024 bits,zero DSP.
Worst Fmax164.74MHz(Slow85:167.59,Slow0:164.74),setup+0.430ns/hold+0.141ns
at6.500ns. All4 corners0 setup/hold TNS. All original register guards pass.

Permanent project settings:seed1,STANDARD FIT,HIGH PERFORMANCE EFFORT,
PHYSICAL_SYNTHESIS_REGISTER_RETIMING OFF. The explicit retiming-OFF setting
preserves the pipeline register structure checked by report_paths.tcl.
Q's retimed fit is diagnostic and is not the selected implementation.

### Run in Quartus GUI

1. Open/reopen `quartus/sampler/sampler.qpf` so current QSF settings load.
2. Choose **Processing > Start Compilation** for synthesis,fit and timing.
3. Read actual placed ALMs from Fitter Resource Usage's
   **[A] ALMs used in final placement** row. Needed is an estimate and is not
   the project's area-selection metric.
4. Read both slow-corner Fmax values and all-corner setup/hold summaries.

No SDC or QSF edits are needed. The constraint is153.85MHz/6.500ns;Fmax is a
separate fitted estimate. Virtual data I/O are excluded from standalone timing;
no physical board integration or new functional netlist run is claimed.
Evidence:docs/sampler_docs/post_midyear/STAGE4_9R_RESULTS.json.

## Historical notes below - superseded settings/results

Historical4.6a candidate(hardware claims withdrawn;see COVERAGE.md):2901 ALMs,2258 registers,one M10K,worst Fmax102.27 MHz,
setup+0.222 ns/hold+0.145 ns at100 MHz. Fresh reports are for this candidate.
User acceptance pending. Old generated Stage5 netlists represent the archived
baseline only;launchers reject the changed RTL/settings. No stage advancement.

Target: Cyclone V 5CGXFC7C7F23C8, Quartus Prime Lite 25.1std.0, fitter seed1.
The complete four-mode sampler is the top; RTL stays under src/sampler/.

## GUI

Open quartus/sampler/sampler.qpf, then Processing -> Start Compilation.
sampler.sdc permanently specifies the user-approved initial 100 MHz target
(10 ns) for fitting and final STA. No manual SDC editing is needed.

Current3.3k: 3543 ALMs, 2388 registers, one M10K, 100.33 MHz worst Fmax, setup +0.033 ns and hold +0.144 ns at 100 MHz. Status: functional checks pass; standalone internal timing passes at 100 MHz.
See THROUGHPUT.md/STAGE3_3K_RESULTS.json in module docs. Earlier fits are
archived separately. Fmax is not the constraint or board-interface signoff.

## Command line

From this folder:

```powershell
& 'F:\altera\quartus\bin64\quartus_sh.exe' --flow compile sampler
& 'F:\altera\quartus\bin64\quartus_sta.exe' -t report_paths.tcl
```

Current reports: output_files/sampler.map.rpt, sampler.fit.rpt,
sampler.sta.rpt/.summary and critical_paths/*_setup.rpt/*_hold.rpt.
The second command exports three paths at each of four corners without changing
constraints. Caches/binaries are ignored; compact baseline evidence is archived.

All 238 data/control port bits are virtual. clk is the sole physical clock input,
with fitter-selected placement and no board pin assignment. The expected missing
exact-clock-pin warning is documented; these results do not establish board I/O
timing. SDC excludes data-input/output paths and retains internal clocked paths.
## Stage5 netlist export

Keep the accepted source/QSF/SDC frozen. From the repository-root terminal:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File quartus/sampler/generate_netlists.ps1
```

The script runs quartus_eda with settings writes disabled. Post-fit uses the
active fitted database; post-synthesis uses a separate postsynth_build directory
with quartus_map only, no fitter. Never label two exports of the fitted database
as two implementation stages. The generated files are simulation_postsynth/
sampler.vo and simulation_postfit/sampler.vo. Reports/logs and helper caches
stay here; RTL remains in src/sampler and UVM remains in tb_uvm/tb_uvm_sampler.

Questa launchers live in sim/sampler; run them with sim/ as the directory.
Cyclone V warning10905 means post-fit is functional only. The small .sft file
is not an SDF delay file; timing evidence remains the retained TimeQuest report.
See FIPS204_SAMPLER.md for the full prepare/export/run/compare commands and
COVERAGE.md/STAGE5_RESULTS.json for recorded validation results and limits.
