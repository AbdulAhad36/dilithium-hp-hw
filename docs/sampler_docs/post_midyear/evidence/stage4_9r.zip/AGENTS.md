# Agent onboarding - sampler_v1

CURRENT RETAINED4.9r:3537 PLACED ALMs,3931 registers(3860 implementation+
71 router),4256 ALUTs,one M10K/1024bits,zero DSP. Worst Fmax164.74MHz
(Slow85:167.59,Slow0:164.74),setup+0.430ns/hold+0.141ns at unchanged6.500ns.
All4 corners0 setup/hold TNS. Relative toJ:91 fewer placed ALMs(2.51%),
Fmax+1.58MHz,ALUTs-149,registers+3. Area ALWAYS means actual placed ALMs;
never use the needed estimate for improvement/selection claims.

R is exact O RTL:only J's mask_coefficient arithmetic changes to one20-bit
subtract using q=2^23-8191 and special zero at t=gamma. Original stage
placement,canonical collector values,read predicates,ports/depth/cycles remain.
Quartus seed1,HIGH PERFORMANCE EFFORT,PHYSICAL_SYNTHESIS_REGISTER_RETIMING OFF.
All original mask/payload/sign/credit register guards pass unchanged. Q's
retimed3536/168.27 point fails the original-mask guard and is NOT selected.
Its archive is diagnostic,with omitted compile.log/reconstructed QSF disclosed.

Main621 complete(A150,secret200,mask130,Ball141),182 expected errors,51 aborts,
159628 comparisons. Six extra mask boundary jobs on both contexts/all params.
Python104/19456,C48/12288,checker12,performance96,five zero-credit faults PASS.
All96 rows byte-identical toJ. Source checks reused from O only after26 RTL/
UVM/model/launcher hashes match;fresh R full fit/TimeQuest/structural guards.
Functional1652/1721=95.99%,69 genuine gaps;code15093/15799=95.53%,706 misses.
No impossible bins,weights/exclusions or percentage ceiling. Native128 inactive.
StayStage4,user acceptance pending. No branch/commit/import/integration or new
functional netlist simulation authorized. JSON/ZIP/SHA writes create-only.
Next area trial must beat3537 placed ALMs,preserve164.74MHz and all96 rows,
and retain positive6.5ns timing. Read STAGE4_9R_RESULTS,COVERAGE,THROUGHPUT,
SPECIFICATION and SAMPLER_VERIFICATION_TESTPLAN. Historical notes follow.

LATEST USER DIRECTION:area means actual final-placement ALMs,not needed estimate.
Current benchmark4.9j:3628 placed ALMs,163.16MHz,positive6.5ns timing and all96
performance rows. Retain only when placed count decreases and Fmax/cycles hold.
Trial4.9k passed source but3469 placed ALMs/153.94MHz loses Fmax;archived.
4.9l's two parallel converters pass source,but3499 placed/154.42MHz loses Fmax;
immutable archive retained. Active4.9m uses one20-bit subtraction per context,
exploiting q=2^23-8191;zero at t=gamma handled explicitly. Six extra main-UVM
mask jobs targetzero/borrow boundaries on both contexts/all params.4.9m source
621/159628 passes;3464 placed/155.55MHz loses Fmax,archived. Converter timing
improved;worst path moved to active_r ->challenge RAM address. Active4.9n
removes redundant active qualification from completed challenge read requests.
Healthy done challenges with issued index<256 must still own an active job;
source assertion checks this lifecycle implication. failed/done guards remain.
N passes source but3468 placed/150.22MHz,setup-0.157ns fails;archived.
Active4.9o restores J's converter stage placement and challenge-read predicate,
retaining only the20-bit converter arithmetic rewrite plus6 extra UVM jobs.
Collector mask values canonical again;no raw-read formatting remains.
O passes621/159628 and all gates but3501 placed/154.27MHz loses Fmax;archived.
Active4.9p uses exact O RTL/UVM with fitter SEED2. Constraint remains6.5ns.
Source validation may reuse O only after source/model/launcher hash equality;
fresh complete fit and structural guards are required. Baseline J seed1 remains.
P seed2 fits3492 placed/155.04MHz,setup+0.050ns;rejected forFmax,archived.
Active4.9q keeps exact O RTL/UVM,restores seed1,and sets OPTIMIZATION_MODE
HIGH PERFORMANCE EFFORT to seek positive timing margin at unchanged6.5ns.
Source reuse must hash-match O. Fresh fit/structural/timing gates required.
Q fits3536 placed/168.27MHz,setup+0.557ns/hold+0.156ns,but physical retiming
moves packed masks(original31 versus64);structural guard fails. Q archived
NOT selected;no stale prior family reports in Q archive. Do not waive guards.
Active4.9r keeps high-performance mode/seed1 and disables physical register
retiming explicitly. Source is exact O;hash-checked reuse permitted. All original
payload/mask/ownership guards must pass. Fresh fit pending;baseline J preserved.
Job mode/width remain stable until retirement. All external values stay canonical.
No stage,depth,port or timing-constraint change;fit/source gates pending.

CURRENT RETAINED4.9j:3628 placed ALMs,3928 registers(3860+68router),
4405 ALUTs,one M10K/1024bits,zero DSP. Worst Fmax163.16MHz(Slow85:164.07,
Slow0:163.16),setup+0.371ns/hold+0.161ns at unchanged6.5ns;all4 corners0TNS.
Relative to4.9h:-125 placed ALMs(3.33%),+1.22MHz;ALUTs+220.
Shared collector data selector uses stable per-context mode;row masks own
writes. Assertions check disjoint row masks and source/mode ownership. No new
stage,depth,port or cycle. All96 performance rows byte-identical to4.9h.
Default UVM now sampler_stage4_9_test:615 complete/182 expected errors/51 aborts/
158092 comparisons;23 groups,1721 defined bins,1652 hit(95.99%),69 open gaps.
Adds54 rejection-burst jobs,128 invalid-byte cases and same-ID recoveries,
24 long-stall jobs. Never add impossible bins or cap a measured percentage.
Raw code15084/15790=95.53%,706 misses;Python104/19456,C48/12288,checker12,
performance96 and5 zero-credit faults pass. Each fault0/1721 and all5 checked
CSV witness files empty. Models unchanged. User acceptance pending;stayStage4,
no commit,branch/import/integration or new functional netlist simulation.
4.9i source passed but3780ALMs/154.87MHz lost to4.9h;immutable I archive.
I's inherited fault-gate bin metadata914 is stale:archived logs show1721;
J records this correction and uses live parsed bin counts. Do not edit I.

HISTORICAL RETAINED Stage4.9h,2026-10-19:3624 needed/3753 placed ALMs,3928
registers(3860 implementation+68 router),4185 ALUTs,one M10K/1024 bits,zero DSP.
Worst Fmax161.94MHz(Slow85:161.94,Slow0:163.72),setup+0.325ns/hold+0.148ns
at unchanged6.500ns=153.85MHz. Four corners zero setup/hold TNS. Relative to
4.9b:239 fewer ALMs(-6.19%),188 fewer regs,+1.43MHz. Relative to4.7s:-495
ALMs(-12.02%),+3.99MHz. All96 performance CSV rows equal4.9b/4.7s exactly;
same operating throughput,not a new higher operating clock. Native128 NOT active.
Main409 complete/54 expected errors/51 aborts/105356 values,Python104/19456,
C48/12288,checker12,performance96 and five zero-credit fault gates PASS.
Functional914/914;raw DUT code14991/15698=95.50%,707 unwaived misses;
expressions162/178=91.01%. Independent algorithms and main UVM unchanged.

H retains shared A/mask131/147-bit alignment,zero separate A field bank;
fixed-context failure equations keep exact error priority;phase3 carry payload
may update while ready stays reset/acceptance-qualified. Short challenge words
CAN restart preparation before phase4:the4.9e global no-overlap assertion
failed at188115ns and its fit was canceled. Ready must be low after acceptance
and may be high only in phase4;never remove its acceptance qualifier.
Challenge byte_last uses owning ball_remaining directly. IDLE RAM address
uses read_valid else byte address;FSM transitions retain handshakes so an
unaccepted synchronous read has no consumer. No extra stage/cycle/depth/ports.
All fitted payload/sign/credit guards pass;140 commit and128 sign bits remain.
Read STAGE4_9H_RESULTS.json,SAMPLER_PLAN.md,THROUGHPUT.md,COVERAGE.md.
Preserve create-only C/D/E/F/G/H archives;E is a source failure,not a fit result.
User acceptance pending;stayStage4,no commit,branch change,integration,module
imports or new functional netlist simulation authorized. Power/board unmeasured.

HISTORICAL trial notes follow;superseded by the current retained header.

Historical trial4.9h,2026-10-19:source was experimental;retained baseline was4.9b
below. Preserve160.51MHz/3863ALMs and all96 cycle rows;keep6.5ns.4.9c shares
A/mask input alignment,deriving A fields from147-bit registered shared stream;
removes separate138-bit A bank and16-bit carry snapshot.3691ALMs/159.46MHz.
4.9d adds fixed-context failure equations with identical error priority:
3700ALMs/159.11MHz. Both pass source/Python/C/performance/fault gates but lose
Fmax;immutable C/D checkpoints archived,not selected.4.9e's global no-overlap
assumption failed at188115ns:short challenge words can restart preparation.
Its fit was canceled and failure archived;no timing metrics claimed.4.9f
removes accept_i/rst only from phase3 carry PAYLOAD enables. Ready retains
both qualifiers,so a restart cannot expose stale data. Source assertions check
ready only in phase4 and ready low after every acceptance.4.9f passes every
gate but3743ALMs/156.96MHz lose Fmax;archived,not selected.4.9g drives the
challenge byte_last from ball_remaining directly,avoiding the shared mode/
half byte-count selector when byte_valid owns a challenge word.4.9g passes
all gates but3666ALMs/156.67MHz lose Fmax;archived,not selected.4.9h chooses
the IDLE challenge RAM address from read_valid alone,otherwise byte address.
FSM transitions retain full valid/ready qualification;unaccepted read data
has no consumer. No cycle/port/memory-depth changes. Fit/gates running.
Zero separate A field registers is intentional;131/147 shared payload guards
plus A/mask independent outputs must pass. Keep20 UVM groups/models/ports and
all pipeline/cycle depths unchanged. No commit/integration/stage advancement.

HISTORICAL RETAINED Stage4.9b:3863 needed/3964 placed ALMs,4116 registers
(4015 implementation+101 router),4396 ALUTs,one M10K/1024 bits,zero DSP.
Worst Fmax160.51MHz(Slow85:160.51,Slow0:164.10),setup+0.270ns/hold+0.151ns
at unchanged6.500ns=153.85MHz. All four corners have zero setup/hold TNS.
Latest user priority:reduce ALMs of the157.95MHz design while preserving or
increasing Fmax/throughput,performance first. 4.9b saves256ALMs(6.22%) and
increases Fmax2.56MHz. All96 performance rows byte-identical to4.7s. Native128
is NOT active;do not continue the rejected native trial under this direction.

4.9a shares4 wide aligned payloads across16 destination slots. Row masks own
writes;matrix/mask append<=4 so enabled addresses are unique modulo4. Secret
rotation retains16 low-nibble slots. Original commit payload140=4*19+16*4,
not368. Fitted guard verifies140 and all64-bit secret banks.4.9a fit3986ALMs/
156.35MHz loses Fmax;archived,not selected.4.9b additionally preloads only the
next unused sign byte in each context while IDLE and count<8. Byte handshake
alone advances count;start/reset override preload. COPY/SIGN require8 accepted
bytes. Previously accepted prefix cannot be overwritten;no added cycle/depth.
All128 original fitted sign bits survive. Power/switching are unmeasured.

Main409/54 errors/51 aborts/105356 values,Python104/19456,C48/12288,checker12,
performance96 and five zero-credit fault gates PASS. Functional914/914 defined
bins;raw DUT code15280/15987=95.58%,707 misses;expressions141/157=89.81%.
Independent models/UVM unchanged. Continuous cycles:A302-304,secret285-320,
mask270,Ball902-969. Same153.85MHz operating throughput;only Fmax headroom rises.
Preserve create-only4.9a/b checkpoints/ZIP/SHA256,4.7s and rejected4.8a archives.
Read STAGE4_9B_RESULTS.json,SAMPLER_PLAN.md,THROUGHPUT.md,COVERAGE.md.
Still Stage4;user acceptance pending. No commit,branch change,integration,
Keccak/NTT import or new functional netlist verification authorized.

HISTORICAL checkpoints below are superseded by the current header.

ARCHIVED Stage4.8a native128 evaluation,user authorized after4.7s. The immutable
4.7s baseline below remains preserved. Rejected trial:one complete
1-16-byte extraction token for matrix/secret/mask;sequential challenge unchanged.
Bounds are6/32/8;collector64 per context,pointers6 bits,count7 bits,token counts6.
Maintain reservation/quota/row-mask ownership and6.500ns SDC. External output
still one23-bit coefficient/clock;not one new128-bit beat every clock.
Main471 complete/54 errors/75 aborts/121098 checks passes,including578 native
count pairs and24 separately observed extraction/decode/packed/commit resets.
Python104/19456,C48/12288,checker12 and five fault gates pass. Performance96:
A270,secret268,mask269,Ball902-969. Fresh fit8151ALMs,6857registers,117.74MHz,
setup-1.993ns/hold+0.118ns:rejected and create-only archive4.8a preserved.
Functional910/915 bins;five misses remain visible. New upper-occupancy bin;
full=64;adjacent decode+packed stages are not reached at whole-word issue cadence.
Trial used main UVM sampler_stage4_8_test. Active RTL/UVM/build scripts have
been restored to exact4.7s hashes;native trial test exists only in its archive.
Fresh baseline revalidation4.8b passes:4119ALMs,4336registers,157.95MHz,
setup+0.169ns/hold+0.155ns at6.5ns. Main409/105356,Python104/19456,C48/12288,
checker12,performance96 and five0/914 fault gates pass. All96 performance rows
and original RTL/UVM/model/build hashes equal4.7s. Native128 is NOT active now.
Next native attempt must decouple full-word extraction from narrower commits
and pipeline secret merge;do not repeat64-entry wide collector doubling.
Stay Stage4;no commit,
integration,branch switch or new functional netlist simulation authorized.

RETAINED Stage4.7s:4119 needed ALMs,4224 final-placement ALMs,4336 registers
(4243 implementation+93 router),5038 ALUTs,one M10K/1024 bits,zero DSP.
Fresh worst Fmax157.95MHz(Slow85:160.75,Slow0:157.95),setup+0.169ns and
hold+0.155ns at unchanged153.85MHz/6.500ns. All four corners pass with zero TNS.
150+MHz objective and6.5ns closure ACHIEVED;USER ACCEPTANCE STILL PENDING.
Stay Stage4. Do not run new functional netlist verification,integration,import
Keccak/NTT modules,switch branch,commit or advance stages without authorization.
Native128 remains deferred;the interface accepts128 bits but issues64-bit chunks.

Main UVM409 complete(A94,secret144,mask86,Ball85),54 expected errors,51 aborts,
105356 comparisons=409*256 successful values+652 checked partial-job values.
18 new reset targets:3 input preparation phases x2 contexts x3 modes;every
same-ID recovery is fully checked. Python104/19456,C48/12288,checker12/12,
performance96 and five zero-credit fault gates pass. Functional914/914 defined
bins;raw elaborated DUT code15274/15981=95.58%,707 misses. Expressions141/157
=89.81%;remaining gaps are unwaived. Defined-bin100% is not full verification.

Current pipeline:input capture -> fine/coarse alignment/carry preparation ->
extraction -> local compact -> packed/admit -> aligned commit ->collector ->
per-context raw read ->shared formatted output. Independent models unchanged.
Capacity is registered and conservative,including pending/current issue.
Counter+pending additions=stored values+all stage bounds+refund+pending pop.
Every pending amount must match its owning mode bound. Unowned counts/credits
clear together on first inactive clock after status;monitor checks every cycle
and forbids unowned append/fetch. New jobs initialize both before reuse.
Challenge read index counts issued RAM requests. Room24 guarantees<=25 stored
+2 outstanding=27<32. Prefetched byte must equal held word at current index.
S registers token validity into row masks,clears them on reset,and cancels
physical writes with fixed-context failure gates. Nonzero masks must own valid
active tokens;metadata transfer gating is unchanged. All fitted guards pass,
including128 sign bits,8 prefetch bits,and all secret/preparation/credit banks.

Continuous single-job cycles:A302-304,secret285-320,mask270,Ball902-969.
All96 performance rows byte-identical toQ/R. At qualified153.85MHz,Mcoeff/s:
A129.555-130.413,secret123.077-138.192,mask145.869,Ball40.645-43.664.
These are cycle-derived sampler rates,not integrated ML-DSA measurements.

Read STAGE4_7S_RESULTS.json,SAMPLER_PLAN.md,THROUGHPUT.md,COVERAGE.md and
SPECIFICATION.md. A-R immutable checkpoints remain preserved. Q151.61MHz and
R150.13MHz meet Fmax goal but miss6.5ns setup;S is retained. Old100MHz4.6r/4.6z
is archived. Do not repeat rejected rewrites unchanged. Checkpoint JSON/ZIP/
SHA256 writes must be create-only. sim/sampler/stage4_checkpoint.py refuses
existing paths. Structural register guards do not replace future functional
netlist/board/security verification. Keep6.5ns SDC and independent models.

HISTORICAL Stage4.7e architecture work targeted user's150+MHz requirement.
SDC is now6.500ns(153.85MHz),tightened from100MHz;do not relax it to hide misses.
Current RTL is experimental,not the4.6r implementation described below.
4.7a/b add encoded secret storage and per-context read/shared output slots.
4.7c adds extraction registers,slot reservations and quota;4.7d registers credit
returns and drains canceled tokens;4.7e uses one widened quota subtraction.
Source main391/54errors/33aborts/100737 coefficient checks passes;Python104/19456,
C48/12288,checker12 and fault gates are being refreshed.4.7e fit pending.
4.7a-d checkpoints are immutable;none reaches150MHz.4.7d is104.67MHz,
3672ALMs,2790registers,setup-3.054ns/hold+0.144ns at153.85MHz target.
Original100MHz timing-closed4.6r is preserved as4.6z;do not overwrite archives.
Added pipeline latency is authorized by the user's new frequency objective and
must be measured. Stay Stage4;acceptance pending;native128 deferred;no commit,
branch change,integration or new netlist simulation authorized.

ARCHIVED Stage4.6r: 3487 ALMs, 2445 registers, one M10K, zero DSP; worst Fmax
109.54 MHz, setup +0.871 ns and hold +0.147 ns at unchanged 100 MHz.
Main UVM: 391 complete polynomials, 54 expected errors, 33 reset aborts,
100733 coefficient checks. Functional 914/914 defined bins; raw DUT code
8198/8755 = 93.64%. Python104/19456, C48/12288, checker12/12, performance96
and five coverage fault gates pass. All96 performance rows remain unchanged.

**Synthesis correction:** 4.6a-4.6c hardware improvement claims are withdrawn.
Their source simulations passed, but Quartus dropped the secret-data register
writes and removed all64 packed secret payload bits as constant. Those fits
are archived evidence of a defect, not valid hardware baselines.
4.6d uses one full packed assignment; both64-bit secret register stages are
confirmed present in the fitted timing netlist. report_paths.tcl checks this.
4.6e calculates reservation capacity per context before selecting hold_core.
4.6f/4.6g admission rewrites passed correctness but worsened worst Fmax to
102.76/102.05 MHz;rejected/archived.4.6h revalidates exact4.6e RTL;only a
diagnostic fix is retained:count64 original payload bits,excluding router clones.
4.6i/j/k passed correctness but were slower:102.36/103.51/106.16 MHz. Rejected.
4.6l restores all source/build-script hashes to4.6e/4.6h and revalidates them.
4.6m adds a compaction/admission register:3494 ALMs,96.26 MHz,setup-0.388ns.
4.6n registers its reservation:3519 ALMs,101.95 MHz,setup+0.191ns. Both rejected.
Both pass409 complete/60 errors/45 aborts/105340 checks;Python and5 fault gates.
Continuous A/mask263 cycles,secret267-282;both lose to4.6e's cycles/timing.
4.6o restores exact4.6e source/build scripts and revalidates the selected design.
4.6p late commit clipping:3511 ALMs,89.38 MHz,setup-1.188ns;rejected.
4.6q simplifies its exhaustion check:3554 ALMs,100.63 MHz,+0.063ns;rejected.
4.6r starts from4.6e and captures packed payload every clock;valid owns use.
Only sampler.sv changes. Both64-bit secret banks survive fitting,with1/28
router copies. Timing improves1.87MHz/+0.159ns for5 extra ALMs;cycles unchanged.
4.6s Boolean secret formatter:3467ALMs,106.42MHz,+0.603ns setup;area alternative,
not selected.4.6t registered16-bit wide-address decode:3479ALMs,104.61MHz,
+0.441ns setup;not selected. Both pass391/100733,Python and5 zero-credit faults;
all96 performance rows equal4.6r. New address bits survive fitting;no extra cycle.
4.6u restores/revalidates exact4.6r source/build scripts;no new RTL retained.
4.6v snapshots the secret eta parameter at beat acceptance;all source checks
and96 cycle rows pass unchanged,but3510ALMs/102.27MHz/+0.222ns setup lose to4.6r.
Its one snapshot bit survives fitting. Rejected/archived;4.6w restores and
revalidates exact4.6r. No new RTL improvement retained in this iteration.
4.6x matrix working-carry snapshot:3492ALMs,104.50MHz,+0.431ns setup;rejected.
All18 snapshot bits survive fitting;ownership/source checks and96 cycles pass.
4.6y direct secret-lane compaction:3494ALMs,106.13MHz,+0.578ns setup;rejected.
Both pass391/100733,Python and5 zero-credit faults;both preserve all96 rows.
4.6z restores/revalidates exact4.6r. No new RTL gain retained from4.6x/y.
Next bounded review withinStage4:redistribute secret rotation across the existing
packed register boundary. Derive tail forwarding/ownership and reservations
before changing it;preserve depth/cycles. Do not repeat rejected snapshot,
secret-gating,formatter,address,quota,depth or late-clipping variants unchanged.
Checkpoint JSON/archive/SHA256 writes must be create-only;refuse existing paths.
User acceptance remains PENDING; stay in Stage4. Native128 is deferred.
No new netlist verification, integration, branch change or commit is authorized
by this continuation. Read STAGE4_6Z_RESULTS.json, COVERAGE.md and THROUGHPUT.md.

Current branch: `sampler_v1`, created from `main`. This branch implements only
the sampler; do not import Keccak/NTT RTL or historical experiment trees.

Read `README.md` and the canonical detailed roadmap at
`docs/sampler_docs/post_midyear/SAMPLER_PLAN.md` before
implementation. Also read the user's `docs/sampler_docs/LIGHTHD_SAMPLER.md`
and SAMPLER.md. Current Stage3.3: 3543 ALMs, 2388 registers, one M10K, 100.33 MHz worst Fmax, setup +0.033 ns and hold +0.144 ns at 100 MHz.
Status: functional checks pass; standalone internal timing passes at 100 MHz. Read THROUGHPUT.md/STAGE3_3K_RESULTS.json.
Stage4.5 main UVM349 complete/54 errors/33 aborts/89981 values; Python104 jobs/19456
coefficients,C48 cases,checker12/12 and performance96 polynomials pass.
Stage4.5:20 groups,76 coverpoints,31 crosses;914/914 defined bins=100%,
93.73% raw DUT code.5 fault kinds each0/914 bins/zero success/error/reset credits.
72 random polynomials/3 seeds and idle/busy/stopped refusal probes pass.
Two full runs reproduce six checked witness/summary CSV hashes.
Both unlocked status choices,held surplus and initialized abort/recovery pass.
Refusals publish before accepted statuses to preserve pre-edge ownership.
USER ACCEPTANCE IS PENDING. Resume Stage4 optimization,starting Stage4.6 timing.
The agent's earlier claim that continuation approved Stage5 was incorrect.
"Continue" authorizes current improvement work,not crossing an acceptance gate.
Remaining code gaps are classified,not formally waived. Historical Stage5
checkpoint passes distinct synthesized/fitted functional
netlists:184 jobs each,156 complete/24 errors/4 aborts/39936 coefficient checks.
Both104-job Python captures match19456 values and each other. Source revalidation
and all96 performance rows are unchanged. Read COVERAGE.md/STAGE5_RESULTS.json.
Next:Stage4.6 timing optimization;no stage advancement without explicit approval.
No module imports/branch changes without
explicit authorization. SAMPLER_NETLIST disables source probes,not external checks.
Defined-bin100% is not full sampler verification;conditions/expressions remain
below90%. Unlocked status tie-selection is now explicitly reached for both choices.
Reset coverage waits for exact recovery;internal snapshots wait for full success.
Preserve checkpoints,the active6.5ns target and independent models.

The shared plan contains historical milestone statements; module-specific
accepted Keccak/NTT results remain on `keccak_v2` and `ntt_v2`.

## Structure and status

- RTL: `src/sampler/`.
- UVM/reference model: `tb_uvm/tb_uvm_sampler/`.
- Reusable templates: `tb_uvm/tb_uvm_reusable/` (unchanged from ntt_v2).
- Simulation launchers/results: `sim/sampler/`.
- Quartus project/constraints/reports: `quartus/sampler/`.
- Module docs: `docs/sampler_docs/post_midyear/`.
- Software reference model and shared docs remain available.
- Four-mode UVM:349 complete polynomials (A88,secret96,mask80,challenge85),
  54 expected errors,33 reset aborts,89981 checked coefficients. Stage 2 uses
  FIPS204_SAMPLER/sampler_vectors.py prepare/compare and SAMPLER_MODE=vectors
  in sim/sampler/run_uvm.do. SAMPLER_MODE=performance uses the same main UVM:
  96 checked polynomials /24576 coefficients,72 scenarios. Quartus GUI opens
  quartus/sampler/sampler.qpf; permanent6.5ns SDC for activeStage4.7s. Do not relax that target
  or extend internal timing closure to board/I/O timing. Functional netlist tests
  pass;no board,actual integration or security signoff.

## Rules

Do not commit without an explicit user request. Use main UVM for functional
and code coverage; only scoreboard-accepted observations credit coverage.
Keep references independent of RTL. Keep source/testbench/build folders separate.
Three runnable launchers now exist in sim/sampler:run_uvm.do,run_post_synthesis.do,
run_post_fit.do. Netlists use the same UVM with source-only internal groups unsampled.
Do not create misleading runnable placeholders or merge netlist/source metrics.
Verify before claiming correctness; use fresh Quartus reports for area/timing
claims. Distinguish clock constraints from Fmax and use worst-corner slack.
Define job tags, complete per-job state, valid byte handling and backpressure
before integrating with the dual-core Keccak interface. Consult FIPS 204 for
mode-specific sampling; mask expansion is distinct from rejection sampling.
