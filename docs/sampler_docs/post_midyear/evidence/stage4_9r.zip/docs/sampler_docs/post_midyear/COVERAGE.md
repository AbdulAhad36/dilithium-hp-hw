# Sampler coverage and implementation verification

## Current retained Stage4.9r - 2026-10-19

Main UVM621 complete(A150,secret200,mask130,challenge141),182 expected errors,
51 reset aborts,159628 coefficient comparisons=621*256+652 partial values.
Six additional mask polynomials target zero/gamma/8191/516097 borrow boundaries
in both widths,on both contexts. Independent scalar/Python/C formulas remain
unchanged. No direct DUT-function sampling or invented coverage holes.

R RTL/UVM/models/launcher are byte-identical toO:26 hashes checked before
reusing its passing source main,Python104/19456,C48/12288,checker12 and
performance96/five fault results. Every performance CSV row equalsJ exactly.
All5 faults hit0/1721 bins and leave all5 checked witness CSVs empty.
R has a fresh full Quartus compile,original-register guards and multicorner
timing reports;source coverage is not functional fitted-netlist verification.

23 groups/88 coverpoints/36 crosses:1652/1721 raw functional bins=95.99%,
69 reachable gaps. The detailed gap list below remains applicable. A percentage
ceiling is not imposed. Raw DUT code15093/15799=95.53%,706 unwaived misses.

| Raw DUT category | Hits / bins | Percent |
|---|---:|---:|
| Statements |954 /956|99.79%|
| Branches |819 /829|98.79%|
| Conditions |185 /199|92.96%|
| Expressions |162 /178|91.01%|
| Toggles |12973 /13637|95.13%|
| Overall summed bins |15093 /15799|95.53%|

The changed formatter adds/removes enabled code bins;denominator changes are
not solely stimulus improvements. All remaining code gaps stay unwaived.
Fresh R implementation:3537 placed ALMs,164.74MHz,setup+0.430ns/hold+0.141ns
at6.5ns;all4 corners0 setup/hold TNS. High-performance mode is enabled,but
physical register retiming is explicitly OFF. All original64-bit mask/secret
guards,140-bit commit payload and128 sign bits pass unchanged. Q's retimed
3536/168.27 point is not selected because original packed-mask count was31/64;
its diagnostic archive excludes stale family reports and records its evidence
limitations. No guard was lowered to accept it. No new functional netlist run.
Evidence:STAGE4_9R_RESULTS.json/evidence/stage4_9r.zip.

## Historical retained Stage4.9j - 2026-10-19

Default source test:`sampler_stage4_9_test` in the existing main UVM.615 complete
polynomials(A150,secret200,mask124,challenge141),182 expected error outcomes,
51 reset aborts,158092 coefficient comparisons=615*256+652 checked partial
values. The independent scalar/Python/C algorithms are unchanged. Source and
five injected mismatch gates pass. Each fault gets0/1721 functional bins and
zero rows in all5 checked witness CSVs,including the new robustness witnesses.

Added54 long-rejection jobs,128 invalid5-bit byte-count cases with same-ID
recovery,and24 prolonged output/status backpressure jobs. All96 separate
performance records remain byte-identical to4.9h. Python104 jobs/19456 values,
C48 cases/12288 values,and checker12/12 corruptions rejected also pass.

### Functional coverage:1652/1721=95.99%,69 unhit bins

23 groups,88 coverpoints,36 crosses. The original model's914 bins expand by
14 individual invalid-byte bins,128 error mode/context/count cross bins,and
665 bins in three new success-gated groups. No unreachable bins,exclusions,
weights or artificial ceiling are used to force92-93%. Sampling remains gated
by independent scoreboard acceptance;error/reset outcomes have separate checks.

| New success group | Raw hits / bins | Raw percent | Open bins |
|---|---:|---:|---:|
| stream_context |405 /409|99.02%|4|
| rejection_bursts |122 /160|76.25%|38|
| backpressure_context |69 /96|71.88%|27|

These69 gaps are reachable but untested combinations,not observed DUT failures:

- Four challenge context/parameter/beat-length combinations:core1,param0,15
  bytes;core0,param1,13 bytes;core0,param0,13 bytes;core0,param0,5 bytes.
- Rejection runs32..127 and2048+ have no credited observations:2 coverpoint
  bins and36 context/mode/parameter cross bins. Directed bursts target17,129,
  513;odd secret targets round up to18,130,514 because bytes contain2 nibbles.
-27 backpressure bins remain,including output stalls1024+ and several medium
  output/status/context combinations. The1024-clock output stall command starts
  before output becomes valid,so the observed consecutive valid-blocked time
  can be shorter. Coverage uses observed duration,not commanded duration.

The GUI's per-coverpoint group mean is a different metric(three new groups
99.79%,90.00%,82.92%);use summed raw bins above for overall reporting.
Witnesses:`sim/sampler/smoke_checked_robustness.csv`;exact bins in
`sim/sampler/smoke_functional.rpt`;zero-filtered view in
`sim/sampler/smoke_functional_misses.rpt`. Wildcard cross rows may represent
multiple misses;do not count display rows as individual bins.

### DUT code coverage:15084/15790=95.53%,706 unwaived misses

| Raw DUT source category | Hits / bins | Percent |
|---|---:|---:|
| Statements |948 /950|99.79%|
| Branches |817 /827|98.79%|
| Conditions |184 /198|92.93%|
| Expressions |162 /178|91.01%|
| Toggles |12973 /13637|95.13%|
| Overall summed bins |15084 /15790|95.53%|

Only elaborated DUT instances are counted;TB bins are not included. The new
collector RTL changes enabled code bins,so percentage changes are not solely
new stimulus hits. `smoke_code.rpt` and `smoke_code_misses.rpt` contain details.
No code misses are waived here. Measured percentages may exceed92-93%.
Unsupported native128 issue,unbounded downstream readiness,board integration
and security claims remain future work,outside these implemented-interface bins.

Fresh J fit:3628 placed ALMs,163.16MHz,+0.371ns setup/+0.161ns
hold at6.5ns;all4 timing corners pass and all fitted payload guards pass.
Source assertions check collector-source exclusivity and stable job-mode
ownership. No new functional netlist run. Evidence:STAGE4_9J_RESULTS.json.

Metadata correction for immutable STAGE4_9I_RESULTS.json:its inherited
`coverage_fault_gates[].bins` field says914,while its actual archived fault
logs show0/1721. Its main coverage/source results remain valid. I is unchanged;
J parses all five fault denominators live and asserts equality to the main
model,preventing this stale-field recurrence.

## Historical retained Stage4.9h - 2026-10-19

Same independent main UVM/reference algorithms.409 complete(A94,secret144,
mask86,challenge85),54 expected errors,51 reset aborts,105356 comparisons=
409*256+652 checked partial-job values. Python104/19456,C48/12288,checker12/12,
performance96/24576 and all5 fault gates pass. All96 performance CSV rows
equal4.9b/4.7s exactly. Every fault(value/index/tag/last/status) produces0/914
functional bins and zero checked job/outcome/activity/protocol rows.

| Raw DUT source category | Hits / bins | Percent |
|---|---:|---:|
| Statements |917 /919|99.78%|
| Branches |755 /765|98.69%|
| Conditions |184 /199|92.46%|
| Expressions |162 /178|91.01%|
| Toggles |12973 /13637|95.13%|
| Overall summed bins |14991 /15698|95.50%|

Functional914/914 defined bins across20 groups;707 raw code misses remain
unwaived. Raw denominator changes from4.9b because A payload storage is shared
and control expressions are rewritten. Percentage shifts do not represent new
test coverage;the finite defined-bin100% is not full sampler verification.

The rejected4.9e assumption was genuinely caught:source stops at188115ns when
a short challenge word restarts preparation before phase4. Its fit was canceled
and failure preserved. Current assertions instead enforce ready low after
acceptance and ready high only in phase4. Ready retains reset/acceptance
qualification;only payload enables are removed. Current main UVM includes the
previously failing challenge case and18 preparation reset/recovery targets.
No assertion was disabled to accept a failing implementation.

Fitted guards confirm shared131/147-bit preparation payloads,zero separate
A field registers,140 commit bits,all64-bit secret banks and128 sign bits.
Independent A/mask comparisons validate that shared storage produces correct
coefficients;physical aliasing is intentional rather than dropped data.
Current fit161.94MHz,+0.325ns setup/+0.148ns hold at6.5ns. Source functional
and fitted structural evidence are separate;no new functional netlist,board
or security signoff. Evidence:STAGE4_9H_RESULTS.json/evidence ZIP.

## Historical retained Stage4.9b

Main UVM409 complete polynomials(A94,secret144,mask86,challenge85),54 expected
errors,51 reset aborts and105356 coefficient comparisons=409*256+652 partial
values. Python104/19456,C48/12288,checker12/12 and performance96/24576 pass.
All96 performance rows are byte-identical to4.7s. Main UVM/reference algorithms
are unchanged;no exclusions or synthetic hits were introduced.

Functional914/914 defined bins across20 groups;raw DUT code15280/15987=95.58%.
707 misses remain unwaived;expressions141/157=89.81%. Native trial coverage is
not merged into this result. Added source invariants enforce the four-wide
append bound,sign-byte ownership count<=8,and8 accepted bytes before COPY/SIGN.

| Raw DUT source category | Hits / bins | Percent |
|---|---:|---:|
| Statements |922 /924|99.78%|
| Branches |748 /758|98.68%|
| Conditions |190 /205|92.68%|
| Expressions |141 /157|89.81%|
| Toggles |13279 /13943|95.24%|
| Overall summed bins |15280 /15987|95.58%|

Five injected faults(value,index,tag,last,status) each produce0/914 functional
bins and zero checked job/outcome/activity/protocol CSV rows. Fitted guards
confirm all64-bit secret stages and128 sign bits remain. The140 original
commit payload registers are deliberate4-slot wide aliasing,not missing data:
4*19 shared upper bits+16*4 distinct low bits. Independent scalar/Python checks
verify the external coefficients,including wrap,clipping,interleaving and
reset/error recovery. Guard checks alone are not functional netlist validation.
Fresh fit closes6.5ns with160.51MHz Fmax,+0.270ns setup/+0.151ns hold.
Evidence:STAGE4_9B_RESULTS.json. No new functional netlist/board/security signoff.

## Archived native128 trial:Stage4.8a

The trial passes471 complete(A102,secret190,mask94,Ball85),54 expected errors,
75 reset aborts and121098 comparisons=471*256+522 partial-job comparisons.
578 lower/upper secret count pairs cover17x17 populations for each eta;
24 new reset targets observe each of4 payload stages x2 contexts x3 modes.
All recoveries compare a complete same-ID polynomial.18 preparation-phase
resets and the earlier independent checks remain. Native surplus checks the
actual32-to16 admission clip. There is no adjacent-half-token assumption.

Functional910/915=99.45% across20 groups. A new upper-occupancy bin covers32-63;
full means64. Five misses:full64,decode+packed simultaneous stage state,and
its three non-challenge mode crosses. These are visible,unwaived model gaps.
No exclusions or artificial hits were added to restore100%.

| Raw DUT source category | Hits / bins | Percent |
|---|---:|---:|
| Statements |1084 /1087|99.72%|
| Branches |881 /890|98.99%|
| Conditions |182 /199|91.46%|
| Expressions |129 /148|87.16%|
| Toggles |14963 /15665|95.52%|
| Overall summed bins |17239 /17989|95.83%|

750 raw code misses remain. Denominators differ from4.7s because this trial
changes lane/storage widths and removes the obsolete half-word helper path.
Independent Python104/19456,C48/12288,checker12 and performance96 pass.
Each value/index/tag/last/status fault gives0/915 functional bins and zero
checked job/outcome/activity/protocol rows. All fitted payload/credit guards
pass,including128-bit secret banks. The trial fails timing and is rejected;
these metrics belong to its immutable checkpoint,not the restored4.7s source.

Restoration4.8b revalidates the exact4.7s RTL/UVM/build scripts:409 complete,
54 expected errors,51 aborts,105356 comparisons,914/914 functional bins and
15274/15981=95.58% raw DUT code. Python104/19456,C48/12288,checker12,
performance96 and five0/914-credit fault gates pass again. No native trial
coverage is merged into the restored source result;see STAGE4_8B_RESULTS.json.

## Retained Stage4.7s source verification

The working RTL has new input/extraction/commit/read/output register boundaries.
Main UVM passes409 complete polynomials,54 expected errors,51 reset aborts,
and105356 coefficient comparisons. The total is409*256 successful values plus
652 checked values observed before expected errors in incomplete jobs.
18 new reset targets cover3 preparation phases x2 contexts x3 non-challenge
modes. Each is followed by fully checked same-ID recovery;the existing
scoreboard and recovery gates remain responsible for acceptance.

Functional coverage remains914/914 defined bins across20 groups;the new phase
tests are explicit directed witnesses,not extra credit in this denominator.
Raw elaborated DUT source code coverage is15274/15981=95.58%. Source totals
include source-only invariant/helper logic and are not fitted-netlist coverage.
Python104 jobs/19456 values,C48 cases/12288 values,checker12/12 and performance96
pass;all five zero-credit fault gates pass. Independent model
formulas remain unchanged. S closes6.5ns timing with157.95MHz worst Fmax,
setup+0.169ns,hold+0.155ns. User acceptance remains pending inStage4.
No functional netlist simulation has been run for these variants. Fresh fitted
guards retain all secret,alignment,output,credit,prefetch and128 sign payload bits.

| Source code category | Hit / defined bins | Coverage |
|---|---:|---:|
| Statements |920/922|99.78%|
| Branches |746/756|98.68%|
| Conditions |188/203|92.61%|
| Expressions |141/157|89.81%|
| Toggles |13279/13943|95.24%|
| Overall |15274/15981|95.58%|

707 raw bins remain uncovered. Expression gaps remain unwaived. The overall
figure sums hits/bins across categories;it is not a mean of percentages.
Clocked row masks now include validity and reset clearing. Nonzero masks must
have valid active owners;per-context failed-job gates cancel writes. The
prefetched challenge byte must equal the held word at its current byte index.
Counter+pending additions must equal stored values+all pending stage bounds+
refund+pending pop credits. These source assertions supplement independent
coefficient comparison;fitted register counts are structural checks only.

**Synthesis correction:** 4.6a-4.6c hardware improvement claims are withdrawn.
Their source simulations passed, but Quartus dropped the secret-data register
writes and removed all64 packed secret payload bits as constant. Those fits
are archived evidence of a defect, not valid hardware baselines.
4.6d corrects the full packed assignment. report_paths.tcl now requires64
mapped registers in each secret stage; both checks pass. Source coverage is
still reported separately from implementation correctness; old Stage5 netlists
apply only to their archived3.3k source identity. Acceptance pending,Stage4 active.

## Archived Stage4.6r source verification - 2026-10-18

Latest exact revalidation:4.6z. Both4.6x/y are rejected for worse fitted timing;
the archived source/TB/build hashes and coverage categories match4.6r. The main,
Python,C,checker,96 performance rows and5 zero-credit fault gates pass again.
No new verification feature or RTL improvement is retained this iteration.

**Archived4.6y verification:**same391 complete/54 errors/33 aborts/100733 values,
Python104/19456,C48/12288,checker12 and5 fault gates pass;all96 cycle rows equal
4.6r. Functional914/914;raw code8068/8625=93.54%. Removing candidate_secret
removes128 covered toggle bins and2 covered statements;557 misses remain.
Statements630/632,branches463/465,conditions123/138,expressions87/97,toggles
6765/7293. This denominator change is not lost or added test coverage. The
raw-lane compactor trial is archived separately;no databases are merged.
STAGE4_6Y/Z_RESULTS.json distinguish trial evidence from restored selected RTL.

**Archived4.6x verification:**same main391 complete/54 errors/33 aborts/100733
comparisons,Python104/19456,C48/12288,checker12 and five zero-credit fault gates
pass. All96 performance rows equal4.6r. Its matrix working-carry ownership
assertion passes across partial-byte inputs,context switches,stalls and recovery.
Functional914/914;raw code8242/8799=93.67% adds44 covered implementation bins:
4 statements,2 branches,2 conditions,36 toggles from18 added carry bits.
557 misses remain;the percentage change is not new verification coverage.
Trial source/databases are archived separately;the slower snapshot is removed.
STAGE4_6X_RESULTS.json records its exact source/evidence identity.

Previous exact revalidation:4.6w after rejecting the eta snapshot trial4.6v.
The same391 complete/54 errors/33 aborts/100733 comparisons,Python104/19456,
C48/12288,checker12 and five zero-credit fault gates pass in both. All96
performance rows remain identical.4.6v adds a held-secret parameter ownership
invariant,not a golden model or coverage feature. It reaches914/914 defined
functional bins;raw code8198/8755=93.64% happens to equal4.6r despite a different
composition:statements633/635,toggles6895/7423,expressions84/94,branches463/465,
conditions123/138. One covered statement/two toggle bins replace three covered
expression bins.557 misses remain;no added tests,exclusions or merged databases.
The trial's snapshot/assertion is archived and removed. Current4.6w categories
below belong to exact4.6r. Evidence:STAGE4_6V/W_RESULTS.json.

Revalidated as4.6u after rejecting4.6s/t. All source/testbench/build-script hashes
match4.6r;the current results below are unchanged. Both trials separately pass
the391-job suite/Python/five fault gates and preserve all96 performance rows.
Both hit914/914 defined bins.4.6s code8193/8750=93.63% removes five covered bins
with its smaller formatter;its16-case algebra check gives no RTL coverage credit.
4.6t code8231/8788=93.66% adds one covered statement and32 toggle bins for16 new
address registers. Its commit-time ownership assertion passes,and all16 original
address registers survive fitting. Neither percentage change adds test features
or closes the557 raw misses. Their databases are archived separately,not merged.
The current selected source retains neither trial's formatter nor address bits/
assertion/diagnostic extension. Evidence:STAGE4_6U_RESULTS.json.

Same main UVM testbench and independent references as4.6e:391 complete
polynomials(A88,secret138,mask80,challenge85),54 expected errors,33 reset aborts,
100733 comparisons=391*256+637 checked partial values. Only the DUT's packed
payload enable changes;no register declaration,external interface or stage is
added. All96 performance rows are byte-identical to4.6e. Python104/19456,
independent C48/12288 and checker12/12 pass. The20 groups/76 points/31 crosses
still hit914/914 defined bins. Five separate injected faults each yield0/914
bins and zero successful/outcome/activity/protocol witness rows.

| Raw DUT category | Hits/bins | Percent |
|---|---:|---:|
|Statements|632/634|99.68%|
|Branches|463/465|99.57%|
|Conditions|123/138|89.13%|
|Expressions|87/97|89.69%|
|Toggles|6893/7421|92.89%|
|Overall|8198/8755|93.64%|

Two covered branch bins disappear with the removed payload enable;there is no
code exclusion or extra verification credit. Payload registers may change while
invalid;only valid-owned observations from scoreboard-accepted jobs earn
functional credit. Conditions/expressions remain below90% and unwaived. Defined
bin100% is finite-model coverage,not exhaustive verification. Separate vector
code8144/8755=93.02%,functional707/914;performance code8058/8755=92.04%,functional
460/914. These databases are not merged into the main result.

Rejected4.6p/q also pass the391-job suite,Python,all96 performance rows and five
fault gates. Their commit-stage clipping probes are archived with their source,
not retained in4.6r. Both hit914/914 bins;raw code8197/8753=93.65%.4.6q separately
checks4369 legal exhaustion-algebra cases with no RTL coverage credit.

Fresh4.6r fit:3487 ALMs,2445 registers,one M10K,zero DSP,worst109.54MHz,
setup+0.871ns/hold+0.147ns at100 MHz. Both64 original secret payload banks are
present,with1/28 router copies counted separately. See STAGE4_6R_RESULTS.json
and evidence/stage4_6r.zip. No new netlist simulation or GUI visual review.

## Preserved Stage4.6e source verification

Revalidated as4.6o after rejecting added-stage experiments4.6m/n. The selected
RTL/testbench/build scripts again match4.6l exactly;the current391/54/33/100733,
914/914 functional and8200/8757 code results below remain selected-design data.
Python104/19456,C48/12288,checker12,performance96 and all five fault gates pass.
All96 selected performance rows equal4.6l. See STAGE4_6O_RESULTS.json.

The rejected pipelines separately pass409 complete polynomials (A94,secret144,
mask86,challenge85),60 expected errors,45 reset aborts and105340 coefficient
comparisons=409*256+636 partial-prefix checks. The changed pipeline timing
changes partial-prefix lengths;these are not success credits. Twelve added
reset cases isolate the compact stage or overlap compact+packed,on both slots
in A/secret/mask. Six added malformed-input cases retain the packed-pending
error witness. Every new error/reset case is followed by same-slot/same-ID
recovery checked by the independent scalar oracle. Existing immediate malformed
input instead overlaps compact work;all three stages participate in draining.

Trial-only probes/coverage represent the real third stage:20 groups,77 points,
31 crosses,928/932 defined bins=99.57%. Four raw misses are the three-occupied
stage mask and its A/secret/mask crosses. The held128-bit beat can issue at most
two consecutive64-bit chunks before accepting another beat;the three-stage
mask is therefore a schedule constraint,not a fabricated missing test. The raw
holes remain visible/unwaived. The reset compact-stage point hits both values.
All five separate corruptions each produce0/932 bins and no witness rows.

Trial raw DUT code:4.6m8581/9143=93.85%;4.6n8609/9175=93.83%. Their changed
register/control structure changes the denominator. Conditions129/145=88.97%
and expressions89/102=87.25% remain unwaived in both. These databases are not
merged into selected4.6e. Three original64-bit secret payload banks survive
fitting in each trial,versus two in4.6e. All pipeline/quota/reservation additions
and trial-specific tests/probes are archived and removed from selected source.

Revalidated again as4.6l after rejecting4.6i/4.6j/4.6k. All source/build-script
hashes match4.6h;selected RTL,main UVM,reference formulas and functional bins
are unchanged.391 complete/100733 checks,Python104/19456,C48/12288,checker12,
performance96 and five negative fault kinds pass. Evidence:STAGE4_6L_RESULTS.json
and evidence/stage4_6l.zip. Prior checkpoints remain immutable.
Rejected source code results are8222/8779=93.66% (i),8223/8779=93.67% (j),
8561/9131=93.76% (k). All hit914/914 functional bins and preserve all96 cycle
records. Their changed source structures/ports alter raw code denominators;
these databases are separate and not merged into selected4.6e's93.64%.
Trial quota and descriptor-ownership assertions are archived with their RTL;
none of those new counters/parallel carry nets/assertions is retained.

Revalidated as4.6h after rejecting admission trials4.6f/4.6g. Every sampler RTL
byte matches the preserved4.6e checkpoint. Fresh regression/vector/performance
and five fault gates pass with the same counts below. New evidence is
STAGE4_6H_RESULTS.json/evidence/stage4_6h.zip;the original4.6e archive stays
unchanged. Trials4.6f/4.6g passed391 polynomials/100733 comparisons and914/914
functional bins but were slower;their93.68% code results are separate rejected
databases,not merged with selected4.6e. No coverage closure gain is claimed.
The payload guard now counts64 original register bits separately from valid
fitter duplicates. It still rejects missing originals. No new netlist simulation.
The actual Tcl guard passes5/5 synthetic collection cases:64 originals with0/2
copies pass;63 originals with2 copies,zero and65 originals reject. This checks
diagnostic logic,not RTL functional coverage. payload_guard_selftest.json records
the cases;the actual fitted register collection separately confirms64+64 originals.

Same main UVM sampler_stage4_6_test and independent scalar oracle:391 complete
polynomials (A88,secret138,mask80,challenge85),54 expected errors,33 reset aborts,
100733 comparisons=391*256+637 checked partial outputs. Per-context capacity
logic changes;references,test sequences and coverage bins remain unchanged.
Existing collector-fill,stall,interleaving,reset and random cases exercise it.
152592 offline cases check threshold arithmetic only;they receive no coverage credit.

Functional20 groups/76 coverpoints/31 crosses:914/914 defined bins100%;finite
bins are not exhaustive correctness. Five separate fault kinds each produce
0/914 functional bins and zero success/outcome/activity/protocol witness rows.

| Code category | Hits/bins | Percent |
|---|---:|---:|
| Statements |632/634|99.68%|
| Branches |465/467|99.57%|
| Conditions |123/138|89.13%|
| Expressions |87/97|89.69%|
| Toggles |6893/7421|92.89%|
| Raw overall |8200/8757|93.64%|

Raw sum across12 DUT instances;new capacity logic adds26 enabled bins and25
hits versus4.6d. No code exclusions. Condition/expression misses remain unwaived;
smoke_code_misses.rpt records current source lines. Separate vector code
8146/8757=93.02%,performance8060/8757=92.04%;no merged total.
Python104/19456,C48/12288,checker12/12 and performance96 pass. All96 performance
rows match4.6d. Both secret register guard counts remain64 after fitting.

Fresh4.6e:3482 ALMs,2412 registers,one M10K,zero DSP,worst Fmax107.67 MHz,
setup+0.712 ns/hold+0.142 ns at100 MHz. STAGE4_6E_RESULTS.json/evidence/stage4_6e.zip
preserve source/reports/checks. Acceptance pending;native128 deferred;old Stage5
netlist launchers reject changed source. No new netlist run or stage advancement.

## Preserved Stage4.6d source verification - 2026-10-18

Main UVM: 391 complete polynomials, 54 expected errors, 33 reset aborts,
100733 coefficient checks. Functional 914/914 defined bins; raw DUT code
8175/8731 = 93.63%. Python104/19456, C48/12288, checker12/12, performance96
and five coverage fault gates pass. All96 performance rows remain unchanged.
Comparisons =391*256+637 checked partial-prefix outputs. Mode counts are
A88,secret138,mask80,challenge85. Main SV/Python/C references and test sequences
are unchanged. Existing partial-byte/context/stall/reset/random cases check
mask carry. The added DUT invariant checks shift + new carry bits equals
chunk bytes*8 when fields exist; it does not replace the independent oracle.

Functional model:20 groups,76 coverpoints,31 crosses;914/914 defined bins100%.
Finite-bin coverage is not exhaustive correctness. Each of five injected-fault
runs has0/914 bins and zero success/outcome/activity/protocol witness rows.

| Code category | Hits/bins | Percent |
|---|---:|---:|
| Statements |629/631|99.68%|
| Branches |461/463|99.57%|
| Conditions |122/138|88.41%|
| Expressions |86/96|89.58%|
| Toggles |6877/7403|92.89%|
| Raw overall |8175/8731|93.63%|

Raw sum across12 DUT instances. The valid3.3k/Stage5 source had7749/8267;
local compactor hierarchy and mask shift logic change the denominator. The
full-assignment fix preserves the same source bin counts as4.6c; this equality
does not validate4.6c hardware. No code exclusions; condition/expression gaps
remain unwaived. smoke_code_misses.rpt contains current lines and misses.
Vector code8121/8731=93.01%,performance8035/8731=92.03%; separate runs,no merge.

Stage4.6d: 3487 ALMs, 2395 registers, one M10K, zero DSP; worst Fmax
103.62 MHz, setup +0.349 ns and hold +0.145 ns at unchanged 100 MHz.
Fresh compilation0 errors/5 warnings; no undriven-secret warning. Structural
64+64 register guard passes; new functional netlist runs still await acceptance.
Evidence:STAGE4_6D_RESULTS.json/evidence/stage4_6d.zip. Native128 deferred;
no new GUI visual review,board/security signoff,stage advancement or commit.
The4.6a source results below remain historical; their fitted metrics are invalid.

## Preserved Stage4.6a source verification - 2026-10-18

Default sampler_stage4_6_test checks391 complete polynomials (A88,secret138,
mask80,challenge85),54 expected errors,33 reset aborts and100733 coefficients
=391*256+637 checked partial outputs.42 added secret jobs exercise1282 chunks:
625 four-group count tuples0..4 plus16 local masks per eta,with rotated survivor
positions and varied nibble values. The scalar SV oracle still owns outputs.
Each sweep chunk stays wholly inside a fully checked polynomial;the generator
pads before a boundary rather than allowing its tuple to be clipped. Counts
construct inputs only;requested patterns are not proof of correct results.

Functional model unchanged:20 groups/76 points/31 crosses,914/914 bins100%.
These finite bins are not an added625-bin cross or exhaustive proof.

| Code category | Hits/bins | Percent |
|---|---:|---:|
| Statements |632/634|99.68%|
| Branches |423/425|99.53%|
| Conditions |105/121|86.78%|
| Expressions |86/96|89.58%|
| Toggles |6841/7361|92.94%|
| Raw overall |8087/8637|93.63%|

One16-lane compactor became four4-lane instances:12 DUT instances instead of9.
Enabled bins rise370,hits338,so percentage falls93.73%->93.63%. No exclusions.
Conditions/expressions remain below90%;misses are unwaived. Current
smoke_code_misses.rpt supplies updated RTL line numbers;older reviews below
refer to their archived source snapshots.

Python104 jobs/19456 coefficients,C48 cases/12288 values,checker12/12,
performance96 polynomials/72 scenarios and5 separate injected-fault gates pass.
Each negative database0/914 bins and zero success/outcome/activity/protocol rows.
Separate vector code8033/8637=93.01%,performance7953/8637=92.08%;no merged total.
All96 performance records match baseline. Fresh fit2901 ALMs/2258 registers/
one M10K,worst Fmax102.27 MHz,setup+0.222 ns/hold+0.145 ns at100 MHz.
Evidence:STAGE4_6A_RESULTS.json/evidence/stage4_6a.zip. Acceptance pending;
no new netlist run or stage advancement. Source compile/fit warnings are retained.

## Historical Stage5 checkpoint results - 2026-10-18

The user continued past the Stage4 review gate; Stage5 functional implementation
verification is complete for the recorded scope. The selected3.3k RTL/settings
are unchanged. Existing condition/expression gaps remain visible and unwaived.

| Representation | Complete / errors / aborts | Coefficient checks | Raw functional | RTL code |
|---|---|---:|---:|---:|
| Source main UVM |349 /54 /33|89981|914/914=100%|7749/8267=93.73%|
| Post-synthesis main UVM |156 /24 /4|39936|730/914=79.87%|Not measured on netlist|
| Post-fit main UVM |156 /24 /4|39936|730/914=79.87%|Not measured on netlist|

Each implementation run has184 jobs:104 file jobs (76 complete,24 expected
errors,4 reset aborts) plus80 additional successful jobs. The latter include72
seeded random polynomials and8 mode/core busy/refused-source/completion cases.
39936=156*256. Each file capture independently passes Python104/104 jobs and
19456/19456 coefficients; the two implementation captures are byte-identical.
No unexpected UVM errors/fatals. Main-UVM SV oracle remains enabled throughout.

The post-synthesis netlist comes from a separate quartus_map-only build, with
no fitted database. Post-fit comes from the selected fitted database. Their
sizes/hashes differ and both are recorded in STAGE5_RESULTS.json. The launchers
compile the generated DUT only,never a source sampler RTL substitute. Quartus
settings writes are disabled. Vendor Cyclone V primitives are compiled locally.

### Netlist observation limits and actual misses

SAMPLER_NETLIST disables source hierarchy connections; source_probes=0 disables
occupancy-conservation assertions/internal snapshots. Reset recovery still must
be verified externally but does not credit unknown internal reset-state bins.
Four groups are unsampled:reset_recovery,pipeline_activity,challenge_states and
completion_arbitration. No optimized internal values are fabricated.
Raw730/914 retains those bins; it is not directly comparable with source100%.
Additional external gaps also remain: scheduling83.33%,mode_transitions91.67%,
checked_errors83.33%,lifecycle_recovery56.67%. This netlist workload is narrower
than the source phase-targeted tests. protocol_refusals/randomized_jobs both100%.
The12-success-group mean97.916667% is a separate metric,not the raw total.
No netlist database is merged into source percentages.

Source-only phase-targeted resets,internal pending-state/error injections and
code-gap probes remain source tests. Netlist checks retain external resets,
exact recovery,value/index/tag/last/status comparisons,stable stalled offers,
all4 modes/all3 parameter sets/both cores,partial valid bytes/interleaving and
seeded backpressure. These runs do not establish exhaustive fault/security or
whole-system behavior.

### Timing, revalidation and commands

- Source349-job regression,104-job Python/C flow,96-polynomial performance test,
  12 checker self-tests and5 separate injected-fault coverage gates all pass
  again. Six checked witness/summary CSV hashes equal the saved Stage4.5 run;
  all96 performance records equal3.3k. Source code/functional metrics unchanged.
- No RTL or new full fit: retained3543 ALMs,2388 registers,one M10K,
  100.33 MHz worst Fmax,+0.033 ns setup,+0.144 ns hold,zero setup/hold TNS;
  minimum pulse-width slack+3.346 ns. Frozen reports/settings hashes verified.
- Cyclone V warning10905 permits functional post-fit only; no SDF is generated
  or used. The .sft file is not SDF timing data. TimeQuest supplies timing evidence.
  Nonclock physical I/O paths remain excluded; board/interface closure is pending.
- Expected simulator warnings about +acc optimization and code not compiled
  with coverage do not change the external equality checks. Gate RTL code
  coverage is deliberately not requested. No new visual GUI review is claimed.

From sim/ in Questa Transcript,run one at a time:

```tcl
do sampler/run_uvm.do
do sampler/run_post_synthesis.do
do sampler/run_post_fit.do
```

Prepare/export and independent Python commands are in FIPS204_SAMPLER.md.
Evidence:STAGE5_RESULTS.json,evidence/stage5.zip and SHA256 sidecar,including
distinct generated netlists,export/map logs,source/settings/report hashes and
checked captures. Earlier checkpoints preserved. Nothing committed.

Next is **Stage6 separate Keccak-sampler-NTT integration planning**. Do not
import module RTL or create/switch an integration branch without explicit
authorization. Actual integration,board/UART and security work remain pending.

## Retained Stage4.5 source results - 2026-10-17

From `sim/` in the Questa Transcript, run `do sampler/run_uvm.do`.
The default is `sampler_stage4_5_test`, using the same main UVM and independent
scalar scoreboard. **349 complete polynomials (A88, secret96, mask80,
challenge85),54 expected errors,33 reset-aborted jobs and89,981 coefficient
comparisons pass**, with zero unexpected UVM errors/fatals.
89,981 =349*256 +637 correctly checked partial outputs.

### New tests and the checker fix

| Requirement | Accepted interface stimulus / check | Result |
|---|---|---|
| C31 unlocked status arbitration | Complete a priming job to set each round-robin turn. Accept malformed input on core0 and an invalid descriptor on core1 on the same edge; assert both ready, both status-eligible and unlocked, and selected core equals the expected turn | Both choices reached; both error statuses checked independently; both failed slots recover with exact same-ID polynomials |
| C32 held surplus | For each core,120 zero secret-input bytes generate240 coefficients. Low half of the final16-byte beat finishes256;80 clocks of output backpressure retain the surplus high half | Driver observes held data with generated=256; branch later clears it, exactly256 outputs/OK match, no extra output |
| C33 refusal on completion edge | Hold a stopped-input valid while releasing status-ready on each core; input must remain refused through the status handshake | Original mask polynomial/status match and stopped witness is credited before ownership retires |
| C34 initialized challenge abort | After challenge RAM clear completes, accept zero-byte metadata in IDLE, then reuse the same core/ID | Expected byte error and exact recovered challenge pass on both contexts; initialized-IDLE abort inhibition expression is hit |

Sequence/test: `sampler_stage4_5_classes.svh`; public-channel driver and monitor:
`sampler_uvm_pkg.sv`; read-only source probes: `sampler_if.sv`/`tb_top.sv`.
The driver checks both unlocked choices, held surplus and stopped completion
once per core; the test fails if any target witness is missing. Probes do not
supply expected coefficients and no DUT state is forced/deposited.

The monitor previously sent accepted status events before refused-input events
from the same edge. The scoreboard would retire ownership first and could
reject a legitimate stopped-input observation as unowned. Refusals now publish
against pre-edge ownership, before accepted status events. C33 exercises this
ordering. This is a **testbench correction**, not a sampler RTL change.

### Current coverage

The20 groups/76 coverpoints/31 crosses are unchanged: **914/914 defined bins
=100.00%**. No new bins, exclusions, or forced misses were added. Individual
bin completion remains distinct from full source/netlist/integration signoff.

| DUT category | Stage4.4 hits | Stage4.5 hits/bins | Percent | Misses |
|---|---:|---:|---:|---:|
| Statements |627|628/630|99.68%|2|
| Branches |421|423/425|99.53%|2|
| Conditions |104|105/121|86.78%|16|
| Expressions |83|86/96|89.58%|10|
| Toggles |6507|6507/6995|93.02%|488|
| Raw overall |7742|7749/8267|93.73%|518|

The seven added hits are one held-surplus statement, two branches (surplus and
unlocked status tie), one surplus condition, two status-selection expressions,
and one initialized challenge abort-inhibition expression. Overall is the sum
of local DUT hit/enabled bins, not a category-percentage mean. No toggle gain
is claimed. Conditions/expressions remain below90% and no waiver is applied.

### Review of remaining misses

These are source-level arguments about the integrated top, **not formal
unreachability proofs**. Every miss remains in the raw denominator/report.

| Remaining location / family | Review and disposition |
|---|---|
| sampler_ball.sv:123 illegal-state default | Reset sets IDLE; each enumerated branch assigns only legal states. No fault/state-corruption campaign was performed; default remains untested |
| sampler.sv:406 failed held-beat cleanup and related hold/failed terms | Bad metadata is accepted only with an empty holding register and does not fill it. Finite-source errors normally occur after the last held byte has drained. Producer continuation after input_last could change this argument; that out-of-contract traffic is untested. Retain the guard and raw misses |
| sampler_ball.sv:127 COPY / READ_OUT abort terms; COPY write abort expression | COPY follows consumption of a held candidate byte; the empty holding adapter permits bad metadata only on the following edge, so registered failure reaches SIGN. READ_OUT starts only after done, which already blocks input/error injection. Reset takes the outer reset branch. No state forcing or formal waiver |
| sampler_ball.sv:88/91 ready condition terms | Read and byte requests are qualified by done/initialized/active ownership. IDLE code is reached only when its earlier priority conditions permit. Independent ready=false requests in the required nonmasking combinations have not been demonstrated |
| sampler.sv:237/246 pipeline core mismatch | A new tagged beat cannot enter while a previous beat is held. The old decode tag advances/clears before the next tag reaches decode. Review predicts the reported nonmasking mismatches are restricted by this schedule; no formal proof or exclusion |
| sampler.sv:256 terminal status vs pending stages;281/292/353/384 active/failed qualification | Error qualification cancels decode; status/reuse waits for pending stages; challenge result-valid is itself abort-gated. These correlated terms are retained for defensive control. Remaining nonmasking FEC combinations are untested/unproven |
| sampler.sv:362 exhausted with held challenge data | Finite end is attached to the last consumed byte; that edge empties holding data before exhaustion becomes visible. Post-last continuation is not exercised |
| Constant/range toggle families | Secret nibbles count only0/2/4; reduced eta2 nibble is0..4; A compactor count0..3; mask fields count0..4; even18/20-bit widths leave even carry counts <=16; challenge values0,1,q-1 have bits1..12 zero. Fixed payload/range bits explain many remaining zero toggles; invalid/X/physical faults are not covered |
| Other raw toggles | `smoke_code_misses.rpt` remains authoritative for every bit and transition; not every residual toggle has a formal invariant or independent test. No blanket unreachable classification |

### Validation and acceptance boundary

- Python104 jobs/19456 coefficients,C48 cases/12288 coefficients,checker12/12
  and performance96 polynomials/72 scenarios pass. All96 performance CSV rows
  match the3.3k checkpoint byte-for-byte.
- Five separate value/index/tag/last/status injections each fail before credit:
  0/914 functional hits and no success/outcome/activity/protocol CSV rows.
- Two full Stage4.5 regressions reproduce the six checked witness/summary CSV
  hashes. The72 fixed-seed random polynomials remain included. This establishes
  repeatability of these records, not an exhaustive seed campaign/input dump.
- Separate vector functional707/914=77.35%, code93.08%; performance functional
  460/914=50.33%, code92.11%. No merged percentage.
- RTL,models and Quartus settings remain unchanged. No new fit was run;
  retained3.3k internal100 MHz results are3543 ALMs,2388 registers,one M10K,
  worst Fmax100.33 MHz,setup+0.033 ns,hold+0.144 ns. The existing SDC excludes
  nonclock input/output paths; actual Keccak/NTT,board/security and netlist work
  remain separate.

Evidence: `STAGE4_5_RESULTS.json`, `evidence/stage4_5.zip` and SHA256 sidecar;
previous checkpoints preserved. Batch verification only; no new GUI visual review.
Stage4.5's bounded review is complete. **Full Stage4 acceptance is pending user
review**, including the unwaived condition/expression gaps. After acceptance,
Stage5 will generate and verify real post-synthesis/post-fit netlists. Nothing
committed; no Stage5 launchers or placeholder passes created.

## Historical Stage4.4 results - 2026-10-17

Run from `sim/` in the Questa Transcript:

```tcl
do sampler/run_uvm.do
```

The default is now `sampler_stage4_4_test`, using the main UVM environment.
**337 complete polynomials (A82, secret94, mask78, challenge83), 48 expected
errors, 33 reset-aborted jobs and 86,909 coefficient comparisons pass.**
The comparison count is 337*256 + 637 correctly checked partial outputs from
jobs that later abort/error. There are zero unexpected UVM errors/fatals.

### What Stage4.4 adds, and why its coverage is justified

| Requirement | Stimulus and check | Credit and evidence |
|---|---|---|
| C28 refused input without an owner | Offer tagged input for eight clocks on each idle slot; assert input ready stays low | The scoreboard independently checks that no job owns the slot before crediting an idle refusal |
| C29 refused busy descriptor / stopped input | Jobs5000..5031 cover each mode/core; offer a second descriptor while busy, then input after source-stop, each for eight clocks | Driver checks refusal on every offered clock; scoreboard retains witnesses and releases coverage only after the original256 outputs and OK status match |
| C30 seeded randomized work | 72 polynomials:3 seeds *4 modes *3 parameters *2 cores; random input bytes,1..16 valid bytes/beat,0..7 source-gap clocks, interleaving and output/status readiness | Independent scalar SV oracle checks every output/index/tag/last/status; only successful jobs credit seed/mode/parameter/core crosses |

These deliberately refused probes withdraw valid after eight clocks without a
handshake. They check admission refusal; they do not claim to model a producer
that keeps valid asserted until acceptance, or all possible refusal transitions.
Status is held until the stopped-input probe finishes, preserving ownership.

Implementation/study map:

- `sampler_stage4_4_classes.svh`: `random_bytes`, `seeded_job`, `random_profile`
  and sequence body generate input and schedule the probes/random jobs.
- `sampler_uvm_pkg.sv`: driver refuses unexpected handshakes; monitor emits
  refusal observations; scoreboard checks ownership and retains owned witnesses.
  Its original independent mode-specific output formulas are unchanged.
- `sampler_outcome_coverage.svh`: `protocol_refusals` and `randomized_jobs`
  sample checked events. The former has23 enabled bins, the latter84.
- `*_checked_protocol.csv`: id/core/mode/refusal_kind (1 idle,2 busy descriptor,
  3 stopped input). Current smoke has32 rows:16 idle-cycle witnesses and8 each
  busy/stopped job witnesses. Rows count observations, not distinct jobs.
- `*_checked_activity.csv`: one row per successful job, now also `random_seed`.
  Its72 seeded rows cover all72 seed/mode/parameter/core combinations.

The xorshift32 seeds are `13579BDF`, `2468ACE1`, `DEADBEEF` (hex).
Input generation, source scheduling and ready generation use separate PRNG
states, so changing backpressure does not change the input-byte generator's
state. The generator counts enough acceptable candidates to finish each job;
it does not provide expected coefficients to the scoreboard.

### Functional coverage

**20 groups,76 coverpoints,31 crosses:914/914 enabled bins =100.00%.**
This adds107 justified bins to Stage4.3's807. The12 successful-job groups and
8 outcome/protocol/random groups each reach100%. Idle refusals have no mode;
their4 mode-cross cells are ignored structurally, in addition to the existing
4 pipeline combinations. No DUT code exclusions, suppressed hits, or artificial
holes were added. This is completion of the defined finite model, not full
sampler verification.

| Separate run | Functional hits/bins | Raw DUT code |
|---|---:|---:|
| Main regression |914/914 =100.00%|7742/8267 =93.65%|
| Vector capture |707/914 =77.35%|7695/8267 =93.08%|
| Performance |460/914 =50.33%|7615/8267 =92.11%|

Runs are reported separately; no merged percentage is claimed.

### Code coverage and remaining work

| Category | Hits/bins | Percent | Misses |
|---|---:|---:|---:|
| Statements |627/630|99.52%|3|
| Branches |421/425|99.06%|4|
| Conditions |104/121|85.95%|17|
| Expressions |83/96|86.46%|13|
| Toggles |6507/6995|93.02%|488|
| Raw overall |7742/8267|93.65%|525|

Overall means the sum of local DUT hits divided by enabled bins across nine
source instances, not an average of category percentages. Six additional toggle
bins were hit versus Stage4.3; no additional statement/branch closure is claimed.
`smoke_code_misses.rpt` retains the current raw misses. Conditions/expressions
remain below90%. The unlocked dual-status selection, defensive held-surplus/
failed-hold statements, challenge COPY/READ_OUT abort terms and illegal-state
default discussed in the historical review below remain unhit and unwaived.
No formal unreachable proof or full security/integration signoff is claimed.

### Repeated checks and reproducibility

- Two complete default runs produced identical SHA256 hashes for six checked
  witness/summary CSVs (jobs,outcomes,activity,protocol,functional,outcome).
  `reproducibility.log` records the check. This establishes repeatability of
  these records; it is not a claim of exhaustive seed testing or an input dump.
- Independent Python:104/104 jobs and19456/19456 coefficients; C cross-check:
  48 cases/12288 coefficients; checker self-test:12/12 corruptions rejected.
- Five separate value/index/tag/last/status injections each cause the expected
  fatal before any credit:0/914 functional hits and zero success/outcome/
  activity/protocol CSV rows. These databases are excluded from positive runs.
- Performance:96 checked polynomials,24576 coefficients,72 scenarios; all96
  CSV rows are byte-identical to the3.3k checkpoint.
- RTL and Quartus settings hashes match3.3k. No new fit was needed or run.
  Retained internal100 MHz results:3543 ALMs,2388 registers,one M10K,
  100.33 MHz worst Fmax,+0.033 ns setup,+0.144 ns hold. Nonclock physical I/O
  paths are excluded by the existing SDC; board/actual integration is pending.

Evidence: `STAGE4_4_RESULTS.json`, `evidence/stage4_4.zip` and SHA256 sidecar.
Earlier checkpoints remain preserved. These runs were batch-verified; no new
visual GUI/wave review is claimed. Nothing committed.

Next bounded step: **Stage4.5 targeted code-gap/reachability and source-verification
acceptance review**. Any RTL change must repeat the unchanged100 MHz fitted
timing gate. Stage5 netlist verification requires user acceptance first.

## Historical Stage4.3 results - 2026-10-17

Default test: sampler_stage4_3_test,run from sim/ in Questa Transcript:

```tcl
do sampler/run_uvm.do
```

**257 complete polynomials (A62,secret74,mask58,challenge63),48 expected errors,
33 reset aborts and66429 coefficient checks pass.**66429=257*256+637 checked
partial outputs. All original12 missing functional cells are now hit. A new
completion-arbitration group checks mode/core against single/dual pending
statuses and stalled/ready offers. Current model: **18 groups,69 coverpoints,
28 crosses,807/807 enabled functional bins=100.00%**. No hits were suppressed
or holes invented to obtain a preferred percentage. This closes the defined
bin model,not all protocol/security/integration requirements.

| New directed cases | What was actually checked |
|---|---|
|4000/4010 plus peers4001/4011|Exhaustion/invalid-parameter error and same-ID recovery while a partly sampled challenge remains live;peer later matches all256 outputs |
|4100..4107|All8 formerly missing reset mode/core/parameter cells,actual occupied-stage reset followed by exact recovery |
|4200/4202|Initial6-byte beat shifts chunk alignment;final16-byte beat includes surplus valid candidates. Matrix774 bytes/mask646 bytes produce exactly256 correct outputs,with actual packed-stage clipping observed |
|4300..4307|Both independently completed statuses are pending before ready is released,in all4 modes;stable offers and exact per-core statuses verified |
|4400/4401|Nine-byte challenge prefix ends on first candidate;bad byte metadata accepted during COPY reaches registered failure in SIGN;expected error and same-ID recovery pass |
|FFFF/8000/AAAA/5555 IDs|Exact output/status tags checked with all16 bits exercised |

The new *_checked_activity.csv gives one row per successful checked job:
ID/core/mode/parameter,max collector count,seen pending-stage masks,clipping,
dual-status and wrap snapshot counts. Jobs4200/4202 each have a clipping witness;
jobs4300..4307 each have a dual-status witness. These are counts of retained
state snapshots,not cycle counts;consecutive identical snapshots are compressed.
Rows are released only after exact polynomial success. This links internal
coverage witnesses to checked jobs without using them as the golden reference.

### Current DUT code coverage and unresolved code review

| Category | Hits/bins | Percent | Misses |
|---|---:|---:|---:|
|Statements|627/630|99.52%|3|
|Branches|421/425|99.06%|4|
|Conditions|104/121|85.95%|17|
|Expressions|83/96|86.46%|13|
|Toggles|6501/6995|92.94%|494|
|Raw overall|7736/8267|93.58%|531|

No DUT code exclusions or RTL guard changes. The current smoke_code_misses.rpt
retains every raw miss. COPY-targeted malformed input covers the previously
unhit SIGN abort and selected-context terms in sampler_ball.sv:127. COPY and
READ_OUT error-abort terms remain unhit;input holding/registered failure and
done/read scheduling correlate those states. They have not been formally waived.

Both pending statuses are verified externally and in completion_arbitration,
but sampler.sv:273's unlocked status_eligible==11 choice is still unhit:the first
status offer locks before the second becomes pending. Dual-pending coverage
must not be misreported as this particular branch hit. Analyze an unlocked
simultaneous-eligibility case or document/prove scheduling restrictions first.
sampler.sv:388/406 defensive held-surplus/failed-hold statements and the challenge
illegal-state default remain unhit. Range-limited and independently untested
toggle/condition cases remain in the classified Stage4.2 review below. Conditions
and expressions are still below90%;overall93.58% does not close them.

### Repeated gates and limits

- Default:257 successful coverage credits,48 checked-error credits,33 reset
  records released after recovery. Zero unexpected UVM errors/fatals.
- Independent Python104/104 jobs/19456 coefficients;C48 cases/12288 coefficients;
  offline checker12/12 corruptions rejected.
- Separate value/index/tag/last/status injections each produce the expected
  COEFFICIENT or STATUS fatal before any credit;each database has0/807 functional
  hits and zero rows in success/outcome/activity CSVs. Negative coverage is not
  merged. SAMPLER_FAULT_KIND commands below remain valid.
- Performance96 polynomials/24576 coefficients/72 scenarios;all96 CSV records
  equal the3.3k checkpoint. Separate performance functional460/807=57.00%,code
 92.11%;separate vector functional707/807=87.61%,code93.08%. No merged total.
- RTL,independent reference formulas,fitter/device/clock/constraint hashes match
  3.3k. No new fit:retained internal100 MHz results are3543 ALMs,2388 registers,
  one M10K,100.33 MHz worst Fmax,+0.033 ns setup,+0.144 ns hold. The narrow setup
  margin,excluded physical I/O timing and untested actual integration remain.

Current evidence:STAGE4_3_RESULTS.json and evidence/stage4_3.zip,including report/
source/document hashes and SHA256 sidecar. Current GUI commands remain;
this step was batch-verified,not visually reviewed.

Next bounded step **Stage4.4**:adversarial idle-tag/blocked-descriptor/source-stop
protocol tests and reproducible randomized byte/partition/scheduling workloads,
plus targeted remaining code-miss reachability review. The current18 groups are
a finite model;new requirements must be added on their merits. Stage5 netlist
verification still awaits user review/acceptance. Nothing committed.

## Historical Stage4.2 checkpoint

### Stage4.2 results as recorded - 2026-10-17

Default main UVM is now sampler_stage4_2_test. From sim/ in the Questa Transcript:

```tcl
do sampler/run_uvm.do
```

Main regression: **229 complete polynomials (A52,secret69,mask52,challenge56),
44 expected errors,25 reset aborts and59261 coefficient checks**.
59261=229*256+637 checked partial-prefix values. There are17 groups,
65 coverpoints and26 crosses: **773/785 functional bins=98.47%,12 misses**.
The original12 successful-operation groups now each reach100%; this does not
close the broader outcome/internal model or the remaining verification plan.
No real hit was suppressed or fictitious hole added to target a percentage.

| New group | Instance percentage | Credit condition |
|---|---:|---|
|checked_errors|96.30%|Expected code/ID/core matches; every observed output prefix already matches the independent oracle |
|reset_recovery|96.97%|Actual pre-reset hold/pipeline/collector/FSM snapshot waits until an independently checked successful recovery on that slot |
|lifecycle_recovery|100.00%|Next checked successful job follows a previously checked success/error or an observed reset abort |
|pipeline_activity|96.83%|Owned occupancy/pending/wrap/clipping/source-stop snapshots released only after exact job success |
|challenge_states|100.00%|Actual shared FSM states/edges attributed to the owning job, released after full challenge equality |

Source-only monitor checks collector occupancy across clocks using the prior
count + committed append delta - accepted output pop. Descriptor/status clear
and reset are handled explicitly. It also checks count<=32 and append<=16.
These invariants supplement the independent value oracle; probes never compute
the oracle's expected coefficients. Candidate/packed stages,head/tail and FSM
probes change only the testbench, not sampler ports or fitted RTL.

Errors use scoreboard.outcome_ap, separate from checked_ap's successful jobs.
Reset records are queued on actual abort and credited only after subsequent
successful recovery. Multiple aborted attempts can await the same eventual
verified recovery; the witness CSV names the aborted and recovery IDs/modes.
Raw reset activity alone earns no hit. Pipeline snapshots earn no credit for
failed/aborted jobs. Any UVM error/fatal prevents new outcome credit.

### Remaining12 functional bins

| Cross | Misses | Actual missing cases |
|---|---:|---|
|checked_errors.cx_reason_peer|2|Exhaustion and invalid parameter while another job remains live |
|reset_recovery.cx_mode_core_param|8|A:core0 param1/2,core1 param0/2;secret:core0 param2,core1 param0;mask:core0 param0,core1 param2 |
|pipeline_activity.cx_mode_clip|2|Valid surplus candidates clipped at256 in matrix and mask jobs |

The new pipeline crosses omit four structurally impossible cells: challenge
with candidate/packed stage masks1/2/3, and challenge with admission clipping.
Challenge bypasses those stages. These are explicit functional-model ignore
bins, not DUT code exclusions. All12 remaining cells above are reachable tests.

The earlier Stage4.1 bin-label interpretation was wrong: Questa names these
individual bins by value, so b[6] means6, not the seventh array element. The
previous mask gaps were **carry6 with chunk bytes1 or7**, not carry12 with2/8.
Cases2900/2901 now hit the actual bins. The old archive is retained unchanged;
this correction applies to its explanatory annotation, not its raw hit totals.

### Current code coverage and review

| Category | Hits/bins | Percent | Misses |
|---|---:|---:|---:|
|Statements|627/630|99.52%|3|
|Branches|421/425|99.06%|4|
|Conditions|102/121|84.30%|19|
|Expressions|82/96|85.42%|14|
|Toggles|6476/6995|92.58%|519|
|Raw overall|7708/8267|93.24%|559|

No code exclusion was added. Conditions/expressions still need review despite
the overall result. The zeros-only report is smoke_code_misses.rpt, generated
from the current smoke.ucdb using this command from sim/:

```powershell
& 'C:\questasim64_2024.1\win64\vcover.exe' report -codeAll -details -zeros -output sampler/smoke_code_misses.rpt sampler/smoke.ucdb
```

| Source / miss | Classification / action |
|---|---|
|sampler_ball.sv:123 default recovery statement/branch |Illegal FSM-state recovery; ordinary reset transitions do not enter invalid states. Retain guard; no formal unreachability waiver applied |
|sampler.sv:388 generated==256 with held surplus;406 failed held-beat clear |Unhit defensive statements; exercise surplus/failure overlap and audit reachability before considering any waiver |
|sampler.sv:273 simultaneous status_eligible==11 branch |Reachable scheduling gap; hold both completions pending,then release/arbitrate |
|sampler.sv:237/246 different pending/held core terms |No independent condition toggle under current schedule; target tightly spaced cross-context offers or prove scheduling constraints |
|sampler_ball.sv:127 abort during COPY/SIGN/READ_OUT |Reset-at-phase tests take reset priority and do not cover these error-abort terms. Target malformed/exhausted input overlap with actual RAM operations |
|sampler_ball.sv:88/91 ready/valid and sampler.sv:292/353 active/failed guards |Correlated enable/ownership terms; distinguish feasible handshake overlap from structurally constrained terms before waiving |
|Secret nibbles_i[0],reduced[3];challenge result_o[1:12];A count high bits |Range-constrained toggle candidates: whole-byte input gives0/2/4 nibbles; reduced eta2 value is0..4; challenge is0,+1,q-1; A count<=3. Keep raw bins visible; no exclusion made |

This is a classified review, not a formal proof that every residual miss is
unreachable. Raw FSM code coverage still was not inferred by Questa; manually
defined functional FSM groups are reported separately.

### Checker strength, artifacts and retained performance

Five separate corruptions (value,index,tag,last,status) each produced the
expected COEFFICIENT or STATUS fatal before any credit: **0/785 functional bins,
zero successful/error/reset credits**. Negative code coverage is not merged.
For one advanced negative run from sim/:

```tcl
set SAMPLER_INJECT_FAULT 1
set SAMPLER_FAULT_KIND status
do sampler/run_uvm.do
```

Allowed kinds:value,index,tag,last,status. Value uses checker_negative files;
other kinds use checker_negative_<kind>. An intentionally failing simulation's
process exit0 is insufficient; inspect the expected fatal and zero-hit report.

In addition to the earlier files, each positive run writes
smoke_checked_outcomes.csv and smoke_outcome_summary.csv (or vector/performance
prefixes). The default outcome file contains44 checked errors and25 recovered
reset records; successful-job CSV contains229 rows. The same GUI launcher still
opens waves/coverage views; this step was batch-verified,not visually reviewed.

Independent Python:104/104 jobs and19456/19456 coefficients;C48 cases/12288
coefficients;offline checker12/12;performance96 polynomials/24576 coefficients.
All96 performance rows and RTL/fitter/constraint hashes match3.3k. No synthesis
rerun was necessary; the retained internal100 MHz fit remains3543 ALMs,
100.33 MHz worst Fmax,+0.033 ns setup and+0.144 ns hold. Physical I/O/netlist/
Keccak-NTT integration remain unverified. Vector functional688/785=87.64%,code
93.08%;performance functional441/785=56.18%,code92.11%,in separate databases.

Current hashes,results and frozen evidence: STAGE4_2_RESULTS.json and
evidence/stage4_2.zip. Next bounded step is **Stage4.3**: the12 reachable crosses,
simultaneous pending statuses,surplus truncation and targeted code-miss tests.
Stage5 netlist acceptance still requires user review. Nothing committed.

## Historical Stage4.1 checkpoint

Measured2026-10-16 with Questa2024.1, seed20261016, main UVM only. RTL/settings
match the fitted Stage3.3k checkpoint. No RTL or independent oracle formula was
changed in Stage4.1. Source timing remains the same100 MHz internal-only fit:
3543 ALMs,100.33 MHz worst Fmax,+0.033 ns setup,+0.144 ns hold. This is not a
new synthesis run or physical I/O/netlist/integration signoff.

## Where to run and see results

From sim/ in the Questa GUI Transcript:

```tcl
do sampler/run_uvm.do
```

The historical default test was sampler_stage4_test. Waves and coverage views are set up by
the same launcher. At completion the Transcript prints each functional group,
the equal-group mean, raw overall functional hits/bins, code categories and raw
overall DUT code coverage. The current revision was batch-verified; GUI layout
has not been visually reviewed in this step.

| File under sim/sampler/ | Meaning |
|---|---|
|smoke_functional.rpt|Detailed functional bin names,counts and misses |
|smoke_code.rpt|DUT-only statement/branch/condition/expression/toggle details |
|smoke_coverage.rpt|General detailed report |
|smoke_checked_jobs.csv|One row per scoreboard-accepted complete polynomial; ID,mode,parameter,core,input sizes and scheduling/reuse witnesses |
|smoke_functional_summary.csv|Per-group percentages,equal-group mean and credited job count |
|smoke.ucdb / smoke.wlf|Coverage database and waves |
|smoke.log|Batch run Transcript; GUI writes uvm_gui.log |

Files are regenerated by the launcher. Compact frozen results are in
STAGE4_1_RESULTS.json and evidence/stage4_1.zip, with hashes and a SHA256 sidecar.

## How a coverage hit is justified

1. The monitor observes actual accepted bytes and outputs, plus external stalls.
2. The independent scoreboard builds the expected polynomial from those bytes.
3. Every accepted output must match value,index,core,ID and last. Success also
   requires256 outputs and correct status,mask-byte bounds/challenge weight.
4. Only then does checked_ap release that job's observed transcript. Any UVM
   error/fatal prevents new coverage credit. Errors/aborts do not sample these
   successful-operation groups.
5. sampler_coverage.svh replays the validated transcript to classify candidates,
   alignments and challenge decisions. Its logic does not generate expected
   results for the scoreboard. Byte parsing stops after256 accepted values.

Example: the first secret chunk in job1600 contains only rejected nibbles, then
enough accepted bytes to complete. After all256 outputs match, its first chunk
credits the zero-acceptance-mask/count bins. An all-rejected exhausted job would
not credit that successful-operation group. For candidate/lane/field definitions,
tests and proof limits see C01-C14 in SAMPLER_VERIFICATION_TESTPLAN.md.

## Current functional results

178 complete polynomials: A41,secret59,mask40,challenge38. There are19 checked
expected errors and11 reset aborts;46173=178*256+605 exact coefficient comparisons.
The605 are partial outputs from error/aborted jobs, not successful coverage.

| Group | Instance percentage |
|---|---:|
|checked_polynomial|100.00%|
|input_format|100.00%|
|scheduling|82.64%|
|mode_transitions|100.00%|
|matrix_candidates|100.00%|
|secret_candidates|100.00%|
|secret_compaction|100.00%|
|mask_fields|100.00%|
|mask18_alignment|99.07%|
|mask20_alignment|100.00%|
|challenge_decisions|100.00%|
|coefficient_shape|100.00%|

Primary raw-bin total: **574/589=97.45%,15 misses**. There are12 groups,
38 coverpoints and17 crosses. The mean of12 group instance percentages is
**98.48%**; it weights groups equally, whereas raw-bin coverage weights each bin
equally. Questa's aggregate headline can differ in displayed rounding. Always
state which definition is used. No bins or hits are suppressed to target a number.

### Exact remaining15 bins in this success-path model

| Group/point | Misses | Interpretation and planned stimulus |
|---|---:|---|
|scheduling.cp_out_stall|2|none,medium_stall(5..16 cycles); current default periodic stalls reach4,forced profiles reach long |
|scheduling.cp_input_block|1|none; source spacing with ready output can avoid all DUT backpressure |
|scheduling.cp_status_stall|1|medium_stall(6..16); add targeted completion stalls |
|scheduling.cx_mode_output_stall|9|All4 modes x none;all4 modes x medium;challenge x long. The initial320-cycle forced stall ends before challenge output begins |
|mask18_alignment.cx_carry_bytes|2|carry6 with chunk bytes1 or7; corrected value-label interpretation, see Stage4.2 above |

These are reachable test gaps. No exclusions are applied. Error/reset/internal
pipeline/FSM/collector requirement families remain planned in the testplan and
outside this implemented success-path denominator. High coverage here does not
close those requirements or prove cryptographic security.

## DUT code coverage

+cover=sbceft covers the nine local RTL instances; no testbench code is included.
Raw overall=sum enabled local hit bins/sum local enabled bins, deduplicated per
instance/category. Toggle bins dominate. Report actual FSM coverage only when
Questa infers it; no FSM percentage was inferred here.

| Category | Hits/bins | Percent | Misses |
|---|---:|---:|---:|
|Statements|627/630|99.52%|3|
|Branches|421/425|99.06%|4|
|Conditions|102/121|84.30%|19|
|Expressions|79/96|82.29%|17|
|Toggles|6468/6995|92.47%|527|

Conditions/expressions remain below90% despite the overall figure. Their
meaningful misses and unreachable conditions require explicit Stage4.2 review;
no code exclusion was added. The detailed totals are in STAGE4_1_RESULTS.json.
Default regression: **7697/8267=93.11%**. Initial comparisons: Stage3.3k smoke
7693/8267=93.06%; the RTL scope/denominator is unchanged. Small code-percentage
movement does not measure the growth in functional checking.

Separate vector run: code7695/8267=93.08%,functional549/589=93.21% (76 complete
jobs). Separate performance run: code7615/8267=92.11%,functional362/589=61.46%
(96 complete jobs). The performance workload intentionally has less feature
diversity. No databases are merged and no best-per-category combined result is
invented.

## Negative check of coverage gating

Advanced separate run, from sim/:

```tcl
set SAMPLER_INJECT_FAULT 1
do sampler/run_uvm.do
```

The monitor flips one bit of the first observed coefficient. Expected result:
COEFFICIENT UVM_FATAL,zero checked-job CSV rows and **0/589 functional hits** in
checker_negative_functional.rpt/UCDB. It is an intentionally failing simulation;
process exit0 alone is not a pass. Normal runs do not set this flag. Negative
results are kept separate and excluded from positive functional/code totals.

Current self-test observed exactly one expected COEFFICIENT fatal,zero coverage
credits and0/589 bins. Offline Python checker self-tests separately reject12/12
corrupted captures. Further corruption classes remain Stage4.2 work.

## Next bounded step

Stage4.1 is complete for this scope. Stage4.2 adds checked error/reset/recovery
and internal occupancy/state coverage, addresses the15 reachable success gaps,
and classifies code misses. Preserve main UVM and independent references; any RTL
change must repeat vector checks and the fixed100 MHz fitted timing gate.
