# Sampler cycles, resources and LightHD comparison

## Current retained Stage4.9r - 2026-10-19

Area means final-placement ALMs. Needed estimates do not enter selection or
improvement claims. Same device,Quartus25.1std,seed1 and6.500ns constraint.
R combines the simpler20-bit mask arithmetic at the original pre-packing stage
with HIGH PERFORMANCE EFFORT and physical register retiming explicitly OFF.
All original register guards pass. Both RTL and compiler settings contribute
to this implementation;the full PPA gain is not attributed to RTL alone.

| Metric |Previous4.9j|Retained4.9r|
|---|---:|---:|
| Actual placed ALMs |3628|3537|
| Registers |3928|3931|
| Combinational ALUTs |4405|4256|
| Worst Fmax MHz |163.16|164.74|
| Worst setup ns at6.5ns |+0.371|+0.430|
| Worst hold ns |+0.161|+0.141|
| M10K / logical bits |1 /1024|1 /1024|
| DSP |0|0|

Physical area falls91 ALMs(2.51%);ALUTs fall149(3.38%). Fmax rises1.58MHz.
Registers are3860 implementation+71 router copies:3 extra router registers
compared withJ. Slow85/0 Fmax167.59/164.74MHz. All4 corners have0 setup/hold
TNS and positive pulse-width margins. Hold margin remains positive but is
0.020ns smaller thanJ. No timing corner is omitted.

| Continuous single-job mode |J cycles|R cycles|Mcoeff/s at153.85MHz|
|---|---:|---:|---:|
| Matrix A |302-304|302-304|129.555-130.413|
| Secret |285-320|285-320|123.077-138.192|
| Mask |270|270|145.869|
| Challenge |902-969|902-969|40.645-43.664|

All96 CSV records are byte-identical toJ,including paired and stalled cases.
Operating throughput at153.85MHz is preserved;Fmax is headroom,not a changed
operating clock. Source TB uses100MHz;rates are cycle-derived and qualified
by fitted internal timing. No board/integration throughput claim.

Source is byte-identical toO. Its621-job UVM/159628 comparisons,Python104/
19456,C48/12288,checker12,performance96 and5 zero-credit faults are reused only
after26 source/model/launcher hashes match. R has a fresh full fit,complete
structural guards and multicorner timing. Q's faster retimed fit is not selected
because its original-mask register guard fails. K..P are rejected fits.
Evidence:STAGE4_9R_RESULTS.json/evidence/stage4_9r.zip. StillStage4.

## Historical retained Stage4.9j - 2026-10-19

Same CycloneV device,Quartus25.1std,seed1,standard fit and6.500ns target.
Sharing collector data selection by stable per-context job mode removes
per-row priority selection;row masks retain write ownership. No stage,port,
collector depth or measured cycle changes. Source assertions check exclusivity
and mode ownership;all existing payload/sign/reservation fit guards pass.

| Metric |Previous4.9h|Retained4.9j|
|---|---:|---:|
| Final-placement ALMs |3753|3628|
| Registers |3928|3928|
| Combinational ALUTs |4185|4405|
| Worst Fmax MHz |161.94|163.16|
| Worst setup ns at6.5ns |+0.325|+0.371|
| Worst hold ns |+0.148|+0.161|
| M10K / logical bits |1 /1024|1 /1024|
| DSP |0|0|

Placed ALMs fall125(3.33%);this physical count is the primary area metric for
all subsequent comparisons and trial gates. ALUTs rise220(5.26%);registers
remain3860 implementation+68 router. Relative to4.7s's4224 placed ALMs,J saves
596(14.11%). Worst Fmax rises1.22MHz versusH. Slow85/0 Fmax is
164.07/163.16MHz;worst setup isSlow0,notSlow85. Four corners have0 setup/hold
TNS and positive pulse-width margin.

| Continuous single-job mode |4.9h cycles|4.9j cycles|Mcoeff/s at153.85MHz|
|---|---:|---:|---:|
| Matrix A |302-304|302-304|129.555-130.413|
| Secret |285-320|285-320|123.077-138.192|
| Mask |270|270|145.869|
| Challenge |902-969|902-969|40.645-43.664|

All96 performance CSV records,including paired/stalled cases,are byte-identical
to4.9h. The measured operating throughput is unchanged;higher Fmax is headroom,
not an operating-clock increase. Source TB uses100MHz;rates are cycle-derived
at153.85MHz and qualified by internal fitted timing. No board/integration claim.

Expanded main UVM615/158092,Python104/19456,C48/12288,checker12 and five
zero-credit faults pass. Functional1652/1721=95.99%;raw DUT code15084/15790=
95.53%. TrialI's3780ALMs/154.87MHz loses both metrics and remains archived,
not selected. Evidence:STAGE4_9J_RESULTS.json/evidence ZIP. StillStage4.

## Historical retained Stage4.9h - 2026-10-19

Same CycloneV device,Quartus25.1std,seed1,standard fit and6.500ns constraint.
H combines shared A/mask alignment,fixed-context failure updates,carry payload
capture independent of acceptance,challenge last from its owning count,and
unqualified IDLE RAM address selection. Ready/FSM handshakes retain ownership.
No stage,collector depth,external port or measured cycle count is added.

| Metric |4.7s|Previous4.9b|Retained4.9h|
|---|---:|---:|---:|
| Needed ALMs |4119|3863|3624|
| Final-placement ALMs |4224|3964|3753|
| Registers |4336|4116|3928|
| Combinational ALUTs |5038|4396|4185|
| Worst Fmax MHz |157.95|160.51|161.94|
| Worst setup ns at6.5ns |+0.169|+0.270|+0.325|
| Worst hold ns |+0.155|+0.151|+0.148|
| M10K / logical bits |1 /1024|1 /1024|1 /1024|
| DSP |0|0|0|

Versus4.9b:H saves239 needed ALMs(6.19%),188 registers and211 ALUTs;Fmax rises
1.43MHz(0.89%). Versus4.7s:H saves495ALMs(12.02%) with3.99MHz more Fmax.
H has3860 implementation+68 router registers. Slow85/0 Fmax161.94/163.72MHz.
Four corners have zero setup/hold TNS and positive pulse-width margins.
Worst Slow85 path is append_tail ->packed_write_mask,+0.325ns. All payload
guards pass:131/147 shared preparation bits,zero separate A bank,140 commit
payload bits,all64-bit secret banks and128 challenge sign bits.

| Continuous single-job mode |4.9b cycles|4.9h cycles|Mcoeff/s at153.85MHz|
|---|---:|---:|---:|
| Matrix A |302-304|302-304|129.555-130.413|
| Secret |285-320|285-320|123.077-138.192|
| Mask |270|270|145.869|
| Challenge |902-969|902-969|40.645-43.664|

All96 CSV rows,including stalls and paired contexts,are byte-identical to4.9b
and4.7s. Operating throughput at the unchanged153.85MHz constraint is preserved;
higher Fmax adds headroom,not an actual operating-clock increase. Source TB
uses100MHz;the rates above are cycle-derived and qualified by fitted internal
timing. No board/integrated throughput or new functional netlist claim.

Main409/105356,Python104/19456,C48/12288,checker12,performance96 and five
zero-credit fault gates pass. Functional914/914;raw code14991/15698=95.50%.
E's failed assumption is corrected:short challenge words CAN restart unused
preparation;ready must keep acceptance priority. Its failed fit was canceled,
not promoted. C/D/F/G are archived intermediate fits;H is selected against
4.9b's stricter160.51MHz gate. See STAGE4_9H_RESULTS.json/evidence ZIP.
StillStage4;user acceptance pending. Native128 is not active;power unmeasured.

## Stage4.9g direct challenge count trial: intermediate

Challenge byte_last uses its owning ball_remaining count directly;the shared
mode/half count mux is bypassed. All409/105356 source checks,Python104/19456,
C48/12288,checker12,performance96 and five fault gates pass;all96 CSV rows
equal4.9b. Functional914/914;raw DUT code14996/15703=95.50%.
Fresh fit3666 needed/3759 placed ALMs,3918 registers(3860 implementation+
58 router),4201 ALUTs,one M10K/zero DSP. Slow85/0 Fmax157.55/156.67MHz;
worst setup+0.117ns/hold+0.155ns at6.5ns. Four corners zero setup/hold TNS.
Not selected versus160.51MHz4.9b. Worst path reaches challenge RAM address
through read eligibility/handshake-qualified address selection. Next trial
selects the IDLE RAM address without ready qualification;accepted operation
state alone owns whether the synchronous read value can be consumed.

## Stage4.9e/f preparation-enable trials

4.9e fails a source assertion at188115ns:short challenge inputs can restart
unused preparation before phase4. Its global no-overlap assumption and ready
rewrite are rejected. Fit canceled;STAGE4_9E_RESULTS.json records no timing.
4.9f keeps reset/acceptance priority on ready,but carry payload captures on
phase3 alone. Assertions require phase4 for ready and ready low after acceptance.
Main409/105356,Python104/19456,C48/12288,checker12,performance96 and five fault
gates pass. All96 performance CSV rows equal4.9b. Functional914/914;raw DUT
code14996/15703=95.50%,707 misses. Fresh fit3743 needed/3767 placed ALMs,
3932 registers(3860 implementation+72 router),4200 ALUTs,one M10K/zero DSP.
Slow85/0 Fmax156.96/157.95MHz,worst setup+0.129ns/hold+0.159ns at6.5ns;
four corners zero setup/hold TNS. Not selected versus160.51MHz4.9b.
Worst path:held context/count ->challenge exhaustion via shared byte-count
selection. Next trial connects challenge last directly to ball_remaining,
which is the owning count whenever its byte_valid is true.

## Stage4.9d fixed-context error trial: intermediate

Builds on4.9c. Failure/error updates are evaluated per fixed context,with the
same priority:short final commit >challenge exhaustion >invalid input bytes >
new descriptor parameter >prior error. No state or cycle is added.
Fresh fit3700 needed/3772 placed ALMs,3926 registers(3860 implementation+
66 router),4201 ALUTs,one M10K/zero DSP. Slow85/0 Fmax159.11/164.64MHz;
worst setup+0.215ns/hold+0.151ns at6.5ns;four corners zero setup/hold TNS.
Main409/105356,Python104/19456,C48/12288,checker12,performance96 and five
fault gates pass. All96 performance CSV rows equal4.9b. Functional914/914;
raw DUT code14993/15700=95.50%,707 misses. Fmax still loses1.40MHz to4.9b;
not selected. Worst path is challenge exhaustion ->preparation carry enable,
through the new-input acceptance guard. Next trial removes that redundant
guard from phase3 payload capture and explicitly asserts no acceptance overlap.

## Stage4.9c shared-preparation trial: intermediate

2026-10-19,same6.5ns target/device/seed/settings as4.9b. One fine/coarse
alignment pipeline serves A and mask;the accepted mode selects carry and
bit/byte shift at acceptance. A fields derive from the registered147-bit
stream,removing the separate138-bit A field bank and16-bit saved carry.
No preparation phase or issue cycle changes. Fitted guards confirm the
shared131/147-bit banks,zero separate A field registers,and all live payloads.

Fresh fit:3691 needed/3798 placed ALMs,3942 registers(3860 implementation+
82 router),4265 ALUTs,one M10K,zero DSP. Worst Fmax159.46MHz(Slow85:159.46,
Slow0:162.02),setup+0.229ns/hold+0.139ns. Four corners have zero setup/hold TNS.
Relative to4.9b:172 fewer ALMs,174 fewer registers,but Fmax loses1.05MHz.
The trial passes409/105356 main UVM,Python104/19456,C48/12288,checker12,
performance96 and five zero-credit fault gates. All96 CSV rows equal4.9b.
Functional914/914;raw DUT code14975/15682=95.49%,707 misses. The denominator
shrinks with removed storage;no hits are excluded. Not selected for Fmax
priority. Worst Slow85 path is challenge done ->failed flag via input-ready.
Preserve STAGE4_9C_RESULTS.json;next trial rewrites failure updates per context.

## Historical retained Stage4.9b: lower ALMs,higher Fmax,same cycles

Same device,Quartus25.1std,seed1 and6.500ns constraint as4.7s. This version
retains64-bit chunk processing;native128 is not active. Fresh current reports
are quartus/sampler/output_files/sampler.fit.rpt and sampler.sta.rpt.

| Metric | Preserved4.7s | Retained4.9b | Change |
|---|---:|---:|---:|
| Needed ALMs |4119|3863|-256(-6.22%)|
| Final-placement ALMs |4224|3964|-260|
| Registers |4336|4116|-220|
| Combinational ALUTs |5038|4396|-642|
| Worst Fmax MHz |157.95|160.51|+2.56(+1.62%)|
| Worst setup ns at6.5ns |+0.169|+0.270|+0.101|
| Worst hold ns |+0.155|+0.151|-0.004;positive|
| M10K / logical bits |1 /1024|1 /1024|unchanged|
| DSP |0|0|unchanged|

4.9b has4015 implementation and101 router registers. Slow85 Fmax160.51MHz,
Slow0 Fmax164.10MHz. All four corners have zero setup/hold TNS and positive
minimum-pulse-width slack. Worst Slow85 setup is hold_core ->extract mask,
+0.270ns. Fitted guards confirm140 original commit payload bits,all64-bit
secret banks and128 challenge sign bits. No data bank was dropped as constant.

| Continuous single-job mode |4.7s cycles|4.9b cycles|Mcoeff/s at153.85MHz|
|---|---:|---:|---:|
| Matrix A |302-304|302-304|129.555-130.413|
| Secret |285-320|285-320|123.077-138.192|
| Mask |270|270|145.869|
| Challenge |902-969|902-969|40.645-43.664|

Every one of96 performance CSV rows,including stalls/paired contexts,is
byte-identical to4.7s. At the unchanged153.85MHz operating constraint,the
cycle-derived throughput is preserved. Higher Fmax is additional clock
headroom,not a demonstrated increase in operating throughput. Functional
source tests use100MHz;these rates are qualified by the positive fitted
153.85MHz internal timing. No integrated,board or new functional-netlist rate.

Change1:matrix/mask wide payloads rotate modulo4 because their append bound
is4. Row masks still use full circular addresses;secret rotation stays16x4.
This removes228 duplicate original commit registers:368 ->140=4*19+16*4.
Change2:challenge preloads only its next unowned sign byte while IDLE. The
actual handshake alone advances its byte count;reset/start override preload,
and COPY/SIGN require8 accepted bytes. This removes the read-arbitration
path from128 payload enables. Power/switching has not been measured.

Main409/105356,Python104/19456,C48/12288,checker12,performance96 and five
zero-credit fault gates pass. Evidence:STAGE4_9B_RESULTS.json and immutable
evidence/stage4_9b.zip. User acceptance pending;stay Stage4,no commit.

## Stage4.9a area trial: intermediate,not selected for Fmax priority

Four wide slots replace16 duplicated wide destinations under the existing
row masks. Fresh fit:3986 needed ALMs,3891 final-placement ALMs,4087 registers
(4015 implementation+72 router),4356 ALUTs,one M10K,zero DSP. Worst Fmax
156.35MHz;setup+0.104ns/hold+0.148ns at unchanged6.5ns;all corners zero TNS.
133 fewer needed ALMs(-3.23%) and249 fewer registers versus4.7s,but Fmax is
1.60MHz lower. All96 performance rows are byte-identical to4.7s,so achieved
throughput at the unchanged timing-closed153.85MHz clock is preserved.
The user prioritizes Fmax too;this is an intermediate candidate,not selected.
Main409/105356,Python104/19456,C48/12288,checker12 and five fault gates pass.
The140 original commit payload registers are confirmed,as are all64-bit
secret banks. The area saving is deliberate aliasing of unenabled wide rows.
Worst Slow0 path:challenge issued index bit8 ->sign payload enable,+0.104ns.
Next trial removes handshake qualification from speculative unused sign-byte
payload capture;the sign-byte count still advances only on a real handshake.

## Stage4.8a native128 trial: rejected

Same device,seed1,Quartus settings and unchanged6.500ns target as4.7s.
Source functionality passes,but this trial is not selected. Restore4.7s.

| Metric | Preserved4.7s | Native4.8a trial |
|---|---:|---:|
| Needed / final-placement ALMs |4119 /4224|8151 /8245|
| Registers |4336|6857|
| Combinational ALUTs |5038|8986|
| M10K / DSP |1 /0|1 /0|
| Worst Fmax MHz |157.95|117.74|
| Worst setup ns at6.5ns |+0.169|-1.993|
| Worst hold ns |+0.155|+0.118|
| A continuous single-job cycles |302-304|270|
| Secret continuous single-job cycles |285-320|268|
| Mask continuous single-job cycles |270|269|
| Challenge continuous single-job cycles |902-969|902-969|

Full-word extraction is proven:continuous performance peaks are6 matrix
candidates,32 secret candidates and7-8 mask fields;16 processed bytes/token.
First-to-last output bubbles fall from33-35 to2 for A and16-51 to0 for secret;
mask remains at1. Throughput remains capped by one coefficient/clock.
Input-block overlays overlap output transfer and are not extra latency totals.

The trial costs4032 extra needed ALMs(+97.89%) and2521 registers(+58.14%).
It fails the required150+MHz objective and6.5ns setup. Its153.85MHz projected
rates are not timing-qualified and must not be reported as achieved throughput.
Worst Slow0 path is decode_secret_count_r[0][0] -> packed_secret_r[10][3],
8.208ns data delay with-1.993ns slack. The native secret merge needs another
register boundary. Wide collector writes/read muxes also increased area;the
next implementation should retain full-word extraction while decoupling it
from narrower ordered collector commits,instead of doubling wide storage.

471 main UVM successes/54 errors/75 aborts/121098 values,Python104/19456,
C48/12288,checker12,performance96 and five zero-credit fault gates pass.
Archive/checkpoint:STAGE4_8A_RESULTS.json,evidence/stage4_8a.zip.
Reproduce the96-row comparison with `python sim/sampler/native128_compare.py`.
It reads immutable4.7s/4.8a archives by default;`--live` reads the working CSV.
The4.8a checkpoint also embeds the original comparison.

Restoration4.8b reruns the exact4.7s RTL/UVM/build scripts. Fresh fitting
reproduces4119 needed/4224 placed ALMs,4336 registers,5038 ALUTs,157.95MHz,
setup+0.169ns/hold+0.155ns at6.5ns;all four corners zero setup/hold TNS.
All96 performance rows are byte-identical to4.7s. Main409/105356,Python19456,
C48/12288,checker12 and five zero-credit fault gates pass. Native128 remains
archived rather than active. See STAGE4_8B_RESULTS.json.

## Retained Stage4.7s - frequency target achieved;acceptance pending

The user now requires150+MHz;the permanent constraint is6.500ns=153.85MHz.
Fresh S closes the unchanged6.500ns=153.85MHz constraint in all four corners.
Worst Fmax157.95MHz,setup+0.169ns,hold+0.155ns.4119 needed ALMs,4224 placed,
4336 fitted registers(4243 implementation+93 router),5038 ALUTs,one M10K/
1024 logical bits,zero DSP. Both the150+MHz objective and6.5ns closure pass.
Evidence:STAGE4_7S_RESULTS.json;output_files/sampler.fit.rpt and sampler.sta.rpt
in quartus/sampler/. Fresh payload/credit/prefetch/sign register guards pass.
User acceptance remains pending inStage4;no new functional netlist simulation.

| Metric | Archived4.6r | Retained4.7s |
|---|---:|---:|
| Constraint MHz |100|153.85|
| Needed ALMs |3487|4119|
| Final-placement ALMs |3562|4224|
| Registers |2445|4336|
| Combinational ALUTs |4588|5038|
| Worst Fmax MHz |109.54|157.95|
| Worst setup ns at declared clock |+0.871|+0.169|
| Worst hold ns across four corners |+0.147|+0.155|
| M10K / logical bits |1/1024|1/1024|
| DSP |0|0|

These are distinct fitted points with different declared clocks. S needs632
more ALMs and1891 more registers than4.6r;its measured worst Fmax is48.41MHz
higher. The extra registers and credit prediction add latency,so frequency
alone is not the throughput comparison.

Single-job continuous-input latency is last accepted output cycle minus
descriptor acceptance cycle. Source TB runs at100MHz for functional checks;
the following153.85MHz rates are calculated from measured cycles and are
qualified by S's positive fitted internal timing. Rate=256*clock_MHz/cycles.

| Mode |4.6r cycles|S cycles|S latency at153.85MHz us|S Mcoeff/s |
|---|---:|---:|---:|---:|
| Matrix A |262|302-304|1.963-1.976|129.555-130.413|
| Secret |262-273|285-320|1.853-2.080|123.077-138.192|
| Mask |262|270|1.755|145.869|
| Challenge |899-966|902-969|5.863-6.299|40.645-43.664|

These are sampler-only workloads,not whole ML-DSA or Keccak/sampler/NTT rates.
All96 rows,including stalled and paired-context jobs,remain in performance.csv
and the checkpoint. R and S are byte-identical to Q's96 measured rows.
The100MHz results below describe earlier RTL.

4.7o retains the registered challenge issued-read address and conservative
room decision,with an outstanding-read ownership assertion. Non-challenge
input length stays stationary;the half selector selects remaining bytes.
All96 performance polynomials pass. Continuous single-job cycles are302-304
for matrix,285-320 for secret,270 for mask,and902-969 for challenge.
The4.7n room guard cost63 cycles;4.7o removes that penalty with a registered
threshold24 and a27<32 bound. Frequency and elapsed-time benefit must be
evaluated together. User acceptance remains pending inStage4.
4.7p registers capacity before issue;its conservative credit return costs4-11
cycles in the continuous secret cases versus4.7o. Other continuous single-job
ranges are unchanged. This tradeoff is recorded across all96 measured rows.
4.7q registers incoming reservation amounts and collector-pop credits before
the counter adder. Conservatively including those delayed credits adds another
5-12 cycles in the continuous secret cases;all other ranges remain unchanged.
R's prefetched challenge byte and fixed-context sign writes preserve all96
Q performance rows byte-for-byte:SHA256
21c86ec78e842ce742f8216d2350a9bce337e9d81eb27e79a52ee2557906b53b.

**Synthesis correction:** 4.6a-4.6c hardware improvement claims are withdrawn.
Their source simulations passed, but Quartus dropped the secret-data register
writes and removed all64 packed secret payload bits as constant. Those fits
are archived evidence of a defect, not valid hardware baselines.
The4.6a-c source checks remain recorded, but their low area/high Fmax figures
must not be used for a correct-sampler comparison. Their immutable archives
are preserved; sim/sampler/secret_payload_review.json records the64 constant
packed bits removed in each. Valid3.3k/Stage5 had neither warning nor removal.

## Archived Stage4.6r - 2026-10-18;100MHz baseline

Latest exact revalidation of this baseline:4.6z after both trials below.
These historical sources/reports are archived;active RTL is described above.

| Metric | Selected4.6r | Rejected4.6x | Rejected4.6y |
|---|---:|---:|---:|
| ALMs needed |3487|3492|3494|
| Final-placement ALMs |3562|3557|3569|
| Fitted registers |2445|2443|2430|
| Combinational ALUTs |4588|4599|4576|
| Slow85 Fmax MHz |109.54|105.88|108.18|
| Slow0 Fmax MHz |110.40|104.50|106.13|
| Worst Fmax MHz |109.54|104.50|106.13|
| Worst setup ns at100MHz |+0.871|+0.431|+0.578|
| Worst hold ns |+0.147|+0.144|+0.147|

All have one M10K/1024 logical bits,zero DSP and byte-identical96 performance
records.4.6y bypasses mode selection at the secret compactor inputs;its group
results remain ignored unless the existing operation/valid tags own their use.
It removes the redundant64-bit candidate_secret signal without adding registers
or cycles. Independent correctness checks pass,but whole-design timing loses
3.41MHz/setup0.293ns and needs7 more ALMs. The worst Slow0 path is generated ->
packed_count,9.238ns. Both original64-bit secret banks survive fitting,with2/27
router copies. These gains in logic simplicity do not improve the selected fit.
Power was not measured. STAGE4_6Y_RESULTS.json preserves the trial;4.6z refreshes
exact4.6r. Next bounded review:split secret rotation around the existing packed
register,with explicit tail-forwarding/ownership/capacity analysis first.

**4.6x matrix-carry snapshot trial rejected.** This separate trial starts from
exact4.6r,captures16 carry bits plus a2-bit byte count on accepted input,and
updates that working copy only on a matrix chunk transfer. Candidate assembly
uses the working copy instead of the selected context's carry. The ownership
invariant and independent checks pass;TimeQuest confirms all18 original working
bits survive fitting. No stage/cycle is added. Nevertheless,whole-design timing
is worse:3492 needed ALMs,3557 final-placement ALMs,2443 registers,4599 ALUTs,
105.88/104.50MHz Slow85/Slow0 Fmax,+0.431ns worst setup,+0.144ns worst hold.
One M10K/1024 logical bits,zero DSP;all96 performance rows equal4.6r. The new
worst Slow85 path is hold_upper -> mask_residual,9.204ns. This costs5 ALMs and
5.04MHz versus4.6r. Archived in STAGE4_6X_RESULTS.json/evidence/stage4_6x.zip;
snapshot/assertion/probe removed before the separate4.6y secret-path trial.

Previous exact revalidation:4.6w. The held-beat eta snapshot trial4.6v is rejected:

| Metric | Retained4.6r | Rejected4.6v |
|---|---:|---:|
| ALMs needed |3487|3510|
| Final placement ALMs |3562|3615|
| Fitted registers |2445|2435|
| Combinational ALUTs |4588|4650|
| Slow85 Fmax MHz |109.54|103.15|
| Slow0 Fmax MHz |110.40|102.27|
| Worst Fmax MHz |109.54|102.27|
| Worst setup ns at100 MHz |+0.871|+0.222|
| Worst hold ns |+0.147|+0.145|

Both use one M10K/1024 logical bits,zero DSP and identical96 performance rows.
4.6v captures one eta4 bit at valid-sized beat acceptance;four secret decoders
use that snapshot across both halves. Its ownership invariant passes and one
original snapshot register survives fitting. Both original64-bit secret banks
survive with1 decode/29 packed router copies. The new worst path is matrix carry
control residual_count_r[1][1] -> decode_secret_r[0][3],9.575ns atSlow0.
Whole-design timing worsens7.27MHz/setup0.649ns despite reducing parameter
selection before the secret lanes. No new stage,cycle or throughput gain.
All391 complete/54 errors/33 aborts/100733 checks,Python104/19456,C48/12288,
checker12 and five fault gates pass.4.6v is archived before removal;4.6w refreshes
the restored4.6r reports. See STAGE4_6V/W_RESULTS.json. Next:review matrix
byte-carry/context selection and collector paths withinStage4.

Revalidated as4.6u after the following collector-path experiments. Both are
valid source/timing measurements at100 MHz,but neither is selected:

| Metric | Retained4.6r | Area alternative4.6s | Rejected4.6t |
|---|---:|---:|---:|
| ALMs needed |3487|3467|3479|
| Final placement ALMs |3562|3558|3630|
| Fitted registers |2445|2433|2474|
| Combinational ALUTs |4588|4557|4385|
| Slow85 Fmax MHz |109.54|107.26|105.86|
| Slow0 Fmax MHz |110.40|106.42|104.61|
| Worst Fmax MHz |109.54|106.42|104.61|
| Worst setup ns at100 MHz |+0.871|+0.603|+0.441|
| Worst hold ns |+0.147|+0.146|+0.137|

All retain one M10K/1024 logical bits,zero DSP and every one of the96 performance
rows. The20/8 needed-ALM savings cost3.12/4.93MHz and0.268/0.430ns worst setup.
Timing remains the selection priority;4.6r stays active. No additional RTL gain
is retained from these trials. The fresh4.6u build uses exact4.6r source/scripts.

4.6s simplifies the fixed-q secret formatter after the narrow rotation. Its
Boolean mapping equals the original for all16 binary nibble encodings;the
offline algebra check earns no RTL coverage credit. Its new worst path is
hold_upper -> mask_residual,9.168ns atSlow0.4.6t starts from4.6r,predecodes the
wide alignment address before the packed boundary,and checks the one-hot value
against the owning packed base on every valid commit. TimeQuest confirms16
original address registers. Its new worst paths are hold_core/hold_upper ->
decode_secret at9.129/9.171ns atSlow85. Reducing one path did not improve the
whole design. Neither trial widens the datapath or adds a stage/cycle.

Each passes391 complete/54 errors/33 aborts/100733 coefficient checks,Python104/
19456,C48/12288,checker12 and all five zero-credit fault gates. Source/reference/
report snapshots are in STAGE4_6S/T_RESULTS.json and their immutable archives.
STAGE4_6U_RESULTS.json preserves fresh selected4.6r revalidation. Next:review
held-beat parameter/mode selection before the first-stage decoder,withinStage4.

Only sampler.sv changes from preserved4.6e:the packed payload bank captures
every clock,including invalid cycles. packed_valid still controls every use;
reset/error cancellation,ownership and both pipeline stages are unchanged.
The original early clipping placement is retained. The independent references,
testbench,launchers,QSF/SDC,device,seed and100 MHz clock are unchanged.

| Metric | Preserved4.6e | Selected4.6r | Rejected4.6p | Rejected4.6q |
|---|---:|---:|---:|---:|
| ALMs needed |3482|3487|3511|3554|
| Final placement ALMs |3571|3562|3636|3661|
| Fitted registers |2412|2445|2398|2400|
| Combinational ALUTs |4591|4588|4618|4676|
| Slow85 Fmax MHz |108.97|109.54|90.29|100.63|
| Slow0 Fmax MHz |107.67|110.40|89.38|102.44|
| Worst Fmax MHz |107.67|109.54|89.38|100.63|
| Worst setup ns at100 MHz |+0.712|+0.871|-1.188|+0.063|
| Worst hold ns |+0.142|+0.147|+0.141|+0.143|

All use one M10K/1024 logical bits and zero DSP.4.6r gains1.87MHz(1.74%) and
0.159ns worst setup for5 extra needed ALMs(0.14%). Needed ALMs and final placement
are distinct fitter metrics. Its2445 registers comprise2390 implementation and55
router registers;4.6e had2392+20=2412. RTL adds no register declaration or stage.
Both original64-bit secret banks survive fitting. There are1 decode/28 packed
router copies;the payload guard counts originals separately and passes unchanged.

Each source variant passes391 complete polynomials/54 expected errors/33 aborts/
100733 coefficient comparisons,Python104/19456,C48/12288,checker12 and five
zero-credit fault gates. Every one of the96 performance rows equals4.6e.
Continuous single cycles remain A/mask262,secret262-273,challenge899-966.
Pair spans remain520,520-521,1795-1924 respectively. At100 MHz the same pair
throughput remains98.46,98.27-98.46 and26.61-28.52 Mcoeff/s. No higher operating
clock,measured hardware throughput,power or new netlist functional signoff is claimed.

4.6p moves clipping to commit and creates generated -> clipped add-back ->
exhaustion -> next payload enable,10.946ns atSlow0.4.6q removes the add-back with
the equivalent raw<remaining check(4369 legal cases);its new critical path is
packed_core -> mask carry control,9.708ns atSlow85. Both lose to4.6e and are
archived.4.6r restores early clipping,then removes the wide payload enable only.
Its worst setup path is packed_base_r[1] -> collector_r,8.867ns atSlow85 and
8.815ns atSlow0. This motivated the4.6s/t trials above. Next review is held-beat
parameter/mode selection;do not add depth or repeat rejected variants unchanged.

Evidence:STAGE4_6P/Q/R_RESULTS.json with create-only ZIP/SHA256 checkpoints.
The4.6e/4.6o baseline and every prior archive remain unchanged. Acceptance is
pending;native128 deferred;no stage advancement or commit.

## Preserved Stage4.6e;revalidation4.6o

The additional-register experiments were measured and rejected:

| Metric | Selected4.6e | Rejected4.6m | Rejected4.6n |
|---|---:|---:|---:|
| ALMs needed |3482|3494|3519|
| Registers |2412|2594|2600|
| Slow85 Fmax MHz |108.97|98.69|106.13|
| Slow0 / worst Fmax MHz |107.67|96.26|101.95|
| Worst setup ns at100 MHz |+0.712|-0.388|+0.191|
| Worst hold ns |+0.142|+0.126|+0.124|
| Continuous single A/mask cycles |262|263|263|
| Continuous single secret cycles |262-273|267-282|267-282|
| Continuous pair A/mask span |520|521|521|
| Continuous pair secret span |520-521|521-524|521-524|
| Pair A/mask Mcoeff/s at100 MHz |98.46|98.27|98.27|
| Pair secret Mcoeff/s at100 MHz |98.27-98.46|97.71-98.27|97.71-98.27|

All three use one M10K/1024 logical memory bits and zero DSP. Pair throughput
is512 coefficients divided by pair span, multiplied by100 MHz. These are
simulation-derived rates at the declared100 MHz;4.6m fails that clock in hardware.
Challenge continuous cycles remain899-966 single/1795-1924 pair;periodic-stall
phase alignment can change individual rows even without changing challenge RTL.
The trial JSONs record every changed field and relative-cycle delta for all96
rows;no byte-equality claim is made against4.6e.4.6n's96 rows exactly equal4.6m.

4.6m adds a register between compaction and clipping admission. A signed
per-context budget reserves raw candidates before clipping;at most15 surplus
candidates can make it negative. Collector capacity includes all three stages,
and status/reuse waits for all pending work to drain. The fresh fitted netlist
retains64 original secret payload registers in each of the three stages.
The critical path moves to decode_bound -> mask_residual,10.146 ns atSlow0.

4.6n registers the exact next-cycle collector+pending reservation and checks
it against actual stage ownership each simulation clock. This shortens the
carry-enable path but creates count_r -> reserved_capacity_r,9.600 ns atSlow0.
Its improved timing versus4.6m still loses to4.6e,with more area and extra cycles.
Both pass409 complete polynomials,60 errors,45 resets/105340 coefficient checks,
Python104/19456 and five zero-credit fault gates. Neither is selected.

All nine experimental source/testbench/build files are restored byte-for-byte
to4.6e/4.6l. Fresh selected-design evidence is STAGE4_6O_RESULTS.json and
evidence/stage4_6o.zip;4.6M/N JSON/archive/SHA256 records preserve rejected trials.
No pipeline addition or RTL performance gain is retained. Next:review register
placement within the existing two-stage depth. Stage4 acceptance remains pending.

### Prior4.6i/j/k experiments and4.6l revalidation

Three further timing experiments passed the full391-polynomial source suite,
Python comparison and all fault gates but failed the whole-design comparison:

| Metric | Selected4.6e | Rejected4.6i | Rejected4.6j | Rejected4.6k |
|---|---:|---:|---:|---:|
| ALMs needed |3482|3488|3505|3627|
| Registers |2412|2407|2425|2441|
| Worst Fmax MHz |107.67|102.36|103.51|106.16|
| Worst setup ns at100 MHz |+0.712|+0.231|+0.339|+0.580|
| Worst hold ns |+0.142|+0.145|+0.145|+0.146|
| Raw source code percent |93.64%|93.66%|93.67%|93.76%|
| Functional bins |914/914|914/914|914/914|914/914|

4.6i moves mask carry state to fixed-context clocked blocks.4.6j instead starts
from4.6e and caches remaining coefficient positions in two9-bit quota counters.
The quota satisfies remaining+committed+pending=256 on every healthy non-challenge
context;the unchanged independent scoreboard also passes.4.6k combines that
quota with two19-bit carry extractors and selects the half after extraction.
It still consumes64-bit chunks;native128 sampling was not implemented.

4.6j removes admission arithmetic from the top paths but exposes mask carry
selection at9.393 ns (Slow85).4.6k moves the top path to matrix byte carry
write control:generated_r[0][2] -> residual_r[1],9.113 ns atSlow0. Its extra145
ALMs do not yield a higher whole-design Fmax. Source coverage differences come
from changed control/port/net structure;test sequences and functional bins are
unchanged. All96 performance records are identical. No RTL gain is retained.

Every source/build-script hash is restored to4.6h's selected4.6e baseline.
STAGE4_6L_RESULTS.json/evidence/stage4_6l.zip preserve fresh revalidation after
restoration.4.6I/J/K result JSON and archive/SHA256 pairs preserve each rejected
trial;checkpoint writes are create-only and refuse existing filenames.

Next:an additional register-boundary experiment withinStage4,with explicit
latency/reservation/reset-drain verification and a fresh area/timing comparison.
This is planned work;user acceptance/native128/integration gates are unchanged.

### Prior4.6f/4.6g rejection and4.6h revalidation

Admission experiments4.6f/4.6g passed source correctness but worsened timing;
both are rejected. All sampler RTL has been restored byte-for-byte to4.6e.
STAGE4_6H_RESULTS.json/evidence/stage4_6h.zip record the new source validation
and fresh fit after restoration. The retained change is diagnostic only:
report_paths.tcl checks64 original payload registers per secret stage,excluding
legitimate~DUPLICATE router copies from that count. Missing original bits still
fail the guard. This correction does not improve RTL area,Fmax or throughput.

| Metric | Selected4.6e | Rejected4.6f | Rejected4.6g |
|---|---:|---:|---:|
| ALMs needed |3482|3487|3496|
| Registers |2412|2400|2401|
| Slow85 Fmax MHz |108.97|102.76|104.00|
| Slow0 Fmax MHz |107.67|103.95|102.05|
| Worst Fmax MHz |107.67|102.76|102.05|
| Worst setup ns at100 MHz |+0.712|+0.269|+0.201|
| Worst hold ns |+0.142|+0.146|+0.147|
| Main raw code coverage |93.64%|93.68%|93.68%|
| Functional bins |914/914|914/914|914/914|

4.6f computed full-width remaining allowance/minimum per context before
selection.4.6g used6-bit arithmetic only for the final32 positions,with a
direct-width assertion during UVM and71961 legal arithmetic cases passing.
Neither reduces cycles. Their mapped critical paths move to mask carry write
controls:hold_upper_r -> mask_residual_r (9.465 ns atSlow85) in4.6f;
decode_core_r -> mask_residual_r sync clear (9.513 ns atSlow0) in4.6g.
Higher source code coverage does not compensate for the measured timing loss.
Archive hashes/reports/source are retained in STAGE4_6F_RESULTS.json and
STAGE4_6G_RESULTS.json with selected_candidate=false.

Next bounded experiment:inspect fixed-context mask carry write/reset controls
and their coupling to reservation/error signals;remeasure after any change.
Do not repeat the rejected admission rewrites unchanged. Stay in Stage4.

### Selected4.6e improvement retained from the previous iteration

| Metric | Preserved corrected4.6d | Fresh4.6e |
|---|---:|---:|
| Clock constraint MHz |100|100|
| ALMs needed |3487|3482|
| ALMs in final placement |3562|3571|
| Logic ALUTs |4589|4591|
| Registers |2395|2412|
| M10K /logical bits /DSP |1 /1024 /0|1 /1024 /0|
| Slow85 Fmax MHz |104.68|108.97|
| Slow0 Fmax MHz |103.62|107.67|
| Worst Fmax MHz |103.62|107.67|
| Worst setup ns |+0.349|+0.712|
| Worst hold ns |+0.145|+0.142|
| Setup/hold TNS ns |0|0|
| Functional bins |914/914|914/914|
| Raw code bins |8175/8731|8200/8757|
| Raw code percent |93.63%|93.64%|

Calculate collector+decode+packed reservation counts independently for each
fixed context. Compare with32-minus-worst-chunk-bound (secret16,matrix29,
mask28),then select the held context's capacity bit. This removes hold_core
selection from the reservation adders without changing admission decisions,
buffer depth,external ports or cycles. Main UVM checks actual RTL;152592
offline cases separately validate the threshold arithmetic (not coverage credit).

Worst Fmax improves4.05/103.62=3.91%;setup improves0.363 ns. ALMs needed fall5
but final-placement ALMs rise9 and ALUTs rise2;report each measure separately.
The fitter lists20 duplicated register rows versus3 in4.6d,accounting for the
17 additional registers. No pipeline stage was added. Hold falls0.003 ns but
stays positive. Same device/tool/seed/100 MHz SDC;fresh compile0 errors/5 warnings.
Both64-bit secret payload register guards pass;no undriven/constant payload loss.

All four internal corners pass setup/hold with zero TNS. Setup ns:Slow85+0.823,
Slow0+0.712,Fast85+5.297,Fast0+5.864. Hold ns:Slow85+0.348,Slow0+0.340,
Fast85+0.158,Fast0+0.142. Worst minimum pulse-width slack+3.343 ns.
The worst path moves to decode_core_r -> remaining/admit_count -> packed_count_r
atSlow0 (9.049 ns). Slow85 shows hold_bytes_r[2] -> matrix residual_r[1][11]
(8.942 ns). Inspect admission arithmetic next within Stage4. Physical I/O stays
excluded;this is internal timing,not board signoff.

All96 performance rows match4.6d byte-for-byte. At100 MHz single latency remains
262 cycles A/mask,262-273 secret,899-966 challenge;aggregate paired throughput
remains98.46 Mcoeff/s A/mask,98.27-98.46 secret,26.61-28.52 challenge. No throughput
gain is claimed at the unchanged operating clock. Estimated Fmax is a separate metric.

Main UVM391 complete/54 expected errors/33 aborts/100733 coefficient checks;
Python104/19456,C48/12288,checker12/12,performance96 and five fault gates pass.
Functional914/914 defined bins,code8200/8757=93.64%;no exclusions or merged total.
Evidence:STAGE4_6E_RESULTS.json/evidence/stage4_6e.zip and SHA256 sidecar.
4.6d remains preserved;4.6a-c fitted claims remain withdrawn. Acceptance pending;
native128 deferred;no new netlist run,GUI review,stage advancement or commit.

## Preserved corrected Stage4.6d - 2026-10-18

| Metric | Valid3.3k/Stage5 | Corrected4.6d |
|---|---:|---:|
| Clock constraint MHz |100|100|
| ALMs needed |3543|3487|
| ALMs in final placement |3667|3562|
| Logic ALUTs |4740|4589|
| Registers |2388|2395|
| M10K /logical bits /DSP |1 /1024 /0|1 /1024 /0|
| Slow85 Fmax MHz |102.52|104.68|
| Slow0 Fmax MHz |100.33|103.62|
| Worst Fmax MHz |100.33|103.62|
| Worst setup ns |+0.033|+0.349|
| Worst hold ns |+0.144|+0.145|
| Setup/hold TNS ns |0|0|
| Functional bins |914/914|914/914|
| Raw source code bins |7749/8267|8175/8731|
| Raw source code percent |93.73%|93.63%|

Corrected4.6d retains local secret compaction and prepares both mask carry
shifts when accepting the128-bit beat. It replaces the decode_secret_r loop
of partial writes with one complete packed assignment, preserving nibble order.
Quartus no longer warns that decode_secret_r is undriven; no packed_secret_r
bit is removed as constant. report_paths.tcl confirms64 decode +64 packed
registers and fails on a changed count. This structural guard addresses the
observed loss; eventual functional netlist tests remain required after acceptance.

Against the valid baseline:56/3543=1.58% fewer ALMs,3.29/100.33=3.28% higher
worst Fmax,setup improvement0.316 ns,7 additional registers. This is a modest
combined improvement. An isolated timing benefit from mask retiming is not
established by comparison with the invalid4.6a-c fits. Same device/tool/seed/
100 MHz SDC; fresh compile0 errors/5 warnings. All four internal setup/hold
corners pass with zero TNS; physical I/O paths remain excluded,not board signoff.

Current slow paths remain mask feedback: mask_carry_shift_r[1][4] ->
mask_residual_r[1][4],9.279 ns atSlow85; hold_core_r ->mask_residual_r[0],
9.413 ns atSlow0. Inspect shift/context selection next within Stage4.

All96 performance rows match3.3k byte-for-byte. At100 MHz single latencies
remain262 cycles A/mask,262-273 secret,899-966 challenge. Pair spans520 A/mask,
520-521 secret,1795-1924 challenge. Aggregate512/span*100 MHz gives98.46 Mcoeff/s
A/mask,98.27-98.46 secret,26.61-28.52 challenge. No throughput gain at the
unchanged clock; estimated Fmax is not an operating-clock approval.

Main UVM: 391 complete polynomials, 54 expected errors, 33 reset aborts,
100733 coefficient checks. Functional 914/914 defined bins; raw DUT code
8175/8731 = 93.63%. Python104/19456, C48/12288, checker12/12, performance96
and five coverage fault gates pass. All96 performance rows remain unchanged.
Raw code bins change with hierarchy/logic; no exclusions or merged runs.
Evidence:STAGE4_6D_RESULTS.json/evidence/stage4_6d.zip and SHA256 sidecar.
Acceptance pending; native128 deferred; no stage advancement or commit.

**Historical4.6a sections below: source tests are retained; hardware improvement
claims are WITHDRAWN due to the synthesis loss described above.**

## Invalidated Stage4.6a fitted comparison - 2026-10-18;source history only

| Metric | Preserved3.3k/Stage5 baseline | Fresh4.6a |
|---|---:|---:|
| Constraint |100 MHz /10 ns|100 MHz /10 ns|
| ALMs needed |3543|2901|
| ALMs in final placement |3667|3085|
| Logic ALUTs |4740|3466|
| Registers |2388|2258|
| M10K /logical bits /DSP |1 /1024 /0|1 /1024 /0|
| Slow85 Fmax MHz |102.52|102.27|
| Slow0 Fmax MHz |100.33|103.24|
| Worst Fmax MHz |100.33|102.27|
| Worst setup ns |+0.033|+0.222|
| Worst hold ns |+0.144|+0.145|
| Setup/hold TNS |0|0|
| Functional bins |914/914|914/914|
| Source code bins |7749/8267=93.73%|8087/8637=93.63%|

ALMs fall642/3543=18.12%;worst Fmax rises1.94/100.33=1.93%. Slow85 itself
falls slightly;both slow corners are shown. Local four-nibble packing now
precedes the existing candidate register;registered dense groups/counts merge
as two pairs then one final pair. No extra clock,port or sampling-formula change.
Old critical decode_mask_r->packed_secret_r data path9.721 ns is replaced by
hold_upper_r->mask_residual_r at9.559 ns;mask carry extraction is next target.

All96 performance.csv rows are byte-identical to baseline. At100 MHz:A/mask262
single cycles,secret262-273,challenge899-966. Two-job spans520 A/mask,520-521
secret,1795-1924 challenge. Aggregate98.46 Mcoeff/s A/mask,98.27-98.46 secret,
26.61-28.52 challenge remain unchanged. No throughput gain at the same clock
is claimed. Higher operating-clock closure needs a separate measured constraint
pass;reported Fmax is not an approval to change the operating clock.

391 complete polynomials/100733 checks=391*256+637 partial comparisons,54
expected errors,33 reset aborts pass.42 added secret jobs check1282 patterns:
625 count tuples and16 local masks per eta. Python104/19456,C48/12288,checker
12/12,performance96 polynomials and5 injected-fault gates pass. Source code
denominator changes from9 to12 DUT instances;no exclusions or hidden misses.

Evidence:STAGE4_6A_RESULTS.json,evidence/stage4_6a.zip and SHA256 sidecar.
Stage5 netlists apply only to their old source identity;launchers now reject
the changed candidate rather than silently simulating old logic. No new netlist
run,stage advancement,commit or branch change. Physical I/O timing stays excluded.

## Historical3.3k/Stage5 baseline and earlier measurements

Date: 2026-10-16. **Stage3.3k current: functional checks pass; standalone internal timing passes at 100 MHz.**
3543 ALMs, 2388 registers, one M10K, 100.33 MHz worst Fmax, setup +0.033 ns and hold +0.144 ns at 100 MHz.
Sections1-8 describe the original Stage3 baseline, section10 records3.1/3.2,
section11 records3.3g, and section12 records current source/results. Historical hashes apply to their
archived snapshots, not current RTL.
Stage4.5 changes UVM/coverage only:349 complete regression polynomials,
89981 coefficient checks; all96 performance CSV records match3.3k. RTL/fitter/
constraint hashes match the saved fit, so its metrics below are retained rather
than described as a new synthesis run. Stage5 revalidates these source results
and both distinct functional netlists (184 jobs/39936 checks each;104-job Python
captures match). No new cycle/Fmax/area gain is claimed. See COVERAGE.md/STAGE5_RESULTS.json.

## 1. Tested configuration and changes

- Four-mode top: src/sampler/sampler.sv, shared 128-to-64 input adapter, two
  job contexts, four 16-bit secret lanes, grouped collectors, mask unpacker,
  sequential challenge engine and one tagged 23-bit output coefficient/cycle.
- Cyclone V 5CGXFC7C7F23C8, Quartus Prime Lite25.1std.0 build1129, seed1,
  standard fit, 0..85 C, 1.1 V timing corners. Approved baseline target100 MHz.
- Main UVM in Questa2024.1, 10 ns simulation clock, seed20261016.
- Quartus required explicit generate/endgenerate around the secret-lane
  instances; this syntax-only RTL compatibility change preserves their behavior.
- Added source-only UVM timing probes and continuous-beat/stalled source profiles.
  The scoreboard's challenge-array initialization now explicitly clears only
  the selected context, avoiding foreach loop-index shadowing. SV oracle formulas
  and the existing C reference remain independent and unchanged.
- No datapath optimization, architecture replacement or source timing exception
  was added to hide the measured failure. Existing caches are excluded from
  compact baseline evidence.

## 2. Source correctness gates

| Gate | Result |
|---|---|
| Original main-UVM regression | 47 complete polynomials, 18 expected errors, seven reset aborts; 12704 checked coefficients |
| Independent vector capture/Python equality | 104/104 jobs; 19456/19456 coefficients; 76 complete, 24 expected errors, four aborts |
| Independent Python/C seeded equality | 48 seed cases / 12288 coefficients |
| Offline compare checker self-test | 12/12 corruptions rejected |
| Main-UVM performance run | 96 complete polynomials / 24576 coefficients; 72 scenarios |
| Unexpected UVM errors/fatals | Zero in all three source tests |

Raw code coverage is separate per run: smoke4885/5558=87.89%,
vector4883/5558=87.86%, performance4820/5558=86.72%. No merged figure or complete
functional coverage claim. The small checked-polynomial group is not the detailed
Stage 4 coverage model. No netlist or board test has been run.

## 3. How cycles are measured

sampler_performance_test uses the same environment, monitor and independent
scoreboard. It selects the first complete seed-derived stream for each
mode/parameter/core from the prepared input file. It tests each mode/parameter
with one job on core0, one on core1, and a pair, under two profiles:

1. Continuous: source offers the next up-to-16-byte beat immediately after an
   accepted beat, while output/status ready stay high.
2. Controlled stalls: input inserts two idle clocks after every five packets;
   output ready is high on cycle%13>=4 and status ready on cycle%17>=5.

This gives 4*3*2*3=72 scenarios, containing 96 polynomials. Paired beats alternate
cores while both have input bytes. No real Keccak or NTT is present; this is a
modeled byte producer and output consumer. Its traffic is not a complete SHAKE
or Dilithium system throughput measurement.

Definitions in sim/sampler/performance.csv:

- Start: accepted descriptor. End: accepted output index255.
- latency_cycles = last_output_cycle - start_cycle, excluding the descriptor
  edge, including every subsequent clock through the last output edge.
- input_to_first_cycles = first_output_cycle - first_input_cycle.
- Pair span: later last-output minus earlier descriptor acceptance for that pair.
  Pair aggregate rate = 512/pair_span coefficients/clock. This is a batch rate,
  not a steady-state initiation interval. Status acknowledgement is recorded
  separately and excluded from these latency windows.
- accepted input bytes, actual extractor/engine processed bytes, examined
  candidates, committed accepted candidates and generated/output coefficients
  are separate counts. Secret final-byte surplus can include discarded nibble
  candidates; committed/candidates is not an unconditional distribution estimate.
  For challenge, accepted candidates means tau accepted positions, not256 outputs.
- Peak candidate/generation/processed-byte counts are actual maximum per-clock
  observations, not all-cycle rates. Average rates divide counts by latency.
- Raw input/output stalls, clear, shuffle writes and RAM-readout clocks can
  overlap. They must not be added to claim a total latency.
- The exclusive_* columns form a priority partition: output stall, input blocked,
  output transfer, clear, shuffle write, readout, source gap, other. Each clock
  enters one bucket. The UVM checks their sum equals latency for every row.
  A bucket is a primary label, not the number of all simultaneously active
  operations; raw overlays show those. Source-gap here means no global input
  valid before this context stops, not a measured SHAKE wait.

Rows are written only after scoreboard.checked_ap confirms the full exact
polynomial and successful status. Raw tick probes cannot credit coverage or
publish an unchecked successful timing row. Probes are source-hierarchy-specific
and must be adapted before any later netlist measurement.

## 4. Measured cycle counts

Single columns show the range over the two distinct core/seed streams.
All entries are clock counts; these are not timing-closed microsecond results.

| Mode | Parameter | Single continuous | Single stalled | Pair span continuous | Pair span stalled |
|---|---|---:|---:|---:|---:|
| A | 44 | 260 | 375-376 | 518 | 746 |
| A | 65 | 260 | 372-375 | 518 | 746 |
| A | 87 | 260 | 372-374 | 518 | 746 |
| Secret | 44 | 260 | 372 | 518 | 746 |
| Secret | 65 | 260 | 372-374 | 518 | 746 |
| Secret | 87 | 260 | 372-373 | 518 | 746 |
| Mask | 44 | 260 | 372 | 518 | 746 |
| Mask | 65 | 260 | 372-373 | 518 | 746 |
| Mask | 87 | 260 | 372 | 518 | 746 |
| Challenge | 44 | 899-900 | 945-947 | 1795 | 1829 |
| Challenge | 65 | 932-934 | 974-977 | 1862 | 1902 |
| Challenge | 87 | 962-966 | 1006-1009 | 1924 | 1964 |

A/secret/mask single rate: 256/260=0.9846 coefficients/clock. Paired continuous
aggregate: 512/518=0.9884 coefficients/clock; stalled pair512/746=0.6863.
Their 23-bit serializer is already the end-to-end throughput limit in these
continuous scenarios, despite different internal candidate widths. Two contexts
preserve/interleave jobs; they do not create a second output coefficient port.

For challenge, each job clears256 entries, performs2*tau ordered writes
(78/98/120 clocks), then performs256 readout states. Request/return scheduling
and stalls also cost clocks; these raw state totals overlap other activity.
They do not alone sum to the measured latency.

Representative continuous single/core0 parameter44:

| Mode | Input/processed bytes | Candidates / committed | Generated/output | First-input to first-output | Peak candidates/generated/bytes per clock | Max collector |
|---|---:|---:|---:|---:|---:|---:|
| A | 771 / 771 | 257 / 256 | 256 / 256 | 3 | 3 / 3 / 8 | 6 |
| Secret | 139 / 139 | 278 / 256 | 256 / 256 | 3 | 16 / 16 / 8 | 31 |
| Mask | 576 / 576 | 256 / 256 | 256 / 256 | 3 | 4 / 4 / 8 | 7 |
| Challenge | 49 / 49 | 41 / 39 | 256 / 256 | 391 | 1 / 1 / 1 | 4 |

Example averages over the accepted-job latency window: A input771/260=2.9654
bytes/clock, candidates257/260=0.9885/clock, committed256/260=0.9846/clock.
Secret candidates278/260=1.0692/clock despite a peak16. Challenge's39 accepted
positions and256 output entries are different quantities. Full timestamps,
peak/average inputs, occupancy and cycle accounting are in performance.csv and
performance_summary.json (a frozen extraction of the recorded CSV; regenerate
report/manifests after new measurements). Source stop occurs before all output serialization
finishes and is recorded independently.

## 5. Fresh fitted resources and timing - FAIL

Sources: output_files/sampler.fit.summary/.rpt, sampler.sta.summary/.rpt and
critical_paths/slow_0C_setup.rpt. Compile completed2026-10-16 19:26:06.
The full compilation process succeeds; TimeQuest reports failed requirements.

| Metric | Measured baseline |
|---|---:|
| Target period/frequency | 10.000 ns / 100 MHz |
| Logic utilization, ALMs needed | 10433 / 56480 |
| ALMs in final placement | 10881 (different fitter metric) |
| Combinational ALUTs | 14156 |
| Registers | 3011 |
| M10K / MLAB memory bits / DSP blocks | 0 / 0 / 0 |
| Physical clock input / virtual bits | 1 / 238 |
| Slow85 C Fmax | 17.29 MHz |
| Slow0 C Fmax, worst | 17.15 MHz |
| Worst setup slack, Slow0 C | -48.304 ns |
| Worst setup endpoint TNS | -77359.334 ns |
| Worst hold slack, Fast0 C | +0.146 ns |
| Hold TNS | 0 ns |
| Worst minimum pulse-width slack | +4.086 ns |
| Pulse-width TNS | 0 ns |
| Reported unconstrained setup/hold paths | 0 under the stated exceptions |

The target remains100 MHz. It was not lowered to hide the failure. The 10 ns
simulation clock checks logical sequencing, not whether this fitted hardware can
operate at100 MHz. No MB/s or microsecond performance at100 MHz is claimed.
Fmax is a reported estimate, not a newly approved operating frequency.

The SDC excludes data-input/output paths for standalone internal-core analysis.
It does not exempt internal register/memory paths. Board I/O timing is unverified.
Recovery/removal are N/A for this synchronous-reset core. Quartus reports the
missing exact placement for clk (automatic fit placement) and the Lite LogicLock
license warning. Three HDL warnings concern an unused observation signal and
signed shift-amount conversion. Four timing warnings correspond to failed setup
at all analyzed corners. None of the timing failures is waived.

## 6. What the reports show needs fixing

### A. Long serial count/compaction path

Worst setup path: active_r[0] -> hold_data_r[66], also [74]/[98]. The Slow0 C
report shows57.914 ns data delay and35 logic levels, repeatedly traversing
`generated_n`, Add* carry chains, `count_n`, the final count test and holding-register
control. This matches the source's dependent per-candidate generated/count updates
in the unrolled secret append loop. The repeated dynamic collector writes also
create a large selection network. These are implementation bottlenecks, not proof
that the published four-lane sampling structure is inherently slow.

Fitter hierarchy estimates (ALMs needed; fractional attribution is the tool's):

| Entity | Local ALMs needed |
|---|---:|
| Top adapter/control/compaction/collectors/serializer | 8447.0 |
| Challenge engine | 1076.3 |
| Mask unpacker | 806.5 |
| Four secret decoders combined | 102.7 |

Thus fixing only the challenge storage cannot resolve most area/timing cost.
The next pass should compute validity/prefix positions and a bounded append count
without serially recomputing the full generated counter for every candidate;
update job counts once and implement collector writes without a cascaded series
of dynamic whole-array updates. Pipeline measured paths where necessary while
preserving stable order, capacity reservation, final truncation and stall behavior.

### B. Challenge memory failed inference

Quartus message276007 states sampler_ball:u_ball|memory is uninferred due to
asynchronous read logic. Although the source captures reads into read_value,
the combined reset/control/read/write structure did not infer a supported RAM.
The intended512x2=1024-bit store instead contributes logic/registers; there are
no physical MLAB or M10K memories. Logic-site names containing MLABCELL in a
path report do not establish RAM inference.

Use a clean inferred memory primitive/interface with explicit address, enable,
write data and registered read return. Keep serial initialization and the copy-
then-sign dependency, including j==i. Confirm actual mapping in a fresh build;
RAM inference must not be claimed from an attribute or source array declaration.

### C. End-to-end scheduling

Once timing/area are repaired, challenge's serial clear/readout cost and the
single output port are candidates for later improvements. A native128-bit input
alone will not remove the measured one-coefficient/cycle output limit for A,
secret and mask in these cases. Actual source/sink integration must be measured
later before changing widths or adding deep FIFOs.

## 7. Comparison with LightHD

Published source: LightHD, Section III.C, Section V, Tables II/III, local PDF at
../../refernce-paper-hw/2026/LightHD_A_Lightweight_and_High-Performance_Hardware_Accelerator_of_CRYSTALS-Dilithium.pdf.

| Item | LightHD publication | Original Stage 3 reconstruction | Comparison limit |
|---|---|---|---|
| Scope | Complete sampling block, all four functions | Complete four-mode sampling plus tagged adapter/status/23-bit serializer | Controller/boundary overhead differs |
| FPGA/tool | Artix-7 XC7A200T, Vivado2020.1 | Cyclone V 5CGXFC7C7F23C8, Quartus25.1 Lite | Different primitives/tool/device |
| Area | 4035 LUTs | 10433 ALMs;14156 combinational ALUTs | ALMs/ALUTs are not equivalent Artix LUT counts; no normalized win claimed |
| Registers | 1157 FFs | 3011 registers | Context/protocol/storage details differ |
| DSPs | 0 | 0 | No modular multiplication datapath in sampler |
| Dedicated RAM blocks | 0 BRAM; distributed RAM used for challenge | 0 M10K and0 MLAB memory; challenge became logic | Zero BRAM is not equivalent memory mapping |
| Source processing | 64-bit words; A2/3/3 candidates, secret four16-bit lanes | Same sampling-width structure behind one128-bit holding register | Adapter also costs cycles/area |
| Source interleaving | Scheduled shared sampler/context swaps | Accepted tags select complete saved state | Required compatibility, not measured novelty |
| Frequency | 212.8 MHz full accelerator; separate sampler Fmax not given | 17.15 MHz standalone sampler estimate | Scope differs; this baseline independently fails its own100 MHz target |
| Per-polynomial cycles | Comparable complete sampler latency not published in reviewed section | Tables above, with explicit boundaries | Do not invent a LightHD sampler cycle count |
| Security timing | Paper states fixed scheduling/secret-dependent constant-time design | Variable acceptance/stalls; no security/constant-time claim | Functional equality is not side-channel verification |

The reviewed text identifies XC7A200T but does not specify the main212.8 MHz
result's complete part/speed-grade here. It separately reports178.6 MHz on a
speed-grade -2 device. Neither is asserted as a standalone sampler frequency.

## 8. Historical Stage 3 decision and next bounded pass

**Reject this baseline as a performance implementation. Retain it as the
immutable functional/reference measurement checkpoint.** Keep the published-width
shared sampler structure and interfaces while correcting the compaction/count/
collector implementation and RAM inference. These are necessary implementation
corrections before claiming a faithful efficient baseline or novel improvements.
A complete architecture replacement is not justified by the current evidence:
the dominant measured problem is the implementation of shared control/storage.

Next is **Stage 3.1 corrective pass**, before full Stage 4 coverage expansion:

1. Preserve this snapshot, restructure count/compaction/collector logic.
2. Run all UVM/vector gates and the same96-polynomial measurement set.
3. Fit again at the unchanged100 MHz target; compare area, all-corner slack,
   Fmax and any extra pipeline clocks against this checkpoint.
4. Correct challenge RAM inference in a separately measured change.
5. Revisit architecture selection using the new evidence, then begin Stage 4.

No area/Fmax improvement or performance acceptance is claimed now. No commit.

## 9. Reproduce

From the repository root, prepare inputs first. From sim/ in Questa Transcript:

```tcl
set SAMPLER_MODE performance
do sampler/run_uvm.do
```

Default `do sampler/run_uvm.do` remains the main smoke regression; vectors use
SAMPLER_MODE=vectors and the same Python prepare/compare flow documented in
FIPS204_SAMPLER.md. Performance has separate CSV/log/UCDB/WLF/code reports.

Quartus GUI: open quartus/sampler/sampler.qpf -> Processing -> Start Compilation.
The permanent SDC already selects the approved100 MHz baseline. From that folder:

```powershell
& 'F:\altera\quartus\bin64\quartus_sh.exe' --flow compile sampler
& 'F:\altera\quartus\bin64\quartus_sta.exe' -t report_paths.tcl
```

STAGE3_RESULTS.json pins sources/settings, raw reports and comparison evidence.
Compact source/results are archived under evidence/stage3_baseline.zip; caches,
SOF files, executables and large waveform/coverage databases are excluded.

## 10. Corrective passes after the rejected baseline

### Stage 3.1 - compaction and collector correction

Saved source/report checkpoint: STAGE3_1_RESULTS.json and
`evidence/stage3_1_compaction.zip` (SHA256 sidecar; archive CRC and all recorded
source/report hashes checked). Full compile ended 2026-10-16 20:01:03.

The unrolled running-count/indexed-write chain was replaced with stable parallel
prefix compaction, one admitted-count calculation, a shared rotation network and
fixed collector writes. All four sampling modes, job contexts, interfaces and
mode grouping widths are retained. This is an implementation correction, not
a source-identical LightHD RTL claim or a new algorithm.

| Metric | Original Stage 3 | Stage 3.1 |
|---|---:|---:|
| Constraint | 100 MHz / 10 ns | 100 MHz / 10 ns |
| ALMs needed | 10433 | 5343 |
| ALMs used in final placement | 10881 | 5435 |
| Combinational ALUTs | 14156 | 7116 |
| Registers | 3011 | 3011 |
| Worst reported Fmax | 17.15 MHz | 45.36 MHz |
| Worst setup slack | -48.304 ns | -12.048 ns |
| Worst hold slack | +0.146 ns | +0.137 ns |
| M10K / MLAB memory bits / DSP | 0 / 0 / 0 | 0 / 0 / 0 |

ALM reduction = (10433-5343)/10433 = 48.79%; Fmax ratio = 45.36/17.15 = 2.64.
Neither result establishes 100 MHz operation. New Slow0 C critical path:
hold_core_r -> collector_r[1][20][1], 13 logic levels, 21.777 ns data delay.
It passes through alignment/candidate checks, prefix counting and append control.
Worst setup TNS is -18233.617 ns at Slow85 C; the worst-slack Slow0 C corner's
TNS is -18107.545 ns. Worst minimum pulse-width slack +4.084 ns. Hold TNS is0.

All correctness gates repeat successfully: smoke47/12704 coefficients;
Python104 jobs/19456 coefficients; C48 seed cases/12288 coefficients;
checker12/12 corruptions; performance96 polynomials/24576 coefficients/72 scenarios.
All96 performance CSV rows match the original baseline exactly; section4's cycle
and activity tables still apply. Zero unexpected UVM errors/fatals. Manifest:
258b35315dc346eda386dd0f73ad7e0c.

Raw DUT code bins, separate databases: smoke8106/8857=91.52%,
vector8184/8857=92.40%, performance8121/8857=91.69%. The new compactor changes
the instrumented scope/denominator (eight DUT instances); the rise is not proof
of increased functional completeness. The small success covergroup remains
separate from the pending full Stage4 model.

Unused input bytes are now FF in main-UVM stimulus. This caught a matrix carry
bug in the first refactor; carry is now masked/zero-extended to its true byte
count. The negative log is archived only as a caught-bug witness and credits no
passing coverage. Independent SV/Python/C sampling formulas were not changed.

### Stage 3.2 - isolated synchronous challenge RAM port

The challenge RAM read/write process is separated from resettable controller
state. One synchronous address/write-data/write-enable port serves serial clear,
copy, sign and readout; its read register has no reset. CLEAR still initializes
each context before use. No uninitialized RAM output is made valid; copy/sign
ordering and j==i behavior are preserved. Read-during-write data is unused.
No forced RAM primitive/attribute or new pipeline clock is introduced.

Full compile finished2026-10-16 20:08:17. Current source/report hashes and
all-corner values: STAGE3_2_RESULTS.json. Saved checkpoint:
`evidence/stage3_2_ram.zip` and its SHA256 sidecar.

| Metric | Stage3.1 | Stage3.2 (current) |
|---|---:|---:|
| Constraint | 100 MHz / 10 ns | 100 MHz / 10 ns |
| ALMs needed | 5343 | 4356 |
| ALMs used in final placement | 5435 | 4527 |
| Combinational ALUTs | 7116 | 6104 |
| Registers | 3011 | 1985 |
| M10K / MLAB / logical stored bits | 0 / 0 / 0 | 1 / 0 / 1024 |
| DSP blocks | 0 | 0 |
| Slow85 C Fmax | 45.70 MHz | 45.13 MHz |
| Slow0 C Fmax, worst | 45.36 MHz | 44.79 MHz |
| Worst setup slack, Slow0 C | -12.048 ns | -12.326 ns |
| Worst setup TNS, across corners | -18233.617 ns | -18250.005 ns |
| Worst hold slack, Fast0 C | +0.137 ns | +0.147 ns |
| Hold TNS | 0 ns | 0 ns |
| Worst minimum pulse-width slack | +4.084 ns | +3.325 ns |

The fitted RAM Summary confirms one M10K at M10K_X26_Y45_N0, common-address
simple dual port, single clock, 512x2 logical entries. The 1024 logical bits
occupy one complete physical M10K, not 0.1 of an available block. AUTO inference
reports MLAB unsuitable for this shape (address too wide). This differs from
LightHD's distributed-RAM mapping and zero dedicated BRAM; no equivalent-memory
claim is made. The fixed shared store still has two256-entry contexts.

The change removes987 ALMs (18.47%) and1026 registers compared with Stage3.1.
Against the original Stage3, ALMs fall58.25%. Fmax falls slightly versus Stage3.1;
this is an area/storage repair, not timing closure. No100 MHz physical throughput
is claimed. The clock constraint and I/O exclusions are unchanged; TimeQuest
reports the internal design fully constrained for setup/hold under those I/O
exceptions. Setup fails at both slow corners and Fast85 C; none is waived.

Main UVM: smoke47 complete/18 expected errors/7 aborts/12704 checked coefficients;
vector104 jobs/19456 coefficients; performance96 polynomials/24576 coefficients,
72 scenarios. All have zero unexpected UVM errors/fatals. Python compare104/104
and19456/19456, C48 cases/12288 coefficients and checker12/12 corruptions pass.
Fresh vector manifest: c535495167bd45948b2aa6354c1c011e. All96 performance CSV
rows match the saved Stage3.1 and original baseline, so section4 still applies.

Raw DUT code coverage (eight local source instances, separate databases):

| Category, hits/bins | Smoke | Vectors | Performance |
|---|---:|---:|---:|
| Statements | 514/517 | 511/517 | 499/517 |
| Branches | 336/340 | 333/340 | 325/340 |
| Conditions | 87/102 | 85/102 | 76/102 |
| Expressions | 70/80 | 69/80 | 58/80 |
| Toggle bins | 7150/7873 | 7236/7873 | 7211/7873 |
| Overall raw code bins | 8157/8912 = 91.53% | 8234/8912 = 92.39% | 8169/8912 = 91.66% |

Overall is summed hits divided by enabled bins; it is not the mean of category
percentages. No FSM model was inferred by Questa, no FSM number is invented,
and no merged or full functional-coverage result is claimed. Changes in source
instrumentation alter denominators. Negative file checker tests credit no coverage.

### Stage3.2 comparison with the publication (historical)

| Item | LightHD | Stage3.2 reference | Limit |
|---|---|---|---|
| Area | 4035 Artix-7 LUTs | 4356 CycloneV ALMs;6104 combinational ALUTs | Different devices/primitives; no direct ALM=LUT comparison |
| Registers | 1157 FFs | 1985 registers | Boundary/context/controller details differ |
| Memory | Distributed RAM;0 BRAM | One M10K;0 MLAB | Different physical mapping |
| DSP | 0 | 0 | Direct count only |
| Frequency | 212.8 MHz full accelerator | 44.79 MHz standalone sampler estimate | No published sampler-only Fmax; our100 MHz target still fails |
| Cycles | Comparable full sampler latency not provided | A/secret/mask260 single; challenge899-966 in measured continuous cases | Explicit standalone measurement boundaries; no whole-ML-DSA claim |

### Recorded next correction after Stage3.2

Fresh Slow0 C critical path remains hold_core_r -> collector_r[1][16][1]
(and bit11),13 logic levels,22.010 ns data delay. Pipeline the measured
extraction/compaction/collector path while explicitly reserving pending capacity,
preserving tags/order, reset cancellation, error-prefix drain and final256-value
truncation. Measure any extra latency or backpressure; do not assume current
cycle counts survive pipelining. Retain both corrected checkpoints, keep100 MHz,
and repeat the same UVM/vector/performance/fit gates before Stage4 expansion.
That checkpoint ended after Stage3.2. Current Stage3.3 results follow below.

## 11. Stage3.3g checkpoint - pipeline, collector and payload correction

Historical candidate3.3g; full compile ended2026-10-16 21:00:05. Same device,
Quartus version,seed1 and100 MHz constraint. Selected current source/reports:
STAGE3_3_RESULTS.json and evidence/stage3_3.zip with SHA256 sidecar. Archive
CRC and source/report/document hashes are checked; no commit.

### Implementation and measured candidate history

- Registered extraction and packed admission before collector commit. Context
  reservations include pending data; polynomial positions cap at256. Reset/error
  cancels pending work, and status waits for owned stages to clear before reuse.
- Whole-word mask alignment/fixed carry slices replace repeated dynamic byte
  writes. Mask conversion occupies the packed stage, bypassing compaction.
- Circular32-entry collectors replace wide shifting on every pop. Head and tail
  advance independently. Original four/16-result output groups remain.
- Occupancy updates once per fixed context for append minus pop.
- Secret candidates remain four-bit signed through16x4 compaction and packed
  storage. A uses a small3x23 compactor. Secret canonical formatting occurs at
  collector write; A/mask wide words select fixed banks directly. There are no
  extra clocks after the first pipeline revision.
- Input lanes, distributions, ordering and external128-bit input/23-bit output
  are retained. Expensive input/control/contexts/collector/output remain shared.
  This is not a second complete sampler or authors' source-identical RTL.

| Revision | ALMs needed | Worst Fmax MHz | Worst setup ns | Observation |
|---|---:|---:|---:|---|
| 3.2 reference |4356|44.79|-12.326|Archived reference|
|3.3a|5496|73.60|-3.587|Pipeline; mask carry becomes critical|
|3.3b|5189|77.89|-2.838|Mask alignment; collector count becomes critical|
|3.3c|4935|88.69|-1.275|Circular collector; mask conversion becomes critical|
|3.3d|5004|87.68|-1.405|Arithmetic-only change regresses Fmax; not selected alone|
|3.3e|5030|92.83|-0.772|Staged mask conversion; secret compaction becomes critical|
|3.3f|3742|85.05|-1.758|Narrow payload saves area; formatting extends compaction path|
|3.3g archived|**3687**|**96.58**|**-0.354**|Retain;100 MHz timing still open|

STAGE3_3A..F_RESULTS.json and evidence/stage3_3a..f.zip preserve the intermediate
sources/reports. Locally simpler logic did not always improve placement/timing;
regressions remain visible. No independent SV/Python/C oracle formula changed.
The independent SV reference package, Python script and challenge RTL match3.2.

### Current resources and all-corner timing

| Metric | Current |
|---|---:|
| ALMs needed / used in final placement |3687 /3823|
| Combinational ALUTs |4899|
| Registers |2349|
| M10K / MLAB memory bits / DSP |1 /0 /0|
| Logical challenge RAM bits |1024|
| Slow85 C / Slow0 C Fmax |96.58 /96.93 MHz|
| Constraint |100 MHz /10 ns|
| Worst setup / hold | -0.354 /+0.169 ns|

| Corner | Setup ns | Setup TNS ns | Hold ns | Hold TNS ns | Pulse slack ns |
|---|---:|---:|---:|---:|---:|
|Slow 1100mV 85C|-0.354|-0.778|+0.496|0.000|+3.419|
|Slow 1100mV 0C|-0.317|-1.091|+0.510|0.000|+3.347|
|Fast 1100mV 85C|+5.228|0.000|+0.179|0.000|+3.790|
|Fast 1100mV 0C|+5.731|0.000|+0.169|0.000|+3.778|

Versus3.2: (4356-3687)/4356=15.36% fewer ALMs,96.58/44.79=2.16x reported Fmax;
registers rise1985->2349 from staging. Against original Stage3, ALMs fall64.66%
and reported Fmax rises5.63x. Each row's clock/area belongs to the same build.

**Timing is not closed at100 MHz.** Slow85 C worst path is hold_core_r ->
mask_residual_r[1][4],10.090 ns data delay,slack -0.354 ns. Slow0 C worst path
is decode_mask_r[10] -> packed_secret_r[2][3],10.078 ns,slack -0.317 ns.
Worst endpoint setup TNS is -1.091 ns at Slow0 C. All hold TNS values are0.
No new exception or clock relaxation was added.

Scope is internal clocked paths under existing standalone data-I/O exceptions.
The circular collector's combinational read mux is excluded; actual sink/board
timing needs interface constraints or a registered boundary. Reported Fmax is
not integrated Keccak/sampler/NTT throughput. No100 MHz physical throughput is
claimed, and no netlist/board/security acceptance follows from these results.

### Current functional gates and cycles

- Main UVM52 complete polynomials (A11,secret16,mask14,challenge11),19 expected
  errors,11 reset aborts;13917 exact coefficient comparisons.
- 13917=52*256 complete outputs +605 checked partial outputs from failing/reset
  jobs. Earlier versions checked different partial prefixes; every successful
  polynomial still requires exactly256 correct outputs and successful status.
- Independent Python104/104 jobs,19456/19456 coefficients:76 complete,24 expected
  errors,four aborts. Python/C equality48 seed cases/12288 coefficients.
- Checker12/12 corruptions rejected. Zero unexpected UVM errors/fatals in all
  three source tests. Negative file tests do not credit coverage.
- Performance96 checked polynomials/24576 coefficients/72 scenarios. All96 CSV
  rows match3.3a. Later rewrites add no further clocks; original3.2 cycles differ.
- Actual pending-stage hazard witnesses: two resets with both stages occupied;
  one malformed-byte acceptance with packed work pending. Subsequent outputs
  compare against the independent oracle. Witnesses are not success coverage.
- Fresh vector manifest71876eaf2f3a4dbeb12b70c1eeb29d5b.

| Mode | Set | Single continuous | Single stalled | Pair continuous | Pair stalled |
|---|---|---:|---:|---:|---:|
|A|44|262|374|520|748|
|A|65|262|375-378|520|748|
|A|87|262|374-378|520|748|
|Secret|44|264-266|376-380|520|748|
|Secret|65|264-273|375-385|521|749|
|Secret|87|262-265|374-381|521|748|
|Mask|44|262|374|520|748|
|Mask|65|262|374-376|520|748|
|Mask|87|262|374-378|520|746|
|Challenge|44|899-900|944-945|1795|1839|
|Challenge|65|932-934|976-980|1862|1909|
|Challenge|87|962-966|1003-1008|1924|1969|

Boundaries remain descriptor acceptance to last accepted output. A/mask singles
rise260->262; secret262-273 versus260; challenge899-966 unchanged. Non-challenge
first-input-to-first-output rises3->5 clocks. Conservative reservations plus
16-result secret groups create additional bubbles; that remains future work.
CSV/summary retain input/processed bytes,candidates,committed values,occupancy,
source stop,raw overlays and exclusive cycle partitions. Accepted-candidate
counts now follow commit separately from extraction.
The periodic ready pattern runs continuously across the entire performance test.
Earlier scenario latency changes shift its phase for later scenarios, including
challenge cases. Different stalled challenge rows do not establish a challenge
engine improvement; its source is unchanged and continuous cycles are identical.

### Current raw DUT code coverage

Same +cover=sbceft and DUT-only aggregation; no exclusions added. Narrow payloads
and the extra small compactor change the source scope/denominator: nine local
DUT instances. Percentages are not a direct functional-quality comparison with
old sources. Overall=sum local hits/enabled bins,not mean category percentages.
Databases are separate, not merged.

| Category,hits/bins | Smoke | Vectors | Performance |
|---|---:|---:|---:|
|Statements|617/620|614/620|600/620|
|Branches|418/422|415/422|405/422|
|Conditions|96/115|94/115|82/115|
|Expressions|79/96|77/96|66/96|
|Toggles|6408/6931|6420/6931|6388/6931|
|Overall raw code|7618/8184=93.08%|7620/8184=93.11%|7541/8184=92.14%|

No FSM metric is fabricated where Questa did not infer one. The initial small
checked-polynomial group reaches100% of its bins only; detailed functional
coverage and code-gap analysis remain Stage4. GUI launcher now includes pending
stages,counts and circular pointers; current revision was batch-verified, not
visually reviewed in GUI. Raw totals still print directly in Questa Transcript.

### Publication comparison and next bounded work

LightHD reports4035 Artix LUTs/1157 FFs/0 BRAM (distributed challenge RAM)/0 DSP.
Current whole four-mode sampler uses3687 CycloneV ALMs/2349 registers/one M10K/
0 DSP. ALMs are not interchangeable with Artix LUTs. Its212.8 MHz is a complete
accelerator result;96.58 MHz here is standalone internal-path Fmax. No
standalone LightHD sampler cycle/Fmax win is claimed.

At this checkpoint the next step was Stage3.3h: preselect mask working carry at input acceptance to remove
context selection before alignment, then shorten the remaining secret prefix
path. Preserve job-tag/carry update ordering. Retain100 MHz and repeat exact
value/protocol/performance/full-fit gates. Then proceed to Stage4 coverage/area/
timing improvements. The corrective gate remains open; no new stage was started
after saving3.3g in this bounded session. No commit.

## 12. Stage3.3h-k - carry ownership and collector timing

Selected current revision: **3.3k**. Full compile ended Fri Oct 16 22:15:30 2026.
Same Cyclone V device, Quartus version, seed1 and permanent 100 MHz /10 ns
constraint; no new timing exclusions or independent model changes.

### Changes and selection

- 3.3h loads mask carry/count/width at input-beat acceptance. Both64-bit
  halves advance a working copy and the saved per-job state together.
- 3.3i captures the append address with packed data using tail_n forwarding.
  This removes the selected-core mux before alignment. Its fit reduced area
  but regressed timing; it was not accepted alone.
- 3.3j additionally zeros invalid input bytes before holding them, removing
  byte masking from mask-carry feedback. Candidate payload registers capture
  every clock under resettable valid-bit ownership, keeping collector-capacity
  logic off data-register enables. Extra switching/power is not characterized.
- 3.3k keeps non-challenge beats stationary, selecting the low/high64-bit
  half with a pointer. Challenge byte shifting remains. This removes capacity
  control from the wide holding-register shift mux.
- Source-only invariants check working-carry context ownership and append
  pointer forwarding. No additional pipeline clocks or interface changes.

| Revision | ALMs needed | Registers | Worst Fmax MHz | Worst setup ns | Worst hold ns |
|---|---:|---:|---:|---:|---:|
|3.3g|3687|2349|96.58|-0.354|+0.169|
|3.3h|3704|2374|99.63|-0.037|+0.171|
|3.3i|3668|2379|97.85|-0.220|+0.170|
|3.3j|3558|2390|97.13|-0.296|+0.146|
|3.3k|3543|2388|100.33|+0.033|+0.144|

Current ALMs used in final placement: 3667; combinational
ALUTs: 4740; logical RAM bits: 1024;
M10K/MLAB bits/DSP: 1/0/0.

### All-corner internal timing

| Corner | Setup ns | Setup TNS ns | Hold ns | Hold TNS ns | Pulse ns |
|---|---:|---:|---:|---:|---:|
|Slow 1100mV 85C|+0.246|0.000|+0.344|0.000|+3.412|
|Slow 1100mV 0C|+0.033|0.000|+0.339|0.000|+3.346|
|Fast 1100mV 85C|+5.376|0.000|+0.156|0.000|+3.785|
|Fast 1100mV 0C|+5.893|0.000|+0.144|0.000|+3.779|

**Status: functional checks pass; standalone internal timing passes at 100 MHz.**
The setup margin is only0.033 ns. Worst path: decode_mask_r[0] to
packed_secret_r[2][3],9.721 ns data delay at Slow0 C; the prefix/packing path
remains a future margin-improvement candidate. Clock constraint is distinct
from reported Fmax.
Data input/output paths remain excluded for this standalone internal-clock
measurement, including the collector output read mux. Physical I/O timing,
actual Keccak/NTT integration, netlist and board checks remain open.

### Repeated verification and cycles

- Main UVM:52 complete polynomials (A11/secret16/mask14/challenge11),19 expected
  errors,11 reset aborts and13917 checked coefficients. All three runs have
  zero unexpected UVM errors/fatals.
- Python:104/104 jobs,19456/19456 coefficients;76 complete,24 expected errors,
  four aborts. Independent Python/C equality:48 cases/12288 coefficients.
- Checker corruption self-test:12/12 rejected; no coverage credit.
- Main-UVM performance:96 polynomials/24576 coefficients/72 scenarios. All96
  CSV records exactly match3.3g; h/i/j/k add no clocks. Descriptor-to-final-output
  continuous singles remain A/mask262,secret262-273,challenge899-966. Full
  cycle table and boundary definitions are in section11.
- Fresh vector manifest: c1e0110cd68a4850bce3de12e28d07ec.

### Raw DUT code coverage

Same DUT-only local-bin sum and +cover=sbceft; no new exclusions. Source changes
alter the enabled denominator. Separate runs, no merged database or inferred
functional completeness.

| Category hits/bins | Smoke | Vectors | Performance |
|---|---:|---:|---:|
|Statements|627/630|624/630|610/630|
|Branches|421/425|418/425|408/425|
|Conditions|102/121|100/121|86/121|
|Expressions|79/96|77/96|66/96|
|Toggles|6464/6995|6476/6995|6445/6995|
|Overall raw code|7693/8267=93.06%|7695/8267=93.08%|7615/8267=92.11%|

The initial checked-polynomial covergroup is still preliminary; Stage4 must
expand feature/test/bin traceability and explain actual gaps. GUI commands
remain available, but this revision was batch-verified, not visually reviewed.

### Evidence and next gate

STAGE3_3H/I/J/K_RESULTS.json and evidence/stage3_3h/i/j/k.zip preserve exact source,
reports and logs per revision. SHA256 sidecars and archive CRC/source hashes
are verified. Current3.3k additionally packages controlled documentation.

The next gate recorded here was Stage4.1. It has now passed for its success-path
scope; next is Stage4.2 checked error/reset/recovery and internal-state coverage,
15 reachable success gaps and code-miss classification. See COVERAGE.md.
No commit or netlist signoff.

At the now-met100 MHz internal clock, the measured continuous testbench counts
correspond to A/mask262*10 ns=2.62 us per single polynomial, secrets2.62-2.73 us
and challenge8.99-9.66 us. A/mask single-job coefficient rate is
256/262*100 MHz=97.71 million coefficients/s under the measured source/sink
profile. These are cycle-derived standalone values, not measured board or
integrated Keccak/NTT rates. The serial coefficient port still bounds the
non-challenge rate at one coefficient/clock.

Stage4.2 retains all96 performance records exactly and the3.3k fitted RTL.
Main UVM now229 complete/44 errors/25 aborts/59261 comparisons.17 groups give
773/785 functional hits (98.47%);DUT code7708/8267=93.24%. No new fit/clock
change. Next Stage4.3 reachable functional crosses and code-gap tests;see COVERAGE.md.

Stage4.3 retains all96 performance rows and the3.3k source/settings/fit.
257 complete/48 errors/33 aborts/66429 checks,807/807 defined functional bins
and code7736/8267=93.58%. No additional cycle or fitted metric change. Broad
protocol and random-workload review follows in4.4;see COVERAGE.md.
