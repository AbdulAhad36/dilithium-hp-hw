# Sampler verification test plan

## Current retained implementation:Stage4.9r

3537 actual placed ALMs,164.74MHz worst Fmax,setup+0.430ns/hold+0.141ns at
unchanged6.5ns. Seed1,HIGH PERFORMANCE EFFORT,physical register retiming OFF.
All original structural guards pass;the faster retimed Q diagnostic was not
accepted. Source is identical toO and its621-job suite is reused only after
26 source/model/launcher hashes match. R's compile/structural/multicorner
reports are fresh. All96 performance rows matchJ,Python104/19456,C48/12288,
checker12 and all5 zero-credit faults pass. No new functional netlist test.
Functional1652/1721=95.99%,69 gaps;raw DUT code15093/15799=95.53%,706 misses.
Evidence:STAGE4_9R_RESULTS.json. StayStage4;user acceptance remains pending.

## Current arithmetic-boundary expansion

Default `sampler_stage4_9_test` now adds six mask polynomials to the615-job
suite below:each context and all three parameter sets. Fields include0,1,
gamma-1,gamma,gamma+1,gamma+8190/8191/8192,and wide-field values around the
516097 borrow boundary,plus2*gamma-1. Inputs are serialized bit-by-bit;the
unchanged scalar scoreboard checks all256 canonical coefficients and status.
No direct DUT-function calls or fabricated coverage hits are used.

Latest source totals:621 complete(A150,secret200,mask130,challenge141),182
expected errors,51 reset aborts,159628 comparisons=621*256+652 partial values.
Require `SAMPLER MASK FORMAT BOUNDARY PASS:6 complete jobs` as well as the
existing robustness/merge/reset gates. Hardware selection still requires fresh
placed ALMs<3537,Fmax>=164.74MHz,positive6.5ns slack and all96 cycle rows.
R itself passed the preceding baseline gate of3628 placed ALMs/163.16MHz.
The independent models,23 functional groups and1721-bin denominator remain.

## Stage4.9 robustness expansion - 2026-10-19

The default source launcher now runs `sampler_stage4_9_test`, extending the
existing main UVM sequence, driver, monitor and independent scalar scoreboard.
The following sections describing391 jobs/100MHz are historical checkpoints.
No reference algorithm is changed by this expansion.

| Requirement | New directed stimulus | Required result |
|---|---|---|
| Rejection cannot corrupt the next accepted candidate |54 complete jobs: A/secret/challenge x2 contexts x3 parameters x3 burst lengths | All256 indexed coefficients and success status match the independent oracle |
| All invalid5-bit byte counts are refused with the specified error |0 and17..31 in each of4 modes on both contexts:128 errors | Byte-count error, followed by exact same-ID/same-mode recovery |
| Output/status payload and ownership survive prolonged backpressure |24 jobs:4 modes x2 contexts x3 parameters; output stalled1024 clocks and status4096 clocks from command issue | No data/tag/index/last loss; eventual independently checked completion after readiness returns |

Burst targets are17,129,513 rejected candidates. Secret nibbles are transported
in bytes, so odd targets round up to18,130,514. Matrix rejects use three bytes
each. Challenge signs are supplied first, followed by rejected255 bytes and
then legal candidates. All inputs use the external interface; no force/deposit.
Existing18 preparation reset/recovery targets and1282 merge patterns remain.

Three new success-gated groups extend the original20 groups to23:

- `stream_context`: context x mode x parameter x accepted beat length1..16.
- `rejection_bursts`: context x rejection-sampling mode x parameter x consecutive
  rejection length, including reachable extended runs2048 or more. Sample only
  when the next candidate is accepted, after whole-polynomial checking succeeds.
- `backpressure_context`: context x mode x observed maximum output/status stall,
  with separate0,1..16,17..127,128..1023,1024+ clock ranges.

The checked-error group now has individual bins for all16 invalid byte counts
and their mode/context cross. Its cross is sampled only on byte-count errors.
`smoke_checked_robustness.csv` records each successful job's maximum rejection
run and observed stalls. Every mismatch fault must leave this file empty as
well as the existing four checked witness files.

Fresh retained Stage4.9j source run:615 complete polynomials,182 expected errors,51 reset
aborts,158092 checked coefficients(615*256+652 partial values),zero UVM errors
or fatals. Defined functional bins:1652/1721=95.99%,69 misses. Three new group
instance scores:stream99.79%,rejection90.00%,backpressure82.92%. Raw DUT code
15084/15790=95.53%,706 misses. Fresh fit3628 placed ALMs,163.16MHz,
setup+0.371ns/hold+0.161ns at6.5ns. All96 performance rows match4.9h byte-for-byte.
Python/C,checker selftest and five zero-credit faults pass. Evidence:
STAGE4_9J_RESULTS.json;the earlier higher-area4.9i collector trial is rejected.

Coverage is measured,not capped at92-93%. Unhit reachable combinations are open
verification work,not evidence that the DUT fails. Native128 issuance,unbounded
readiness assumptions,board integration and security signoff remain outside the
implemented contract; they are not invented as impossible bins. Keep failures
visible and reproduce any actual mismatch before changing RTL or expectations.

Current4.6r retains default sampler_stage4_6_test and C35:1282
secret patterns (625 group-count tuples +16 local masks per eta),42 extra
complete secret polynomials. The independent scalar oracle is unchanged.
Main UVM: 391 complete polynomials, 54 expected errors, 33 reset aborts,
100733 coefficient checks. Functional 914/914 defined bins; raw DUT code
8198/8755 = 93.64%. Python104/19456, C48/12288, checker12/12, performance96
and five coverage fault gates pass. All96 performance rows remain unchanged.

4.6r changes only the DUT's packed payload enable;valid ownership remains.
The entire testbench and independent references match4.6e. Existing interleaved
stalls,reset/error draining,same-ID reuse,refusals and clipping cases all pass;
all96 performance records match byte-for-byte. Both original64-bit secret banks
survive fitting,with1/28 router copies counted separately. Fresh metrics:
3487 ALMs,2445 registers,109.54MHz worst,+0.871ns setup/+0.147ns hold at100 MHz.
Stage4.6p/q also pass this suite but are slower and rejected. Their relocated
clipping probes are archived with those trials and restored in the active TB.
No new bins/tests/exclusions are introduced to claim coverage growth.
Trials4.6s/t also pass the same suite,Python,all96 performance rows and all five
fault gates,but lose the timing comparison.4.6s additionally checks16 formatter
encodings algebraically(no RTL credit);4.6t checks packed one-hot address ownership
on valid commits and confirms16 original address registers after fitting.
Their assertions/probes are archived with those trials.4.6u restores/revalidates
exact4.6r.4.6v snapshots the secret eta parameter at beat acceptance and asserts
ownership on held healthy secret beats. All existing correctness/reset/error/
interleaving checks and all96 cycle rows pass;one fitted snapshot bit survives.
The trial loses timing/area and is archived/removed.4.6w restores/revalidates
exact4.6r;no TB/model/bin change is retained.4.6x working matrix carry and4.6y
direct secret compaction also pass all existing checks and unchanged96 cycle
records,but worsen timing/area. Their source/probe changes are archived/removed.
4.6z restores/revalidates exact4.6r with no retained TB/model/bin change.
Next:review secret rotation across the existing packed boundary;derive ownership,
tail forwarding and capacity first. Acceptance pending,Stage4 active.
Read STAGE4_6Z_RESULTS.json.

**Synthesis correction:** 4.6a-4.6c hardware improvement claims are withdrawn.
Their source simulations passed, but Quartus dropped the secret-data register
writes and removed all64 packed secret payload bits as constant. Those fits
are archived evidence of a defect, not valid hardware baselines.
4.6d fixes the assignment without changing reference formulas,test sequences,
coverage bins or cycle counts. Existing partial-byte,interleaving,stall,reset
and random cases check mask carry; a DUT invariant checks shift metadata.
New synthesis gate in report_paths.tcl requires64 mapped decode_secret_r and
64 packed_secret_r registers; both counts pass. This catches the observed
synthesis loss but does not substitute for functional implementation checking.
4.6e changes capacity arithmetic only;existing fill/stall/interleaving/reset
tests and independent scoreboard remain.152592 offline cases check threshold
algebra separately;no functional coverage credit is assigned to that check.
Stage4.6e:3482 ALMs,2412 registers,one M10K,zero DSP;worst Fmax107.67 MHz,
setup+0.712 ns/hold+0.142 ns at unchanged100 MHz.
Acceptance pending; old Stage5 netlists reject changed source. Native128 deferred.
4.6f/4.6g passed this same regression but failed the performance comparison;
selected RTL is restored to4.6e and revalidated as4.6h.4.6g additionally checked
the original-width admission formula each active decode and71961 offline legal
arithmetic cases;these trial-only checks are archived,not retained in selected RTL.
Register guard counts64 original bits separately from legitimate router copies.
4.6i/j/k also passed391 jobs/100733 checks,Python and five fault gates but
were slower. Their ownership/quota assertions are archived with each rejected
RTL. Selected source/build scripts are restored exactly and revalidated4.6l.
The4.6m/n pipeline experiment added compact-stage ownership/position-budget/
reservation invariants,12 exact phase-targeted resets and6 pending-work errors,
all followed by independent same-ID recovery.409 successes/60 errors/45 aborts/
105340 comparisons pass;928/932 trial bins and all five zero-credit fault gates
are recorded separately. All96 latency records are explicitly compared to4.6e.
These slower pipelines are rejected and their tests/probes archived with them;
4.6o restores/revalidates selected4.6e's391-job testbench and unchanged references.
Those two-stage placement trials are recorded above;the current next target is
held-beat parameter/mode selection within the existing depth. Stage4 remains active.
STAGE4_6L_RESULTS.json/COVERAGE.md supersede earlier descriptions below.

**Current:Stage4 optimization resumed;user acceptance pending.** Source and
netlist results below are checkpoint evidence. Passing tests and the initial
100 MHz target did not authorize stage advancement. Stage4.6 targets measured
timing bottlenecks with main UVM/Python,performance/coverage and fresh fitting.

Current: Stage5,2026-10-18. Source main UVM validates349 complete jobs,54 expected
errors,33 reset aborts and89981 coefficients.20 groups/76 points/31 crosses:
914/914 defined functional bins=100%,DUT code93.73%. Distinct post-synthesis and
post-fit functional netlists each pass184 jobs/156 complete/24 errors/4 aborts/
39936 checks;104-job Python captures19456 values match. Netlist raw730/914
functional bins,source-only groups unsampled. See COVERAGE.md/STAGE5_RESULTS.json.
The earlier success-path model and historical checklists are retained below.
Historical Stage1-3 checklists below retain their original measured counts.

## Stage5 implementation-test scope

The user continued past the Stage4 review gate on2026-10-18. Freeze the selected
3.3k RTL/settings and retained fitted evidence; source code gaps remain unwaived.
sampler_netlist_test reuses the main driver,monitor,scalar oracle and checked
coverage. It runs104 file jobs plus80 additional jobs:72 random polynomials
(3 seeds *4 modes *3 parameters *2 cores) and8 mode/core admission/completion
cases. Independent Python compares only the104 captured file jobs.

Both netlists must pass184 total jobs:156 complete,24 expected errors,4 reset
aborts,39936 checked coefficients. Require zero unexpected errors/fatals,exact
same capture equality between implementations and independent Python equality.
The capture stops recording after the file phase; SV checks continue throughout.

`SAMPLER_NETLIST` disables source hierarchy connections. Monitor occupancy
conservation checks and internal snapshots are gated by source_probes. Successful
job coverage based on accepted bytes/outputs still runs. Source-only reset-state,
pipeline activity,challenge-state and internal completion-arbitration groups
are unsampled, not falsely credited or silently excluded. Phase-targeted source
resets/error injection and internal code-gap tests cannot run on optimized
hierarchies; external reset/cancellation/reuse remains in the file workload.

Netlist-specific logs/report hashes and outcomes are recorded in
STAGE5_RESULTS.json and COVERAGE.md. No merged RTL/netlist percentage, inferred
gate-code coverage,physical I/O closure,SDF or security claim.

## Historical Stage4.5 added traceability

| Requirement | Stimulus/check | Evidence and limit |
|---|---|---|
| C31 unlocked status tie |7000/7010 prime the turn; simultaneous byte error7001/7011 and invalid descriptor7002/7012; assert both eligible and unlocked and expected chosen core | Both selector choices hit; each status independently checked; same-ID exact recoveries pass |
| C32 held surplus |7100/7101:120 secret bytes then16-byte final beat,80-clock output stall | Hold/core/generated=256 witnessed; cleanup statement/branch/condition hit; exactly256 outputs and OK |
| C33 refusal through status |7200/7201:mask source-stop then hold input-valid through status-ready/acceptance | Every edge refuses input; pre-edge ownership checked before retirement; correct polynomial/status |
| C34 initialized IDLE abort |7300/7301:challenge clear then malformed metadata then same-ID recovery | Byte error and recovered challenge checked; initialized byte-ready abort term hit |

sampler_stage4_5_classes.svh extends main UVM; sampler_uvm_pkg.sv adds public
channel actions and corrects refusal/status publication order. The test checks
all six explicit dual-choice/surplus/completion target witnesses. Seven code
bins added, no RTL or reference-formula change and no added functional bins.
Remaining2 statements/2 branches/16 conditions/10 expressions/488 toggles are
retained. COVERAGE.md classifies scheduling/range arguments separately from
untested fault/producer traffic; none is a formal waiver. Conditions86.78%,
expressions89.58% remain below90%. Full source-verification acceptance is pending
user review before Stage5 real netlist generation/simulation.

## Historical Stage4.4 added traceability

| Requirement | Stimulus/check | Coverage/evidence |
|---|---|---|
| C28 idle-source refusal | Both slots,8-clock input offers without descriptors; every offered edge must keep input ready low | Scoreboard checks absence of ownership before protocol_refusals credit;16 idle-cycle rows in checked_protocol.csv |
| C29 busy/stopped refusal | Each mode/core: blocked second descriptor then source-stop input offer,8 clocks each; original job must still match all256 outputs/status | Retain owned witnesses until successful completion;8 busy and8 stopped job rows; protocol kind/core and owned kind/mode crosses |
| C30 reproducible random workloads | 3 fixed seeds *4 modes *3 parameters *2 cores; random bytes/valid-byte partitions/source gaps/interleaving/readies | Every coefficient/index/tag/last/status checked by independent oracle;72 successful activity rows; randomized_jobs crosses all72 combinations |

The new generator lives in sampler_stage4_4_classes.svh; driver/monitor/scoreboard
in sampler_uvm_pkg.sv; checked coverage in sampler_outcome_coverage.svh.
Three independent PRNG states separate data,source scheduling and readies.
Seeds:13579BDF,2468ACE1,DEADBEEF (hex). Two full runs reproduce identical six
checked witness/summary CSV hashes. Refused probes withdraw valid without a
handshake after8 clocks; this is an admission test, not all valid-holding cases.
Five separate fault classes still yield zero coverage/CSV rows (0/914 bins).
No RTL/reference formula change; all96 performance records match3.3k.
Current remaining code misses:3 statements,4 branches,17 conditions,13 expressions,
488 toggles. Conditions/expressions remain below90%; no exclusion or unreachable
waiver. Next Stage4.5 is code-gap/reachability and acceptance review, before Stage5.

## Historical Stage4.3 added traceability

| Requirement | Stimulus/check | Coverage/evidence |
|---|---|---|
|C22 peer errors with recovery |4000/4010 exhaust/invalid-param while challenge peer remains live;recover failed ID then finish peer |Former checked_errors peer cells hit only after validated statuses;all recovered/peer coefficients match |
|C23 reset parameter combinations |4100..4107 actual occupied-stage resets and same-ID recovery |Former8 reset mode/core/parameter cells hit after exact recovery |
|C24 final truncation |6-byte first beat,final full beat with surplus A/mask candidates |4200/4202 exact256 outputs plus owned clipping witnesses in *_checked_activity.csv |
|C25 completion arbitration |Hold status ready low until both pending,then release;all4 modes |completion_arbitration mode/core/pending/stall;stable offers and exact statuses. Does not imply unlocked tie-selection branch hit |
|C26 error during RAM work |9-byte prefix,malformed metadata accepted during COPY |Registered abort reaches SIGN;error and recovery4400/4401 checked. COPY/READ_OUT abort terms remain reviewed misses |
|C27 complete tag width |FFFF,8000,AAAA,5555 polynomial IDs |Every output/status tag compared exactly;upper ID-bit toggle holes reduced |

Current18-group model has0 missing defined bins. Code still has3 statement,
4 branch,17 condition,13 expression and494 toggle misses. No code exclusion
or RTL change was made. Broader protocol and reproducible random workloads
remain Stage4.4;full model coverage is not full sampler signoff.

## Historical Stage4.2 added traceability

| Requirement | Stimulus | Observation/check | Credit/review |
|---|---|---|---|
|C15 checked error reasons |Each mode/core:finite16-byte exhaustion,param3,byte count0/17; same-ID exact recovery |Code/ID/core independently expected by scoreboard; every emitted prefix already compared |checked_errors,mode x reason/core x reason/reason x live peer |
|C16 reset and clean recovery |Reset with both pending stages; challenge CLEAR/COPY/SIGN/READ_OUT on both contexts; same-ID recovery |Pre-reset state snapshots; no unowned output; later256-value exact recovery |reset_recovery,mode/core/param plus held/decode/packed/collector/prefix/FSM state. Queue records until verified recovery |
|C17 lifecycle |Success/error/reset followed by another operation |Prior checked outcome and current successful completion |lifecycle_recovery; no successful-polynomial credit for the error/abort itself |
|C18 collector/pipeline |All main jobs plus prolonged backpressure |Clock-to-clock count conservation from append delta/output pop;bounds<=32/16;pending context tags;head/tail wrap,admission clipping,source stop |pipeline_activity samples owned snapshots only after exact success. Challenge has no candidate/packed/clipping path |
|C19 challenge FSM |All parameters,interleaving,reset at observed RAM phases |Actual owner-qualified IDLE/CLEAR/COPY/SIGN/READ_OUT states and legal edges; independent full challenge equality |challenge_states and param x state; functional FSM coverage is distinct from inferred code FSM coverage |
|C20 success gaps |Source gaps with ready outputs;stall actual output/status offer for9/40 cycles;mask6-bit carry then1/7 bytes |Accepted transfers and stable stalled payload;scalar bit queue for masks |Original15 success misses now hit; all12 success groups100%,not full overall closure |
|C21 checker faults |Separate first value/index/tag/last/status corruption |COEFFICIENT/STATUS fatal before first credit;empty success/outcome witness CSVs |All5 runs0/785 bins; excluded from positive percentages |

The remaining12 functional cells and code-miss classifications are in COVERAGE.md.
Reset-at-phase coverage must not be used to claim error-abort logic at those
phases was covered: reset takes priority. No code exclusion was applied.

## Historical Stage4.1 success-path traceability

## Stage4.1 requirements, checking and coverage traceability

Default main UVM is sampler_stage4_test. Its sequence extends the original smoke
sequence; it does not replace the independent scalar reference. Current results:
178 complete jobs (A41/secret59/mask40/challenge38),19 expected errors,11 reset
aborts and46173 exact coefficient checks. 46173=178*256+605 checked partial
prefix values. All178 completed polynomials receive one coverage credit each;
errors/reset-aborted jobs receive none in these success-path groups.

The monitor records accepted input bytes and external stall observations. The
scoreboard retains them per context. Only after exact value/index/ID/core/last,
256-output count and successful status checks does checked_ap release the
transcript to sampler_coverage.svh. Coverage also withholds credit if any UVM
error/fatal exists. Reset discards pending transcripts. Replaying these bytes
classifies the independently validated operation; it supplies no golden results
to the checker and never samples unaccepted requests or surplus candidates past
the first256 accepted values.

| Requirement | Directed stimulus in sampler_stage4_classes.svh or inherited smoke | Independent check | Implemented group and sampling logic |
|---|---|---|---|
| C01 modes/parameters/contexts/completion | Original all-parameter paired tests plus ordered mode pairs |256 exact indexed outputs and OK status |checked_polynomial at checked_ap; mode x core x parameter |
| C02 valid bytes and low/high halves | All1..16-byte partitions; driver poisons unused high bytes |Scalar byte/bit queues ignore invalid bytes |input_format, observed beat size x mode, after job success |
| C03 backpressure and ownership |Periodic stalls; forced output/status stalls; both live slots |Monitor payload stability, scalar stream equality, checked status |scheduling, longest observed per-job output/input/status runs and mode x output stall; paired/switched/reused witnesses |
| C04 successive modes |Each of16 prior/next combinations on both contexts |Each operation completes against its mode's scalar oracle |mode_transitions; prior successful mode per slot, reset/error breaks history |
| C05 matrix boundaries/high bit/candidate order |0,1,q-1,q,q+1,2^23-1, high-bit-set forms; fragments |matrix_candidate scalar oracle and indexed output comparison |matrix_candidates; replay3-byte little-endian candidates until256 accepted; top-bit x acceptance and continuous-byte offset x acceptance |
| C06 secret mapping/lane rejection |All nibble values,eta2/4,all physical nibble positions |secret_candidate scalar modulo5/eta4 oracle |secret_candidates; byte position within each64-bit chunk determines lane0..15; eta x nibble, lane x acceptance |
| C07 stable secret compaction/count |First full chunk deliberately accepts each count0..16; all-reject prefix later completes |Exact output order/count against scalar accepted queue |secret_compaction; examined acceptance mask and count up to completion, not an unverified RTL mask probe |
| C08 mask extrema/zero/sign |Raw fields0,1,gamma-1,gamma,gamma+1,max-1,max,lower/upper interiors |Scalar bit-queue gamma-field and canonical conversion |mask_fields; width x field class, after successful polynomial |
| C09 mask18 carry |Arbitrary accepted-byte partitions and interleaved jobs |Bit-queue oracle plus exact outputs |mask18_alignment; scalar reservoir count before each consumed chunk x chunk bytes; reachable carries0,2,...16 |
| C10 mask20 carry |Same for ML-DSA65/87 |Same independent bit oracle |mask20_alignment; reachable carries0,4,8,12,16 x chunk bytes |
| C11 challenge rejection/shuffle dependencies |j>i,j==i,repeated nonzero positions,all tau values |Signed-array sequential shuffle,exact polynomial and weight |challenge_decisions; replay accepted bytes through sign/index algorithm, param x each decision |
| C12 output endpoints/canonical values |All completed polynomials and boundary-generating inputs |Exact value/index/last and mode range/weight checks |coefficient_shape; checked reference values known equal to actual outputs, mode x canonical lower/upper/zero and index positions |
| C13 active peer survives ID reuse |Challenge1951 partly shuffled; A1950 completes/reuses while peer stays live |Scalar per-job state plus eventual full challenge equality |C03 witnesses and exact checks; no dedicated internal-memory hazard coverage claimed |
| C14 coverage gate rejects wrong data |Separate SAMPLER_INJECT_FAULT run flips first observed coefficient |COEFFICIENT UVM_FATAL before first success |Witness CSV has zero jobs and separate UCDB has0/589 functional hits; excluded from positive totals |

Twelve groups contain38 coverpoints and17 crosses,589 enabled bins. Primary
functional percentage is574/589=97.45%; equal-group mean98.48% is a separate
weighting and must not be substituted for raw-bin coverage. See COVERAGE.md for
per-group results, actual missed bins, code coverage and exact commands.

## Stage4.1 recorded future requirements (historical; see C15-C21 above)

| Requirement family | Next observation/check and coverage work |
|---|---|
| Checked errors and recovery |Separate checked error outcomes by mode/core/parameter, malformed counts0/17,exhaustion before/after offered output, ID reuse and peer survival; preserve successful-group semantics |
| Reset/cancellation |Checked reset while hold/candidate/packed/collector/status/challenge states are occupied; recovery equality and no stale output; abort activity is not a successful polynomial |
| Internal pipeline/collector |Observe occupancy, pending reservations, simultaneous append/pop, circular wrap, first/last clipping and source stop; release coverage only after the affected observation/job is independently accepted |
| Challenge state/memory hazards |State/transition and self/repeated-index RAM timing observations, per-context signs and drain; distinguish reference input classifications from actual internal state witnesses |
| Protocol corner cases |Idle-tag refusal, blocked descriptor, both pending statuses, stalled offers across peer activity, source stop/drain and legal context lifecycle |
| Former success misses |Closed in Stage4.2. Corrected mask labels:carry6 with1/7 bytes,not carry12 with2/8 |
| Checker strength |Additional targeted value/index/tag/last/status corruptions in separate failing databases; no negative-run coverage merge |
| Code misses |Classify every remaining meaningful condition/expression/toggle miss and any justified unreachable condition; add no unexplained exclusions |

No full functional signoff follows from97.45% of the currently implemented model.
Keep future requirements visible without inventing zero-hit bins to manipulate
the denominator. The previous small100% group remains a subset of this model.

## Historical Stage1-3 checks and main UVM path

`sampler_smoke_seq -> sampler_driver -> DUT -> sampler_monitor ->
sampler_scoreboard -> checked_ap -> sampler_coverage`.

The monitor captures accepted descriptors, actual input bytes and actual
coefficient/status outputs. The scalar reference in sampler_ref_pkg.sv assembles
one candidate at a time, uses scalar signed secret mapping with modulo 5,
unpacks masks with a scalar bit queue, and constructs challenges with a signed
indexed array plus a sign-bit queue. Literal mask and challenge examples supplement
these scalar references. It does not reuse the RTL's chunk extraction, collector
or arbitration. The scoreboard checks exact value/index/job/core/last and success
count before publishing a completed polynomial. Error/reset-aborted jobs do not
credit functional coverage. All DUT valid payloads are checked for unknown bits;
coefficient/status stability is checked across stalls.

| Requirement | Stimulus/check | Current evidence |
|---|---|---|
| q boundary and top-bit removal | q rejected, q-1 accepted, FFFFFF rejected after masking, legal high-bit-set candidates; scalar byte oracle | Eleven complete matrix polynomials including mixed-mode jobs |
| Stable compaction/order | Mixed accepted/rejected candidates; exact per-job indexed value comparison | Passing |
| Input adaptation/carry | Full 16-byte words and counts 1..16; 64-bit split and byte fragments | Passing output comparison; detailed internal 2/3/3 witnesses remain Stage 4 |
| Two independent contexts | Paired jobs, alternating accepted packets and different per-job data | Six paired polynomials across parameter encodings 0/1/2 |
| Output groups/backpressure | Periodic ready stalls; stable tagged output and exact last | Passing; detailed group/cross coverage pending |
| Status/backpressure | Periodic status-ready stalls; stable payload, exact ID/code | Passing; simultaneous pending-status adversarial test pending |
| Finite-source exhaustion | One short input and one longer prefix | Expected EXHAUSTED; latter has 24 checked prefix coefficients, no success credit |
| Invalid parameter | Parameter encoding 3 | Expected PARAM |
| Invalid byte count | Counts 0 and 17 | Expected BYTES |
| Reset/reuse | Reset in-progress A/secret/mask and challenge clear/sign/shuffle/drain state; fresh jobs reuse slots | Seven aborted jobs; recovery polynomials pass |
| Idle tag, held command/input, source stop/drain | RTL and future integration contract | Broader directed checks pending |
| Secret eta=2/4 and lanes | All nibble values, both contexts/all parameter sets, mixed A/secret, all-accepted and all-rejected words, partial input counts and canonical signs | Thirteen complete secret polynomials; two zero-acceptance exhausted jobs and one exhausted after output prefix |
| Mask 18/20-bit reservoir | Bit-queue oracle, extrema/zero, all parameter/core combinations, mixed modes, partial words, 576/640-byte completion, reset with 12 residual bits | Twelve complete masks; fixed 18-byte example matches; 1-byte and one-byte-short exhaustion cases return errors |
| Challenge signs/shuffle | Scalar signed-array oracle; little-endian sign bits, j>i rejection, j==i and repeated nonzero locations, exact indexed comparison | Eleven complete challenges, all parameters/both contexts, tau=39/49/60 and coefficient range verified |
| Challenge literal | Signs 29 00 00 00 00 00 00 00, 39 repeated zero candidates, trailing FF surplus; continuous-source last=0 | id620: -1 at 218/221/223, +1 at 0 and remaining 218..255, zero elsewhere |
| Challenge mixed modes | Paired challenge/A, secret/challenge, mask/challenge | Passing with periodic input gaps/output/status stalls |
| Challenge errors/reset | Finite 7/8/16/46-byte streams, malformed 0/17 bytes, invalid parameter; reset during clear/partial signs/shuffle/drain | Seven expected challenge errors, four challenge aborts; recovery id634 passes |
| Independent Python / software check | One prepare/compare script plus unchanged C reference; fast capture in same main UVM | 104 jobs / 19456 coefficients match Python; 48 seed cases / 12288 coefficients also match C |
| File-checker corruption self-tests | Offline altered captures, no simulation/coverage credit | 12/12 corruptions rejected; CLI wrong-value comparison returns 1; UVM fault-injection/coverage-gating self-tests remain Stage 4 |
| Full requirements/coverage expansion | Detailed functional interactions and DUT code gap analysis | Stage 4 pending |

## Initial coverage definition

The single checked_polynomial group samples successful status only after 256
exact outputs match. It contains core {0,1}, mode {A,secret,mask,challenge}, parameters {0,1,2},
completed-count {256} and mode x core x parameter. It reaches 100% on this small smoke set. This is **not**
100% coverage of sampler functionality. Error paths
are checked by status/value logic but do not sample that success covergroup.

DUT code coverage covers sampler.sv, four sampler_secret_lane instances and
sampler_mask_unpack, sampler_ball and (from Stage3.1) sampler_compact
(nine local DUT instances from3.3f;3.1-3.3e had eight,Stage1/2 had seven).
The automatic raw overall total deduplicates each local category per DUT instance;
it includes lane logic, not just the top module. Raw overall means summed
hit bins divided by summed enabled statement/branch/condition/expression/toggle
bins; toggles dominate. Questa's filtered headline is a different aggregation.
Questa did not infer an FSM coverage model for this run despite the challenge
state enum; no FSM percentage is fabricated.
See STAGE1_RESULTS.md for counts, real misses and the tested revision manifest.

## Stage 2 vector set

See FIPS204_SAMPLER.md and STAGE2_RESULTS.json. The same environment runs a
file-driven sequence and observation-only capture subscriber. Default smoke
regression remains separate. 76 successful polynomials (19 per mode), 24 expected
errors and four zero-output reset aborts compare exactly with Python. Seeded and
explicit-byte cases cover all mode/parameter/core combinations; byte partitioning
and output/status stalls exercise alignment/context preservation. Stage 1 retains
deeper reset and error-prefix cases. No exhaustive functional closure is claimed.

Vector code coverage is stored separately: 4883/5558=87.86%; smoke regression
remains 4885/5558=87.89%. No combined/merged coverage percentage is claimed.

## Stage 3 measurement checks

sampler_performance_test runs96 successful jobs in72 scenarios using the same
scoreboard. Measurements are accepted via checked_ap only after exact output
validation. One/two jobs, both single-context placements, continuous source and
periodic stalls are measured separately. Exclusive cycle buckets must sum to
accepted-job-to-last-output latency, generated/output counts must both equal256,
and processed bytes cannot exceed accepted source bytes. THROUGHPUT.md defines
raw activity overlays, peak/average rates and the actual failed fitted baseline.
The scoreboard's challenge-array initialization was corrected to clear only the
selected context; adversarial active-other-slot reuse remains Stage 4 work.

## Stage 3.1 compaction correction checks

The existing main-UVM directed, independent-vector and performance cases are
rerun against sampler_compact plus fixed collector writes. All-accepted/rejected
secret chunks, mixed valid nibbles, final truncation, simultaneous pop/append,
partial input counts, error-prefix drain and reset are checked by exact output
comparison. Drivers deliberately fill invalid high bytes with FF. The first
refactor failed a matrix coefficient check under that witness; zero-extending
carry to its declared byte count fixed it. Keep carry_poison_negative.log only
as a historical caught-bug witness, not a passing result or coverage credit.
No standalone non-UVM bench or replacement oracle is used.

## Stage 3.2 synchronous-memory correction checks

Main-UVM smoke checks reset during clear, sign collection, shuffle and drain;
finite-source errors, all challenge parameters, repeated locations and j==i
remain compared against the independent scalar oracle. Vector capture is
regenerated after the RAM source change, then checked against Python/C-derived
expected coefficients. The performance CSV must be compared with the saved
Stage3.1 CSV to detect any extra RAM-read or controller clocks. A clean memory
process alone is not inference proof: require fresh fitted physical RAM reports.
No netlist, board or exhaustive memory-hazard claim follows from these source tests.

## Stage 3.3 pending-stage and mask-alignment checks

The main smoke sequence adds pipeline_cases(): reset while both candidate and
packed stages are occupied with a second live descriptor, recover both contexts,
then accept malformed byte metadata with earlier packed work pending and reuse
the failed ID. Source-only monitor probes must witness at least two occupied-stage
resets and one pending-work invalid-byte acceptance; missing stimulus fails the
test. These witness counts are not successful-polynomial coverage. Every recovery
output is still checked by the original independent scoreboard.

The expanded main smoke gate requires52 complete polynomials (11 A,16 secret,
14 mask,11 challenge),19 expected errors and11 reset-aborted jobs. Pending-stage
capacity assertions supplement exact indexed comparisons, final truncation and
stable stalled-output/status checks. Reset clears pipeline valids; descriptor
status cannot release a context while it still owns pending data.

Mask18/20-bit cases, all partial-byte partitions and deliberately FF-filled
invalid high input bytes repeat after alignment/carry changes. The104-job Python
capture comparison and96-polynomial performance run remain separate modes of
the same UVM environment. Performance accepted-candidate counts now follow
collector commit rather than extraction, because these occur on different clocks.
No independent SV/Python/C sampling formula is altered by this timing work.

Stage3.3h/i add simulation-only ownership assertions. During a held mask beat,
working carry/count/width must equal the selected job's saved state. At every
healthy packed commit, the captured append address must equal that job's tail.
Existing interleaved18/20-bit streams, arbitrary valid-byte partitions, poisoned
unused bytes, reset recovery, mixed modes and simultaneous append/pop cases
repeat through main UVM. Exact output/status comparisons remain independent;
these internal invariants are supplementary and do not credit functional bins.

The selected3.3k source keeps secrets four-bit through both pending stages and
restores canonical values at collector write; A uses a3x23 compactor. Current
category counts,scope/cycle changes and all fitted revisions are in THROUGHPUT.md.
No exclusions were added; source widths change the raw denominator. Detailed
functional coverage remains pending. Current timing status is in THROUGHPUT.md.

Stage3.3j repeats poisoned-byte partitions after moving zero padding to beat
acceptance. Candidate payloads now capture unconditionally, with valid bits
owning every use. The independent scoreboard, reset/error recovery, exact
Python comparison and performance gates remain required.
