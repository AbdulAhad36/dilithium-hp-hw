# Sampler post-midyear design and verification plan

## Current retained Stage4.9r - actual placed area reduced

3537 placed ALMs,3931 registers(3860 implementation+71 router),4256 ALUTs,
one M10K/1024 bits,zero DSP. Worst Fmax164.74MHz,setup+0.430ns/hold+0.141ns
at unchanged6.500ns. Compared withJ:91 fewer placed ALMs(2.51%),Fmax+1.58MHz,
149 fewer ALUTs;3 additional router registers. All4 corners0 setup/hold TNS.
All96 performance CSV rows equalJ byte-for-byte;operating throughput unchanged.

R retains O's simpler20-bit mask arithmetic at J's original pre-packing stage.
Compiler seed1,HIGH PERFORMANCE EFFORT,physical register retiming explicitly
OFF. Every original payload/mask/sign/ownership guard passes unchanged. Source
checks reuse O only after26 RTL/UVM/model/launcher hashes match;R has a fresh
full compilation and structural/multicorner reports. Main621/159628,Python
104/19456,C48/12288,checker12,performance96 and5 zero-credit faults pass.
Functional1652/1721=95.99%,69 gaps;raw code15093/15799=95.53%,706 misses.
Retain R;archive create-only in STAGE4_9R_RESULTS.json/evidence/stage4_9r.zip.
Further optimization must beat3537 placed ALMs while preserving164.74MHz,
all96 measured cycle rows and positive6.5ns setup/hold. Acceptance pending;
stayStage4,no commit/integration/functional netlist simulation or branch change.

The following bounded-work entries describe the trials leading to R.

## Current bounded work: further area reduction and broader UVM stress

Latest user direction:count actual final-placement ALMs as area. All new trial
gates use `alms_final_placement`,with4.9j's3628 ALMs and163.16MHz as baseline.
Needed estimates stay in raw historical Quartus artifacts only;they do not
establish improvement. Preserve all96 cycle rows and positive6.5ns timing.

Trial4.9k shares one mask gamma-field converter at the existing formatted
output register. Collectors retain raw20-bit mask fields;mode/width belong to
the job and remain stable until all output/status work retires. No new register
stage or cycle. The main independent UVM and all reference comparisons must
pass before any area/timing claim. Its source/reference/performance/fault gates
pass,but3469 placed ALMs/153.94MHz,+0.004ns setup fails Fmax preservation.
Archived create-only,not selected. The measured critical path is turn_r through
arbitration and the mask converter to out_data_r. Active4.9l formats each
registered context read in parallel,then arbitrates the two results. Two mask
converters still replace four original converters without adding any cycle.
4.9l passes all source/reference/performance/fault gates,but3499 placed ALMs/
154.42MHz,+0.024ns setup still loses Fmax. Archived create-only,not selected.
The remaining critical path is read_data_r through mask arithmetic to out_data_r.
Active4.9m uses q=2^23-8191 to replace two subtract paths with one20-bit subtract
and constant high bits per context. Zero at t=gamma remains explicit. Six
additional UVM jobs target zero and borrow boundaries on both contexts/all
parameters:621 successes/159628 comparisons pass. The independent model remains
unchanged. M measures3464 placed ALMs/155.55MHz,+0.071ns setup;not selected.
Its mask converter path improves to+0.658ns;the worst path moves to active_r
through challenge-read arbitration into the RAM address. Active4.9n removes
active_r from that request condition:healthy completed challenges with unread
indices cannot retire before all256 outputs are emitted. failed/done/index/mode
and capacity checks remain. A source ownership implication asserts the removed
condition on every qualifying cycle. No scheduling change is intended.
Preserve4.9j if placed area or Fmax preservation fails.

N measures3468 placed ALMs/150.22MHz,setup-0.157ns and fails the6.5ns target;
archived,not selected. Active4.9o restores J's original stage placement and
challenge-read predicate,and retains only the simpler20-bit mask conversion
arithmetic. Collector mask values are canonical again;shared output readout
formatting and the redundant-active trial are removed. Six boundary jobs stay
in the main UVM. Source621/159628,Python/C,performance96 and fault gates pass;
the fit decides retention against3628 placed ALMs/163.16MHz. No clock relaxation.

| Trial | Placed ALMs | Worst Fmax MHz | Worst setup ns | Selection |
|---|---:|---:|---:|---|
|4.9j baseline|3628|163.16|+0.371|Retained baseline|
|4.9k one output converter|3469|153.94|+0.004|Rejected:Fmax|
|4.9l parallel context converters|3499|154.42|+0.024|Rejected:Fmax|
|4.9m shorter arithmetic at readout|3464|155.55|+0.071|Rejected:Fmax|
|4.9n read predicate simplification|3468|150.22|-0.157|Rejected:timing and Fmax|
|4.9o arithmetic only/original stages|3501|154.27|+0.018|Rejected:Fmax|
|4.9p exact O RTL/fitter seed2|3492|155.04|+0.050|Rejected:Fmax|

Active4.9q retains exact O RTL/UVM and restores seed1,with Quartus
`OPTIMIZATION_MODE "HIGH PERFORMANCE EFFORT"`. The6.500ns constraint is
unchanged. Quartus confirms this mode in map report Info16303. This is a
compiler-setting experiment,not a new functional architecture. See the
[Standard Edition optimization settings](https://docs.altera.com/r/docs/683230/18.1/quartus-prime-standard-edition-user-guide-design-optimization/synthesis-netlist-optimizations?contentId=kxim8H_4~m0hL9P2w~73aA).
Source checks may be reused only after matching all26 RTL/UVM/model/launcher
hashes against O. Capture manifests bind those files and do not include QSF
placement settings;fresh complete Quartus/structural/multicorner checks remain
mandatory. The placed-area/Fmax gate is unchanged. No need to rerun unchanged
RTL simulations for a seed/optimization setting alone.

Q fits3536 placed ALMs/168.27MHz,setup+0.557ns/hold+0.156ns. However,physical
register retiming moves packed mask registers:the original-register guard
finds31 instead of64. The fitter explicitly reports those originals deleted
and replacement retimed registers. Q is NOT selected and its diagnostic ZIP
does not include stale prior family reports. Its compile.log was overwritten
after a failed generic freeze assertion(error-string whitespace),so the Q
diagnostic archive records that omission and reconstructs only the known QSF
retiming-default settings. The direct Q fit/STA/guard reports are preserved.
No retimed functional netlist simulation or guard waiver was performed.

Active4.9r keeps high-performance mode/seed1 and explicitly sets
`PHYSICAL_SYNTHESIS_REGISTER_RETIMING OFF`. Source remains byte-identical to O.
All original payload/mask register guards must pass on its fresh fit,along
with the unchanged placed-area/Fmax/cycle gate. The compiler setting is listed
in the [Standard Edition physical optimization reference](https://docs.altera.com/r/docs/683230/18.1/quartus-prime-standard-edition-user-guide-design-optimization/physical-synthesis-optimizations?contentId=nXouX5oVO5Om1XRqJeg5PQ).
R passes the fresh fit and all original register guards:3537 placed ALMs,
164.74MHz,+0.430ns setup/+0.141ns hold. It is the retained candidate described
at the top of this plan;Q remains an unaccepted diagnostic checkpoint.

Retained Stage4.9j improves the4.9h baseline:3628 placed ALMs,
3928 registers,4405 ALUTs,one M10K/zero DSP. Worst Fmax163.16MHz,setup+0.371ns/
hold+0.161ns at6.5ns. Saves125 placed ALMs(3.33%);
ALUTs rise220 and registers are unchanged. Fmax rises1.22MHz. All96 measured
performance rows equal4.9h exactly;no operating-throughput or clock change.
The latest user asks for lower area and more tests;no acceptance/stage change.

The expanded default `sampler_stage4_9_test` adds54 rejection-burst jobs,
128 malformed byte-count outcomes with same-ID recovery,and24 long-stall jobs.
Source totals are615 successes,182 expected errors,51 aborts,158092 comparisons.
Coverage expands from914 finite bins/20 groups to1721 bins/23 groups:1652 hits,
69 genuine unhit combinations,95.99% raw functional coverage. Code coverage is
reported independently. No impossible bins,weights,exclusions or percentage cap
are introduced to force the requested92-93% number. Missing supported behavior
is verification work;proposed unsupported features remain future work.

Trial4.9i replaces collector priority writes with parallel masked data. It
passes source,Python/C,96 performance cases and5 zero-credit fault gates,but
3780 ALMs/154.87MHz,+0.043ns setup lose to4.9h;rejected and archived create-only
in STAGE4_9I_RESULTS.json/evidence/stage4_9i.zip. Trial4.9j instead shares the
data selector by stable job mode across circular rows;row masks own enables.
Assertions require ordinary/challenge writes retain their job-mode ownership.
Fresh fit,source615/158092,Python104/19456,C48/12288,checker12,performance96 and
5 zero-credit faults all pass. Retain J;archive create-only. Raw DUT code
15084/15790=95.53%,706 unwaived misses. J's first Quartus compile rejected inline
genvar declarations accepted by Questa;using standalone declarations fixes
portability,and all source/vector/performance/fault checks were rerun afterward.

## Active Stage4.9: area optimization of the157.95MHz design

Retained4.9h meets the4.9b priority gate:3624 needed/3753 placed ALMs,3928
registers,4185 ALUTs,one M10K/zero DSP. Worst Fmax161.94MHz,setup+0.325ns/
hold+0.148ns at unchanged6.5ns. Versus4.9b:-239 ALMs(-6.19%),-188 registers,
+1.43MHz;versus4.7s:-495 ALMs(-12.02%),+3.99MHz. All96 CSV rows equal4.9b
and4.7s exactly. Main409/105356,Python104/19456,C48/12288,checker12 and five
fault gates pass. Functional914/914;raw DUT code14991/15698=95.50% with707
unwaived misses. The raw denominator changes with shared/removed storage.
Archive STAGE4_9H_RESULTS.json/evidence/stage4_9h.zip. No user acceptance,
stage advancement,integration,commit or new functional netlist verification.

4.9d keeps shared preparation and rewrites failure updates per context with
unchanged error priority. It measures3700ALMs/159.11MHz and passes every gate,
but remains below4.9b's160.51MHz. Archived,not selected.
4.9e's global no-overlap assumption is rejected:UVM stops at188115ns because
short challenge words can restart unused preparation before phase4. Its fit
was canceled and failure archived;no timing metrics claimed.4.9f removes
acceptance/reset only from phase3 carry payload enables. Ready retains both
qualifiers,so restarting cannot expose old payload. Assertions require ready
only in phase4 and ready low after acceptance. Phase count,input interval and
drain/reuse behavior remain fixed. This targets the measured exhaustion ->
input-ready ->carry-enable path.4.9f passes all gates but measures3743ALMs/
156.96MHz;archived,not selected.4.9g drives challenge byte_last directly from
ball_remaining instead of shared hold_bytes. The two counts are identical
for every valid challenge byte;unused snapshots may differ. This targets the
measured mode/count-selector ->exhaustion path.4.9g passes all gates but
3666ALMs/156.67MHz lose Fmax;archived,not selected.4.9h removes ready/byte-valid
qualification from IDLE RAM address selection. read_valid selects the read
address,otherwise the byte address. Accepted read/byte handshakes alone enter
READ_OUT/COPY,so an unaccepted synchronous read cannot be consumed. Writes,
initialization,abort and state timing are unchanged. H passes the fresh fit
and complete verification gate above;C/D/F/G remain archived intermediate
trials,E remains an archived source failure. No acceptance guard was removed
from ready;only payload capture/address selection was simplified.

4.9c trial,2026-10-19:share input alignment payload between A and mask modes.
At acceptance,encode the shared shift as8*a_byte_carry for A or mask_bit_carry
for mask,and select the owning carry into the shared19-bit snapshot. The same
fine/coarse shifter produces a147-bit aligned stream;A fields/carry are now
derived from that registered stream. The separate138-bit A field register and
16-bit saved A payload disappear. Fine/coarse phases,ready timing and chunk
issue remain fixed. Unused mode outputs may differ;only the accepted word's
mode owns consumption. Invalid metadata and reset/error drain are unchanged.
Use4.9b as the comparison gate:ALMs<3863,Fmax>=160.51MHz,positive6.5ns timing,
and no latency regression in any of96 performance rows. Preserve4.9b if the
fresh fit does not meet this gate. Independent models/main UVM stay unchanged.

Retained4.9b meets the priority gate:3863 needed/3964 placed ALMs,4116 registers,
4396 ALUTs,one M10K,zero DSP. Worst Fmax160.51MHz,setup+0.270ns/hold+0.151ns
at unchanged6.5ns. Compared with4.7s:256 fewer ALMs(-6.22%),220 fewer registers
and2.56MHz higher Fmax. Main409/105356,Python104/19456,C48/12288,checker12,
performance96,five fault gates and all fitted payload guards pass. Every one
of96 performance CSV rows equals4.7s;throughput at153.85MHz is unchanged.
Functional914/914;raw DUT code15280/15987=95.58%. Preserve immutable evidence
STAGE4_9B_RESULTS.json/evidence/stage4_9b.zip. User acceptance still pending;
stay Stage4. This is a measured improvement,not a claim of minimum possible area.

Latest user direction supersedes the proposed native128 continuation:work on
the retained64-bit-chunk architecture. Reduce ALMs while preserving or
improving Fmax and throughput;performance is the main priority. Keep6.500ns
and preserve immutable4.7s/4.8b baselines. No stage acceptance or commit.

First bounded trial4.9a:matrix/mask append at most4 wide coefficients per
token,so share4 rotated wide payload slots across16 destinations. Row masks
own every write;enabled wide destinations are unique modulo4. Secret values
retain16 distinct4-bit rotation slots. Only the wide-data selection changes;
token timing,credit/quota/pointers,buffer depth and external ports are fixed.
Expected original commit payload is4*19+16*4=140 mapped registers rather than
16*23=368. Fitted register guards must verify the expected aliasing while all
secret banks remain present. Independent output models and UVM stay intact.

Measure main UVM,Python/C,performance96,five fault gates,code/functional
coverage and fresh Quartus timing. Retain only if needed ALMs decrease,Fmax
is at least157.95MHz,all96 measured latency rows do not regress,and setup/hold
remain positive at6.5ns. Report any rejected fit rather than hiding the cost.

4.9a measures3986ALMs,156.35MHz,+0.104ns setup/+0.148ns hold. It saves133ALMs
and preserves all96 cycle rows,but loses1.60MHz;not selected for Fmax priority.
4.9b builds on it and preloads only the next unused challenge sign-byte slot
while IDLE. Each context's accepted prefix is protected by its sign-byte count;
the actual byte handshake overwrites the next slot and alone advances that
count. No preload occurs after8 bytes or during COPY/SIGN. Start/reset override
preload. Thus read arbitration is removed from128 payload enables,while the
control count remains exact. Source assertions forbid using sign data before
all8 bytes are accepted. Measure unchanged cycles and fresh timing/area;power
is unmeasured and speculative writes may increase switching activity.

The native128 experiment below is historical;it is not the active work item.

## Stage4.8a complete: native128 trial rejected;4.7s restored

The user authorized this experiment after reviewing4.7s. Stay within Stage4;
acceptance of Stage4 and integration remain pending. Preserve the immutable
4.7s archive as the timing-closed comparison baseline;keep the6.500ns SDC.

The native trial extracts one whole1-16-byte accepted word per non-challenge
token:up to6 matrix candidates,32 secret nibbles,or8 mask fields. Both halves
are processed together;there is no low/high half issue loop. Carry belongs to
the input context and advances once per complete-word issue. Secret compaction
keeps ordered four-nibble groups,merges pairs and halves,and retains narrow
4-bit encoded coefficients until output formatting. Counts/bounds are6 bits
so the all32-accepted case cannot wrap to zero.

Collector depth doubles from32 to64 entries per context to admit32 candidates
while prior output drains. Ring addresses become6 bits and occupancy7 bits;
registered reservation prediction uses64-bound,64-2*bound and64-3*bound with
mode bounds32(secret),6(matrix),8(mask). Pending additions,pop credits,refunds,
quota,append addresses and error/reset cancellation retain ownership checks.
Challenge still uses sequential bytes and its existing conservative room24.
The external output remains one23-bit coefficient per accepted clock. Full-word
extraction is native128 processing,not one new128-bit word every clock.

Verification uses the main UVM and unchanged scalar/Python/C algorithms.
578 new lower/upper population pairs exercise17x17 counts for both eta values;
24 new reset/recovery cases observe extraction,decode,packed and commit on
each context in each non-challenge mode. Legacy adjacent-half reset witnesses
are replaced by separately observed stages;surplus now checks a32-to16 clipped
token. Upper collector occupancy has a new bin;full now means64. Report real
misses,including adjacent-stage combinations not reached by the new schedule.

Compare all96 performance rows with4.7s using
`python sim/sampler/native128_compare.py`. Input blocking overlaps output
transfers and must not be summed with output latency. Measure output bubbles,
candidate peaks,storage,cycles and fresh fitted timing before selecting a
replacement. Fresh fit:8151 needed ALMs,6857 registers,117.74MHz worst Fmax,
setup-1.993ns and hold+0.118ns at6.5ns. This fails the timing requirement and
nearly doubles ALMs. Reject it,preserve its create-only checkpoint/archive,
and restore4.7s RTL/UVM/build scripts. Fresh restoration checkpoint4.8b passes:
4119ALMs,157.95MHz,setup+0.169ns and hold+0.155ns at6.5ns. Main409/105356,
Python104/19456,C48/12288,checker12,performance96 and five fault gates pass;
all96 performance rows and RTL/UVM/model/build hashes match4.7s exactly.
Native128 is not active after restoration. No stage acceptance or commit.

Next bounded Stage4 experiment:retain full-word candidate extraction but
decouple it from narrow ordered collector commits. Pipeline the measured
decode-secret-count -> packed-secret merge path;avoid repeating64-entry wide
collector/read mux doubling. Define pending-word ownership,lower/upper ordered
commit counts,reserved credits,quota clipping,error drain and reset/reuse
before changing RTL. The one-coefficient output remains a separate ceiling;
grouped output would change the external contract and needs a measured choice.

The sections below record the4.7s baseline and earlier history.

**Project:** ML-DSA / CRYSTALS-Dilithium hardware thesis  
**Branch:** sampler_v1, created from main  
**Date:** 2026-10-18  
**Current stage:Stage4.7s frequency objective and6.5ns closure achieved;user acceptance pending.**
**Latest user requirement:150+MHz.** Stage4.7 is active architecture work,not
stage acceptance. The fitter/STA target is now6.500ns=153.85MHz. This tightens
the former100MHz target;immutable4.6r/4.6z archives preserve that baseline.
The two-register-depth/no-cycle-change restriction is superseded where needed
to meet the new frequency objective;every added cycle and buffer is measured.
No target achievement is claimed until fresh worst-corner timing proves it.
4.7a moves secret formatting into a registered output slot;4.7b adds one raw
read slot per context;4.7c registers extraction before local compaction and
adds explicit reservation/quota state. Independent output models remain intact.

**Retained4.7s;frequency and6.5ns timing targets achieved. User acceptance pending.**
Fresh worst Fmax157.95MHz;setup+0.169ns,hold+0.155ns at153.85MHz.4119 needed
ALMs,4224 final-placement ALMs,4336 registers,5038 ALUTs,one M10K,zero DSP.
Main409 complete/54 errors/51 reset aborts/105356 values passes,including18
preparation-phase reset/recovery targets. Python104/19456,C48/12288,checker12,
performance96 and five zero-credit fault gates pass. Defined bins914/914;
raw DUT source code15274/15981=95.58%. All fitted payload/credit/sign guards
pass. No new functional netlist verification or integration. Stay Stage4.

**Archived milestones:**
4.7q measured151.61MHz
at3854ALMs,setup-0.096ns,hold+0.145ns. This meets the150+MHz Fmax goal but
misses6.5ns timing closure. R prefetches challenge bytes without extra cycles
and uses fixed-context sign writes to shorten the remaining paths. All
variants are preserved as create-only JSON/ZIP/SHA256.

R reaches150.13MHz and preserves Q's96 cycle records,but its collector write
enable misses6.5ns by0.161ns. S registers token validity into commit/Ball row
masks,clears those masks on reset,and gates physical writes with each context's
own failure bit. Nonzero masks must have valid active owners;source assertions
check this. Metadata/counter transfer gating remains unchanged. No payload
stage or cycle is added. S's fresh fit and all independent checks pass. All96
performance rows are byte-identical toQ/R. Evidence:STAGE4_7S_RESULTS.json and
evidence/stage4_7s.zip with create-only SHA256. The retained pipeline trades
additional secret cycles for frequency;see THROUGHPUT.md. This meets the
current frequency objective without accepting the next stage. Native128 and
any further architectural improvements remain subject to the existing plan
and user acceptance;continuation does not authorize stage advancement.

Current stage boundaries and ownership:

| Boundary | Data and responsibility |
|---|---|
| Input hold | Stationary128-bit word;low/high chunks consumed separately;challenge byte cursor |
| Input preparation | Registered fine/coarse alignment,then carry extraction;held word cannot issue until ready;no acceptance overlap in4.7l |
| Extraction | Raw candidates plus per-job mode/tag/byte-valid metadata |
| Local compact | Four secret groups and registered accepted population for every mode |
| Packed/admit | Full compact data,clipped coefficient count,reserved append address,row masks |
| Alignment/commit | Rotated payload and write masks;failed tokens cancel writes and return credits |
| Collector |32 words per context;count/ownership reset,payload not bulk-cleared |
| Read slots | One raw pending coefficient per context;counts reflect actual collector fetch |
| Output slot | Canonical23-bit value and tags held until external acceptance |

Archived4.7l continuous single-job latency is302-304 cycles for A,276-297 for secret,
270 for mask and902-969 for Ball. The added input stages are a measured timing
tradeoff;150+MHz and user acceptance remain pending. Native128 lane expansion
is deferred. Reset cancels preparation ownership;errors discard held input
and drain the separately reserved extraction/compact/commit tokens.

Ball readout has a separate commit register and pending-index reservation.
4.7p registers capacity before issue. Both constant thresholds are evaluated
without an occupancy adder:if a chunk issues,current slots must be<=32-2*bound
to permit the next clock's issue;otherwise<=32-bound suffices. Returns and
pops can only decrease next occupancy and are ignored by this conservative
lookahead. A source invariant checks every granted capacity against actual
reservations. Returned credits may cost one extra wait cycle;measure96 rows.

4.7q additionally registers the incoming reservation amount and pop credit
before the counter adder. The counter excludes the just-issued pending amount;
the conservation check is now:counter+pending addition=collector+all pending
stage bounds+refund+pending pop. Every pending addition must match its mode's
bound. Capacity predicts the next clock using thresholds32-bound,32-2*bound,
or32-3*bound according to pending and current issue bits. For secret,bound16
makes the three-bound case impossible,so capacity is false. Ignoring returned
credits is conservative. This changes credit bookkeeping,not payload depth.
Status/reuse waits for all token/read/output ownership to drain. Slot reservation
includes raw-stage bounds,commits,Ball pending work and registered credit returns.
Admission quota tracks uncommitted coefficients separately from generated count.
Independent Python/C/SV reference algorithms remain unchanged. The invalid-byte
overlap test synchronizes to actual pending packed work;its witness gate remains.
Old914 defined bins do not exhaustively cover this expanded pipeline. User
acceptance,expanded-stage verification and150+MHz timing closure remain pending.
The user explicitly rejected treating the existing metrics as satisfactory.
Earlier statements that continuation authorized Stage5 acceptance were the
agent's mistake and are superseded by this correction. Stage5 artifacts remain
historical checkpoint evidence only, not user approval or permission to advance.
No further stage advancement without explicit user approval.

**Current bounded step: Stage4.6 timing optimization.** Preserve the3.3k/Stage5
checkpoint,inspect worst paths,change one bottleneck,run main UVM/Python and a
fresh fit at unchanged100 MHz. Compare area,Fmax,all-corner slack,cycles,
throughput and both coverage metrics. Native128-bit sampling and challenge
acceleration remain separate experiments; actual integration stays pending.

**Current selected candidate4.6r:**3487 ALMs,2445 registers,one M10K,zero DSP;
worst Fmax109.54 MHz,worst setup+0.871 ns/hold+0.147 ns at unchanged100 MHz.
Only sampler.sv changes from preserved4.6e:packed payload registers capture
every clock while packed_valid alone owns their use. No stage or cycle is added.
The original early admission logic and original testbench are retained. All391
complete polynomials/100733 comparisons,Python104/19456 and five fault gates pass;
all96 performance rows equal4.6e. Functional914/914;code8198/8755=93.64%.
Versus4.6e:+5 ALMs,+1.87MHz,+0.159ns setup,+0.005ns hold;this is a modest timing
improvement,not a throughput gain at the fixed100 MHz clock. Acceptance pending.
STAGE4_6R_RESULTS.json preserves this source/fit identity.4.6e remains archived.
Latest revalidation is4.6z after rejecting4.6x/y. All source/testbench/build
hashes match4.6r;no additional RTL change is retained. All trial archives remain.

**4.6x/y rejected after fresh100MHz fits.**4.6x snapshots16 matrix carry bits
and2 byte-count bits at input acceptance,advancing only on a matrix chunk.
Its ownership invariant and all18 fitted bits pass,but3492ALMs/104.50MHz/
+0.431ns setup lose to4.6r.4.6y instead starts from exact4.6r and connects
secret compactors directly to their lane valid/data signals,removing operation
gating before compaction. Tags/valid controls still own consumption. It uses
3494ALMs/106.13MHz/+0.578ns setup,also worse. Both retain one M10K,zero DSP,
both original64-bit secret banks,and unchanged stage depth/cycles. Main391/
100733,Python104/19456,C48/12288,checker12 and5 zero-credit fault gates pass;
all96 performance rows equal4.6r. Separate immutable X/Y archives preserve
these rejected sources/reports;4.6z restores/revalidates exact4.6r.
Next bounded Stage4 review:move part of the secret rotation across the existing
packed register boundary. First derive the owning append address,tail forwarding
and reservation behavior;preserve depth,latency and error/reset cancellation.
This is a new hypothesis,not a measured improvement. No stage advancement.

**4.6v held-beat parameter experiment rejected.** One eta4 bit is captured on
valid-sized input acceptance and used by all four secret lanes across both
halves. A simulation invariant checks its context ownership. No stage/cycle is
added;main391/100733,Python104/19456,C48/12288,checker12 and five zero-credit
fault gates pass. All96 performance CSV rows are byte-identical to4.6r.
The snapshot bit and both64-bit secret banks survive fitting. At the same100MHz,
seed1/device/settings:3510 ALMs,2435 registers,102.27MHz worst Fmax,+0.222ns setup,
+0.145ns hold. This costs23 ALMs and7.27MHz versus4.6r. Source correctness did
not establish a hardware improvement. The immutable4.6v archive preserves this
trial;4.6w restores/revalidates exact4.6r. Next bounded review:matrix byte-carry/
context selection feeding first-stage decoding,alongside collector paths.
Preserve existing depth and cycle records;no promised gain or stage advancement.

**Preserved Stage4.6e benchmark:**3482 ALMs,2412 registers,one M10K,zero DSP;
worst Fmax107.67 MHz,setup+0.712 ns/hold+0.142 ns at unchanged100 MHz.
Collector/decode/packed reservations are calculated per context before selecting
the held context's capacity bit. Same32-slot buffers,chunk bounds and cycles.
Main UVM: 391 complete polynomials, 54 expected errors, 33 reset aborts,
100733 coefficient checks. Functional 914/914 defined bins; raw DUT code
8200/8757 = 93.64%. Python104/19456, C48/12288, checker12/12, performance96
and five coverage fault gates pass. All96 performance rows remain unchanged.

**Synthesis correction:** 4.6a-4.6c hardware improvement claims are withdrawn.
Their source simulations passed, but Quartus dropped the secret-data register
writes and removed all64 packed secret payload bits as constant. Those fits
are archived evidence of a defect, not valid hardware baselines.
4.6d replaces the partial-write loop with one full packed secret assignment.
Fresh synthesis has no undriven decode warning or constant secret-payload
removal; TimeQuest confirms64 decode +64 packed registers. Its report script
now checks these counts. Correct source behavior alone did not validate the
previous mapped hardware. The archived4.6a-c benchmark claims are superseded.

Compare against preserved corrected4.6d:3487 ->3482 ALMs (-5),103.62 ->107.67
MHz worst Fmax (+4.05,+3.91%),setup+0.349 ->+0.712 ns (+0.363). Hold decreases
0.003 ns but stays positive. Fitter duplication adds17 registers;no RTL cycle
was added. Against valid3.3k/Stage5:61 fewer ALMs,7.34 MHz higher worst Fmax.
No change in cycles or throughput at100 MHz. Both slow corners and raw code
bin arithmetic are reported in THROUGHPUT.md/COVERAGE.md. Native128 remains
explicitly deferred. The4.6e path review showed remaining/admit arithmetic:
decode_core_r -> packed_count_r (9.049 ns atSlow0),and matrix byte carry at
8.942 ns atSlow85. The admission trials below did not improve overall timing.
Acceptance remains pending.
**Admission trials4.6f/4.6g rejected:**both passed the same main UVM/Python
checks but worst Fmax fell to102.76/102.05 MHz at3487/3496 ALMs.4.6g's6-bit
tail arithmetic also passed71961 legal cases and the direct-width assertion.
All RTL is restored byte-for-byte to4.6e;fresh revalidation is4.6h.
The only retained change counts64 original secret payload bits separately from
legitimate fitter duplicates in report_paths.tcl;no hardware gain is claimed.
**4.6i/4.6j/4.6k also rejected:**fixed-context carry writes102.36 MHz/3488 ALMs;
cached quota103.51 MHz/3505 ALMs;quota plus late carry-half selection106.16 MHz/
3627 ALMs. All pass391 complete jobs/100733 checks,Python and fault gates with
identical96 performance records. Their whole-design timing is worse than4.6e.
All source/build-script hashes are restored to4.6e/4.6h;fresh revalidation is
4.6l. No RTL performance gain is retained. Read STAGE4_6L_RESULTS.json and
THROUGHPUT.md. Existing trial archives are immutable;new checkpoints use
create-only JSON/archive/SHA256 writes that fail on existing filenames.

**Register-boundary experiments4.6m/n completed and rejected.**4.6m separates
compaction/position snapshot from clipping with a third stage. Raw-candidate
quota and all-stage reservations/draining pass independent checking,including
12 added targeted resets and6 errors followed by same-ID recovery. It fits at
3494 ALMs/96.26 MHz with-0.388 ns setup.4.6n registers the exact next-cycle
reservation,passes its cycle-by-cycle ownership invariant,and recovers to
3519 ALMs/101.95 MHz/+0.191 ns setup. Both are worse than selected4.6e.
Both pass409 complete/60 errors/45 aborts/105340 coefficient checks,Python104/
19456,C48/12288,checker12/12 and five zero-credit fault gates. Their96 performance
rows are identical to each other;explicit per-row deltas versus4.6e are stored
in each result JSON. Continuous A/mask rises262->263 cycles;secret262-273->267-282.
This does not justify replacing4.6e. No new RTL or testbench change is retained.
4.6o restores/revalidates exact4.6e source/build scripts. Archives remain immutable.

**Two-stage experiments4.6p/q rejected:**4.6p moves clipping to packed commit,
preserving all96 cycle records,but its clipped add-back exhaustion check creates
a10.946ns path and89.38MHz/-1.188ns setup at3511 ALMs.4.6q compares raw count
against remaining positions directly;4369 legal count cases and the full suite
pass. It reaches100.63MHz/+0.063ns at3554 ALMs,still worse than4.6e. Both are
archived;their clipping placement and probe changes are removed. The selected
4.6r starts from exact4.6e and retains only unconditional packed payload capture.

**Collector-path trials4.6s/t completed,not selected.**4.6s replaces the secret
formatter case table with equivalentBoolean mapping for all16 binary encodings;
it saves20 ALMs but reaches only106.42MHz/+0.603ns setup at3467 ALMs.4.6t instead
starts from4.6r and registers16 one-hot wide-alignment bits in the existing packed
stage. All16 originals survive fitting;the ownership assertion passes. It saves
8 needed ALMs but reaches104.61MHz/+0.441ns at3479 ALMs. Both pass391 complete
jobs/100733 comparisons,Python104/19456 and all five fault gates;all96 performance
rows are identical to4.6r. Their new worst paths are mask carry selection(4.6s)
and input selection/local secret compaction(4.6t). Area savings alone do not
replace the better timing of4.6r.4.6u restores/revalidates exact4.6r and removes
the trial-only address probe from active reports after archiving it.

**Next bounded work,stillStage4:**review held-beat mode/secret-parameter selection
before the first-stage lane decoder. Consider capturing selected metadata at
beat acceptance,with ownership/reset/error assertions,as already done for mask
working state. Inspect all near-critical paths before implementing one change;
do not repeat rejected formatter/address/quota/depth/late-clipping variants unchanged.
Keep independent references,100 MHz,capacity/cancellation checks and all96 measured
performance rows. Any intentional latency change needs an explicit per-row
comparison. Native128 remains deferred;acceptance pending. No stage advancement
or commit. See THROUGHPUT.md,COVERAGE.md and STAGE4_6U_RESULTS.json.

**Historical checkpoint:** Stage5 functional post-synthesis/post-fit verification complete.
Each distinct implementation netlist passes184 jobs,156 complete polynomials,
24 expected errors,4 reset aborts and39936 coefficient checks;each104-job capture
passes Python19456 values and the captures match byte-for-byte. Source revalidation:
349 main-UVM successes,
54 expected errors,33 aborts,89981 coefficient checks;914/914 defined functional
bins(100%),DUT code93.73%.5 fault kinds each credit0/914 bins. Python104
jobs/19456 coefficients and performance96 polynomials pass. RTL/settings match
the3.3k fit:3543 ALMs,2388 registers,one M10K,100.33 MHz worst Fmax,+0.033 ns setup,
+0.144 ns hold at100 MHz. Full verification pending.
**Next action:** Improve the sampler within Stage4; acceptance remains pending.
Do not import module RTL/create or switch branches without explicit authorization.
100% of defined source bins is not
full verification. Read COVERAGE.md,SAMPLER_VERIFICATION_TESTPLAN.md,
STAGE5_RESULTS.json and THROUGHPUT.md. Remaining code misses are classified,
not formally waived;conditions86.78% and expressions89.58% remain below90%.

## 1. Objective and working agreement

User acceptance means explicit approval of measured results. "Continue" or
"go on" authorizes the current improvement work,not an acceptance-gate crossing.
Correctness and the initial100 MHz baseline are not completion of optimization.

Follow the NTT progression: reconstruct the published architecture; establish
independent output correctness; simulate, synthesize and compare the baseline;
make an architecture decision; improve through detailed UVM verification and
repeated synthesis; verify accepted netlists; then integrate separately.

This is the authoritative sampler roadmap and self-contained new-chat handoff.
The shared docs/POST_MIDYEAR_VERIFICATION_PLAN.md is an older project-wide
recovery plan; its dated milestone statements are historical.

- Reconstruct LightHD's published sampling structure first, not a substantially
  different optimized architecture. Missing authors' RTL/control details must
  be derived and identified, not described as source-identical reproduction.
- Initial compatibility/control decisions are **baseline architectural choices**,
  not claimed improvements. Preserve a decision log before implementation.
- Cover the complete sampling block: matrix A, bounded secrets s1/s2, mask y
  and challenge c. Build in mode-sized increments, but do not compare an A-only
  or rejection-only subset against LightHD's complete sampling block.
- Keep compatibility with current Keccak/NTT interfaces from the start; actual
  combined RTL integration remains a later separate branch/stage.
- Retain one simple Python prepare/compare script and a fast output-capture
  mode separate from full regression. Preserve the SV oracle as well.
- Main UVM owns verification and coverage. Preserve reusable templates and the
  src/tb_uvm/sim/quartus/docs separation.
- Work in bounded stages, announce completion and the next stage, and report
  concrete commands, results and remaining work. Avoid uninterrupted multi-day
  optimization runs. A failed gate must be diagnosed, not silently bypassed.
- Do not commit, push, merge or switch branches without explicit instruction.
  Execution was authorized on 2026-10-16; continue in bounded steps with evidence.

## 2. Sources and existing state

Read these before implementation:

1. [LIGHTHD_SAMPLER.md](../LIGHTHD_SAMPLER.md): user's architecture analysis and
   improvement proposals. Preserve as authored; proposals are hypotheses, not
   proven faults in the publication.
2. [SAMPLER.md](../SAMPLER.md): worked extraction, mask and shuffle examples.
   Illustrative bytes there are teaching examples, not official test vectors.
3. [LightHD paper](../../refernce-paper-hw/2026/LightHD_A_Lightweight_and_High-Performance_Hardware_Accelerator_of_CRYSTALS-Dilithium.pdf):
   Sections III.A/III.C, Figures 3/4, Section III.D, Section IV and Table II.
4. [Final FIPS 204](../../FIPS/NIST.FIPS.204.pdf): coefficient conversion,
   SampleInBall, RejNTTPoly, RejBoundedPoly, ExpandA/S and ExpandMask. Follow the
   final standard where a paper sentence or explanatory note disagrees.
5. dilithium-sw-model/ref/: independent reference. Pin its revision and
   parameter configuration; check compatibility with final ML-DSA first.
6. On ntt_v2: docs/ntt_docs/post_midyear/POST_MIDYEAR_VERIFICATION_PLAN.md,
   FIPS204_NTT.md, NTT_VERIFICATION_TESTPLAN.md, SPECIFICATION.md,
   THROUGHPUT.md and COVERAGE.md. Read through Git when absent locally;
   do not import old experiment/build trees into this branch.

Primary references:

- LightHD: https://doi.org/10.1109/TC.2026.3666457
- FIPS 204: https://nvlpubs.nist.gov/nistpubs/fips/nist.fips.204.pdf
- NIST ACVP ML-DSA: https://pages.nist.gov/ACVP/draft-celi-acvp-ml-dsa.html
- NIST samples: https://github.com/usnistgov/ACVP-Server

Candidate throughput is not accepted-coefficient throughput. SHAKE256 is not
SHA-256. Mask expansion is not coefficient rejection; signature retry is another
separate operation. A is already sampled in NTT representation.

## 3. Functional scope

| Mode | SHAKE | Functional result / parsing | Destination |
|---|---|---|---|
| Matrix A | SHAKE128 | 256 accepted residues; 3 bytes/candidate, clear top bit, accept below q | NTT-domain storage / PWM path |
| Secrets s1/s2 | SHAKE256 | 256 small coefficients; two nibble candidates/byte, eta-dependent rejection/mapping | Forward NTT or eligible Pre-NTT |
| Mask y | SHAKE256 | 256 signed coefficients; continuous 18/20-bit fields, no coefficient rejection | Forward NTT |
| Challenge c | SHAKE256 | 256 values in {-1,0,+1}, exactly tau nonzero; signs, position rejection and indexed shuffle | Controller-selected storage/transform |

| Parameter set | Conventional level | eta | gamma1 | Mask bits/coefficient | tau |
|---|---:|---:|---:|---:|---:|
| ML-DSA-44 | 2 | 2 | 2^17 | 18 | 39 |
| ML-DSA-65 | 3 | 4 | 2^19 | 20 | 49 |
| ML-DSA-87 | 5 | 2 | 2^19 | 20 | 60 |

All polynomials have n=256 and q=8,380,417. Define signed internal widths and
canonical 23-bit NTT-boundary encoding. Seed/nonce construction, byte order and
parameter-dependent challenge seed length follow final FIPS 204. Bounds/count
checks do not replace exact deterministic polynomial comparison.

## 4. Stage overview

| Stage | Work | Exit gate |
|---|---|---|
| 0 | Published structure, required compatibility choices and interface contract | Decision log, initial specification and baseline block diagram |
| 1 | Full LightHD-style reconstruction in four bounded mode substeps | Main-UVM smoke checks for all modes; reconstruction inventory |
| 2 | Independent vectors and exact output comparison | Fresh Python equality, all modes/parameters and failure-path checks |
| 3 | Baseline simulation/synthesis/comparison and architecture selection | Stored baseline, bottleneck evidence and recorded decision |
| 4 | Detailed UVM coverage and measured improvement loop | Traceable verification, current fitted metrics, selected improved source |
| 5 | User acceptance and functional implementation verification | Distinct synthesis/fit netlist PASS results, final timing/docs |
| 6 | Separate Keccak/sampler/NTT integration | Verified data path and measured subsystem behavior |

## 5. Stage 0 - freeze the baseline and required decisions

### 5.1 Published architecture to preserve

- One shared sampling subsystem for two polynomial streams, not two complete
  duplicated samplers.
- Secret path: four 16-bit lanes per 64-bit input, four nibble candidates/lane;
  stable validity compaction, collector and groups of 16 accepted results.
- Matrix path: residual-byte carry, 2/3/3 candidate extraction over three full
  64-bit words, selector/collector and groups of four accepted results.
- Active/saved context concept: Buffer/cnt and BufferA/cntA. Explicit context
  bank indexing may implement the required tagged interface; record the choice.
- Dedicated Mask and SampleInBall functionality; compact challenge storage
  consistent with the published distributed-memory approach where appropriate.
- Keep internal grouping visible even when an adapter serializes outputs.

The authors' full RTL and complete control tables are unavailable. Derive and
verify missing details. Mask/challenge pipelines are less fully described than
rejection sampling; do not invent claims of exact microarchitectural identity.

### 5.2 Required initial decisions - not improvement claims

| ID | Decision | Baseline direction to freeze before coding |
|---|---|---|
| A01 | 128-bit source adaptation | Hold our 128-bit tagged beat and supply ordered up-to-64-bit chunks to the published-width datapath. Preserve valid bytes/tag across both halves. Native 128-bit sampling is a later experiment. |
| A02 | Two contexts | Select complete per-job context from accepted core/job mapping. Our stream may switch frequently; fixed 15/17-beat switching cannot be assumed. Tag selection is required compatibility. |
| A03 | Job lifecycle | Descriptor maps reusable core ID to polynomial ID, mode, parameters and destination. Define start/completion/cancel/reset/reuse; core ID is not a globally unique job ID. |
| A04 | Complete state | Retain residual bytes/bits, parse phase, partial collection, generated/emitted counts, parameters, indices and challenge signs/shuffle/storage ownership as applicable. Resolve simultaneous updates. |
| A05 | Flow control | valid/ready, state updates on accepted transfers, stable stalled output and minimum safe adapter/skid/result storage. Larger performance queues are later experiments. |
| A06 | Output/encoding | Keep internal 4/16-result groups and serialize to one canonical 23-bit coefficient/accepted beat, with job/index/end metadata. Define signed debug format separately. |
| A07 | Routing | A to NTT-domain storage/PWM; secrets and mask to transform path; challenge as directed. Never forward-transform A automatically. |
| A08 | Exhaustion/refill | Define request-more, error/abort and retry behavior. Never pad an incomplete polynomial or restart SHAKE from byte zero as continuation. |
| A09 | Completion | Exactly 256 coefficients; correct final-group truncation, surplus bytes and queued-job isolation. |
| A10 | Missing controls | Derive selectors, challenge indexed update ordering and same-address bypass explicitly; label reconstructed details. |
| A11 | Timing/security policy | Identify variable consumption, public/secret inputs, visible completion/stalls and exhausted-budget handling. Fixed loops alone do not prove side-channel resistance. |
| A12 | Clock/reset/errors | Single clock, defined invalid-command/cancel behavior and supported parameters. Do not inherit an operating frequency silently from NTT. |

### 5.3 Existing module contracts

Snapshot branch commits at implementation start and recheck interfaces if they
change. These contracts were read directly while preparing this plan:

- keccak_v2:src/keccak_engine/keccak_dual_interleaved.sv: 128-bit
  output_data_o, output_valid_o/output_ready_i, output_bytes_o and output_core_o;
  separate request/core assignment, finite requested output length, stop/done.
  Each beat belongs to one core; its halves are not different polynomials.
- ntt_v2:src/ntt_LightHD/ntt_engine.sv: start_i/op_i, busy/done;
  23-bit s_tdata with s_tvalid/s_tready/s_tlast; 256 accepted coefficients/load.
  Current wrapper does not overlap arbitrary polynomial jobs.
- Pre-NTT accepts canonical residues of signed [-4,4]; controller eligibility
  and mode selection must prevent unsupported values.

**Refill gate:** determine whether Keccak can extend an active XOF request after
its configured output length. If not, explicitly choose provisioned requests
with exhaustion/error handling or plan a continuation extension on integration.
A finite budget is not a guarantee that rejection sampling always completes.
Check byte order from RTL/captures. SHAKE128/256 rate blocks are 168/136 bytes;
paper burst labels do not automatically mean complete rate blocks. Do not use
15/17-word boundaries as universal completion rules.

**Deliverable:** SPECIFICATION.md with initial decisions, context lifecycle,
mode routing, block diagram and published/reconstructed/compatibility ledger.
No Keccak or NTT RTL changes on this branch.

## 6. Stage 1 - reconstruct the baseline

Implement four substeps with the same selected interface and main UVM bench:

1. Matrix A: byte carry, extraction, q-check, ordered compaction, grouped output,
   two contexts and exact completion.
2. Secrets: four 16-bit lanes, eta=2/4 mapping, compaction, collector and signed
   to canonical conversion.
3. Mask: 18/20-bit reservoir/unpacking, signed conversion and context-local
   residual bits; no rejection logic in this mode.
4. Challenge: initialization, sign bits, bounded position rejection and shuffle;
   verify same-index/read-after-write behavior and separate live job storage.

Build a minimal **main UVM environment** with driver, monitor, scalar reference,
scoreboard and smoke tests as modes become runnable. It becomes the final bench,
not a collection of disposable non-UVM benches. Use a source model matching the
Keccak pins without importing its RTL. Observe actual DUT outputs.

Check deterministic values, acceptance boundaries, input gaps, output stalls,
context switches and reset recovery. Check indices/order, not only ranges.
Mark unfinished modes pending. No optimization or fitted-performance claims.

**Exit:** all four modes pass main-UVM smoke checks, published structure is
reviewed, adaptations are recorded. Independent vector proof follows next.

## 7. Stage 2 - independent vectors and exact correctness

### 7.1 Establish provenance

The reviewed NIST ACVP documentation exposes ML-DSA KeyGen, Sign and Verify
testing. No standalone sampler input/output suite has been identified for this
plan. This does not mean sampling is unstandardized. Recheck official sources
when implementing the flow and record the discovery result and retrieval date.

If official vectors expose exact sampler inputs and coefficients, retain their
original files/hashes/provenance and use them directly. Full public/private keys
or signatures alone are not standalone sampler expected results. Extracted or
recomputed intermediates must be labeled as derived, not official standalone
vectors. Do not name locally generated expected outputs downloaded NIST vectors.

Otherwise follow the NTT method: independent FIPS-derived Python expected
outputs, cross-checked against pinned software reference behavior. Validate the
reference's final-standard version, parameters, signed/canonical conventions,
seed construction and byte order before using it. Fixed seeds make runs repeatable.

### 7.2 One script, explicit files and separate fast capture

Implemented Stage 2 artifacts (see FIPS204_SAMPLER.md for current commands/results):

| Path | Purpose |
|---|---|
| FIPS204_SAMPLER/sampler_vectors.py | Single prepare/compare script colocated with vector files |
| FIPS204_SAMPLER/sampler_inputs.txt | IDs, modes, parameters, SHAKE byte streams and relevant job/flow schedule |
| FIPS204_SAMPLER/sampler_expected.txt | Independently computed indexed coefficients and completion/error expectations |
| FIPS204_SAMPLER/provenance.json | Sources, revisions/hashes, seeds, generation version and official/derived labels |
| sim/sampler/sampler_dut_outputs.txt | Observed DUT IDs, indices, values, completion/errors and specified consumption counters |
| sim/sampler/vector.log | Capture transcript |
| sim/sampler/compare.log | Exact comparison result |

Two input families: seed/nonce cases expanded by Python SHAKE for realistic
known-answer behavior, and explicit byte streams for rare boundaries/rejections.
Host-generated SHAKE bytes do not prove actual Keccak RTL integration.

Use a dedicated fast sampler_vector_test in the **same main UVM environment**.
It reads inputs and dumps observed DUT results. It must not substitute expected
values for observations. Vector mode skips the full regression and uses separate
output/coverage files. Keep the independent SV model alongside Python.

Runnable commands (checked in Stage 2):

```text
# Repository root
py -3 FIPS204_SAMPLER/sampler_vectors.py prepare

# Fresh Questa session, working directory = sim/
set SAMPLER_MODE vectors
do sampler/run_uvm.do

# Repository root, after successful capture
py -3 FIPS204_SAMPLER/sampler_vectors.py compare
```

prepare creates independent inputs/expected values and invalidates old captures
or attaches a unique manifest ID. Failed/partial capture must not validate stale
output. compare is offline and does not launch synthesis or a full regression.

Compare exact case/mode/parameter/job identity, per-job coefficient order/index,
value, length, specified consumption and status. Define any allowed cross-job
interleaving explicitly. Reject missing, extra, duplicate, malformed or unknown
records. Print mismatch positions, totals and nonzero failure exit status.
Normal completion requires exactly 256 correct coefficients per polynomial.

Keep the distinction between SAMPLER VECTOR CAPTURE COMPLETE and
SAMPLER COMPARE PASS: X/X cases, Y/Y coefficients. Only the latter proves file
equality. Record actual totals, never planned totals as completed evidence.

### 7.3 Required case families

- All modes and all three parameter sets; entire deterministic polynomials,
  different seeds/nonces and identifiers, not just a matching prefix.
- Matrix 0, q-1, q, 2^23-1, top-bit masking, and all byte-carry positions.
- Every secret nibble under both eta values; low/high order, rejection masks,
  all/none accepted, collector near-full and final truncation.
- Mask signed extrema/zero, 18/20-bit alignment and bit carry; exact 576/640
  input bytes per complete polynomial and defined unused-byte handling.
- Challenge sign order, every tau, j=i, j>i rejection, repeated/populated
  positions, same-index updates and initialization. Advance sign only when
  appropriate; exact shuffled output is required, not sparsity alone.
- Switching with partial bytes/bits/output, two live jobs, queue stalls,
  exhaustion, cancel/reset and descriptor reuse; negative metadata cases.

**Exit:** fresh independent comparison passes the agreed case set, main UVM is
clean, and corrupted output-file checker self-tests fail as expected. Create
FIPS204_SAMPLER.md explaining files, commands, provenance and measured results.
This proves the tested cases, not exhaustive correctness or NIST certification.

## 8. Stage 3 - measure baseline and decide architecture

Run existing main UVM, vector capture/comparison and full Quartus map/fit/STA
on the intended Cyclone V device. Save a compact immutable baseline before
optimization: source/settings hashes, tools/device/seed, commands, oracle
provenance, reports, logs and results manifest. Exclude build caches and huge
wave histories. Source correctness gates must remain passing.

Measure each mode/parameter separately, one/two jobs, continuous flow and
controlled stalls. Distinguish source-model sampler tests from actual integrated
SHAKE measurements. Record:

- Input bytes/cycle, candidates/cycle, acceptance fraction, accepted and emitted
  coefficients/cycle, peak versus average and context-switch overhead.
- Accepted-job to last accepted output latency, first-input to first-output,
  inter-job completion interval; state whether load/compute/output overlap.
- Input waiting, processing, output stall, initialize/shuffle/flush clocks;
  per-context and queue occupancy. Do not assign overlapping stalls twice
  when reporting a total cycle breakdown.
- Adapter/collector/serializer cost, compaction path, inferred memory layout,
  ALMs/registers/DSPs/M10Ks/MLABs, logical bits and physical allocation.
- Worst-corner Fmax, setup/hold, TNS, pulse checks, unconstrained paths and
  critical-path detail. State fitter target and operating clock separately.
  NTT's 148 MHz approval does not automatically apply to the sampler.

### LightHD comparison rules

Table II reports the **whole sampling block** at 4,035 LUTs, 1,157 FFs,
0 DSPs and 0 dedicated BRAM on Artix-7; SampleInBall uses distributed memory.
The reported 212.8 MHz is for the full accelerator, not a separate sampler-only
Fmax. Confirm device/speed-grade/version before any cross-paper comparison.

Do not compare our incomplete subset against their entire block, equate ALMs
with LUTs, or equate different RAM/DSP primitives. Report compatibility adapter
costs and internal versus external widths. Where the paper only specifies a
local processing schedule, mark missing per-polynomial cycle evidence unknown.
Do not invent a published number. Report same-device baseline-to-improved
comparisons separately from cross-vendor publication comparisons.

**Decision:** if correct and promising, keep this baseline and begin Stage 4.
If not, diagnose functional/interface/timing issues and present measured
alternatives before a major redesign. Record selected architecture and reason;
do not silently replace the reconstruction with an oversized parallel design.

### Stage 3 measured decision - 2026-10-16

The complete baseline was measured and fitted on 5CGXFC7C7F23C8, seed1,
Quartus25.1 Lite, user-approved100 MHz target. It uses10433 ALMs and3011
registers, with17.15 MHz worst Fmax, -48.304 ns setup, +0.146 ns hold and
-77359.334 ns setup TNS. No RAM was inferred; the intended challenge memory
became logic. All source UVM/Python gates remain passing. Main-UVM performance
checks96 polynomials/24576 coefficients across72 scenarios. A/secret/mask take
260 clocks per single continuous job; challenge takes899-966 over the sampled
parameters/seeds. See THROUGHPUT.md and STAGE3_RESULTS.json for definitions.

**Performance selection fails.** Retain this source/settings/report checkpoint
as a reference, not the selected performance implementation. The largest local
cost is top control/compaction/collectors (~8447 ALMs); the critical35-level path
runs from active_r through repeated generated_n/Add/count logic into hold_data_r.
The shared published-width structure remains the direction; evidence points to
implementation corrections before a major architecture replacement.

**Historical Stage3 decision: 3.1 corrective pass.** Replace the dependent per-candidate
count/append chain with bounded parallel count/position logic and efficient
collector writes; pipeline if required. Recheck all value/protocol gates and the
same measurement set, then fit at unchanged100 MHz. Repair challenge RAM
inference in a separate measured change. Do not start full Stage 4 coverage
expansion or claim an improvement before fresh comparison supports selection.
These corrections restore an efficient intended baseline; they are not by
themselves a claim of novel work beyond LightHD. Actual integration stays separate.

### Corrective checkpoints - 2026-10-16

Stage3.1 parallel prefix compaction/once-per-chunk counts/fixed collector writes:
5343 ALMs,45.36 MHz Fmax, -12.048 ns setup. Source/vector/performance gates pass;
cycle counts unchanged. Saved as STAGE3_1_RESULTS.json/evidence/stage3_1_compaction.zip.

Stage3.2 isolated synchronous challenge RAM:4356 ALMs,1985 registers,one M10K,
44.79 MHz Fmax, -12.326 ns setup,+0.147 ns hold. Fmax slightly regresses versus3.1;
retain for18.47% further ALM savings and real RAM mapping. Source gates pass:
47 smoke polynomials/12704 coefficients; Python104 jobs/19456 coefficients;
C48 cases/12288 coefficients; checker12/12; performance96 polynomials/24576
coefficients/72 scenarios. All96 measured CSV rows match earlier checkpoints.
Current manifest STAGE3_2_RESULTS.json and evidence/stage3_2_ram.zip.

**Recorded next step after3.2:3.3 measured-path pipelining.** The critical13-level path is
hold_core_r -> collector_r[1][16][1],22.010 ns data delay. Separate extraction,
compaction and collector commit as needed; explicitly account for pending entries,
tags/order, capacity, reset/error cancellation and the final256-value cap.
Repeat independent value/protocol/performance checks and full100 MHz fit. Report
extra clocks/stalls honestly. These corrections precede full Stage4. Target is
not relaxed. At that checkpoint no100 MHz timing closure was claimed;
3.3k closes the standalone internal gate below. No LightHD performance win is claimed.

### Stage3.3k fitted checkpoint (before Stage4.1 test expansion)

3543 ALMs, 2388 registers, one M10K, 100.33 MHz worst Fmax, setup +0.033 ns and hold +0.144 ns at 100 MHz; functional checks pass; standalone internal timing passes at 100 MHz. Candidate history3.3a..k, scope and exact current
code/cycle/all-corner results are in THROUGHPUT.md/STAGE3_3K_RESULTS.json.
Main UVM52 complete/19 errors/11 aborts/13917 coefficients. Python104 jobs/
19456 coefficients,C48 cases,checker12/12 and performance96 polynomials pass.
This was the entry gate to Stage4; Stage4.1 results and the next gate follow.
No full acceptance or commit.

## 9. Stage 4 - detailed UVM verification and improvements

### Stage4.1 historical record

Completed:12 success-gated groups with38 coverpoints and17 crosses; all16 ordered
live-mode pairs,16 transitions on both contexts,secret accepted counts0..16,
mask/matrix boundary fields,long stalls and active-peer ID-reuse checks. Main UVM
178 complete/19 expected errors/11 aborts/46173 coefficients passes. Coverage:
574/589 raw functional bins=97.45%,15 misses; equal-group mean98.48% is a separate
weighting. Raw DUT code7697/8267=93.11%. Injected first-output corruption raises
COEFFICIENT fatal before any credit; its separate UCDB has0/589 functional hits.
Python104 jobs/19456 coefficients,C48 cases,checker12/12 and performance96
polynomials pass; all96 performance rows match3.3k. No RTL/settings change or
new fit. See COVERAGE.md,STAGE4_1_RESULTS.json and evidence/stage4_1.zip.

Next Stage4.2: implement checked error/reset/recovery and internal occupancy/
pipeline/challenge-state coverage, address the15 reachable success gaps, and
classify code misses. The current high percentage applies to implemented
success-path bins; additional planned requirement families are still open.

### Stage4.2 historical record

17 groups/65 coverpoints/26 crosses now include checked error outcomes,reset
records released after exact recovery,prior-outcome lifecycle,pipeline/collector
activity and owned challenge states/edges. Main UVM229 complete jobs,44 expected
errors,25 reset aborts/59261 coefficient comparisons passes.773/785 functional
bins=98.47%,12 genuine misses;DUT code7708/8267=93.24%. The original15 success
misses are closed; all12 success groups100% does not close the broader plan.
Five separately injected faults each fail with the expected checker fatal before
any successful/error/reset credit; each database has0/785 functional bins.

Python104/104 jobs/19456 coefficients,C48 cases/12288 coefficients,checker12/12
and performance96 polynomials pass. All96 performance rows and RTL/settings
hashes match3.3k; no new fit was needed. The zero-only DUT report classifies
3 missing statements,4 branches,19 conditions,14 expressions and519 toggles.
No code exclusion or guard removal was made. See COVERAGE.md/STAGE4_2_RESULTS.json
and evidence/stage4_2.zip. Corrected an explanatory bin-label error from4.1:
Questa b[6] means value6,so missing masks were carry6 with1/7 bytes.

Next Stage4.3:the12 reachable crosses (2 peer-error cases,8 reset mode/core/param
cells,2 A/mask final-clipping cells),simultaneous pending statuses and targeted
error-abort/defensive-guard code-miss tests. Preserve functional invariants and
independent references. Any RTL change must repeat100 MHz fit. Stage5 still
requires user acceptance; no commit.

### Stage4.3 record and next bounded step

Added all12 remaining functional cells:live-peer exhausted/parameter errors,
8 reset mode/core/parameter combinations,A/mask final candidate clipping.
Added completion_arbitration with exact checked jobs for both pending statuses
in all4 modes. Accepted bad metadata during challenge COPY reaches registered
failure in SIGN;expected errors and same-ID recovery pass. High16-bit job-ID
patterns verify full tag width. Checked activity CSV links clipping/dual-status/
wrap/occupancy witnesses to independently validated successful jobs.

Main UVM257 complete(A62,secret74,mask58,challenge63),48 expected errors,
33 reset aborts,66429 coefficient comparisons passes.18 groups/69 points/28
crosses,807/807 defined functional bins=100%;DUT code7736/8267=93.58%.
Conditions104/121=85.95%,expressions83/96=86.46% remain below90%. No exclusions
or fabricated holes. Both pending statuses verified does not prove the still
unhit unlocked tie-selection branch;SIGN error-abort hit does not cover COPY/
READ_OUT abort terms. Guards remain intact. See COVERAGE.md for classified misses.

Python104 jobs/19456 values,C48 cases,checker12/12,performance96 polynomials
and5 fault-injection classes pass. Each negative database0/807 functional bins,
zero success/error/reset/activity credits. All96 performance records and RTL/
settings hashes match3.3k;no fit was rerun. Evidence:STAGE4_3_RESULTS.json and
evidence/stage4_3.zip. Earlier checkpoints are preserved. No commit.

Next bounded Stage4.4:adversarial idle-source-tag/blocked-descriptor/source-stop
protocol tests,reproducible randomized data/partitions/scheduling,additional
requirement coverage where justified and remaining code-gap reachability review.
Full coverage of the current finite model is not full sampler signoff. Stage5
netlist verification still waits for user review/acceptance; any RTL change
must repeat the unchanged100 MHz fitted timing gate.

### Stage4.4 record and next bounded step

Added idle-input, busy-descriptor and post-source-stop refusal probes on both
contexts. Eight mode/core jobs validate busy/stopped witnesses after their256
outputs and OK status match. Idle refusal credits require independent absence
of ownership. These are eight-clock nonaccepted offers, then valid withdrawal;
they do not cover every valid-holding producer transition.

Added72 random polynomials (3 seeds *4 modes *3 parameters *2 cores) with random
input bytes,1..16-byte partitions,0..7-clock source gaps,interleaving and readies.
Data/source/ready PRNG states are separate. Scalar SV oracle remains unchanged.
Seeds13579BDF,2468ACE1,DEADBEEF; successful-job activity rows retain each seed.
Two full runs reproduce six checked witness/summary CSV hashes.

Main UVM337 complete (A82,secret94,mask78,challenge83),48 expected errors,
33 aborts,86909 checks=337*256+637 partial coefficients.20 groups/76 points/
31 crosses:914/914 defined functional bins100%; raw DUT code7742/8267=93.65%.
Conditions85.95% and expressions86.46% remain open; no exclusions or RTL changes.
Python104/19456,C48/12288,checker12/12 and performance96 polynomials pass.
Five separate faults each credit0/914 bins and zero witness rows.
RTL/settings and all96 performance rows match3.3k; no new fit or speed claim.
Evidence:STAGE4_4_RESULTS.json and evidence/stage4_4.zip; prior archives preserved.

Next bounded Stage4.5: review remaining code misses for reachable test cases,
document proven constraints separately from untested behavior, and prepare
source-verification acceptance evidence. Do not force internal DUT state just
to raise percentages or claim unreachable without proof. Full Stage4 signoff
remains pending. Stage5 post-synthesis/post-fit verification requires user
acceptance first. Any RTL change repeats the unchanged100 MHz fit gate.
No commit,push,branch change,netlist or board verification in Stage4.4.

### Stage4.5 record and acceptance boundary

Targeted reachable misses using public channels: simultaneous bad-byte input
and invalid peer descriptor create both status eligibilities on the same edge.
Prime each round-robin turn,check unlocked state and both chosen cores,then
verify both error statuses and exact same-ID recovery. Final secret-beat
surplus is held by backpressure after generated=256,exercising its cleanup.
Initialized challenge IDLE receives malformed metadata and recovers exactly.

Corrected monitor event ordering: refused offers describe pre-edge ownership
and publish before accepted status retires the context. A stopped valid held
through status acceptance checks this case on both cores. No RTL,clock,
Quartus setting or reference-formula change; no state forcing or code exclusions.

Main UVM349 complete (A88,secret96,mask80,challenge85),54 expected errors,
33 reset aborts and89981 coefficient checks=349*256+637 partial comparisons.
20 groups/76 points/31 crosses remain914/914 defined bins100%. Code increases
by7 bins to7749/8267=93.73%:statements628/630,branches423/425,conditions105/121,
expressions86/96,toggles6507/6995. Conditions86.78%/expressions89.58% remain open.
COVERAGE.md records the integrated scheduling/range arguments and untested
fault/producer behavior; these are not formal unreachability proofs or waivers.

Python104/19456,C48/12288,checker12/12,performance96 polynomials and five
fault-injection gates pass. Negative runs each0/914 bins and zero witness rows.
Two full runs reproduce six checked witness/summary CSV hashes;all96 performance
records and RTL/settings match3.3k. No new fit. Evidence:STAGE4_5_RESULTS.json,
evidence/stage4_5.zip and SHA256 sidecar;all previous archives remain preserved.

Stage4.5's bounded tests/review are complete;full Stage4 acceptance remains
pending user review of these results and unwaived gaps. After acceptance,
Stage5 will produce real post-synthesis/post-fit netlists and main-UVM checks.
Do not add placeholder launchers or claim board/I/O/security/integration signoff.
No commit,push or branch change was requested or made.

### 9.1 Requirements and coverage plan

Create SAMPLER_VERIFICATION_TESTPLAN.md with every feature/requirement, stimulus,
observation, independent check/assertion, coverpoint/cross, sample condition,
expected behavior and evidence artifact. Explain what a hit proves, where its
logic lives and which test/checker justifies it. Start with the existing bench;
do not bypass it with another non-UVM coverage environment.

Coverage families:

- Mode x parameters x contexts and operation transitions.
- Candidate boundaries/lane placement, rejection masks and stable compaction.
- Input valid-byte counts and mode-specific residual byte/bit alignments.
- Collector occupancy, simultaneous append/emit, flush and 256th coefficient.
- Input gaps, output stalls and stalls during context switch/completion.
- Job/core mapping, routing, ID reuse, reset/cancel/recovery and error behavior.
- Mask extrema and field alignments; challenge signs/positions/repeated-index
  memory hazards, exact polynomial and tau-dependent nonzero count.
- Internal FSM states/transitions and real arithmetic/selector conditions.

Cross interacting requirements, not arbitrary enormous Cartesian products.
Only scoreboard-accepted **observations** credit functional coverage; requested
transactions alone are not proof. Checkers must reject deliberate corruptions
without coverage credit, using separate self-test databases. Assertions
supplement exact output comparisons rather than replace them.

Collect code coverage only from DUT hierarchy; report statements, branches,
conditions, expressions, toggles and FSM states/transitions. Define overall
aggregation and show raw hit/total counts. Use >=90% meaningful functional/code
coverage as an initial review goal with category-level misses visible. The
previous 90-91% NTT review range is not a cap. Never suppress real hits or invent
bins to obtain a preferred percentage. Justify exclusions and prioritize
remaining functional risk even after percentages look good.

### 9.2 Improvement inventory from both sources

These candidates combine the user's LIGHTHD_SAMPLER.md and earlier discussion.
They are hypotheses, not proven publication defects. Anything required by
Stage 0 is baseline compatibility and must not be counted again as an improvement.

| ID / origin | Experiment | Evidence and constraints |
|---|---|---|
| I01 - both | Native 128-bit sampling; matrix 5/5/6 candidates over three full beats and up to 32 secret nibble candidates/beat | Compare against the same 128-to-64 baseline adapter; include partial words, rejection, compactor timing, area and fitted clock. Full beats every clock are only a peak assumption. |
| I02 - both | More elastic scheduling/context handling beyond mandatory two-job correctness | Measure switch cost, stalls and realistic arbitration. Extra contexts or batching are optional; keep complete descriptors. |
| I03 - prior discussion + wider-path notes | Balanced/prefix compaction, staged muxes or pipelining | Use measured critical paths; preserve job tags and ordering through pipelines, context hazards and cancellation. |
| I04 - user notes | Mode-specialized decoding with selective sharing of extraction/formatting/storage | Sharing may increase mux cost. Measure all four modes; do not claim unified logic is automatically smaller. |
| I05 - both | Tuned input/coefficient queue depths | Show occupancy, fewer producer/consumer idle cycles and RAM/logic cost. Finite buffers do not solve sustained bandwidth mismatch. |
| I06 - both | NTT-compatible packing, wider writes and reduced staging traffic | Current NTT is serial; actual interface changes belong to later integration decisions. A is already NTT-domain. Measure transfer savings, not only candidate rate. |
| I07 - both / earlier NTT plan | Small-secret Pre-NTT regrouping and packing | LightHD already has this feature. Assign one owner so sampler and NTT do not both execute the first stage. Verify exact ordinary-NTT equivalence and eligibility. |
| I08 - both | Sampling/NTT overlap, ping-pong storage, queued jobs and improved scheduling | LightHD already overlaps sampling and NTT; demonstrate an additional benefit, respect operand dependencies and measure full completion intervals. |
| I09 - prior discussion | Lower-overhead refill/exhaustion management | Baseline correctness already requires safe handling. Reduce stalls without altering the distribution, repeating SHAKE bytes or returning incomplete output. |
| I10 - both | Memory/MLAB/register packing and serializer/formatter efficiency | Inspect depth/width/ports and physical allocation; judge logic, RAM, Fmax and net throughput together. |
| I11 - user notes | Later challenge-shuffle optimization | Preserve repeated-index sequential semantics and memory hazards; missing authors' datapath detail limits exact claims. Defer aggressive parallel shuffle initially. |
| I12 - user notes + prior discussion | Timing/information-flow review | Examine visible stalls/refills and secret-state behavior; fixed loops alone are insufficient. Functional tests do not prove power/EM/timing resistance. |

Do not use the notes' earlier Keccak-only GB/s benchmark as measured sampler
performance. Use actual seed/nonce lengths, XOF output requests, burst patterns
and backpressure. KeyGen/Sign/Verify gains cannot be measured until those full
paths exist. Label intermediate subsystem models explicitly.

### 9.3 Bounded improvement loop

#### Inventory status after Stage4.6e

| Item | Actual state / remaining work |
|---|---|
| I01 native128-bit sampling | NOT implemented;128-to-64 adapter remains. Deferred by user;evaluate compute/input/sink bottlenecks before proposing widening |
| I02 elastic scheduling | Tagged contexts/backpressure are baseline compatibility;further queue/scheduling gains unmeasured |
| I03 compaction/pipelines |4.6e selected/revalidated4.6l;f/g/i/j/k rewrites rejected;4.6a-c fitted gains withdrawn;register-boundary experiment is next |
| I04 mode specialization | Narrow secret payloads/separate A packing/mask carry extraction present in corrected4.6d;further gains unmeasured |
| I05 queue depth |32/context retained;depth trade-offs unmeasured |
| I06 NTT packing | Serial23-bit contract remains;wider transfer savings unimplemented |
| I07 Pre-NTT | NTT owns eligible transform;no duplicate sampler transform;actual path integration pending |
| I08 sampling/NTT overlap | Actual overlap NOT implemented;separate integration work,not a claimed gain |
| I09 refill | Correct exhaustion/status handling exists;additional refill performance unmeasured |
| I10 storage/serializer | One M10K/circular collectors retained;4.6e saves61 ALMs versus valid3.3k;output width/challenge cycles unchanged |
| I11 challenge acceleration | Sequential899-966 cycles unchanged;optimization outstanding |
| I12 information flow | No constant-time/side-channel signoff;output correctness is insufficient |

Evaluate the remaining inventory explicitly. Passing correctness/initial100 MHz
cannot mark it complete. Stay in Stage4 until explicit user approval.

For each candidate: state hypothesis and acceptance metric; preserve the selected
checkpoint; change one feature; run focused UVM/vector checks; run the agreed
full regression; map/fit/STA and critical paths; compare equal workloads/device/
constraints; retain or reject based on correctness, cycles, clock and resources.
Update the decision/results log. Run broader tests only for a concrete risk/gate.

Do not claim Fmax from simulation or synthesis estimates. Do not relax the clock
silently to obtain positive slack. Agree an operating frequency based on fresh
reports and retain benchmark constraints separately. Rejected candidates need
small evidence records, not many active RTL trees and build caches.

**Exit:** selected improved source, current full regressions/vector comparison,
traceable coverage with genuine gaps, fresh fitted reports and user review.
Return to the Stage 3 decision gate before a major architectural departure.

## 10. Stage 5 - acceptance and implementation verification

Begin after the user is satisfied with the selected source implementation:

1. Freeze source/settings hashes, tool/device/seed, modes and approved operating
   clock. Report worst setup/hold/TNS/pulse checks and applicable I/O constraints.
   Internal/virtual-pin timing is not physical board-interface closure.
2. Generate **distinct** post-synthesis and post-fit functional netlists from
   the frozen build; record hashes and generation commands. Do not simulate
   the same netlist twice under different labels.
3. Reuse main UVM with adapters for hierarchy-dependent source observations.
   Retain external value/protocol checks for all feasible modes/parameters,
   interleaving, stalls and reset. Label netlist exclusions and reasons.
4. Use supported Cyclone V vendor-library functional simulation; do not promise
   unsupported SDF timing simulation. TimeQuest supplies timing evidence.
   Check initialized memories and reset behavior in both implementations.
5. Require explicit PASS markers and exact compared job/coefficient totals,
   zero unexpected errors/fatals and fresh artifacts. A zero process exit alone
   is not a pass. Do not merge netlist statistics into RTL code coverage claims.
6. Update specification, testplan, vector report, throughput, coverage and pins.
   Keep board/UART and full-system work explicitly pending unless performed.

### Historical Stage5 execution record - 2026-10-18

The agent incorrectly interpreted continuation after Stage4.5 as acceptance.
The user rejected that interpretation. These performed tests remain checkpoint
evidence;they do not authorize Stage5 acceptance or moving to integration.
Source condition/expression gaps remain documented and unwaived.

Frozen3.3k source/settings and fit-report hashes match. No RTL change/new full
fit. Distinct netlists come from a separate synthesis-only helper and the active
fitted database; their hashes differ. Cyclone V10905 gives functional post-fit
only,no SDF. TimeQuest remains timing evidence (setup+0.033 ns,hold+0.144 ns,
minimum pulse-width+3.346 ns,zero setup/hold TNS at100 MHz,physical I/O excluded).

Both main-UVM netlist runs pass184 jobs:104 file jobs plus80 extra successes.
Totals per implementation:156 complete,24 expected errors,4 reset aborts,
39936 coefficients=156*256. Python independently matches each104-job capture
with19456 values. The two captures are byte-identical. Added cases include72
seeded random polynomials and8 mode/core admission/completion cases. Source
349-polynomial regression,96-polynomial performance test,Python/C checks and
five coverage-gating faults pass again;checked CSVs/performance rows unchanged.

Netlist source_probes=0 skips internal snapshots/occupancy assertions and
phase-targeted stimulus. External scalar equality,reset/recovery,valid-byte,
tag/index/last/status,stall stability/refusal checks remain. Source-only groups
stay unsampled;raw730/914=79.87% per netlist is not source coverage100% or a
merged total. External scheduling/transition/error/lifecycle gaps also remain.
Source code remains7749/8267=93.73%;netlist gate code is not measured.

Exactly3 .do launchers now exist in sim/sampler:run_uvm.do,
run_post_synthesis.do,run_post_fit.do. Shared Tcl is netlist_common.tcl;
Quartus export is generate_netlists.ps1;UVM remains under tb_uvm. One Python
script retains prepare/compare/selftest. Prepare after testbench edits;never
bypass its source freshness guard. See FIPS204_SAMPLER.md for exact commands.

Evidence:STAGE5_RESULTS.json,evidence/stage5.zip and SHA256 sidecar. Prior
checkpoints preserved. No commit/branch change/import,board/UART,actual subsystem
integration,physical I/O or security signoff. Next:Stage6 planning and explicit
integration-branch authorization before bringing module RTL together.

## 11. Stage 6 - separate integration

Create/select the integration branch only when explicitly authorized. Combine
accepted Keccak, sampler and NTT snapshots there, keeping module baselines intact.

- Verify real Keccak request-to-sampled-polynomial behavior with independent
  seeded expectations, not only a modeled byte producer.
- Check per-job tags/nonce/parameters, partial valid-byte beats, refill/exhaustion,
  cancellation/reuse, upstream backpressure and downstream memory ownership.
- Route A directly to NTT-domain storage/PWM operands. Route eligible secrets
  through forward NTT or the single-owner Pre-NTT path. Route y/challenge as
  required by the arithmetic schedule.
- Verify against serial/batched reference computations before adding overlap.
- Measure SHAKE waiting, sampling, queue occupancy, NTT load/compute/output and
  completion intervals. Wider ports alone do not prove a system gain.
- Full KeyGen/Sign/Verify benchmarking and official full-operation ACVP checks
  follow implementation of the remaining controller/arithmetic/encoding paths.
  A working Keccak-sampler-NTT subsystem is not a complete ML-DSA accelerator.

## 12. Folder structure, documents and tool experience

```text
src/sampler/                         selected sampler RTL only
tb_uvm/tb_uvm_sampler/                main UVM, reference, monitors/checkers
tb_uvm/tb_uvm_reusable/               shared UVM templates
sim/sampler/                        simulation launchers and outputs
quartus/sampler/                     project, constraints, scripts and reports
FIPS204_SAMPLER/                     one Python script and vector artifacts
docs/sampler_docs/                   existing explanatory notes
docs/sampler_docs/post_midyear/      controlled plan/specification/results
```

Keep shared standards, papers, software model and common project notes. No
Keccak/NTT RTL or unrelated experiment builds on this module branch. Do not
remove unrelated local files as part of implementing this plan. Maintain one
selected active RTL implementation and compact baseline/accepted evidence.

| Document / artifact | When and what to maintain |
|---|---|
| SAMPLER_PLAN.md (this file) | Now; stage gates, decisions, accepted/pending status, next-session handoff |
| SPECIFICATION.md | Stage 0; modes/parameters, data domains, interfaces, timing/reset/error contract and architecture decisions |
| SAMPLER_VERIFICATION_TESTPLAN.md | Minimal requirements in Stage 1; full features/tests/checkers/assertions/coverage traceability before Stage 4 expansion |
| FIPS204_SAMPLER.md | Stage 2; official/derived provenance, file format, one-script flow, commands, exact results and study order |
| THROUGHPUT.md | Stage 3 onward; per-mode boundaries/cycles/rates, stalls/overlap assumptions, resources/clocks and publication comparison limits |
| COVERAGE.md | Stage 4; covergroup/checker locations, sampling rules, what verifies each hit, actual functional/code results and misses/exclusions |
| SAMPLER_VIRTUAL_PIN_CONFIG.md | Once ports freeze; signal/direction/width/reset/meaning table and actual Quartus virtual-pin assignments; no invented package pins |
| Compact checkpoint/result manifests | Stage 3 onward; source/settings/oracle hashes, commands/tool/device/seed, logs/reports and selected/rejected decisions |

Create documents when useful evidence exists; do not fill empty result tables
with anticipated values. Add command examples that were actually checked and
explain output artifacts in a beginner-friendly order.

Exactly three `.do` entry points once runnable:

- run_uvm.do: default main UVM with GUI, waves, functional and code coverage;
  optional separate vector/checker modes using distinct output/databases.
- run_post_synthesis.do: functional post-synthesis main-UVM run.
- run_post_fit.do: functional post-fit main-UVM run.

Run from sim/. GUI must retain loaded design, meaningful nonzero waves and
coverage panes. At completion print measured functional coverage and DUT code
categories plus a clearly defined overall code total directly in **Questa
Transcript**, not only an external terminal. Save coverage immediately and
support batch runs. No extra vector `.do` or disposable non-UVM coverage bench.
Do not create nonfunctional launchers/projects and call them implemented.

Quartus GUI: open QPF and Start Compilation without manual SDC edits. Distinguish
benchmark and approved operating clocks with reproducible constraint selection.
Ignore caches/libraries/WLF/UCDB while retaining compact evidence for thesis claims.

## 13. Current status and handoff to another chat

| Item | Current verified state |
|---|---|
| Branch/scaffold | sampler_v1; existing uncommitted setup/user files must be preserved |
| User's LIGHTHD_SAMPLER.md and SAMPLER.md | Read; not modified |
| Detailed staged plan | Written here |
| Stage 0 decisions/specification | Contract frozen; continuous Keccak XOF strategy confirmed from source |
| Sampler RTL and main UVM |4.6e:391 complete (A88,secret138,mask80,challenge85),54 expected errors,33 aborts;100733 coefficient comparisons |
| Current source coverage |20 groups,914/914 defined bins100%,code8200/8757=93.64% across12 DUT instances;5 negative kinds each0/914 bins;misses unwaived |
| Python / independent vectors | Stage 2 PASS: 104/104 jobs, 19456/19456 coefficients; 76 complete, 24 expected errors, four aborts; 48 seed cases match C; 12 corruption checks rejected |
| Sampler synthesis/netlist results |4.6e:3482 ALMs/2412 registers/one M10K/107.67 MHz worst Fmax/+0.712 ns setup/+0.142 ns hold at100 MHz;64+64 secret payload registers confirmed.4.6a-c hardware claims withdrawn;Stage5 netlists apply only to3.3k |
| Measurements/decision |96 checked polynomials/72 scenarios;cycles unchanged;netlist raw730/914 bins per implementation,source-only groups unsampled;no merged percentage |
| Acceptance / integration | NOT ACCEPTED. Stage4 optimization resumed;Stage5 tests are historical checkpoint evidence only. No stage advancement without explicit approval. Actual integration,board/I/O/security work pending |

### Paste into a new chat

> CURRENT OVERRIDE:Stage4 optimization;user acceptance PENDING.4.6e
> is active:3482 ALMs,2412 registers,one M10K,107.67 MHz worst Fmax,+0.712 ns
> setup/+0.142 ns hold at100 MHz;391 complete/100733 checks,code93.64%,
> functional914/914. Read STAGE4_6L_RESULTS.json. All96 cycle records unchanged.
>4.6f/4.6g passed correctness but were slower;both rejected.4.6h revalidates
> byte-identical4.6e RTL with an improved original-bit/duplicate diagnostic guard.
>4.6i/j/k also pass correctness but are slower;all source/build scripts restored.
>4.6l is revalidation,not a new RTL design. Checkpoints are create-only.
> Native128 deferred. Next:register-boundary experiment with explicit latency,
> reservation and error/reset-drain checks;stay in Stage4. User acceptance pending.
>4.6a-c fitted claims WITHDRAWN:Quartus dropped secret data;4.6d fixes the full
> packed assignment and confirms64+64 mapped registers. Compare to valid3.3k.
> Old
> Stage5 acceptance interpretation was WRONG;do not advance on "continue".
> Preserve3.3k/Stage5 archives. Netlist launchers block mismatched candidate
> source;do not regenerate/advance stages without explicit approval. Broader
> native128/challenge work remains;see inventory status in section9.3.

> Work in D:/GitHub/dilithium-hp-hw on sampler_v1. Inspect git status.
> Read `AGENTS.md` and `docs/sampler_docs/post_midyear/SAMPLER_PLAN.md` completely.
> Also read `docs/sampler_docs/LIGHTHD_SAMPLER.md` and `docs/sampler_docs/SAMPLER.md`.
> Preserve existing user-authored and uncommitted files. Read the current status
> plus SPECIFICATION.md, STAGE0_DECISIONS.md and STAGE1_RESULTS.md. Stage 0 is
> complete and Stage 1.4 all-four-mode baseline passes main UVM. Stage 2 also
> passes independent Python comparison (104 jobs, 19456 coefficients) plus 48 C
> seed cases and 12 checker self-tests. Read FIPS204_SAMPLER.md and
> STAGE2_RESULTS.json. Read THROUGHPUT.md and STAGE3_3K_RESULTS.json.
> Current3.3k: 3543 ALMs, 2388 registers, one M10K, 100.33 MHz worst Fmax, setup +0.033 ns and hold +0.144 ns at 100 MHz. Internal timing passes at 100 MHz.
> Stage4.5 main UVM349 successes/54 expected errors/33 aborts/89981 values;
> Python104 jobs/19456 coefficients and performance96 polynomials pass. Read
> COVERAGE.md and STAGE4_5_RESULTS.json:20 checked groups,914/914 defined bins,
> 93.73% code;5 fault kinds each0/914 bins. RTL/settings match existing3.3k fit.
> 72 random jobs/3 seeds and idle/busy/stopped refusal probes pass;two full
> runs reproduce six checked witness/summary CSV hashes. Both unlocked status
> choices,held surplus and initialized challenge abort/recovery pass. Refusal
> monitor events publish before status retirement. Code gaps are classified,
> not formally waived;conditions86.78%/expressions89.58%. IMPORTANT:the user did
> NOT accept these metrics. Stage4 optimization is resumed. Earlier acceptance
> interpretations in Stage5 artifacts are incorrect and superseded by this plan.
> Read STAGE5_RESULTS.json only as historical evidence:distinct post-synthesis
> and post-fit functional netlists each pass184 jobs,156 complete,24 errors,
> 4 reset aborts,39936 comparisons. Both104-job Python captures match19456
> values and each other. Source-only probes/groups are disabled/unsampled;
> netlist raw730/914=79.87%,no RTL gate-code/SDF claim. Source revalidation
> and all96 performance rows are unchanged. Three .do launchers are runnable.
> Next:Stage4.6 timing optimization;no stage advancement without explicit approval.
> Do not import module RTL/create or
> switch an integration branch without explicit user authorization.
> Defined-bin100% is not full sampler signoff. No guards/
> code exclusions were changed; preserve100 MHz and independent references.
> Preserve the reconstructed shared two-context 64-bit sampler baseline and its
> documented sequential challenge RAM controller. Adapt to our tagged
> 128-bit Keccak output and 23-bit serial NTT sink; baseline compatibility is
> not a performance improvement. Read module contracts using git show instead
> of importing their RTL. Preserve the implemented one-script Python
> prepare/compare flow, fast main-UVM capture mode and independent SV oracle.
> Recheck vectors after RTL changes; locally calculated intermediates
> are FIPS-derived, not downloaded standalone NIST vectors. Then simulate/fit
> each correction at unchanged100 MHz, compare with the archived baseline and
> fairly with LightHD, and update the architecture decision,
> and broaden UVM/coverage while improving measured bottlenecks and rerunning
> synthesis. Announce stage transitions, work in bounded sessions and record
> evidence/results/next action. After user acceptance, verify distinct functional
> synthesis/fit netlists and maintain spec/testplan/vector/throughput/coverage/
> virtual-pin docs. Actual system integration is separate. Current state is
> four-mode UVM/vector verification for the recorded cases, not full sampler signoff. Do not commit, push
> or change branches without instruction.

### End-of-session record

```text
Stage/substep and decision/hypothesis:
Files changed:
Source/settings/reference hashes:
Commands, tool/device/seed:
Functional PASS/FAIL and exact comparison totals:
Coverage definitions, hit/total counts and misses:
Cycles/rates and measurement boundaries:
Resources, operating clock/Fmax, worst setup/hold/TNS:
Evidence paths:
Selected/rejected candidate and reason:
Remaining risks and exact next action:
Commit status (only if explicitly authorized):
```
