# Sampler specification

## Current retained Stage4.9r: shorter mask arithmetic,original pipeline

External ports,64-bit chunk issue,32 entries/context,stage depth,canonical
23-bit output and every measured cycle remain unchanged fromJ. Matrix and
mask collector values are canonical;secret4-bit encodings are converted by
the existing shared output formatter. The attempted raw-mask readout variants
K..N are archived and are not the active architecture.

Only `mask_coefficient` arithmetic changes relative toJ. With fixed
q=2^23-8191,gamma=2^17 or2^19,and normalized field t:

- Lower half:base=gamma;subtract t in20 bits and prepend000.
- Upper half:base=gamma-8191;subtract t in20 bits and prepend111.
- t=gamma is explicitly zero. Other upper-half results equalq+gamma-t.

The bases are0x20000/0x1e001 at18-bit fields and0x80000/0x7e001 at20-bit
fields. The operation stays before packing,so collector/readout ownership
and output arbitration do not acquire arithmetic dependencies. The original
challenge-read active qualifier and all original payload/mask guards remain.
Six extra main-UVM jobs check zero and borrow boundaries on both contexts/all
params,using the unchanged scalar oracle.

Implementation settings:seed1,HIGH PERFORMANCE EFFORT,
PHYSICAL_SYNTHESIS_REGISTER_RETIMING OFF,clock6.500ns. Fresh fit3537 placed
ALMs,3931 registers,4256 ALUTs,one M10K/zero DSP;worst Fmax164.74MHz,
setup+0.430ns/hold+0.141ns. All original structural guards pass unchanged.
R reuses O's source validation only after hash identity;all96 performance
records equalJ. Main621/159628,Python/C/checker/fault gates pass. No native128,
new functional netlist verification or integration. Evidence:STAGE4_9R_RESULTS.json.

## Stage4.9j mechanisms retained by4.9r

The complete4.9h pipeline/interface contract below is retained. The only
functional RTL refactor is collector write-data selection. Each context's
stable SAMPLE_BALL flag selects challenge data or ordinary aligned commit
data once per16-bank index;the two circular rows share that selected payload.
The registered row-mask OR and per-context failure flag own the write enable.
No job can change mode until all old tokens drain. Source assertions require
disjoint challenge/ordinary row masks and matching job mode on every write.

This removes per-row priority data selection while preserving both write
sources,32 entries/context,reset/error cancellation and every pipeline cycle.
No inputs,outputs,latencies,clock constraint or independent model change.
Fresh fit3628 placed ALMs,3928 registers,4405 ALUTs,one M10K/zero
DSP;worst Fmax163.16MHz,setup+0.371ns/hold+0.161ns at6.5ns. All96 performance
rows equal4.9h. Source615 successes/182 expected errors/51 aborts/158092 values
and independent Python/C/fault gates pass. StillStage4;native128 not active.
Evidence:STAGE4_9J_RESULTS.json. No new functional netlist or board signoff.

## Stage4.9h mechanisms retained by4.9j

Same external ports,64-bit chunk issue,32-entry collectors,pipeline depth and
cycle counts. A/mask share the131-bit fine alignment and147-bit registered
stream. At acceptance,the shared shift/carry encode A byte alignment or mask
bit alignment. A fields derive from this stream;the separate138-bit A field
bank and16-bit saved A payload are removed. Only the accepted word's mode
owns outputs. Fitted guards confirm the shared banks and zero separate A bank.

Failure equations are per context with unchanged priority:short final commit,
challenge exhaustion,invalid byte count,new descriptor parameter,prior error.
Carry payload captures on phase3;ready remains reset/acceptance-qualified.
Short challenge words can restart preparation before phase4;assertions require
ready low after acceptance and ready high only in phase4. Reset may change
unowned payload but cannot expose it. Challenge last uses its own remaining
count;IDLE RAM address selects read_valid else byte address without ready
qualification. FSM transitions keep full handshakes;only accepted operations
consume synchronous RAM data. Writes/clear/abort schedules are unchanged.

Fresh fit3624 needed ALMs,3928 registers,161.94MHz,+0.325ns setup/+0.148ns
hold at6.5ns. Main UVM/Python/C/fault gates pass;96 performance CSV rows are
identical to4.9b. No operating-throughput increase or power/board claim.
Evidence:STAGE4_9H_RESULTS.json. Native128 is not active;stillStage4.

## Stage4.9b mechanisms retained by4.9h

External interface,32-entry collectors,64-bit chunk issue,output ordering and
pipeline depth are unchanged. Matrix/mask append<=4,so wide aligned payloads
share4 rotated slots using append address bits1:0;destination row masks still
use full5-bit circular addresses. An enabled group contains no modulo4 alias.
Secret appends retain16 distinct4-bit rotation slots. Fitted original commit
payload is140 bits(4*19 upper+16*4 lower),with all64-bit secret stages preserved.

While the challenge engine is IDLE,each incomplete context preloads its next
unused sign-byte slot. Previously accepted bytes are untouched. Only a real
input-byte handshake advances sign_bytes,and writes the valid byte to its
slot on that edge. After8 accepted bytes no preload is allowed. COPY/SIGN
cannot consume signs before all8 bytes are accepted. Start/reset override
preloads. This removes read arbitration from wide sign-payload enables without
adding cycles. All128 fitted sign bits survive;power has not been measured.

Fresh fit:3863 needed ALMs,4116 registers,160.51MHz worst Fmax,+0.270ns setup/
+0.151ns hold at unchanged6.5ns. Main UVM/Python and all96 performance rows
pass;the rows are byte-identical to4.7s. Timing is internal only;no new netlist,
board or integration verification. See STAGE4_9B_RESULTS.json.

## Archived native128 experiment:Stage4.8a (rejected)

The archived trial processes both halves of a valid1-16-byte non-challenge input
word together. Matrix extraction has6 candidate lanes,secret has8 parallel
16-bit lanes(32 nibbles),mask has8 field slots. Only valid input bytes count;
carry remains per-context and advances once per full-word token. One token
can accept32 secret coefficients,so token counts/bounds are6 bits. Two64-entry
collectors use6-bit circular addresses and7-bit occupancy. Reservation bounds
are matrix6,secret32,mask8. Eight ordered four-nibble groups compact through
pairs and halves;secret data stays4-bit encoded until output formatting.

External ports,output ordering,burst sizes,error/status semantics and the
sequential challenge algorithm are unchanged. Output remains one23-bit
coefficient per accepted clock. Input capture/preparation still takes several
clocks;native128 does not mean a new128-bit beat can be accepted every clock.
Trial source verification passes,but8151ALMs,117.74MHz and-1.993ns setup fail
the required timing/area tradeoff. The full trial is archived and4.7s source
is restored. Current hardware again issues64-bit halves and uses32-entry
collectors. The4.7s measurements below describe the retained baseline.

## Retained Stage4.7s architecture;acceptance pending

The150+MHz objective is achieved. Fresh4.7s worst Fmax157.95MHz;setup+0.169ns,
hold+0.155ns at the permanent6.500ns=153.85MHz constraint,all corners passing.
4119 needed ALMs,4224 final-placement ALMs,4336 registers(4243 implementation+
93 router),5038 ALUTs,one M10K/1024 logical bits,zero DSP. User acceptance is
pending inStage4;no new functional netlist,board or integration signoff.
Older100MHz results below are historical.

Input capture -> three preparation phases -> extraction -> local compaction ->
packed/admit -> aligned commit -> per-context collector/read -> shared output.
Preparation registers fine/coarse mask alignment,matrix fields and both halves'
carry state. One beat owns the preparation payload until its chunks retire;
each128-bit beat still issues64-bit chunks. Native128 processing is deferred.
Reservations cover issued chunks through commit;quota clips surplus values.
Capacity is registered using conservative current-slot thresholds32-bound or
32-2*bound after an issue. Returns/pops can only decrease next occupancy and
are ignored in the prediction;an invariant checks actual room on every grant.
The counter now applies registered pending additions and registered pop credits.
Capacity includes the pending addition and current issue,requiring thresholds
32-bound,32-2*bound,or32-3*bound;the last case forbids secret grants. The exact
conservation invariant includes delayed additions,returns,and every raw stage.
Errors drain pending reservations before status/reuse;reset cancels ownership.
After status retirement,unowned count/credits clear together on the first
inactive clock. A new descriptor initializes both if the slot is reused then.
The challenge RAM uses an issued-read index and registered conservative room
flag;assertions include its outstanding RAM result and commit token. A room
threshold24 permits at most25 stored values plus2 outstanding,below32 slots.
R prefetches the next challenge byte into8 registers,with exact held-byte
ownership asserted;fixed-context sign writes avoid the selected sign-count
mux. All96 performance rows are byte-identical toQ;no measured cycle is added.
S includes token validity in registered collector/Ball row masks,clears masks
on reset,and cancels writes with each context's local failure bit. Nonzero
masks must own valid active tokens. Global metadata/count transfer gating is
unchanged;this removes the shared selected-context enable from physical writes.
External ports,23-bit canonical coefficient serialization and independent
sampling reference formulas are unchanged. See SAMPLER_PLAN.md for boundaries.

## Archived Stage4.6r baseline

Archived Stage4.6r: 3487 ALMs, 2445 registers, one M10K, zero DSP; worst Fmax
109.54 MHz, setup +0.871 ns and hold +0.147 ns at unchanged 100 MHz.
Main UVM: 391 complete polynomials, 54 expected errors, 33 reset aborts,
100733 coefficient checks. Functional 914/914 defined bins; raw DUT code
8198/8755 = 93.64%. Python104/19456, C48/12288, checker12/12, performance96
and five coverage fault gates pass. All96 performance rows remain unchanged.

4.6r retains the original decode/packed depth,early admission,per-context
reservations and cancellation logic. Packed payload registers now capture
every clock;their values may change in invalid cycles. packed_valid owns every
consumer,so invalid payload does not commit or earn coverage. No RTL register,
stage,interface or reference formula is added. The fitter uses2390 implementation
registers+55 router registers=2445. Both original64-bit secret banks remain.
Only sampler.sv changes from preserved4.6e;STAGE4_6R_RESULTS.json records the fit.
At the fixed100 MHz clock,cycles and throughput remain unchanged. Power has
not been measured;the timing result does not establish a power improvement.
Latest revalidation:STAGE4_6Z_RESULTS.json. Trials4.6s/t reduce area but worsen
timing and are not selected. Their formatter/address metadata/assertion changes
are archived and removed. All active source/testbench/build hashes match4.6r.
Trial4.6v captures one secret eta flag at beat acceptance;the ownership
invariant and independent checks pass with unchanged cycles. Its fitted bit
survives,but3510ALMs/102.27MHz/+0.222ns setup are worse. The snapshot/assertion
is archived and removed;4.6w restores/revalidates exact4.6r. No interface,
stage,latency or functional capability is added by the rejected experiment.
Trials4.6x matrix carry snapshot and4.6y direct secret compaction also pass the
independent checks/unchanged96 cycle rows,but worsen fitted timing/area. Both
are archived and removed.4.6z restores/revalidates exact4.6r,including its
original operation-gated compactor inputs and selected-context matrix carry.

4.6e calculates collector+decode+packed reservations independently per context.
Each compares against32-minus-chunk-bound:secret16,matrix29,mask28. Only then
is the held context's capacity bit selected. Reservations/admission behavior
and32-slot buffers are unchanged;there is no extra state or pipeline cycle.
Preserved4.6e has2412 fitted registers;current4.6r has2445. Their implementation/
router breakdowns are recorded in THROUGHPUT.md.

The candidate retains local secret compaction and prepares mask carry shifts for both
64-bit halves at128-bit beat acceptance. Metadata belongs to the held beat;
an invariant checks shift + new carry bits = chunk bytes*8 when fields exist.
An unfinished first field still combines saved and incoming bits. No extra
sampling cycle or external interface/formula change. Native128 remains deferred.

**Synthesis correction:** 4.6a-4.6c hardware improvement claims are withdrawn.
Their source simulations passed, but Quartus dropped the secret-data register
writes and removed all64 packed secret payload bits as constant. Those fits
are archived evidence of a defect, not valid hardware baselines.
The decode_secret_r loop used outer-dimension part-select writes; replacing
these with one complete packed assignment preserves bit order and prevents
the observed synthesis loss. Both secret stages now contain64 mapped registers;
report_paths.tcl rejects an unexpected count. This structural check does not
replace eventual functional netlist verification. Acceptance pending.
Preserved4.6e revalidation is STAGE4_6O_RESULTS.json.4.6f/4.6g
admission experiments were slower and are rejected. The retained diagnostic
change requires64 original register bits per secret stage,excluding legitimate
router~DUPLICATE copies.4.6i/j/k carry/quota/extraction experiments also passed
correctness but worsened timing;the source/build scripts were then restored
to4.6h before the current4.6r payload change.
Third-stage experiments4.6m/n pass expanded source verification but are slower
than4.6e and add latency. They are rejected;the selected design still has only
decode and packed stages. No quota/compact-stage/reservation register is retained.
4.6p/q late-admission placement is also rejected. Selected4.6r instead changes
only packed payload capture as described above. Future changes must measure
latency and preserve cancellation. After4.6s/t,the next review is held-beat
parameter/mode selection before the first-stage decoder,within existing depth.
4.6d/4.6e archives remain preserved;earlier sections below are historical.

**Stage4 optimization resumed;user acceptance pending.** Previous Stage5
verification is checkpoint evidence only. No advancement/integration is approved.

Date: 2026-10-16. Stage 0 contract frozen for incremental implementation.
Stage 1.4 implements all four modes: matrix A, secrets, mask and challenge.
Source main-UVM smoke checks and Stage 2 independent Python/C/vector checks pass
for the recorded case sets. See FIPS204_SAMPLER.md. Current Stage3.3: 3543 ALMs, 2388 registers, one M10K, 100.33 MHz worst Fmax, setup +0.033 ns and hold +0.144 ns at 100 MHz.
Status: functional checks pass; standalone internal timing passes at 100 MHz. See THROUGHPUT.md/STAGE3_3K_RESULTS.json.
Stage4.5 main UVM checks349 complete jobs,54 expected errors,33 reset aborts and
89981 coefficients.20 groups include checked errors,recovered resets,success-gated
internal snapshots,dual completion arbitration,refusals and seeded random jobs.
All914 defined functional bins hit;DUT code93.73%;5 fault kinds each0/914 bins.
72 random polynomials/3 seeds and idle/busy/stopped refusal probes pass.
Two complete runs reproduce six checked witness/summary CSV hashes.
Both unlocked status choices,held surplus and initialized challenge abort/recovery
pass. Monitor checks refused offers against pre-edge ownership before retirement.
RTL/settings remain fitted3.3k. See COVERAGE.md/STAGE4_5_RESULTS.json.
Code gaps are classified without waivers. The user continued to Stage5 on2026-10-18.
Distinct synthesized/fitted functional netlists each pass184 jobs,156 complete,
24 expected errors,4 reset aborts and39936 comparisons. Both104-job captures
pass Python19456 coefficients and match each other. Optimized hierarchy probes
are disabled explicitly; external scalar checking stays enabled. No RTL or
fitted metric change. Read COVERAGE.md/STAGE5_RESULTS.json for scope and exclusions.

## Architecture

```text
Tagged 128-bit SHAKE output + valid-byte count
             |
       one-beat holding adapter
          ordered 64-bit chunks
             |
     shared mode-specific datapath
             |
       two saved job contexts
       registered candidate/packed stages
       circular grouped collectors
             |
   tagged 23-bit coefficient serializer
             |
   destination storage / NTT adapter
```

The matrix datapath extracts 2/3/3 three-byte candidates from successive full
64-bit chunks, preserves zero/one/two residual bytes per context, clears each
candidate's high bit and accepts values below 8,380,417. Stable compaction feeds
groups of four. The secret path uses four explicit 16-bit lane modules and
groups of 16. Eta=2 applies to parameter encodings 0/2; eta=4 to encoding 1.
Each lane examines low-first nibbles, rejects unsupported values and converts
accepted signed coefficients to compact four-bit codes, restored to canonical residues at collector write. Matrix and secret jobs may
be live simultaneously; mode and parameter are stored per context.
Mask expansion now has a dedicated four-field 64-bit unpacker plus per-context
19-bit residual storage/count. It consumes consecutive 18-bit fields for
parameter 0 or 20-bit fields for parameters 1/2, and maps t to gamma1-t,
converted to a canonical residue. No coefficient rejection occurs in this mode.
This requires exactly 576/640 bytes for 256 coefficients. Partial byte words,
context switches and backpressure preserve the bit stream.

Stage3.3h snapshots the mask carry, bit count and field width when a valid
input beat is accepted. A working copy feeds both64-bit halves and advances
on each consumed chunk; the same update saves the selected job's persistent
carry. Holding a beat blocks acceptance of another beat, so a later beat sees
the committed carry. Reset clears beat ownership, and every new accepted beat
initializes the working state. No additional pipeline clock is introduced.
Stage3.3j zeros invalid bytes when accepting the128-bit beat. The mask unpacker
therefore requires zero above its byte count; it uses that count to determine
complete fields/carry, without repeating byte masking on its feedback path.
Stage3.3k retains the accepted128-bit payload unchanged for non-challenge jobs.
A half selector chooses low64 then high64 bits; capacity controls this selector
and the byte count rather than rewriting the wide holding register. Challenge
continues shifting one byte per accepted byte handshake. No extra clock is added.

Mask uses four-result output groups and the existing serializer. Four-field
extraction/grouping is our documented reconstruction: the paper does not expose
its complete Mask microarchitecture. These are baseline reconstruction choices,
not measured improvements.

### Stage 3.1 initial correction (archived; current staging below)

sampler_compact.sv uses four levels of parallel prefix addition to compute the
stable rank of each valid candidate among up to16 candidates. A onehot rank
selection packs candidates in their original order. The chunk's accepted count
is capped once by 256-generated, then generated/collector counts update once.
Four stages rotate the packed results to the post-pop collector append position;
each collector register has one fixed append condition. Output groups, reserved
capacity, tags, 32-entry per-job storage and serial output behavior are retained.

For example, validity [1,0,1,1] yields inclusive ranks [1,1,2,3]; valid source
positions0,2,3 become packed positions0,1,2. If only two polynomial entries remain,
only the first two are appended. The input holding register no longer waits on
16 successive generated-count updates to decide completion.

Matrix carry is zero-extended according to its actual zero/one/two-byte count.
Only valid low input bytes may affect the polynomial. Main-UVM drivers now set
unused high input bytes to FF to enforce this interface requirement. This caught
and corrected a carry-masking bug in the first unaccepted refactor. The original
Stage 3 baseline and its reports are preserved before implementation corrections.

### Stage 3.3 registered pipeline

The shared non-challenge path now has three clocked operations: extract a
64-bit chunk into candidate registers; compact/admit into packed registers;
commit packed results into the collector. Each pending stage retains its core
tag and finite-input-end flag. Mode/parameter/ID remain owned by that context
until status acknowledgement, which also waits for both pending stages to clear.
The data registers need no reset because reset clears their valid bits.
Candidate payload registers capture every clock; only decode_valid_r grants
ownership. This removes the capacity-check signal from payload clock enables.
Unused payload values have no architectural effect; their extra switching has
not been evaluated for power or side-channel behavior.

Secret candidate payloads use four-bit two's-complement internally, sufficient
for[-4,+4]. The four published16-bit input lanes and their rejection/mapping
rules are unchanged. A16-lane/four-bit compactor packs secrets; a separate small
three-lane/23-bit instance packs matrix candidates. These share the input adapter,
admission counters, contexts, collector and serializer. Mask fields bypass data
compaction. Candidate registers are explicitly sized for their mode payloads,
rather than padding16 secret words to23 bits. The collector write stage restores
canonical23-bit residues (e.g.4'hF -> q-1). Collector entries/output encoding
remain identical for every mode, with no extra pipeline cycle.

Stage3.3i also registers the collector append address with the packed payload.
It captures tail_n for the candidate's context, including any older append
committing in that clock. Pops affect only the head. Consequently the captured
address equals that context's tail when the packed chunk commits. This removes
the context-selection mux before collector alignment; capacity, ordering,
polynomial truncation and finite-source/status barriers are unchanged.

Capacity accounting includes committed collector entries, an upper bound on
decoded candidates and the exact packed count, before admitting another chunk.
It uses the existing32 entries per context; no deeper FIFO was added. All modes
can use that capacity while preserving four/16-result output arbitration groups.
Polynomial admission subtracts the packed stage's reserved positions from the
remaining256-entry budget. The generated count advances at collector commit.
Surplus pending chunks admit zero entries; error/reset cancels pending work and
an already offered output group still drains before error status. Stale pipeline
data cannot survive reset or cross descriptor reuse.

The collector now uses five-bit circular head/tail pointers over the same32
register entries. Pop advances only the head; append addresses derive from the
registered tail, independent of a simultaneous pop. Five-bit modular offsets
select fixed write banks, and the shared rotation uses the tail's low four bits.
Challenge readout appends at its context's tail too. A source-only invariant
checks tail-head equals committed occupancy modulo32, including the full case.
The output reads the selected head combinationally; that read mux is excluded
from the internal timing benchmark by its existing I/O exceptions. Actual sink/board
timing still requires integration constraints or an output register.

The mask extractor masks invalid high bytes, aligns a whole64-bit word once,
then uses fixed18/20-bit field and carry slices. Candidate registers hold raw
mask fields and a saved width flag. Because mask fields are contiguous without
rejection, the packed stage converts them directly, bypassing the compactor's
data mux. Thus alignment and coefficient subtraction occupy separate existing
stages without an extra clock. Saved carry stays zero above its declared bit
count. Conversion splits t into its gamma-sized upper-half bit and lower bits:
the lower half gives gamma-low; the upper half gives -low modulo q, with zero
handled explicitly. Examples: t=0 gives gamma, t=gamma gives0, and t=gamma+1
gives q-1. The independent reference formulas and external interface are
unchanged. Secret packed storage remains four-bit; collector write performs
canonical conversion after narrow alignment. A/mask wide words use direct bank
selection. Occupancy updates once per fixed context for append minus pop.
These internal changes require fresh measured cycles; the old
260-cycle non-challenge result is historical. THROUGHPUT.md records each fit.

### Challenge / SampleInBall

sampler_ball.sv contains one shared sequential controller and a 512-entry,
two-bit memory: 256 entries per context, encoding zero, +1 and -1. A new
challenge clears its 256 entries serially; memory contents have no bulk reset.
Both contexts retain their own 64 sign bits, sign-byte count, position counter,
initialization state and done/exhausted flags. The first eight bytes supply
little-endian signs, consumed least significant bit first. Parameter encodings
0/1/2 select tau=39/49/60, hence starting positions 217/207/196.

A candidate byte j is rejected if j>i. An accepted position performs a synchronous
read of old c[j], a separate copy write c[i]=old c[j], then a sign write c[j]=+/-1.
Only acceptance advances i and consumes a sign. The separate writes preserve
j==i semantics and repeated-position read-after-write dependencies. No coefficient
is emitted until the complete shuffle is immutable. A read request then transfers
one stored coefficient into the existing collector; challenge output groups
contain four canonical 23-bit results, including zeros.

CLEAR, COPY, SIGN and READ_OUT share the memory controller. Initialization and
completed-output reads can stall another challenge's byte processing. The shared
128-bit holding adapter consumes challenge bytes one at a time and retains the
remainder while the controller is busy. This bounded baseline deliberately does
not unroll dependent indexed updates. The historical Stage3/3.1 implementations
failed RAM inference and mapped the array into logic/registers. Stage3.2 isolates
one synchronous RAM port in a process with no array/read-register reset; writes
are suppressed on reset/abort. The controller still clears each context before
reading it, and ignores read-during-write data. Fitted mapping is recorded in
THROUGHPUT.md: Stage3.2 confirms one M10K/1024 logical bits, no MLAB,
1985 total registers. Quartus AUTO selects common-address simple dual port;
MLAB is unsuitable for this address width. LightHD specifies distributed RAM but does not publish
this exact controller; compact storage and its cycle schedule are explicit
reconstruction choices, not a claim of source-identical RTL or improvement.

Finite input ending before the last required accepted position reports EXHAUSTED,
with no challenge polynomial output. Ending on the final accepted position is
successful after its copy/sign writes. Surplus bytes in the final accepted beat
are discarded. source_stop asserts when the shuffle finishes, before serialization
of all 256 entries. Reset cancels initialization, signs, shuffle and output state;
slot reuse performs a new clear, preventing stale memory from becoming output.

## Interface contract

All transfers occur on rising clk when valid and ready are both asserted.
Reset is active high and synchronous. All command/data/response payloads must
remain stable under stall; reset explicitly cancels both jobs and pending output.

| Port | Direction | Bits | Meaning |
|---|---|---:|---|
| clk, rst | input | 1 each | Clock and synchronous reset |
| job_valid_i / job_ready_o | input/output | 1 each | Descriptor transfer |
| job_core_i | input | 1 | Context slot, matching assigned Keccak core |
| job_id_i | input | 16 | Controller's polynomial identifier |
| job_mode_i | input | 2 | 0=A, 1=secret, 2=mask, 3=challenge |
| job_param_i | input | 2 | 0=ML-DSA-44, 1=65, 2=87; 3 invalid |
| input_data_i | input | 128 | Consecutive SHAKE bytes, earliest in bits 7:0 |
| input_bytes_i | input | 5 | Valid contiguous low bytes, 1..16 |
| input_core_i | input | 1 | Context for the whole beat |
| input_last_i | input | 1 | Optional finite-source exhaustion after this beat |
| input_valid_i / input_ready_o | input/output | 1 each | Source transfer |
| output_data_o | output | 23 | Canonical coefficient in 0..q-1 |
| output_core_o, output_id_o | output | 1,16 | Result context/job |
| output_index_o | output | 8 | Polynomial index 0..255 |
| output_last_o | output | 1 | Index 255 |
| output_valid_o / output_ready_i | output/input | 1 each | Coefficient transfer |
| status_valid_o / status_ready_i | output/input | 1 each | Completion/error transfer |
| status_core_o, status_id_o | output | 1,16 | Completed/failed descriptor |
| status_code_o | output | 3 | 0=OK, 1=source exhausted, 2=unsupported mode, 3=invalid parameters, 4=invalid byte count |
| active_o | output | 2 | Slot owned until its status is accepted |
| source_stop_o | output | 2 | Stop producing for this slot; held until status acceptance |

Two descriptors may be live, one per slot. Never reuse a slot until its status
has been accepted AND the integration controller has stopped/drained its old
Keccak source. A core ID is not a globally unique job ID. No independent cancel
command is exposed initially: coordinated reset aborts both jobs. Per-job cancel
needs a separate future protocol decision and tests.

The input adapter holds at most one 128-bit beat and presents its low bytes
first, then its high bytes. It retains tag and last across both chunks. Per-slot
collectors now hold up to 32 results to support a secret chunk appending up to
16 results when at most 16 are already buffered. All non-challenge modes reserve space for pending tokens within the same32
entries; matrix chunks append at most three results. Collector and group
counters were widened accordingly; this is required secret baseline capacity. This is minimum bounded elastic storage, not a deep
performance FIFO. Output arbitrates groups of four (A/mask/challenge) or 16 (secret);
within each job all coefficients remain ordered. A group stays selected during
backpressure. Do not wire interleaved jobs blindly into a single NTT polynomial:
the future destination adapter must demultiplex to tagged storage or restrict
job admission. No integrated throughput claim follows from this serial port.

Success is reported only after 256 accepted output coefficients. Sampling stops
when 256 values have been generated (challenge stops its source at shuffle completion); surplus bytes/candidates from its final
accepted beat are discarded, not transferred into another job. Error status may
follow a partial result prefix: the entire failed polynomial must be discarded
by the destination. An already offered output group drains before error status;
other pending coefficients are discarded. Stalled payloads remain stable until
accepted or reset, including when the job encounters an error. Invalid idle-source tags are
not accepted. Malformed valid-byte counts on an active source are accepted and
fail that job. No zero padding and no repeated SHAKE prefix on exhaustion.

## Keccak and NTT contracts inspected

Keccak branch fe54a782e3df9ed684dc960b0067b39ce323289d exposes tagged 128-bit
output with low-byte order, valid-byte count and ready/valid. Its core explicitly
defines output_len_i=0 as continuous output; stop_i is sampled in SQUEEZE.
Baseline integration uses continuous SHAKE and drives stop for a completed job.
The controller must handle stop acknowledgement, already offered data and
request reuse. A bounded stream uses input_last_i from a controller tracking its
requested length; Keccak has no equivalent last pin on this output port.
No live length-extension operation is required for the continuous strategy.

NTT branch 577a34b2fff19864cb16b490b7629ed211613000 accepts one 23-bit
canonical coefficient/beat, 256 beats/load with separate operation command.
Matrix A is already NTT-domain and routes to operand storage/PWM, not forward
NTT. Small secrets can use ordinary or eligible Pre-NTT; the existing Pre path
already owns its first-stage transformation. Sampler does not apply it again.

## Timing and limits

The original Stage3 and intermediate fits are archived. Current: 3543 ALMs, 2388 registers, one M10K, 100.33 MHz worst Fmax, setup +0.033 ns and hold +0.144 ns at 100 MHz.
Status: functional checks pass; standalone internal timing passes at 100 MHz.
Next: Stage6 separate actual Keccak-sampler-NTT integration planning.
See COVERAGE.md. Conditions86.78%/expressions89.58% remain below90%.
Input consumption and visible stalls vary with data/flow; no constant-time or
side-channel-resistance claim is made. Cryptographic distribution and exact
ordering must be preserved. Any fixed-budget production policy needs explicit
failure handling. Synthesis/timing measurements follow the plan's Stage 3 gate.
