# sim/sampler

## Current source regression

Run in the Questa GUI Transcript from `sim/`:

```tcl
do sampler/run_uvm.do
```

Default:`sampler_stage4_9_test`,621 complete polynomials,182 expected errors,
51 reset aborts and159628 coefficient comparisons. Six additional mask jobs
check zero/modular-borrow boundaries in both widths and on both contexts.23 functional groups;
1652/1721 raw bins=95.99%,69 open bins. Waves,coverage and raw DUT code totals
appear in Questa itself. `sampler/smoke_checked_robustness.csv` records checked
rejection/stall witnesses; `sampler/smoke_functional.rpt` lists exact bins.
Code coverage and hardware metrics depend on the current candidate;see
`docs/sampler_docs/post_midyear/COVERAGE.md` and the latest result checkpoint.
`SAMPLER_MODE vectors` and `SAMPLER_MODE performance` still use this launcher.
Hardware optimization stays inStage4;no new netlist runs are authorized.

## Historical checkpoint notes

Historical4.6a default sampler_stage4_6_test:391 complete/54 expected errors/
33 reset aborts/100733 checks. Source functional914/914,code8087/8637=93.63%
across12 DUT instances. Python104,C48,performance96 and5 fault gates pass.
All96 performance rows unchanged. Historical netlists belong to3.3k/Stage5;
their launchers block changed candidate RTL/settings. No regeneration/stage
advancement until explicit user approval. See STAGE4_6A_RESULTS.json/COVERAGE.md.

Run from sim/ in Questa Transcript: `do sampler/run_uvm.do`.
Current four-mode main UVM checks349 complete polynomials,54 expected errors,
33 reset-aborted jobs and89981 coefficients. Waves,20-group functional
coverage and DUT code coverage appear in GUI/Transcript and save locally.
Raw overall code coverage sums local DUT hit/enabled bins across nine source
instances. Current category counts and fitted metrics are in
docs/sampler_docs/post_midyear/COVERAGE.md. Raw functional coverage is914/914
defined bins=100%; raw DUT code7749/8267=93.73%. Broader requirements remain open.
User review/acceptance precedes Stage5 real netlist checks. Historical Stage1 counts
remain in STAGE1_RESULTS.md and its archived sources.

For fast file capture, set `SAMPLER_MODE vectors` before the same .do.
The 104-job vector set matches Python (19456 coefficients), with separate
vector logs/coverage/waves. Read FIPS204_SAMPLER.md for prepare/capture/compare.

There are now exactly three .do launchers:

| Launcher | DUT / test |
|---|---|
| run_uvm.do | Source RTL; main621-polynomial regression, or vectors/performance modes |
| run_post_synthesis.do | Synthesis-only netlist; same main UVM with public-port184-job test |
| run_post_fit.do | Fitted functional netlist; same public-port184-job test |

Generate vectors and actual netlists first; see FIPS204_SAMPLER.md. The two
netlist launchers share netlist_common.tcl,compile/cache vendor libraries and
leave external waves/functional coverage in the GUI. They do not compile the
source DUT or claim RTL code coverage/SDF timing. Compare each saved104-job
capture with the same Python script using --outputs. Extra80 jobs retain the
independent SV scoreboard. Internal hierarchy probes/groups are unsampled.

Stage 3 measurements: `set SAMPLER_MODE performance`, then the same .do.
96 checked polynomials across72 scenarios write performance.csv, with separate
log/coverage/waves. See THROUGHPUT.md for cycle definitions and the separate
fitted revisions. GUI waves also show pending stages and circular pointers.
Stage5 results and the limits of internal source-only measurements are in COVERAGE.md.

Advanced checker self-test: set SAMPLER_INJECT_FAULT1 in Tcl using
`set SAMPLER_INJECT_FAULT 1`, then the same .do. It intentionally corrupts the
first monitor output and must report COEFFICIENT fatal,zero checked jobs and
0/914 functional hits in separate checker_negative files. A process exit0 is
insufficient; inspect those markers. Normal runs do not set the flag.

Optional SAMPLER_FAULT_KIND:value,index,tag,last,status. All5 separate runs
were rejected with the expected fatal andzero success/error/reset credits.
Checked errors/recovered-reset records are in *_checked_outcomes.csv; group
results in *_outcome_summary.csv. No negative database is merged into positives.

Current Stage4.5:349 complete/54 expected errors/33 reset aborts/89981 checks.
Default sampler_stage4_5_test adds both unlocked status choices,held surplus,
stopped valid through completion,and initialized challenge abort/recovery.
Monitor refusals publish before status retirement,using pre-edge ownership.
20 groups/76 points/31 crosses remain914/914 functional bins100%;raw DUT code
7749/8267=93.73%.5 fault kinds each0/914 bins and zero success/outcome/activity/
protocol rows.72 fixed-seed random jobs and prior directed cases remain included.
Two full runs reproduce six checked witness/summary CSV hashes. RTL/all96
performance records/3.3k fit unchanged. Read COVERAGE.md/STAGE4_5_RESULTS.json.
Remaining code misses are classified without formal waivers;conditions86.78%
and expressions89.58% remain below90%. Stage5 now passes both distinct functional
netlists:184 jobs/39936 checks each;104-job Python captures match19456 values and
each other. Netlist raw730/914 bins,source-only groups unsampled. Read
STAGE5_RESULTS.json/COVERAGE.md. Next:separate actual integration planning.
Finite-model100% is not full signoff.
