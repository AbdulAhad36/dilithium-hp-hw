# ML-DSA sampler (`sampler_v1`)

**Current retained candidate:Stage4.9r.**3537 placed ALMs,3931 registers,
4256 ALUTs,one M10K/1024 bits,zero DSP. Worst Fmax164.74MHz;setup+0.430ns/
hold+0.141ns at unchanged6.500ns. Versus4.9j:91 fewer actual placed ALMs
(2.51%),Fmax+1.58MHz,149 fewer ALUTs;registers+3(router copies). All96
performance records are byte-identical to4.9j,so operating throughput is unchanged.

The mask converter uses one20-bit subtraction with fixed q=2^23-8191,at the
original pre-packing stage. Collector mask values remain canonical. Quartus
uses seed1,HIGH PERFORMANCE EFFORT,and physical register retiming explicitly
OFF. All original payload/mask register guards pass;no guard was relaxed.
The earlier retimed Q fit is unaccepted diagnostic evidence only.

Main UVM621 complete/182 expected errors/51 aborts/159628 comparisons,including
six new zero/borrow-boundary mask jobs. Source is byte-identical to O;its
passing main/Python/C/performance/fault checks are reused after26 file hashes
match. R has a fresh full fit and structural/multicorner reports. Functional
1652/1721=95.99%(69 gaps);raw DUT code15093/15799=95.53%(706 misses). No coverage
cap or invented bins. Evidence:STAGE4_9R_RESULTS.json. StillStage4;acceptance
pending,no commit/integration or new functional netlist simulation.

**Historical retained candidate:Stage4.9j.**3628 placed ALMs,3928
registers,4405 ALUTs,one M10K/zero DSP. Worst Fmax163.16MHz,setup+0.371ns and
hold+0.161ns at unchanged6.500ns. Compared with4.9h:125 fewer placed ALMs
(3.33%),1.22MHz higher Fmax;ALUTs increase220. Placed ALMs are the primary
area metric and the acceptance gate for subsequent optimization.
All96 performance rows are byte-identical to4.9h. A stable per-context job-mode
selector shares collector data selection across circular rows;registered row
masks still own every write. No new stage,depth,port or operating clock change.

Main UVM now615 complete/182 expected errors/51 aborts/158092 comparisons.
Adds54 rejection-burst jobs,128 invalid-byte cases with same-ID recovery and
24 prolonged-stall jobs.23 groups:1652/1721 raw functional bins=95.99%,69 open
gaps. Raw DUT code15084/15790=95.53%,706 unwaived misses. Percentages are measured,
not capped. Python104/19456,C48/12288,checker12,performance96 and5 zero-credit
fault gates pass. Evidence:STAGE4_9J_RESULTS.json;stillStage4,no commit or
integration. Exactly3 simulation launchers remain;native128 is not active.

**Historical retained candidate:Stage4.9h,lower area and higher Fmax.**
3624 needed/3753 placed ALMs,3928 registers(3860 implementation+68 router),
4185 ALUTs,one M10K/1024 bits,zero DSP. Worst Fmax161.94MHz;setup+0.325ns/
hold+0.148ns at unchanged153.85MHz/6.500ns. Versus4.9b:239 fewer ALMs(-6.19%)
and1.43MHz higher Fmax. Versus4.7s:495 fewer ALMs(-12.02%),+3.99MHz.
All96 performance rows are byte-identical to4.9b/4.7s:throughput is preserved.
Main409/105356,Python104/19456,C48/12288,checker12 and five fault gates pass.
Functional914/914;raw DUT code14991/15698=95.50%,707 misses remain unwaived.
Input alignment is shared between A/mask;failure updates preserve priority;
carry capture avoids handshake enables while ready retains restart priority;
challenge last/address payloads bypass redundant selectors. No added cycles.
Evidence:STAGE4_9H_RESULTS.json and THROUGHPUT.md. Still Stage4;user acceptance
pending. Native128 is not active;no commit,integration or new netlist simulation.

**Historical retained candidate:Stage4.9b.**
3863 needed ALMs(-256/-6.22% vs4.7s),3964 placed ALMs,4116 registers,
4396 ALUTs,one M10K/1024 bits,zero DSP. Worst Fmax160.51MHz(+2.56MHz);
setup+0.270ns/hold+0.151ns at unchanged153.85MHz/6.500ns. Four corners pass.
Main409 complete/54 errors/51 aborts/105356 values,Python104/19456,C48/12288,
checker12,performance96 and five zero-credit fault gates pass. All96 CSV rows
are byte-identical to4.7s:throughput at153.85MHz is preserved,not increased.
Functional914/914;raw DUT code15280/15987=95.58%. Native128 is not active.
Four shared wide commit slots reduce duplication;unused challenge sign slots
preload while their ownership counts still advance only on valid handshakes.
Evidence:STAGE4_9B_RESULTS.json and THROUGHPUT.md. Stay Stage4;user acceptance
pending,no commit/integration/new functional netlist verification.

The following sections record previous checkpoints.

**Stage4.8a native128 evaluated and rejected;4.7s source restored.** The trial
passes471 main UVM polynomials/121098 comparisons and Python19456 values;
cycles improve to A270,secret268,mask269. But8151 ALMs,117.74MHz and-1.993ns
setup at6.5ns fail the required timing and area tradeoff. Its complete source,
verification and fit are preserved in STAGE4_8A_RESULTS.json/evidence ZIP.
Active RTL/UVM/build scripts match4.7s again;native128 is not active. Fresh
baseline rebuild reproduces4119ALMs,157.95MHz,+0.169ns setup/+0.155ns hold.
All409 UVM jobs,Python19456 values,96 performance rows and five fault gates
pass again. See STAGE4_8B_RESULTS.json. Stay Stage4;no commit/integration.

**Retained Stage4.7s candidate:150+MHz achieved and timing closed.**
Fresh worst-corner Fmax157.95MHz;setup+0.169ns and hold+0.155ns at the unchanged
153.85MHz(6.500ns) constraint.4119 needed ALMs,4336 registers,one M10K,zero DSP.
Main UVM409 complete/54 expected errors/51 reset aborts/105356 values passes;
Python104/19456,C48/12288,checker12,performance96 and five fault gates pass.
Functional914/914 defined bins;raw DUT source code15274/15981=95.58%.
All96 performance rows equalQ/R. See SAMPLER_PLAN.md,THROUGHPUT.md and
STAGE4_7S_RESULTS.json. User acceptance is pending;stay Stage4. No commit,
stage advancement,integration or new functional netlist simulation performed.

**Archived100MHz baseline:** Stage4.6r: 3487 ALMs, 2445 registers, one M10K, zero DSP; worst Fmax
109.54 MHz, setup +0.871 ns and hold +0.147 ns at unchanged 100 MHz.
Main UVM: 391 complete polynomials, 54 expected errors, 33 reset aborts,
100733 coefficient checks. Functional 914/914 defined bins; raw DUT code
8198/8755 = 93.64%. Python104/19456, C48/12288, checker12/12, performance96
and five coverage fault gates pass. All96 performance rows remain unchanged.

**Synthesis correction:** 4.6a-4.6c hardware improvement claims are withdrawn.
Their source simulations passed, but Quartus dropped the secret-data register
writes and removed all64 packed secret payload bits as constant. Those fits
are archived evidence of a defect, not valid hardware baselines.
4.6d fixes the packed register assignment and confirms64 decode +64 packed
secret registers survive fitting.4.6e retains that fix and calculates capacity
for each context before selection. Against4.6d:5 fewer ALMs,4.05 MHz higher
worst Fmax,setup improves0.363 ns;cycles unchanged.4.6d checkpoint preserved.
Admission trials4.6f/4.6g passed correctness but were slower;both rejected.
Revalidation4.6h restores exact4.6e RTL;only the diagnostic register guard is
corrected to separate original bits from router duplicates. Acceptance pending;
Trials4.6i/j/k were also slower despite passing correctness. All source/build
scripts are restored to4.6e/4.6h;revalidation4.6l retains no new RTL change.
The register-boundary trials4.6m/n also lose:96.26/101.95 MHz and3494/3519 ALMs,
with extra latency despite409 complete source jobs/105340 checks passing.
Both are archived;4.6o preserves exact4.6e. Late-clipping trials4.6p/q also lose.
Current4.6r starts from4.6e and removes the enable from packed payload registers;
the valid bit still owns every use. Fmax improves1.87MHz for5 extra ALMs,with no
changed performance row. Native128 deferred;
acceptance pending.4.6s/t save20/8 ALMs but worsen timing;both are archived.
4.6u restores and revalidates exact4.6r.4.6v snapshots the held secret eta
parameter;all functional checks/cycles pass,but3510ALMs/102.27MHz/+0.222ns
setup are worse. Rejected and archived;4.6w restores/revalidates exact4.6r.
4.6x matrix-carry snapshot and4.6y direct secret compaction also pass correctness
and unchanged cycles,but lose timing/area:3492/3494ALMs,104.50/106.13MHz.
Both are archived/removed;4.6z restores/revalidates exact4.6r. Next:review splitting
secret rotation across the existing packed boundary,with unchanged depth/cycles.
See STAGE4_6Z_RESULTS.json and
THROUGHPUT.md in module docs. No stage advancement or commit.

**Current:Stage4 optimization. User acceptance is pending.** The existing100.33
MHz checkpoint is not accepted as the final result. Stage5 tests already run
are historical evidence only. Next:Stage4.6 measured timing-path optimization;
no stage advancement without explicit user approval.

M.Engg IC Design thesis: hardware implementation and verification of
CRYSTALS-Dilithium / ML-DSA on Cyclone V.

Branch created from `main` at `6a06aca`; shared documentation, project notes,
ignore rules and reusable UVM components brought across from `ntt_v2` at
`577a34b`. The software reference model inherited from main is retained.

| Folder | Purpose |
|---|---|
| `src/sampler/` | Sampler RTL |
| `tb_uvm/tb_uvm_sampler/` | Sampler UVM and independent reference model |
| `tb_uvm/tb_uvm_reusable/` | Shared UVM templates |
| `sim/sampler/` | Simulation launchers and results |
| `quartus/sampler/` | Synthesis project, constraints and reports |
| `docs/sampler_docs/post_midyear/` | Sampler plan, specification and verification docs |
| `docs/` | Shared plan, standards, thesis documents and reference papers |
| `dilithium-sw-model/` | Existing software reference model |

Stage0 contracts are frozen. Current3.3k has all four modes,registered
compaction,narrow mode-sized payloads and circular collectors. Stage4.5 main UVM:
349 complete polynomials,54 expected errors,33 reset aborts/89981 checks.
20 checked groups:914/914 defined functional bins (100%); DUT code93.73%.
Five corruptions each yield zero success/error/reset credits and0/914 bins.
72 random polynomials use3 reproducible seeds; idle/busy/stopped refusals pass.
Both unlocked status choices,held surplus and initialized abort/recovery pass.
Remaining code gaps are classified and unwaived. User has not accepted the metrics.
Python104 jobs/19456 coefficients; C48 cases; performance96 polynomials pass.

Historical3.3k fit: **3543 ALMs, 2388 registers, one M10K, 100.33 MHz worst Fmax, setup +0.033 ns and hold +0.144 ns at 100 MHz**. Current4.6r metrics are at the top of this page.
See [results/comparison](docs/sampler_docs/post_midyear/THROUGHPUT.md) and
[vector flow](docs/sampler_docs/post_midyear/FIPS204_SAMPLER.md).

Keccak and NTT RTL remain on their module branches; integration is separate.

## Sampler roadmap

[Detailed plan](docs/sampler_docs/post_midyear/SAMPLER_PLAN.md).
Stage5:distinct post-synthesis/post-fit functional netlists each pass184 jobs,
156 complete polynomials/39936 coefficient checks. Both104-job captures pass
Python19456 coefficients and match each other. Source metrics remain unchanged.
Exactly3 launchers live in sim/sampler. Next:Stage4 timing/throughput improvement.
See COVERAGE.md/STAGE5_RESULTS.json
in module docs. Fitted RTL/settings remain the unchanged Stage3.3k checkpoint.
No commit/board/actual Keccak-NTT integration or security signoff is implied.
